# -*- coding: utf-8 -*-
"""Consegna pratiche (Altri Enti): logica senza QGIS.

Le schede delle istanze (Strade, RFI, Acque, Soprintendenza, Parchi) scrivono
ogni istanza in una cartella con file numerati «1.N_<istanza>_<documento>»
(1.0 istanza art. 49, 1.1 PL, 1.2 RT+CR, 1.3 bollo, ...). Qui si cercano
quelle cartelle, si dice cosa manca e si prepara per ogni istanza una
cartella di consegna con i file e un PDF unico nell'ordine stabilito.

I documenti personali (documento d'identita', procura) si riconoscono solo
dal nome del file: non si aprono e non si leggono.
"""
import os
import re
import shutil

# tipo di documento -> (ordine nel PDF unico, descrizione)
TIPI = {
    "istanza":     (0, "Istanza"),
    "relazione":   (1, "Relazione tecnica"),
    "planimetria": (2, "Planimetria (PL)"),
    "bollo":       (3, "Imposta di bollo"),
    "allegato":    (4, "Allegato"),
    "documento":   (5, "Documento d'identità"),
    "procura":     (6, "Procura"),
}
OBBLIGATORI = ("istanza", "relazione", "planimetria")
DA_VERIFICARE = ("bollo", "documento", "procura")
ESTENSIONI = (".pdf", ".docx", ".doc", ".p7m")
CARTELLA_CONSEGNA = "Consegna"
_SALTA = {CARTELLA_CONSEGNA.lower(), "_immagini_tavole", "__pycache__"}
_NUMERATO = re.compile(r"^(\d+)\.(\d+)[_ ]")


def tipo_file(nome: str) -> str:
    """Tipo di documento dal NOME del file (non si apre il file)."""
    n = nome.lower()
    base = re.sub(r"(\.p7m)+$", "", n)
    if "procura" in base:
        return "procura"
    if any(k in base for k in ("identit", "documento", "carta d", "_ci.", " ci.",
                               "passaporto", "patente")) or re.match(r"^ci[a-z_ ]", base):
        return "documento"
    if "bollo" in base:
        return "bollo"
    if re.search(r"_pl[\. _]", base) or "planimetri" in base:
        return "planimetria"
    if re.search(r"_rt[\.\+ _]", base) or "relazione tecnica" in base:
        return "relazione"
    m = _NUMERATO.match(base)
    if ("art.49" in base or "art. 49" in base or "istanza" in base or "domanda" in base
            or (m and m.group(2) == "0")):
        return "istanza"
    return "allegato"


def _chiave_ordine(nome: str):
    t = tipo_file(nome)
    m = _NUMERATO.match(nome)
    num = (int(m.group(1)), int(m.group(2))) if m else (99, 99)
    return (TIPI[t][0], num, nome.lower())


def _stem(nome: str) -> str:
    n = re.sub(r"(\.p7m)+$", "", nome, flags=re.I)
    return os.path.splitext(n)[0].lower()


def scegli_file(nomi: list) -> list:
    """Per ogni documento il file da consegnare: il PDF (anche firmato .p7m)
    batte il DOCX con lo stesso nome. Ritorna [(nome, tipo, nota)] in ordine."""
    per_stem = {}
    for n in nomi:
        if not n.lower().endswith(ESTENSIONI) or n.startswith("~$"):
            continue
        per_stem.setdefault(_stem(n), []).append(n)
    out = []
    for _s, gruppo in per_stem.items():
        firmato = [n for n in gruppo if n.lower().endswith(".p7m")]
        pdf = [n for n in gruppo if n.lower().endswith(".pdf")]
        if firmato:
            out.append((firmato[0], tipo_file(firmato[0]), "firmato digitalmente (.p7m): "
                        "si consegna così, non entra nel PDF unico"))
        elif pdf:
            out.append((pdf[0], tipo_file(pdf[0]), ""))
        else:
            n = gruppo[0]
            out.append((n, tipo_file(n), "solo Word: salvalo in PDF (e firmalo) per "
                        "metterlo nel PDF unico"))
    out.sort(key=lambda x: _chiave_ordine(x[0]))
    return out


def e_cartella_istanza(nomi: list) -> bool:
    """Una cartella e' un'istanza se ha almeno due file numerati 1.N_..."""
    return sum(1 for n in nomi if _NUMERATO.match(n.lower())
               and n.lower().endswith(ESTENSIONI)) >= 2


def cerca_istanze(radice: str, profondita: int = 5) -> list:
    """Cartelle di istanza sotto `radice` (salta Consegna e le immagini).
    [{'nome', 'cartella', 'file': [(nome, tipo, nota)], 'mancano': [...],
      'verificare': [...], 'note': [...]}] in ordine di nome."""
    out = []
    if not radice or not os.path.isdir(radice):
        return out
    base_liv = radice.rstrip("\\/").count(os.sep)
    for cart, dirs, files in os.walk(radice):
        dirs[:] = [d for d in dirs if d.lower() not in _SALTA and not d.startswith(".")]
        if cart.count(os.sep) - base_liv >= profondita:
            dirs[:] = []
        if not e_cartella_istanza(files):
            continue
        scelti = scegli_file(files)
        tipi = {t for _n, t, _x in scelti}
        out.append({
            "nome": os.path.basename(cart),
            "cartella": cart,
            "file": scelti,
            "mancano": [TIPI[t][1] for t in OBBLIGATORI if t not in tipi],
            "verificare": [TIPI[t][1] for t in DA_VERIFICARE if t not in tipi],
            "note": ["%s: %s" % (n, x) for n, _t, x in scelti if x],
        })
    out.sort(key=lambda d: d["nome"].lower())
    return out


def stato(ist: dict) -> str:
    if ist["mancano"]:
        return "incompleta"
    if any("solo Word" in n for n in ist["note"]):
        return STATO_WORD
    return "completa"


# alcuni documenti ci sono solo in Word: si consegnano, ma fuori dal PDF unico
STATO_WORD = "completa, ma con file solo in Word"


def file_solo_word(ist: dict) -> list:
    """Nomi dei documenti dell'istanza che ci sono solo in Word (.docx)."""
    return [n for n, _t, x in ist["file"] if x and "solo Word" in x]


def unisci_pdf(percorsi: list, uscita: str) -> int:
    """PDF unico con pypdf (o PyPDF2). Ritorna il numero di pagine."""
    try:
        from pypdf import PdfReader, PdfWriter
    except ImportError:
        from PyPDF2 import PdfReader, PdfWriter
    w = PdfWriter()
    pagine = 0
    for p in percorsi:
        r = PdfReader(p)
        for pg in r.pages:
            w.add_page(pg)
            pagine += 1
    os.makedirs(os.path.dirname(uscita) or ".", exist_ok=True)
    with open(uscita, "wb") as f:
        w.write(f)
    return pagine


def prepara_consegna(ist: dict, radice_consegna: str, limite_mb: float = 30.0) -> dict:
    """Cartella <radice_consegna>/<istanza> con i file scelti (copiati) e il
    PDF unico «<istanza>_COMPLETO.pdf» (solo i PDF, nell'ordine stabilito;
    documento d'identita' e procura restano file separati).
    Ritorna {'cartella', 'pdf', 'pagine', 'mb', 'mb_totali', 'avvisi'}."""
    dest = os.path.join(radice_consegna, ist["nome"])
    os.makedirs(dest, exist_ok=True)
    avvisi = []
    pdf = []
    for nome, _t, _nota in ist["file"]:
        src = os.path.join(ist["cartella"], nome)
        shutil.copy2(src, os.path.join(dest, nome))
        # documento d'identita' e procura restano file a parte (non si uniscono)
        if nome.lower().endswith(".pdf") and _t not in ("documento", "procura"):
            pdf.append(src)
    uscita = os.path.join(dest, "%s_COMPLETO.pdf" % ist["nome"])
    pagine = 0
    if pdf:
        try:
            pagine = unisci_pdf(pdf, uscita)
        except Exception as e:  # noqa: BLE001
            avvisi.append("PDF unico non creato: %s" % e)
            uscita = ""
    else:
        uscita = ""
        avvisi.append("nessun PDF da unire")
    mb = os.path.getsize(uscita) / 1048576.0 if uscita else 0.0
    mb_tot = sum(os.path.getsize(os.path.join(dest, n)) for n in os.listdir(dest)
                 if os.path.isfile(os.path.join(dest, n))) / 1048576.0
    if limite_mb and mb > limite_mb:
        avvisi.append("PDF unico di %.1f MB: supera il limite di %.0f MB della PEC"
                      % (mb, limite_mb))
    return {"cartella": dest, "pdf": uscita, "pagine": pagine, "mb": mb,
            "mb_totali": mb_tot, "avvisi": avvisi}
