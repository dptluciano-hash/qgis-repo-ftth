"""Suggerimento dei comuni italiani nei campi «Comune».

L'elenco (nome;sigla provincia) è assets/comuni_italiani.txt, ricavato dal
file ISTAT «Elenco-comuni-italiani.csv»: funziona senza internet.
Mentre si scrive compare «Castiglione del Lago (PG)»; scelta la voce, nel
campo resta solo il nome del comune.
"""
import os

_FILE = os.path.join(os.path.dirname(__file__), "assets", "comuni_italiani.txt")
_CACHE = None
_PROVINCE = {}      # sigla -> nome della provincia (dall'elenco ISTAT)


def elenco():
    """[(nome, sigla), ...] dei comuni italiani (vuoto se il file manca)."""
    global _CACHE
    if _CACHE is None:
        out = []
        try:
            with open(_FILE, encoding="utf-8") as f:
                for riga in f:
                    riga = riga.strip()
                    if not riga or riga.startswith("#") or ";" not in riga:
                        continue
                    parti = riga.split(";")
                    nome, sigla = parti[0], parti[1]
                    if len(parti) > 2 and parti[2]:
                        # «Bolzano/Bozen» -> «Bolzano»
                        _PROVINCE.setdefault(sigla, parti[2].split("/")[0].strip())
                    out.append((nome, sigla))
        except OSError:
            pass
        _CACHE = out
    return _CACHE


def cerca(testo, limite=None):
    """Comuni che contengono `testo` (senza badare alle maiuscole); prima
    quelli che iniziano col testo."""
    t = (testo or "").strip().lower()
    if not t:
        return []
    inizio = [c for c in elenco() if c[0].lower().startswith(t)]
    dentro = [c for c in elenco() if t in c[0].lower() and not c[0].lower().startswith(t)]
    res = inizio + dentro
    return res[:limite] if limite else res


def sigla_di(nome):
    """Sigla della provincia dall'elenco ISTAT, se il nome è univoco."""
    n = (nome or "").strip().lower()
    sigle = {s for c, s in elenco() if c.lower() == n}
    return sigle.pop() if len(sigle) == 1 else ""


def nome_provincia(sigla):
    """«SA» -> «Salerno» (vuoto se la sigla non è nota)."""
    elenco()
    return _PROVINCE.get((sigla or "").strip().upper(), "")


def collega_provincia(campo, prov):
    """Screening: scritto o scelto il comune, il campo Provincia prende il NOME
    della provincia (serve a Nominatim per le omonimie). Con un nome che
    esiste in più province vale la voce scelta dalla tendina («Nome (SG)»);
    scritto a mano resta da compilare."""
    from qgis.PyQt.QtCore import QModelIndex, QTimer
    stato = {"ultimo": None, "scelta": ""}

    def da_testo():
        nome = campo.text().strip()
        if not nome or nome.lower() == stato["ultimo"]:
            return
        stato["ultimo"] = nome.lower()
        sg = stato["scelta"] or sigla_di(nome)
        stato["scelta"] = ""
        prov.setText(nome_provincia(sg) if sg else "")

    def da_tendina(indice):
        testo = str(indice.data() or "")
        if testo.endswith(")") and "(" in testo:
            stato["scelta"] = testo.rsplit("(", 1)[1].rstrip(")").strip()
        stato["ultimo"] = None              # la voce scelta vale anche se il nome è lo stesso
        QTimer.singleShot(0, da_testo)

    campo.editingFinished.connect(da_testo)
    comp = campo.completer()
    if comp is not None:
        try:
            comp.activated[QModelIndex].connect(da_tendina)
        except Exception:  # noqa: BLE001
            pass
    return da_testo


def dati_online(nome):
    """{'prov': sigla, 'cap': cap} dal servizio usato dallo Screening
    (Nominatim/OSM). Vuoto se non risolto."""
    try:
        from . import ftth_screening as scr, ftth_rfi as rfi
    except ImportError:
        import ftth_screening as scr
        import ftth_rfi as rfi
    d = scr.risolvi_comune(nome, None).data or {}
    prov = rfi.sigla_provincia(d["provincia"]) if d.get("provincia") else ""
    cap = str(d["cap"]).split(";")[0].strip() if d.get("cap") else ""
    return {"prov": prov or "", "cap": cap}


def collega_prov_cap(campo, prov, cap, log=None):
    """Scritto (o scelto dalla tendina) il comune, compila provincia e CAP:
    la provincia subito dall'elenco ISTAT, il CAP da internet. Se il comune
    cambia, provincia e CAP del comune precedente vengono sostituiti."""
    from qgis.PyQt.QtCore import Qt, QTimer
    from qgis.PyQt.QtWidgets import QApplication
    stato = {"ultimo": None}

    def aggiorna():
        nome = campo.text().strip()
        if not nome or nome.lower() == stato["ultimo"]:
            return
        stato["ultimo"] = nome.lower()
        # sempre sostituiti: provincia e CAP già presenti possono essere di un
        # altro comune (scritto prima o arrivato da un'altra scheda)
        prov.clear(); cap.clear()
        sg = sigla_di(nome)
        if sg:
            prov.setText(sg)
        QApplication.setOverrideCursor(Qt.BusyCursor)
        try:
            d = dati_online(nome)
        except Exception as e:  # noqa: BLE001
            d = {}
            if log:
                log("CAP non trovato automaticamente (%s): compilalo a mano." % e)
        finally:
            QApplication.restoreOverrideCursor()
        if d.get("prov") and not prov.text().strip():
            prov.setText(d["prov"])
        if d.get("cap") and not cap.text().strip():
            cap.setText(d["cap"])

    campo.editingFinished.connect(aggiorna)
    comp = campo.completer()
    if comp is not None:
        try:
            comp.activated[str].connect(lambda *_: QTimer.singleShot(0, aggiorna))
        except Exception:  # noqa: BLE001
            pass
    return aggiorna


def norm(s) -> str:
    """Nome di comune confrontabile: minuscolo, senza accenti, apostrofi,
    trattini e spazi doppi."""
    import unicodedata
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode()
    return " ".join(s.lower().replace("'", " ").replace("-", " ").split())


def comuni_degli_shape(project=None, max_per_layer=20000):
    """Comuni scritti negli shape del progetto (campo COMUNE di armadi,
    pozzetti, civici, PTE…): [(nome, quanti)], il più frequente per primo,
    e i layer letti. Vuoto se nessun layer ha il campo valorizzato."""
    from collections import Counter
    from qgis.core import QgsFeatureRequest, QgsProject, QgsVectorLayer
    project = project or QgsProject.instance()
    conta = Counter()
    forma = {}
    letti = []
    for lyr in project.mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            continue
        # solo elementi di rete (punti e linee): i poligoni dei confini
        # comunali hanno anch'essi un campo COMUNE, ma con tutti i comuni
        if lyr.geometryType() not in (0, 1):
            continue
        campo = next((f.name() for f in lyr.fields() if f.name().upper() == "COMUNE"), None)
        if campo is None:
            continue
        req = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry) \
            .setSubsetOfAttributes([campo], lyr.fields()).setLimit(max_per_layer)
        n0 = sum(conta.values())
        for f in lyr.getFeatures(req):
            v = f[campo]
            if v is None or str(v).strip() in ("", "NULL") or str(v).strip().isdigit():
                continue
            k = norm(v)
            conta[k] += 1
            forma.setdefault(k, str(v).strip())
        if sum(conta.values()) > n0:
            letti.append(lyr.name())
    return [(forma[k], n) for k, n in conta.most_common()], letti


def controlla_con_shape(nome, project=None):
    """None se il comune scritto va bene (o non si può verificare); altrimenti
    (comune degli shape, layer letti). Un progetto a cavallo di due comuni:
    va bene ogni comune presente in almeno il 5% degli elementi."""
    if not (nome or "").strip():
        return None
    try:
        voci, letti = comuni_degli_shape(project)
    except Exception:  # noqa: BLE001
        return None
    if not voci:
        return None
    tot = sum(n for _c, n in voci)
    ok = {norm(c) for c, n in voci if n >= 0.05 * tot}
    if norm(nome) in ok:
        return None
    return voci[0][0], letti


def collega_controllo_shape(campo, maiuscolo=False):
    """Scritto o scelto il comune, lo confronta con il campo COMUNE degli shape
    del progetto. Se non corrisponde il campo si colora e una domanda propone
    il comune del progetto. Stesso controllo in tutte le schede (Screening,
    Strade, RFI, Acque, Soprintendenza, Parchi, relazione comunale)."""
    from qgis.PyQt.QtCore import QTimer
    from qgis.PyQt.QtWidgets import QMessageBox
    stato = {"chiesto": set(), "occupato": False}
    stile0 = campo.styleSheet()

    def verifica():
        if stato["occupato"]:
            return
        nome = campo.text().strip()
        esito = controlla_con_shape(nome)
        if esito is None:
            campo.setStyleSheet(stile0)
            campo.setToolTip("")
            return
        vero, letti = esito
        vero_txt = vero.upper() if maiuscolo else vero
        campo.setStyleSheet(stile0 + "QLineEdit { border: 2px solid #d9534f; }")
        campo.setToolTip("Negli shape del progetto il comune è «%s»." % vero)
        # comune scritto dal plugin (nome del file del progetto, altra scheda,
        # lavoro salvato) e mai toccato: si corregge da solo, senza domanda
        if not campo.isModified():
            campo.setText(vero_txt)
            campo.setStyleSheet(stile0)
            campo.setToolTip("Comune preso dagli shape del progetto (campo COMUNE).")
            campo.editingFinished.emit()
            return
        coppia = (norm(nome), norm(vero))
        if coppia in stato["chiesto"]:
            return
        stato["chiesto"].add(coppia)
        stato["occupato"] = True
        try:
            r = QMessageBox.question(
                campo.window(), "Comune diverso dagli shape del progetto",
                "Hai scritto «%s», ma negli shape del progetto (campo COMUNE di %s) "
                "il comune è «%s».\n\nUso «%s»?" % (
                    nome, ", ".join(letti[:4]) + ("…" if len(letti) > 4 else ""),
                    vero, vero_txt),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        finally:
            stato["occupato"] = False
        if r == QMessageBox.Yes:
            campo.setText(vero_txt)
            campo.setStyleSheet(stile0)
            campo.setToolTip("")
            campo.editingFinished.emit()       # provincia, CAP, ricerche collegate

    campo.editingFinished.connect(lambda: QTimer.singleShot(0, verifica))

    # anche quando la scheda si apre: il comune può essere già scritto (da
    # un'altra scheda, dal progetto salvato) senza che nessuno lo abbia toccato
    from qgis.PyQt.QtCore import QEvent, QObject

    class _AllaVista(QObject):
        def eventFilter(self, obj, ev):
            if ev.type() == QEvent.Show and campo.text().strip():
                QTimer.singleShot(150, verifica)
            return False
    campo._controllo_shape = _AllaVista(campo)
    campo.installEventFilter(campo._controllo_shape)
    return verifica


def aggiungi_suggerimenti(campo, maiuscolo=False):
    """Collega al QLineEdit `campo` il suggerimento dei comuni. La tendina
    mostra «Nome (SG)», nel campo va solo il nome (MAIUSCOLO se richiesto,
    come nelle schede che lo scrivono così). Collega anche il controllo con
    il comune degli shape del progetto."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QStandardItemModel, QStandardItem
    from qgis.PyQt.QtWidgets import QCompleter
    try:
        collega_controllo_shape(campo, maiuscolo)
    except Exception:  # noqa: BLE001
        pass
    comuni = elenco()
    if not comuni:
        return None
    modello = QStandardItemModel(campo)
    for nome, sigla in comuni:
        it = QStandardItem("%s (%s)" % (nome, sigla) if sigla else nome)
        it.setData(nome.upper() if maiuscolo else nome, Qt.UserRole)
        it.setEditable(False)
        modello.appendRow(it)
    comp = QCompleter(modello, campo)
    comp.setCompletionRole(Qt.UserRole)       # si cerca e si inserisce il solo nome
    comp.setCaseSensitivity(Qt.CaseInsensitive)
    comp.setFilterMode(Qt.MatchContains)
    comp.setCompletionMode(QCompleter.PopupCompletion)
    comp.setMaxVisibleItems(12)
    campo.setCompleter(comp)
    return comp
