# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Scheda «Vista istanze» (Altri Enti): cosa vedere in mappa, incrociando
tutte le schede istanze.

Un albero con un occhio per voce: Suolo comunale (rete senza nessuna
istanza), Strade (divise in statali, provinciali, regionali… e poi strada per
strada), Ferrovie (linea, poi istanza per tipologia e stazione), Acque,
Soprintendenza, Parchi. Si accende o spegne qualunque combinazione: tutto il
progetto, solo il comunale, solo le SP, solo una linea… I dati vengono dai
campi IST_* scritti negli shape principali con «Conferma le interferenze
spuntate»; la vista usa le stesse copie temporanee degli occhi delle schede
(i layer principali non si toccano)."""
import re

try:
    from . import ftth_gruppi_istanze as GR
except ImportError:  # pragma: no cover
    import ftth_gruppi_istanze as GR

TITOLI = (("strade", "Strade"), ("rfi", "Ferrovie"), ("acque", "Corsi d'acqua"),
          ("sopr", "Soprintendenza (aree vincolate)"), ("parchi", "Parchi e Natura 2000"))
FAMIGLIE_STRADE = (("A", "Autostrade (A)"), ("SS", "Strade statali (SS)"),
                   ("SR", "Strade regionali (SR)"), ("SP", "Strade provinciali (SP)"))


def famiglia_strada(nome: str) -> str:
    n = (nome or "").upper().replace(".", "").strip()
    for sigla, titolo in FAMIGLIE_STRADE:
        if re.match(r"^%s\s*\d" % sigla, n):
            return titolo
    return "Altre strade"


def linea_di(nome: str) -> str:
    return GR.pulisci(nome).split(" - ")[0]


def _vuoto():
    return {"tratte": set(), "pozzetti": set(), "armadi": set()}


def _conta(d):
    return "%d tratte, %d pozzetti, %d armadi" % (
        len(d["tratte"]), len(d["pozzetti"]), len(d["armadi"]))


def dati_progetto(project) -> dict:
    """{sezione: {istanza: fid}} e '' = rete senza nessuna istanza."""
    out, liberi = {}, None
    for sez, _t in TITOLI:
        try:
            per = GR.istanze_nel_campo(project, sez)
        except Exception:  # noqa: BLE001
            continue
        senza = per.pop("", _vuoto())
        liberi = senza if liberi is None else {k: liberi[k] & senza[k] for k in liberi}
        if per:
            out[sez] = per
    out[""] = liberi or _vuoto()
    return out


def scheda(dlg):
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QHBoxLayout, QPushButton, QTreeWidget, QTreeWidgetItem,
                                     QVBoxLayout, QWidget)
    try:
        from qgis.core import QgsApplication
        ic_on = QgsApplication.getThemeIcon("/mActionShowAllLayers.svg")
        ic_off = QgsApplication.getThemeIcon("/mActionHideAllLayers.svg")
    except Exception:  # noqa: BLE001
        ic_on = ic_off = None
    w = QWidget()
    v = QVBoxLayout(w)
    v.addWidget(dlg._desc(
        "Cosa vedere in mappa, incrociando tutte le schede istanze: accendi o spegni con "
        "l'occhio il suolo comunale, una famiglia di strade (statali, provinciali…), una "
        "strada, una linea ferroviaria, un corso d'acqua, un'area. Le voci vengono dalle "
        "interferenze confermate nelle schede (campi IST_* degli shape); i layer "
        "principali non si toccano."))
    gb = dlg._gruppo("Vista delle istanze in mappa", compresso=False)
    vg = QVBoxLayout(gb)
    r = QHBoxLayout()
    b_tutto = QPushButton("Mostra tutto il progetto")
    b_tutto.setProperty("primario", True)
    b_com = QPushButton("Solo suolo comunale")
    b_ist = QPushButton("Solo le istanze")
    b_agg = QPushButton("Aggiorna l'elenco")
    b_agg.setToolTip("Rilegge le istanze dagli shape (dopo una nuova conferma in una scheda).")
    for b in (b_tutto, b_com, b_ist, b_agg):
        r.addWidget(b)
    r.addStretch()
    vg.addLayout(r)
    albero = QTreeWidget()
    albero.setHeaderLabels(["Voce", "Elementi"])
    albero.setMinimumHeight(320)
    albero.setColumnWidth(0, 430)
    vg.addWidget(albero)
    v.addWidget(gb)
    v.addStretch()
    stato = {"dati": {}, "occupato": False}

    def _icona(it):
        if ic_on is None or ic_on.isNull():
            return
        it.setIcon(0, ic_off if it.checkState(0) == Qt.Unchecked else ic_on)

    def _voce(padre, testo, dato=None, conta=""):
        it = QTreeWidgetItem(padre, [testo, conta])
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
        it.setCheckState(0, Qt.Checked)
        if dato is not None:
            it.setData(0, Qt.UserRole, dato)
        _icona(it)
        return it

    def aggiorna(*_a):
        stato["occupato"] = True
        albero.blockSignals(True)
        albero.clear()
        dati = dati_progetto(dlg.project)
        stato["dati"] = dati
        _voce(albero, "Suolo comunale (rete senza istanze)", ("", ""), _conta(dati[""]))
        for sez, titolo in TITOLI:
            per = dati.get(sez)
            if not per:
                continue
            radice = _voce(albero, titolo)
            if sez == "strade":
                gruppi = {}
                for nome in sorted(per):
                    gruppi.setdefault(famiglia_strada(nome), []).append(nome)
                for fam, _t in [(t, None) for _s, t in FAMIGLIE_STRADE] + [("Altre strade", None)]:
                    if fam not in gruppi:
                        continue
                    g = _voce(radice, fam)
                    for nome in gruppi[fam]:
                        _voce(g, nome, (sez, nome), _conta(per[nome]))
            elif sez == "rfi":
                gruppi = {}
                for nome in sorted(per):
                    gruppi.setdefault(linea_di(nome), []).append(nome)
                for linea, nomi in gruppi.items():
                    g = _voce(radice, linea)
                    for nome in nomi:
                        resto = GR.pulisci(nome)[len(linea):].strip(" -") or nome
                        _voce(g, resto, (sez, nome), _conta(per[nome]))
            else:
                for nome in sorted(per):
                    _voce(radice, nome, (sez, nome), _conta(per[nome]))
        albero.expandAll()
        albero.blockSignals(False)
        stato["occupato"] = False
        if len(dati) == 1:
            QTreeWidgetItem(albero, ["Nessuna istanza confermata: premi «Conferma le "
                                     "interferenze spuntate» nelle schede istanze.", ""])

    def _foglie():
        out = []

        def giro(it):
            if it.childCount() == 0:
                d = it.data(0, Qt.UserRole)
                if d is not None:
                    out.append((it, tuple(d)))
            for k in range(it.childCount()):
                giro(it.child(k))
        for k in range(albero.topLevelItemCount()):
            giro(albero.topLevelItem(k))
        return out

    def applica(*_a):
        if stato["occupato"]:
            return
        foglie = _foglie()
        accese = [d for it, d in foglie if it.checkState(0) == Qt.Checked]
        for it, _d in foglie:
            _icona(it)
        # anche i nodi intermedi (strade, famiglie, linee) cambiano occhio
        def giro(it):
            _icona(it)
            for k in range(it.childCount()):
                giro(it.child(k))
        albero.blockSignals(True)
        for k in range(albero.topLevelItemCount()):
            giro(albero.topLevelItem(k))
        albero.blockSignals(False)
        try:
            if len(accese) == len(foglie):
                GR.togli_vista(dlg.project)
            else:
                vis = _vuoto()
                dati = stato["dati"]
                for sez, nome in accese:
                    d = dati[""] if sez == "" else dati.get(sez, {}).get(nome)
                    if d:
                        for k in vis:
                            vis[k] |= d[k]
                nome_v = "vista " + (accese[0][1] or "suolo comunale") if len(accese) == 1 \
                    else "vista %d voci" % len(accese)
                GR.mostra_fid(dlg.project, "Vista incrociata", vis, nome_v)
            dlg.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(dlg, "Vista istanze", "Vista non applicata:\n%s" % e)

    def _solo(pred):
        albero.blockSignals(True)
        for it, d in _foglie():
            it.setCheckState(0, Qt.Checked if pred(d) else Qt.Unchecked)
        albero.blockSignals(False)
        applica()

    albero.itemChanged.connect(lambda *_a: applica())
    b_tutto.clicked.connect(lambda: _solo(lambda d: True))
    b_com.clicked.connect(lambda: _solo(lambda d: d[0] == ""))
    b_ist.clicked.connect(lambda: _solo(lambda d: d[0] != ""))
    b_agg.clicked.connect(aggiorna)
    try:
        aggiorna()
        dlg.project.readProject.connect(lambda *_: aggiorna())
    except Exception:  # noqa: BLE001
        pass
    w._albero = albero          # per le prove
    w._aggiorna = aggiorna
    w._solo = _solo
    return w
