# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Scheda «Vista istanze» (Altri Enti): cosa vedere in mappa, incrociando
tutte le schede istanze.

Un albero con un occhio per voce: Suolo comunale (rete senza nessuna
istanza), Strade (divise in statali, provinciali, regionali… e poi strada per
strada), Ferrovie (linea, poi istanza per tipologia e stazione), Acque,
Soprintendenza, Parchi. Si accende o spegne qualunque combinazione: tutto il
progetto, solo il comunale, solo le SP, solo una linea… I dati vengono dai
campi IST_* scritti negli shape principali con «Conferma le interferenze
spuntate»; la vista usa le stesse copie temporanee degli occhi delle schede
(i layer principali non si toccano)."""
import re

try:
    from . import ftth_gruppi_istanze as GR
except ImportError:  # pragma: no cover
    import ftth_gruppi_istanze as GR

TITOLI = (("strade", "Strade"), ("rfi", "Ferrovie"), ("acque", "Corsi d'acqua"),
          ("sopr", "Soprintendenza (aree vincolate)"), ("parchi", "Parchi e Natura 2000"))
FAMIGLIE_STRADE = (("A", "Autostrade (A)"), ("SS", "Strade statali (SS)"),
                   ("SR", "Strade regionali (SR)"), ("SP", "Strade provinciali (SP)"))


def famiglia_strada(nome: str) -> str:
    n = (nome or "").upper().replace(".", "").strip()
    for sigla, titolo in FAMIGLIE_STRADE:
        if re.match(r"^%s\s*\d" % sigla, n):
            return titolo
    return "Altre strade"


def linea_di(nome: str) -> str:
    return GR.pulisci(nome).split(" - ")[0]


def _vuoto():
    return {"tratte": set(), "pozzetti": set(), "armadi": set()}


def _conta(d):
    return "%d tratte, %d pozzetti, %d armadi" % (
        len(d["tratte"]), len(d["pozzetti"]), len(d["armadi"]))


def dati_progetto(project) -> dict:
    """{sezione: {istanza: fid}} e '' = rete senza nessuna istanza."""
    out, liberi = {}, None
    for sez, _t in TITOLI:
        try:
            per = GR.istanze_nel_campo(project, sez)
        except Exception:  # noqa: BLE001
            continue
        senza = per.pop("", _vuoto())
        liberi = senza if liberi is None else {k: liberi[k] & senza[k] for k in liberi}
        if per:
            out[sez] = per
    out[""] = liberi or _vuoto()
    return out


def scheda(dlg):
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QHBoxLayout, QPushButton, QTreeWidget, QTreeWidgetItem,
                                     QVBoxLayout, QWidget)
    try:
        from qgis.core import QgsApplication
        ic_on = QgsApplication.getThemeIcon("/mActionShowAllLayers.svg")
        ic_off = QgsApplication.getThemeIcon("/mActionHideAllLayers.svg")
    except Exception:  # noqa: BLE001
        ic_on = ic_off = None
    w = QWidget()
    v = QVBoxLayout(w)
    v.addWidget(dlg._desc(
        "Cosa vedere in mappa: l'istanza comunale (la rete senza istanze) e le istanze agli "
        "altri enti (strade, ferrovie, corsi d'acqua, aree). Spunta o togli la spunta alle "
        "voci. Quando inizi le istanze agli altri enti premi «Dividi per gruppi»: nel "
        "pannello Layer il progetto comunale va nel gruppo «Comunale» e le istanze in "
        "«Altri enti»."))
    gb = dlg._gruppo("Vista delle istanze in mappa", compresso=False)
    vg = QVBoxLayout(gb)
    r = QHBoxLayout()
    b_div = QPushButton("Dividi per gruppi")
    b_div.setToolTip("Pannello Layer: Permesso, Ottico, Foto… nel gruppo «Comunale»; le istanze "
                     "agli altri enti in «Altri enti». Le cartografie comuni restano fuori.")
    b_tutto = QPushButton("Tutto")
    b_tutto.setProperty("primario", True)
    b_com = QPushButton("Solo comunale")
    b_ist = QPushButton("Solo istanze altri enti")
    b_agg = QPushButton("Aggiorna")
    b_agg.setToolTip("Rilegge le istanze dagli shape (dopo una nuova conferma in una scheda).")
    for b in (b_div, b_tutto, b_com, b_ist, b_agg):
        r.addWidget(b)
    r.addStretch()
    vg.addLayout(r)
    albero = QTreeWidget()
    albero.setHeaderLabels(["Voce", "Elementi"])
    albero.setMinimumHeight(320)
    albero.setColumnWidth(0, 430)
    vg.addWidget(albero)
    # trasparenza dei layer comunali veri: per vedere le istanze sopra
    from qgis.PyQt.QtWidgets import QLabel, QSlider
    rt = QHBoxLayout()
    rt.addWidget(QLabel("Trasparenza della rete comunale:"))
    sl = QSlider(Qt.Horizontal)
    sl.setRange(0, 90)
    lab_t = QLabel("0%")
    lab_t.setMinimumWidth(34)

    def _trasp(val):
        lab_t.setText("%d%%" % val)
        for _c, nome_l, _t in GR.LAYER:
            l_ = GR.layer_principale(dlg.project, nome_l)
            if l_ is not None:
                l_.setOpacity(1.0 - val / 100.0)
                l_.triggerRepaint()

    def _cursore(val):
        _trasp(val)
        # con tutto acceso le istanze stanno nei layer veri: per lasciarle
        # piene mentre la rete comunale sfuma servono le copie (e viceversa)
        foglie = _foglie()
        tutto = foglie and all(it.checkState(0) == Qt.Checked for it, _d in foglie)
        ist = any(d[0] != "" for _it, d in foglie)
        if tutto and ist and bool(val) != stato.get("copie", False):
            applica()
    sl.valueChanged.connect(_cursore)
    rt.addWidget(sl, 1)
    rt.addWidget(lab_t)
    vg.addLayout(rt)
    v.addWidget(gb)
    v.addStretch()
    stato = {"dati": {}, "occupato": False}

    def _icona(it):
        if ic_on is None or ic_on.isNull() or it.data(0, Qt.CheckStateRole) is None:
            return
        it.setIcon(0, ic_off if it.checkState(0) == Qt.Unchecked else ic_on)

    def _voce(padre, testo, dato=None, conta=""):
        it = QTreeWidgetItem(padre, [testo, conta])
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
        it.setCheckState(0, Qt.Checked)
        if dato is not None:
            it.setData(0, Qt.UserRole, dato)
        _icona(it)
        return it

    def aggiorna(*_a):
        stato["occupato"] = True
        albero.blockSignals(True)
        albero.clear()
        dati = dati_progetto(dlg.project)
        stato["dati"] = dati
        _voce(albero, "Istanza comunale (rete senza istanze)", ("", ""), _conta(dati[""]))
        for sez, titolo in TITOLI:
            per = dati.get(sez)
            if not per:
                continue
            radice = _voce(albero, titolo)
            if sez == "strade":
                gruppi = {}
                for nome in sorted(per):
                    gruppi.setdefault(famiglia_strada(nome), []).append(nome)
                for fam, _t in [(t, None) for _s, t in FAMIGLIE_STRADE] + [("Altre strade", None)]:
                    if fam not in gruppi:
                        continue
                    g = _voce(radice, fam)
                    for nome in gruppi[fam]:
                        _voce(g, nome, (sez, nome), _conta(per[nome]))
            elif sez == "rfi":
                gruppi = {}
                for nome in sorted(per):
                    gruppi.setdefault(linea_di(nome), []).append(nome)
                for linea, nomi in gruppi.items():
                    g = _voce(radice, linea)
                    for nome in nomi:
                        resto = GR.pulisci(nome)[len(linea):].strip(" -") or nome
                        _voce(g, resto, (sez, nome), _conta(per[nome]))
            else:
                for nome in sorted(per):
                    _voce(radice, nome, (sez, nome), _conta(per[nome]))
        albero.expandAll()
        albero.blockSignals(False)
        stato["occupato"] = False
        if len(dati) == 1:
            from qgis.PyQt.QtWidgets import QLabel
            it = QTreeWidgetItem(albero, ["", ""])
            it.setFirstColumnSpanned(True)
            it.setFlags(Qt.NoItemFlags)
            lab = QLabel(
                "<b>Per ora c'è solo la rete comunale.</b><br>"
                "Le istanze per gli altri enti (strade, ferrovie, acque) appariranno qui "
                "sotto quando le crei. Ecco come:<br>"
                "1. apri la scheda <b>Istanze Strade</b> (oppure RFI o Acque);<br>"
                "2. al passo 3 premi <b>«Trova le interferenze»</b>;<br>"
                "3. metti la spunta sulle interferenze che ti servono;<br>"
                "4. premi <b>«Conferma le interferenze spuntate»</b>.<br>"
                "Poi torna qui e premi <b>«Aggiorna»</b>.")
            lab.setWordWrap(True)
            lab.setStyleSheet("color:#555; padding:6px;")
            albero.setItemWidget(it, 0, lab)

    def _foglie():
        out = []

        def giro(it):
            if it.childCount() == 0:
                d = it.data(0, Qt.UserRole)
                if d is not None:
                    out.append((it, tuple(d)))
            for k in range(it.childCount()):
                giro(it.child(k))
        for k in range(albero.topLevelItemCount()):
            giro(albero.topLevelItem(k))
        return out

    def applica(*_a):
        if stato["occupato"]:
            return
        foglie = _foglie()
        accese = [d for it, d in foglie if it.checkState(0) == Qt.Checked]
        for it, _d in foglie:
            _icona(it)
        # anche i nodi intermedi (strade, famiglie, linee) cambiano occhio
        def giro(it):
            _icona(it)
            for k in range(it.childCount()):
                giro(it.child(k))
        albero.blockSignals(True)
        for k in range(albero.topLevelItemCount()):
            giro(albero.topLevelItem(k))
        albero.blockSignals(False)
        try:
            from . import ftth_pannello as PN
            com_acceso = any(sez == "" for sez, _n in accese)
            ist_accese = [(s, n) for s, n in accese if s != ""]
            ci_sono_istanze = any(d[0] != "" for _it, d in foglie)
            # 1) prima le copie delle istanze accese (stile preso dai layer veri
            #    SENZA filtro, se no le copie nascerebbero invisibili)
            PN.filtro_comunale(dlg.project, False)
            GR.togli_vista(dlg.project)
            # tutto acceso e rete piena: i layer veri bastano, niente copie
            tutto_pieno = len(accese) == len(foglie) and sl.value() == 0
            stato["copie"] = bool(ist_accese) and not tutto_pieno
            if stato["copie"]:
                vis = _vuoto()
                dati = stato["dati"]
                for sez, nome in ist_accese:
                    d = dati.get(sez, {}).get(nome)
                    if d:
                        for k in vis:
                            vis[k] |= d[k]
                nome_v = "vista " + ist_accese[0][1] if len(ist_accese) == 1 \
                    else "vista %d istanze" % len(ist_accese)
                GR.mostra_fid(dlg.project, "Vista incrociata", vis, nome_v)
                for lid in GR.registro(dlg.project).get("_viste") or []:
                    c = dlg.project.mapLayer(lid)
                    if c is not None:
                        c.setOpacity(1.0)       # le istanze sempre piene, sopra
            # 2) la rete comunale è sempre quella dei layer VERI: accesa o spenta,
            #    filtrata in disegno (solo elementi senza istanza), trasparente
            #    quanto dice il cursore
            radice = dlg.project.layerTreeRoot()
            for _c, nome_l, _t in GR.LAYER:
                l_ = GR.layer_principale(dlg.project, nome_l)
                nodo = radice.findLayer(l_.id()) if l_ is not None else None
                if nodo is not None:
                    nodo.setItemVisibilityChecked(com_acceso)
                    if com_acceso:
                        nodo.setItemVisibilityCheckedParentRecursive(True)
            if com_acceso and ci_sono_istanze and not tutto_pieno:
                PN.filtro_comunale(dlg.project, True)
            _trasp(sl.value())
            dlg.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            from qgis.PyQt.QtWidgets import QMessageBox
            QMessageBox.warning(dlg, "Vista istanze", "Vista non applicata:\n%s" % e)
    def _solo(pred):
        albero.blockSignals(True)
        for it, d in _foglie():
            it.setCheckState(0, Qt.Checked if pred(d) else Qt.Unchecked)
        albero.blockSignals(False)
        applica()

    albero.itemChanged.connect(lambda *_a: applica())

    # l'occhio si clicca come la spunta (prima era solo un disegno)
    from qgis.PyQt.QtCore import QObject, QEvent

    class _Occhio(QObject):
        def eventFilter(self, ogg, ev):
            if ev.type() == QEvent.MouseButtonRelease and ev.button() == Qt.LeftButton:
                idx = albero.indexAt(ev.pos())
                it = albero.itemFromIndex(idx) if idx.isValid() else None
                if it is not None and idx.column() == 0 and \
                        it.data(0, Qt.CheckStateRole) is not None:
                    r = albero.visualRect(idx)
                    x = ev.pos().x() - r.left()
                    lato = albero.iconSize().width() if albero.iconSize().width() > 0 else 16
                    # [casella ~22 px][occhio]
                    if 20 <= x <= 22 + lato + 6:
                        it.setCheckState(0, Qt.Unchecked if it.checkState(0) != Qt.Unchecked
                                         else Qt.Checked)
                        return True
            return False
    albero._occhio = _Occhio(albero)
    albero.viewport().installEventFilter(albero._occhio)
    b_tutto.clicked.connect(lambda: _solo(lambda d: True))
    b_com.clicked.connect(lambda: _solo(lambda d: d[0] == ""))
    b_ist.clicked.connect(lambda: _solo(lambda d: d[0] != ""))
    b_agg.clicked.connect(aggiorna)

    def _dividi(*_a):
        from qgis.PyQt.QtWidgets import QMessageBox
        from . import ftth_pannello as PN
        spostati, fuori = PN.dividi_per_gruppi(dlg.project)
        QMessageBox.information(
            dlg, "Dividi per gruppi",
            "Nel gruppo «Comunale»: %s.\nIl gruppo «Altri enti» raccoglie le istanze agli altri "
            "enti.%s" % (", ".join(spostati) or "niente da spostare",
                         ("\nRestano fuori (cartografie comuni): %s." % ", ".join(fuori))
                         if fuori else ""))
    b_div.clicked.connect(_dividi)
    try:
        aggiorna()
        dlg.project.readProject.connect(lambda *_: aggiorna())
    except Exception:  # noqa: BLE001
        pass
    w._albero = albero          # per le prove
    w._aggiorna = aggiorna
    w._solo = _solo
    return w


def _riquadro_layer_enti(dlg):
    """Riquadro «Layer degli enti»: i gruppi «Comunale» e «Altri enti» del
    pannello Layer (strade, ferrovie, fasce, corsi d'acqua, vincoli, foto…)
    con l'occhio per accenderli/spegnerli e la trasparenza di ogni layer."""
    from qgis.core import QgsLayerTree
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import (QHBoxLayout, QLabel, QPushButton, QSlider, QTreeWidget,
                                     QTreeWidgetItem, QVBoxLayout, QWidget)
    try:
        from . import ftth_pannello as PN
    except ImportError:  # pragma: no cover
        import ftth_pannello as PN
    gb = dlg._gruppo("Layer degli enti: accendi, spegni, trasparenza", compresso=False)
    v = QVBoxLayout(gb)
    v.addWidget(dlg._desc(
        "I layer creati dal plugin, divisi come nel pannello Layer: «Comunale» e «Altri "
        "enti» (Strade, RFI, Acque, Soprintendenza, Parchi, Rilievo). Con la spunta li "
        "accendi o spegni, con il cursore scegli la trasparenza (0% = pieno)."))
    r = QHBoxLayout()
    b_agg = QPushButton("Aggiorna l'elenco")
    b_ord = QPushButton("Riordina il pannello Layer")
    b_ord.setToolTip("Sposta nei gruppi «Comunale» / «Altri enti» i gruppi e i layer del "
                     "plugin rimasti in cima al pannello.")
    r.addWidget(b_agg)
    r.addWidget(b_ord)
    r.addStretch()
    v.addLayout(r)
    albero = QTreeWidget()
    albero.setHeaderLabels(["Layer", "Trasparenza"])
    albero.setColumnWidth(0, 380)
    albero.setMinimumHeight(220)
    v.addWidget(albero)
    stato = {"occupato": False}

    def _cursore(lyr):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(2, 0, 2, 0)
        s = QSlider(Qt.Horizontal)
        s.setRange(0, 90)
        s.setValue(int(round((1.0 - lyr.opacity()) * 100)))
        lab = QLabel("%d%%" % s.value())
        lab.setMinimumWidth(34)

        def _cambia(val, l_=lyr, lb=lab):
            lb.setText("%d%%" % val)
            l_.setOpacity(1.0 - val / 100.0)
            l_.triggerRepaint()
        s.valueChanged.connect(_cambia)
        h.addWidget(s, 1)
        h.addWidget(lab)
        return w

    def _nodo(padre, n):
        nome = n.name()
        it = QTreeWidgetItem(padre, [nome])
        it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
        it.setCheckState(0, Qt.Checked if n.itemVisibilityChecked() else Qt.Unchecked)
        it.setData(0, Qt.UserRole, n)
        if QgsLayerTree.isGroup(n):
            for c in n.children():
                _nodo(it, c)
        elif n.layer() is not None:
            albero.setItemWidget(it, 1, _cursore(n.layer()))
        return it

    def aggiorna(*_a):
        stato["occupato"] = True
        albero.clear()
        radice = dlg.project.layerTreeRoot()
        trovati = False
        for nome in (PN.COMUNALE, PN.ALTRI):
            g = next((c for c in radice.children()
                      if QgsLayerTree.isGroup(c) and c.name() == nome), None)
            if g is not None:
                _nodo(albero, g)
                trovati = True
        if not trovati:
            QTreeWidgetItem(albero, ["Nessun layer del plugin nei gruppi «Comunale» / «Altri "
                                     "enti»: premi «Riordina il pannello Layer»."])
        albero.expandToDepth(1)
        stato["occupato"] = False

    def _spunta(it, col):
        if stato["occupato"] or col != 0:
            return
        n = it.data(0, Qt.UserRole)
        if n is None:
            return
        try:
            acceso = it.checkState(0) == Qt.Checked
            n.setItemVisibilityChecked(acceso)
            if acceso:
                n.setItemVisibilityCheckedParentRecursive(True)
            dlg.iface.mapCanvas().refresh()
        except Exception:  # noqa: BLE001
            pass

    def _riordina(*_a):
        PN.ordina_pannello(dlg.project)
        aggiorna()

    albero.itemChanged.connect(_spunta)
    b_agg.clicked.connect(aggiorna)
    b_ord.clicked.connect(_riordina)
    try:
        aggiorna()
        dlg.project.readProject.connect(lambda *_: aggiorna())
    except Exception:  # noqa: BLE001
        pass
    gb._aggiorna = aggiorna      # per le prove
    gb._albero = albero
    return gb
