# -*- coding: utf-8 -*-
"""
ftth_acque.py — Logica della scheda "Istanze Acque" (Consorzi di bonifica,
demanio idrico / Genio Civile, reticolo minore comunale).

Solo Python + shapely, senza QGIS: si prova con i test. L'interfaccia sta in
ftth_acque_ui.py. Le geometrie entrano ed escono in EPSG:4326.
(c) Beexact S.r.l.

Tre regimi da non confondere (vedi procedimenti.yaml):
- alveo demaniale -> concessione/nulla osta idraulico della Regione (Genio
  Civile), fascia di polizia idraulica 10 m (R.D. 523/1904 art. 96);
- canale di bonifica -> autorizzazione del Consorzio, fascia fissata dal suo
  regolamento (R.D. 368/1904; di solito 4-10 m);
- reticolo idrico minore -> in alcune regioni (es. Lombardia) e' del Comune.
La fascia paesaggistica di 150 m e' un'altra cosa (Soprintendenza).
"""
import math
import re
from dataclasses import dataclass, field
from typing import Optional

try:
    from . import ftth_rfi as rfi
except ImportError:  # test fuori da QGIS
    import ftth_rfi as rfi

# ---------------------------------------------------------------------------
# Costanti
# ---------------------------------------------------------------------------
CATEGORIE = {
    "demanio": "Demanio idrico (fiume/torrente)",
    "bonifica": "Canale di bonifica",
    "marittimo": "Demanio marittimo",
}
# chi riceve l'istanza
ENTI_TIPO = {
    "genio_civile": "Regione - Genio Civile (demanio idrico)",
    "consorzio": "Consorzio di bonifica",
    "comune": "Comune (reticolo idrico minore)",
    "demanio_marittimo": "Regione - Demanio marittimo",
    "altro": "Altro ente",
}
ENTE_PREDEFINITO = {"demanio": "genio_civile", "bonifica": "consorzio",
                    "marittimo": "demanio_marittimo"}
# marittimo: art. 55 Codice della Navigazione, 30 m dalla dividente demaniale
FASCIA_PREDEFINITA = {"demanio": 10.0, "bonifica": 10.0, "marittimo": 30.0}

# come si passa il corso d'acqua
TECNICHE_ATTR = {
    "nodig": "Perforazione no-dig sotto l'alveo",
    "tombino": "Nel corpo stradale sopra il tombino",
    "ponte": "Sul ponte (staffaggio o nel corpo del ponte)",
    "cielo_aperto": "Scavo a cielo aperto nell'alveo",
    "esistente": "Infrastruttura esistente",
    "?": "da decidere",
}
TIPI_INTERF = {"attraversamento": "Attraversamento", "parallelismo": "Parallelismo in fascia"}


def descr_tipo(tipo: str, categoria: str) -> str:
    """Il mare non si attraversa: per il demanio marittimo 'attraversamento'
    vuol dire che lo scavo passa la dividente ed entra nell'area demaniale."""
    if categoria == "marittimo":
        return {"attraversamento": "Dentro l'area demaniale",
                "parallelismo": "In fascia di competenza"}.get(tipo, tipo)
    return TIPI_INTERF.get(tipo, tipo)

# destinatari gia' usati nelle pratiche (dati istituzionali pubblici):
# si propongono in tabella, sempre modificabili
ENTI_NOTI = {
    "consorzio est ticino villoresi": {
        "nome": "Consorzio Est Ticino Villoresi",
        "indirizzo": "Via Ludovico Ariosto n. 30 - 20145 Milano (MI)",
        "pec": "info@etvilloresi.it"},
    "_marittimo_sicilia": {
        "nome": "Regione Siciliana - Demanio Marittimo",
        "indirizzo": "Via Ugo La Malfa, 169 - 90146 Palermo",
        "pec": "dipartimento.ambiente@certmail.regione.sicilia.it"},
}


def destinatario_noto(ente_tipo: str, ente_nome: str, regione: str = "") -> dict:
    """Destinatario gia' noto per l'ente, o {}."""
    k = (ente_nome or "").strip().lower()
    if k in ENTI_NOTI:
        return dict(ENTI_NOTI[k])
    if ente_tipo == "demanio_marittimo" and "sicil" in (regione or "").lower():
        return dict(ENTI_NOTI["_marittimo_sicilia"])
    return {}


TOLL_CLUSTER_M = 15.0     # pezzi piu' vicini = stessa interferenza
TOLL_TOMBINO_M = 4.0      # incrocio entro questa distanza da un tratto tunnel=culvert
TOLL_PONTE_M = 8.0        # incrocio entro questa distanza da una strada su ponte
RAGGIO_VIA_M = 40.0       # strada con nome piu' vicina per la colonna Via
TOCCA_M = 1.0             # due tratti senza nome "si toccano": stesso fosso

WATERWAY_OSM = ("river", "stream", "canal", "ditch", "drain")


# ---------------------------------------------------------------------------
# Classificazione dei corsi d'acqua
# ---------------------------------------------------------------------------
def categoria_osm(tags: dict) -> str:
    """'demanio' per fiumi e torrenti, 'bonifica' per canali, fossi e scoline.
    'canal' in OSM non dice chi lo gestisce: nella pratica sono quasi sempre
    canali consortili, quindi bonifica (si corregge in tabella)."""
    w = (tags or {}).get("waterway", "")
    if w in ("river", "stream"):
        return "demanio"
    return "bonifica"


def ente_da_testo(testo: str) -> Optional[str]:
    """Riconosce il tipo di ente da un attributo libero di un layer regionale
    (es. RIP / RIB / RIM in Lombardia, 'Consorzio ...', 'Genio Civile')."""
    t = (testo or "").strip().lower()
    if not t:
        return None
    if re.search(r"\brib\b|bonific|consorz", t):
        return "consorzio"
    if re.search(r"\brim\b|minore|comun", t):
        return "comune"
    if re.search(r"maritt|costa|dividente", t):
        return "demanio_marittimo"
    if re.search(r"\brip\b|principal|genio|region|demani|aipo|utr\b", t):
        return "genio_civile"
    return None


def nome_corso(tags: dict) -> str:
    nome = (tags.get("name") or "").strip()
    if nome:
        return nome
    w = tags.get("waterway", "")
    return {"river": "Fiume senza nome", "stream": "Torrente senza nome",
            "canal": "Canale senza nome", "ditch": "Fosso senza nome",
            "drain": "Scolina senza nome"}.get(w, "Corso d'acqua senza nome")


@dataclass
class CorsoAcqua:
    geom: object                      # shapely LineString (o Polygon per l'alveo)
    nome: str = ""
    waterway: str = ""
    categoria: str = "bonifica"       # demanio | bonifica
    tombino: bool = False             # tunnel=culvert: passa sotto la strada
    ente_tipo: str = ""               # da layer regionale, se c'e'
    ente_nome: str = ""
    osm_id: object = None
    con_nome: bool = True
    # da dove viene la linea: FONTE_OSM, FONTE_DISEGNO o il nome del layer
    # (per il demanio marittimo la legenda della PL dice se e' la dividente)
    fonte: str = ""


FONTE_OSM = "OpenStreetMap"
FONTE_DISEGNO = "disegnata a mano"


def legenda_marittimo(fonte: str) -> str:
    """Voce di legenda della linea da cui parte la fascia del demanio marittimo,
    senza fonti (scelta dell'utente): dividente se viene da un layer o da un
    disegno, linea di costa se c'e' solo quella di OSM."""
    if not fonte or fonte == FONTE_OSM:
        return "LINEA DI COSTA"
    return "DIVIDENTE DEMANIALE"


def da_osm(elements: list) -> dict:
    """Dai risultati Overpass: {'corsi': [CorsoAcqua], 'alvei': [Polygon],
    'ponti': [LineString], 'strade': [(LineString, nome)]}."""
    from shapely.geometry import LineString, Polygon
    from shapely.ops import polygonize, unary_union
    corsi, alvei, ponti, strade = [], [], [], []
    for e in elements or []:
        tags = e.get("tags") or {}
        if e.get("type") == "way" and e.get("geometry"):
            pts = [(p["lon"], p["lat"]) for p in e["geometry"]]
            if len(pts) < 2:
                continue
            ww = tags.get("waterway", "")
            if ww in WATERWAY_OSM:
                corsi.append(CorsoAcqua(
                    geom=LineString(pts), nome=nome_corso(tags), waterway=ww,
                    categoria=categoria_osm(tags),
                    tombino=tags.get("tunnel") in ("culvert", "yes") or tags.get("culvert") == "yes",
                    osm_id=e.get("id"), con_nome=bool((tags.get("name") or "").strip()),
                    fonte=FONTE_OSM))
            elif tags.get("natural") == "coastline":
                # linea di costa OSM: solo un'approssimazione della dividente
                # demaniale (che sta a monte della spiaggia)
                corsi.append(CorsoAcqua(geom=LineString(pts), nome="Demanio marittimo",
                                        waterway="coastline", categoria="marittimo",
                                        osm_id=e.get("id"), con_nome=True, fonte=FONTE_OSM))
            elif ww == "riverbank" or tags.get("natural") == "water":
                if len(pts) >= 4 and pts[0] == pts[-1]:
                    try:
                        pg = Polygon(pts)
                        if pg.is_valid and pg.area > 0:
                            alvei.append(pg)
                    except Exception:  # noqa: BLE001
                        pass
            elif tags.get("highway"):
                ls = LineString(pts)
                if tags.get("bridge") and tags.get("bridge") != "no":
                    ponti.append(ls)
                if (tags.get("name") or "").strip():
                    strade.append((ls, tags["name"].strip()))
        elif e.get("type") == "relation" and (tags.get("natural") == "water"
                                             or tags.get("waterway") == "riverbank"):
            linee = []
            for m in e.get("members") or []:
                if m.get("role") == "outer" and m.get("geometry"):
                    pts = [(p["lon"], p["lat"]) for p in m["geometry"]]
                    if len(pts) >= 2:
                        linee.append(LineString(pts))
            try:
                for pg in polygonize(unary_union(linee)):
                    if pg.area > 0:
                        alvei.append(pg)
            except Exception:  # noqa: BLE001
                pass
    return {"corsi": corsi, "alvei": alvei, "ponti": ponti, "strade": strade}


# ---------------------------------------------------------------------------
# Interferenze
# ---------------------------------------------------------------------------
@dataclass
class InterferenzaAcqua:
    id: int
    tipo: str                          # attraversamento | parallelismo
    corso: str                         # nome del corso d'acqua nei documenti
    categoria: str                     # demanio | bonifica
    ente_tipo: str                     # chiave di ENTI_TIPO
    ente_nome: str = ""                # es. "Consorzio Est Ticino Villoresi"
    tecnica_attr: str = ""             # chiave di TECNICHE_ATTR (attraversamenti)
    via: str = ""
    metri: dict = field(default_factory=dict)      # {tecnica scavo: metri}
    pozzetti: dict = field(default_factory=dict)   # {dimensione: n}
    lon: float = 0.0
    lat: float = 0.0
    dist_min_m: Optional[float] = None
    note: list = field(default_factory=list)
    includi: bool = True
    foto: str = ""
    bbox: tuple = ()
    elementi: list = field(default_factory=list)   # come in ftth_rfi (etichette tavola)
    tratte_fid: list = field(default_factory=list)
    coord_da: str = ""                 # "45.68880154,8.77084837" (tabella scavi RT)
    coord_a: str = ""
    attraversa: bool = False
    tavola: int = 0                    # numero della tavola della PL (per zona)
    etichetta: str = ""                # testo in tavola corretto a mano (righe con \n)

    def totale_metri(self) -> float:
        return sum(self.metri.values())


TECNICA_ETICHETTA = {"trincea": "SCAVO TRADIZIONALE", "minitrincea": "SCAVO MINITRINCEA",
                     "microtrincea": "SCAVO MICROTRINCEA", "nodig": "PERFORAZIONE NO DIG",
                     "canaletta": "POSA CANALETTA VTR"}


def etichetta_automatica(i) -> str:
    """Testo proposto per l'etichetta in tavola (senza il numero, che mette la
    PL): le lavorazioni e basta, 'SCAVO TRADIZIONALE Mt 13\\nPOSA 1 POZZETTO
    76X40'. Per l'acqua non si distingue fra attraversamento e parallelismo:
    conta cio' che cade vicino al corso d'acqua. Si corregge nella scheda."""
    righe = []
    for t, m in i.metri.items():
        if m:
            righe.append("%s Mt %s" % (TECNICA_ETICHETTA.get(t, t.upper()), int(float(m) + 0.5)))
    for d, k in i.pozzetti.items():
        righe.append("POSA %d POZZETT%s %s" % (k, "O" if k == 1 else "I", str(d).upper()))
    for e in i.elementi:
        if e.get("tipo") in ("armadio", "colonnina"):
            righe.append(testo_elemento_auto(e))
    if not righe:
        righe.append("POSA SENZA SCAVO")
    return "\n".join(righe)


def testo_elemento_auto(e: dict) -> str:
    """Testo proposto per l'etichetta di un elemento in tavola."""
    t = e.get("tipo")
    if t == "scavo":
        return "%s Mt %s" % (TECNICA_ETICHETTA.get(e.get("tecnica"),
                                                    str(e.get("tecnica")).upper()), e.get("metri"))
    if t == "pozzetto":
        return "POSA POZZETTO %s" % str(e.get("dim_testo") or e.get("dim") or "").upper()
    if t == "armadio":
        n = numero_armadio(e.get("id"))
        return "POSA ARMADIO ARLO %s" % n if n else "POSA ARMADIO"
    if t == "colonnina":
        return "POSA COLONNINA PTE"
    return ""


def numero_armadio(v) -> str:
    """Numero ARLO dell'armadio (campo AREA_AO): «201.0» -> «201»."""
    s = str(v or "").strip()
    if s.upper() == "NULL":
        return ""
    if re.fullmatch(r"\d+\.0+", s):
        s = s.split(".")[0]
    return s


def elementi_etichettabili(i) -> list:
    """Elementi dell'interferenza che hanno un'etichetta in tavola (scavi
    continui, pozzetti e armadi in fascia), nell'ordine della scheda."""
    return [e for e in i.elementi if e.get("chiave_el") and e.get("tipo") in
            ("scavo", "pozzetto", "armadio", "colonnina") and
            (e.get("tipo") != "scavo" or e.get("metri"))]


def testi_modificati(interferenze: list) -> tuple:
    """({chiave elemento: testo}, {chiave interferenza: testo unico}) dei testi
    corretti a mano, da riapplicare dopo una nuova ricerca."""
    el, unici = {}, {}
    for i in interferenze or []:
        for e in i.elementi:
            if e.get("testo") and e.get("chiave_el"):
                el[e["chiave_el"]] = e["testo"]
        if i.etichetta:
            unici[chiave_interferenza(i)] = i.etichetta
    return el, unici


def chiave_interferenza(i) -> str:
    return "%s|%s" % (i.corso, ",".join(str(f) for f in sorted(i.tratte_fid, key=str)))


def riapplica_testi(interferenze: list, el: dict, unici: dict) -> int:
    """Rimette i testi corretti a mano sugli elementi con la stessa chiave.
    Ritorna quanti testi non hanno ritrovato il loro elemento (il progetto e'
    cambiato: lo scavo si e' allungato o diviso)."""
    usati = set()
    for i in interferenze:
        for e in i.elementi:
            k = e.get("chiave_el")
            if k in el:
                e["testo"] = el[k]
                usati.add(k)
        ki = chiave_interferenza(i)
        if ki in unici:
            i.etichetta = unici[ki]
            usati.add(ki)
    return len((set(el) | set(unici)) - usati)


def testo_etichetta(n: int, i) -> str:
    """Etichetta in tavola: numero + testo corretto a mano o quello proposto."""
    righe = [r for r in (i.etichetta or etichetta_automatica(i)).split("\n") if r.strip()]
    if not righe:
        righe = [descr_tipo(i.tipo, i.categoria).upper()]
    righe[0] = "%d - %s" % (n, righe[0].strip())
    return "\n".join(r.strip() for r in righe)


# ---------------------------------------------------------------------------
# Disposizione delle etichette in tavola (in mm sulla carta)
# ---------------------------------------------------------------------------
def _seg_incrocia(p1, p2, q1, q2) -> bool:
    """True se i segmenti p1-p2 e q1-q2 si incrociano (estremi esclusi)."""
    def orient(a, b, c):
        v = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
        return 0 if abs(v) < 1e-9 else (1 if v > 0 else -1)
    o1, o2 = orient(p1, p2, q1), orient(p1, p2, q2)
    o3, o4 = orient(q1, q2, p1), orient(q1, q2, p2)
    return o1 * o2 < 0 and o3 * o4 < 0


def _seg_box(p1, p2, box) -> bool:
    """True se il segmento attraversa il rettangolo (x0, y0, x1, y1)."""
    x0, y0, x1, y1 = box
    for q1, q2 in (((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)),
                   ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))):
        if _seg_incrocia(p1, p2, q1, q2):
            return True
    return False


def _attacco(ancora, box):
    """Punto del bordo del riquadro piu' vicino all'ancora (dove parte la
    linea di richiamo)."""
    x0, y0, x1, y1 = box
    return (min(max(ancora[0], x0), x1), min(max(ancora[1], y0), y1))


def _seg_tocca_box(p1, p2, box) -> bool:
    """True se il segmento entra nel rettangolo (anche solo un estremo dentro)."""
    x0, y0, x1, y1 = box
    for p in (p1, p2):
        if x0 <= p[0] <= x1 and y0 <= p[1] <= y1:
            return True
    return _seg_box(p1, p2, box)


def disponi_etichette(ancore: list, dimensioni: list, w: float, h: float,
                      ostacoli: list = None, margine: float = 2.0,
                      linee: list = None) -> list:
    """Posizioni (centri, mm) delle etichette di una tavola: mai sovrapposte fra
    loro ne' ai punti, linee di richiamo che non si incrociano e non tagliano
    altre etichette, dentro il riquadro. ancore = [(x, y)] mm dall'angolo in
    alto a sinistra; dimensioni = [(larghezza, altezza)] mm.
    Si piazzano prima le etichette piu' 'difficili' (quelle con piu' vicini);
    per ognuna si provano 16 direzioni a distanze crescenti e si sceglie la
    posizione col costo minore (sovrapposizioni e incroci pesano molto piu'
    della distanza).
    linee = [((x1, y1), (x2, y2), peso)]: segmenti che le etichette non devono
    coprire (scavi, corso d'acqua); ostacoli = [(x0, y0, x1, y1)] da non
    coprire (pozzetti)."""
    import math as _m
    ostacoli = list(ostacoli or [])
    linee = list(linee or [])
    n = len(ancore)
    pos = [None] * n
    box_fatti, linee_fatte = [], []
    punti = [(x - 1.8, y - 1.8, x + 1.8, y + 1.8) for x, y in ancore] + ostacoli

    def sovr(a, b, gap=1.2):
        return max(0.0, min(a[2], b[2]) + gap - max(a[0], b[0])) * \
            max(0.0, min(a[3], b[3]) + gap - max(a[1], b[1]))

    vicini = [sum(1 for j in range(n) if j != i and _m.hypot(
        ancore[i][0] - ancore[j][0], ancore[i][1] - ancore[j][1]) < 40) for i in range(n)]
    ordine = sorted(range(n), key=lambda i: (-vicini[i], ancore[i][1]))
    direzioni = [(_m.cos(_m.radians(a)), -_m.sin(_m.radians(a))) for a in range(0, 360, 15)]
    box_di = {}            # indice -> riquadro piazzato
    linea_di = {}          # indice -> linea di richiamo

    def valuta(i, box, att):
        ax, ay = ancore[i]
        costo = 0.0
        if box[0] < margine or box[1] < margine or box[2] > w - margine or \
                box[3] > h - margine:
            costo += 1e6
        for j, b in box_di.items():
            if j == i:
                continue
            costo += sovr(box, b) * 1000
            if _seg_box((ax, ay), att, b):
                costo += 5000
        for j, (l1, l2) in linea_di.items():
            if j == i:
                continue
            if _seg_incrocia((ax, ay), att, l1, l2):
                costo += 5000
            if _seg_box(l1, l2, box):
                costo += 5000
        costo += sum(sovr(box, p, 0.5) for k, p in enumerate(punti) if k != i) * 300
        # l'etichetta non copre scavi, pozzetti, corso d'acqua; e la sua linea
        # di richiamo non li taglia (prima il richiamo attraversava canale,
        # fascia e scavi per arrivare a un'etichetta lontana)
        gonfio = (box[0] - 0.8, box[1] - 0.8, box[2] + 0.8, box[3] + 0.8)
        for q1, q2, peso in linee:
            if _seg_tocca_box(q1, q2, gonfio):
                costo += peso
            if _seg_incrocia((ax, ay), att, q1, q2):
                costo += peso * 0.8
        return costo

    def forma_richiamo(i, att):
        """Richiami corti e il piu' possibile orizzontali."""
        ax, ay = ancore[i]
        lun = _m.hypot(att[0] - ax, att[1] - ay)
        costo = lun * 2.5 + abs(att[1] - ay) * 1.5
        if lun > 28:
            costo += (lun - 28) * 40
        return costo

    def piazza(i):
        ax, ay = ancore[i]
        bw, bh = dimensioni[i]
        migliore = None
        candidati = []
        for dist in (4.0, 7.0, 11.0, 16.0, 22.0, 30.0, 40.0, 52.0):
            for dx, dy in direzioni:
                candidati.append((ax + dx * (dist + bw / 2.0), ay + dy * (dist + bh / 2.0)))
            # di lato, alla stessa altezza o appena sopra/sotto: richiamo orizzontale
            for lato in (1, -1):
                for sv in (0.0, -bh * 0.6, bh * 0.6):
                    candidati.append((ax + lato * (dist + bw / 2.0), ay + sv))
        for cx, cy in candidati:
            box = (cx - bw / 2.0, cy - bh / 2.0, cx + bw / 2.0, cy + bh / 2.0)
            att = _attacco((ax, ay), box)
            costo = valuta(i, box, att) + forma_richiamo(i, att)
            if migliore is None or costo < migliore[0]:
                migliore = (costo, (cx, cy), box, att)
        costo, centro, box, att = migliore
        pos[i] = centro
        box_di[i] = box
        linea_di[i] = ((ax, ay), att)
        return costo

    for i in ordine:
        piazza(i)
    # secondo passaggio: chi e' rimasto in conflitto si riposiziona con tutte
    # le altre al loro posto (qualche giro, finche' migliora)
    for _giro in range(6):
        in_conflitto = [i for i in ordine if valuta(i, box_di[i], linea_di[i][1]) >= 250]
        if not in_conflitto:
            break
        for i in in_conflitto:
            del box_di[i], linea_di[i]
            piazza(i)
    return pos


def conflitti_etichette(ancore, dimensioni, pos, w, h, linee=None) -> int:
    """Quanti problemi ha una disposizione: etichette sovrapposte o fuori
    riquadro, richiami incrociati o che passano su un'altra etichetta,
    etichette sopra scavi/corso d'acqua."""
    box = [(cx - bw / 2.0, cy - bh / 2.0, cx + bw / 2.0, cy + bh / 2.0)
           for (cx, cy), (bw, bh) in zip(pos, dimensioni)]
    ric = [(a, _attacco(a, b)) for a, b in zip(ancore, box)]
    n = 0
    for i, b in enumerate(box):
        if b[0] < 0 or b[1] < 0 or b[2] > w or b[3] > h:
            n += 1
        for q1, q2, _p in (linee or []):
            if _seg_tocca_box(q1, q2, b):
                n += 1
            if _seg_incrocia(ric[i][0], ric[i][1], q1, q2):
                n += 1
        for j in range(i + 1, len(box)):
            c = box[j]
            if min(b[2], c[2]) > max(b[0], c[0]) and min(b[3], c[3]) > max(b[1], c[1]):
                n += 1
            if _seg_incrocia(ric[i][0], ric[i][1], ric[j][0], ric[j][1]):
                n += 1
            if _seg_box(ric[i][0], ric[i][1], c) or _seg_box(ric[j][0], ric[j][1], b):
                n += 1
    return n


def accorpa_etichette(voci: list, unisci: bool) -> list:
    """Etichette della tavola. voci = [(x, y, testo, tipo, chiave, gruppo)]
    con tipo scavo / pozzetto / armadio / libera e gruppo = la tratta di
    scavo (lo scavo e i pozzetti che stanno su quella tratta hanno lo stesso
    gruppo). unisci=False: un'etichetta per voce. unisci=True: lo scavo e i
    SUOI pozzetti in un'etichetta sola ('SCAVO TRADIZIONALE Mt 13 / POSA
    POZZETTO 40X76'); scavi diversi non si uniscono mai (prima l'accorpamento
    per vicinanza mescolava pezzi sparsi e non si capiva quale fosse quale).
    L'etichetta unita si aggancia allo scavo. Ritorna [(x, y, testo)]."""
    gruppi, per_gruppo = [], {}
    for v in voci:
        g = v[5] if len(v) > 5 else ""
        if unisci and g:
            if g not in per_gruppo:
                per_gruppo[g] = []
                gruppi.append(per_gruppo[g])
            per_gruppo[g].append(v)
        else:
            gruppi.append([v])
    out = []
    for g in gruppi:
        # testi corretti a mano (tipo *_mod): riportati cosi' come sono
        mod = [u for u in g if str(u[3]).endswith("_mod")]
        g_auto = [u for u in g if u not in mod]
        ancora_mod = next((u for u in g if u[3] in ("scavo", "scavo_mod")), None)
        scavi = [u for u in g_auto if u[3] == "scavo"]
        pozz = {}
        for u in g:
            if u[3] == "pozzetto":
                pozz[u[4]] = pozz.get(u[4], 0) + 1
        # scavi della stessa tecnica sommati: 'SCAVO MINITRINCEA Mt 26' invece
        # di una riga per ogni pezzo di tratta
        metri, ordine = {}, []
        for u in scavi:
            m = re.search(r"Mt\s+(\d+)", u[2])
            tec = u[4] or re.sub(r"\s*Mt\s+\d+.*$", "", u[2])
            if tec not in metri:
                ordine.append(tec)
                metri[tec] = 0
            metri[tec] += int(m.group(1)) if m else 0
        righe = ["%s Mt %d" % (tec, metri[tec]) if metri[tec] else tec for tec in ordine]
        # prima gli scavi corretti a mano, poi i pozzetti
        for u in mod:
            if u[3] == "scavo_mod":
                righe += [r for r in u[2].split("\n") if r.strip()]
        for dim, k in pozz.items():
            righe.append("POSA POZZETTO %s" % dim if k == 1 else "POSA %d POZZETTI %s" % (k, dim))
        for u in g:
            if u[3] not in ("scavo", "pozzetto", "scavo_mod"):
                for r in u[2].split("\n"):
                    if r.strip() and r not in righe:
                        righe.append(r)
        ancora = ancora_mod or g[0]
        out.append((ancora[0], ancora[1], "\n".join(righe)))
    return out


def fmt_coord(lat: float, lon: float) -> str:
    return "%.8f,%.8f" % (lat, lon)


def _gruppi_corsi(corsi, pr):
    """Corsi d'acqua raggruppati: stesso nome + categoria + ente = un corso;
    i tratti senza nome si uniscono solo se si toccano (stesso fosso)."""
    gruppi = {}
    anonimi = []
    for c in corsi:
        gm = pr.avanti(c.geom)
        if c.con_nome:
            k = (c.nome.lower(), c.categoria, c.ente_tipo, c.ente_nome.lower())
            g = gruppi.setdefault(k, {"nome": c.nome, "categoria": c.categoria,
                                      "ente_tipo": c.ente_tipo, "ente_nome": c.ente_nome,
                                      "geoms": [], "tombini": [], "osm": []})
            g["geoms"].append(gm)
            g["osm"].append(c.fonte == FONTE_OSM)
            if c.tombino:
                g["tombini"].append(gm)
        else:
            anonimi.append((c, gm))
    # tratti anonimi: componenti connesse
    visti = [False] * len(anonimi)
    n = 0
    for i, (c, gm) in enumerate(anonimi):
        if visti[i]:
            continue
        visti[i] = True
        comp = [(c, gm)]
        coda = [gm]
        while coda:
            g0 = coda.pop()
            for j, (c2, gm2) in enumerate(anonimi):
                if not visti[j] and c2.categoria == c.categoria and g0.distance(gm2) <= TOCCA_M:
                    visti[j] = True
                    comp.append((c2, gm2))
                    coda.append(gm2)
        n += 1
        gruppi[("_anonimo", n)] = {
            "nome": c.nome, "categoria": c.categoria, "ente_tipo": c.ente_tipo,
            "ente_nome": c.ente_nome, "geoms": [g for _, g in comp],
            "tombini": [g for cc, g in comp if cc.tombino],
            "osm": [cc.fonte == FONTE_OSM for cc, _ in comp]}
    return list(gruppi.values())


def _lato(g, d, segno):
    """Buffer di `d` metri da UN lato della linea: segno +1 = sinistra (per la
    linea di costa OSM e' la terra), -1 = destra."""
    from shapely.ops import unary_union
    parti = [p for p in getattr(g, "geoms", [g])
             if p.geom_type == "LineString" and p.length > 0]
    return unary_union([p.buffer(segno * d, single_sided=True) for p in parti])


def zona_marittima_m(linee, metri, costa=None, largo=400.0):
    """Zona di competenza del demanio marittimo in metri (art. 55 Cod. Nav.),
    SOLO verso terra: i 30 m disegnati sul mare non hanno senso.
      linee: [(geom_m, da_osm)]: linea di costa OSM (terra a sinistra, per
             convenzione OSM) o dividente demaniale (verso sconosciuto);
      costa: [geom_m] linee di costa OSM per capire da che parte e' il mare
             rispetto alla dividente.
    Per la dividente la zona e' la striscia di demanio fra dividente e mare
    (spiaggia) + i `metri` verso terra. Ritorna (zona, orientata): orientata
    False = dividente senza costa per orientarla, fascia sui due lati."""
    from shapely.ops import unary_union
    costa_u = unary_union([c for c in (costa or []) if c is not None and not c.is_empty]) \
        if costa else None
    if costa_u is not None and costa_u.is_empty:
        costa_u = None
    pezzi, orientata = [], True
    for g, da_osm in linee:
        for p in [q for q in getattr(g, "geoms", [g]) if q.geom_type == "LineString"]:
            if da_osm:
                pezzi.append(_lato(p, metri, +1))
                continue
            if costa_u is None:
                pezzi.append(p.buffer(metri))
                orientata = False
                continue
            sx, dx = _lato(p, largo, +1), _lato(p, largo, -1)
            lsx, ldx = sx.intersection(costa_u).length, dx.intersection(costa_u).length
            if lsx == ldx:      # costa oltre `largo`: decide la distanza
                mare_sx = sx.centroid.distance(costa_u) < dx.centroid.distance(costa_u)
            else:
                mare_sx = lsx > ldx
            mare, segno_terra = (sx, -1) if mare_sx else (dx, +1)
            pezzi.append(_lato(p, metri, segno_terra))
            # demanio fra dividente e mare: lato mare della dividente e lato
            # terra della costa
            pezzi.append(mare.intersection(_lato(costa_u, largo, +1)))
    return unary_union([z for z in pezzi if not z.is_empty]), orientata


def _fattore_lunghezza(t) -> float:
    """Correzione dei metri disegnati con il campo LUNGHEZZA della tratta, solo
    se il campo e' coerente col disegno (entro il 10%). Un campo molto diverso
    (es. la lunghezza dell'intero scavo copiata su uno spezzone) gonfiava i
    metri in fascia: 11 m in fascia diventavano 60."""
    try:
        lung, geo = float(t.get("lunghezza") or 0), float(t["gm"].length)
    except (TypeError, ValueError, KeyError):
        return 1.0
    if lung <= 0 or geo <= 0:
        return 1.0
    f = lung / geo
    return f if 0.9 <= f <= 1.1 else 1.0


def _via_vicina(punto_m, strade_m) -> str:
    best, dbest = "", RAGGIO_VIA_M
    for g, nome in strade_m:
        d = punto_m.distance(g)
        if d <= dbest:
            best, dbest = nome, d
    return best


def _consorzio_in(punto_wgs, comprensori) -> str:
    for c in comprensori or []:
        try:
            if c["geom"].contains(punto_wgs):
                return c.get("nome") or ""
        except Exception:  # noqa: BLE001
            continue
    return ""


def trova_interferenze_acque(corsi: list, tratte: list, pozzetti: list = None,
                             armadi: list = None, alvei: list = None, ponti: list = None,
                             strade: list = None, comprensori: list = None,
                             fasce: dict = None, costa: list = None, zone: list = None,
                             colonnine: list = None) -> list:
    """Interferenze fra la rete di progetto e i corsi d'acqua.

    corsi:   [CorsoAcqua]
    tratte:  [{'geom', 'stato', 'tecnica', 'fid', 'lunghezza'}] come in ftth_rfi
    pozzetti/armadi: [{'geom': Point, 'stato', 'dim', 'fid'}]
    alvei:   [Polygon] sponde dei fiumi larghi (la fascia parte dalla sponda)
    ponti:   [LineString] strade su ponte; strade: [(LineString, nome)]
    comprensori: [{'geom': Polygon, 'nome'}] per il nome del Consorzio
    fasce:   {'demanio': m, 'bonifica': m}
    zone:    al posto dei corsi d'acqua, aree vincolate (schede Soprintendenza
             e Parchi / Natura 2000): [{'nome', 'categoria', 'ente_tipo',
             'ente_nome', 'geom': Polygon WGS84, 'distanza': m}]. La "fascia"
             e' il poligono (allargato di `distanza`); non ci sono
             attraversamenti, e pozzetti/armadi dentro l'area sono
             interferenze anche senza scavo.
    colonnine: colonnine PTE nuove (fuori terra, come gli armadi), stesso
             formato di armadi; elemento di tipo 'colonnina' (Soprintendenza).
    Ritorna una lista di InterferenzaAcqua, numerate da 1."""
    from shapely.geometry import Point
    from shapely.ops import unary_union

    pozzetti = pozzetti or []
    armadi = armadi or []
    colonnine = colonnine or []
    fasce = dict(FASCIA_PREDEFINITA, **(fasce or {}))
    corsi = corsi or []
    if not (corsi or zone) or not tratte:
        return []
    if zone and not corsi:
        # aree vincolate / strade: media dei centroidi (l'unione di poligoni
        # appena riproiettati puo' fallire per geometrie non valide)
        _cc = [z["geom"].centroid for z in zone]
        c0 = Point(sum(p.x for p in _cc) / len(_cc), sum(p.y for p in _cc) / len(_cc))
    else:
        c0 = unary_union([c.geom for c in corsi] + [z["geom"] for z in (zone or [])]).centroid
    pr = rfi._Proiezione(c0.x, c0.y)
    alvei_m = [pr.avanti(a) for a in (alvei or [])]
    # linee di costa OSM (anche quelle non usate come corso d'acqua): servono a
    # capire da che parte e' il mare rispetto alla dividente
    costa_m = [pr.avanti(c.geom) for c in list(corsi) + list(costa or [])
               if c.categoria == "marittimo" and c.fonte == FONTE_OSM]
    ponti_m = [pr.avanti(p) for p in (ponti or [])]
    strade_m = [(pr.avanti(g), n) for g, n in (strade or [])]

    tr_m = []
    for k, t in enumerate(tratte):
        g = t.get("geom")
        if g is None or g.is_empty:
            continue
        tr_m.append(dict(t, gm=pr.avanti(g), _k=k))

    # pozzetti (nuovi ed esistenti): spezzano lo scavo continuo in etichette
    pozz_m = [pr.avanti(pz["geom"]) for pz in pozzetti if pz.get("geom") is not None]

    risultati = []
    contate = set()
    geom_interf = {}
    nid = 1

    def _esistente(t):
        return (t.get("stato") or "").strip().lower() == "esistente"

    if zone:
        gruppi = []
        for z in zone:
            gz = pr.avanti(z["geom"])
            if not gz.is_valid:
                gz = gz.buffer(0)
            d = float(z.get("distanza") or 0)
            gruppi.append({"nome": z.get("nome") or "", "categoria": z.get("categoria") or "",
                           "ente_tipo": z.get("ente_tipo") or "",
                           "ente_nome": z.get("ente_nome") or "", "geoms": [],
                           "tombini": [], "_zona": gz.buffer(d) if d > 0 else gz})
    else:
        gruppi = _gruppi_corsi(corsi, pr)
    for gr in gruppi:
        zona = "_zona" in gr
        if zona:
            # area vincolata: dentro il poligono e' tutto "in fascia", non ci
            # sono alveo, tombini ne' attraversamenti
            fascia, alveo, tombini = gr["_zona"], None, None
        else:
            linea = unary_union(gr["geoms"])
            # i fiumi larghi hanno anche l'alveo disegnato: la fascia parte dalla sponda
            miei_alvei = [a for a in alvei_m if a.intersects(linea)]
            alveo = unary_union([linea] + miei_alvei) if miei_alvei else linea
            fascia_m = fasce.get(gr["categoria"], 10.0)
            if gr["categoria"] == "marittimo":
                # solo verso terra (con la dividente: spiaggia demaniale + 30 m)
                fascia, _ori = zona_marittima_m(
                    list(zip(gr["geoms"], gr.get("osm") or [False] * len(gr["geoms"]))),
                    fascia_m, costa_m)
            else:
                fascia = alveo.buffer(fascia_m)
            tombini = unary_union(gr["tombini"]) if gr["tombini"] else None

        attraversamenti, paralleli = [], []
        for t in tr_m:
            gm = t["gm"]
            if not gm.intersects(fascia):
                continue
            pezzo = rfi._solo_linee(gm.intersection(fascia))
            if pezzo is None or pezzo.length < 0.5:
                continue
            if alveo is not None and gm.intersects(alveo):
                punto = gm.intersection(alveo).centroid
                for a in attraversamenti:
                    if a["punto"].distance(punto) <= TOLL_CLUSTER_M:
                        a["pezzi"].append((t, pezzo))
                        break
                else:
                    attraversamenti.append({"punto": punto, "pezzi": [(t, pezzo)]})
            else:
                paralleli.append((t, pezzo))

        def _metri(pezzi):
            m = {}
            for t, p in pezzi:
                chiave = (t["_k"], round(p.length, 2))
                if chiave in contate or _esistente(t):
                    continue
                contate.add(chiave)
                tec = t.get("tecnica")
                if tec:
                    m[tec] = m.get(tec, 0.0) + p.length * _fattore_lunghezza(t)
            return {k: max(1, int(v + 0.5)) for k, v in m.items() if v > 0}

        def _elementi(pezzi):
            """Etichette della tavola: uno SCAVO CONTINUO per tecnica (le tratte
            attaccate della stessa tecnica sommate, etichetta a meta' percorso)
            invece di una per ogni spezzone di tratta: nel progetto molte
            tratte sono pezzi di 1-5 m e la tavola si riempiva di 'Mt 2',
            'Mt 3'..."""
            from shapely.ops import linemerge
            out, visti = [], set()
            per_tec = {}
            for t, p in pezzi:
                if _esistente(t) or not t.get("tecnica"):
                    continue
                fatt = _fattore_lunghezza(t)
                for q in getattr(p, "geoms", [p]):
                    per_tec.setdefault(t["tecnica"], []).append((q, fatt, t.get("fid")))
            from shapely.ops import nearest_points

            def _attaccati(q, r):
                """Si toccano (entro mezzo metro) e nel punto di contatto NON
                c'e' un pozzetto: dove c'e' il pozzetto lo scavo si interrompe e
                ogni tratto ha la sua etichetta."""
                if q.distance(r) > 0.5:
                    return False
                if not pozz_m:
                    return True
                contatto = nearest_points(q, r)[0]
                return not any(contatto.distance(pz) <= 1.5 for pz in pozz_m)
            for tec, lst in per_tec.items():
                # componenti connesse (pezzi attaccati, spezzati ai pozzetti)
                comp = []
                for q, fatt, fid in lst:
                    dove = [c for c in comp if any(_attaccati(q, r[0]) for r in c)]
                    if not dove:
                        comp.append([(q, fatt, fid)])
                    else:
                        base = dove[0]
                        base.append((q, fatt, fid))
                        for altro in dove[1:]:
                            base.extend(altro)
                            comp.remove(altro)
                for c in comp:
                    L = sum(q.length * fatt for q, fatt, _fid in c)
                    u = unary_union([q for q, _f, _fid in c])
                    unito = u if u.geom_type == "LineString" else linemerge(u)
                    parti = list(getattr(unito, "geoms", [unito]))
                    lungo = max(parti, key=lambda q: q.length)
                    w = pr.indietro(lungo.interpolate(0.5, normalized=True))
                    # chiave stabile fra una ricerca e l'altra: tecnica + tratte
                    # del progetto che formano lo scavo (serve a ritrovare il
                    # testo corretto a mano)
                    fids = sorted({str(fid) for _q, _f, fid in c if fid is not None})
                    chiave = "S|%s|%s" % (tec, ",".join(fids))
                    out.append({"tipo": "scavo", "tecnica": tec,
                                "metri": max(1, int(L + 0.5)), "lon": w.x, "lat": w.y,
                                "km": "", "gruppo": chiave, "chiave_el": chiave,
                                "_gm": u, "_wkt": pr.indietro(u).wkt})
            for t, _p in pezzi:
                if t["_k"] in visti or _esistente(t):
                    continue
                visti.add(t["_k"])
                # "non di competenza" solo sugli scavi: una tratta senza scavo
                # (aerea, sul ponte) non ha nulla da computare
                fuori = rfi._solo_linee(t["gm"].difference(fascia)) if t.get("tecnica") else None
                for parte in getattr(fuori, "geoms", [fuori]) if fuori is not None else []:
                    if parte.length >= 3:
                        w = pr.indietro(parte.interpolate(0.5, normalized=True))
                        out.append({"tipo": "fuori", "lon": w.x, "lat": w.y, "km": ""})
            return out

        def _nuova(tipo, pezzi, rif_m, dist=None):
            nonlocal nid
            if tipo == "attraversamento":
                cen = pr.indietro(rif_m.centroid)
            else:
                lungo = max((p for _, p in pezzi), key=lambda p: p.length)
                parti = list(getattr(lungo, "geoms", [lungo]))
                lungo = max(parti, key=lambda p: p.length)
                cen = pr.indietro(lungo.interpolate(0.5, normalized=True))
            in_fascia = unary_union([p for _, p in pezzi])
            estremi = rfi._estremi(pr.indietro(in_fascia))
            if estremi:
                (x1, y1), (x2, y2) = estremi[0], estremi[-1]
                if len(estremi) > 2:
                    # i due estremi piu' lontani fra loro
                    coppie = [(a, b) for a in estremi for b in estremi]
                    (x1, y1), (x2, y2) = max(coppie, key=lambda ab: (ab[0][0] - ab[1][0]) ** 2
                                             + (ab[0][1] - ab[1][1]) ** 2)
                cda, ca = fmt_coord(y1, x1), fmt_coord(y2, x2)
            else:
                cda = ca = fmt_coord(cen.y, cen.x)
            ente_tipo = gr["ente_tipo"] or ENTE_PREDEFINITO.get(gr["categoria"], "altro")
            ente_nome = gr["ente_nome"]
            if not ente_nome and ente_tipo == "consorzio":
                ente_nome = _consorzio_in(Point(cen.x, cen.y), comprensori)
            intere = unary_union([t["gm"] for t, _ in pezzi])
            i = InterferenzaAcqua(
                id=nid, tipo=tipo, corso=gr["nome"], categoria=gr["categoria"],
                ente_tipo=ente_tipo, ente_nome=ente_nome,
                via=_via_vicina(pr.avanti(Point(cen.x, cen.y)), strade_m),
                metri=_metri(pezzi), lon=cen.x, lat=cen.y, dist_min_m=dist,
                attraversa=(tipo == "attraversamento"),
                bbox=tuple(pr.indietro(intere).bounds), coord_da=cda, coord_a=ca,
                tratte_fid=sorted({t.get("fid") for t, _ in pezzi if t.get("fid") is not None}),
                elementi=_elementi(pezzi))
            strane = sorted({str(t.get("fid")) for t, _ in pezzi
                             if t.get("tecnica") and t.get("lunghezza") and t["gm"].length > 0
                             and _fattore_lunghezza(t) == 1.0
                             and abs(float(t["lunghezza"]) / t["gm"].length - 1) > 0.1})
            if strane:
                i.note.append("campo LUNGHEZZA diverso dal disegno sulle tratte %s: i metri in "
                              "fascia sono misurati sul disegno" % ", ".join(strane))
            geom_interf[nid] = intere
            nid += 1
            return i

        # attraversamenti: tecnica proposta
        for a in attraversamenti:
            t0 = max(a["pezzi"], key=lambda tp: tp[1].length)[0]
            a["t0"] = t0
        # gli scavi nuovi in fascia attaccati a un attraversamento ne sono
        # l'avvicinamento: vanno con lui
        restanti = []
        for t, p in paralleli:
            vicino = None
            if not _esistente(t) and t.get("tecnica"):
                for a in attraversamenti:
                    # un attraversamento in infrastruttura esistente non va in
                    # istanza: gli scavi nuovi vicini restano parallelismi
                    if _esistente(a["t0"]) or not a["t0"].get("tecnica"):
                        continue
                    # pezzi di scavo a ridosso dell'attraversamento (entro
                    # 15 m): stesso cantiere, stessa interferenza in tavola
                    if any(p.distance(q) <= TOLL_CLUSTER_M for _, q in a["pezzi"]):
                        vicino = a
                        break
            if vicino is not None:
                vicino["pezzi"].append((t, p))
            else:
                restanti.append((t, p))
        paralleli = restanti

        for a in attraversamenti:
            t0 = a["t0"]
            i = _nuova("attraversamento", a["pezzi"], a["punto"])
            punto = a["punto"]
            if gr["categoria"] == "marittimo":
                # nessun "attraversamento" del mare: lo scavo entra nell'area
                # demaniale, la tecnica e' quella della tratta
                i.tecnica_attr = ""
                if _esistente(t0) and not i.metri:
                    i.includi = False
                    i.note.append("solo infrastruttura esistente: di norma nessuna istanza")
            elif _esistente(t0):
                i.tecnica_attr = "esistente"
                i.includi = False
                i.note.append("passa in un'infrastruttura esistente: di norma nessuna "
                              "istanza (verificare)")
            elif tombini is not None and punto.distance(tombini) <= TOLL_TOMBINO_M:
                i.tecnica_attr = "tombino"
                i.note.append("il corso d'acqua passa in un tombino sotto la strada: "
                              "indicare in sezione la quota sopra il tombino")
            elif any(punto.distance(p) <= TOLL_PONTE_M for p in ponti_m):
                i.tecnica_attr = "ponte"
                i.note.append("la strada passa su un ponte: serve anche l'assenso del "
                              "proprietario del ponte")
            elif t0.get("tecnica") == "nodig":
                i.tecnica_attr = "nodig"
            elif t0.get("tecnica") == "canaletta":
                # canaletta = staffata a un ponte o a un manufatto, non scavo
                i.tecnica_attr = "ponte"
                i.note.append("passaggio in canaletta VTR sul manufatto: serve anche "
                              "l'assenso del proprietario del ponte o del manufatto")
            elif t0.get("tecnica"):
                i.tecnica_attr = "cielo_aperto"
                i.note.append("scavo %s attraverso il corso d'acqua: verificare se c'e' un "
                              "tombino o prevedere no-dig" % rfi.ETICH_TECNICA.get(
                                  t0["tecnica"], t0["tecnica"]).lower())
            else:
                i.tecnica_attr = "?"
                if not i.metri:
                    i.includi = False
                i.note.append("tratta senza scavo (TIPOLOGIA vuota): aerea o in "
                              "infrastruttura esistente? Spunta la riga solo se serve l'istanza")
            risultati.append(i)

        # parallelismi: pezzi nuovi vicini fra loro = una interferenza
        nuovi = [(t, p) for t, p in paralleli if not _esistente(t) and t.get("tecnica")]
        cluster = []
        for t, p in nuovi:
            dove = [cl for cl in cluster if any(p.distance(q) <= TOLL_CLUSTER_M for _, q in cl)]
            if not dove:
                cluster.append([(t, p)])
            else:
                base = dove[0]
                base.append((t, p))
                for altro in dove[1:]:
                    base.extend(altro)
                    cluster.remove(altro)
        for cl in cluster:
            g_cl = unary_union([p for _, p in cl])
            dist = round(g_cl.distance(alveo), 1) if alveo is not None else None
            i = _nuova("parallelismo" if alveo is not None else "area", cl, g_cl, dist)
            if dist is not None and dist < 4.0:
                i.note.append("scavo a %.1f m dall'alveo: verificare la distanza minima "
                              "ammessa dal regolamento" % dist)
            risultati.append(i)

        # pozzetti e armadi nuovi in fascia
        mie = [i for i in risultati if i.id in geom_interf and i.corso == gr["nome"]
               and i.categoria == gr["categoria"]]
        if mie or zona:
            punti = ([("pozzetto", pz) for pz in pozzetti] + [("armadio", a) for a in armadi]
                     + [("colonnina", c) for c in colonnine])
            for tipo, pz in punti:
                if (pz.get("stato") or "").strip().lower() == "esistente":
                    continue
                if pz.get("geom") is None or (tipo == "pozzetto" and not pz.get("dim")):
                    continue
                pm = pr.avanti(pz["geom"])
                attaccata = [i for i in mie if pm.distance(geom_interf[i.id]) <= 1.0]
                if not pm.within(fascia) and not attaccata:
                    continue
                if zona and not attaccata and (
                        not mie or min(pm.distance(geom_interf[i.id]) for i in mie)
                        > TOLL_CLUSTER_M):
                    # area vincolata: armadio o pozzetto dentro l'area lontano
                    # dagli scavi = interferenza a se' (l'armadio fuori terra e'
                    # proprio cio' che la Soprintendenza autorizza)
                    g = pz["geom"]
                    nuova = InterferenzaAcqua(
                        id=nid, tipo="area", corso=gr["nome"], categoria=gr["categoria"],
                        ente_tipo=gr["ente_tipo"], ente_nome=gr["ente_nome"],
                        via=_via_vicina(pm, strade_m), lon=g.x, lat=g.y,
                        bbox=(g.x, g.y, g.x, g.y), coord_da=fmt_coord(g.y, g.x),
                        coord_a=fmt_coord(g.y, g.x))
                    geom_interf[nid] = pm
                    nid += 1
                    risultati.append(nuova)
                    mie.append(nuova)
                    attaccata = [nuova]
                vicina = min(attaccata or mie, key=lambda i: pm.distance(geom_interf[i.id]))
                dentro = pm.within(fascia)
                if tipo == "pozzetto" and dentro:
                    vicina.pozzetti[pz["dim"]] = vicina.pozzetti.get(pz["dim"], 0) + 1
                g = pz["geom"]
                # scavo continuo su cui sta il pozzetto (in testa, in coda o
                # lungo): in tavola, se serve accorpare, il pozzetto va con il
                # SUO scavo
                gruppo = ""
                scavi_v = [e for e in vicina.elementi if e.get("tipo") == "scavo" and "_gm" in e]
                if scavi_v:
                    e_min = min(scavi_v, key=lambda e: pm.distance(e["_gm"]))
                    if pm.distance(e_min["_gm"]) <= 1.5:
                        gruppo = e_min["gruppo"]
                vicina.elementi.append({
                    "tipo": tipo if dentro else tipo + "_fuori", "dim": pz.get("dim") or "",
                    "dim_testo": pz.get("dim_testo") or pz.get("dim") or "",
                    "lon": g.x, "lat": g.y, "km": "", "id": pz.get("id") or "",
                    "fid": pz.get("fid"), "gruppo": gruppo,
                    "chiave_el": "%s|%s" % ({"pozzetto": "P", "colonnina": "C"}.get(tipo, "A"),
                                            pz.get("fid"))})

    risultati.sort(key=lambda i: (i.ente_tipo, i.ente_nome, i.corso, -i.lat, i.lon))
    for n, i in enumerate(risultati, 1):
        i.id = n
    return risultati


# ---------------------------------------------------------------------------
# Raggruppamento in istanze: una per ente destinatario
# ---------------------------------------------------------------------------
@dataclass
class IstanzaAcqua:
    """Una istanza = un ente e UN corso d'acqua (o la costa): la PL e' quella
    del canale, con dentro tutte le interferenze che lo riguardano."""
    numero: int
    ente_tipo: str
    ente_nome: str
    interferenze: list = field(default_factory=list)
    nome_base: str = ""
    corso: str = ""                    # nome del corso d'acqua nei documenti
    tavole: list = field(default_factory=list)     # [[InterferenzaAcqua]] per tavola
    # corsi d'acqua dell'istanza (chiavi di nome_corso_istanza): uno se
    # l'istanza e' per corso d'acqua, tutti quelli dell'ente se e' unica
    corsi_chiavi: list = field(default_factory=list)

    def corsi(self) -> list:
        visti = []
        for i in self.interferenze:
            if i.corso not in visti:
                visti.append(i.corso)
        return visti

    def vie(self) -> list:
        visti = []
        for i in self.interferenze:
            if i.via and i.via not in visti:
                visti.append(i.via)
        return visti


PAROLE_VUOTE = {"DI", "DEL", "DELLA", "DELLE", "DEI", "DEGLI", "IN", "IL", "LA", "LO", "E",
                "-", "D'", "PER"}


def sigla_ente(ente_tipo: str, ente_nome: str, max_len: int = 30) -> str:
    """Nome breve dell'ente per cartelle e file: il percorso completo
    (cartella del progetto + Istanze Acque + cartella + file con lo stesso
    nome) non deve passare i 260 caratteri di Windows.
    'Consorzio di Bonifica in Destra del Fiume Sele' -> 'CB DESTRA FIUME SELE'."""
    nome = re.sub(r'[\\/:*?"<>|]+', " ", (ente_nome or "").upper()).strip()
    if not nome:
        return {"genio_civile": "GENIO CIVILE", "consorzio": "CONSORZIO",
                "comune": "COMUNE", "demanio_marittimo": "DEMANIO MARITTIMO",
                "altro": "ENTE"}.get(ente_tipo, "ENTE")
    nome = re.sub(r"\bCONSORZIO\s+(DI\s+)?BONIFICA\b", "CB", nome)
    nome = re.sub(r"\bCONSORZIO\b", "CONS", nome)
    parole = [p for p in nome.split() if p not in PAROLE_VUOTE]
    out = ""
    for p in parole:
        if len(out) + len(p) + (1 if out else 0) > max_len:
            break
        out = (out + " " + p).strip()
    return out or nome[:max_len]


# una tavola: planimetria di circa 206 x 165 mm; a 1:2000 sono 412 x 330 m,
# con margine per le etichette ne usiamo un po' meno
# planimetria 153x131 mm = 306x263 m a 1:2000; tolti 40 m per lato per le
# etichette, i PUNTI delle interferenze di una tavola stanno in 226x183 m
FRAME_TAVOLA_M = (226.0, 183.0)
MARGINE_TAVOLA_M = 40.0


def _bbox_m(i, lat0):
    """Punto dell'interferenza in metri (equirettangolare), come riquadro
    degenere. Si raggruppa sui PUNTI e non sull'ingombro delle tratte: con
    le tratte lunghe le zone si gonfiavano e due tavole mostravano quasi le
    stesse interferenze."""
    kx = 111320.0 * math.cos(math.radians(lat0))
    ky = 110540.0
    return (i.lon * kx, i.lat * ky, i.lon * kx, i.lat * ky)


def tavole_per_zona(interf: list, frame_m: tuple = None, max_per: int = 0) -> list:
    """Raggruppa le interferenze in tavole: unisce le zone vicine finche'
    l'insieme sta in una planimetria (frame_m metri). Numera i.tavola.
    Le tavole seguono il corso d'acqua da nord-ovest a sud-est.
    `max_per` > 0: al massimo tante interferenze per tavola (Soprintendenza
    «solo armadi»: un armadio per foto, 2 o 4 per tavola)."""
    if not interf:
        return []
    fw, fh = frame_m or FRAME_TAVOLA_M
    lat0 = sum(i.lat for i in interf) / len(interf)
    gruppi = [[i] for i in interf]
    box = [_bbox_m(i, lat0) for i in interf]

    def unione(a, b):
        return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))

    def sta(b):
        return (b[2] - b[0]) <= fw and (b[3] - b[1]) <= fh
    while True:
        migliore = None
        for a in range(len(gruppi)):
            for b in range(a + 1, len(gruppi)):
                if max_per and len(gruppi[a]) + len(gruppi[b]) > max_per:
                    continue
                u = unione(box[a], box[b])
                if not sta(u):
                    continue
                area = (u[2] - u[0]) * (u[3] - u[1])
                if migliore is None or area < migliore[0]:
                    migliore = (area, a, b, u)
        if migliore is None:
            break
        _, a, b, u = migliore
        gruppi[a] = gruppi[a] + gruppi[b]
        box[a] = u
        del gruppi[b], box[b]
    for g in gruppi:
        g.sort(key=lambda i: (-i.lat, i.lon))
    gruppi.sort(key=lambda g: (-max(i.lat for i in g), min(i.lon for i in g)))
    for n, g in enumerate(gruppi, 1):
        for i in g:
            i.tavola = n
    return gruppi


def nome_corso_istanza(corso: str, categoria: str) -> str:
    """I tratti senza nome dello stesso ente vanno in una istanza sola."""
    if _con_nome(corso) or categoria == "marittimo":
        return corso
    return {"bonifica": "Canali e fossi senza nome",
            "demanio": "Corsi d'acqua senza nome"}.get(categoria, "Corsi d'acqua senza nome")


def _breve(testo: str, max_len: int) -> str:
    t = re.sub(r'[\\/:*?"<>|«»]+', " ", (testo or "").upper()).strip()
    parole = [p for p in t.split() if p not in PAROLE_VUOTE]
    out = ""
    for p in parole:
        if len(out) + len(p) + (1 if out else 0) > max_len:
            break
        out = (out + " " + p).strip()
    return out or t[:max_len]


def raggruppa_istanze_acque(interferenze: list, comune: str, frame_m: tuple = None,
                            per_corso: bool = True) -> list:
    """Istanze fra le interferenze incluse; dentro, le tavole per zona
    (interferenze vicine nella stessa tavola, senza distinguere fra
    attraversamenti e parallelismi).
    per_corso=True: una istanza per ente e corso d'acqua (PL del singolo
    canale); False: una istanza per ente con tutti i suoi corsi d'acqua.
    frame_m = (larghezza, altezza) in metri che una tavola puo' contenere."""
    gruppi = {}
    for i in interferenze:
        if not i.includi:
            continue
        corso = nome_corso_istanza(i.corso, i.categoria)
        k = (i.ente_tipo, (i.ente_nome or "").strip(), corso if per_corso else "")
        gruppi.setdefault(k, []).append(i)
    istanze = []
    for n, (k, lst) in enumerate(sorted(gruppi.items()), 1):
        chiavi = []
        for i in lst:
            c = nome_corso_istanza(i.corso, i.categoria)
            if c not in chiavi:
                chiavi.append(c)
        nome_corsi = k[2] or _elenco(chiavi)
        ist = IstanzaAcqua(numero=n, ente_tipo=k[0], ente_nome=k[1], interferenze=lst,
                           corso=nome_corsi, corsi_chiavi=chiavi)
        sigla = sigla_ente(k[0], k[1], 26)
        if not per_corso:
            ist.nome_base = "%s_%s" % ((comune or "COMUNE").upper(), sigla)
        elif k[2] and k[2].lower() not in ("demanio marittimo",):
            breve = _breve(k[2], 20) if _con_nome(k[2]) else "SENZA NOME"
            ist.nome_base = "%s_%s_%s" % ((comune or "COMUNE").upper(), sigla, breve)
        else:
            ist.nome_base = "%s_%s" % ((comune or "COMUNE").upper(), sigla)
        ist.tavole = tavole_per_zona(lst, frame_m)
        # interferenze in ordine di tavola (relazione e LEGGIMI seguono la PL)
        ist.interferenze = [i for t in ist.tavole for i in t]
        istanze.append(ist)
    usati = {}
    for ist in istanze:
        if ist.nome_base in usati:
            usati[ist.nome_base] += 1
            ist.nome_base = "%s_%d" % (ist.nome_base, usati[ist.nome_base])
        else:
            usati[ist.nome_base] = 1
    return istanze


# ---------------------------------------------------------------------------
# Testi e documenti (modelli in modelli_acque/, ricavati da quelli RFI)
# ---------------------------------------------------------------------------
TEMPLATE_FILES = {
    "art49": "TEMPLATE_1.0_art.49.docx",
    "rt":    "TEMPLATE_1.2_RT+CR.docx",
    "bollo": "TEMPLATE_1.3_Bollo.docx",
}


def _elenco(voci: list) -> str:
    voci = [v for v in voci if v]
    if not voci:
        return ""
    if len(voci) == 1:
        return voci[0]
    return "%s e %s" % (", ".join(voci[:-1]), voci[-1])


def _con_nome(nome: str) -> bool:
    n = (nome or "").lower()
    return bool(n) and "senza nome" not in n and n != "demanio marittimo"


def articolo_di(nome: str) -> str:
    """'del Consorzio ...', 'della Regione ...', "dell'Ufficio ..."."""
    n = (nome or "").strip()
    primo = n.split(" ")[0].lower() if n else ""
    if primo in ("regione", "provincia", "citta'", "città", "direzione", "struttura", "autorità",
                 "autorita'", "agenzia", "aipo"):
        return "della %s" % n
    if primo[:1] in "aeiou" and primo:
        return "dell'%s" % n
    if primo in ("consorzio", "comune", "genio", "dipartimento", "servizio", "demanio"):
        return "del %s" % n
    return "di %s" % n


def descr_corsi(ist) -> str:
    """'del canale «Fontanile Vecchio»', 'dei corsi d'acqua «A» e «B»',
    'di canali e fossi del reticolo di bonifica'."""
    cats = {i.categoria for i in ist.interferenze}
    nomi = [n for n in ist.corsi() if _con_nome(n)]
    if cats == {"bonifica"}:
        sing, plur, anon = "del canale", "dei canali", "di canali e fossi del reticolo di bonifica"
    elif cats == {"demanio"}:
        sing, plur, anon = "del corso d'acqua", "dei corsi d'acqua", \
            "di corsi d'acqua del demanio idrico"
    else:
        sing, plur, anon = "del corso d'acqua", "dei corsi d'acqua", "di corsi d'acqua"
    citati = ["«%s»" % n for n in nomi]
    anonimi = any(not _con_nome(n) for n in ist.corsi())
    if not citati:
        return anon
    testo = "%s %s" % (sing if len(citati) == 1 else plur, _elenco(citati))
    if anonimi:
        testo += " e %s" % anon.replace("di ", "", 1)
    return testo


def relazione_tipi(ist) -> str:
    """Per l'acqua non si distingue per tipologia di interferenza: le opere
    sono quelle che cadono nella fascia di rispetto del corso d'acqua."""
    return "nella fascia di rispetto"


def testi_istanza(ist, dest_nome: str) -> dict:
    """Frasi dell'oggetto e della relazione per una istanza acque."""
    vie = ist.vie()
    vie_txt = _elenco(vie) if vie else "le vie indicate negli elaborati grafici"
    ente = dest_nome or sigla_ente(ist.ente_tipo, ist.ente_nome).title()
    marittimo = all(i.categoria == "marittimo" for i in ist.interferenze)
    if marittimo:
        nucleo = "%s, nella fascia di competenza del Demanio Marittimo %s" % (
            vie_txt, articolo_di(ente) if "maritt" not in ente.lower() else "(%s)" % ente)
        titolo = "NELLA FASCIA DI COMPETENZA DEL DEMANIO MARITTIMO"
        descr = "Scavi e posa nella fascia di competenza del demanio marittimo"
        tabella = "NELLA FASCIA DI COMPETENZA DEL DEMANIO MARITTIMO"
    else:
        rel = relazione_tipi(ist)
        corsi = descr_corsi(ist)
        nucleo = "%s, %s %s, di competenza %s" % (vie_txt, rel, corsi, articolo_di(ente))
        for da, a in (("del ", "con il "), ("dei ", "con i "), ("di ", "con ")):
            if corsi.startswith(da):
                titolo = ("IN INTERFERENZA " + a + corsi[len(da):]).upper()
                break
        else:
            titolo = ("IN INTERFERENZA CON " + corsi).upper()
        descr = rel[0].upper() + rel[1:]
        tabella = "IN FASCIA DI RISPETTO"
    return {"oggetto": "lungo %s." % nucleo, "premessa": "lungo %s" % nucleo,
            "bollo": "%s, per la propria competenza." % nucleo, "titolo": titolo,
            "descr": descr, "tabella": tabella, "ente": ente}


RIGHE_TABELLE = {
    "via": "Indirizzo (se la via non è nota: coordinate)",
    "coordinate": "Coordinate di inizio e fine",
    "via_coordinate": "Indirizzo e coordinate di inizio e fine",
}


def coordinate_tavola(tav) -> str:
    """Coordinate dei lavori della tavola per le tabelle della relazione:
    «da lat, lon a lat, lon» con i due estremi piu' lontani fra loro, un punto
    solo se coincidono. 6 decimali (circa 10 cm)."""
    pts = []
    for i in tav:
        for s in (i.coord_da, i.coord_a):
            try:
                la, lo = (float(v) for v in str(s).split(","))
                pts.append((la, lo))
            except (TypeError, ValueError):
                continue
    if not pts and tav:
        pts = [(tav[0].lat, tav[0].lon)]
    if not pts:
        return ""
    a, b = max(((p, q) for p in pts for q in pts),
               key=lambda pq: (pq[0][0] - pq[1][0]) ** 2 + (pq[0][1] - pq[1][1]) ** 2)

    def _f(p):
        return "%.6f, %.6f" % p
    if abs(a[0] - b[0]) < 1e-6 and abs(a[1] - b[1]) < 1e-6:
        return _f(a)
    # una riga per estremo: nella cella della tabella si legge meglio
    return "inizio %s\nfine %s" % (_f(a), _f(b))


def tratte_istanza(ist, righe: str = "via") -> list:
    """Righe delle tabelle della relazione (scavi, pozzetti, cronoprogramma):
    una per tavola della PL, con metri e pozzetti sommati. `righe` sceglie
    come si riconosce il tratto (RIGHE_TABELLE): le vie della tavola (come a
    Valderice: "Via Antonino e Via Marco Polo (Tavola 1)"), le coordinate, o
    tutte e due. Senza via nota si usano le coordinate."""
    tavole = ist.tavole or [[i] for i in ist.interferenze]
    out = []
    for k, tav in enumerate(tavole, 1):
        vie = []
        for i in tav:
            if i.via and i.via not in vie:
                vie.append(i.via)
        metri, pozz = {}, {}
        for i in tav:
            for t, m in i.metri.items():
                metri[t] = metri.get(t, 0) + m
            for d, n in i.pozzetti.items():
                pozz[d] = pozz.get(d, 0) + n
        if not any(metri.values()) and not pozz:
            # tavola senza lavori da autorizzare (solo posa aerea o in
            # infrastruttura esistente): nessuna riga, la numerazione resta
            # quella delle tavole della PL
            continue
        via, coord = _elenco(vie), coordinate_tavola(tav)
        tav_txt = "(Tavola %d)" % k
        if righe == "coordinate" or (righe == "via" and not via):
            etich = "Tavola %d\n%s" % (k, coord) if coord else \
                "%s %s" % (ist.corso or "Interferenze", tav_txt)
        elif righe == "via_coordinate":
            etich = "%s %s" % (via or ist.corso or "Interferenze", tav_txt) + \
                ("\n" + coord if coord else "")
        else:
            etich = "%s %s" % (via, tav_txt)
        tr = rfi.Tratta("", "", metri, pozz, etich, [(etich, pozz)] if pozz else [])
        tr.tavola = k            # il cronoprogramma dice solo «Tavola n»
        tr._elementi = [e for i in tav for e in i.elementi]     # colonna «N. ARLO»
        out.append(tr)
    return out


def ritocca_tabelle_rt(doc, tratte: list, intestazione: str = "Indirizzo") -> None:
    """Dopo rfi.riempi_tabelle_rt, solo per le relazioni acque:
    - scavi e pozzetti: colonna «Indirizzo» con intestazione, piu' larga (le
      vie e le coordinate andavano a capo 7-8 volte) e testo centrato non in
      grassetto, come nelle pratiche presentate;
    - cronoprogramma: la riga dice solo «Tavola n»."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH

    def _riga_dati(cell):
        for p in cell.paragraphs:
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for r in p.runs:
                r.bold = False

    # (tabella, prima riga dati) come in rfi.riempi_tabelle_rt
    for idx, prima in ((rfi.RT_TAB_SCAVI, 4), (rfi.RT_TAB_POZZETTI, 2)):
        if idx >= len(doc.tables):
            continue
        tb = doc.tables[idx]
        # intestazione: la riga con «Tot»/«Totale» nelle altre colonne
        for r in list(tb.rows[:prima])[::-1]:
            if any(c.text.strip().lower().startswith("tot") for c in r.cells[1:]):
                if not r.cells[0].text.strip():
                    rfi._set_cella(r.cells[0], intestazione)
                    # stesso aspetto delle intestazioni accanto (es. «Tot»)
                    vicino = next((run for c in r.cells[1:] for p in c.paragraphs
                                   for run in p.runs if run.text.strip()), None)
                    for p in r.cells[0].paragraphs:
                        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                        for run in p.runs:
                            run.bold = True
                            if vicino is not None:
                                run.font.size = vicino.font.size
                                run.font.name = vicino.font.name
                break
        _prima_colonna_larga(tb, 0.36)
        for r in tb.rows[prima:-1]:                 # righe dati (non il totale)
            _riga_dati(r.cells[0])
    if rfi.RT_TAB_CRONO < len(doc.tables):
        tb = doc.tables[rfi.RT_TAB_CRONO]
        for tr, r in zip(tratte, tb.rows[2:]):
            if getattr(tr, "tavola", None):
                rfi._set_cella(r.cells[0], "Tavola %d" % tr.tavola)


def _prima_colonna_larga(tb, quota):
    """Prima colonna = `quota` della larghezza della tabella, le altre si
    dividono il resto in parti uguali (griglia e celle, come fa Word)."""
    from docx.oxml.ns import qn
    from docx.oxml import OxmlElement
    grid = tb._tbl.tblGrid
    cols = grid.findall(qn("w:gridCol")) if grid is not None else []
    if len(cols) < 2:
        return
    try:
        tot = sum(int(c.get(qn("w:w"))) for c in cols)
    except (TypeError, ValueError):
        return
    w0 = int(tot * quota)
    wa = int((tot - w0) / (len(cols) - 1))
    larghe = [w0] + [wa] * (len(cols) - 1)
    for c, w in zip(cols, larghe):
        c.set(qn("w:w"), str(w))
    for row in tb.rows:
        k = 0
        for tc in row._tr.findall(qn("w:tc")):
            tcPr = tc.get_or_add_tcPr()
            span = tcPr.find(qn("w:gridSpan"))
            n = int(span.get(qn("w:val"))) if span is not None else 1
            w = sum(larghe[k:k + n])
            k += n
            tcW = tcPr.find(qn("w:tcW"))
            if tcW is None:
                tcW = OxmlElement("w:tcW")
                tcPr.insert(0, tcW)
            tcW.set(qn("w:w"), str(w))
            tcW.set(qn("w:type"), "dxa")


def valori_istanza(ist, comune, dest: dict, oggi=None, testi: dict = None) -> dict:
    """{segnaposto: valore} per i modelli acque. dest = {nome, indirizzo, pec}.
    `testi`: frasi gia' pronte (schede Soprintendenza e Parchi / Natura 2000,
    stesse chiavi di testi_istanza) al posto di quelle dei corsi d'acqua."""
    import datetime
    oggi = oggi or datetime.date.today()
    t = testi or testi_istanza(ist, (dest or {}).get("nome", ""))
    base = ist.nome_base
    X = rfi.XXX
    return {
        "NOME_COMUNE": comune.nome.upper(), "PROV_SIGLA": comune.prov_sigla.upper(),
        "CAP": comune.cap, "INDIRIZZO_COMUNE": comune.indirizzo or X,
        "COMUNE_PEC": comune.pec or X,
        "DEST_NOME": t["ente"], "DEST_INDIRIZZO": (dest or {}).get("indirizzo") or X,
        "DEST_PEC": (dest or {}).get("pec") or X,
        "OGGETTO_ACQUE": t["oggetto"], "PREMESSA_ACQUE": t["premessa"],
        "TITOLO_ACQUE": t["titolo"], "DESCR_INTERFERENZA": t["descr"],
        "DESCR_TABELLA": t["tabella"], "OGGETTO_BOLLO": t["bollo"],
        "PL_FILE": rfi.NOMI_FILE["pl"].format(base=base),
        "RT_FILE": rfi.NOMI_FILE["rt"].format(base=base).replace(".docx", ".pdf"),
        "MESE_ANNO": oggi.strftime("%m/%Y"),
        # firmatari: restano da compilare, come per RFI
        "DATA": "XX/XX/%d" % oggi.year, "LUOGO_FIRMA": X,
        "PROC_COGNOME": X, "PROC_NOME": X, "PROC_CF": X, "PROC_NATO_A": X,
        "PROC_PROV": "XX", "PROC_NATO_IL": "XX/XX/XXXX", "PROC_RESIDENZA": X,
        "PROC_VIA": X, "PROC_DOC": X,
    }


def genera_documenti_istanza(ist, comune, dest: dict, cartella_template: str,
                             cartella_out: str, rese: dict = None, oggi=None,
                             righe: str = "via", testi: dict = None,
                             solo: tuple = None, tratte: list = None,
                             intestazione: str = "Indirizzo") -> dict:
    """Compila i 3 modelli Word dell'istanza (art. 49, RT+CR, bollo).
    `righe`: come si indicano i tratti nelle tabelle (RIGHE_TABELLE).
    `testi`: frasi al posto di quelle dei corsi d'acqua (vedi valori_istanza).
    `solo`: chiavi dei modelli da compilare (es. ("rt",)); None = tutti.
    Ritorna {chiave: percorso} (None se il modello manca)."""
    import os
    from docx import Document
    os.makedirs(cartella_out, exist_ok=True)
    valori = valori_istanza(ist, comune, dest, oggi, testi)
    # righe gia' pronte (scheda Strade: una per scavo/pozzetto per progressiva)
    # colonna «N. ARLO» (flag del progetto): numeri sugli elementi, righe in
    # ordine di numero
    try:
        from . import ftth_arlo as ARLO
    except ImportError:
        import ftth_arlo as ARLO
    ARLO.annota_progetto(ist.interferenze)
    tratte = tratte if tratte is not None else tratte_istanza(ist, righe)
    con_arlo = ARLO.assegna(tratte)
    if con_arlo:
        ARLO.ordina(tratte)
    prodotti = {}
    for chiave, nome_tpl in TEMPLATE_FILES.items():
        if solo is not None and chiave not in solo:
            continue
        tpl = os.path.join(cartella_template, nome_tpl)
        if not os.path.isfile(tpl):
            prodotti[chiave] = None
            continue
        doc = Document(tpl)
        if chiave == "rt":
            rfi.applica_condizioni(doc, {
                "SE_POZZETTI": any(i.pozzetti for i in ist.interferenze),
                "SE_ARMADI": any(e.get("tipo") == "armadio"
                                 for i in ist.interferenze for e in i.elementi),
                # colonnine PTE scelte (Soprintendenza, punto 6): paragrafo come l'armadio
                "SE_COLONNINE": any(e.get("tipo") == "colonnina"
                                    for i in ist.interferenze for e in i.elementi)})
            rfi.riempi_tabelle_rt(doc, tratte, rese)
            try:
                rfi.aggiungi_tabella_armadi(doc, ist)
            except Exception:  # noqa: BLE001
                pass
            try:
                rfi.togli_note_doppie(doc)
            except Exception:  # noqa: BLE001
                pass
            ritocca_tabelle_rt(doc, tratte, intestazione)
        rfi.sostituisci_tutto(doc, valori)
        if chiave == "rt":
            rfi.adatta_relazione(doc, {t for tr in tratte for t, m in tr.metri.items() if m},
                                 con_pozzetti=any(i.pozzetti for i in ist.interferenze))
            rfi.uniforma_spaziature(doc)
            rfi.compatta_copertina(doc)
            if con_arlo:
                ARLO.colonne_rt(doc, tratte)
        out = os.path.join(cartella_out, rfi.NOMI_FILE[chiave].format(base=ist.nome_base))
        doc.save(out)
        prodotti[chiave] = out
    return prodotti


TITOLI_SEZIONE = {
    "tombino": ("SEZIONE TIPO ATTRAVERSAMENTO SOPRA IL TOMBINO", ["sezione_tipo_tombino"]),
    "nodig": ("SEZIONE TIPO NO DIG SOTTO L'ALVEO", ["sezione_tipo_nodig", "sezione_nodig"]),
    "ponte": ("SEZIONE TIPO POSA SUL PONTE", ["sezione_tipo_ponte"]),
}
TITOLI_SCAVO = {"minitrincea": "SEZIONE TIPO SCAVO IN MINITRINCEA",
                "microtrincea": "SEZIONE TIPO SCAVO IN MICROTRINCEA",
                "trincea": "SEZIONE TIPO SCAVO TRADIZIONALE",
                "nodig": "SEZIONE TIPO PERFORAZIONE NO DIG"}


def sezione_tipo(i, libreria: dict = None) -> tuple:
    """(nomi file da cercare, titolo, nome da suggerire) della sezione tipo di
    una interferenza: per come si passa il corso d'acqua, altrimenti per la
    tecnica di scavo prevalente (particolare del plugin)."""
    libreria = libreria or {}
    nomi, titolo = [], ""
    if i.tecnica_attr in TITOLI_SEZIONE:
        titolo, nomi = TITOLI_SEZIONE[i.tecnica_attr]
        nomi = list(nomi)
    tec = max(i.metri, key=i.metri.get) if i.metri else None
    if tec:
        nomi += ["sezione_%s" % tec] + ([libreria["sezione_%s" % tec]]
                                        if "sezione_%s" % tec in libreria else [])
        titolo = titolo or TITOLI_SCAVO.get(tec, "SEZIONE TIPO")
    return nomi, titolo or "SEZIONE TIPO", (nomi[0] if nomi else "sezione_tipo")


def candidati_sezione(i, libreria: dict = None) -> list:
    """[(nomi file, titolo)] in ordine: prima la sezione tipo di come si passa il
    corso d'acqua (se il disegno c'e'), poi il particolare della tecnica di
    scavo prevalente. Il titolo segue il disegno trovato davvero."""
    libreria = libreria or {}
    out = []
    if i.tecnica_attr in TITOLI_SEZIONE:
        titolo, nomi = TITOLI_SEZIONE[i.tecnica_attr]
        out.append((list(nomi), titolo))
    tec = max(i.metri, key=i.metri.get) if i.metri else None
    if tec:
        nomi = ["sezione_%s" % tec] + ([libreria["sezione_%s" % tec]]
                                       if "sezione_%s" % tec in libreria else [])
        out.append((nomi, TITOLI_SCAVO.get(tec, "SEZIONE TIPO")))
    return out


def promemoria(ist, comune, dest: dict) -> str:
    L = ["ISTANZA %d — %s" % (ist.numero, ist.nome_base), "",
         "Ente: %s" % ENTI_TIPO.get(ist.ente_tipo, ist.ente_tipo),
         "Destinatario: %s — %s — PEC %s" % (
             (dest or {}).get("nome") or "DA COMPILARE",
             (dest or {}).get("indirizzo") or "indirizzo DA COMPILARE",
             (dest or {}).get("pec") or "DA COMPILARE"),
         "Corso d'acqua: %s" % ist.corso,
         "Comune: %s (%s)" % (comune.nome.upper(), comune.prov_sigla.upper()), "",
         "Interferenze (numerate come nella PL):"]
    for k, i in enumerate(ist.interferenze, 1):
        metri = ", ".join("%s %s m" % (rfi.ETICH_TECNICA.get(t, t), m)
                          for t, m in i.metri.items() if m)
        L.append("  - %d (Tavola %d): %s — %s%s" % (
            k, i.tavola or k, descr_tipo(i.tipo, i.categoria), i.via or "via da indicare",
            (" — " + metri) if metri else ""))
        if i.tecnica_attr:
            L.append("      come si passa: %s" % TECNICHE_ATTR.get(i.tecnica_attr, i.tecnica_attr))
        L.append("      da %s a %s" % (i.coord_da, i.coord_a))
        for n in i.note:
            L.append("      ! %s" % n)
    L += ["", "Documenti:",
          "  1.0 Istanza art. 49 (Word)",
          "  1.1 Planimetria PL (PDF, dal layout QGIS)",
          "  1.2 Relazione tecnica + cronoprogramma (Word + PDF)",
          "  1.3 Autocertificazione bollo (Word)", "",
          "Da fare prima dell'invio:",
          "  - Compilare i campi XXXXX (procuratore, referenti, firme).",
          "  - Controllare la sezione di ogni tavola (SEZIONE A-A' disegnata o sezione tipo)."]
    if not ((dest or {}).get("pec") and (dest or {}).get("indirizzo")):
        L.append("  - Destinatario incompleto: inserire indirizzo e PEC dell'ente.")
    if ist.ente_tipo == "consorzio":
        L.append("  - Verificare la fascia di rispetto nel regolamento del Consorzio.")
    if any(i.categoria == "marittimo" for i in ist.interferenze):
        L.append("  - Verificare la dividente demaniale (SITR) se si è usata la linea di costa OSM.")
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------
# Screening acque del comune
# ---------------------------------------------------------------------------
def query_overpass_comune(rel_id) -> str:
    """Corsi d'acqua dentro il confine comunale (relation OSM del comune).
    L'area stessa esce come sentinella (ftth_screening._overpass la usa per
    capire se il server ha davvero risolto il confine)."""
    # su tutto il comune solo i corsi principali e i fossi con nome: tutti i
    # fossi di un comune grande (Eboli, 137 km2) fanno scadere la richiesta;
    # quelli senza nome vicino al progetto arrivano dalla ricerca sull'area
    return ("[out:json][timeout:150];rel(%s);map_to_area->.a;.a out ids;("
            'way["waterway"~"^(river|stream|canal)$"](area.a);'
            'way["waterway"~"^(ditch|drain)$"]["name"](area.a);'
            ");out body geom qt;" % rel_id)


def unisci_corsi(*liste) -> list:
    """Unisce liste di CorsoAcqua togliendo i doppioni (stessa way OSM)."""
    visti, out = set(), []
    for lst in liste:
        for c in lst or []:
            k = c.osm_id if c.osm_id is not None else id(c)
            if k in visti:
                continue
            visti.add(k)
            out.append(c)
    return out


def query_costa_bbox(bbox_snwe) -> str:
    """Linea di costa nel riquadro del comune (la coastline corre lungo il
    confine e map_to_area non la prende)."""
    S, N, W, E = bbox_snwe
    return ('[out:json][timeout:90];way["natural"="coastline"](%f,%f,%f,%f);'
            "out body geom qt;" % (S, W, N, E))


def chiave_screening(c) -> tuple:
    """Una riga di screening per corso d'acqua con nome; i tratti senza nome
    in una riga per categoria."""
    if c.con_nome or c.categoria == "marittimo":
        return (c.nome, c.categoria)
    return (nome_corso_istanza(c.nome, c.categoria), c.categoria)


def riepilogo_screening(corsi: list, tratte: list = None, fasce: dict = None,
                        vicino_m: float = 200.0) -> list:
    """Righe dello screening: [{'chiave', 'nome', 'categoria', 'ente_tipo',
    'km', 'tratti', 'tombini', 'dist_m', 'in_fascia', 'proposto'}], ordinate
    per distanza dal progetto. `tratte` = geometrie WGS84 della rete (anche
    vuoto: senza progetto si vede solo l'elenco). proposto = da sottoporre a
    istanza (entro `vicino_m` dalla rete)."""
    from shapely.ops import unary_union
    if not corsi:
        return []
    fasce = dict(FASCIA_PREDEFINITA, **(fasce or {}))
    c0 = unary_union([c.geom for c in corsi]).centroid
    pr = rfi._Proiezione(c0.x, c0.y)
    rete = unary_union([pr.avanti(g) for g in (tratte or []) if g is not None and not g.is_empty]) \
        if tratte else None
    gruppi = {}
    for c in corsi:
        k = chiave_screening(c)
        g = gruppi.setdefault(k, {"chiave": k, "nome": k[0], "categoria": k[1],
                                  "ente_tipo": c.ente_tipo or ENTE_PREDEFINITO.get(k[1], "altro"),
                                  "geoms": [], "tratti": 0, "tombini": 0})
        g["geoms"].append(pr.avanti(c.geom))
        g["tratti"] += 1
        g["tombini"] += 1 if c.tombino else 0
    out = []
    for g in gruppi.values():
        u = unary_union(g.pop("geoms"))
        g["km"] = round(u.length / 1000.0, 2)
        if rete is not None and not rete.is_empty:
            d = u.distance(rete)
            g["dist_m"] = round(d, 0)
            g["in_fascia"] = d <= fasce.get(g["categoria"], 10.0)
            g["proposto"] = d <= vicino_m
        else:
            g["dist_m"] = None
            g["in_fascia"] = False
            g["proposto"] = False
        out.append(g)
    out.sort(key=lambda g: (g["dist_m"] is None, g["dist_m"] or 0, g["nome"]))
    return out


def siti_utili(comune: str, provincia: str = "", regione: str = "",
               geoportale: str = "") -> list:
    """[(titolo, url, a cosa serve)] per trovare l'ente competente sull'acqua.
    Dove un indirizzo diretto non e' certo si usa una ricerca gia' impostata:
    porta sempre alla pagina giusta senza rischiare link sbagliati."""
    from urllib.parse import quote_plus

    def cerca(q):
        return "https://www.google.com/search?q=" + quote_plus(q)
    luogo = comune + ((" " + provincia) if provincia else "")
    out = []
    if geoportale:
        out.append(("Geoportale della Regione %s" % (regione or ""), geoportale,
                    "reticolo idrografico, comprensori di bonifica, dividente demaniale"))
    out += [
        ("Consorzio di bonifica competente", cerca("consorzio di bonifica %s" % luogo),
         "chi gestisce canali e fossi nel comune (comprensorio, regolamento, PEC)"),
        ("ANBI - Consorzi di bonifica d'Italia", "https://www.anbi.it/",
         "elenco nazionale dei Consorzi di bonifica"),
        ("Genio Civile / demanio idrico", cerca("genio civile %s demanio idrico concessioni"
                                                % (provincia or regione or comune)),
         "ufficio regionale per fiumi e torrenti (nulla osta idraulico, concessioni)"),
        ("Reticolo idrico minore del Comune", cerca("reticolo idrico minore %s" % comune),
         "in alcune regioni (es. Lombardia) i fossi minori sono del Comune"),
        ("Autorità di bacino distrettuale", cerca("autorità di bacino distrettuale %s PAI"
                                                  % (regione or comune)),
         "piano di assetto idrogeologico e fasce fluviali"),
        ("SID - Portale del mare (demanio marittimo)", "https://sid.mit.gov.it/",
         "dividente demaniale e concessioni sulla costa (accesso con credenziali)"),
        ("Demanio marittimo della Regione", cerca("demanio marittimo regione %s istanza"
                                                  % (regione or comune)),
         "ufficio regionale competente per la fascia costiera"),
    ]
    return out


AVVISO_VERIFICA = (
    "Nota: i siti indicati sono solo suggerimenti per orientare la ricerca e possono cambiare "
    "indirizzo nel tempo. Anche i corsi d'acqua e la linea di costa trovati su OpenStreetMap "
    "sono dati collaborativi, non ufficiali: nomi, tracciati, categorie ed enti competenti "
    "vanno sempre verificati sulle fonti ufficiali (geoportale regionale, Consorzio, "
    "Genio Civile, Comune) prima di presentare l'istanza.")


def query_overpass(bbox, solo_acque: bool = False) -> str:
    """bbox = (latmin, lonmin, latmax, lonmax). solo_acque: senza strade e
    ponti, per le aree grandi dove la richiesta completa scade."""
    # strade e ponti solo vicino all'acqua: su un comune grande (Ferrara)
    # tutte le strade con nome fanno scadere la richiesta
    b = "%f,%f,%f,%f" % tuple(bbox)
    acqua = '"water"~"^(river|canal|stream|oxbow|ditch|drain|lagoon)$"'
    if solo_acque:
        return ("[out:json][timeout:180];("
                'way["waterway"~"^(river|stream|canal|ditch|drain)$"](%s);'
                'way["natural"="coastline"](%s);'
                ");out body geom qt;") % (b, b)
    return ("[out:json][timeout:180];("
            'way["waterway"~"^(river|stream|canal|ditch|drain)$"](%s);'
            'way["waterway"="riverbank"](%s);'
            'way["natural"="water"][%s](%s);'
            'relation["natural"="water"][%s](%s);'
            'way["natural"="coastline"](%s);'
            ")->.acque;"
            ".acque out body geom qt;"
            'way["highway"]["bridge"](around.acque:%d);out body geom qt;'
            'way["highway"]["name"](around.acque:%d);out body geom qt;'
            ) % (b, b, acqua, b, acqua, b, b, int(TOLL_PONTE_M + 20), int(RAGGIO_VIA_M + 20))
