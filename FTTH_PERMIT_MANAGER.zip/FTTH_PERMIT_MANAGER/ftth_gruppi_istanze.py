﻿"""Istanze negli shape principali: un campo per sezione, per gestire tutte le
istanze in un solo progetto.

Confermate le interferenze, «Scrivi l'istanza negli shape» compila nei layer
principali 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO il campo della
sezione (IST_STRADE, IST_ACQUE, IST_FERROV, IST_SOPR, IST_PARCHI) con il nome
dell'istanza: «SP28», «Canale San Marco», ... Un elemento in due istanze
della stessa sezione ha i due nomi separati da «; ».

Dal plugin si sceglie un'istanza e «Mostra solo questa» spegne i layer
principali e accende una vista filtrata (gruppo «Istanze > sezione > vista»),
senza filtri sui layer principali; «Mostra tutto» torna alla vista normale.

Si possono aggiungere altri elementi all'istanza (selezione in mappa + «Aggiungi
la selezione all'istanza»): alla generazione si contano come quelli trovati
dalla ricerca, con l'interferenza che la ricerca ha calcolato per loro (taglio
su fascia/sede/area, km); fuori da tutte le zone contano 0 m. Quando il campo
di un'istanza è compilato, la PL disegna gli elementi con quel nome.

(Fino alla 3.0 di sviluppo c'erano gruppi di copie in 01_File shp/Istanze.gpkg:
i layer di quei gruppi restano esclusi dai layer principali.)
"""
import json
import os
import re

RADICE = "Istanze"
FILE = "Istanze.gpkg"
PRJ = "FTTH_GRUPPI_ISTANZE"
SEZIONI = {"strade": "Strade", "acque": "Acque", "rfi": "Ferrovia",
           "sopr": "Soprintendenza", "parchi": "Parchi e Natura 2000"}
# nome del campo negli shape principali (al massimo 10 caratteri: shapefile)
CAMPI = {"strade": "IST_STRADE", "acque": "IST_ACQUE", "rfi": "IST_FERROV",
         "sopr": "IST_SOPR", "parchi": "IST_PARCHI"}
SEP = "; "
# campo delle copie della vista con il fid dell'elemento vero (mancava: la
# vista con gli occhi si fermava con un errore e non mostrava niente)
CAMPO_ORIG = "ftth_orig"
GRUPPO_VISTA = "Vista dell'istanza"
GRUPPO_VISTA_COMUNALE = "Istanza comunale"
# (chiave, nome del layer principale, tipi degli elementi nelle interferenze)
LAYER = (("tratte", "03 INFRASTRUTTURE", ()),
         ("pozzetti", "02_POZZETTO", ("pozzetto", "pozzetto_fuori")),
         ("armadi", "01_ARMADIO OTTICO", ("armadio", "armadio_fuori")))


# --------------------------------------------------------------------------- #
#  Parte senza QGIS (testabile)
# --------------------------------------------------------------------------- #
def fid_istanza(ist) -> dict:
    """{'tratte': {fid}, 'pozzetti': {fid}, 'armadi': {fid}} dell'istanza, come
    nelle PL («solo armadi» compreso: interferenze_pl)."""
    rete = getattr(ist, "interferenze_pl", None) or ist.interferenze
    out = {"tratte": set(), "pozzetti": set(), "armadi": set()}
    for i in rete:
        for f in getattr(i, "tratte_fid", None) or []:
            if f is not None:
                out["tratte"].add(int(f))
        for e in getattr(i, "elementi", None) or []:
            for chiave, _n, tipi in LAYER[1:]:
                if e.get("tipo") in tipi and e.get("fid") is not None:
                    out[chiave].add(int(e["fid"]))
    return out


def etichetta(sezione: str, ist) -> str:
    """Nome leggibile dell'istanza: «SS45 — ANAS S.p.A.», «Canale X», ..."""
    if sezione == "rfi":
        parti = [getattr(ist, "linea", "") or "",
                 ("Tipo %s" % ist.tipologia) if getattr(ist, "tipologia", "") else "",
                 getattr(ist, "stazione", "") or ""]
        testo = " — ".join(p for p in parti if p)
    else:
        corso = (getattr(ist, "corso", "") or "").strip()
        ente = (getattr(ist, "ente_nome", "") or "").strip()
        testo = "%s — %s" % (corso, ente) if (corso and ente and sezione == "strade") \
            else corso
    return testo or getattr(ist, "nome_base", "") or "Istanza"


_TRATTINI = "—–‒―−"


def pulisci(testo) -> str:
    """Testo che lo shapefile conserva così com'è: trattini lunghi e virgolette
    tipografiche diventano «-» e «'» (nello shapefile «—» diventava «?», e le
    tratte non risultavano più dell'istanza: scavi persi in tabella). Un «?»
    fra due spazi lasciato da quel problema torna «-»."""
    import unicodedata
    s = str(testo or "")
    for c in _TRATTINI:
        s = s.replace(c, "-")
    s = (s.replace("’", "'").replace("‘", "'")
         .replace("“", '"').replace("”", '"').replace(" ", " "))
    s = re.sub(r"(?<=\s)\?(?=\s)", "-", s)
    try:
        s.encode("cp1252")
    except UnicodeEncodeError:
        s = unicodedata.normalize("NFKD", s).encode("cp1252", "ignore").decode("cp1252")
    return re.sub(r"\s+", " ", s).strip()


def simili(a, b) -> bool:
    """Due nomi della stessa istanza scritti in tempi diversi: uno è l'altro
    con un pezzo in più («Linea X - Tipo D» e «Linea X - Tipo D - Stazione»)."""
    ca, cb = chiave_nome(a), chiave_nome(b)
    return ca != cb and (ca.startswith(cb + " - ") or cb.startswith(ca + " - "))


def chiave_nome(testo) -> str:
    """Chiave per confrontare due nomi di istanza («—», «-» e «?» uguali,
    «Bari-Taranto» = «Bari - Taranto»)."""
    return re.sub(r"\s*-\s*", " - ", pulisci(testo).lower())


def valore(sezione: str, ist) -> str:
    """Testo scritto nel campo degli shape: breve («SP28», «Canale San Marco»,
    «Linea X - Tipo D - Stazione»). Niente «;», che separa due istanze, e
    niente caratteri che lo shapefile non sa scrivere."""
    if sezione == "strade":
        t = (getattr(ist, "corso", "") or "").strip() or etichetta(sezione, ist)
    else:
        t = etichetta(sezione, ist)
    return pulisci(t.replace(";", ","))


def unisci_valori(attuale, nuovo: str) -> str:
    """Aggiunge `nuovo` ai nomi già nel campo (senza doppioni)."""
    voci = [pulisci(v) for v in dividi(attuale)]
    if nuovo and chiave_nome(nuovo) not in {chiave_nome(v) for v in voci}:
        voci.append(pulisci(nuovo))
    return SEP.join(voci)


def togli_valore(attuale, vecchio: str) -> str:
    return SEP.join(pulisci(v) for v in dividi(attuale)
                    if chiave_nome(v) != chiave_nome(vecchio))


def dividi(attuale) -> list:
    if attuale is None or str(attuale) in ("", "NULL"):
        return []
    return [v.strip() for v in str(attuale).split(";") if v.strip()]


def tabella(sezione: str, nome_base: str, chiave: str) -> str:
    t = re.sub(r"[^0-9A-Za-z]+", "_", "%s_%s_%s" % (sezione, nome_base, chiave))
    return t.strip("_").lower()


# --------------------------------------------------------------------------- #
#  Parte QGIS
# --------------------------------------------------------------------------- #
def percorso_file(project) -> str:
    base = project.homePath() or os.path.expanduser("~")
    cart = os.path.join(base, "01_File shp")
    if not os.path.isdir(cart):
        cart = base
    return os.path.join(cart, FILE)


def registro(project, voci=None) -> dict:
    """{nome_base: {sezione, etichetta, valore[, layers vecchi gruppi]}} e,
    sotto la chiave «_viste», gli id dei layer della vista filtrata."""
    if voci is None:
        txt, ok = project.readEntry(PRJ, "gruppi", "")
        try:
            return json.loads(txt) if ok and txt else {}
        except Exception:  # noqa: BLE001
            return {}
    project.writeEntry(PRJ, "gruppi", json.dumps(voci))
    return voci


def _istanze_reg(project) -> dict:
    return {k: v for k, v in registro(project).items() if not k.startswith("_")}


def _id_gruppi(project) -> set:
    """Id dei layer che NON sono principali: viste filtrate e vecchi gruppi."""
    reg = registro(project)
    out = set(reg.get("_viste") or []) | set(reg.get("_etichette") or [])
    for k, v in reg.items():
        if not k.startswith("_") and isinstance(v, dict):
            out |= set((v.get("layers") or {}).values())
    return out


def layer_principale(project, nome):
    """Layer principale per nome (mai una vista filtrata o una vecchia copia)."""
    nostri = _id_gruppi(project)
    for l in project.mapLayersByName(nome):
        if l.id() not in nostri:
            return l
    for l in project.mapLayers().values():
        if l.id() not in nostri and nome.lower() in l.name().lower() \
                and FILE.lower() not in (l.source() or "").lower():
            return l
    return None


def _nome_pulito(nome):
    return re.sub(r"^\s*\d+\s*[_ .-]\s*", "", nome or "").strip() or nome


def _campo(layer, sezione, crea=True):
    """Indice del campo della sezione nel layer (lo crea se manca)."""
    from qgis.core import QgsField
    from qgis.PyQt.QtCore import QVariant
    nome = CAMPI[sezione]
    k = layer.fields().indexOf(nome)
    if k >= 0 or not crea:
        return k
    f = QgsField(nome, QVariant.String, len=254)
    if layer.isEditable():
        layer.addAttribute(f)
    else:
        if not layer.dataProvider().addAttributes([f]):
            raise RuntimeError("non riesco ad aggiungere il campo %s a «%s»"
                               % (nome, layer.name()))
    layer.updateFields()
    k = layer.fields().indexOf(nome)
    if k < 0:
        raise RuntimeError("campo %s non creato in «%s»" % (nome, layer.name()))
    return k


def _scrivi_valori(layer, k, valori: dict):
    """{fid: testo} nel campo k: nel buffer se il layer è in modifica,
    altrimenti direttamente nel file."""
    if not valori:
        return
    if layer.isEditable():
        for fid, t in valori.items():
            layer.changeAttributeValue(fid, k, t)
    else:
        layer.dataProvider().changeAttributeValues({fid: {k: t} for fid, t in valori.items()})
    layer.triggerRepaint()


def fid_con_valore(project, sezione: str, val: str) -> dict:
    """{chiave: {fid}} degli elementi principali con `val` nel campo."""
    out = {}
    for chiave, nome, _t in LAYER:
        out[chiave] = set()
        l = layer_principale(project, nome)
        if l is None:
            continue
        k = l.fields().indexOf(CAMPI[sezione])
        if k < 0:
            continue
        cv = chiave_nome(val)
        for f in l.getFeatures():
            if cv in {chiave_nome(v) for v in dividi(f.attribute(k))}:
                out[chiave].add(f.id())
    return out


def crea_gruppo(project, sezione: str, ist) -> dict:
    """Scrive (da capo) l'istanza nel campo della sezione degli shape
    principali: tolto il nome dove c'era, poi messo sugli elementi delle
    interferenze confermate. Ritorna {chiave: n}."""
    reg = registro(project)
    vecchio = reg.get(ist.nome_base) or {}
    val = valore(sezione, ist)
    fids = fid_istanza(ist)
    conta = {}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is None:
            continue
        k = _campo(l, sezione)
        cambi = {}
        for f in l.getFeatures():
            att = f.attribute(k)
            nuovo = att
            for v in {val, vecchio.get("valore") or val}:
                nuovo = togli_valore(nuovo, v)
            # stessa istanza con un nome vecchio (es. senza stazione): via
            nuovo = SEP.join(x for x in dividi(nuovo) if not simili(x, val))
            if f.id() in fids[chiave]:
                nuovo = unisci_valori(nuovo, val)
            if (nuovo or "") != ("" if att is None or str(att) == "NULL" else str(att)):
                cambi[f.id()] = nuovo or None
        _scrivi_valori(l, k, cambi)
        conta[chiave] = len(fids[chiave])
    for k_ in [k for k, v in reg.items() if not k.startswith("_") and isinstance(v, dict)
               and v.get("sezione") == sezione and simili(v.get("valore"), val)]:
        reg.pop(k_, None)
    reg[ist.nome_base] = {"sezione": sezione, "etichetta": etichetta(sezione, ist),
                          "valore": val}
    registro(project, reg)
    return conta


def layer_gruppo(project, nome_base: str):
    """Compatibilità: {chiave: True} se l'istanza è scritta negli shape."""
    v = _istanze_reg(project).get(nome_base)
    if not v or not v.get("valore"):
        return None
    f = fid_con_valore(project, v["sezione"], v["valore"])
    return {k: True for k, s in f.items() if s} or None


def gruppi_della_sezione(project, sezione: str) -> list:
    """[(nome_base, etichetta)] delle istanze scritte negli shape."""
    return [(k, v.get("valore") or v.get("etichetta") or k)
            for k, v in sorted(_istanze_reg(project).items())
            if v.get("sezione") == sezione and v.get("valore")]


def aggiungi_selezione(project, nome_base: str) -> dict:
    """Scrive l'istanza sugli elementi selezionati nei layer principali.
    Ritorna {chiave: n aggiunti} (quelli che l'avevano già non contano)."""
    v = _istanze_reg(project).get(nome_base) or {}
    if not v.get("valore"):
        return {}
    out = {}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is None or not l.selectedFeatureCount():
            continue
        k = _campo(l, v["sezione"])
        cambi = {}
        for f in l.selectedFeatures():
            nuovo = unisci_valori(f.attribute(k), v["valore"])
            if nuovo != SEP.join(dividi(f.attribute(k))):
                cambi[f.id()] = nuovo
        _scrivi_valori(l, k, cambi)
        out[chiave] = len(cambi)
    return out


def sposta_selezione(project, sezione: str, val: str = None) -> dict:
    """Elementi selezionati in mappa nei layer principali: con `val` passano
    a quell'istanza (tolti dalle altre istanze della stessa sezione), senza
    `val` escono da tutte le istanze della sezione. Ritorna {chiave: n}."""
    from qgis.core import QgsFeatureRequest
    # selezione sui layer principali e sulle copie della vista (campo ftth_orig)
    scelti = {"tratte": set(), "pozzetti": set(), "armadi": set()}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is not None:
            scelti[chiave] |= set(l.selectedFeatureIds())
    reg = registro(project)
    for lid, chiave in (reg.get("_viste_chiave") or {}).items():
        c = project.mapLayer(lid)
        if c is None or not c.selectedFeatureCount():
            continue
        k_o = c.fields().indexOf(CAMPO_ORIG)
        for f in c.selectedFeatures():
            try:
                scelti[chiave].add(int(f.attribute(k_o)))
            except (TypeError, ValueError):
                pass
    out = {}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is None or not scelti[chiave]:
            continue
        if val is None and l.fields().indexOf(CAMPI[sezione]) < 0:
            continue
        k = _campo(l, sezione)
        cambi = {}
        for f in l.getFeatures(QgsFeatureRequest().setFilterFids(sorted(scelti[chiave]))):
            prima = SEP.join(dividi(f.attribute(k)))
            dopo = pulisci(val) if val else ""
            if dopo != prima:
                cambi[f.id()] = dopo or None
        _scrivi_valori(l, k, cambi)
        out[chiave] = len(cambi)
    return out


def _fid_scavo(e) -> set:
    grezzi = [e.get("fid")] if e.get("fid") is not None else \
        [x for x in (e.get("chiave_el") or "").split("|")[-1].split(",") if x]
    try:
        return {int(x) for x in grezzi}
    except (TypeError, ValueError):
        return set()


def _ristretta(i, tieni: dict):
    """Copia dell'interferenza con i soli elementi `tieni` ({chiave: {fid}}):
    metri e pozzetti rifatti da quelli rimasti."""
    import copy
    j = copy.copy(i)
    j.tratte_fid = [x for x in (getattr(i, "tratte_fid", None) or [])
                    if x is not None and int(x) in tieni["tratte"]]
    metri, pozz, nuovi = {}, {}, []
    for e in getattr(i, "elementi", None) or []:
        t = e.get("tipo")
        if t == "scavo":
            if not (_fid_scavo(e) & tieni["tratte"]):
                continue
            if e.get("tecnica"):
                metri[e["tecnica"]] = metri.get(e["tecnica"], 0) + (e.get("metri") or 0)
        elif t in ("pozzetto", "pozzetto_fuori", "armadio", "armadio_fuori"):
            chiave = "pozzetti" if t.startswith("pozzetto") else "armadi"
            if e.get("fid") is None or int(e["fid"]) not in tieni[chiave]:
                continue
            if t == "pozzetto" and e.get("dim"):
                pozz[e["dim"]] = pozz.get(e["dim"], 0) + 1
        nuovi.append(e)
    j.elementi = nuovi
    if hasattr(i, "metri"):
        j.metri = metri
    if hasattr(i, "pozzetti"):
        j.pozzetti = pozz
    return j


def togli_rimossi(project, istanze, log=None) -> int:
    """Alla generazione: dalle istanze escono gli elementi a cui l'utente ha
    tolto l'istanza in mappa («Togli dall'istanza» o «Sposta in» un'altra).
    Interferenza senza più elementi -> esce dall'istanza; in parte -> via gli
    scavi (con i loro metri) e i pozzetti/armadi tolti. Le interferenze
    della ricerca non si toccano (si lavora su copie). Ritorna quanti
    elementi sono usciti."""
    import copy
    import types
    log = log or (lambda _m: None)
    reg = _istanze_reg(project)
    tot = 0
    for ist in istanze:
        v = reg.get(ist.nome_base) or {}
        if not v.get("valore"):
            continue
        sez = v["sezione"]
        layers = [layer_principale(project, n) for _c, n, _t in LAYER]
        if not any(l is not None and l.fields().indexOf(CAMPI[sez]) >= 0 for l in layers):
            continue
        ammessi = fid_con_valore(project, sez, v["valore"])
        sostituzioni, uscite, parti = {}, [], []
        for i in list(ist.interferenze):
            f = fid_istanza(types.SimpleNamespace(interferenze=[i]))
            via = {k: f[k] - ammessi.get(k, set()) for k in f}
            if not any(via.values()):
                continue
            if all(f[k] <= via[k] for k in f):
                uscite.append(i)
                tot += sum(len(x) for x in via.values())
                continue
            j = copy.copy(i)
            j.metri = dict(getattr(i, "metri", {}) or {})
            j.pozzetti = dict(getattr(i, "pozzetti", {}) or {})
            j.tratte_fid = [x for x in (getattr(i, "tratte_fid", None) or [])
                            if x is None or int(x) not in via["tratte"]]
            nuovi = []
            for e in getattr(i, "elementi", None) or []:
                t = e.get("tipo")
                if t == "scavo":
                    grezzi = [e.get("fid")] if e.get("fid") is not None else \
                        [x for x in (e.get("chiave_el") or "").split("|")[-1].split(",") if x]
                    try:
                        fids = {int(x) for x in grezzi}
                    except (TypeError, ValueError):
                        fids = set()
                    if fids and fids <= via["tratte"]:
                        tec, m = e.get("tecnica"), e.get("metri") or 0
                        if tec in j.metri:
                            j.metri[tec] = max(0, j.metri[tec] - m)
                            if not j.metri[tec]:
                                j.metri.pop(tec)
                        continue
                elif t in ("pozzetto", "pozzetto_fuori", "armadio", "armadio_fuori") and \
                        e.get("fid") is not None:
                    chiave = "pozzetti" if t.startswith("pozzetto") else "armadi"
                    if int(e["fid"]) in via[chiave]:
                        dim = e.get("dim")
                        if t == "pozzetto" and dim and j.pozzetti.get(dim):
                            j.pozzetti[dim] -= 1
                            if not j.pozzetti[dim]:
                                j.pozzetti.pop(dim)
                        continue
                nuovi.append(e)
            j.elementi = nuovi
            sostituzioni[id(i)] = j
            tot += sum(len(x) for x in via.values())
            parti.append("n. %s" % getattr(i, "id", "?"))

        def _rifai(lst):
            return [sostituzioni.get(id(x), x) for x in lst
                    if not any(x is u for u in uscite)]
        ist.interferenze = _rifai(ist.interferenze)
        if getattr(ist, "interferenze_pl", None):
            ist.interferenze_pl = _rifai(ist.interferenze_pl)
        if getattr(ist, "tavole", None):
            ist.tavole = [t for t in (_rifai(t) for t in ist.tavole) if t]
        if uscite or parti:
            log("%s: tolti in mappa dall'istanza — %s%s." % (
                ist.nome_base,
                ("interferenze uscite: %s" % ", ".join("n. %s" % getattr(x, "id", "?")
                                                       for x in uscite)) if uscite else "",
                ("; in parte: %s" % ", ".join(parti)) if parti else ""))
    return tot


# ------------------------------------------------------------ vista filtrata
def gruppo_sezione(radice, sezione: str):
    """Gruppo dell'ente nel pannello: «Altri enti > Strade», «Altri enti >
    RFI», … (prima: «Istanze > Strade»)."""
    try:
        from . import ftth_pannello as PN
    except ImportError:  # pragma: no cover
        import ftth_pannello as PN
    if sezione == "comunale":
        return PN.gruppo(radice, PN.COMUNALE)
    return PN.gruppo(radice, PN.ALTRI, sezione)


def togli_vista(project):
    """Toglie la vista filtrata e riaccende i layer principali."""
    reg = registro(project)
    for lid in reg.get("_viste") or []:
        if project.mapLayer(lid) is not None:
            project.removeMapLayer(lid)
    reg["_viste"] = []
    reg["_viste_chiave"] = {}
    registro(project, reg)
    radice = project.layerTreeRoot()
    for g in list(radice.findGroups(True)):
        if g.name() in (GRUPPO_VISTA, GRUPPO_VISTA_COMUNALE):
            g.parent().removeChildNode(g)
    for _c, nome, _t in LAYER:
        l = layer_principale(project, nome)
        nodo = radice.findLayer(l.id()) if l is not None else None
        if nodo is not None:
            nodo.setItemVisibilityChecked(True)


def mostra_solo(project, sezione: str, val: str) -> dict:
    """Spegne i layer principali e mostra solo gli elementi con `val` nel
    campo della sezione (cloni dei layer principali con un filtro: i layer
    principali restano senza filtri). Ritorna {chiave: n}."""
    togli_vista(project)
    reg = registro(project)
    radice = project.layerTreeRoot()
    g_sez = gruppo_sezione(radice, sezione)
    g_v = g_sez.insertGroup(0, GRUPPO_VISTA)
    g_v.setExpanded(False)      # il pannello Layer non si apre a ogni clic
    campo = CAMPI[sezione]
    esc = val.replace("'", "''")
    filtro = ("\"%s\" = '%s' OR \"%s\" LIKE '%s;%%' OR \"%s\" LIKE '%%; %s' OR "
              "\"%s\" LIKE '%%; %s;%%'" % (campo, esc, campo, esc, campo, esc, campo, esc))
    viste, conta = [], {}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is None or l.fields().indexOf(campo) < 0:
            continue
        c = l.clone()
        c.setName("%s — %s" % (_nome_pulito(l.name()), val))
        c.setSubsetString(filtro)
        project.addMapLayer(c, False)
        g_v.insertLayer(0, c)
        viste.append(c.id())
        conta[chiave] = c.featureCount()
        nodo = radice.findLayer(l.id())
        if nodo is not None:
            nodo.setItemVisibilityChecked(False)
    reg["_viste"] = viste
    registro(project, reg)
    return conta


def tutti_i_fid(project) -> dict:
    """{chiave: {fid}} di tutti gli elementi dei layer principali."""
    from qgis.core import QgsFeatureRequest
    out = {}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        out[chiave] = set() if l is None else {
            f.id() for f in l.getFeatures(QgsFeatureRequest().setNoAttributes()
                                          .setFlags(QgsFeatureRequest.NoGeometry))}
    return out


def mostra_fid(project, sezione: str, fids: dict, nome: str) -> dict:
    """Vista con solo gli elementi `fids` ({chiave: {fid}}): i layer
    principali si spengono e al loro posto ci sono copie in memoria dei soli
    elementi visibili, con lo stesso stile (i layer principali non si toccano).
    Ritorna {chiave: n}."""
    from qgis.core import QgsFeatureRequest, QgsMapLayerStyle
    togli_vista(project)
    reg = registro(project)
    radice = project.layerTreeRoot()
    g_sez = gruppo_sezione(radice, sezione)
    g_v = g_sez.insertGroup(0, GRUPPO_VISTA_COMUNALE if sezione == "comunale" else GRUPPO_VISTA)
    g_v.setExpanded(False)      # il pannello Layer non si apre a ogni clic
    # la vista si vede anche se l'utente aveva spento il gruppo «Istanze»
    # (prima: «Solo suolo comunale» spegneva tutto)
    g_v.setItemVisibilityCheckedParentRecursive(True)
    viste, conta = [], {}
    for chiave, nome_l, _t in LAYER:
        l = layer_principale(project, nome_l)
        if l is None:
            continue
        ids = sorted(fids.get(chiave) or [])
        c = l.materialize(QgsFeatureRequest().setFilterFids(ids))
        c.setName("%s — %s" % (_nome_pulito(l.name()), nome))
        # ogni copia ricorda l'elemento vero (campo ftth_orig): la selezione
        # fatta sulla vista vale per «Sposta in» e «Togli»
        from qgis.core import QgsField
        from qgis.PyQt.QtCore import QVariant
        c.dataProvider().addAttributes([QgsField(CAMPO_ORIG, QVariant.LongLong)])
        c.updateFields()
        k_o = c.fields().indexOf(CAMPO_ORIG)
        # stesso ordine con cui materialize() ha letto gli elementi
        origini = [f.id() for f in l.getFeatures(
            QgsFeatureRequest().setFilterFids(ids).setNoAttributes()
            .setFlags(QgsFeatureRequest.NoGeometry))]
        c.dataProvider().changeAttributeValues(
            {g.id(): {k_o: o} for g, o in zip(c.getFeatures(), origini)})
        reg.setdefault("_viste_chiave", {})[c.id()] = chiave
        stile = QgsMapLayerStyle()
        stile.readFromLayer(l)
        stile.writeToLayer(c)
        project.addMapLayer(c, False)
        g_v.insertLayer(0, c)
        viste.append(c.id())
        conta[chiave] = len(ids)
        nodo = radice.findLayer(l.id())
        if nodo is not None:
            nodo.setItemVisibilityChecked(False)
    reg["_viste"] = viste
    registro(project, reg)
    return conta


def istanze_nel_campo(project, sezione: str) -> dict:
    """{nome istanza: {chiave: {fid}}} letto dal campo della sezione negli
    shape principali, più "" = elementi senza istanza (suolo comunale)."""
    from qgis.core import QgsFeatureRequest
    campo = CAMPI[sezione]
    out = {"": {"tratte": set(), "pozzetti": set(), "armadi": set()}}
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is None:
            continue
        k = l.fields().indexOf(campo)
        req = QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)
        for f in l.getFeatures(req):
            # stesso nome scritto in modi diversi («—», «-», «?»): una voce sola
            voci = list(dict.fromkeys(pulisci(v) for v in dividi(f.attribute(k)))) \
                if k >= 0 else []
            if not voci:
                out[""][chiave].add(f.id())
            for v in voci:
                out.setdefault(v, {"tratte": set(), "pozzetti": set(), "armadi": set()})
                out[v][chiave].add(f.id())
    return out


def estensione_vista(project):
    """Estensione (nel sistema del progetto) dei layer della vista."""
    from qgis.core import QgsCoordinateTransform, QgsRectangle
    r = None
    for lid in registro(project).get("_viste") or []:
        l = project.mapLayer(lid)
        if l is None or not l.featureCount():
            continue
        e = QgsCoordinateTransform(l.crs(), project.crs(), project).transformBoundingBox(
            l.extent())
        if r is None:
            r = QgsRectangle(e)
        else:
            r.combineExtentWith(e)
    return r


def rete_per_pl(project, ist, copia_filtrata, prefisso):
    """Copie (infra, pozz, arm) per la PL dagli elementi con il nome
    dell'istanza nel campo, o None se l'istanza non è scritta negli shape.
    `copia_filtrata` è quella dei layout (stile ed etichette dell'originale)."""
    v = _istanze_reg(project).get(ist.nome_base)
    if not v or not v.get("valore"):
        return None
    fids = fid_con_valore(project, v["sezione"], v["valore"])
    if not fids.get("tratte"):
        return None
    out = []
    for chiave, nome, _t in LAYER:
        orig = layer_principale(project, nome)
        if orig is None:
            out.append(None)
            continue
        leg = _nome_pulito(orig.name()).replace("_", " ")
        out.append(copia_filtrata(project, orig, sorted(fids[chiave]), prefisso,
                                  nome_legenda=leg))
    return tuple(out)


def _ListaOcchi():
    """Pannello delle istanze: una riga per istanza (e il «Suolo comunale»)
    con un pulsante a occhio che si preme per accendere/spegnere e «Solo
    questa». Emette `cambiato` quando cambia un occhio."""
    from qgis.PyQt.QtCore import pyqtSignal, Qt
    from qgis.PyQt.QtGui import QIcon
    from qgis.PyQt.QtWidgets import (QFrame, QHBoxLayout, QLabel, QPushButton, QScrollArea,
                                     QToolButton, QVBoxLayout, QWidget)
    try:
        from qgis.core import QgsApplication
        ic_on = QgsApplication.getThemeIcon("/mActionShowAllLayers.svg")
        ic_off = QgsApplication.getThemeIcon("/mActionHideAllLayers.svg")
    except Exception:  # noqa: BLE001
        ic_on = ic_off = None

    class Lista(QScrollArea):
        cambiato = pyqtSignal()

        def __init__(self):
            super().__init__()
            self.setWidgetResizable(True)
            self.setMaximumHeight(190)
            self.setMinimumHeight(60)
            self.setFrameShape(QFrame.StyledPanel)
            self._w = QWidget()
            self._v = QVBoxLayout(self._w)
            self._v.setContentsMargins(4, 4, 4, 4)
            self._v.setSpacing(3)
            self.setWidget(self._w)
            self._occhi = {}          # nome -> QToolButton
            self._vuoto()

        def _vuoto(self):
            lb = QLabel("Nessuna istanza ancora confermata: premi «Conferma le interferenze "
                        "spuntate» e qui compaiono gli occhi.")
            lb.setWordWrap(True)
            lb.setStyleSheet("color: gray;")
            self._v.addWidget(lb)
            self._v.addStretch()

        def _pulisci(self):
            while self._v.count():
                it = self._v.takeAt(0)
                if it.widget() is not None:
                    it.widget().deleteLater()
            self._occhi = {}

        def _stile(self, b):
            on = b.isChecked()
            # occhio aperto / barrato sempre visibile (le icone del tema
            # mancavano in alcune installazioni)
            b.setIcon(QIcon())
            b.setText("👁" if on else "🚫")
            b.setToolTip("Visibile in mappa: premi per nasconderla" if on
                         else "Nascosta: premi per vederla in mappa")
            b.setStyleSheet("QToolButton{border:1px solid %s;border-radius:4px;"
                            "background:%s;padding:3px;}" % (
                                ("#2e7d32", "#c8e6c9") if on else ("#9e9e9e", "#eeeeee")))
            lb = b.property("etichetta")
            if lb is not None:
                lb.setStyleSheet("" if on else "color: gray;")

        def imposta(self, voci):
            """voci = [(nome, testo)]; nome "" = suolo comunale. Tutti accesi."""
            self._pulisci()
            if not voci:
                self._vuoto()
                return
            for nome, testo in voci:
                riga = QWidget()
                h = QHBoxLayout(riga)
                h.setContentsMargins(0, 0, 0, 0)
                b = QToolButton()
                b.setCheckable(True)
                b.setChecked(True)
                b.setAutoRaise(False)
                b.setMinimumSize(30, 26)
                lb = QLabel(testo)
                lb.setTextInteractionFlags(Qt.NoTextInteraction)
                b.setProperty("etichetta", lb)
                b.toggled.connect(lambda _on, bb=b: (self._stile(bb), self.cambiato.emit()))
                # anche il testo si preme
                lb.mousePressEvent = lambda _e, bb=b: bb.toggle()
                solo = QPushButton("Solo questa")
                solo.setToolTip("In mappa resta solo questa (gli altri occhi si spengono).")
                solo.clicked.connect(lambda _c=False, n=nome: self.solo(n))
                h.addWidget(b)
                h.addWidget(lb, 1)
                h.addWidget(solo)
                self._v.addWidget(riga)
                self._occhi[nome] = b
                self._stile(b)
            self._v.addStretch()

        def conta(self):
            return len(self._occhi)

        def accese(self):
            return {n for n, b in self._occhi.items() if b.isChecked()}

        def nomi(self):
            return set(self._occhi)

        def accendi(self, nomi):
            """Accende solo `nomi` (senza segnale per ogni occhio), poi un segnale."""
            for n, b in self._occhi.items():
                b.blockSignals(True)
                b.setChecked(n in nomi)
                b.blockSignals(False)
                self._stile(b)
            self.cambiato.emit()

        def solo(self, nome):
            self.accendi({nome})

        def premi(self, nome):
            """Come un clic sull'occhio (per le prove)."""
            self._occhi[nome].toggle()

    return Lista()


def riquadro(dlg, sezione: str, fornisci_istanze):
    """Riquadro comune a tutte le schede istanze, subito sotto le
    interferenze: «Conferma le interferenze spuntate» scrive il nome
    dell'istanza nel campo della sezione degli shape principali; il pannello
    sotto ha un occhio per ogni istanza (letta dal campo) e uno per il
    «Suolo comunale» (elementi senza istanza della sezione): spento l'occhio,
    in mappa spariscono i suoi elementi. `fornisci_istanze()` ritorna le
    istanze dalle righe spuntate (o None dopo aver avvisato l'utente)."""
    from qgis.PyQt.QtWidgets import QHBoxLayout, QMessageBox, QPushButton, QVBoxLayout
    campo = CAMPI[sezione]
    gb = dlg._gruppo("Conferma e vista per istanza (campo %s negli shape)" % campo,
                     compresso=False)
    v = QVBoxLayout(gb)
    v.addWidget(dlg._desc(
        "«Conferma le interferenze spuntate» scrive il nome dell'istanza (es. SP28, Canale "
        "San Marco) nel campo %s di 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO: si "
        "lavora sempre sugli stessi shape. Poi con l'occhio accendi o spegni in mappa ogni "
        "istanza e il «Suolo comunale» (il resto della rete)." % campo))
    r1 = QHBoxLayout()
    b_crea = QPushButton("Conferma le interferenze spuntate")
    b_crea.setProperty("primario", True)
    b_crea.setToolTip("Scrive l'istanza nel campo %s degli elementi delle interferenze "
                      "spuntate (modifica gli shape del progetto)." % campo)
    r1.addWidget(b_crea)
    r1.addStretch()
    v.addLayout(r1)
    lst = _ListaOcchi()
    v.addWidget(lst)
    r2 = QHBoxLayout()
    b_tutto = QPushButton("Mostra tutto")
    b_tutto.setToolTip("Riaccende tutti gli occhi: torna la mappa normale.")
    r2.addWidget(b_tutto)
    r2.addStretch()
    v.addLayout(r2)
    # correzioni in mappa: seleziona scavi, pozzetti o armadi e spostali
    from qgis.PyQt.QtWidgets import QComboBox, QLabel
    r3 = QHBoxLayout()
    r3.addWidget(QLabel("Selezione in mappa →"))
    cb_dest = QComboBox()
    cb_dest.setProperty("non_memorizzare", True)
    cb_dest.setMinimumContentsLength(16)
    cb_dest.setToolTip("L'istanza in cui spostare gli elementi selezionati in mappa (strada, "
                       "linea ferroviaria, corso d'acqua, area vincolata, parco).")
    r3.addWidget(cb_dest, 1)
    b_agg = QPushButton("Sposta in questa istanza")
    b_agg.setToolTip("Seleziona in mappa tratte, pozzetti o armadi (anche nella vista) e "
                     "premi: passano all'istanza scelta (campo %s aggiornato, tolti dalle "
                     "altre istanze di questa scheda). Alla generazione l'interferenza si "
                     "aggiorna." % campo)
    r3.addWidget(b_agg)
    b_togli = QPushButton("Togli dall'istanza")
    b_togli.setToolTip("Gli elementi selezionati in mappa escono da ogni istanza di questa "
                       "scheda (campo %s svuotato): alla generazione non si contano più." % campo)
    r3.addWidget(b_togli)
    v.addLayout(r3)
    stato = {"per": {}}

    def aggiorna():
        """Elenco delle istanze dal campo degli shape (anche a progetto riaperto)."""
        try:
            per = istanze_nel_campo(dlg.project, sezione)
        except Exception:  # noqa: BLE001
            per = {"": {"tratte": set(), "pozzetti": set(), "armadi": set()}}
        stato["per"] = per
        voci = []
        for nome in sorted(k for k in per if k):
            d = per[nome]
            voci.append((nome, "<b>%s</b> — %d tratte, %d pozzetti, %d armadi" % (
                nome, len(d["tratte"]), len(d["pozzetti"]), len(d["armadi"]))))
        if voci:
            d = per[""]
            voci.append(("", "<b>Suolo comunale</b> — il resto della rete (%d tratte)"
                         % len(d["tratte"])))
        lst.blockSignals(True)
        lst.imposta(voci)
        lst.blockSignals(False)
        # istanze in cui spostare: quelle confermate (registro) e quelle nel campo
        nomi = sorted({pulisci(x.get("valore")) for x in _istanze_reg(dlg.project).values()
                       if x.get("sezione") == sezione and x.get("valore")}
                      | {k for k in per if k})
        prima = cb_dest.currentText()
        cb_dest.clear()
        cb_dest.addItems(nomi)
        if prima in nomi:
            cb_dest.setCurrentText(prima)
        b_agg.setEnabled(bool(nomi))
        b_togli.setEnabled(len(per) > 1)

    def applica(*_a):
        accese = lst.accese()
        try:
            if lst.conta() == 0 or len(accese) == lst.conta():
                togli_vista(dlg.project)
            else:
                vis = {"tratte": set(), "pozzetti": set(), "armadi": set()}
                for nome, d in stato["per"].items():
                    if nome in accese:
                        for k in vis:
                            vis[k] |= d[k]
                if not accese:
                    nome_v = "vista vuota"
                elif len(accese) == 1:
                    nome_v = "vista " + (next(iter(accese)) or "suolo comunale")
                else:
                    nome_v = "vista %d su %d" % (len(accese), lst.conta())
                mostra_fid(dlg.project, sezione, vis, nome_v)
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(dlg, "Vista per istanza",
                                "Non riesco a cambiare la vista in mappa:\n%s" % e)
            return
        try:
            dlg.iface.mapCanvas().refresh()
        except Exception:  # noqa: BLE001
            pass

    def crea():
        istanze = fornisci_istanze()
        if not istanze:
            return
        msg = ("Scrivo nel campo %s di 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO "
               "(modifica gli shape del progetto):\n%s\n\nSe un'istanza c'era già si rifà "
               "da capo: gli elementi aggiunti a mano a quell'istanza si perdono."
               % (campo, "\n".join("  • %s" % valore(sezione, i) for i in istanze)))
        if QMessageBox.question(dlg, "Conferma le interferenze", msg + "\n\nProcedo?",
                                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        righe, ko = [], []
        togli_vista(dlg.project)
        for ist in istanze:
            try:
                c = crea_gruppo(dlg.project, sezione, ist)
                righe.append("%s: %d tratte, %d pozzetti, %d armadi" % (
                    valore(sezione, ist), c.get("tratte", 0), c.get("pozzetti", 0),
                    c.get("armadi", 0)))
            except Exception as e:  # noqa: BLE001
                ko.append("%s: %s" % (valore(sezione, ist), e))
        aggiorna()
        testo = "\n".join(righe)
        if ko:
            testo += "\n\nNON riusciti:\n" + "\n".join(ko)
        testo += ("\n\nCampo %s compilato: con gli occhi qui sotto accendi o spegni le "
                  "istanze in mappa. Salva il progetto." % campo)
        (QMessageBox.warning if ko else QMessageBox.information)(
            dlg, "Interferenze confermate", testo)

    def tutto():
        lst.accendi(lst.nomi())

    def _dopo_modifica(n, titolo, testo):
        tot = sum(n.values())
        if not tot:
            QMessageBox.information(
                dlg, titolo,
                "Seleziona in mappa tratte, pozzetti o armadi (nei layer principali o nella "
                "vista). Quelli che sono già così non cambiano.")
            return
        accese = lst.accese()
        spente = lst.nomi() - accese
        aggiorna()
        if spente:                  # la vista si rifà con gli stessi occhi
            lst.accendi(lst.nomi() - spente)
        QMessageBox.information(
            dlg, titolo, testo % (n.get("tratte", 0), n.get("pozzetti", 0),
                                  n.get("armadi", 0)))

    def sposta():
        nome = cb_dest.currentText().strip()
        if not nome:
            return
        if not any(x.get("sezione") == sezione and chiave_nome(x.get("valore")) == chiave_nome(nome)
                   for x in _istanze_reg(dlg.project).values()):
            reg = registro(dlg.project)
            reg["%s_%s" % (sezione, nome)] = {"sezione": sezione, "etichetta": nome,
                                              "valore": nome}
            registro(dlg.project, reg)
        n = sposta_selezione(dlg.project, sezione, nome)
        _dopo_modifica(n, "Sposta in «%s»" % nome,
                       "Spostati in «" + nome + "»: %d tratte, %d pozzetti, %d armadi.\n\n"
                       "Alla generazione si contano come quelli trovati dalla ricerca (solo "
                       "i metri dentro fascia, sede o area, con la progressiva km); quelli "
                       "tutto fuori contano 0 m e restano solo in tavola.")

    def togli():
        n = sposta_selezione(dlg.project, sezione, None)
        _dopo_modifica(n, "Togli dall'istanza",
                       "Tolti dall'istanza: %d tratte, %d pozzetti, %d armadi.\n\nAlla "
                       "generazione non si contano più: l'interferenza perde quegli scavi, "
                       "pozzetti e armadi (o esce dall'istanza se non le resta niente).")

    b_crea.clicked.connect(crea)
    b_tutto.clicked.connect(tutto)
    b_agg.clicked.connect(sposta)
    b_togli.clicked.connect(togli)
    lst.cambiato.connect(applica)
    aggiorna()
    gb._aggiorna_vista = aggiorna          # per le prove e per chi conferma da codice
    gb._lista_vista = lst
    try:
        dlg.project.readProject.connect(lambda *_: aggiorna())
    except Exception:  # noqa: BLE001
        pass
    return gb


def origini_manuali(project, ist) -> tuple:
    """({chiave: {fid principali}} degli elementi con il nome dell'istanza che
    non vengono dalle interferenze trovate (aggiunti a mano), 0)."""
    v = _istanze_reg(project).get(ist.nome_base)
    out = {"tratte": set(), "pozzetti": set(), "armadi": set()}
    if not v or not v.get("valore"):
        return out, 0
    con = fid_con_valore(project, v["sezione"], v["valore"])
    attesi = fid_istanza(ist)
    for k in out:
        out[k] = con.get(k, set()) - attesi[k]
    return out, 0


def elementi_in_piu(project, ist) -> int:
    """Quanti elementi sono stati aggiunti a mano all'istanza."""
    return sum(len(v) for v in origini_manuali(project, ist)[0].values())


def interferenze_per_elementi(tutte, fids: dict) -> tuple:
    """Interferenze della ricerca che contengono gli elementi `fids`
    ({chiave: {fid principali}}) e, a parte, i fid che non sono in nessuna
    interferenza (fuori da fasce, sedi e aree: 0 m)."""
    import types
    trovate = []
    usati = {k: set() for k in fids}
    for i in tutte or []:
        f = fid_istanza(types.SimpleNamespace(interferenze=[i]))
        if any(f[k] & fids[k] for k in fids):
            trovate.append(i)
            for k in fids:
                usati[k] |= f[k] & fids[k]
    return trovate, {k: fids[k] - usati[k] for k in fids}


NOTA_DAL_GRUPPO = "aggiunta all'istanza dagli elementi aggiunti a mano"


def _aggiungi_alla_tavola(ist, i):
    """Mette l'interferenza nella tavola piu' vicina (ist.tavole)."""
    tav = getattr(ist, "tavole", None)
    if not tav:
        return

    def d(t):
        return min((x.lon - i.lon) ** 2 + (x.lat - i.lat) ** 2 for x in t) if t else 1e18
    min(tav, key=d).append(i)


def _completa_gruppo(project, ist, i):
    """Scrive l'istanza anche sugli altri elementi dell'interferenza (es.
    l'altro pezzo dello stesso scavo), cosi' la PL li disegna."""
    from qgis.core import QgsFeatureRequest
    import types
    v = _istanze_reg(project).get(ist.nome_base) or {}
    if not v.get("valore"):
        return
    f = fid_istanza(types.SimpleNamespace(interferenze=[i]))
    for chiave, nome, _t in LAYER:
        l = layer_principale(project, nome)
        if l is None or not f[chiave]:
            continue
        k = _campo(l, v["sezione"])
        cambi = {}
        for g in l.getFeatures(QgsFeatureRequest().setFilterFids(sorted(f[chiave]))):
            nuovo = unisci_valori(g.attribute(k), v["valore"])
            if nuovo != SEP.join(dividi(g.attribute(k))):
                cambi[g.id()] = nuovo
        _scrivi_valori(l, k, cambi)


def aggiungi_da_ricerca(project, istanze, tutte, stessa_istanza=None, log=None) -> int:
    """Elementi aggiunti a mano a un'istanza: si contano ALLO STESSO MODO delle
    interferenze trovate, cioe' con l'interferenza che la ricerca ha gia'
    calcolato per loro (taglio su fascia/sede/area, metri, km, sede o fascia),
    anche se la sua riga non era spuntata. Gli elementi fuori da tutte le zone
    contano 0 m e restano solo in tavola. Un'interferenza gia' in un'altra
    istanza o di un'altra istanza (`stessa_istanza(i, ist)` falso) non si
    aggiunge. Ritorna quante interferenze ha aggiunto."""
    import copy
    import types
    log = log or (lambda _m: None)
    # prima escono gli elementi tolti o spostati altrove in mappa
    try:
        togli_rimossi(project, istanze, log)
    except Exception as e:  # noqa: BLE001
        log("Elementi tolti in mappa non considerati: %s" % e)
    n_tot = 0
    for ist in istanze:
        fids, senza = origini_manuali(project, ist)
        if not any(fids.values()):
            continue
        trovate, fuori = interferenze_per_elementi(tutte, fids)
        ids = {getattr(x, "id", None) for x in ist.interferenze}
        aggiunte, altre = [], []
        for i in trovate:
            if any(x is i for x in ist.interferenze) or getattr(i, "id", None) in ids:
                continue
            fi = fid_istanza(types.SimpleNamespace(interferenze=[i]))
            mie = {k: fi[k] & fids[k] for k in fi}
            # dell'interferenza entrano solo gli elementi spostati qui (il
            # resto, se c'è, resta all'istanza di prima)
            j = _ristretta(i, mie) if any(fi[k] - mie[k] for k in fi) else copy.copy(i)
            if stessa_istanza and not stessa_istanza(i, ist):
                # spostata in mappa da un'altra istanza: prende il nome di questa
                for att in ("corso", "linea"):
                    if hasattr(j, att) and getattr(ist, att, None):
                        setattr(j, att, getattr(ist, att))
                altre.append("n. %s" % i.id)
            j.includi = True
            j.note = list(getattr(i, "note", None) or []) + [NOTA_DAL_GRUPPO]
            ist.interferenze.append(j)
            if getattr(ist, "interferenze_pl", None):
                ist.interferenze_pl.append(j)
            _aggiungi_alla_tavola(ist, j)
            try:
                _completa_gruppo(project, ist, j)
            except Exception:  # noqa: BLE001
                pass
            aggiunte.append(j)
        n_tot += len(aggiunte)
        n_fuori = sum(len(v) for v in fuori.values())
        parti = []
        if aggiunte:
            parti.append("interferenze aggiunte dagli elementi aggiunti a mano: %s" % ", ".join(
                "n. %s (%s)" % (j.id, ", ".join("%s %d m" % (t, m) for t, m in j.metri.items()
                                               if m) or "senza scavi") for j in aggiunte))
        if altre:
            parti.append("spostate in mappa da un'altra istanza: %s" % ", ".join(altre))
        if n_fuori:
            parti.append("%d elementi fuori da fasce, sedi e aree: 0 m, solo in tavola"
                         % n_fuori)
        if parti:
            log("%s: %s." % (ist.nome_base, "; ".join(parti)))
    return n_tot
