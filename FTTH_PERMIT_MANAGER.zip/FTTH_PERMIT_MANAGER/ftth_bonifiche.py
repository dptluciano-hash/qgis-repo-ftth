# -*- coding: utf-8 -*-
"""Siti contaminati e procedimenti di bonifica (ISPRA/SNPA).

Perche' sta nello screening di un permesso FTTH: scavare dentro un'area
con un procedimento di bonifica aperto non e' un lavoro ordinario. La
movimentazione del terreno ricade nel DLgs 152/2006 Titolo V, e l'ARPA
competente entra nel procedimento. Caso estremo il SIN (Sito di
Interesse Nazionale): li' autorizza il Ministero, non il Comune.

Nota di merito: ARPA non rilascia il permesso di scavo, e' organo tecnico
di controllo. Per questo NON compare fra gli enti del registro: qui serve
a dire CHI va coinvolto se il tracciato tocca un sito, non a produrre
un'istanza.

Fonte: FeatureServer ISPRA (banca dati MOSAICO), 42 SIN e ~17.700
procedimenti nazionali. Le codifiche sono quelle pubblicate dal servizio.
"""

BASE = ("https://sinacloud.isprambiente.it/arcgisgeo/rest/services/"
        "SitiContaminati_UtenteGenerico/FeatureServer")
LAYER_PROCEDIMENTI = 0
LAYER_SIN = 1

# stati che indicano contaminazione accertata o possibile: sono quelli per
# cui lo scavo va concordato. Gli stati "non contaminato" e "bonifica
# conclusa e certificata" si segnalano a parte, senza allarmare.
STATI_CHIUSI = {"200", "210", "220", "230", "240", "250", "260", "270", "280", "300"}

NOMI_SIN = {
"1": "NO_SIN",
"10": "Venezia (Porto Marghera)",
"100": "Massa e Carrara",
"110": "Casale Monferrato",
"120": "Litorale Domizio Flegreo e Agro Aversano",
"130": "Pitelli",
"140": "Balangero",
"150": "Pieve Vergonte",
"160": "Sesto San Giovanni",
"170": "Napoli Bagnoli-Coroglio",
"180": "Pioltello e Rodano",
"190": "Fiumi Saline e Alento",
"20": "Napoli Orientale",
"200": "Tito",
"210": "Crotone-Cassano-Cerchiara",
"220": "Sassuolo-Scandiano",
"230": "Fidenza",
"240": "Trieste",
"250": "Caffaro di Torviscosa (già Laguna di Grado e Marano)",
"260": "Frosinone",
"270": "Cogoleto-Stoppani",
"280": "Cerro al Lambro",
"290": "Milano Bovisa",
"30": "Gela",
"300": "Basso bacino del fiume Chienti",
"310": "Campobasso – Guglionesi II",
"320": "Basse di Stura",
"330": "Bari - Fibronit",
"340": "Sulcis – Iglesiente – Guspinese",
"350": "Biancavilla",
"360": "Livorno",
"370": "Terni - Papigno",
"380": "Emarese",
"390": "Mardimago – Ceregnano",
"40": "Priolo",
"400": "Bolzano",
"410": "Trento nord",
"420": "Brescia - Caffaro",
"430": "Broni",
"440": "Falconara Marittima",
"450": "Serravalle Scrivia",
"460": "Laghi di Mantova e Polo Chimico",
"470": "Orbetello",
"480": "Aree del litorale vesuviano",
"490": "Aree industriali di Porto Torres",
"50": "Manfredonia",
"500": "Area industriale della Val Basento",
"510": "Bacino del fiume Sacco",
"520": "Bacino idrografico del fiume Sarno",
"530": "Milazzo",
"540": "Le Strillaie",
"550": "Pianura",
"560": "Bussi sul Tirino",
"570": "La Maddalena",
"580": "Officina Grande Riparazione ETR di Bologna",
"590": "Area vasta di Giugliano",
"60": "Brindisi",
"70": "Taranto",
"80": "Cengio e Saliceto",
"90": "Piombino"
}

CODICI = {
"autorita": {
"999": "Altro",
"ARPA": "ARPA",
"CIMET": "Città Metropolitana",
"COMST": "Commissario Straordinario",
"COMUN": "Comune",
"MiTE": "Ministero della Transizione Ecologica",
"PROVI": "Provincia",
"RDIFE": "Rappresentante dell'Amministrazione della Difesa (siti militari_ DM 22/10/2009)",
"REGIO": "Regione"
},
"arpa_appa": {
"APPA_BZ": "APPA Bolzano",
"APPA_TN": "APPA Trento",
"AR_LAZ_FR": "ARPA Lazio - Dipartimento stato dell’Ambiente_Servizio Suolo e Bonifiche_ Unità suolo e bonifiche_Frosinone",
"AR_LAZ_LT": "ARPA Lazio - Dipartimento stato dell’Ambiente_Servizio Suolo e Bonifiche_ Unità suolo e bonifiche_Latina",
"AR_LAZ_N": "ARPA Lazio - Dipartimento stato dell’Ambiente_Servizio Suolo e Bonifiche_ Unità suolo e bonifiche_Area Nord",
"AR_LAZ_RM": "ARPA Lazio - Dipartimento stato dell’Ambiente_Servizio Suolo e Bonifiche_ Unità suolo e bonifiche_Roma",
"AR_LOM_BG": "ARPA Lombardia - Dipartimento di Bergamo",
"AR_LOM_BS": "ARPA Lombardia - Dipartimento di Brescia",
"AR_LOM_C_M": "ARPA Lombardia - Dipartimento di Cremona e Mantova",
"AR_LOM_C_V": "ARPA Lombardia - Dipartimento di Como e Varese",
"AR_LOM_L_P": "ARPA Lombardia - Dipartimento di Lodi e Pavia",
"AR_LOM_L_S": "ARPA Lombardia - Dipartimento di Lecco e Sondrio",
"AR_LOM_M_M": "ARPA Lombardia - Dipartimento di Milano e Monza",
"AR_MOLISE": "ARPA Molise",
"AR_PIE_NE": "ARPA Piemonte - Quadrante Piemonte Nord Est",
"AR_PIE_NO": "ARPA Piemonte - Quadrante Piemonte Nord Ovest",
"AR_PIE_SE": "ARPA Piemonte - Quadrante Piemonte Sud Est",
"AR_PIE_SO": "ARPA Piemonte - Quadrante Piemonte Sud Ovest",
"AR_PUG_BA": "ARPA Puglia - Servizio Territoriale Dipartimento di Bari",
"AR_PUG_BAT": "ARPA Puglia - Servizio Territoriale Dipartimento di Barletta-Andria-Trani",
"AR_PUG_BR": "ARPA Puglia - Servizio Territoriale Dipartimento di Brindisi",
"AR_PUG_FG": "ARPA Puglia - Servizio Territoriale Dipartimento di Foggia",
"AR_PUG_LE": "ARPA Puglia - Servizio Territoriale Dipartimento di Lecce",
"AR_PUG_TA": "ARPA Puglia - Servizio Territoriale Dipartimento di Taranto",
"AR_SICILIA": "ARPA Sicilia",
"AR_UMB_BON": "ARPA Umbria - Servizio bonifiche AIA VIA SIN",
"AR_UMB_N": "ARPA Umbria - Area dipartimentale umbria nord",
"AR_UMB_S": "ARPA Umbria - Area dipartimentale umbria sud",
"ARPA_FVG": "ARPA Friuli-Venezia Giulia",
"ARPA_VDA": "ARPA Valle d'Aosta",
"ARPAB": "ARPA Basilicata",
"ARPAC_AV": "ARPAC - Dipartimento Provinciale di Avellino",
"ARPAC_BV": "ARPAC - Dipartimento Provinciale di Benevento",
"ARPAC_CE": "ARPAC - Dipartimento Provinciale di Caserta",
"ARPAC_NA": "ARPAC - Dipartimento Provinciale di Napoli",
"ARPAC_SA": "ARPAC - Dipartimento Provinciale di Salerno",
"ARPACAL_CS": "ARPACAL -Dipartimento Provinciale di Cosenza (DAP CS)",
"ARPACAL_CZ": "ARPACAL - Dipartimento Provinciale di Catanzaro (DAP CZ)",
"ARPACAL_KR": "ARPACAL - Dipartimento Provinciale di Crotone (DAP KR)",
"ARPACAL_RC": "ARPACAL - Dipartimento Provinciale di Reggio Calabria (DAP RC)",
"ARPACAL_VV": "ARPACAL - Dipartimento Provinciale di Vibo Valentia (DAP VV)",
"ARPAE_ACC": "ARPAE - Area autorizzazioni e concessioni centro",
"ARPAE_ACE": "ARPAE - Area autorizzazioni e concessioni est",
"ARPAE_ACM": "ARPAE - Area autorizzazioni e concessioni metropolitana",
"ARPAE_ACO": "ARPAE - Area autorizzazioni e concessioni ovest",
"ARPAE_PAC": "ARPAE - Area prevenzione ambientale centro",
"ARPAE_PAE": "ARPAE - Area prevenzione ambientale est",
"ARPAE_PAM": "ARPAE - Area prevenzione ambientale metropolitana",
"ARPAE_PAO": "ARPAE - Area Prevenzione ambientale ovest",
"ARPAL_LE": "ARPAL - Settore Controlli e pareri ambientali levante",
"ARPAL_MT": "ARPAL - Settore Controlli e pareri ambientali metropolitani",
"ARPAL_PO": "ARPAL - Settore Controlli e pareri ambientali ponente",
"ARPAM": "ARPAM",
"ARPAM_N": "ARPAM - Area Vasta Nord",
"ARPAM_S": "ARPAM - Area Vasta Sud",
"ARPAS_CAMC": "ARPAS - Dipartimento Cagliari e Medio Campidano",
"ARPAS_NUOG": "ARPAS - Dipartimento Nuoro e Ogliastra",
"ARPAS_OR": "ARPAS - Dipartimento Oristano",
"ARPAS_SSGA": "ARPAS - Dipartimento Sassari e Gallura",
"ARPAS_SUL": "ARPAS - Dipartimento Sulcis",
"ARPAT_AR": "ARPAT - Dipartimento Arezzo",
"ARPAT_CE": "ARPAT - Area Vasta CENTRO",
"ARPAT_CO": "ARPAT - Area Vasta COSTA",
"ARPAT_EM": "ARPAT - Dipartimento Circondario Empolese",
"ARPAT_FI": "ARPAT - Dipartimento Firenze",
"ARPAT_GEN": "ARPAT - Direzione generale",
"ARPAT_GR": "ARPAT - Dipartimento Grosseto",
"ARPAT_LI": "ARPAT - Dipartimento Livorno",
"ARPAT_LU": "ARPAT - Dipartimento Lucca",
"ARPAT_MG": "ARPAT - Dipartimento Firenze Settore Mugello",
"ARPAT_MS": "ARPAT - Dipartimento Massa Carrara",
"ARPAT_PB": "ARPAT - Dipartimento Piombino-Elba",
"ARPAT_PI": "ARPAT - Dipartimento Pisa",
"ARPAT_PO": "ARPAT - Dipartimento Prato",
"ARPAT_PT": "ARPAT - Dipartimento Pistoia",
"ARPAT_S": "ARPAT - Area Vasta SUD",
"ARPAT_SI": "ARPAT - Dipartimento Siena",
"ARPAV": "ARPA Veneto",
"ARTA_AQ": "ARTA Abruzzo - Distretto di L'Aquila",
"ARTA_CH": "ARTA Abruzzo - Distretto di Chieti",
"ARTA_SanS": "ARTA Abruzzo - Distretto di San Salvo",
"ARTA_TE": "ARTA Abruzzo  - Distretto di Teramo"
},
"motivo_inserimento": {
"A242": "DLgs 152/06 Art.242",
"A242T": "DLgs 152/06 Art.242 a seguito di DPR 120/2017 (terre e rocce da scavo)",
"A244": "DLgs 152/06 Art.244 c.1",
"A245": "DLgs 152/06 Art.245",
"ART7": "DM 471/99 Art.7",
"ART8": "DM 471/99 Art.8",
"ART9": "DM 471/99 Art.9",
"ND": "Non disponibile",
"NN152": "Non noto-DLgs 152/06",
"NN471": "Non noto-DM 471/99",
"PREGB": "Piano Regionale Bonifiche ANTE DM 471/99",
"SINSI": "Perimetrazione SIN/SIR"
},
"stato_corrente": {
"10": "Notifica attivazione procedimento ai sensi del DLgs152/06",
"100": "Progetto di MISP approvato",
"110": "Progetto di intervento misto approvato",
"120": "Altro - Progetto di MISO e/o Bonifica e/o MISP approvato",
"130": "MISO conclusa in attesa di interventi di MISP e/o bonifica da effettuare a conclusione delle attività produttive",
"140": "Bonifica e/o MISP e/o MISO conclusa/e e da certificare",
"20": "Siti ricadenti nella perimetrazione di uno dei 17 ex SIN",
"200": "Non contaminato con non necessità di intervento (a seguito di indagini preliminari, C < CSC)",
"210": "Non contaminato con non necessità di intervento (a seguito di caratterizzazione, C < CSC)",
"220": "Non contaminato con non necessità di intervento (a seguito di AdR C < CSR) con monitoraggio in corso",
"230": "Non contaminato con non necessità di intervento (a seguito di AdR C < CSR)",
"240": "MISO conclusa (eventuale certificazione MISO)",
"250": "Bonifica conclusa (certificazione avvenuta bonifica)",
"260": "MISP conclusa (certificazione MISP)",
"270": "Intervento misto concluso (certificazione)",
"280": "Altro - bonifica e/o MISP e/o MISO conclusa/e e certificata/e",
"30": "Notifica attivazione procedimento ex DM 471/99",
"300": "Procedimento sostituito da uno o più procedimenti",
"40": "Altro - Notifica attivazione procedimento o MIPRE o MISE o indagini preliminari, etc. e comunque Piano di Caratterizzazione non ancora approvato",
"50": "Piano di Caratterizzazione approvato",
"60": "Caratterizzazione conclusa e/o Analisi di Rischio presentata da approvare e/o progetto di intervento alle CSC presentato da approvare",
"70": "Analisi di Rischio approvata",
"80": "Progetto di MISO approvato",
"90": "Progetto di bonifica approvato",
"135": "Bonifica e/o MISP e/o MISO con certificazione parziale"
},
"tipo_proc_corr": {
"242B": "Art. 242bis DLgs 152/06",
"249": "Art. 249 DLgs 152/06",
"471": "DM 471/99",
"47113": "DM 471/99 Art.13",
"A471": "Ante DM 471/99",
"DM22": "DM 22/10/2009 - Siti Militari",
"DM31": "DM 31/2015",
"DM46": "DM 46/2019 - Aree Agricole",
"NN152": "Non noto-DLgs 152/06",
"ORD": "DLgs 152/06 ordinaria"
},
"stato_cont_corr": {
"ATTES": "In attesa di accertamenti analitici",
"CONT": "Contaminato",
"N_CON": "Non contaminato",
"ND": "Non disponibile",
"P_CON": "Potenzialmente contaminato"
},
"sito_orfano": {
"FINAN": "Finanziato",
"INDIV": "Individuato e non finanziato",
"NO": "No"
}
}


def _decodifica(attr):
    """Sostituisce i codici con le etichette ufficiali del servizio."""
    fuori = {}
    for k, v in (attr or {}).items():
        if v is None:
            fuori[k] = None; continue
        tab = CODICI.get(k)
        fuori[k] = tab.get(str(v), str(v)) if tab else v
    return fuori


def _chiedi(url, timeout):
    import json as _j
    try:
        from urllib.request import urlopen
    except ImportError:
        from urllib2 import urlopen
    with urlopen(url, timeout=timeout) as r:
        return _j.loads(r.read().decode("utf-8", "replace"))


def interroga_siti_contaminati(xmin, ymin, xmax, ymax, timeout=45):
    """Interroga SIN e procedimenti su un riquadro in WGS84.

    Restituisce {'sin': [...], 'procedimenti': [...], 'errore': str|None}.
    L'errore non viene mai nascosto: se il servizio non risponde lo
    screening deve dichiarare 'non verificato', non 'nessun vincolo'.
    """
    from urllib.parse import urlencode
    esito = {"sin": [], "procedimenti": [], "errore": None}
    riquadro = "%s,%s,%s,%s" % (xmin, ymin, xmax, ymax)
    comuni = {"geometry": riquadro, "geometryType": "esriGeometryEnvelope",
              "inSR": "4326", "outSR": "4326",
              "spatialRel": "esriSpatialRelIntersects", "f": "json"}
    try:
        q = dict(comuni, outFields="id_sin,den_sin,validita,matrice",
                 returnGeometry="true")
        for f in _chiedi("%s/%d/query?%s" % (BASE, LAYER_SIN, urlencode(q)),
                         timeout).get("features", []):
            a = _decodifica(f.get("attributes"))
            # den_sin arriva come CODICE, non come nome: senza questa
            # traduzione il verbale direbbe «SIN 20» invece del nome vero
            cod = str((f.get("attributes") or {}).get("den_sin") or "")
            a["den_sin"] = NOMI_SIN.get(cod, a.get("den_sin"))
            a["cod_sin"] = cod
            esito["sin"].append({"attributi": a, "geometria": f.get("geometry")})
        q = dict(comuni, returnGeometry="true", outFields=(
            "id_procedimento,codice_regionale,comune_istat,autorita,arpa_appa,"
            "stato_corrente,tipo_proc_corr,stato_cont_corr,motivo_inserimento,"
            "sito_orfano,cod_sin,nome_regione"))
        for f in _chiedi("%s/%d/query?%s" % (BASE, LAYER_PROCEDIMENTI, urlencode(q)),
                         timeout).get("features", []):
            a = f.get("attributes") or {}
            d = _decodifica(a)
            d["_aperto"] = str(a.get("stato_corrente")) not in STATI_CHIUSI
            esito["procedimenti"].append({"attributi": d, "geometria": f.get("geometry")})
    except Exception as e:
        esito["errore"] = "%s: %s" % (type(e).__name__, e)
    return esito
