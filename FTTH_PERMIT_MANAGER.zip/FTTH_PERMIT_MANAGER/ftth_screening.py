# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Screening territoriale per richieste di scavo su suolo pubblico (reti TLC).

Modulo di LOGICA PURA del plugin FTTH Permessi Manager: non importa qgis né
PyQt, così è testabile fuori da QGIS (come ftth_core). Dato il nome di un
comune produce un report di PRE-ISTRUTTORIA: rete stradale classificata con
ente gestore, Soprintendenza ABAP competente (con PEC), vincoli paesaggistici
SITAP, interferenze lineari (ferrovie, corsi d'acqua) e l'elenco degli enti da
interpellare con titolo, norme e documentazione tipica.

NON certifica nulla: comprime la ricognizione da giorni a minuti, non
sostituisce l'istruttoria. La confidenza di ogni fonte è propagata fino al
report ed è ciò che distingue questo strumento da un certificatore.

Fonti: OSM/Nominatim (confine comunale), OSM/Overpass (strade, ferrovie,
acque), SITAP WFS del Ministero della Cultura (Soprintendenze e vincoli),
kb 'procedimenti.yaml' (mappa infrastruttura → ente → procedimento, curata a
mano e versionata: è la parte di valore).
"""
from __future__ import annotations

import json
import os
import re
import threading
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests
import yaml
from shapely.geometry import shape

UA = "ftth-permessi-screening/0.80 (pre-istruttoria autorizzativa; QGIS plugin)"

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
NOMINATIM = "https://nominatim.openstreetmap.org/search"
SITAP_WFS = "https://sitap.cultura.gov.it/geoserver/wfs"
CRS84 = "urn:ogc:def:crs:OGC:1.3:CRS84"

# Rete Natura 2000 (SIC/ZSC direttiva Habitat + ZPS direttiva Uccelli) dal
# servizio ArcGIS REST dell'Agenzia Europea per l'Ambiente (EEA): fonte europea
# autoritativa, copre tutta Italia, stabile e interrogabile per bbox in GeoJSON.
# Layer 4 = SIC/ZSC (scala di dettaglio), layer 8 = ZPS (scala di dettaglio).
EEA_N2000 = "https://bio.discomap.eea.europa.eu/arcgis/rest/services/ProtectedSites/Natura2000_Dyna_WM/MapServer"
EEA_N2000_LAYERS = [(4, "SIC/ZSC (Dir. Habitat 92/43/CEE)"), (8, "ZPS (Dir. Uccelli 2009/147/CE)")]

# Geoportale Regione Siciliana (SITR) — ArcGIS REST dei Piani Paesaggistici.
# La Sicilia NON è in SITAP nazionale per le fasce art.142, ma le pubblica qui,
# organizzate per ambito/provincia. Ogni servizio ha i suoi id-layer (variano),
# mappati sotto. Provincia (sigla) -> lista servizi candidati (Messina e Trapani
# hanno più ambiti: si prova finché il bbox restituisce feature).
SICILIA_REST = "https://map.sitr.regione.sicilia.it/gis/rest/services/piani_paesaggistici/%s_beni_paesaggistici/MapServer"
# servizio -> {chiave art.142: id layer}. Verificato via REST (2026-09).
SICILIA_142_LAYERS = {
    "ag":          {"a_costa": 6, "c_fiumi": 8, "g_boschi": 9, "art136": 10},
    "cl":          {"a_costa": 5, "c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "ct":          {"a_costa": 9, "c_fiumi": 11, "g_boschi": 12, "art136": 13},
    "egadi":       {"a_costa": 3, "g_boschi": 4, "art136": 5},
    "en":          {"c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "me_ambito9":  {"a_costa": 5, "c_fiumi": 8, "g_boschi": 9, "art136": 10},
    "pa":          {"a_costa": 12, "c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "pelagie":     {"g_boschi": 5, "a_costa": 6, "art136": 7},
    "rg":          {"a_costa": 4, "c_fiumi": 6, "g_boschi": 7, "art136": 8},
    "sr":          {"a_costa": 4, "c_fiumi": 6, "g_boschi": 7, "art136": 8},
    "tp_ambiti23": {"a_costa": 5, "c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "tp_ambito1":  {"g_boschi": 4, "a_costa": 5, "art136": 7},
}
# provincia (da Nominatim 'county'/'state_district', lower) -> servizi candidati
SICILIA_PROV_SERVIZI = {
    "agrigento": ["ag", "pelagie"],
    "caltanissetta": ["cl"],
    "catania": ["ct"],
    "enna": ["en"],
    "messina": ["me_ambito9"],
    "palermo": ["pa"],
    "ragusa": ["rg"],
    "siracusa": ["sr"],
    "trapani": ["tp_ambiti23", "tp_ambito1", "egadi"],
}
SICILIA_142_DESC = {
    "a_costa": "Fascia costiera 300 m (art. 142 c.1 lett. a)",
    "c_fiumi": "Fascia di rispetto fiumi/corsi d'acqua 150 m (art. 142 c.1 lett. c)",
    "g_boschi": "Aree boscate (art. 142 c.1 lett. g)",
    "art136": "Immobili e aree di notevole interesse pubblico (art. 136)",
}

# --- Geoportale PPTR Puglia (SIT Puglia, ArcGIS REST) ---------------------
# La Puglia non è in SITAP per le componenti insediative regionali (UCP).
# 'Città consolidata' e simili sono Ulteriori Contesti Paesaggistici (UCP,
# NTA PPTR art.76-77): NON sono vincolo ex D.Lgs 42/2004, ma per manufatti
# fuori terra (armadi ottici) attivano valutazione paesaggistica regionale.
# Il servizio rifiuta f=geojson (HTTP 400): si usa f=json + Referer.
PUGLIA_PPTR_REST = ("https://webapps.sit.puglia.it/arcgis/rest/services/"
                    "Operationals/PPTR_APPROVATO/MapServer")
PUGLIA_PPTR_REFERER = "https://webapps.sit.puglia.it/"
PUGLIA_PPTR_LAYERS = {
    54: "Città consolidata (UCP PPTR, NTA art. 77)",
}

_KB_CACHE = None


def carica_kb() -> dict:
    """Knowledge base procedimenti.yaml, accanto a questo modulo."""
    global _KB_CACHE
    if _KB_CACHE is None:
        percorso = Path(__file__).parent / "procedimenti.yaml"
        _KB_CACHE = yaml.safe_load(percorso.read_text(encoding="utf-8"))
    return _KB_CACHE


@dataclass
class SourceResult:
    data: Any
    fonte: str
    url: str
    licenza: str
    autoritativo: bool
    confidenza: str
    note: list = field(default_factory=list)
    errore: str | None = None


# ---------------------------------------------------------------------------
# Budget di tempo e annullamento
#
# Il guasto che si evita: QGIS bloccato a tempo indeterminato. I timeout di
# requests valgono per SINGOLA richiesta, quindi si MOLTIPLICANO: quattro
# endpoint Overpass per due giri, oppure quaranta pagine WFS da 120 s, fanno
# decine di minuti su una fonte sola, e le fonti sono una decina.
# Il caso che fa danno non e' il server morto — quello va in timeout e si
# recupera — ma il server LENTO MA VIVO: risponde sempre, nessun timeout
# scatta mai, e le attese si sommano finche' l'utente uccide QGIS.
# Qui si fissa un tetto di tempo misurato con time.monotonic(): quando lo
# stadio sfora si ABBANDONA quella fonte e si prosegue con le altre, e
# l'abbandono viene DICHIARATO nel report (mai un silenzioso "vincolo assente":
# un falso negativo su un vincolo cogente e' il danno peggiore possibile).
# ---------------------------------------------------------------------------

# Misura di riferimento: uno screening reale completo su Coriano e' durato
# 366 s in condizioni normali. Il tetto sta comodamente sopra (2,5x) perche'
# un comune grande e carico di vincoli e' legittimamente piu' lento, ma resta
# nell'ordine dei minuti e non delle ore.
BUDGET_TOTALE_DEFAULT = 900.0        # 15 minuti per l'intero screening
BUDGET_RFI_DEFAULT = 240.0           # lo screening RFI tocca due sole fonti

# Tetto per singolo stadio. La somma supera di proposito il budget totale: il
# budget totale e' il vincolo duro, questi servono a impedire che UNA fonte
# lenta si mangi il tempo di tutte le altre.
BUDGET_STADI = {
    "confine comunale": 60.0,
    "rete stradale": 180.0,
    "soprintendenze": 240.0,
    "vincoli paesaggistici": 240.0,
    "rete natura 2000": 120.0,
    "aree protette (parchi)": 150.0,
    "siti contaminati e bonifiche": 120.0,
    "interferenze lineari": 180.0,
    "fasce art.142 (costa/fiumi)": 180.0,
    "UCP PPTR Puglia (Città consolidata)": 120.0,
    "pericolosità idrogeologica": 90.0,
}

OVERPASS_BUDGET_DEFAULT = 180.0      # tutti i tentativi su tutti gli endpoint
WFS_BBOX_BUDGET_DEFAULT = 120.0      # tutte le pagine di UN layer WFS
WFS_TUTTE_BUDGET_DEFAULT = 200.0     # i tre tentativi su UN layer "scarica tutto"

_LOCALE = threading.local()


class _Scadenze:
    """Tempo residuo dello screening e dello stadio in corso.

    Vive in un threading.local perche' il pannello del plugin lancia lo
    screening in un thread di lavoro: due screening in parallelo non devono
    rubarsi il budget a vicenda.
    """

    def __init__(self, budget_s=None, annulla=None):
        self.inizio = time.monotonic()
        self.budget = float(budget_s or BUDGET_TOTALE_DEFAULT)
        self._annulla = annulla if callable(annulla) else None
        self.stadio = None
        self._inizio_stadio = self.inizio
        self._fine_stadio = None
        self.abbandoni = []            # [(stadio, secondi_spesi)]
        self.annullato_visto = False
        self.errori_callback = []      # un callback rotto non deve far cadere lo screening

    def speso(self):
        return time.monotonic() - self.inizio

    def residuo_totale(self):
        return self.budget - self.speso()

    def apri_stadio(self, nome, budget_s=None):
        b = float(budget_s if budget_s is not None else BUDGET_STADI.get(nome, 120.0))
        self.stadio = nome
        self._inizio_stadio = time.monotonic()
        # lo stadio non puo' durare piu' di quanto resti all'intero screening
        self._fine_stadio = self._inizio_stadio + min(b, max(0.0, self.residuo_totale()))
        return b

    def residuo(self):
        r = self.residuo_totale()
        if self._fine_stadio is not None:
            r = min(r, self._fine_stadio - time.monotonic())
        return r

    def scaduto(self):
        return self.residuo() <= 0.5

    def annullato(self):
        if self._annulla is None:
            return False
        try:
            esito = bool(self._annulla())
        except Exception as e:  # noqa: BLE001
            # un callback rotto non deve ne' bloccare ne' interrompere: si
            # prosegue, ma l'anomalia resta tracciata e finisce nei warning
            self.errori_callback.append(str(e))
            return False
        if esito:
            self.annullato_visto = True
        return esito


def _scadenze():
    return getattr(_LOCALE, "scad", None)


def _avvia_budget(budget_s=None, annulla=None):
    """Apre il budget per il thread corrente. Fuori da esegui() non c'e' budget
    attivo e i connettori si comportano come prima (utile per i test unitari)."""
    _LOCALE.scad = _Scadenze(budget_s, annulla)
    return _LOCALE.scad


def _chiudi_budget():
    _LOCALE.scad = None
    ant = getattr(_LOCALE, "anticipo", None)
    if ant is not None:
        ant.chiudi()
        _LOCALE.anticipo = None


class _Anticipo:
    """Fonti indipendenti scaricate IN PARALLELO appena il confine comunale è
    noto: prima si interrogavano una dopo l'altra e lo screening sommava i
    tempi di tutte (Coriano: 366 s). Ogni lavoro ha il suo budget di stadio
    (stesso tetto di prima) e vede il pulsante Annulla. Le richieste a
    Overpass restano in fila fra loro (un solo lavoro alla volta): i server
    pubblici rifiutano più richieste contemporanee dallo stesso indirizzo.
    Lo stadio, quando arriva il suo turno, prende il risultato già pronto o
    ne aspetta la fine."""

    GRUPPI = {"osm": 1, "sitap": 3, "altro": 3}

    def __init__(self):
        import concurrent.futures as cf
        main = _scadenze()
        self._annulla = main._annulla if main else None
        self._ex = {g: cf.ThreadPoolExecutor(max_workers=n, thread_name_prefix="scr_" + g)
                    for g, n in self.GRUPPI.items()}
        self._fut = {}

    def avvia(self, gruppo, stadio, fn, *a, **k):
        annulla = self._annulla

        def lavoro():
            _avvia_budget(BUDGET_STADI.get(stadio, 120.0) + 5.0, annulla)
            _apri_stadio(stadio)
            try:
                return fn(*a, **k)
            finally:
                _LOCALE.scad = None
        self._fut[stadio] = self._ex[gruppo].submit(lavoro)

    def prendi(self, stadio, fn, *a, **k):
        """Risultato dello stadio (o la chiamata diretta se non anticipato)."""
        f = self._fut.get(stadio)
        if f is None:
            return fn(*a, **k)
        while not f.done():
            if _annullato():
                return SourceResult(data=[], fonte="n/d", url="", licenza="",
                                    autoritativo=False, confidenza="NON VERIFICATA",
                                    errore="annullato dall'utente")
            time.sleep(0.15)
        return f.result()

    def chiudi(self):
        for ex in self._ex.values():
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:          # Python < 3.9
                ex.shutdown(wait=False)


def _anticipo():
    return getattr(_LOCALE, "anticipo", None)


def _prendi(stadio, fn, *a, **k):
    ant = _anticipo()
    return ant.prendi(stadio, fn, *a, **k) if ant is not None else fn(*a, **k)


def _residuo():
    s = _scadenze()
    return s.residuo() if s else float("inf")


def _residuo_totale():
    s = _scadenze()
    return s.residuo_totale() if s else float("inf")


def _scaduto():
    s = _scadenze()
    return bool(s and s.scaduto())


def _annullato():
    s = _scadenze()
    return bool(s and s.annullato())


def _timeout_req(secondi, minimo=5.0):
    """Timeout per requests, mai oltre il tempo che resta.

    Tupla (connessione, lettura): con un timeout scalare requests applica lo
    stesso valore a connessione E lettura, quindi il caso peggiore e' il doppio
    di quanto si crede — ed e' proprio il raddoppio che faceva sforare i conti.
    """
    t = max(float(minimo), float(secondi))
    return (min(10.0, t), t)


def _attesa(secondi):
    """Pausa limitata al tempo residuo: dormire oltre il budget e' tempo buttato
    che non produce nessun dato in piu'."""
    r = _residuo()
    d = float(secondi) if r == float("inf") else max(0.0, min(float(secondi), r - 1.0))
    if d > 0:
        time.sleep(d)


def _apri_stadio(nome, budget_s=None):
    """Apre lo stadio e ritorna i secondi di attesa massima, da mostrare
    nell'avanzamento: l'utente deve sapere COSA si sta interrogando e per
    quanto, altrimenti un log fermo sembra un blocco."""
    s = _scadenze()
    if s:
        return int(s.apri_stadio(nome, budget_s))
    return int(budget_s if budget_s is not None else BUDGET_STADI.get(nome, 120.0))


def _marca_fonte(rep, stadio, motivo):
    """Scrive nel report che una fonte NON e' stata verificata.

    Finisce sia in rep['fonti'] (la confidenza diventa 'NON VERIFICATA', cosi'
    l'Excel la mostra fra le fonti) sia in rep['warning']. L'abbandono di una
    fonte non deve MAI diventare un silenzioso "questo vincolo non esiste".
    """
    trovato = False
    for f in rep.get("fonti", []):
        if f.get("stadio") == stadio:
            f["confidenza"] = "NON VERIFICATA"
            f["errore"] = motivo
            f["disponibile"] = False
            trovato = True
            break
    if not trovato:
        rep.setdefault("fonti", []).append(
            {"stadio": stadio, "fonte": "n/d", "confidenza": "NON VERIFICATA",
             "errore": motivo, "disponibile": False})
    rep.setdefault("fonti_non_disponibili", [])
    if stadio not in rep["fonti_non_disponibili"]:
        rep["fonti_non_disponibili"].append(stadio)
    if motivo not in rep.setdefault("warning", []):
        rep["warning"].append(motivo)


def _chiudi_stadio(rep, nome, testo, ok=None):
    """Chiude lo stadio; se ha esaurito il budget la fonte e' stata abbandonata
    e lo si dichiara. `testo` deve contenere un %d per i secondi spesi.
    `ok=True` (dati effettivamente ottenuti) evita di marcare come non
    verificata una fonte che ha risposto giusto sul filo."""
    s = _scadenze()
    if not s or s.stadio != nome:
        return False
    sforato = s.scaduto()
    spesi = time.monotonic() - s._inizio_stadio
    s.stadio = None
    s._fine_stadio = None
    if sforato and not ok:
        s.abbandoni.append((nome, round(spesi, 1)))
        testo_s = testo % int(spesi)
        if s.residuo_totale() <= 0.5:
            testo_s += (" (si e' fermata perche' era esaurito il budget complessivo "
                        "di %d s dello screening)" % int(s.budget))
        _marca_fonte(rep, nome, testo_s)
        return True
    return False


# Ordine di esecuzione degli stadi di esegui(): serve a dichiarare come NON
# verificate TUTTE le fonti rimaste indietro quando ci si ferma, non solo
# quella in cui ci si e' fermati. Un report che semplicemente non nomina i
# vincoli paesaggistici si legge come "nessun vincolo": e' il falso negativo
# da evitare. La Puglia (UCP PPTR) resta fuori perche' vale solo li'.
ORDINE_STADI = [
    "confine comunale",
    "rete stradale",
    "soprintendenze",
    "vincoli paesaggistici",
    "rete natura 2000",
    "aree protette (parchi)",
    "siti contaminati e bonifiche",
    "ARPA in Conferenza di Servizi",
    "interferenze lineari",
    "fasce art.142 (costa/fiumi)",
    "pericolosità idrogeologica",
]


def _stadi_non_eseguiti(dove):
    """Lo stadio in cui ci si ferma e tutti quelli che venivano dopo."""
    try:
        i = ORDINE_STADI.index(dove)
    except ValueError:
        return [dove]
    return ORDINE_STADI[i:]


def _ferma(rep, avvisa, dove):
    """True se l'utente ha chiesto di annullare o se il budget complessivo e'
    finito: si smette appena possibile e si torna un report PARZIALE.
    L'annullamento NON e' un errore e non solleva eccezioni."""
    if _annullato():
        rep["annullato"] = True
        # lo stadio saltato va dichiarato fonte NON disponibile, non lasciato
        # fuori dal report: un report senza la riga 'vincoli paesaggistici' si
        # legge come "nessun vincolo", ed e' il falso negativo da evitare
        for st in _stadi_non_eseguiti(dove):
            _marca_fonte(rep, st,
                         "Stadio '%s' NON eseguito: screening annullato dall'utente prima "
                         "di interrogare questa fonte. Nulla di questa fonte è stato "
                         "verificato." % st)
        if avvisa:
            avvisa("Annullato dall'utente (prima di: %s)" % dove)
        return True
    if _residuo_totale() <= 0.5:
        rep["budget_esaurito"] = True
        for st in _stadi_non_eseguiti(dove):
            _marca_fonte(rep, st,
                         "Stadio '%s' NON eseguito: budget complessivo dello screening "
                         "esaurito prima di interrogare questa fonte. Nulla di questa fonte "
                         "è stato verificato: rilanciare lo screening o aumentare il "
                         "budget." % st)
        if avvisa:
            avvisa("Budget esaurito: stadio '%s' non eseguito" % dove)
        return True
    return False


# ---------------------------------------------------------------------------
# Normalizzazione dei riferimenti stradali
#
# La realtà di OSM: "SP006", "SP6", "SP 6", "SP45/Variante_C.V.", "SP5a",
# "SR71ter", "NSA 123". Senza normalizzazione si contano 3 volte le stesse
# strade e si sbaglia il conteggio nel report.
# ---------------------------------------------------------------------------
REF_RE = re.compile(
    r"^\s*(?P<cls>SS|SP|SR|SC|A|RA|NSA|T|E)\s*[-. ]?\s*(?P<num>\d{1,4})(?P<suf>[a-zA-Z]{0,6})",
    re.IGNORECASE,
)

# Formato provinciale lombardo/veneto: "SP BS 469", "SPBS469", "SPBS469D1" =
# SP + sigla provincia (2 lettere) + numero (+ suffisso). Su OSM molte provinciali
# del Nord sono taggate così; senza questo la strada veniva persa (Capriolo BS).
_REF_PROV_RE = re.compile(
    r"^\s*SP\s*(?P<prov>[A-Z]{2})\s*[-. ]?\s*(?P<num>\d{1,4})(?P<suf>[a-zA-Z0-9]{0,4})",
    re.IGNORECASE,
)
# Provinciali con numero ROMANO: "SP XII", "SPXII". Cattura fino a ~8 simboli romani.
_REF_ROM_RE = re.compile(
    r"^\s*(?P<cls>SP|SR|SS)\s*[-. ]?\s*(?P<rom>[IVXLC]{1,8})\s*$",
    re.IGNORECASE,
)
# sigle provincia italiane valide (per non confondere 'SPD1' con provincia 'PD')
_SIGLE_PROV = {
    "AG","AL","AN","AO","AP","AQ","AR","AT","AV","BA","BG","BI","BL","BN","BO",
    "BR","BS","BT","BZ","CA","CB","CE","CH","CL","CN","CO","CR","CS","CT","CZ",
    "EN","FC","FE","FG","FI","FM","FR","GE","GO","GR","IM","IS","KR","LC","LE",
    "LI","LO","LT","LU","MB","MC","ME","MI","MN","MO","MS","MT","NA","NO","NU",
    "OR","PA","PC","PD","PE","PG","PI","PN","PO","PR","PT","PU","PV","PZ","RA",
    "RC","RE","RG","RI","RM","RN","RO","SA","SI","SO","SP","SR","SS","SU","SV",
    "TA","TE","TN","TO","TP","TR","TS","TV","UD","VA","VB","VC","VE","VI","VR",
    "VT","VV",
}
_ROM_VAL = {"I":1,"V":5,"X":10,"L":50,"C":100}


def _roman_to_int(s):
    """Converte un numero romano semplice in intero, o None se non valido."""
    s = s.upper()
    tot, prev = 0, 0
    for ch in reversed(s):
        v = _ROM_VAL.get(ch)
        if v is None:
            return None
        tot += -v if v < prev else v
        prev = max(prev, v)
    return tot if tot > 0 else None

# Declassamenti annotati in OSM con la convenzione "ex": una ex statale passata
# alla Provincia. Forme viste sui dati reali (Fino Mornasco CO, SS35->SP35):
# "SP ex SS35", "SPexSS35", "SP ex SS 35", "SPex SS35". Cattura il numero storico.
_EX_RE = re.compile(
    r"^\s*SP\s*ex\s*SS\s*[-. ]?\s*(?P<num>\d{1,4})",
    re.IGNORECASE,
)


def normalizza_ref(ref):
    """'SP006' -> ('SP', 'SP6');  'SR71ter' -> ('SR', 'SR71ter'); None se non classificabile.

    Una way OSM può portare più ref separati da ';' in ordine NON deterministico
    (es. 'E45;SS3bis' oppure 'SS3bis;E45'): li proviamo TUTTI e teniamo il primo
    che dà una classe con competenza (SS/SP/SR/A/RA/NSA/SC), così una statale non
    viene persa solo perché in OSM l'itinerario europeo E era scritto per primo.
    """
    if not ref:
        return None
    candidati = []
    for parte in ref.split(";"):
        primo = parte.split("/")[0]        # scarta "SP45/Variante_C.V."
        # --- declassamento annotato in OSM: "SP ex SS35", "SPexSS35", "SP ex SS 35"
        # Una statale trasferita alla Provincia spesso in OSM viene taggata con la
        # convenzione "ex": la strada NON è più ANAS/SS, è provinciale. La portiamo
        # a classe SP (competenza Provincia) tenendo il numero storico come sigla
        # leggibile, così l'ente indicato è corretto anche se OSM è a metà migrazione.
        mex = _EX_RE.match(primo.strip())
        if mex:
            num = str(int(mex.group("num")))
            candidati.append(("SP", "SPex SS%s" % num))
            continue
        # --- provinciale con sigla provincia: "SP BS 469", "SPBS469", "SPBS469D1"
        # (formato lombardo/veneto su OSM). La classe è SP; teniamo sigla+numero
        # come denominazione leggibile così l'ente Provincia è corretto.
        mprov = _REF_PROV_RE.match(primo.strip())
        if mprov and mprov.group("prov").upper() in _SIGLE_PROV:
            prov = mprov.group("prov").upper()
            num = str(int(mprov.group("num")))
            suf = (mprov.group("suf") or "").upper()
            candidati.append(("SP", "SP%s%s%s" % (prov, num, suf)))
            continue
        # --- provinciale con numero romano: "SP XII", "SPXII"
        mrom = _REF_ROM_RE.match(primo.strip())
        if mrom:
            n = _roman_to_int(mrom.group("rom"))
            if n:
                cls_r = mrom.group("cls").upper()
                candidati.append((cls_r, "%s%d" % (cls_r, n)))
                continue
        m = REF_RE.match(primo)
        if not m:
            continue
        cls = m.group("cls").upper()
        num = str(int(m.group("num")))     # azzera lo zero-padding: 006 -> 6
        suf = m.group("suf").lower()
        if cls in {"T", "E"}:              # itinerari europei / tangenziali: non danno competenza
            continue
        candidati.append((cls, "%s%s%s" % (cls, num, suf)))
    if not candidati:
        return None
    # se un ramo dello stesso ref è annotato come declassato ("SPex SS<n>"), quella
    # è l'informazione più aggiornata: vince sul "SS<n>" grezzo dello stesso numero
    # (tratto misto tipico OSM a metà migrazione, es. "SS35;SPex SS35").
    ex_nums = {c[1].replace("SPex SS", "") for c in candidati if c[1].startswith("SPex SS")}
    if ex_nums:
        candidati = [c for c in candidati
                     if not (c[0] == "SS" and str(_solo_num(c[1])) in ex_nums)]
    # priorità alle classi con competenza sovracomunale piu' rilevante
    ordine = {"A": 0, "RA": 1, "NSA": 2, "SS": 3, "SR": 4, "SP": 5, "SC": 6}
    candidati.sort(key=lambda c: ordine.get(c[0], 9))
    return candidati[0]


def _solo_num(sigla):
    """Estrae il primo gruppo di cifre da una sigla ('SP35'->'35', 'SPex SS35'->'35')."""
    m = re.search(r"(\d{1,4})", sigla)
    return m.group(1) if m else ""


def tipo_corso_acqua(tags):
    """Classifica un corso d'acqua OSM in 'naturale' (fiume/torrente/rio, demanio
    idrico) o 'bonifica' (canale/fosso/scolina artificiale, tipicamente gestito da
    un Consorzio di bonifica). Ritorna (categoria, tipo_leggibile).

    Distinzione utile perché il regime cambia:
    - naturale demaniale -> R.D. 523/1904 (polizia idraulica 10 m dal piede argine)
      + Genio Civile/Regione, oltre alla fascia paesaggistica 150 m (art. 142 lett. c);
    - bonifica -> Consorzio di bonifica competente, fascia di rispetto stabilita dal
      REGOLAMENTO consortile (non i 150 m, non sempre i 10 m: spesso 4-10 m).
    OSM: 'canal' è ambiguo (può essere navigabile demaniale o consortile), lo
    trattiamo come bonifica salvo che il nome indichi un fiume/naviglio maggiore.
    """
    w = (tags or {}).get("waterway", "")
    if w in ("river", "stream"):
        return ("naturale", "fiume/torrente")
    if w in ("ditch", "drain"):
        return ("bonifica", "canale/scolina di bonifica")
    if w == "canal":
        # un canale grande demaniale vs canale consortile: OSM non lo dice.
        # Default prudente: reticolo di bonifica (competenza Consorzio), che è il
        # caso più frequente per i 'canal' minori in pianura.
        return ("bonifica", "canale")
    return ("naturale", w or "corso d'acqua")


def classifica_strade(elements):
    """Raggruppa le way OSM per classe amministrativa e ref normalizzato."""
    per_classe = defaultdict(lambda: defaultdict(
        lambda: {"n_way": 0, "operator": set(), "nomi": set()}))
    senza_ref = 0
    for e in elements:
        t = e.get("tags", {})
        parsed = normalizza_ref(t.get("ref", ""))
        if not parsed:
            if t.get("highway") in {"motorway", "trunk", "primary", "secondary"}:
                senza_ref += 1
            continue
        cls, ref_norm = parsed
        rec = per_classe[cls][ref_norm]
        rec["n_way"] += 1
        if t.get("operator"):
            rec["operator"].add(t["operator"])
        if t.get("name"):
            rec["nomi"].add(t["name"])

    out = {}
    for cls, refs in per_classe.items():
        out[cls] = {
            r: {"n_way": v["n_way"],
                "operator": sorted(v["operator"]),
                "nomi": sorted(v["nomi"])[:2]}
            for r, v in sorted(refs.items(), key=lambda kv: _sortkey(kv[0]))
        }
    return {"strade": out, "way_classificate_senza_ref": senza_ref}


def _sortkey(ref):
    m = re.match(r"([A-Z]+)(\d+)(.*)", ref)
    return (m.group(1), int(m.group(2)), m.group(3)) if m else (ref, 0, "")


def rileva_incoerenze(strade, comune_nome=None):
    """Segnala i casi in cui il dato OSM è internamente contraddittorio o obsoleto.

    Casi coperti:
    - SR con operator=Provincia (trasferimento non recepito);
    - SP senza operator;
    - SS/SR sempre: possibile declassamento a provinciale/comunale non ancora in
      OSM (OSM non rispecchia i declassamenti in tempo reale — verificato: SS35 a
      Fino Mornasco è oggi SP35, ma molte way OSM la portano ancora come SS);
    - declassamenti NOTI dalla kb (tabella `declassamenti`): correzione mirata.
    """
    warn = []
    for ref, v in strade.get("SR", {}).items():
        for op in v["operator"]:
            if "provincia" in op.lower():
                warn.append(
                    "%s: classificata come strada regionale ma OSM riporta "
                    "operator='%s'. Possibile trasferimento di competenza recente "
                    "non ancora recepito nei dati: verificare l'ente gestore attuale."
                    % (ref, op))
    for ref, v in strade.get("SP", {}).items():
        if not v["operator"]:
            warn.append("%s: nessun tag operator in OSM, ente gestore da confermare." % ref)
    for ref, v in strade.get("A", {}).items():
        if not v["operator"]:
            warn.append(
                "%s: concessionario autostradale non desumibile dai dati. "
                "Va identificato su elenco MIT/AISCAT prima di istruire la pratica." % ref)
    # avviso sistematico su ogni statale/regionale: OSM può essere obsoleto sul
    # declassamento (una SS/SR trasferita a Provincia/Comune resta a lungo "SS" in OSM)
    for cls in ("SS", "SR"):
        for ref in strade.get(cls, {}):
            warn.append(
                "%s: verificare l'eventuale DECLASSAMENTO a strada provinciale/comunale. "
                "OSM non rispecchia i declassamenti in tempo reale: una ex statale/"
                "regionale può risultare ancora '%s' in mappa pur essendo passata "
                "alla Provincia o al Comune (in tal caso l'ente competente cambia)." % (ref, cls))
    # correzione mirata dai declassamenti noti in kb
    warn += _declassamenti_noti(strade, comune_nome)
    # correzione OPPOSTA: SP in OSM che sono in realtà ANAS (rientri statali)
    warn += _rientri_anas_noti(strade, comune_nome)
    return warn


def _declassamenti_noti(strade, comune_nome):
    """Confronta le strade rilevate con la tabella `declassamenti` della kb e, se
    una SS/SR nota come declassata compare nel comune indicato, avvisa con l'ente
    corretto. La tabella è una memoria dei casi incontrati, non un catasto."""
    avvisi = []
    try:
        tab = carica_kb().get("declassamenti") or []
    except Exception:  # noqa: BLE001
        return avvisi
    if not tab:
        return avvisi
    comune_l = (comune_nome or "").strip().lower()
    for voce in tab:
        vecchia = str(voce.get("da", "")).upper().replace(" ", "")
        cls_vecchia = vecchia[:2]
        refs_cls = strade.get(cls_vecchia, {})
        # match sul numero della sigla storica (SS35 -> '35')
        num = _solo_num(vecchia)
        presente = any(_solo_num(r) == num for r in refs_cls)
        com_voce = str(voce.get("comune", "")).strip().lower()
        if presente and (not com_voce or not comune_l or com_voce in comune_l or comune_l in com_voce):
            avvisi.append(
                "DECLASSAMENTO NOTO: %s risulta declassata a %s (%s%s). "
                "Ignorare la classe/operator ANAS di OSM: l'ente competente è %s."
                % (voce.get("da"), voce.get("a"), voce.get("ente", "ente provinciale/comunale"),
                   (" — %s" % voce["comune"]) if voce.get("comune") else "",
                   voce.get("ente", "l'ente subentrato")))
    return avvisi


def _rientri_anas_noti(strade, comune_nome):
    """Speculare a _declassamenti_noti: strade che OSM classifica come SP ma che
    sono in realtà STATALI (ANAS). Confronta le SP rilevate con la tabella kb
    `rientri_anas` e, se una SP nota compare nel comune, avvisa che l'ente
    corretto è ANAS, non la Provincia. Fonte: Catasto Strade / stradario ANAS."""
    avvisi = []
    try:
        tab = carica_kb().get("rientri_anas") or []
    except Exception:  # noqa: BLE001
        return avvisi
    if not tab:
        return avvisi
    comune_l = (comune_nome or "").strip().lower()
    for voce in tab:
        vecchia = str(voce.get("da", "")).upper().replace(" ", "")
        cls_vecchia = vecchia[:2]  # "SP"
        refs_cls = strade.get(cls_vecchia, {})
        num = _solo_num(vecchia)
        presente = any(_solo_num(r) == num for r in refs_cls)
        com_voce = str(voce.get("comune", "")).strip().lower()
        if presente and (not com_voce or not comune_l or com_voce in comune_l or comune_l in com_voce):
            nota = voce.get("nota", "")
            avvisi.append(
                "COMPETENZA ANAS: %s è taggata come provinciale in OSM ma la sua "
                "asta principale è STATALE, gestita da %s. Ignorare la classe SP di "
                "OSM per l'asta principale: l'ente competente è %s.%s"
                % (voce.get("da"), voce.get("ente", "ANAS"),
                   voce.get("ente", "ANAS"),
                   (" %s" % nota) if nota else ""))
    return avvisi


# ---------------------------------------------------------------------------
# Connettori
# ---------------------------------------------------------------------------
def risolvi_comune(nome, provincia_hint=None):
    """Nome del comune -> geometria amministrativa (admin_level=8) + ISTAT.

    Gestisce le omonimie: se Nominatim restituisce più candidati di rango
    comunale li riporta tutti invece di scegliere silenziosamente il primo.
    """
    q = nome if not provincia_hint else "%s, %s" % (nome, provincia_hint)
    params = {"q": q, "countrycodes": "it", "format": "json", "limit": 10,
              "polygon_geojson": 1, "addressdetails": 1, "extratags": 1}
    if _annullato():
        return SourceResult(None, "OSM/Nominatim", NOMINATIM, "ODbL", False, "bassa",
                            errore="annullato dall'utente")
    try:
        r = requests.get(NOMINATIM, params=params, headers={"User-Agent": UA},
                         timeout=_timeout_req(min(45, max(5.0, _residuo()))))
        r.raise_for_status()
        raw = r.json()
    except Exception as e:  # noqa: BLE001
        return SourceResult(None, "OSM/Nominatim", NOMINATIM, "ODbL", False, "bassa", errore=str(e))

    cand = [x for x in raw
            if x.get("osm_type") == "relation" and x.get("class") == "boundary"
            and x.get("addresstype") in {"town", "city", "village", "municipality", "administrative"}]
    if not cand:
        return SourceResult(None, "OSM/Nominatim", NOMINATIM, "ODbL", False, "bassa",
                            errore="Nessun comune trovato per '%s'" % q)
    # preferisci i confini a livello COMUNALE (admin_level=8): 'administrative' è
    # un catch-all che intercetta anche Città Metropolitane/Province omonime dei
    # capoluoghi (Roma, Milano, Napoli...). Senza questo filtro cand[0] ordinato
    # per importance può risolvere sulla relation dell'area vasta (admin_level 6),
    # analizzando un territorio enormemente più grande del Comune.
    def _al(x):
        return str((x.get("extratags") or {}).get("admin_level") or "")
    comunali = [x for x in cand if _al(x) == "8"]
    if comunali:
        cand = comunali
    note = []
    if len(cand) > 1:
        alt = ", ".join(c["display_name"] for c in cand[1:4])
        note.append("OMONIMIA: %d candidati. Alternative scartate: %s" % (len(cand), alt))

    c = cand[0]
    addr = c.get("address", {})
    extra = c.get("extratags") or {}
    geom = shape(c["geojson"]) if c.get("geojson") else None
    pop = None
    for k in ("population", "population:date", "ref:ISTAT:population"):
        if extra.get(k) and str(extra[k]).replace(".", "").isdigit():
            pop = int(str(extra[k]).replace(".", ""))
            break
    out = {
        "nome": c.get("name"),
        "display_name": c.get("display_name"),
        "provincia": addr.get("county") or addr.get("state_district"),
        "regione": addr.get("state"),
        "cap": addr.get("postcode"),
        "osm_relation_id": c.get("osm_id"),
        "istat": extra.get("ref:ISTAT"),
        "popolazione": pop,
        "geometry": geom,
        "bbox": [float(v) for v in c["boundingbox"]],  # [S, N, W, E]
        "admin_level": _al(c),  # deve essere "8" (confine comunale); trasparenza
    }
    # confine non comunale: avvisa (area vasta = analisi su territorio sbagliato)
    if _al(c) and _al(c) != "8":
        note.append("ATTENZIONE: confine risolto con admin_level=%s (non 8=comunale): "
                    "l'area analizzata potrebbe non coincidere col Comune." % _al(c))
    return SourceResult(out, "OSM/Nominatim", NOMINATIM, "ODbL 1.0", False, "media", note)


OVERPASS_STRADE = """
[out:json][timeout:120];
rel({rel_id});map_to_area->.a;
.a out ids;
(
  way["highway"]["ref"](area.a);
  way["highway"~"^(motorway|trunk|primary|secondary)"](area.a);
);
out tags{geom};
"""

OVERPASS_ALTRO = """
[out:json][timeout:120];
rel({rel_id});map_to_area->.a;
.a out ids;
(
  way["railway"="rail"]["railway:traffic_mode"!="service"](area.a);
  way["railway"~"^(abandoned|disused|razed)$"](area.a);
  way["waterway"~"^(river|stream|canal)$"](area.a);
  way["waterway"~"^(ditch|drain)$"]["name"](area.a);
  way["natural"="wood"](area.a);
  way["landuse"="forest"](area.a);
  relation["natural"="wood"](area.a);
  relation["landuse"="forest"](area.a);
);
out tags{geom};
"""

NOTA_OSM = ("OSM non è fonte autoritativa: la classificazione e l'ente gestore "
            "vanno confermati presso il gestore della strada.")


def _overpass(query, giri=2, pausa=20, budget_s=None):
    """Esegue una query Overpass con failover tra endpoint, dentro un budget.

    Due giri, non uno. I server pubblici Overpass rifiutano o troncano le
    richieste quando sono carichi, e lo fanno a ondate: misurato su Fabrica
    di Roma, primo giro a vuoto (tutti e quattro in timeout) e secondo giro
    73 elementi, stessa query a pochi secondi di distanza. Con un giro solo
    il plugin concludeva "nessuna strada" e lasciava la mappa vuota: il
    ritentativo RESTA.

    Quello che cambia e' che l'insieme dei tentativi sta dentro un tetto
    complessivo. Prima il timeout era per singola richiesta e si moltiplicava:
    60 s x 4 endpoint + pausa + 150 s x 4 endpoint = fino a 868 s per UNA
    interrogazione, e di interrogazioni Overpass ne servono tre per screening.
    Da li' nasceva QGIS bloccato per decine di minuti.

    Il primo giro non puo' mangiarsi tutto il budget: al secondo — quello che
    storicamente recupera i dati — resta sempre una fetta garantita.
    """
    # stessa richiesta riuscita negli ultimi giorni: risposta dalla cache (lo
    # screening rifatto sulla stessa zona non riaspetta i server pubblici)
    in_cache = _cache_overpass(query)
    if in_cache is not None:
        return in_cache, "cache locale (OpenStreetMap)", None
    els, ep, err = _overpass_rete(query, giri, pausa, budget_s)
    if not err:
        _cache_overpass(query, els)
    return els, ep, err


OVERPASS_CACHE_GIORNI = 7


def _cache_overpass(query, els=None):
    """Legge (els=None) o scrive la cache su disco di una richiesta Overpass."""
    import hashlib
    import json as _json
    cart = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache")
    p = os.path.join(cart, "overpass_scr_%s.json"
                     % hashlib.md5(query.encode("utf-8")).hexdigest())
    try:
        if els is None:
            if os.path.isfile(p) and \
                    time.time() - os.path.getmtime(p) < OVERPASS_CACHE_GIORNI * 86400:
                with open(p, encoding="utf-8") as fh:
                    return _json.load(fh)
            return None
        os.makedirs(cart, exist_ok=True)
        with open(p, "w", encoding="utf-8") as fh:
            _json.dump(els, fh)
    except Exception:  # noqa: BLE001
        return None
    return None


def _overpass_rete(query, giri=2, pausa=20, budget_s=None):
    tetto = float(budget_s or OVERPASS_BUDGET_DEFAULT)
    tetto = min(tetto, max(1.0, _residuo()))
    avvio = time.monotonic()
    fine = avvio + tetto
    limiti_giro = [avvio + tetto * 0.45, fine]
    last_err = None
    for giro in range(giri):
        if _annullato():
            return [], "", "annullato dall'utente"
        if time.monotonic() >= fine:
            break
        if giro:
            # pausa utile a far sbollire il carico, ma mai oltre un quarto di
            # quello che resta: l'attesa non produce dati
            _attesa(min(pausa, max(0.0, fine - time.monotonic()) * 0.25))
        limite = min(limiti_giro[giro] if giro < len(limiti_giro) else fine, fine)
        base = 60 if giro == 0 and giri > 1 else 150
        for ep in OVERPASS_ENDPOINTS:
            if _annullato():
                return [], "", "annullato dall'utente"
            resta = limite - time.monotonic()
            if resta <= 2:
                break   # niente tentativi condannati in partenza: il tempo serve al giro dopo
            try:
                r = requests.post(ep, data=query.encode("utf-8"),
                                  headers={"User-Agent": UA},
                                  timeout=_timeout_req(min(base, resta)))
                if r.status_code != 200:
                    last_err = "%s -> HTTP %s" % (ep, r.status_code)
                    continue
                j = r.json()
                # Overpass in overload/timeout risponde 200 con un 'remark' e
                # elements PARZIALI/vuoti: NON è un successo, va trattato come
                # errore per attivare il failover ed evitare falsa 'assenza'
                remark = j.get("remark")
                if remark and ("timed out" in remark.lower() or "runtime error" in remark.lower()
                               or not j.get("elements")):
                    last_err = "%s -> remark: %s" % (ep, remark[:120])
                    _attesa(1)
                    continue
                els = j.get("elements", [])
                if "map_to_area" in query:
                    # Sentinella dell'area: le query per confine comunale
                    # emettono l'area stessa (".a out ids;"). Se manca, il server
                    # NON ha risolto il confine (indice aree vuoto o non
                    # aggiornato: visto su nodi di overpass.kumi.systems e
                    # overpass.private.coffee, ottobre 2026) e risponde 200 con
                    # zero elementi e nessun 'remark'. Quella risposta non dice
                    # "nessuna ferrovia/strada": dice "non ho cercato". Va
                    # scartata e si passa al server successivo.
                    if not any(e.get("type") == "area" for e in els):
                        last_err = ("%s -> confine comunale non risolto dal server "
                                    "(indice aree vuoto o non aggiornato): risposta "
                                    "scartata" % ep)
                        _attesa(1)
                        continue
                    els = [e for e in els if e.get("type") != "area"]
                return els, ep, None
            except Exception as e:  # noqa: BLE001
                last_err = "%s -> %s" % (ep, e)
                _attesa(1)
    speso = time.monotonic() - avvio
    if speso >= tetto - 1:
        last_err = ("%s | budget Overpass di %d s esaurito (spesi %d s): la query NON "
                    "e' stata completata, un risultato vuoto qui non significa assenza"
                    % (last_err or "nessun endpoint utile", int(tetto), int(speso)))
    return [], "", last_err


# Con il tracciato (o l'area) di progetto le strade e le opere lineari si
# chiedono a Overpass in UNA sola richiesta e solo nel riquadro attorno alla
# rete, non su tutto il comune: la richiesta per confine comunale con le
# geometrie di tutti i boschi era la parte più lenta dello screening
# (Deruta: strade in timeout dopo 180 s, opere lineari 144 s).
OVERPASS_RIQUADRO = """
[out:json][timeout:120];
(
  way["highway"]["ref"]({bb});
  way["highway"~"^(motorway|trunk|primary|secondary)"]({bb});
  way["railway"="rail"]["railway:traffic_mode"!="service"]({bb});
  way["railway"~"^(abandoned|disused|razed)$"]({bb});
  way["waterway"~"^(river|stream|canal)$"]({bb});
  way["waterway"~"^(ditch|drain)$"]["name"]({bb});
  way["natural"="wood"]({bb});
  way["landuse"="forest"]({bb});
);
out tags{geom};
"""
_OSM_RIQUADRO = {}          # (bbox, geom) -> (els, ep, err): stessa richiesta una volta sola
_OSM_RIQUADRO_LOCK = threading.Lock()


def _osm_riquadro(bbox, con_geometrie):
    """Elementi Overpass nel riquadro bbox = (sud, ovest, nord, est)."""
    chiave = (tuple(round(x, 5) for x in bbox), bool(con_geometrie))
    with _OSM_RIQUADRO_LOCK:
        if chiave in _OSM_RIQUADRO:
            return _OSM_RIQUADRO[chiave]
        bb = "%.6f,%.6f,%.6f,%.6f" % tuple(bbox)
        q = OVERPASS_RIQUADRO.format(bb=bb, geom=" geom" if con_geometrie else "")
        ris = _overpass(q)
        if not ris[2]:
            _OSM_RIQUADRO.clear()           # solo l'ultimo riquadro: niente memoria che cresce
            _OSM_RIQUADRO[chiave] = ris
        return ris


def _e_strada(e):
    return "highway" in (e.get("tags") or {})


def strade_nel_comune(rel_id, con_geometrie=False, bbox=None):
    if bbox is not None:
        els, ep, err = _osm_riquadro(bbox, con_geometrie)
        els = [e for e in els if _e_strada(e)]
    else:
        q = OVERPASS_STRADE.format(rel_id=rel_id, geom=" geom" if con_geometrie else "")
        els, ep, err = _overpass(q)
    if err:
        return SourceResult([], "OpenStreetMap (Overpass)", ep or "n/d", "ODbL 1.0",
                            False, "bassa", errore=err)
    return SourceResult(els, "OpenStreetMap (Overpass)", ep, "ODbL 1.0", False, "media",
                        note=[NOTA_OSM])


def _comune_costiero(rel_id, bbox=None):
    """True se il territorio comunale tocca la linea di costa (natural=coastline).
    Serve per attivare il vincolo art.142 lett.a (fascia costiera 300 m) come
    probabile quando la regione non ha i layer SITAP.

    NB: la coastline OSM corre LUNGO il confine comunale, non dentro l'area, quindi
    map_to_area non la cattura: usiamo il bbox del comune (verificato su Letojanni,
    dove map_to_area dava 0 e il bbox 1). In caso di errore ritorna None: "non
    verificato" non e' "non costiero" (il vecchio False faceva sparire la fascia
    costiera 300 m sui comuni di mare quando Overpass non rispondeva).
    """
    try:
        if bbox is not None:
            S, N, W, E = bbox
            q = ("[out:json][timeout:60];"
                 "way[\"natural\"=\"coastline\"](%f,%f,%f,%f);out ids 1;" % (S, W, N, E))
        else:
            q = ("[out:json][timeout:60];rel(%s);>;"
                 "way[\"natural\"=\"coastline\"];out ids 1;" % rel_id)
        els, ep, err = _overpass(q)
        if err:
            return None
        return bool(els)
    except Exception:  # noqa: BLE001
        return None


def interferenze_lineari(rel_id, con_geometrie=False, bbox=None):
    if bbox is not None:
        els, ep, err = _osm_riquadro(bbox, con_geometrie)
        els = [e for e in els if not _e_strada(e)]
    else:
        q = OVERPASS_ALTRO.format(rel_id=rel_id, geom=" geom" if con_geometrie else "")
        els, ep, err = _overpass(q)
    if err:
        return SourceResult([], "OpenStreetMap (Overpass)", ep or "n/d", "ODbL 1.0",
                            False, "bassa", errore=err)
    return SourceResult(els, "OpenStreetMap (Overpass)", ep, "ODbL 1.0", False, "media")


# ---------------------------------------------------------------------------
# ISPRA IdroGEO — pericolosità idraulica e da frana (dato per comune ISTAT)
#
# API REST ufficiale ISPRA (idrogeo.isprambiente.it/api), OpenAPI 3.
# Dà le mosaicature nazionali PAI: aree a pericolosità idraulica (P1/P2/P3) e
# da frana (P1..P4) come kmq e % del territorio comunale. È un dato per COMUNE,
# non per area di progetto: non si interseca con l'ARLO ma vale come indicatore
# autoritativo "questo comune ha vincolo idrogeologico/rischio alluvioni".
# ---------------------------------------------------------------------------
IDROGEO_API = "https://idrogeo.isprambiente.it/api/pir/comuni"


def pericolosita_idrogeologica(istat):
    """Indicatori PAI del comune da ISPRA IdroGEO. `istat` = codice ISTAT
    comunale (es. '030101'). Ritorna SourceResult con dict di percentuali, o
    errore se il comune non è risolvibile."""
    if not istat:
        return SourceResult(None, "ISPRA IdroGEO", IDROGEO_API, "ISPRA", True, "bassa",
                            errore="codice ISTAT del comune non disponibile")
    try:
        target = int(str(istat).lstrip("0") or "0")
    except ValueError:
        target = None

    def _match(pro_com):
        # confronto robusto: normalizza entrambi a intero (gestisce lo zero
        # iniziale delle province 01-09, es. Genova '010032' -> 10032)
        if pro_com is None:
            return False
        try:
            return int(str(pro_com).lstrip("0") or "0") == target
        except (ValueError, TypeError):
            return str(pro_com) == str(istat)
    try:
        # 1) elenco comuni → trova l'uid dal pro_com (l'elenco NON porta le
        #    percentuali, che stanno solo nel dettaglio /comuni/{uid})
        r = requests.get(IDROGEO_API, headers={"User-Agent": UA},
                         timeout=_timeout_req(min(60, max(5.0, _residuo()))))
        r.raise_for_status()
        elenco = r.json()
        uid = None
        for c in elenco:
            if _match(c.get("pro_com")):
                uid = c.get("uid")
                break
        if uid is None:
            return SourceResult(None, "ISPRA IdroGEO", IDROGEO_API, "ISPRA", True, "bassa",
                                errore="comune ISTAT %s non trovato in IdroGEO" % istat)
        # 2) dettaglio comune → percentuali PAI/PGRA
        r2 = requests.get("%s/%s" % (IDROGEO_API, uid), headers={"User-Agent": UA},
                          timeout=_timeout_req(min(60, max(5.0, _residuo()))))
        r2.raise_for_status()
        rec = r2.json()
    except Exception as e:  # noqa: BLE001
        return SourceResult(None, "ISPRA IdroGEO", IDROGEO_API, "ISPRA", True, "bassa", errore=str(e))

    def _num(x):
        return x if isinstance(x, (int, float)) else 0.0
    dato = {
        "superficie_kmq": rec.get("ar_kmq"),
        "idraulica": {
            "P3_elevata_pct": _num(rec.get("aridp3_p")),
            "P2_media_pct": _num(rec.get("aridp2_p")),
            "P1_bassa_pct": _num(rec.get("aridp1_p")),
        },
        "frane": {
            "P4_molto_elevata_pct": _num(rec.get("ar_frp4_p")),
            "P3_elevata_pct": _num(rec.get("ar_frp3_p")),
            "P3P4_pct": _num(rec.get("ar_frp3p4p")),
            "P2_media_pct": _num(rec.get("ar_frp2_p")),
            "P1_pct": _num(rec.get("ar_frp1_p")),
        },
    }
    return SourceResult(dato, "ISPRA IdroGEO (mosaicatura nazionale PAI)", IDROGEO_API,
                        "ISPRA", autoritativo=True, confidenza="alta",
                        note=["Dato per COMUNE (non ristretto all'area di progetto): "
                              "indica se il territorio comunale ha aree a pericolosità "
                              "idraulica/da frana. La perimetrazione di dettaglio va letta "
                              "sul PAI del distretto e sul geoportale regionale."])


def _wfs_bbox(typename, bbox_snwe, count=400, budget_s=None):
    """GetFeature con filtro bbox. bbox_snwe = [S, N, W, E] come da Nominatim.

    ATTENZIONE — trappola nota di GeoServer sull'ordine degli assi: con
    'EPSG:4326' questo server interpreta lon,lat (contro la spec), mentre con
    la forma urn si comporta secondo spec. CRS84 elimina l'ambiguità: è
    definito lon,lat per costruzione. I layer SITAP sono nativamente in
    EPSG:32632/23032 (mixed): la riproiezione la fa il server.

    Pagina con startIndex fino a esaurire il dataset: senza paginazione un
    comune denso di vincoli (centinaia di poligoni art.142) veniva TRONCATO
    silenziosamente al tetto `count`, dichiarando assente un vincolo cogente
    realmente intersecante (falso negativo su dato autoritativo).

    MAX_PAGINE da solo non basta a limitare il tempo: 40 pagine x 120 s di
    timeout fanno 80 minuti su UN layer, e i layer SITAP interrogati sono
    nove. Serve anche un tetto di tempo. Se scade con pagine gia' raccolte si
    tengono i dati PARZIALI e si dichiara il troncamento al chiamante, che
    deve riportarlo: dati incompleti dichiarati, mai un'assenza falsa.
    """
    s_, n_, w_, e_ = bbox_snwe
    tutte = []
    start = 0
    MAX_PAGINE = 40   # guardia: fino a 40*count features
    tetto = float(budget_s or WFS_BBOX_BUDGET_DEFAULT)
    tetto = min(tetto, max(1.0, _residuo()))
    fine = time.monotonic() + tetto
    for _ in range(MAX_PAGINE):
        if _annullato():
            if tutte:
                return tutte, "annullato dall'utente dopo %d feature (elenco PARZIALE)" % len(tutte)
            return [], "annullato dall'utente"
        resta = fine - time.monotonic()
        if resta <= 2:
            if tutte:
                return tutte, ("TRONCATO: budget di %d s esaurito dopo %d feature — elenco "
                               "PARZIALE, possono esserci vincoli non letti" % (int(tetto), len(tutte)))
            return [], "budget di %d s esaurito senza alcuna risposta utile" % int(tetto)
        params = {"service": "WFS", "version": "2.0.0", "request": "GetFeature",
                  "typeNames": typename, "outputFormat": "application/json",
                  "srsName": CRS84, "count": count, "startIndex": start,
                  "bbox": "%s,%s,%s,%s,%s" % (w_, s_, e_, n_, CRS84)}
        try:
            r = requests.get(SITAP_WFS, params=params, headers={"User-Agent": UA},
                             timeout=_timeout_req(min(120, resta)))
            if r.status_code == 400 and start == 0 and not tutte:
                # Alcune viste SITAP (vw_vasvia_boschi, vw_vasvia_zone_umide,
                # vw_unesco_*) non hanno chiave primaria: GeoServer rifiuta la
                # paginazione («Cannot do natural order without a primary key»,
                # HTTP 400, verificato a novembre 2026) ma risponde senza
                # startIndex. Si chiede tutto in una pagina sola, con un tetto
                # alto; se lo raggiunge il troncamento si dichiara.
                tetto_n = 5000
                p2 = dict(params, count=tetto_n)
                p2.pop("startIndex", None)
                r = requests.get(SITAP_WFS, params=p2, headers={"User-Agent": UA},
                                 timeout=_timeout_req(min(120, max(5.0, fine - time.monotonic()))))
                if r.status_code != 200:
                    return [], "HTTP %s" % r.status_code
                feats = r.json().get("features", [])
                if len(feats) >= tetto_n:
                    return feats, ("TRONCATO: %d feature (tetto di una pagina sola, il layer "
                                   "non permette la paginazione) — elenco PARZIALE" % len(feats))
                return feats, None
            if r.status_code != 200:
                if tutte:
                    break   # abbiamo già dati parziali: li teniamo
                return [], "HTTP %s" % r.status_code
            j = r.json()
        except Exception as e:  # noqa: BLE001
            if tutte:
                break
            return [], str(e)
        pagina = j.get("features", [])
        tutte.extend(pagina)
        # WFS 2.0.0 espone numberMatched (totale) e numberReturned (pagina)
        n_match = j.get("numberMatched")
        if len(pagina) < count:
            break   # ultima pagina
        if isinstance(n_match, int) and len(tutte) >= n_match:
            break
        start += count
    return tutte, None


# cache di sessione: le giurisdizioni delle soprintendenze cambiano di rado e
# il download completo (senza bbox) e' pesante ma affidabile — lo paghiamo una
# volta sola per run del processo.
_WFS_TUTTE_CACHE = {}

# cache SU DISCO: le soprintendenze SITAP (~16 MB) sono il pezzo piu' lento dello
# screening e cambiano una volta ogni anni. Le salviamo in un file locale con
# scadenza, cosi' dal secondo screening in poi il download non serve.
_CACHE_GIORNI = 30


def _cache_dir():
    """Cartella cache nella TEMP di sistema (…/ftth_screening_cache/): dato
    nazionale riutilizzabile tra tutti i progetti, NON dentro la cartella del
    plugin (si perderebbe a ogni aggiornamento e sporcherebbe il pacchetto).
    Creata se assente."""
    import os as _os, tempfile
    d = _os.path.join(tempfile.gettempdir(), "ftth_screening_cache")
    try:
        _os.makedirs(d, exist_ok=True)
    except Exception:  # noqa: BLE001
        return None
    return d


def _cache_path(chiave):
    """Percorso file cache per una chiave (typename[, propertyName])."""
    import os as _os, hashlib
    d = _cache_dir()
    if not d:
        return None
    h = hashlib.md5(("|".join(chiave)).encode("utf-8")).hexdigest()[:16]
    return _os.path.join(d, "wfs_%s.json" % h)


def _cache_leggi(chiave):
    """Legge le feature dalla cache su disco se presente e non scaduta."""
    import os as _os, json as _json
    p = _cache_path(chiave)
    if not p or not _os.path.exists(p):
        return None
    try:
        eta_giorni = (time.time() - _os.path.getmtime(p)) / 86400.0
        if eta_giorni > _CACHE_GIORNI:
            return None
        with open(p, "r", encoding="utf-8") as fh:
            return _json.load(fh)
    except Exception:  # noqa: BLE001
        return None


def _cache_scrivi(chiave, feats):
    """Salva le feature nella cache su disco (best-effort, errori ignorati)."""
    import json as _json
    p = _cache_path(chiave)
    if not p:
        return
    try:
        with open(p, "w", encoding="utf-8") as fh:
            _json.dump(feats, fh)
    except Exception:  # noqa: BLE001
        pass


def _wfs_tutte(typename, propertyName=None, budget_s=None):
    """Scarica TUTTE le feature di un layer WFS senza filtro spaziale.

    Necessario per i layer soprintendenze SITAP: il filtro `bbox` su quelle viste
    (poligoni giurisdizionali molto grandi) restituisce sistematicamente HTTP 400
    e anche il CQL spaziale server-side non risponde. Scaricare l'intero layer
    (poche decine di poligoni) e fare il match in locale e' l'unica via robusta.
    Risultato in cache di sessione E su disco (30 giorni) per (typename, propertyName)."""
    chiave = (typename, propertyName or "")
    if chiave in _WFS_TUTTE_CACHE:
        return _WFS_TUTTE_CACHE[chiave], None
    # cache su disco: evita il download da 16 MB nei run successivi
    su_disco = _cache_leggi(chiave)
    if su_disco is not None:
        _WFS_TUTTE_CACHE[chiave] = su_disco
        return su_disco, None
    params = {"service": "WFS", "version": "2.0.0", "request": "GetFeature",
              "typeNames": typename, "outputFormat": "application/json",
              "srsName": CRS84}
    if propertyName:
        params["propertyName"] = propertyName
    # SITAP è lento (~16 MB, 30-40 s) e sotto carico risponde 502/503/timeout in
    # modo intermittente: 3 tentativi con backoff prima di arrendersi (misurato:
    # tentativi che alternano 502/503 e 200 sullo stesso layer nello stesso minuto).
    ultimo_err = None
    tetto = float(budget_s or WFS_TUTTE_BUDGET_DEFAULT)
    tetto = min(tetto, max(1.0, _residuo()))
    fine = time.monotonic() + tetto
    for tentativo in range(3):
        if _annullato():
            return [], "annullato dall'utente"
        resta = fine - time.monotonic()
        if resta <= 2:
            # tre tentativi da 180 s con backoff fanno quasi 10 minuti su UN
            # layer: oltre il tetto si rinuncia e lo si dichiara al chiamante
            return [], ("%s | budget di %d s esaurito: layer NON scaricato"
                        % (ultimo_err or "nessuna risposta utile", int(tetto)))
        try:
            r = requests.get(SITAP_WFS, params=params, headers={"User-Agent": UA},
                             timeout=_timeout_req(min(180, resta)))
            if r.status_code == 200:
                feats = r.json().get("features", [])
                _WFS_TUTTE_CACHE[chiave] = feats
                _cache_scrivi(chiave, feats)
                return feats, None
            ultimo_err = "HTTP %s" % r.status_code
            # 4xx diverso da 429 non è transitorio: inutile ritentare
            if 400 <= r.status_code < 500 and r.status_code != 429:
                if tentativo == 0:
                    # un 400 al primo colpo può dipendere dal carico: un retry
                    _attesa(3)
                    continue
                return [], ultimo_err
        except Exception as e:  # noqa: BLE001
            ultimo_err = str(e)
        if tentativo < 2:
            _attesa(4 * (tentativo + 1))  # 4s, 8s
    return [], ultimo_err


def soprintendenza_competente(comune_geom, bbox):
    """Individua la/le Soprintendenza/e ABAP territorialmente competenti.

    Layer nazionali di giurisdizione del SITAP: espongono denominazione, sito
    e PEC — l'unico dato autoritativo davvero riutilizzabile della catena.

    Il filtro `bbox` su queste viste dà HTTP 400 (poligoni giurisdizionali troppo
    grandi per il server): scarichiamo l'intero layer (poche decine di poligoni)
    e facciamo il match spaziale in LOCALE contro la geometria del comune. Se il
    download completo non è disponibile, si ripiega sul vecchio filtro bbox.
    """
    risultati = {}
    errori = []
    for tn, etichetta in [
        ("sitap_ws:vw_sitap_soprintendenze_paesaggio", "paesaggio"),
        ("sitap_ws:vw_sitap_soprintendenze_no_paesaggio", "beni culturali/archeologia"),
    ]:
        feats, err = _wfs_tutte(tn)
        if err or not feats:
            # ripiego sul vecchio metodo bbox (potrebbe comunque fallire con 400)
            feats2, err2 = _wfs_bbox(tn, bbox, count=50)
            if err2 and err:
                errori.append("%s: %s (fallback bbox: %s)" % (tn, err, err2))
                continue
            feats = feats2 or feats
            if err2 and not feats:
                errori.append("%s: %s" % (tn, err or err2))
                continue
        for f in feats:
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is not None and not g.intersects(comune_geom):
                continue
            p = f.get("properties", {})
            # quota del territorio comunale coperta: nei comuni di confine il
            # comune può ricadere su più giurisdizioni e serve capire quale prevale
            try:
                quota = g.intersection(comune_geom).area / comune_geom.area * 100
            except Exception:  # noqa: BLE001
                quota = 0.0
            if quota < 0.5:
                continue
            key = (p.get("codice"), etichetta)
            risultati[key] = {
                "ambito": etichetta,
                "codice": p.get("codice"),
                "denominazione": p.get("denominazione"),
                "sito": p.get("sito"),
                "pec": p.get("pec"),
                "quota_territorio": round(quota, 1),
                "marginale": quota < 15.0,
            }
    ordinati = sorted(risultati.values(), key=lambda x: -x["quota_territorio"])
    return SourceResult(ordinati, "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                        "Dati MiC", autoritativo=True,
                        confidenza="alta" if risultati else "bassa", note=errori)


VINCOLI_LAYERS = [
    ("sitap_ws:v1497pol_wgs84", "art136", "Vincolo paesaggistico decretato (art. 136)"),
    ("sitap_ws:vw_vasvia_boschi", "art142", "Aree boscate ex art. 142 lett. g"),
    ("sitap_ws:vw_vasvia_zone_umide", "art142", "Zone umide ex art. 142 lett. i"),
    ("sitap_ws:vw_unesco_sito", "unesco", "Sito UNESCO"),
    ("sitap_ws:vw_unesco_buffer", "unesco", "Buffer zone UNESCO"),
]

# ── Vincoli NON verificabili automaticamente ───────────────────────────────
# Lo screening interroga i servizi nazionali/regionali disponibili, ma diverse
# fattispecie dell'art. 142 c.1 D.Lgs 42/2004 NON hanno un layer nazionale
# interrogabile (o il servizio non espone quel tema). Dichiararle "assenti"
# sarebbe un falso negativo su un vincolo cogente: vanno invece ELENCATE come
# da verificare a mano sul PPR/PTCP e sulla cartografia regionale.
#
# Le lettere coperte dallo screening sono a, c, e, g, i (più art. 136, UNESCO,
# Natura 2000, idrogeologico, PAI). Restano fuori quelle qui sotto.
VINCOLI_DA_VERIFICARE_A_MANO = [
    ("art142_b", "Territori contermini ai laghi — fascia 300 m (art. 142 c.1 lett. b)",
     "Nessun layer nazionale: verificare sul PPR regionale se il tracciato passa "
     "entro 300 m da un lago o invaso."),
    ("art142_d", "Montagne oltre quota (art. 142 c.1 lett. d)",
     "Vincolo ex lege sopra 1600 m sulle Alpi e 1200 m su Appennini e isole: "
     "verificare la quota del tracciato quando si lavora in montagna."),
    ("art142_f", "Parchi e riserve nazionali o regionali (art. 142 c.1 lett. f)",
     "Lo screening controlla Natura 2000 (SIC/ZPS/ZSC), che è cosa diversa: i "
     "perimetri di parchi e riserve vanno verificati sull'ente parco competente."),
    ("art142_h", "Zone gravate da usi civici (art. 142 c.1 lett. h)",
     "Non esiste un catasto nazionale consultabile: verificare presso il Comune "
     "e la Regione (commissario agli usi civici)."),
    ("art142_l", "Vulcani (art. 142 c.1 lett. l)",
     "Rilevante solo in alcune aree (Etna, Vesuvio, Campi Flegrei, Eolie)."),
    ("art142_m", "Zone di interesse archeologico (art. 142 c.1 lett. m)",
     "SITAP espone le Soprintendenze competenti ma non sempre i perimetri delle "
     "aree di interesse archeologico: verificare con la Soprintendenza ABAP."),
    ("strade_paesaggistiche", "Strade a valenza paesaggistica / panoramiche",
     "Individuate dai Piani Paesaggistici Regionali (PPR/PPTR) e dai PTCP, non "
     "dal D.Lgs 42/2004: non esiste un layer nazionale. Dove il tracciato segue "
     "una strada panoramica o un itinerario di interesse paesaggistico, lo scavo "
     "e soprattutto gli armadi fuori terra possono richiedere autorizzazione "
     "paesaggistica. Verificare sul PPR regionale e sulle NTA del PTCP."),
    ("tratturi", "Tratturi, tratturelli e bracci (dove previsti)",
     "Beni di interesse archeologico/paesaggistico in Abruzzo, Molise, Puglia, "
     "Campania e Basilicata: verificare sul PPR regionale."),
]


def vincoli_da_verificare_a_mano():
    """Elenco dei vincoli che lo screening NON può accertare da solo.

    Non sono "assenti": sono NON VERIFICATI. Vanno sempre riportati nel esito,
    perché un falso negativo su un vincolo cogente (usi civici, parco, strada
    panoramica) costa molto più di una riga in più nel report.
    """
    return [{"chiave": k, "titolo": t, "nota": n}
            for k, t, n in VINCOLI_DA_VERIFICARE_A_MANO]

# Fasce art.142 lett.a (territori costieri 300 m) e lett.c (rispetto fiumi 150 m):
# in SITAP NON esiste un layer nazionale funzionante (vw_vasvia_aree_di_rispetto
# restituisce record vuoti col solo campo 'inside'). Esistono invece layer REGIONALI
# nel workspace 'sitap_ws_clone' (nomi eterogenei), ma solo per ALCUNE regioni —
# la Sicilia, ad esempio, NON è pubblicata. Mappa regione(lower) -> {a: layer costa,
# c: layer fiumi}. Per le regioni assenti si ricade sul fallback attivo (vedi
# fasce_142_probabili): lett.a se comune costiero, lett.c se ci sono corsi d'acqua.
# Typename verificati via GetCapabilities (2026-09).
SITAP_142_REGIONALE = {
    "basilicata":      {"a": "sitap_ws_clone:basilicata_art_142_c_1_a_territori_costieri",
                        "c": "sitap_ws_clone:BASILICATA_art142_c_fiumi"},
    "calabria":        {"a": "sitap_ws_clone:calabria_142_territori_costieri",
                        "c": "sitap_ws_clone:calabria_art142_corsi_acqua"},
    "campania":        {"a": "sitap_ws_clone:CAMPANIA_art_142_a_coste",
                        "c": "sitap_ws_clone:CAMPANIA_art_142_c_fiumi"},
    "emilia-romagna":  {"a": "sitap_ws_clone:emiliaromagna_art_142_c_1_a_territori_costieri",
                        "c": "sitap_ws_clone:emiliaromagna_art_142_c_1_c_aree_rispetto_fiumi"},
    "friuli-venezia giulia": {"c": "sitap_ws_clone:FVG_art_142_c_1_c_aree_rispetto_fiumi"},
    "friuli venezia giulia": {"c": "sitap_ws_clone:FVG_art_142_c_1_c_aree_rispetto_fiumi"},
    "lazio":           {"a": "sitap_ws_clone:LAZIO_art_142_c_1_a_territori_costieri",
                        "c": "sitap_ws_clone:LAZIO_art_142_fascia_150m_fiumi"},
    "lombardia":       {"c": "sitap_ws_clone:lombardia_142_rispetto_fiumi"},
    "piemonte":        {"c": "sitap_ws_clone:PIEMONTE_art_142_fascia_150m_fiumi"},
    "sardegna":        {"a": "sitap_ws_clone:SARDEGNA_art_142_territori_costieri_300m",
                        "c": "sitap_ws_clone:SARDEGNA_art_142_fascia_150m_fiumi"},
    "toscana":         {"a": "sitap_ws_clone:toscana_art142_territori_costieri",
                        "c": "sitap_ws_clone:toscana_art142_rispetto_fiumi"},
    "veneto":          {"a": "sitap_wms_bounce:VENETO_art_142_new_a_coste",
                        "c": "sitap_wms_bounce:VENETO_art_142_new_c_fiumi"},
}


def vincoli_paesaggistici(comune_geom, bbox, raccogli_geometrie=False):
    trovati = []
    errori = []
    geometrie = []          # [(etichetta, geojson_feature)] se richiesto
    for tn, chiave, etichetta in VINCOLI_LAYERS:
        feats, err = _wfs_bbox(tn, bbox, count=800)
        if err:
            errori.append("%s: %s" % (tn, err))
            if not feats:
                continue
            # dati PARZIALI (budget scaduto a meta' paginazione): li usiamo lo
            # stesso, ma l'errore resta dichiarato nel report. Un conteggio
            # incompleto e segnalato e' meglio di un "nessun vincolo" falso.
        n_int = 0
        inters = []             # intersezioni col comune, da unire (no doppie aree)
        for f in feats:
            if not f.get("geometry"):
                continue
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is not None and g.intersects(comune_geom):
                n_int += 1
                gi = None
                try:
                    gi = g.intersection(comune_geom)
                    inters.append(gi)
                except Exception:  # noqa: BLE001
                    pass
                if raccogli_geometrie:
                    # salva la geometria RITAGLIATA sul confine comunale, non la
                    # feature intera: altrimenti lo shapefile dei vincoli sfora
                    # nei comuni confinanti (il WFS interroga per bbox, non per
                    # confine). Se il ritaglio fallisce, ripiega sulla feature.
                    if gi is not None and not gi.is_empty:
                        import json as _json
                        from shapely.geometry import mapping as _mapping
                        f_clip = dict(f)
                        try:
                            f_clip["geometry"] = _json.loads(_json.dumps(_mapping(gi)))
                        except Exception:  # noqa: BLE001
                            f_clip = f
                        geometrie.append((etichetta, f_clip))
                    else:
                        geometrie.append((etichetta, f))
        if n_int:
            # unione delle intersezioni: poligoni sovrapposti NON gonfiano l'area
            # (senza union la % puo' superare il 100% del territorio comunale)
            area_int = 0.0
            if inters:
                try:
                    from shapely.ops import unary_union
                    u = unary_union(inters)
                    if not u.is_valid:
                        u = u.buffer(0)
                    area_int = u.area
                except Exception:  # noqa: BLE001
                    area_int = max((x.area for x in inters), default=0.0)
            pct = (area_int / comune_geom.area * 100) if comune_geom and comune_geom.area else 0.0
            pct = min(pct, 100.0)
            trovati.append({"chiave": chiave, "layer": tn, "etichetta": etichetta,
                            "n_poligoni": n_int, "pct_territorio": round(pct, 1)})
    res = SourceResult(trovati, "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                       "Dati MiC", autoritativo=False, confidenza="media",
                       note=errori + [
                           "SITAP è ricognitivo e non certificativo: la copertura per "
                           "regione è fortemente disomogenea e i vincoli ex art. 142 "
                           "operano anche se non cartografati."])
    res.geometrie = geometrie
    return res


def _norm_regione(nome):
    """Normalizza il nome regione per il match con SITAP_142_REGIONALE."""
    n = (nome or "").strip().lower()
    n = n.replace("'", " ").replace("-", "-")
    # alias comuni
    alias = {"friuli-venezia giulia": "friuli-venezia giulia",
             "friuli venezia giulia": "friuli-venezia giulia",
             "emilia romagna": "emilia-romagna",
             "trentino-alto adige": "trentino-alto adige"}
    return alias.get(n, n)


def fasce_142_regionali(comune_geom, bbox, regione, raccogli_geometrie=False):
    """Fasce art.142 lett.a (territori costieri 300 m) e lett.c (rispetto fiumi
    150 m) dai layer SITAP REGIONALI, quando la regione è coperta.

    Ritorna (trovati, geometrie, coperta, errori). `coperta`=False se la regione
    non ha layer in SITAP (es. Sicilia): il chiamante attiverà il fallback.
    """
    reg = _norm_regione(regione)
    mapping = SITAP_142_REGIONALE.get(reg)
    if not mapping:
        return [], [], False, []
    trovati = []
    geometrie = []
    errori = []
    lett_desc = {"a": ("Fascia costiera 300 m (art. 142 c.1 lett. a)", "art142"),
                 "c": ("Fascia di rispetto fiumi/corsi d'acqua 150 m (art. 142 c.1 lett. c)", "art142")}
    for lettera, tn in mapping.items():
        desc, chiave = lett_desc.get(lettera, ("Fascia art. 142", "art142"))
        feats, err = _wfs_bbox(tn, bbox, count=800)
        if err:
            errori.append("%s (%s): %s" % (desc, tn, err))
            if not feats:
                continue
            # vedi vincoli_paesaggistici: dati parziali tenuti ma dichiarati
        n_int = 0
        inters = []
        for f in feats:
            if not f.get("geometry"):
                continue
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is not None and g.intersects(comune_geom):
                n_int += 1
                try:
                    gi = g.intersection(comune_geom)
                    inters.append(gi)
                except Exception:  # noqa: BLE001
                    gi = None
                if raccogli_geometrie:
                    if gi is not None and not gi.is_empty:
                        import json as _json
                        from shapely.geometry import mapping as _mapping
                        f_clip = dict(f)
                        try:
                            f_clip["geometry"] = _json.loads(_json.dumps(_mapping(gi)))
                        except Exception:  # noqa: BLE001
                            f_clip = f
                        geometrie.append((desc, f_clip))
                    else:
                        geometrie.append((desc, f))
        if n_int:
            area_int = 0.0
            if inters:
                try:
                    from shapely.ops import unary_union
                    u = unary_union(inters)
                    if not u.is_valid:
                        u = u.buffer(0)
                    area_int = u.area
                except Exception:  # noqa: BLE001
                    area_int = max((x.area for x in inters), default=0.0)
            pct = (area_int / comune_geom.area * 100) if comune_geom and comune_geom.area else 0.0
            trovati.append({"chiave": chiave, "layer": tn, "etichetta": desc,
                            "n_poligoni": n_int, "pct_territorio": round(min(pct, 100.0), 1)})
    return trovati, geometrie, True, errori


def fasce_142_probabili(comune_geom, bbox, costiero, ha_corsi_acqua):
    """Fallback per le regioni SENZA layer SITAP art.142 (es. Sicilia): segnala i
    vincoli come PROBABILI in base a segnali oggettivi (comune costiero -> lett.a;
    presenza di corsi d'acqua -> lett.c). Non sono i poligoni esatti, ma evitano il
    falso negativo "nessun vincolo" quando il vincolo ex lege quasi certamente esiste.
    Ritorna una lista di avvisi (stringhe)."""
    avvisi = []
    if costiero:
        avvisi.append(
            "PROBABILE fascia costiera 300 m (art. 142 c.1 lett. a): il comune è "
            "costiero e la fascia opera EX LEGE anche se non cartografata in SITAP. "
            "La perimetrazione esatta va letta sul geoportale/PPTR regionale.")
    if ha_corsi_acqua:
        avvisi.append(
            "PROBABILE fascia di rispetto 150 m dei corsi d'acqua (art. 142 c.1 lett. c): "
            "sono presenti corsi d'acqua nel territorio; la fascia opera EX LEGE per i "
            "corsi iscritti negli elenchi delle acque pubbliche (R.D. 1775/1933). "
            "Verificare l'iscrizione e la perimetrazione sul geoportale regionale.")
    return avvisi


def _esri_to_geojson_geom(g):
    """Converte una geometria ArcGIS (rings/paths/x,y) in geometria GeoJSON."""
    if g is None:
        return None
    if "rings" in g:
        return {"type": "Polygon" if len(g["rings"]) == 1 else "MultiPolygon",
                "coordinates": g["rings"] if len(g["rings"]) == 1 else [[r] for r in g["rings"]]}
    if "paths" in g:
        return {"type": "LineString" if len(g["paths"]) == 1 else "MultiLineString",
                "coordinates": g["paths"][0] if len(g["paths"]) == 1 else g["paths"]}
    if "x" in g and "y" in g:
        return {"type": "Point", "coordinates": [g["x"], g["y"]]}
    return None


def _arcgis_query(base_url, layer_id, bbox, timeout=90, fmt="geojson", referer=None):
    """Interroga un layer ArcGIS REST (MapServer) per bbox, ritorna (features_geojson, err).
    bbox = [S, N, W, E].
    fmt='geojson' (SITR Sicilia) oppure 'json' (Esri nativo, per servizi che rifiutano
    geojson con HTTP 400 — es. PPTR Puglia); referer opzionale per servizi che filtrano
    le richieste senza header Referer."""
    S, N, W, E = bbox
    envelope = "%f,%f,%f,%f" % (W, S, E, N)
    params = {"f": fmt, "where": "1=1", "geometry": envelope,
              "geometryType": "esriGeometryEnvelope", "inSR": "4326",
              "spatialRel": "esriSpatialRelIntersects", "outFields": "*",
              "outSR": "4326", "returnGeometry": "true"}
    headers = {"User-Agent": UA}
    if referer:
        headers["Referer"] = referer
    url = "%s/%d/query" % (base_url, layer_id)
    ultimo = "sconosciuto"
    for tentativo in range(3):
        if _annullato():
            return [], "annullato dall'utente"
        resta = _residuo()
        if resta <= 2:
            # tre tentativi da 90 s con backoff sono oltre quattro minuti su un
            # solo layer: oltre il budget si rinuncia dichiarandolo
            return [], "%s | budget dello stadio esaurito: layer NON interrogato" % ultimo
        try:
            r = requests.get(url, params=params, headers=headers,
                             timeout=_timeout_req(min(timeout, resta)))
            if r.status_code == 200:
                try:
                    j = r.json()
                except Exception:  # noqa: BLE001
                    return [], "risposta non-JSON"
                if fmt == "geojson":
                    return j.get("features", []), None
                # formato Esri json -> converto in feature geojson
                feats = []
                for f in j.get("features", []):
                    feats.append({"type": "Feature",
                                  "properties": f.get("attributes", {}),
                                  "geometry": _esri_to_geojson_geom(f.get("geometry"))})
                return feats, None
            ultimo = "HTTP %s" % r.status_code
        except Exception as e:  # noqa: BLE001
            ultimo = str(e)
        if tentativo < 2:
            _attesa(2 * (tentativo + 1))
    return [], ultimo


def vincoli_142_sicilia(comune_geom, bbox, provincia, raccogli_geometrie=False):
    """Fasce/vincoli art.142 e art.136 dal geoportale Regione Siciliana (SITR),
    quando il comune è in Sicilia. La Sicilia non è in SITAP: qui i vincoli sono
    poligoni VERI (costa 300 m lett.a, fiumi 150 m lett.c, boschi lett.g, art.136).

    Ritorna (trovati, geometrie, coperta, errori). `coperta`=False se la provincia
    non è mappata (allora il chiamante usa il fallback ex lege).
    """
    prov = (provincia or "").strip().lower()
    # normalizza 'città metropolitana di messina' -> 'messina', 'libero consorzio…'
    for k in SICILIA_PROV_SERVIZI:
        if k in prov:
            prov = k
            break
    servizi = SICILIA_PROV_SERVIZI.get(prov)
    if not servizi:
        return [], [], False, []
    trovati = []
    geometrie = []
    errori = []
    visti = set()   # (chiave) per non duplicare se più ambiti rispondono
    for serv in servizi:
        base = SICILIA_REST % serv
        layers = SICILIA_142_LAYERS.get(serv, {})
        for chiave_l, lid in layers.items():
            if chiave_l in visti:
                continue
            desc = SICILIA_142_DESC.get(chiave_l, chiave_l)
            feats, err = _arcgis_query(base, lid, bbox)
            if err:
                errori.append("%s (%s id %d): %s" % (desc, serv, lid, err))
                continue
            n_int = 0
            inters = []
            for f in feats:
                if not f.get("geometry"):
                    continue
                try:
                    g = shape(f["geometry"])
                    if not g.is_valid:
                        g = g.buffer(0)
                except Exception:  # noqa: BLE001
                    continue
                if comune_geom is not None and g.intersects(comune_geom):
                    n_int += 1
                    try:
                        gi = g.intersection(comune_geom)
                        inters.append(gi)
                    except Exception:  # noqa: BLE001
                        gi = None
                    if raccogli_geometrie:
                        etich_geo = "%s%s" % (
                            "Fascia costiera 300 m" if chiave_l == "a_costa" else
                            "Fascia fiumi 150 m" if chiave_l == "c_fiumi" else
                            "Area boscata art.142g" if chiave_l == "g_boschi" else
                            "Vincolo art.136", "")
                        if gi is not None and not gi.is_empty:
                            import json as _json
                            from shapely.geometry import mapping as _mapping
                            f_clip = {"type": "Feature",
                                      "properties": {"vincolo": desc},
                                      "geometry": _json.loads(_json.dumps(_mapping(gi)))}
                            geometrie.append((desc, f_clip))
                        else:
                            geometrie.append((desc, f))
            if n_int:
                visti.add(chiave_l)
                area_int = 0.0
                if inters:
                    try:
                        from shapely.ops import unary_union
                        u = unary_union(inters)
                        if not u.is_valid:
                            u = u.buffer(0)
                        area_int = u.area
                    except Exception:  # noqa: BLE001
                        area_int = max((x.area for x in inters), default=0.0)
                pct = (area_int / comune_geom.area * 100) if comune_geom and comune_geom.area else 0.0
                chiave_v = "art136" if chiave_l == "art136" else "art142"
                trovati.append({"chiave": chiave_v, "layer": "SITR:%s/%d" % (serv, lid),
                                "etichetta": desc, "n_poligoni": n_int,
                                "pct_territorio": round(min(pct, 100.0), 1)})
    return trovati, geometrie, True, errori


def vincoli_pptr_puglia(bbox, raccogli_geometrie=False):
    """Componenti insediative UCP del PPTR Puglia (SIT Puglia, ArcGIS REST),
    quando il comune è in Puglia. Fase 1: 'Città consolidata' (layer 54).

    Gli UCP NON sono vincolo ex D.Lgs 42/2004: per lo scavo interrato sono di
    norma fatti salvi, ma per manufatti fuori terra (armadi ottici) attivano una
    valutazione paesaggistica di competenza regionale/comunale (NTA PPTR art.77).

    Ritorna (trovati, geometrie). `trovati` è una lista di dict con chiave,
    etichetta, n_poligoni; `geometrie` è la lista (etichetta, feature_geojson).
    """
    trovati, geometrie = [], []
    for lid, desc in PUGLIA_PPTR_LAYERS.items():
        feats, err = _arcgis_query(PUGLIA_PPTR_REST, lid, bbox,
                                   fmt="json", referer=PUGLIA_PPTR_REFERER)
        if err or not feats:
            continue
        polys = []
        for f in feats:
            g = f.get("geometry")
            if not g:
                continue
            try:
                sh = shape(g)
                if not sh.is_valid:
                    sh = sh.buffer(0)
                polys.append(sh)
                if raccogli_geometrie:
                    geometrie.append((desc, f))
            except Exception:  # noqa: BLE001
                continue
        if polys:
            trovati.append({"chiave": "ucp_pptr", "layer": "PPTR:%d" % lid,
                            "etichetta": desc, "n_poligoni": len(polys),
                            "_geoms": polys})
    return trovati, geometrie


def analizza_armadi(armadi, geometrie_vincoli, ucp_puglia=None):
    """Per ogni armadio ottico (manufatto FUORI TERRA, visibile) verifica la
    sovrapposizione con i vincoli paesaggistici/percettivi e determina la
    competenza autorizzativa.

    Regola giuridica (D.Lgs 42/2004): lo scavo interrato non altera l'aspetto
    esteriore (art.149, di norma esente); un armadio fuori terra SÌ, quindi in
    area tutelata attiva l'autorizzazione paesaggistica (art.146).

    Gruppo A — vincoli formali 42/2004 (art.136, art.142): parere Soprintendenza
      VINCOLANTE (art.146). Vale su tutta Italia (fonte SITAP / geoportale reg.).
    Gruppo B — UCP regionali (es. 'Città consolidata' PPTR Puglia): valutazione
      paesaggistica di competenza REGIONE/COMUNE (NON Soprintendenza), salvo che
      l'armadio ricada ANCHE in un Gruppo A → allora Soprintendenza obbligatoria.

    `armadi`: lista di dict {id, tipo, indirizzo, civico, lon, lat}.
    `geometrie_vincoli`: lista (etichetta, feature_geojson) — i vincoli 42/2004
       raccolti dallo screening (SITAP art.136/142, geoportali regionali).
    `ucp_puglia`: lista di poligoni shapely degli UCP (Città consolidata), opz.

    Ritorna una lista di dict per armadio: {id, tipo, indirizzo, gruppo_a[],
    gruppo_b[], competenza, note}.
    """
    from shapely.geometry import Point

    # prepara le geometrie Gruppo A (vincoli 42/2004) come (etichetta, shape)
    geoms_a = []
    for etich, f in geometrie_vincoli or []:
        g = f.get("geometry") if isinstance(f, dict) else None
        if not g:
            continue
        try:
            sh = shape(g)
            if not sh.is_valid:
                sh = sh.buffer(0)
            # solo vincoli paesaggistici formali: 136 e 142 (non natura2000/idro)
            el = etich.lower()
            if ("136" in el or "142" in el or "interesse pubblico" in el
                    or "costiera" in el or "fiumi" in el or "boscate" in el
                    or "boschi" in el):
                geoms_a.append((etich, sh))
        except Exception:  # noqa: BLE001
            continue

    ucp = ucp_puglia or []
    risultati = []
    for a in armadi or []:
        try:
            p = Point(float(a["lon"]), float(a["lat"]))
        except Exception:  # noqa: BLE001
            continue
        ga = [etich for etich, sh in geoms_a if sh.contains(p) or sh.intersects(p)]
        gb = []
        for sh in ucp:
            if sh.contains(p) or sh.intersects(p):
                gb.append("Città consolidata (UCP PPTR)")
                break
        # competenza
        if ga:
            comp = "Soprintendenza (parere vincolante art.146 D.Lgs 42/2004)"
        elif gb:
            comp = "Regione/Comune (valutazione paesaggistica UCP, NTA PPTR art.77)"
        else:
            comp = "nessun vincolo paesaggistico rilevato sull'armadio"
        note = []
        if ga or gb:
            note.append("Manufatto fuori terra in area tutelata: verificare "
                         "assoggettabilità ad autorizzazione paesaggistica.")
            note.append("Possibile procedura semplificata DPR 31/2017 "
                         "(All. A esenzioni / All. B semplificata) per manufatti "
                         "tecnologici minori: verificare dimensioni e collocazione.")
        risultati.append({
            "id": a.get("id") or a.get("indirizzo") or "armadio",
            "tipo": a.get("tipo", ""),
            "indirizzo": a.get("indirizzo", ""),
            "civico": a.get("civico", ""),
            "lon": a.get("lon"), "lat": a.get("lat"),
            "gruppo_a": ga, "gruppo_b": gb,
            "vincolato": bool(ga or gb),
            "competenza": comp, "note": note,
        })
    return risultati


def _eea_query(layer_id, bbox):
    """Interroga un layer del servizio EEA Natura2000 (ArcGIS REST) per bbox.
    bbox = [S, N, W, E] (come da risolvi_comune). Ritorna (features_geojson, err).
    Con retry: il servizio EEA è generalmente stabile ma può avere picchi."""
    S, N, W, E = bbox
    envelope = "%f,%f,%f,%f" % (W, S, E, N)   # xmin,ymin,xmax,ymax
    params = {"f": "geojson", "where": "1=1", "geometry": envelope,
              "geometryType": "esriGeometryEnvelope", "inSR": "4326",
              "spatialRel": "esriSpatialRelIntersects", "outFields": "*",
              "outSR": "4326", "returnGeometry": "true"}
    url = "%s/%d/query" % (EEA_N2000, layer_id)
    ultimo = None
    for tentativo in range(3):
        if _annullato():
            return [], "annullato dall'utente"
        resta = _residuo()
        if resta <= 2:
            return [], "%s | budget dello stadio esaurito: layer NON interrogato" % (ultimo or "")
        try:
            r = requests.get(url, params=params, headers={"User-Agent": UA},
                             timeout=_timeout_req(min(90, resta)))
            if r.status_code == 200:
                return r.json().get("features", []), None
            ultimo = "HTTP %s" % r.status_code
        except Exception as e:  # noqa: BLE001
            ultimo = str(e)
        if tentativo < 2:
            _attesa(3 * (tentativo + 1))
    return [], ultimo


def natura2000_intercettati(comune_geom, bbox, raccogli_geometrie=False):
    """Siti Rete Natura 2000 (SIC/ZSC + ZPS) che intersecano il comune, da EEA.

    Ogni sito porta codice (SITECODE) e denominazione (SITENAME). Distingue i due
    regimi (Habitat/Uccelli). Il trigger della Valutazione di Incidenza (VIncA)
    scatta anche in PROSSIMITÀ, non solo dentro il sito: qui riportiamo i siti che
    intersecano il territorio comunale; l'analisi sul tracciato affina la distanza.
    """
    trovati = []
    errori = []
    geometrie = []
    for layer_id, etichetta in EEA_N2000_LAYERS:
        feats, err = _eea_query(layer_id, bbox)
        if err:
            errori.append("EEA layer %d (%s): %s" % (layer_id, etichetta, err))
            continue
        for f in feats:
            if not f.get("geometry"):
                continue
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is None or not g.intersects(comune_geom):
                continue
            p = f.get("properties", {}) or {}
            codice = (p.get("SITECODE") or p.get("sitecode") or p.get("CODE")
                      or p.get("code") or "?")
            nome = (p.get("SITENAME") or p.get("sitename") or p.get("NAME")
                    or p.get("name") or "sito senza nome")
            trovati.append({"tipo": etichetta, "codice": codice, "nome": nome})
            if raccogli_geometrie:
                try:
                    gi = g.intersection(comune_geom)
                    import json as _json
                    from shapely.geometry import mapping as _mapping
                    f_clip = {"type": "Feature",
                              "properties": {"vincolo": "Natura 2000 %s" % etichetta,
                                             "codice": codice, "nome": nome},
                              "geometry": _json.loads(_json.dumps(_mapping(
                                  gi if not gi.is_empty else g)))}
                    geometrie.append(("Natura 2000 — %s" % etichetta, f_clip))
                except Exception:  # noqa: BLE001
                    pass
    res = SourceResult(trovati, "EEA - Rete Natura 2000 (Agenzia Europea Ambiente)",
                       EEA_N2000, "EEA/Copernicus", autoritativo=True,
                       confidenza="alta" if trovati else "media",
                       note=errori + [
                           "La Valutazione di Incidenza (VIncA) può essere richiesta "
                           "anche per interventi in PROSSIMITÀ del sito, non solo "
                           "all'interno: verificare con l'ente gestore."])
    res.geometrie = geometrie
    return res


# Aree naturali protette (parchi) — SITAP: come le soprintendenze, il filtro bbox
# su questi poligoni giganti dà HTTP 400, quindi si scarica tutto il layer
# (poche decine di poligoni nazionali/regionali) e si fa il match spaziale locale.
PARCHI_LAYERS = [
    ("sitap_ws:vw_vasvia_parchi_nazionali", "Parco nazionale"),
    ("sitap_ws:vw_vasvia_parchi_regionali", "Parco regionale"),
]


def parchi_intercettati(comune_geom, raccogli_geometrie=False):
    """Aree naturali protette (parchi nazionali/regionali) che intersecano il
    comune, da SITAP. Scarica-tutte + match locale (il bbox rompe la query, 400).

    Ogni parco porta denominazione e codice EUAP. L'ente gestore va contattato
    per il nulla osta ex art. 13 L. 394/1991 (aree protette)."""
    if comune_geom is None:
        return SourceResult([], "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                            "Dati MiC", autoritativo=True, confidenza="bassa",
                            note=["Confine comunale non disponibile: parchi non verificabili."])
    trovati = []
    errori = []
    geometrie = []
    for typename, etichetta in PARCHI_LAYERS:
        feats, err = _wfs_tutte(typename)
        if err:
            errori.append("%s: %s" % (etichetta, err))
            continue
        for f in feats:
            g_raw = f.get("geometry")
            if not g_raw:
                continue
            try:
                g = shape(g_raw)
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if not g.intersects(comune_geom):
                continue
            p = f.get("properties", {}) or {}
            nome = (p.get("denominazione") or p.get("denominazi")
                    or p.get("nome") or "parco senza nome")
            euap = p.get("euap") or ""
            trovati.append({"tipo": etichetta, "nome": nome, "euap": euap})
            if raccogli_geometrie:
                try:
                    gi = g.intersection(comune_geom)
                    import json as _json
                    from shapely.geometry import mapping as _mapping
                    f_clip = {"type": "Feature",
                              "properties": {"vincolo": etichetta,
                                             "codice": euap, "nome": nome},
                              "geometry": _json.loads(_json.dumps(_mapping(
                                  gi if not gi.is_empty else g)))}
                    geometrie.append(("%s — %s" % (etichetta, nome), f_clip))
                except Exception:  # noqa: BLE001
                    pass
    res = SourceResult(trovati, "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                       "Dati MiC", autoritativo=True,
                       confidenza="alta" if trovati else "media", note=errori)
    res.geometrie = geometrie
    return res


# ---------------------------------------------------------------------------
# Composizione del report
# ---------------------------------------------------------------------------
def scheda_strada(classe):
    for s in carica_kb()["strade"]:
        if s["classe"] == classe:
            return s
    return None


def scheda_vincolo(chiave):
    for v in carica_kb()["vincoli"]:
        if v["chiave"] == chiave:
            return v
    return None


def gestore_regionale(classe, regione, provincia=None):
    """Gestore stradale probabile per una strada di classe `classe` nella
    regione `regione` (nome, case-insensitive), da kb 'gestori_regionali'.
    Ritorna (gestore, nota) o (None, None) se non mappato. È un SUGGERIMENTO da
    confermare, usato solo quando OSM non porta il tag operator.

    `provincia` sostituisce il segnaposto {provincia}: serve dove l'ente di
    area vasta dipende dal territorio e NON è una Provincia (gli EDR del
    Friuli, i Liberi Consorzi siciliani, le Province autonome)."""
    if not regione:
        return None, None
    kb = carica_kb()
    # "Trentino-Alto Adige/Südtirol", "Valle d'Aosta/Vallée d'Aoste" (OSM)
    reg = str(regione).split("/")[0].strip().lower()
    prov = _nome_provincia(provincia)
    metro = {m.lower() for m in kb.get("citta_metropolitane") or []}
    if classe == "A":
        return None, None          # autostrade: concessionario_autostrada(ref)
    for g in kb.get("gestori_regionali", []) or []:
        if g.get("regione", "").strip().lower() == reg:
            val = g.get(classe)
            if not val and classe == "SP" and prov:
                val = ("Citta' metropolitana di %s" % prov) if prov.lower() in metro \
                    else "Provincia di %s" % prov
            if val:
                if "{consorzio_sicilia}" in val:
                    val = val.replace("{consorzio_sicilia}",
                                      "Citta' metropolitana di" if prov and prov.lower() in metro
                                      else "Libero Consorzio comunale di")
                if "{provincia}" in val:
                    # senza provincia nota si lascia il posto vuoto esplicito,
                    # non un nome inventato
                    val = val.replace("{provincia}", prov or "(provincia da indicare)")
                return val, g.get("note")
            return None, g.get("note")
    if classe == "SP" and prov:
        return (("Citta' metropolitana di %s" % prov) if prov.lower() in metro
                else "Provincia di %s" % prov), None
    return None, None


def _nome_provincia(provincia):
    """'Provincia di Salerno' / 'Città metropolitana di Napoli' / 'Salerno' -> 'Salerno'."""
    p = str(provincia or "").strip()
    p = re.sub(r"(?i)^(provincia( autonoma)? di|citt[aà]'? metropolitana di|"
               r"libero consorzio comunale di|ente di decentramento regionale di)\s+", "", p)
    return p.split("/")[0].strip()


def concessionario_autostrada(ref):
    """Concessionario (o concessionari per tratta) di un'autostrada dalla kb
    'autostrade_concessionarie': 'A4' -> 'Torino-Milano: SATAP; ...'. None se
    la sigla non e' in elenco."""
    m = re.match(r"^\s*A\s*(\d+)", str(ref or "").upper())
    if not m:
        return None
    return (carica_kb().get("autostrade_concessionarie") or {}).get("A%s" % m.group(1))


def geoportale_regionale(regione):
    """Ritorna (portale_url, wfs_url) del geoportale della regione dalla kb
    'geoportali_regionali', per la verifica manuale dei vincoli quando SITAP non
    risponde. wfs_url e' '' se non c'e' un endpoint pubblico verificato.
    (None, None) se la regione non e' mappata."""
    if not regione:
        return None, None
    reg = str(regione).strip().lower()
    for g in carica_kb().get("geoportali_regionali", []) or []:
        if g.get("regione", "").strip().lower() == reg:
            return g.get("portale") or None, g.get("wfs") or ""
    return None, None


ANAS_REGIONE_URL = "https://www.stradeanas.it/it/anas_roads_region/search_roads_region"
ANAS_STRADA_URL = "https://www.stradeanas.it/anas_roads_region/search_roads_in_region"
_ANAS_CACHE = {}


def _anas_get(url, params, timeout=25):
    k = (url, tuple(sorted(params.items())))
    if k in _ANAS_CACHE:
        return _ANAS_CACHE[k]
    r = requests.get(url, params=params, headers={"User-Agent": UA}, timeout=timeout)
    r.raise_for_status()
    j = r.json()
    _ANAS_CACHE[k] = j
    return j


def _anas_regione(regione):
    """JSON «Anas per regione» (strade, Struttura territoriale) o None. ANAS
    scrive le regioni in maiuscolo con gli spazi (EMILIA ROMAGNA)."""
    base = re.sub(r"[-'’]", " ", (regione or "").upper())
    base = " ".join(base.split())
    for nome in (base, base.replace("D AOSTA", "D'AOSTA"), base.replace(" ", "")):
        try:
            j = _anas_get(ANAS_REGIONE_URL, {"regione": nome})
        except Exception:  # noqa: BLE001
            continue
        if j and j.get("strade"):
            j["_chiave"] = nome
            return j
    return None


def _km_anas(s):
    """'100,200' -> '100+200' (progressiva come nelle istanze)."""
    try:
        v = float(str(s).replace(",", "."))
    except (TypeError, ValueError):
        return str(s or "")
    km = int(v)
    return "%d+%03d" % (km, int(round((v - km) * 1000)))


def anas_verifica_strade(regione, refs, comune):
    """Controverifica sul sito ANAS («Anas per regione») delle strade statali
    del comune: per ogni ref (es. 'SS 71') le tratte di competenza ANAS (dal
    km al km, capisaldi), i centri abitati attraversati NEL COMUNE con i km e
    la classe di popolazione indicata da ANAS (inferiore/superiore a 10.000),
    e la Struttura territoriale con indirizzo e PEC.
    Ritorna {ref: dict} solo per le strade trovate; {} se il sito non risponde."""
    reg = _anas_regione(regione)
    if not reg:
        return {}
    struttura = {}
    for u in reg.get("uffici_territoriali") or []:
        testo = re.sub(r"<[^>]+>", " ", (u.get("indirizzo") or "") + " " +
                       (u.get("telefono") or ""))
        pec = re.findall(r"[\w.\-]+@postacert\.[\w.\-]+|[\w.\-]+@pec\.[\w.\-]+", testo)
        struttura = {"nome": "ANAS S.p.A. - %s" % (u.get("descrizione") or "").strip(),
                     "indirizzo": " ".join(re.sub(r"<[^>]+>", " ",
                                                  u.get("indirizzo") or "").split()),
                     "pec": pec[0] if pec else ""}
        break
    ids = {}
    for s in reg.get("strade") or []:
        m = re.match(r"^([A-Z]+)\s+(?:R\.A\.\s*)?([\d]+[A-Z/ .]*?)\s", (s.get("label") or "") + " ")
        if m:
            ids.setdefault("%s %s" % (m.group(1), m.group(2).strip()), s.get("id"))
    out = {}
    from unicodedata import normalize as _n

    def _norm(t):
        return " ".join(_n("NFKD", str(t or "")).encode("ascii", "ignore").decode()
                        .upper().replace("'", " ").split())
    for ref in refs:
        m = re.match(r"^\s*(SS|SR|RA|NSA|NS)\s*(\d+\s*[A-Z/]*)", str(ref).upper())
        if not m:
            continue
        chiave = "%s %s" % ("NS" if m.group(1) == "NSA" else m.group(1), m.group(2).strip())
        sid = ids.get(chiave)
        if not sid:
            if m.group(1) == "SS":
                # la regione risponde ma questa SS non c'e': in OSM porta ancora
                # la sigla statale ma ANAS non la gestisce (declassata o
                # trasferita a Regione/Provincia, o gestita da un ente regionale)
                out[ref] = {"id": "", "nome": chiave, "non_anas": True,
                            "regione": reg.get("compartimento") or regione,
                            "tratte": [], "centri_abitati": [], "struttura": {}}
            continue
        try:
            d = _anas_get(ANAS_STRADA_URL, {"regione": reg["_chiave"], "strada": sid})
        except Exception:  # noqa: BLE001
            continue
        centri = [c for c in d.get("centri_abitati") or []
                  if _norm(c.get("nome_comune")) == _norm(comune)]
        out[ref] = {
            "id": sid,
            "nome": ("%s %s" % ((d.get("tipologia") or "").strip('"'),
                                (d.get("nome_strada") or "").strip('"').replace(" - ", " "))
                     ).strip(),
            "tratte": [{"dal": _km_anas(t.get("dal")), "al": _km_anas(t.get("al")),
                        "capisaldi": t.get("capisaldi") or "",
                        "competenza": t.get("competenza") or ""}
                       for t in d.get("tratte") or []],
            "centri_abitati": [{"nome": c.get("nome_ca") or "", "dal": _km_anas(c.get("dal")),
                                "al": _km_anas(c.get("al")),
                                "sotto_10000": "inferior" in (c.get("inferiore") or "").lower()}
                               for c in centri],
            "struttura": struttura,
            # geometrie delle tratte (lon, lat), senza doppioni: servono a
            # calcolare le progressive quando mancano i cippi
            "geo": _anas_geo_unici(d.get("geo_tratte") or []),
            "tratte_m": [(_km_metri_anas(t.get("dal")), _km_metri_anas(t.get("al")))
                         for t in d.get("tratte") or []],
        }
    return out


def _km_metri_anas(s):
    try:
        return int(round(float(str(s).replace(",", ".")) * 1000))
    except (TypeError, ValueError):
        return None


def _anas_geo_unici(geo):
    out, visti = [], set()
    for g in geo:
        pts = [(p.get("lng"), p.get("lat")) for p in g if p.get("lng") is not None]
        if len(pts) < 2:
            continue
        k = (round(pts[0][0], 6), round(pts[0][1], 6), round(pts[-1][0], 6),
             round(pts[-1][1], 6), len(pts))
        if k in visti:
            continue
        visti.add(k)
        out.append(pts)
    return out


def nota_anas(info):
    """Testo per report ed Excel dalla verifica ANAS di una strada."""
    if not info:
        return ""
    if info.get("non_anas"):
        return ("Verifica sul sito ANAS: la %s NON risulta fra le strade gestite da ANAS in %s. "
                "Probabile strada declassata o trasferita (Regione, Provincia o ente regionale): "
                "verificare il gestore prima di intestare l'istanza ad ANAS."
                % (info.get("nome"), info.get("regione") or "regione"))
    parti = ["Verifica sul sito ANAS (Anas per regione): la %s è gestita da ANAS nelle tratte %s."
             % (info.get("nome") or info.get("id"),
                "; ".join("km %s-%s" % (t["dal"], t["al"]) for t in info["tratte"]) or "n/d")]
    for c in info.get("centri_abitati") or []:
        if c["sotto_10000"]:
            parti.append("Centro abitato %s dal km %s al km %s: secondo ANAS sotto i 10.000 "
                         "abitanti, quindi la strada resta ANAS anche dentro il centro abitato; "
                         "l'autorizzazione la rilascia il Comune previo nulla osta ANAS (art. 26 "
                         "c. 3 CdS), ma in pratica l'istanza si presenta anche ad ANAS."
                         % (c["nome"], c["dal"], c["al"]))
        else:
            parti.append("Centro abitato %s dal km %s al km %s: secondo ANAS sopra i 10.000 "
                         "abitanti, quindi in quel tratto la strada è comunale (art. 2 c. 7 CdS): "
                         "istanza al Comune." % (c["nome"], c["dal"], c["al"]))
    s = info.get("struttura") or {}
    if s.get("nome"):
        parti.append("Destinatario ANAS: %s, %s, PEC %s." % (s["nome"], s.get("indirizzo") or "",
                                                            s.get("pec") or "n/d"))
    return " ".join(parti)


RIF_COMPETENZA_STRADE = (
    "Rif. normativi: art. 2 c. 7, art. 4 e art. 26 cc. 2, 3 e 3-bis D.Lgs. 285/1992 "
    "(Codice della Strada); art. 49 D.Lgs. 259/2003 (Codice delle comunicazioni "
    "elettroniche).")


def nota_competenza_strada(classe, popolazione, ente_tipo):
    """Chi autorizza i lavori su una strada non comunale, secondo il centro
    abitato e la popolazione (testo per report ed Excel dello screening).
    - fuori dal centro abitato: l'ente proprietario (art. 26 c. 2 CdS);
    - centro abitato > 10.000 ab.: i tratti interni sono comunali per legge
      (art. 2 c. 7 CdS; Cass. civ. 3253/2012, Cons. Stato 403/2014) -> Comune;
    - centro abitato < 10.000 ab.: autorizza il Comune, previo nulla osta
      dell'ente proprietario (art. 26 c. 3 CdS), da rilasciare entro 15 giorni
      per la banda ultralarga (art. 26 c. 3-bis, art. 8-bis c. 4 DL 135/2018
      conv. L. 12/2019).
    Il dato giusto e' la popolazione del CENTRO ABITATO (perimetro deliberato
    dal Comune, art. 4 CdS): qui si usa quella del Comune come approssimazione.
    None per le classi senza regola (es. comunali)."""
    if classe == "A":
        return ("Autostrada: autorizza il concessionario, secondo la convenzione (art. 26 "
                "c. 2 CdS), anche dentro i centri abitati. " + RIF_COMPETENZA_STRADE)
    if classe not in ("SS", "SR", "SP"):
        return None
    fuori = ("Fuori dal centro abitato autorizza l'ente proprietario (%s), art. 26 c. 2 "
             "CdS." % ente_tipo)
    verifica = ("Quali tratti sono dentro il centro abitato si verifica sulla delibera di "
                "delimitazione del Comune (art. 4 CdS); conta la popolazione del centro "
                "abitato, qui approssimata con quella del Comune.")
    if popolazione is None:
        return ("Popolazione del Comune non nota: dentro i centri abitati sopra i 10.000 "
                "abitanti i tratti della strada sono comunali (art. 2 c. 7 CdS), sotto i "
                "10.000 autorizza il Comune previo nulla osta dell'ente proprietario "
                "(art. 26 c. 3 CdS). %s %s %s" % (fuori, verifica, RIF_COMPETENZA_STRADE))
    n = "{:,}".format(int(popolazione)).replace(",", ".")
    if popolazione > 10000:
        return ("Comune con %s ab. (oltre 10.000): i TRATTI INTERNI al centro abitato di "
                "questa strada sono comunali per legge (art. 2 c. 7 CdS; Cass. civ. "
                "3253/2012, Cons. Stato 403/2014): l'istanza va al COMUNE, non a %s. %s %s %s"
                % (n, ente_tipo, fuori, verifica, RIF_COMPETENZA_STRADE))
    return ("Comune con %s ab. (fino a 10.000): dentro il centro abitato la strada resta di "
            "%s, ma l'autorizzazione la rilascia il COMUNE previo NULLA OSTA dell'ente "
            "proprietario (art. 26 c. 3 CdS); per le reti a banda ultralarga il nulla osta va "
            "rilasciato entro 15 giorni dalla richiesta del Comune (art. 26 c. 3-bis CdS, "
            "introdotto dall'art. 8-bis c. 4 DL 135/2018 conv. L. 12/2019). %s %s %s"
            % (n, ente_tipo, fuori, verifica, RIF_COMPETENZA_STRADE))


def rfi_struttura(regione):
    """Ritorna la scheda della struttura territoriale RFI competente per la
    regione (dict con struttura/citta/pgos_range) dalla kb 'rfi_strutture', o
    None se non mappata. Usata per associare la struttura RFI corretta quando
    nel territorio c'e' una linea ferroviaria RFI."""
    if not regione:
        return None
    reg = str(regione).strip().lower()
    for r in carica_kb().get("rfi_strutture", []) or []:
        if r.get("regione", "").strip().lower() == reg:
            return r
    return None


_RE_GESTORE_RFI = re.compile(r"rete ferroviaria italiana|\brfi\b|ferrovie dello stato", re.I)


def gestore_ferrovia(etichetta, gestori=None):
    """Chi gestisce la linea: 'rfi', 'altro' (ferrovia regionale/in concessione,
    es. Ferrovie del Gargano, FAL, FSE, Ferrotramviaria) o 'ignoto' (OSM non
    riporta l'operatore). `gestori` = rep['_gestori_ferrovie'] {etichetta:
    operator o None}. Nei report di versioni precedenti la mappa manca: allora
    si giudica dall'etichetta e, se non nomina RFI, il gestore resta ignoto."""
    gestori = gestori or {}
    if etichetta in gestori:
        op = gestori[etichetta]
        if not op:
            return "ignoto"
        return "rfi" if _RE_GESTORE_RFI.search(op) else "altro"
    return "rfi" if (etichetta and _RE_GESTORE_RFI.search(etichetta)) else "ignoto"


def esegui_rfi(nome, provincia=None, avanzamento=None, annulla=None, budget_s=None):
    """Screening RISTRETTO per le istanze RFI, con budget e annullamento.

    `annulla` e' un callable senza argomenti che torna True quando l'utente
    chiede di fermarsi; `budget_s` e' il tetto complessivo in secondi
    (None = BUDGET_RFI_DEFAULT). Condivide con lo screening completo le due
    fonti lente (Nominatim e Overpass), quindi serve lo stesso tetto.
    """
    _avvia_budget(budget_s or BUDGET_RFI_DEFAULT, annulla)
    try:
        return _esegui_rfi_corpo(nome, provincia, avanzamento)
    finally:
        _chiudi_budget()


def _esegui_rfi_corpo(nome, provincia=None, avanzamento=None):
    """Screening RISTRETTO per la precompilazione delle istanze RFI: risolve il
    comune e cerca SOLO le ferrovie (niente strade, SITAP, vincoli paesaggistici,
    idrogeologico). Molto piu' veloce dello screening completo.
    Ritorna un dict compatibile con esegui() nei campi usati dalla scheda RFI:
    'comune' (nome/provincia/regione/cap/istat), 'ferrovie', 'ferrovie_dismesse'.
    In piu' 'rfi' con la struttura territoriale RFI competente (da rfi_struttura).
    """
    def _av(msg):
        if avanzamento:
            avanzamento(msg)

    rep = {"input": {"comune": nome, "provincia_hint": provincia},
           "warning": [], "fonti": [], "solo_rfi": True}

    _av("Nominatim: confine comunale (max %d s)…" % _apri_stadio("confine comunale"))
    c = risolvi_comune(nome, provincia)
    rep["fonti"].append({"stadio": "confine comunale", "fonte": c.fonte,
                         "confidenza": c.confidenza, "errore": c.errore})
    _chiudi_stadio(rep, "confine comunale",
                   "Confine comunale NON risolto: Nominatim non ha risposto entro %d s.",
                   ok=bool(c.data))
    if c.errore or not c.data:
        rep["errore"] = c.errore or "comune non risolto"
        if _annullato():
            rep["annullato"] = True
        return rep
    rep["warning"] += c.note
    rep["comune"] = {k: v for k, v in c.data.items() if k != "geometry"}
    _av("Comune: %s (%s, %s) — ISTAT %s" % (
        c.data["nome"], c.data["provincia"] or "n/d",
        c.data["regione"] or "n/d", c.data["istat"] or "n/d"))

    if _ferma(rep, _av, "interferenze lineari"):
        return rep
    _av("Overpass: ferrovie nel territorio, 4 endpoint con ritentativo (max %d s)…"
        % _apri_stadio("interferenze lineari"))
    il = interferenze_lineari(c.data["osm_relation_id"], con_geometrie=False)
    gestori = {}
    ferr, ferr_dism = set(), set()
    for e in il.data or []:
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            etich = t.get("operator") or t.get("name") or "linea ferroviaria"
            ferr.add(etich)
            gestori[etich] = t.get("operator")
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            ferr_dism.add(t.get("name") or "ex sedime ferroviario")
    rep["ferrovie"] = sorted(ferr)[:10]
    rep["_gestori_ferrovie"] = gestori
    rep["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    rep["fonti"].append({"stadio": "interferenze lineari", "fonte": il.fonte,
                         "confidenza": il.confidenza, "errore": il.errore})
    _chiudi_stadio(rep, "interferenze lineari",
                   "Ferrovie NON verificate: Overpass non ha risposto entro %d s — "
                   "un elenco vuoto qui NON significa assenza di linee ferroviarie.",
                   ok=bool(il.data))
    if il.errore:
        rep["warning"].append("Ferrovie NON verificate (Overpass irraggiungibile): %s" % il.errore)
    _av("Ferrovie: %s" % (", ".join(rep["ferrovie"]) or "nessuna rilevata"))

    # struttura RFI competente per regione (DOIT + PEC dalla kb)
    rep["rfi"] = rfi_struttura((rep.get("comune") or {}).get("regione"))
    if rep["rfi"]:
        _av("Struttura RFI: %s" % rep["rfi"].get("struttura", "?"))
    return rep


def esegui(nome, provincia=None, avanzamento=None, raccogli_geometrie=False,
           annulla=None, budget_s=None, bbox_osm=None):
    """Screening completo, limitato nel tempo e annullabile.

    `avanzamento(testo)` è chiamata tra gli stadi (il pannello la usa per il
    log e per tenere viva l'interfaccia) e dichiara COSA sta per essere
    interrogato e con quale attesa massima: un log fermo su una riga scritta
    PRIMA dello stadio non distingue un lavoro in corso da un blocco.
    `annulla` è un callable senza argomenti che torna True quando l'utente ha
    chiesto di fermarsi: viene interrogato prima di ogni richiesta di rete e
    fra uno stadio e l'altro; quando torna True si smette appena possibile e
    si torna un report PARZIALE con rep['annullato'] = True (nessuna eccezione).
    `budget_s` è il tetto complessivo in secondi (None = BUDGET_TOTALE_DEFAULT):
    quando scade, le fonti non interrogate vengono dichiarate NON verificate
    invece di risultare silenziosamente "senza vincoli".
    Con raccogli_geometrie=True il risultato porta anche gli elementi con
    geometria (strade/lineari da Overpass, vincoli da SITAP) per il
    caricamento in mappa.
    `bbox_osm` = (sud, ovest, nord, est) attorno alla rete di progetto: strade
    e opere lineari si chiedono a OSM solo lì (una richiesta, molto più
    veloce) invece che su tutto il territorio comunale."""
    scad = _avvia_budget(budget_s, annulla)
    try:
        rep = _esegui_corpo(nome, provincia, avanzamento, raccogli_geometrie, bbox_osm)
    finally:
        _chiudi_budget()
    if not isinstance(rep, dict):
        return rep
    rep["_tempo_s"] = round(scad.speso(), 1)
    rep["_budget_s"] = scad.budget
    if scad.annullato_visto:
        rep["annullato"] = True
        msg = ("Screening ANNULLATO dall'utente: il report è PARZIALE e le fonti non "
               "interrogate NON sono state verificate — non usarlo come esito di "
               "pre-istruttoria.")
        if msg not in rep.setdefault("warning", []):
            rep["warning"].insert(0, msg)
    if scad.abbandoni:
        rep["fonti_abbandonate"] = [{"stadio": n, "secondi": s} for n, s in scad.abbandoni]
    # un report interrotto deve restare USABILE: senza 'enti' il pannello e
    # l'export non hanno nulla da mostrare e l'interruzione sembra un errore
    if "enti" not in rep and rep.get("comune"):
        try:
            rep["enti"] = componi_enti(rep)
        except Exception as e:  # noqa: BLE001
            rep.setdefault("warning", []).append(
                "Elenco enti non ricomposto sul report parziale: %s" % e)
    for e in scad.errori_callback:
        msg = ("Il controllo di annullamento ha sollevato un errore (%s): lo screening "
               "è proseguito, ma il pulsante Annulla potrebbe non aver funzionato." % e)
        if msg not in rep.setdefault("warning", []):
            rep["warning"].append(msg)
    if avanzamento:
        avanzamento("Screening concluso in %.0f s (budget %.0f s)%s"
                    % (rep["_tempo_s"], scad.budget,
                       " — ANNULLATO dall'utente" if rep.get("annullato") else ""))
    return rep


def _esegui_corpo(nome, provincia=None, avanzamento=None, raccogli_geometrie=False,
                  bbox_osm=None):
    """Corpo dello screening: usa il budget aperto da esegui() tramite i
    controlli _ferma/_apri_stadio/_chiudi_stadio."""
    def _av(msg):
        if avanzamento:
            avanzamento(msg)

    rep = {"input": {"comune": nome, "provincia_hint": provincia}, "warning": [], "fonti": []}

    _av("Nominatim: confine comunale (max %d s)…" % _apri_stadio("confine comunale"))
    c = risolvi_comune(nome, provincia)
    rep["fonti"].append({"stadio": "confine comunale", "fonte": c.fonte,
                         "confidenza": c.confidenza, "errore": c.errore})
    _chiudi_stadio(rep, "confine comunale",
                   "Confine comunale NON risolto: Nominatim non ha risposto entro %d s — "
                   "senza confine nessuna fonte territoriale è interrogabile.",
                   ok=bool(c.data))
    if c.errore or not c.data:
        rep["errore"] = c.errore or "comune non risolto"
        # Senza confine comunale nessuno stadio successivo viene eseguito: vanno
        # dichiarati TUTTI, altrimenti il report esce con la tabella delle fonti
        # muta e si legge come "nessun vincolo trovato". Vale sia quando l'utente
        # annulla subito, sia quando Nominatim non risponde.
        motivo = ("screening annullato dall'utente prima di interrogare questa fonte"
                  if _annullato() else
                  "confine comunale non risolto: la fonte non \u00e8 stata interrogata")
        for st in _stadi_non_eseguiti("rete stradale"):
            _marca_fonte(rep, st,
                         "Stadio '%s' NON eseguito: %s. Nulla di questa fonte \u00e8 "
                         "stato verificato." % (st, motivo))
        if _annullato():
            rep["annullato"] = True
        return rep
    rep["warning"] += c.note
    geom = c.data["geometry"]
    rep["comune"] = {k: v for k, v in c.data.items() if k != "geometry"}
    rep["_geometria_comune"] = geom
    _av("Comune: %s (%s, %s) — ISTAT %s" % (
        c.data["nome"], c.data["provincia"] or "n/d",
        c.data["regione"] or "n/d", c.data["istat"] or "n/d"))

    # tutte le fonti indipendenti partono insieme (vedi _Anticipo)
    if _scadenze() is not None and not _annullato():
        osm_id, bbox = c.data["osm_relation_id"], c.data["bbox"]
        regione_a = (c.data.get("regione") or "").strip().lower()
        ant = _Anticipo()
        _LOCALE.anticipo = ant
        ant.avvia("osm", "rete stradale", strade_nel_comune, osm_id,
                  con_geometrie=raccogli_geometrie, bbox=bbox_osm)
        ant.avvia("osm", "interferenze lineari", interferenze_lineari, osm_id,
                  con_geometrie=raccogli_geometrie, bbox=bbox_osm)
        ant.avvia("osm", "linea di costa", _comune_costiero, osm_id, bbox)
        ant.avvia("sitap", "soprintendenze", soprintendenza_competente, geom, bbox)
        ant.avvia("sitap", "vincoli paesaggistici", vincoli_paesaggistici, geom, bbox,
                  raccogli_geometrie=raccogli_geometrie)
        ant.avvia("sitap", "aree protette (parchi)", parchi_intercettati, geom,
                  raccogli_geometrie=raccogli_geometrie)
        if "sicilia" not in regione_a:
            ant.avvia("sitap", "fasce art.142 (costa/fiumi)", fasce_142_regionali, geom, bbox,
                      c.data.get("regione"), raccogli_geometrie=raccogli_geometrie)
        ant.avvia("altro", "rete natura 2000", natura2000_intercettati, geom, bbox,
                  raccogli_geometrie=raccogli_geometrie)
        ant.avvia("altro", "siti contaminati e bonifiche", siti_contaminati, bbox,
                  raccogli_geometrie=raccogli_geometrie)
        ant.avvia("altro", "pericolosità idrogeologica", pericolosita_idrogeologica,
                  c.data.get("istat"))
        _av("Fonti interrogate in parallelo (OSM, SITAP, EEA, ISPRA): lo screening "
            "aspetta la più lenta invece di sommarle.")
        if bbox_osm is not None:
            _av("OpenStreetMap: strade, ferrovie, corsi d'acqua e boschi cercati attorno "
                "alla rete di progetto (una richiesta), non su tutto il comune.")

    if _ferma(rep, _av, "rete stradale"):
        return rep
    _av("Overpass: rete stradale classificata, 4 endpoint con ritentativo (max %d s)…"
        % _apri_stadio("rete stradale"))
    st = _prendi("rete stradale", strade_nel_comune, c.data["osm_relation_id"],
                 con_geometrie=raccogli_geometrie, bbox=bbox_osm)
    rep["fonti"].append({"stadio": "rete stradale", "fonte": st.fonte,
                         "confidenza": st.confidenza, "errore": st.errore})
    _chiudi_stadio(rep, "rete stradale",
                   "Rete stradale NON verificata: Overpass non ha risposto entro %d s — "
                   "l'elenco delle strade è vuoto o parziale, NON significa che non ci "
                   "siano strade classificate da autorizzare.", ok=bool(st.data))
    cls = classifica_strade(st.data) if st.data else {"strade": {}, "way_classificate_senza_ref": 0}
    rep["rete_stradale"] = cls["strade"]
    rep["warning"] += rileva_incoerenze(cls["strade"], (rep.get("comune") or {}).get("nome"))
    if st.errore:
        rep["warning"].append("Rete stradale NON verificata (Overpass irraggiungibile): %s" % st.errore)
    if raccogli_geometrie:
        rep["_elementi_strade"] = st.data
    n_str = sum(len(v) for v in cls["strade"].values())
    _av("Strade classificate: %d (classi: %s)" % (
        n_str, ", ".join("%s×%d" % (k, len(v)) for k, v in sorted(cls["strade"].items())) or "nessuna"))
    # controverifica sul sito ANAS delle strade statali: tratte di competenza,
    # centri abitati (con la classe di popolazione) e Struttura territoriale
    ss = list((cls["strade"].get("SS") or {}).keys())
    if ss and c.data.get("regione"):
        try:
            rep["anas"] = anas_verifica_strade(c.data["regione"], ss, c.data["nome"])
            _av("Sito ANAS: verificate %d strade statali su %d" % (len(rep["anas"]), len(ss)))
        except Exception as e:  # noqa: BLE001
            rep["anas"] = {}
            rep["warning"].append("Verifica sul sito ANAS non riuscita: %s" % e)

    if _ferma(rep, _av, "soprintendenze"):
        return rep
    _av("SITAP WFS: Soprintendenze ABAP competenti, 2 layer nazionali (max %d s)…"
        % _apri_stadio("soprintendenze"))
    so = _prendi("soprintendenze", soprintendenza_competente, geom, c.data["bbox"])
    rep["fonti"].append({"stadio": "soprintendenze", "fonte": so.fonte,
                         "confidenza": so.confidenza, "errore": so.errore})
    _chiudi_stadio(rep, "soprintendenze",
                   "SITAP non ha risposto entro %d s: la Soprintendenza ABAP competente "
                   "NON è stata individuata — va ricavata manualmente prima di inviare "
                   "qualunque istanza.", ok=bool(so.data))
    rep["soprintendenze"] = so.data
    rep["warning"] += [n for n in so.note if n]
    for s in so.data or []:
        _av("  %s: %s (%s%% del territorio)" % (s["ambito"], s["denominazione"], s["quota_territorio"]))

    if _ferma(rep, _av, "vincoli paesaggistici"):
        return rep
    _av("SITAP WFS: vincoli paesaggistici nazionali, %d layer (max %d s)…"
        % (len(VINCOLI_LAYERS), _apri_stadio("vincoli paesaggistici")))
    vi = _prendi("vincoli paesaggistici", vincoli_paesaggistici, geom, c.data["bbox"],
                 raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "vincoli paesaggistici", "fonte": vi.fonte,
                         "confidenza": vi.confidenza, "errore": vi.errore})
    _chiudi_stadio(rep, "vincoli paesaggistici",
                   "SITAP non ha risposto entro %d s: i vincoli paesaggistici (art. 136/142) "
                   "NON sono stati verificati — l'assenza di vincoli in questo report non è "
                   "una dichiarazione di assenza di vincoli.", ok=bool(vi.data))
    rep["vincoli"] = vi.data
    if raccogli_geometrie:
        rep["_geometrie_vincoli"] = getattr(vi, "geometrie", [])
    for v in vi.data:
        _av("  %s: %d poligoni (%s%% del territorio)" % (v["etichetta"], v["n_poligoni"], v["pct_territorio"]))
    # se SITAP ha avuto errori sui vincoli, rimanda al geoportale regionale per
    # la verifica manuale (fallback): meglio un link giusto che un buco muto
    # Nota: vi.note contiene SEMPRE il disclaimer "SITAP è ricognitivo": per
    # capire se la fonte ha davvero fallito vanno guardati gli errori sui layer,
    # altrimenti si dichiarerebbe "non verificato" anche un run perfettamente
    # riuscito senza vincoli.
    guasti_sitap = [n for n in (getattr(vi, "note", None) or [])
                    if n and not n.startswith("SITAP è ricognitivo")]
    if (vi.errore or guasti_sitap) and not vi.data:
        # nessun vincolo trovato MA la fonte ha avuto errori: non è "nessun
        # vincolo", è "non verificato", e va detto con queste parole
        rep.setdefault("warning", []).append(
            "SITAP non ha risposto correttamente: i vincoli paesaggistici (art. 136/142) "
            "NON sono stati verificati. L'assenza di vincoli in questo report NON è una "
            "dichiarazione di assenza di vincoli.")
        _marca_fonte(rep, "vincoli paesaggistici",
                     "SITAP incompleto o irraggiungibile: vincoli paesaggistici NON verificati.")
    if vi.errore or getattr(vi, "note", None):
        portale, wfs = geoportale_regionale(c.data.get("regione"))
        if portale:
            msg = ("Vincoli SITAP con errori/parziali per questo run: verificare i "
                   "vincoli paesaggistici (art. 136/142) sul geoportale di %s → %s"
                   % (c.data.get("regione") or "regione", portale))
            if wfs:
                msg += " (WFS: %s)" % wfs
            rep.setdefault("warning", []).append(msg)
            _av("  ⚠ SITAP incompleto: fallback geoportale %s" % (c.data.get("regione") or ""))

    if _ferma(rep, _av, "rete natura 2000"):
        return rep
    _av("EEA: Rete Natura 2000, SIC/ZSC e ZPS (max %d s)…" % _apri_stadio("rete natura 2000"))
    n2k = _prendi("rete natura 2000", natura2000_intercettati, geom, c.data["bbox"],
                  raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "rete natura 2000", "fonte": n2k.fonte,
                         "confidenza": n2k.confidenza, "errore": n2k.errore})
    _chiudi_stadio(rep, "rete natura 2000",
                   "EEA non ha risposto entro %d s: i siti Rete Natura 2000 NON sono stati "
                   "verificati — la Valutazione di Incidenza non può essere esclusa su "
                   "questo report.", ok=bool(n2k.data))
    rep["natura2000"] = n2k.data
    rep["warning"] += [x for x in n2k.note if x and x not in rep["warning"]]
    if raccogli_geometrie and getattr(n2k, "geometrie", None):
        rep.setdefault("_geometrie_vincoli", [])
        rep["_geometrie_vincoli"] += n2k.geometrie
    for s in n2k.data or []:
        _av("  %s — %s (%s)" % (s["codice"], s["nome"], s["tipo"]))
    if not n2k.data and not n2k.errore:
        _av("  nessun sito Natura 2000 nel territorio comunale")

    if _ferma(rep, _av, "aree protette (parchi)"):
        return rep
    _av("SITAP WFS: aree naturali protette, parchi nazionali/regionali (max %d s)…"
        % _apri_stadio("aree protette (parchi)"))
    prc = _prendi("aree protette (parchi)", parchi_intercettati, geom,
                  raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "aree protette (parchi)", "fonte": prc.fonte,
                         "confidenza": prc.confidenza, "errore": prc.errore})
    _chiudi_stadio(rep, "aree protette (parchi)",
                   "SITAP non ha risposto entro %d s: le aree naturali protette NON sono "
                   "state verificate — il nulla osta ex art. 13 L. 394/1991 non può essere "
                   "escluso su questo report.", ok=bool(prc.data))
    rep["parchi"] = prc.data
    rep["warning"] += [x for x in prc.note if x and x not in rep["warning"]]
    if raccogli_geometrie and getattr(prc, "geometrie", None):
        rep.setdefault("_geometrie_vincoli", [])
        rep["_geometrie_vincoli"] += prc.geometrie
    for s in prc.data or []:
        _av("  %s%s (%s)" % (s["nome"], (" [%s]" % s["euap"]) if s.get("euap") else "", s["tipo"]))
    if not prc.data and not prc.errore:
        _av("  nessuna area protetta nel territorio comunale")

    if _ferma(rep, _av, "siti contaminati e bonifiche"):
        return rep
    _av("ISPRA/MOSAICO: siti contaminati e procedimenti di bonifica (max %d s)…"
        % _apri_stadio("siti contaminati e bonifiche"))
    sc = _prendi("siti contaminati e bonifiche", siti_contaminati, c.data["bbox"],
                 raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "siti contaminati e bonifiche", "fonte": sc.fonte,
                         "confidenza": sc.confidenza, "errore": sc.errore})
    _chiudi_stadio(rep, "siti contaminati e bonifiche",
                   "ISPRA/MOSAICO non ha risposto entro %d s: SIN e procedimenti di bonifica "
                   "NON sono stati verificati — vanno controllati prima di movimentare "
                   "terreno.", ok=bool(sc.data))
    rep["siti_contaminati"] = sc.data
    rep["warning"] += [x for x in sc.note if x and x not in rep["warning"]]
    if raccogli_geometrie and getattr(sc, "geometrie", None):
        rep.setdefault("_geometrie_vincoli", [])
        rep["_geometrie_vincoli"] += sc.geometrie
    if sc.data:
        for x in sc.data["sin"]:
            _av("  SIN: %s" % (x["nome"] or x["codice"]))
        _av("  procedimenti di bonifica: %d totali, %d aperti"
            % (sc.data["procedimenti_totali"], sc.data["procedimenti_aperti"]))
        for a in sc.data["arpa_competenti"]:
            _av("  ARPA competente: %s" % a)

    _av("ARPA/APPA in Conferenza di Servizi (prassi regionale)…")
    ar = arpa_in_conferenza((rep.get("comune") or {}).get("regione"),
                            (rep.get("comune") or {}).get("provincia"))
    rep["fonti"].append({"stadio": "ARPA in Conferenza di Servizi", "fonte": ar.fonte,
                         "confidenza": ar.confidenza, "errore": ar.errore})
    rep["arpa_cds"] = ar.data
    rep["warning"] += [x for x in ar.note if x and x not in rep["warning"]]
    if ar.data:
        _av("  %s — PEC: %s" % (ar.data.get("agenzia"), ar.data.get("pec_competente")))
    else:
        _av("  nessuna prassi verificata per questa regione")

    if _ferma(rep, _av, "interferenze lineari"):
        return rep
    _av("Overpass: ferrovie, corsi d'acqua e aree boscate, 4 endpoint con ritentativo (max %d s)…"
        % _apri_stadio("interferenze lineari"))
    il = _prendi("interferenze lineari", interferenze_lineari, c.data["osm_relation_id"],
                 con_geometrie=raccogli_geometrie, bbox=bbox_osm)
    ferr, ferr_dism, acque = set(), set(), set()
    gestori = {}
    acque_nat, bonifica = set(), set()
    boschi = set()
    for e in il.data or []:
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            etich = t.get("operator") or t.get("name") or "linea ferroviaria"
            ferr.add(etich)
            gestori[etich] = t.get("operator")
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            ferr_dism.add(t.get("name") or "ex sedime ferroviario")
        if t.get("waterway") in {"river", "stream", "canal", "ditch", "drain"}:
            # anche i rii demaniali senza nome sono corsi d'acqua rilevanti:
            # scartarli per assenza di 'name' perdeva interferenze reali.
            # Distinguiamo il reticolo NATURALE (demanio idrico, R.D. 523 + fascia
            # paesaggistica 150 m) dal reticolo di BONIFICA (Consorzio, fascia da
            # regolamento consortile): il regime e l'ente competente sono diversi.
            cat, tipo_l = tipo_corso_acqua(t)
            nome_acq = t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"]
            acque.add(nome_acq)
            if cat == "bonifica":
                bonifica.add(nome_acq)
            else:
                acque_nat.add(nome_acq)
        if t.get("natural") == "wood" or t.get("landuse") == "forest":
            # aree boscate: vincolo paesaggistico ex lege art.142 lett.g D.Lgs
            # 42/2004 (i boschi sono vincolati per legge, cartografati o meno)
            nome_b = t.get("name") or "area boscata senza nome"
            boschi.add(nome_b)
            # raccogli la geometria del bosco per lo shape delle tavole (art.142g):
            # gli elementi Overpass 'way' con natural=wood portano 'geometry' (lista
            # di nodi) quando la query è stata fatta con 'out geom'. Chiudiamo l'anello
            # in un poligono. Le relation (multipolygon) non hanno geom diretta: saltate.
            if raccogli_geometrie:
                geo = e.get("geometry")
                if geo and len(geo) >= 3:
                    coords = [[p["lon"], p["lat"]] for p in geo if "lon" in p and "lat" in p]
                    if len(coords) >= 3:
                        if coords[0] != coords[-1]:
                            coords.append(coords[0])   # chiudi l'anello
                        f_b = {"type": "Feature",
                               "properties": {"vincolo": "Area boscata art.142 lett.g",
                                              "nome": nome_b},
                               "geometry": {"type": "Polygon", "coordinates": [coords]}}
                        rep.setdefault("_geometrie_vincoli", [])
                        rep["_geometrie_vincoli"].append(
                            ("Area boscata (art.142 lett.g) — %s" % nome_b, f_b))
    rep["ferrovie"] = sorted(ferr)[:10]
    rep["_gestori_ferrovie"] = gestori
    rep["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    rep["corsi_acqua"] = sorted(acque)[:15]
    rep["corsi_acqua_naturali"] = sorted(acque_nat)[:15]
    rep["canali_bonifica"] = sorted(bonifica)[:15]
    rep["boschi"] = sorted(boschi)[:15]
    rep["fonti"].append({"stadio": "interferenze lineari", "fonte": il.fonte,
                         "confidenza": il.confidenza, "errore": il.errore})
    _chiudi_stadio(rep, "interferenze lineari",
                   "Overpass non ha risposto entro %d s: ferrovie, corsi d'acqua e aree "
                   "boscate NON sono stati verificati — nessun nulla osta idraulico o "
                   "ferroviario può essere escluso su questo report.", ok=bool(il.data))
    if il.errore:
        rep["warning"].append(
            "Ferrovie e corsi d'acqua NON verificati (Overpass irraggiungibile): "
            "%s — un elenco vuoto qui non significa assenza di interferenze." % il.errore)
    elif not ferr and not acque and not ferr_dism:
        # query riuscita ma nulla trovato: in una pre-istruttoria l'assenza in
        # OSM non è probante (OSM non è esaustivo su reticolo idrografico/RFI)
        rep["warning"].append(
            "Nessuna interferenza lineare (ferrovie/corsi d'acqua) rilevata in OSM: "
            "OSM NON è esaustivo — verificare su CTR/RFI e sul reticolo idrografico "
            "regionale prima di escludere nulla osta idraulici o ferroviari.")
    if raccogli_geometrie:
        rep["_elementi_lineari"] = il.data
    if il.errore:
        # Overpass non ha risposto: "0" qui vorrebbe dire "non cercato", non
        # "assente". Il registro lo deve dire come lo dice il report.
        _av("  ⚠ Ferrovie e corsi d'acqua NON verificati (Overpass non ha risposto): "
            "NON significa che non ci siano")
    else:
        _av("Ferrovie: %d gestori/linee · corsi d'acqua denominati: %d" % (len(ferr), len(acque)))

    # -- fasce art.142 lett.a (costa 300 m) e lett.c (fiumi 150 m) --
    # SITAP le pubblica come layer REGIONALI (solo alcune regioni). Dove la regione
    # è coperta, interroghiamo il layer giusto; dove non lo è (es. Sicilia) attiviamo
    # il fallback "vincolo probabile" (costiero -> lett.a; corsi d'acqua -> lett.c).
    if _ferma(rep, _av, "fasce art.142 (costa/fiumi)"):
        return rep
    _av("Fasce paesaggistiche art.142, costa 300 m / fiumi 150 m (max %d s)…"
        % _apri_stadio("fasce art.142 (costa/fiumi)"))
    ha_corsi = bool(rep.get("corsi_acqua"))
    costiero = _prendi("linea di costa", _comune_costiero, c.data["osm_relation_id"],
                       c.data["bbox"])
    if costiero is None:
        rep["warning"].append(
            "Linea di costa NON verificata (Overpass non ha risposto): se il comune è "
            "costiero opera ex lege la fascia di 300 m (art. 142 c.1 lett. a).")
        _av("  ⚠ linea di costa non verificata (Overpass non ha risposto)")
    regione_l = (c.data.get("regione") or "").strip().lower()

    # 1) Sicilia: NON è in SITAP ma pubblica i vincoli art.142/136 come poligoni veri
    #    sul geoportale SITR (per provincia/ambito). Provalo per primo.
    f142, geom142, err142 = [], [], []
    coperta142 = False
    fonte142 = None
    if "sicilia" in regione_l:
        prov = (c.data.get("provincia") or "")
        fs, gs, cop_sic, es = vincoli_142_sicilia(
            geom, c.data["bbox"], prov, raccogli_geometrie=raccogli_geometrie)
        if cop_sic and fs:
            f142, geom142, err142, coperta142 = fs, gs, es, True
            fonte142 = "Geoportale Regione Siciliana (SITR)"

    # 2) altre regioni: layer SITAP regionali art.142
    if not coperta142 and "sicilia" not in regione_l:
        f142, geom142, coperta142, err142 = _prendi(
            "fasce art.142 (costa/fiumi)", fasce_142_regionali,
            geom, c.data["bbox"], c.data.get("regione"), raccogli_geometrie=raccogli_geometrie)
        if coperta142:
            fonte142 = "SITAP - layer regionali art.142"

    rep["fonti"].append({"stadio": "fasce art.142 (costa/fiumi)",
                         "fonte": fonte142 or "fallback ex lege (regione non coperta)",
                         "confidenza": "media" if coperta142 else "bassa",
                         "errore": "; ".join(err142) if err142 else None})
    _chiudi_stadio(rep, "fasce art.142 (costa/fiumi)",
                   "Le fasce art.142 (costa 300 m / fiumi 150 m) NON sono state verificate: "
                   "la fonte non ha risposto entro %d s. Operano EX LEGE anche se non "
                   "cartografate: vanno controllate sul geoportale regionale.",
                   ok=bool(coperta142 and f142))
    if coperta142:
        # aggiungi le fasce trovate ai vincoli (così finiscono in enti, Excel, shape)
        rep.setdefault("vincoli", [])
        rep["vincoli"] += f142
        if raccogli_geometrie and geom142:
            rep.setdefault("_geometrie_vincoli", [])
            rep["_geometrie_vincoli"] += geom142
        for v in f142:
            _av("  %s: %d poligoni (%s%% del territorio)" % (v["etichetta"], v["n_poligoni"], v["pct_territorio"]))
        if not f142:
            _av("  nessuna fascia art.142 (costa/fiumi) intercettata nei layer regionali")
    else:
        # regione senza layer art.142: fallback attivo (avviso ex lege)
        probabili = fasce_142_probabili(geom, c.data["bbox"], costiero, ha_corsi)
        for p in probabili:
            rep.setdefault("warning", []).append(p)
            _av("  ⚠ %s" % p.split(":")[0])
        if not probabili:
            _av("  nessun segnale di fascia art.142 (%s, nessun corso d'acqua)"
                % ("costa non verificata" if costiero is None else "comune non costiero"))
        portale, _wfs = geoportale_regionale(c.data.get("regione"))
        if portale:
            rep.setdefault("warning", []).append(
                "Le fasce art.142 (costa 300 m / fiumi 150 m) per %s non sono in SITAP: "
                "verificare la perimetrazione sul geoportale/PPTR regionale → %s"
                % (c.data.get("regione") or "questa regione", portale))
    rep["_costiero"] = costiero

    # 3) Puglia: componenti insediative UCP del PPTR (es. 'Città consolidata').
    #    Non è vincolo 42/2004: rileva ma NON entra tra i vincoli paesaggistici
    #    formali. Serve soprattutto per la valutazione degli armadi (fuori terra).
    rep["_ucp_puglia_geoms"] = []
    if "puglia" in regione_l and not _ferma(rep, _av, "UCP PPTR Puglia (Città consolidata)"):
        _av("SIT Puglia: componenti insediative PPTR, UCP Città consolidata (max %d s)…"
            % _apri_stadio("UCP PPTR Puglia (Città consolidata)"))
        try:
            ucp_tr, ucp_geoms = vincoli_pptr_puglia(c.data["bbox"], raccogli_geometrie=True)
            for t in ucp_tr:
                rep["_ucp_puglia_geoms"] += t.get("_geoms", [])
                _av("  %s: %d poligoni" % (t["etichetta"], t["n_poligoni"]))
                rep.setdefault("ucp_pptr", []).append(
                    {"etichetta": t["etichetta"], "n_poligoni": t["n_poligoni"]})
            if raccogli_geometrie and ucp_geoms:
                rep.setdefault("_geometrie_vincoli", [])
                rep["_geometrie_vincoli"] += ucp_geoms
            rep["fonti"].append({"stadio": "UCP PPTR Puglia (Città consolidata)",
                                 "fonte": "SIT Puglia (PPTR, ArcGIS REST)",
                                 "confidenza": "media", "errore": None})
            _chiudi_stadio(rep, "UCP PPTR Puglia (Città consolidata)",
                           "Il PPTR Puglia non ha risposto entro %d s: le componenti "
                           "insediative UCP NON sono state verificate.", ok=bool(ucp_tr))
            if not ucp_tr:
                _av("  nessuna componente insediativa UCP intercettata")
        except Exception as e:  # noqa: BLE001
            _av("  PPTR Puglia non raggiungibile: %s" % str(e)[:80])

    # -- pericolosità idrogeologica (ISPRA IdroGEO, per comune ISTAT) --
    if _ferma(rep, _av, "pericolosità idrogeologica"):
        return rep
    _av("ISPRA IdroGEO: pericolosità idraulica e da frana (max %d s)…"
        % _apri_stadio("pericolosità idrogeologica"))
    pg = _prendi("pericolosità idrogeologica", pericolosita_idrogeologica, c.data.get("istat"))
    rep["fonti"].append({"stadio": "pericolosità idrogeologica", "fonte": pg.fonte,
                         "confidenza": pg.confidenza, "errore": pg.errore})
    _chiudi_stadio(rep, "pericolosità idrogeologica",
                   "ISPRA IdroGEO non ha risposto entro %d s: la pericolosità idraulica e "
                   "da frana NON è stata verificata.", ok=bool(pg.data))
    if pg.data:
        rep["idrogeologico"] = pg.data
        rep["warning"] += [n for n in pg.note if n]
        idr = pg.data["idraulica"]; fr = pg.data["frane"]
        _av("  idraulica: P3 %.1f%% · P2 %.1f%% · P1 %.1f%% del territorio"
            % (idr["P3_elevata_pct"], idr["P2_media_pct"], idr["P1_bassa_pct"]))
        _av("  frane: P3+P4 %.1f%% del territorio" % fr["P3P4_pct"])
    elif pg.errore:
        rep["warning"].append("Pericolosità idrogeologica non verificata (ISPRA IdroGEO): %s" % pg.errore)

    rep["enti"] = componi_enti(rep)
    _av("Enti da interpellare: %d" % len(rep["enti"]))
    return rep


def siti_contaminati(bbox, raccogli_geometrie=False):
    """Siti contaminati e procedimenti di bonifica (ISPRA, banca dati MOSAICO).

    Perche' in uno screening di scavo: dentro un'area con bonifica aperta la
    movimentazione del terreno ricade nel DLgs 152/2006 Titolo V e l'ARPA
    entra nel procedimento. Dentro un SIN autorizza il Ministero.

    bbox e' [S, N, W, E] come lo restituisce risolvi_comune().
    """
    try:
        from . import ftth_bonifiche
    except (ImportError, ValueError):
        import ftth_bonifiche
    s_, n_, w_, e_ = bbox
    # Legato ai tetti dello screening: le due richieste di MOSAICO sono in
    # fila e senza questo residuo lo stadio poteva sforare il proprio tetto
    # mentre la finestra aspettava. `_residuo` tiene conto anche del budget
    # complessivo, quindi questa fonte non mangia il tempo delle altre.
    r = ftth_bonifiche.interroga_siti_contaminati(
        w_, s_, e_, n_,
        annulla=_annullato,
        budget_s=_residuo())
    note = []
    if r.get("errore"):
        note.append("Siti contaminati e bonifiche NON verificati "
                    "(servizio ISPRA irraggiungibile): %s. "
                    "Non significa che non ce ne siano." % r["errore"])
        return SourceResult(None, "ISPRA - banca dati MOSAICO", ftth_bonifiche.BASE,
                            "Dati aperti ISPRA", True, "alta", note, r["errore"])

    aperti = [p for p in r["procedimenti"] if p["attributi"].get("_aperto")]
    arpa = sorted({p["attributi"].get("arpa_appa") for p in r["procedimenti"]
                   if p["attributi"].get("arpa_appa")})
    dati = {
        "sin": [{"nome": x["attributi"].get("den_sin"),
                 "codice": x["attributi"].get("cod_sin"),
                 "matrice": x["attributi"].get("matrice")} for x in r["sin"]],
        "procedimenti_totali": len(r["procedimenti"]),
        "procedimenti_aperti": len(aperti),
        "arpa_competenti": arpa,
        "dettaglio_aperti": [{
            "stato": p["attributi"].get("stato_corrente"),
            "contaminazione": p["attributi"].get("stato_cont_corr"),
            "tipo": p["attributi"].get("tipo_proc_corr"),
            "motivo": p["attributi"].get("motivo_inserimento"),
            "autorita": p["attributi"].get("autorita"),
            "arpa": p["attributi"].get("arpa_appa"),
            "lon": (p.get("geometria") or {}).get("x"),
            "lat": (p.get("geometria") or {}).get("y"),
        } for p in aperti[:40]],
    }
    if dati["sin"]:
        note.append("Area dentro o a ridosso di un SIN (%s): dentro il perimetro "
                    "l'autorizzazione e' ministeriale, non comunale."
                    % ", ".join(x["nome"] or x["codice"] or "?" for x in dati["sin"]))
    if aperti:
        note.append("%d procedimenti di bonifica APERTI nel riquadro del comune: "
                    "se il tracciato li interseca, lo scavo va concordato con "
                    "l'ARPA competente (terre e rocce, DPR 120/2017)." % len(aperti))
    geoms = []
    if raccogli_geometrie:
        for x in r["sin"]:
            g = x.get("geometria") or {}
            if g.get("rings"):
                # coppia (etichetta, feature) come TUTTE le altre geometrie dei
                # vincoli: una feature "nuda" faceva fallire l'analisi sul
                # tracciato con "too many values to unpack (expected 2)" nei
                # comuni con un SIN (es. Manfredonia)
                nome_sin = x["attributi"].get("den_sin") or "senza nome"
                geoms.append(("SIN - Sito di Interesse Nazionale — %s" % nome_sin,
                              {"type": "Feature",
                               "properties": {"vincolo": "SIN - Sito di Interesse Nazionale",
                                              "nome": nome_sin},
                               "geometry": {"type": "Polygon", "coordinates": g["rings"]}}))
    res = SourceResult(dati, "ISPRA - banca dati MOSAICO (SIN e procedimenti di bonifica)",
                       ftth_bonifiche.BASE, "Dati aperti ISPRA", True, "alta", note)
    res.geometrie = geoms
    return res


def arpa_in_conferenza(regione, provincia):
    """ARPA/APPA da convocare in Conferenza di Servizi, se e' prassi regionale.

    ARPA non rilascia il titolo di scavo, ma dove viene convocata in CdS il
    suo parere entra nel procedimento e una richiesta di integrazione lo
    sospende. La tabella in procedimenti.yaml e' una memoria di casi
    VERIFICATI: fuori da quelli non si afferma nulla.
    """
    kb = carica_kb() or {}
    reg_norm = _norm_regione(regione or "")
    for v in kb.get("arpa_conferenza_servizi", []) or []:
        if _norm_regione(v.get("regione", "")) == reg_norm:
            pec = None
            mappa = v.get("pec_per_provincia") or {}
            for prov, indirizzo in mappa.items():
                if provincia and _norm_regione(prov) == _norm_regione(provincia):
                    pec = indirizzo
                    break
            dati = dict(v)
            dati["pec_competente"] = pec or v.get("pec_direzione")
            dati["pec_provinciale_trovata"] = bool(pec)
            note = []
            if v.get("prassi") == "sempre":
                note.append("%s: convocata di prassi in Conferenza di Servizi. "
                            "Prevederla nel cronoprogramma, non come eventualita'."
                            % v.get("agenzia", "ARPA"))
            if not pec and mappa:
                note.append("PEC provinciale non determinata (provincia '%s' non "
                            "riconosciuta): usare la Direzione Generale." % provincia)
            if v.get("avvertenza_pec"):
                note.append(v["avvertenza_pec"])
            return SourceResult(dati, "procedimenti.yaml - casi verificati",
                                v.get("sito", ""), "Interna", False, "alta", note)
    return SourceResult(None, "procedimenti.yaml - casi verificati", "", "Interna",
                        False, "media",
                        ["Per %s non risulta verificato se ARPA venga convocata in "
                         "Conferenza di Servizi: verificare con il Comune. L'assenza "
                         "qui non significa che non venga convocata."
                         % (regione or "questa regione")])


def componi_enti(rep):
    enti = []
    sc = scheda_strada("COMUNALE")   # il Comune c'è sempre
    # '_origine' marca COSA ha generato la voce: senza questo dato, a valle non
    # è più possibile risalire al fatto territoriale che attiva l'ente e quindi
    # distinguere chi è toccato dalla rete da chi è solo presente nel comune.
    enti.append({"ruolo": "Ente proprietario del suolo pubblico comunale",
                 "ente": "Comune di %s" % rep["comune"]["nome"], "scheda": sc,
                 "trigger": "sempre", "livello": 4, "_origine": "comune"})

    pop = (rep.get("comune") or {}).get("popolazione")
    grande_centro = pop is not None and pop > 10000

    for classe in ["A", "SS", "SR", "SP"]:
        # unisci la rete primaria (DBSN/stradario) con le strade presenti solo in
        # OSM e con quelle non misurate: una SP che il tracciato attraversa NON
        # deve sparire dagli enti solo perché lo stradario di riferimento non la
        # copre (caso Montelabbate: SP423 con 3 attraversamenti stava solo in OSM
        # e la Provincia non veniva generata come ente da interpellare).
        refs = dict(rep["rete_stradale"].get(classe, {}))
        for extra in ("rete_stradale_solo_osm", "rete_stradale_non_misurate"):
            for r, v in (rep.get(extra) or {}).get(classe, {}).items():
                refs.setdefault(r, v)
        if not refs:
            continue
        sc = scheda_strada(classe)
        ops = sorted({o for v in refs.values() for o in v.get("operator", [])})
        # L'ente da interpellare NON è sempre "la Provincia": in diverse regioni
        # la competenza sulla viabilità ex provinciale è passata ad altri enti
        # (EDR in Friuli, Liberi Consorzi in Sicilia) o a società regionali
        # (ASTRAL, Veneto Strade, FVG Strade). Scrivere a un ente soppresso
        # costa settimane di istruttoria. Ordine: prima il gestore letto dai
        # dati (operator OSM), poi il gestore regionale della kb, infine il
        # tipo generico.
        _reg = (rep.get("comune") or {}).get("regione") or ""
        _prov = (rep.get("comune") or {}).get("provincia") or ""
        _gest_kb, _nota_kb = gestore_regionale(classe, _reg, _prov)
        if classe == "A" and not ops:
            conc = []
            for r in refs:
                cc = concessionario_autostrada(r)
                if cc and "%s: %s" % (r, cc) not in conc:
                    conc.append("%s: %s" % (r, cc))
            if conc:
                _gest_kb = "; ".join(conc) + " (da confermare per la tratta)"
                _nota_kb = ("Concessionario dall'elenco MIT delle convenzioni autostradali: "
                            "dove la sigla e' divisa fra piu' concessionari conta la tratta.")
        if ops:
            _ente = ", ".join(ops)
        elif _gest_kb:
            _ente = "%s (da confermare)" % _gest_kb
        else:
            _ente = sc["ente_tipo"]
        voce = {
            "ruolo": sc["descrizione"],
            "ente": _ente,
            "scheda": sc,
            "trigger": "%d strade: %s%s" % (len(refs), ", ".join(list(refs)[:12]),
                                            " ..." if len(refs) > 12 else ""),
            "_origine": "strada",
            "_classe_strada": classe,
        }
        if _nota_kb and (_gest_kb or ops):
            # la nota spiega PERCHÉ l'ente non è quello che ci si aspetta:
            # senza, "EDR di Udine" al posto della Provincia sembra un errore
            voce["nota_gestore"] = _nota_kb
            if ops and _gest_kb and _gest_kb.split(" (")[0].lower() not in _ente.lower():
                voce["nota_gestore"] = (
                    "%s — NOTA: i dati OSM indicano '%s', la competenza attesa in "
                    "questa regione sarebbe '%s': verificare quale dei due è il "
                    "gestore effettivo della tratta." % (_nota_kb, _ente, _gest_kb))
        # competenza art.2 c.7 CdS: i tratti di SS/SR/SP che attraversano un
        # centro abitato con >10.000 abitanti sono strade COMUNALI ex lege
        # (Cons. Stato 403/2014). Il criterio e' sul centro abitato attraversato,
        # non sull'intero Comune: qui usiamo la pop. comunale come proxy e lo
        # dichiariamo, perche' il perimetro del centro abitato (delibera di
        # delimitazione ex art.4 CdS) non e' un dato nazionale interrogabile.
        voce["nota_competenza"] = nota_competenza_strada(classe, pop, sc["ente_tipo"])
        if classe == "SS" and rep.get("anas"):
            anas = [nota_anas(rep["anas"][r]) for r in refs if r in rep["anas"]]
            if anas:
                voce["nota_competenza"] = " ".join(anas) + " " + (voce["nota_competenza"] or "")
                s = next((rep["anas"][r].get("struttura") for r in refs
                          if r in rep["anas"] and rep["anas"][r].get("struttura")), None) or {}
                if s.get("pec"):
                    voce["contatti"] = {"pec": s["pec"], "indirizzo": s.get("indirizzo")}
                    voce["ente"] = s.get("nome") or voce["ente"]
        # livello gerarchico dell'ente (per l'ordinamento nazionale->comunale)
        _liv_strada = {"A": 1, "SS": 1, "SR": 2, "SP": 3}.get(classe, 3)
        voce["livello"] = _liv_strada
        enti.append(voce)

    for s in rep.get("soprintendenze", []):
        sc = scheda_vincolo("sopr_paesaggio" if s["ambito"] == "paesaggio" else "archeologia")
        enti.append({"ruolo": "Soprintendenza (%s)" % s["ambito"], "ente": s["denominazione"],
                     "contatti": {"pec": s.get("pec"), "sito": s.get("sito")},
                     "scheda": sc, "trigger": "competenza territoriale", "livello": 1,
                     "_origine": "soprintendenza"})

    chiavi = {v["chiave"] for v in rep.get("vincoli", [])}
    for k in sorted(chiavi):
        sc = scheda_vincolo(k)
        if sc and k not in {"sopr_paesaggio"}:
            et = [v["etichetta"] for v in rep["vincoli"] if v["chiave"] == k]
            # livello: UNESCO e beni statali = nazionale(1); paesaggistici e
            # ambientali delegati = regionale(2)
            _liv_v = 1 if k in {"unesco"} else 2
            enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"],
                         "scheda": sc, "trigger": "; ".join(et), "livello": _liv_v,
                         "_origine": "vincolo", "_etichette": list(et),
                         "_chiave_vincolo": k})
        elif not sc and k not in {"sopr_paesaggio"}:
            # vincolo intercettato ma senza scheda in kb: NON silenziarlo, o il
            # report mostrerebbe la criticità senza dire a chi rivolgersi
            et = [v["etichetta"] for v in rep["vincoli"] if v["chiave"] == k]
            rep.setdefault("warning", []).append(
                "Vincolo '%s' rilevato ma privo di scheda ente in procedimenti.yaml "
                "(%s): l'interlocutore va individuato manualmente." % (k, "; ".join(et)))

    # Rete Natura 2000 (SIC/ZSC + ZPS): genera l'ente con la Valutazione di
    # Incidenza (VIncA). Livello 2 (regionale/ente gestore). Elenca i codici siti.
    if rep.get("natura2000"):
        sc_n = scheda_vincolo("natura2000")
        if sc_n:
            siti = ["%s %s (%s)" % (s["codice"], s["nome"], s["tipo"].split(" ")[0])
                    for s in rep["natura2000"]]
            enti.append({"ruolo": sc_n["descrizione"], "ente": sc_n["ente_tipo"],
                         "scheda": sc_n, "trigger": "; ".join(siti[:6]), "livello": 2,
                         "_origine": "natura2000"})

    # Aree naturali protette (parchi nazionali/regionali): nulla osta dell'Ente
    # gestore ex art. 13 L. 394/1991. Livello 2. Elenca i parchi intercettati.
    if rep.get("parchi"):
        sc_p = scheda_vincolo("aree_protette")
        if sc_p:
            nomi = ["%s%s" % (p["nome"], (" [%s]" % p["euap"]) if p.get("euap") else "")
                    for p in rep["parchi"]]
            enti.append({"ruolo": sc_p["descrizione"], "ente": sc_p["ente_tipo"],
                         "scheda": sc_p, "trigger": "; ".join(nomi[:6]), "livello": 2,
                         "_origine": "parchi"})

    if rep.get("ferrovie"):
        sc = scheda_vincolo("ferrovia")
        gestori = rep.get("_gestori_ferrovie") or {}
        # distanze dal tracciato (solo in analisi sul tracciato): il trigger dice
        # se il tracciato ATTRAVERSA la linea o ricade nella fascia di 30 m,
        # invece del generico "linea nel territorio comunale"
        dist_f = (rep.get("_distanze_lineari") or {}).get("ferrovie") or {}
        fascia_f = sc.get("fascia_rispetto_m", 30)

        def _trig_ferr(nomi):
            parti = []
            for n in nomi:
                d = dist_f.get(n)
                if d is None:
                    continue
                if d <= 0.5:
                    parti.append("%s: ATTRAVERSAMENTO del tracciato" % n)
                else:
                    parti.append("%s: tracciato a %.0f m (entro fascia %d m)" % (n, d, fascia_f))
            return "; ".join(parti) if parti else "linea ferroviaria nel territorio comunale"

        linee_rfi = [n for n in rep["ferrovie"] if gestore_ferrovia(n, gestori) != "altro"]
        linee_altre = [n for n in rep["ferrovie"] if gestore_ferrovia(n, gestori) == "altro"]
        if linee_rfi:
            # associa la struttura territoriale RFI competente per regione (punto 4):
            # la linea RFI implica interfaccia con la DTP/struttura RFI di zona
            rfi = rfi_struttura((rep.get("comune") or {}).get("regione"))
            ente_rfi = ", ".join(linee_rfi[:3])
            trig_rfi = _trig_ferr(linee_rfi)
            if rfi:
                ente_rfi = "%s — %s" % (rfi["struttura"], ", ".join(linee_rfi[:3]))
                trig_rfi += " · Fascicolo Circolazione Linee (PGOS Art.2) %s" % rfi.get("pgos_range", "")
            if any(gestore_ferrovia(n, gestori) == "ignoto" for n in linee_rfi):
                trig_rfi += " · gestore non indicato in OSM: da confermare (RFI o ferrovia concessa)"
            enti.append({"ruolo": sc["descrizione"], "ente": ente_rfi,
                         "scheda": sc, "trigger": trig_rfi, "livello": 1,
                         "rfi": rfi, "_origine": "ferrovia"})
        for n in linee_altre:
            # ferrovia regionale/in concessione: la fascia di 30 m (art. 49 DPR
            # 753/1980) vale uguale, ma il nulla osta lo rilascia il GESTORE della
            # linea, non la DOIT RFI. Mandare l'istanza a RFI = istanza all'ente
            # sbagliato.
            enti.append({"ruolo": sc["descrizione"],
                         "ente": "%s — gestore della linea (NON RFI: ferrovia regionale/in concessione)" % n,
                         "scheda": sc,
                         "trigger": _trig_ferr([n]) + " · fascia 30 m art. 49 DPR 753/1980 "
                                    "valida anche per le ferrovie in concessione",
                         "livello": 2, "rfi": None, "_origine": "ferrovia"})
    if rep.get("ferrovie_dismesse"):
        sc = scheda_vincolo("ferrovia_dismessa")
        if sc:
            enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"], "scheda": sc,
                         "trigger": "ex sedime: %s" % ", ".join(rep["ferrovie_dismesse"][:3]),
                         "livello": 2, "_origine": "ferrovia_dismessa"})
    if rep.get("corsi_acqua"):
        sc = scheda_vincolo("idrico")
        # distingui l'ATTRAVERSAMENTO demaniale (il tracciato tocca l'alveo,
        # dist ~0 → serve concessione/nulla osta idraulico R.D. 523/1904) dalla
        # semplice PROSSIMITÀ entro la fascia paesaggistica 150 m (art. 142 lett. c
        # → rileva ai fini paesaggistici, NON è occupazione del demanio idrico).
        dist_corsi = (rep.get("_distanze_lineari") or {}).get("corsi_acqua") or {}
        if not dist_corsi:
            # nessuna distanza misurata (modalità comune, senza analisi sul
            # tracciato): comportamento generico, la distinzione non è possibile
            enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"], "scheda": sc,
                         "trigger": "%d corsi d'acqua denominati (distanza non misurata: "
                                    "usare l'analisi sul tracciato per distinguere "
                                    "attraversamento da prossimità)" % len(rep["corsi_acqua"]),
                         "livello": 2, "_origine": "idrico_non_misurato"})
        else:
            attraversati = [n for n in rep["corsi_acqua"] if dist_corsi.get(n, 999) <= 0.5]
            vicini = [n for n in rep["corsi_acqua"]
                      if 0.5 < dist_corsi.get(n, 999) <= 150]
            if attraversati:
                trig = "%d corso/i attraversato/i (alveo demaniale): %s" % (
                    len(attraversati), ", ".join(attraversati))
                if vicini:
                    trig += " · entro fascia 150 m (solo paesaggistico): %s" % ", ".join(vicini)
                enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"],
                             "scheda": sc, "trigger": trig, "livello": 2,
                             "_origine": "idrico_attraversato"})
            elif vicini:
                # nessun attraversamento: NON è competenza demaniale, è solo la
                # fascia paesaggistica dei 150 m. Segnaliamo il vincolo
                # paesaggistico, non la concessione demaniale (che richiederebbe
                # di toccare l'alveo).
                sc_p = scheda_vincolo("sopr_paesaggio") or sc
                det = ", ".join("%s (~%.0f m)" % (n, dist_corsi.get(n, 0)) for n in vicini)
                enti.append({
                    "ruolo": "Corso d'acqua entro la fascia paesaggistica di 150 m (art. 142 lett. c) — NON attraversato",
                    "ente": "Autorizzazione paesaggistica (fascia fluviale); nessuna concessione demaniale se non si tocca l'alveo",
                    "scheda": sc_p,
                    "trigger": "prossimità (nessun attraversamento demaniale): %s" % det,
                    "livello": 2, "_origine": "idrico_prossimita"})

    # Canali del reticolo di BONIFICA: competenza del Consorzio di bonifica, con
    # fascia di rispetto stabilita dal regolamento consortile (non i 150 m). OSM non
    # dice quale Consorzio: segnaliamo il reticolo e rimandiamo all'identificazione.
    if rep.get("canali_bonifica"):
        sc_bon = scheda_vincolo("bonifica")
        if sc_bon:
            elenco = ", ".join(rep["canali_bonifica"][:8])
            enti.append({
                "ruolo": sc_bon["descrizione"],
                "ente": sc_bon["ente_tipo"],
                "scheda": sc_bon,
                "trigger": "reticolo di bonifica nel territorio (%d canali/scoline denominati): %s"
                           " · fascia di rispetto da REGOLAMENTO consortile (non i 150 m paesaggistici),"
                           " Consorzio da identificare (OSM non lo riporta)"
                           % (len(rep["canali_bonifica"]), elenco),
                "livello": 2, "_origine": "bonifica"})

    # boschi / aree forestali: vincolo paesaggistico ex lege art.142 lett.g. Se
    # nel comune (o sul tracciato, in modalità tracciato) ci sono aree boscate,
    # segnala il vincolo. Distingue attraversamento da presenza nel comune.
    if rep.get("boschi"):
        sc_b = scheda_vincolo("art142")
        if sc_b:
            dist_b = (rep.get("_distanze_lineari") or {}).get("boschi") or {}
            if dist_b:
                # modalità tracciato: usa le distanze misurate
                attr_b = [n for n in rep["boschi"] if dist_b.get(n, 999) <= 0.5]
                vic_b = [n for n in rep["boschi"] if 0.5 < dist_b.get(n, 999) <= 150]
                if attr_b or vic_b:
                    parti = []
                    if attr_b:
                        parti.append("attraversati/interni: %s" % ", ".join(attr_b[:5]))
                    if vic_b:
                        parti.append("entro 150 m: %s" % ", ".join(vic_b[:5]))
                    enti.append({"ruolo": "Vincolo paesaggistico su aree boscate (art. 142 lett. g)",
                                 "ente": sc_b["ente_tipo"], "scheda": sc_b,
                                 "trigger": "; ".join(parti), "livello": 2,
                                 "_origine": "boschi_misurati"})
            else:
                # modalità comune: nessuna distanza, segnala la presenza
                enti.append({"ruolo": "Vincolo paesaggistico su aree boscate (art. 142 lett. g)",
                             "ente": sc_b["ente_tipo"], "scheda": sc_b,
                             "trigger": "%d aree boscate nel territorio comunale (verificare se il "
                                        "tracciato le interseca o vi ricade entro 150 m)" % len(rep["boschi"]),
                             "livello": 2, "_origine": "boschi_non_misurati"})
    # pericolosità significativa (idraulica P2/P3 o frane P3/P4). Soglia bassa
    # di proposito: in pre-istruttoria meglio segnalare e far verificare.
    idg = rep.get("idrogeologico")
    if idg:
        idr = idg["idraulica"]; fr = idg["frane"]
        trig = []
        if idr["P3_elevata_pct"] >= 1.0:
            trig.append("pericolosità idraulica ELEVATA (P3) sul %.1f%% del territorio" % idr["P3_elevata_pct"])
        elif idr["P2_media_pct"] >= 1.0:
            trig.append("pericolosità idraulica media (P2) sul %.1f%% del territorio" % idr["P2_media_pct"])
        if fr["P3P4_pct"] >= 1.0:
            trig.append("pericolosità da frana elevata (P3-P4) sul %.1f%% del territorio" % fr["P3P4_pct"])
        if trig:
            sc = scheda_vincolo("idrogeologico")
            if sc:
                enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"], "scheda": sc,
                             "trigger": "; ".join(trig), "livello": 2,
                             "_origine": "idrogeologico"})

    # Ordinamento GERARCHICO nazionale -> comunale (punto 3): livello 1=Stato/
    # nazionale (ANAS/autostrade, RFI, MiC/UNESCO), 2=regionale (SR, vincoli
    # paesaggistici/ambientali, corsi d'acqua, idrogeologico), 3=provinciale (SP,
    # Province), 4=comunale. Ordinamento STABILE: a parità di livello resta
    # l'ordine di inserimento, così nessun ente viene perso o riordinato a caso.
    for e in enti:
        e.setdefault("livello", 3)
    enti.sort(key=lambda e: e.get("livello", 3))
    return enti


# ---------------------------------------------------------------------------
# Rendering markdown
# ---------------------------------------------------------------------------
def _fmt_stato(v):
    """Cella 'stato/distanza' per la modalità tracciato."""
    st = v.get("stato")
    if not st:
        return "—"
    aff = v.get("affiancamento_m")
    attr = v.get("attraversamenti")
    # stato gia' arricchito (affiancamento/attraversamenti) in analizza_su_tracciato
    if aff and aff >= 5:
        s = "**affianc. ~%d m**" % aff
        if attr:
            s += " +%d attr." % attr
        return s
    if attr:
        return "**%d attravers.**" % attr
    if st == "ATTRAVERSAMENTO":
        return "**ATTRAVERSAMENTO**"
    d = v.get("distanza_m")
    return "%s (%.0f m)" % (st.split(" (")[0], d) if d is not None else st


def to_markdown(rep):
    KB = carica_kb()
    if rep.get("errore"):
        return "# Errore\n\n%s\n" % rep["errore"]
    c = rep["comune"]
    L = ["# Screening scavi su suolo pubblico — %s" % c["nome"], ""]
    if rep.get("area_progetto"):
        L[0] += " (ristretto a: %s)" % rep["area_progetto"]["nome"]
    L.append("**%s**  " % c["display_name"])
    L.append("Provincia: %s · Regione: %s · ISTAT: %s · OSM rel: %s" % (
        c["provincia"] or "n/d", c["regione"] or "n/d", c["istat"] or "n/d", c["osm_relation_id"]))
    L += ["", "> Documento di **pre-istruttoria**. " + KB["meta"]["disclaimer"].strip(), ""]

    L += ["## 1. Rete stradale classificata", ""]
    etich = {"A": "Autostrade", "SS": "Strade statali", "SR": "Strade regionali",
             "SP": "Strade provinciali", "SC": "Strade comunali classificate",
             "RA": "Raccordi autostradali", "NSA": "Nuove strade ANAS"}
    sf = rep.get("stradario_fonte")
    modo_tracc = (rep.get("area_progetto") or {}).get("modalita") == "tracciato"
    if sf:
        L += ["_Fonte primaria: **%s**%s. Colonna 'OSM' = la stessa strada è "
              "confermata anche dai dati OpenStreetMap._" % (
                  sf["nome"],
                  " (indipendente da OSM)" if sf["indipendente"]
                  else " — estratto OSM, non indipendente"), ""]
    if modo_tracc:
        L += ["_Analisi sul tracciato: colonna 'Stato/distanza' = rapporto tra il "
              "tracciato e la strada (attraversamento o distanza entro fascia di rispetto)._", ""]
    if not rep["rete_stradale"]:
        L.append("_Nessuna strada classificata rilevata (o fonte non raggiungibile)._")
    for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
        refs = rep["rete_stradale"].get(cls)
        if not refs:
            continue
        col_extra = ""
        if modo_tracc:
            col_extra = " Stato/distanza |"
        if sf:
            L += ["### %s — %d" % (etich.get(cls, cls), len(refs)), "",
                  "| Ref | Segmenti | Confermata OSM | Gestore | Denominazione |%s" % col_extra,
                  "|---|---:|:---:|---|---|%s" % ("---|" if modo_tracc else "")]
            for r, v in refs.items():
                riga = "| **%s** | %s | %s | %s | %s |" % (
                    r, v["n_way"], "sì" if v.get("confermato_osm") else "**no**",
                    ", ".join(v["operator"]) or "—", "; ".join(v["nomi"]) or "—")
                if modo_tracc:
                    riga += " %s |" % _fmt_stato(v)
                L.append(riga)
            L.append("")
        else:
            L += ["### %s — %d" % (etich.get(cls, cls), len(refs)), "",
                  "| Ref | Segmenti OSM | Gestore da OSM | Denominazione |%s" % col_extra,
                  "|---|---:|---|---|%s" % ("---|" if modo_tracc else "")]
            for r, v in refs.items():
                riga = "| **%s** | %s | %s | %s |" % (
                    r, v["n_way"], ", ".join(v["operator"]) or "—", "; ".join(v["nomi"]) or "—")
                if modo_tracc:
                    riga += " %s |" % _fmt_stato(v)
                L.append(riga)
            L.append("")
    # strade che OSM ha ma lo stradario di riferimento no
    solo_osm = rep.get("rete_stradale_solo_osm") or {}
    if solo_osm:
        tutte = ", ".join(r for cls in solo_osm for r in solo_osm[cls])
        L += ["**Presenti in OSM ma non nello stradario di riferimento** "
              "(riclassificazioni o copertura mancante — da verificare): %s" % tutte, ""]

    L += ["> **Avvertenza sulla fonte strade.** L'elenco delle strade classificate "
          "(SS/SP/SR) deriva da OpenStreetMap, che può essere incompleto o non "
          "aggiornato: singole provinciali possono mancare o avere una classificazione "
          "diversa da quella ufficiale. Prima della richiesta di autorizzazione, "
          "verificare le strade sul **Catasto Strade / geoportale della Provincia (o "
          "Città Metropolitana) competente** e sullo stradario ANAS per le statali.", ""]

    L += ["## 2. Tutela beni culturali e paesaggio", ""]
    if rep.get("soprintendenze"):
        L += ["| Ambito | Soprintendenza | % territorio | PEC |", "|---|---|---:|---|"]
        for s in rep["soprintendenze"]:
            flag = " ⚠︎" if s.get("marginale") else ""
            L.append("| %s | %s%s | %s%% | `%s` |" % (
                s["ambito"], s["denominazione"], flag,
                s.get("quota_territorio", "—"), s.get("pec") or "—"))
        if any(s.get("marginale") for s in rep["soprintendenze"]):
            L += ["", "⚠︎ = giurisdizione marginale. Comune di confine: verificare la "
                  "competenza sul tratto specifico, non sull'intero territorio."]
        L.append("")
    else:
        L += ["_Soprintendenza non determinata dai servizi SITAP._", ""]

    if rep.get("vincoli"):
        L += ["| Vincolo | Poligoni intersecanti | % territorio |", "|---|---:|---:|"]
        for v in rep["vincoli"]:
            L.append("| %s | %s | %s%% |" % (v["etichetta"], v["n_poligoni"], v["pct_territorio"]))
        L.append("")
    else:
        L += ["_Nessun vincolo intercettato nei layer nazionali SITAP interrogati — "
              "**non equivale ad assenza di vincoli**._", ""]

    # Vincoli che lo screening NON può accertare: vanno sempre elencati, altrimenti
    # la tabella qui sopra viene letta come "nessun vincolo" anche per fattispecie
    # cogenti che nessun servizio nazionale espone (usi civici, parchi, strade
    # panoramiche...). Falso negativo = istanza respinta o lavori fermati.
    try:
        _dav = vincoli_da_verificare_a_mano()
    except Exception:
        _dav = []
    if _dav:
        L += ["### Vincoli da verificare a mano (non coperti dai servizi interrogati)",
              "",
              "Lo screening copre l'art. 142 c.1 lett. a, c, e, g, i, l'art. 136, "
              "UNESCO, Natura 2000, vincolo idrogeologico e PAI. Le voci qui sotto "
              "**non sono state verificate**: non significa che siano assenti.",
              ""]
        for v in _dav:
            L.append("- **%s** — %s" % (v["titolo"], v["nota"]))
        L.append("")

    # Siti contaminati e ARPA: non sono vincoli paesaggistici e non stanno
    # nella tabella sopra, ma decidono se lo scavo e' ordinario o no.
    sc = rep.get("siti_contaminati")
    ar = rep.get("arpa_cds")
    if sc or ar:
        L += ["### Ambiente: siti contaminati e ARPA", ""]
    if sc is None and "siti_contaminati" in rep:
        L += ["_Siti contaminati e bonifiche **non verificati**: servizio ISPRA "
              "non raggiungibile. Non equivale ad assenza._", ""]
    elif sc:
        if sc["sin"]:
            for x in sc["sin"]:
                L.append("- **SIN — %s**: dentro il perimetro autorizza il "
                         "Ministero, non il Comune. Matrice: %s."
                         % (x["nome"] or x["codice"], x.get("matrice") or "n/d"))
        if sc["procedimenti_aperti"]:
            L.append("- **%d procedimenti di bonifica aperti** nel riquadro del "
                     "comune (%d totali in anagrafe). Se il tracciato ne interseca "
                     "uno, lo scavo non e' ordinario: la movimentazione del terreno "
                     "ricade nel D.Lgs 152/2006 Titolo V."
                     % (sc["procedimenti_aperti"], sc["procedimenti_totali"]))
            righe = [d for d in sc["dettaglio_aperti"] if d.get("contaminazione")
                     in ("Contaminato", "Potenzialmente contaminato")]
            if righe:
                L += ["", "| Stato contaminazione | Stato procedimento | Autorita' |",
                      "|---|---|---|"]
                for d in righe[:12]:
                    L.append("| %s | %s | %s |" % (d["contaminazione"],
                             (d["stato"] or "")[:60], d["autorita"] or "n/d"))
                L.append("")
        elif not sc["sin"]:
            L.append("- Nessun procedimento di bonifica aperto nel riquadro del "
                     "comune (%d chiusi/certificati in anagrafe)."
                     % sc["procedimenti_totali"])
        for a in sc["arpa_competenti"]:
            L.append("- ARPA competente per l'area: **%s**" % a)
        L.append("")
    if ar:
        L += ["**%s va convocata in Conferenza di Servizi.**" % ar.get("agenzia", "ARPA"), ""]
        L.append("- Prassi: %s. %s" % (ar.get("prassi"), (ar.get("nota") or "").strip()))
        if ar.get("struttura_competente"):
            L.append("- Struttura: %s" % ar["struttura_competente"])
        if ar.get("pec_competente"):
            L.append("- PEC: `%s`%s" % (ar["pec_competente"],
                     "" if ar.get("pec_provinciale_trovata") else " (Direzione Generale: provincia non riconosciuta)"))
        if ar.get("avvertenza_pec"):
            L.append("- ATTENZIONE: %s" % ar["avvertenza_pec"].strip())
        L.append("")

    if rep.get("ferrovie") or rep.get("ferrovie_dismesse") or rep.get("corsi_acqua"):
        L += ["## 3. Altre interferenze", ""]
        if rep.get("ferrovie"):
            dist_f = (rep.get("_distanze_lineari") or {}).get("ferrovie") or {}
            def _con_dist(n):
                d = dist_f.get(n)
                if d is None:
                    return n
                return "%s (%s)" % (n, "ATTRAVERSAMENTO" if d <= 0.5 else "tracciato a %.0f m" % d)
            L.append("- **Ferrovie**: %s — fascia di rispetto 30 m ex D.P.R. 753/1980"
                     % ", ".join(_con_dist(n) for n in rep["ferrovie"]))
            gestori = rep.get("_gestori_ferrovie") or {}
            linee_altre = [n for n in rep["ferrovie"] if gestore_ferrovia(n, gestori) == "altro"]
            if linee_altre:
                L.append("  **Linee NON gestite da RFI**: %s — il nulla osta va chiesto al "
                         "gestore della linea, non alla DOIT RFI." % ", ".join(linee_altre))
            # Contatti RFI per l'invio dell'istanza (Modalità di invio istanze):
            # PEC delle DOIT competenti e referenti RFI della regione (kb).
            # Solo se c'e' almeno una linea RFI (o di gestore non noto).
            rfi_c = (rfi_struttura((rep.get("comune") or {}).get("regione"))
                     if len(linee_altre) < len(rep["ferrovie"]) else None)
            contatti = (rfi_c or {}).get("contatti") or []
            if contatti:
                L.append("")
                L.append("  **Invio istanza RFI — %s** (verificare la DOIT competente per la linea):"
                         % (rfi_c.get("struttura") or "RFI"))
                for c in contatti:
                    ref = ", ".join(c.get("referenti") or [])
                    L.append("  - DOIT **%s** — PEC: `%s`%s" % (
                        c.get("doit", "?"), c.get("pec", "n/d"),
                        (" — referenti: %s" % ref) if ref else ""))
                L.append("  _Fonte: Open Fiber – Modalità di invio delle istanze RFI. "
                         "Verificare la DOIT territorialmente competente per la specifica linea._")
        if rep.get("ferrovie_dismesse"):
            L.append("- **Ex sedimi ferroviari** (linee dismesse): %s — il sedime resta "
                     "di norma di proprietà RFI anche se riconvertito: serve il nulla osta"
                     % ", ".join(rep["ferrovie_dismesse"]))
        if rep.get("corsi_acqua"):
            L.append("- **Corsi d'acqua** (%d): %s%s" % (
                len(rep["corsi_acqua"]), ", ".join(rep["corsi_acqua"][:8]),
                " …" if len(rep["corsi_acqua"]) > 8 else ""))
        L.append("")

    idg = rep.get("idrogeologico")
    if idg:
        idr = idg["idraulica"]; fr = idg["frane"]
        L += ["## 3-bis. Pericolosità idrogeologica (ISPRA IdroGEO — dato comunale)", "",
              "| Tipo | Classe | % del territorio comunale |", "|---|---|---:|",
              "| Idraulica (PGRA) | P3 elevata | %.1f%% |" % idr["P3_elevata_pct"],
              "| Idraulica (PGRA) | P2 media | %.1f%% |" % idr["P2_media_pct"],
              "| Idraulica (PGRA) | P1 bassa | %.1f%% |" % idr["P1_bassa_pct"],
              "| Frane (PAI) | P4+P3 | %.1f%% |" % fr["P3P4_pct"], "",
              "_Percentuali riferite all'**intero comune** (fonte ISPRA, mosaicatura "
              "nazionale PAI/PGRA), non all'area di progetto: indicano se il territorio "
              "ha aree vincolate. Se il tracciato ricade in una di queste aree va verificato "
              "sul PAI del distretto / geoportale regionale._", ""]

    L += ["## 4. Enti da interpellare", ""]
    for i, e in enumerate(rep["enti"], 1):
        sc = e["scheda"] or {}
        L.append("### %d. %s" % (i, e["ente"]))
        L.append("*%s* — trigger: %s" % (e["ruolo"], e["trigger"]))
        if e.get("nota_competenza"):
            L.append("\n> ⚠️ **Competenza**: %s" % e["nota_competenza"])
        if e.get("nota_gestore"):
            L.append("\n> 🛣️ **Gestore della strada**: %s" % e["nota_gestore"])
        if e.get("contatti", {}).get("pec"):
            L.append("PEC: `%s` · %s" % (e["contatti"]["pec"], e["contatti"].get("sito", "")))
        if sc.get("titolo_richiesto"):
            L.append("\n**Titolo**: %s" % sc["titolo_richiesto"])
        if sc.get("norme"):
            nn = [KB["norme"][n]["id"] for n in sc["norme"] if n in KB["norme"]]
            L.append("**Riferimenti**: %s" % ", ".join(nn))
        if sc.get("documentazione_tipica"):
            L.append("\n**Documentazione tipica**:")
            L += ["- %s" % d for d in sc["documentazione_tipica"]]
        if sc.get("criticita"):
            L.append("\n**Criticità note**:")
            L += ["- %s" % d for d in sc["criticita"]]
        L.append("")

    if rep.get("warning"):
        L += ["## 5. Warning e incoerenze rilevate", ""]
        L += ["- %s" % w for w in rep["warning"]]
        L.append("")

    L += ["## 6. Provenienza e affidabilità dei dati", "",
          "| Stadio | Fonte | Confidenza | Errore |", "|---|---|---|---|"]
    for f in rep["fonti"]:
        L.append("| %s | %s | %s | %s |" % (f["stadio"], f["fonte"], f["confidenza"], f.get("errore") or "—"))
    L += ["", "---", "",
          "**Non coperto da questo screening** (richiede fonti regionali/locali): "
          "vincolo idrogeologico, PAI e fasce di pericolosità, usi civici, PUGSS e "
          "regolamento scavi comunale, sottoservizi esistenti (SINFI), reti Natura 2000, "
          "servitù militari, piani di rischio aeroportuale."]
    return "\n".join(L)


# ---------------------------------------------------------------------------
# GeoJSON per il caricamento in mappa (consumato dal pannello QGIS)
# ---------------------------------------------------------------------------
def geojson_strade(elementi, rep=None, solo_rilevanti=True):
    """Way Overpass (con 'geometry') -> FeatureCollection di LineString con
    classe/ref/operator/name. Solo le way classificate. Se `rep` è dato, aggiunge
    lo 'stato' dell'analisi sul tracciato (ATTRAVERSAMENTO/entro fascia/fuori
    fascia) per ref, così lo stile QGIS può categorizzare per stato.

    solo_rilevanti=True (default): in modalità tracciato/ARLO NON disegna le strade
    'fuori fascia' — quelle a distanza tale da non generare alcun obbligo. Senza
    questo filtro una SP che passa a km dal progetto veniva disegnata su tutta la
    sua lunghezza, ingombrando la tavola con strade irrilevanti (caso Siculiana
    SP75 a 2-8 km). Le strade rilevanti (attraversamento/entro fascia) restano.
    """
    # mappa ref -> stato dalle reti analizzate (se disponibili)
    stato_per_ref = {}
    ref_fuori = set()      # ref presenti SOLO come fuori fascia
    ref_rilevanti = set()  # ref con almeno un tratto entro fascia/attraversamento
    if rep is not None:
        for chiave in ("rete_stradale", "rete_stradale_solo_osm",
                       "rete_stradale_non_misurate", "rete_stradale_fuori"):
            for cls, refs in (rep.get(chiave) or {}).items():
                for ref, v in refs.items():
                    st = v.get("stato")
                    if st and ref not in stato_per_ref:
                        stato_per_ref[ref] = st
                    if chiave == "rete_stradale_fuori":
                        ref_fuori.add(ref)
                    else:
                        ref_rilevanti.add(ref)
    # una strada è "solo fuori fascia" se compare tra le fuori e MAI tra le rilevanti
    solo_fuori = ref_fuori - ref_rilevanti
    feats = []
    for e in elementi or []:
        geomtr = e.get("geometry")
        if not geomtr:
            continue
        t = e.get("tags", {})
        parsed = normalizza_ref(t.get("ref", ""))
        if not parsed:
            continue
        cls, ref_norm = parsed
        # filtro rilevanza: in analisi tracciato/ARLO scarta le strade che sono
        # SOLO fuori fascia (irrilevanti, altrimenti riempiono la mappa di linee
        # che non c'entrano col progetto — es. SP75 a chilometri di distanza).
        if solo_rilevanti and ref_norm in solo_fuori:
            continue
        # stato sintetico per lo stile: attraversamento / entro fascia / fuori / n.d.
        st_raw = stato_per_ref.get(ref_norm, "")
        if "ATTRAVERS" in st_raw.upper() or "attravers" in st_raw:
            stato_cls = "attraversamento"
        elif "fuori fascia" in st_raw:
            stato_cls = "fuori fascia"
        elif st_raw:
            stato_cls = "entro fascia"
        else:
            stato_cls = "n.d."
        feats.append({
            "type": "Feature",
            "properties": {"classe": cls, "ref": ref_norm,
                           "operator": t.get("operator") or "",
                           "name": t.get("name") or "",
                           "stato": stato_cls, "stato_dett": st_raw},
            "geometry": {"type": "LineString",
                         "coordinates": [[p["lon"], p["lat"]] for p in geomtr]},
        })
    return {"type": "FeatureCollection", "features": feats}


def geojson_lineari(elementi):
    """Ferrovie e corsi d'acqua Overpass -> FeatureCollection di LineString."""
    feats = []
    for e in elementi or []:
        geomtr = e.get("geometry")
        if not geomtr:
            continue
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            tipo = "ferrovia"
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            tipo = "ex sedime ferroviario"
        elif t.get("waterway") in {"river", "stream", "canal"}:
            tipo = "corso d'acqua"
        else:
            continue
        feats.append({
            "type": "Feature",
            "properties": {"tipo": tipo, "name": t.get("name") or "",
                           "operator": t.get("operator") or "",
                           "etichetta": (t.get("name") or "").strip() or tipo},
            "geometry": {"type": "LineString",
                         "coordinates": [[p["lon"], p["lat"]] for p in geomtr]},
        })
    return {"type": "FeatureCollection", "features": feats}


def geojson_comune(rep):
    """Confine comunale (da Nominatim) -> FeatureCollection con un poligono."""
    from shapely.geometry import mapping
    g = rep.get("_geometria_comune")
    if g is None:
        return {"type": "FeatureCollection", "features": []}
    c = rep.get("comune", {})
    return {"type": "FeatureCollection", "features": [{
        "type": "Feature",
        "properties": {"nome": c.get("nome"), "istat": c.get("istat"),
                       "provincia": c.get("provincia"), "regione": c.get("regione")},
        "geometry": mapping(g),
    }]}


# ---------------------------------------------------------------------------
# Override da stradario locale (layer scelto dall'utente)
# ---------------------------------------------------------------------------
def rete_da_stradario(records):
    """records = [{"ref": <valore campo classificazione>, "name": str,
    "operator": str, "distanza_m": float|None}] estratti da un layer locale e
    già filtrati sull'area. Ritorna {classe: {ref_norm: {n_way, operator, nomi,
    [distanza_m, stato, fascia_m]}}}. Se i record portano 'distanza_m' (modalità
    tracciato), ogni ref riceve la distanza minima, lo stato rispetto alla
    fascia di rispetto della sua classe, e i ref oltre fascia vengono scartati."""
    finti = []
    dist_per = {}   # (cls,ref_norm) -> distanza minima
    for r in records:
        tags = {}
        if r.get("ref"):
            tags["ref"] = str(r["ref"])
        if r.get("name"):
            tags["name"] = str(r["name"])
        if r.get("operator"):
            tags["operator"] = str(r["operator"])
        finti.append({"tags": tags})
        d = r.get("distanza_m")
        if d is not None:
            parsed = normalizza_ref(str(r.get("ref") or ""))
            if parsed:
                k = parsed
                if k not in dist_per or d < dist_per[k]:
                    dist_per[k] = d
    rete = classifica_strade(finti)["strade"]
    if not dist_per:
        return rete
    # applica distanza/stato/fascia e scarta i ref oltre la fascia di rispetto
    fasce = {s["classe"]: s.get("fascia_rispetto_m", 0) for s in carica_kb()["strade"]}
    out = {}
    for cls, refs in rete.items():
        fascia = fasce.get(cls, 0)
        tenuti = {}
        for ref, v in refs.items():
            d = dist_per.get((cls, ref))
            if d is None:
                tenuti[ref] = v
                continue
            stato, prio = _classifica_distanza(d, fascia)
            if prio == 2:
                continue   # oltre fascia: non genera obbligo
            v["distanza_m"] = round(d, 1)
            v["stato"] = stato
            v["fascia_m"] = fascia
            tenuti[ref] = v
        if tenuti:
            out[cls] = tenuti
    return out


def fondi_stradario(rep, rete_stradario, nome_fonte, fonte_indipendente):
    """Fonde nel report la rete stradale da un layer locale (fonte primaria)
    con quella già presente da OSM/Overpass (controprova).

    - rep["rete_stradale"] diventa quella dello stradario, con ogni ref marcato
      'confermato_osm' True/False;
    - i ref presenti in OSM ma non nello stradario finiscono in
      rep["rete_stradale_solo_osm"] (potenziali strade che lo stradario locale
      non copre: NON vanno perse, vanno segnalate);
    - warning esplicito per ogni discordanza;
    - la fonte 'rete stradale' nel report è aggiornata a 'stradario locale …';
    - gli enti vengono ricomposti sulla rete fusa.
    fonte_indipendente=True quando il layer NON è un estratto OSM (DBSN, grafi
    regionali): allora la conferma incrociata ha valore; se False (ANAS_Italia,
    Stradario Provincia Italia = estratti OSM) il report lo dichiara."""
    osm = rep.get("rete_stradale", {})
    fusa = {}
    solo_osm = {}
    discordanze = []

    classi = set(rete_stradario) | set(osm)
    for cls in classi:
        refs_str = rete_stradario.get(cls, {})
        refs_osm = osm.get(cls, {})
        tenuti = {}
        for ref, v in refs_str.items():
            voce = dict(v)
            voce["confermato_osm"] = ref in refs_osm
            # se il report era già stato analizzato sul tracciato, la voce OSM
            # porta distanza_m/stato/fascia_m: propagali alla voce fusa così
            # non si perdono (fondi_stradario gira dopo analizza_su_tracciato)
            if ref in refs_osm:
                for campo in ("distanza_m", "stato", "fascia_m"):
                    # riempi dalla voce OSM SOLO se lo stradario primario (DBSN)
                    # non ha gia' calcolato il valore sulla propria geometria:
                    # la fonte primaria e' piu' accurata, non va sovrascritta
                    if campo not in voce and campo in refs_osm[ref]:
                        voce[campo] = refs_osm[ref][campo]
            tenuti[ref] = voce
            if ref not in refs_osm:
                discordanze.append("%s presente nello stradario '%s' ma non tra le "
                                   "strade OSM del comune: verificare." % (ref, nome_fonte))
        if tenuti:
            fusa[cls] = tenuti
        # ref che OSM ha e lo stradario no
        mancanti = {ref: v for ref, v in refs_osm.items() if ref not in refs_str}
        if mancanti:
            solo_osm[cls] = mancanti
            for ref in mancanti:
                discordanze.append("%s presente in OSM ma non nello stradario '%s': "
                                   "possibile riclassificazione o copertura mancante." % (ref, nome_fonte))

    rep["rete_stradale"] = fusa
    rep["rete_stradale_solo_osm"] = solo_osm
    rep["stradario_fonte"] = {"nome": nome_fonte, "indipendente": fonte_indipendente}
    rep["warning"] += discordanze

    # aggiorna la riga di provenienza della rete stradale
    et = ("stradario locale '%s' (fonte indipendente da OSM)" if fonte_indipendente
          else "stradario locale '%s' (ATTENZIONE: estratto OSM, stessa origine di Overpass)")
    trovato = False
    for f in rep.get("fonti", []):
        if f["stadio"] == "rete stradale":
            f["fonte"] = et % nome_fonte
            f["confidenza"] = "alta" if fonte_indipendente else "media"
            trovato = True
            break
    if not trovato:
        rep.setdefault("fonti", []).append(
            {"stadio": "rete stradale (stradario)", "fonte": et % nome_fonte,
             "confidenza": "alta" if fonte_indipendente else "media", "errore": None})

    if not fonte_indipendente:
        rep["warning"].append(
            "Lo stradario di riferimento '%s' è un estratto OpenStreetMap (campo osm_id): "
            "la conferma incrociata con Overpass NON aggiunge una fonte indipendente. "
            "Per una verifica indipendente usare come riferimento il DBSN (IGM) o un grafo "
            "regionale." % nome_fonte)

    rep["enti"] = componi_enti(rep)
    return rep


def geojson_vincoli(geometrie):
    """[(etichetta, feature SITAP)] -> FeatureCollection con l'etichetta del vincolo."""
    feats = []
    for etichetta, f in geometrie or []:
        if not f.get("geometry"):
            continue
        feats.append({"type": "Feature",
                      "properties": {"vincolo": etichetta},
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_natura2000(geometrie):
    """Estrae dai _geometrie_vincoli i soli poligoni Natura 2000 (etichetta che
    inizia per 'Natura 2000') -> FeatureCollection con tipo/codice/nome, per uno
    stile e uno shape dedicati distinti dai vincoli paesaggistici SITAP."""
    feats = []
    for etichetta, f in geometrie or []:
        if not str(etichetta).startswith("Natura 2000"):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_parchi(geometrie):
    """Estrae dai _geometrie_vincoli i soli poligoni delle aree protette (etichetta
    che inizia per 'Parco') -> FeatureCollection, per uno shape/stile dedicati."""
    feats = []
    for etichetta, f in geometrie or []:
        if not str(etichetta).startswith("Parco"):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_boschi(geometrie):
    """Estrae dai _geometrie_vincoli i poligoni delle aree boscate (art.142 lett.g).
    Cattura sia 'Area boscata' (OSM) sia 'Aree boscate' (geoportale Sicilia)."""
    feats = []
    for etichetta, f in geometrie or []:
        e = str(etichetta).lower()
        if not ("area boscata" in e or "aree boscate" in e):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_fasce142(geometrie):
    """Estrae dai _geometrie_vincoli le fasce art.142 costa/fiumi (etichetta che
    inizia per 'Fascia') -> FeatureCollection, per uno shape/stile dedicati."""
    feats = []
    for etichetta, f in geometrie or []:
        if not str(etichetta).startswith("Fascia"):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_armadi(armadi_analisi):
    """Punti armadi ottici analizzati -> FeatureCollection di Point, con lo stato
    del vincolo per lo stile QGIS (vincolato_136_142 / vincolato_ucp / libero)."""
    feats = []
    for a in armadi_analisi or []:
        if a.get("lon") is None or a.get("lat") is None:
            continue
        if a.get("gruppo_a"):
            stato = "Soprintendenza (art.136/142)"
        elif a.get("gruppo_b"):
            stato = "Regione/Comune (UCP)"
        else:
            stato = "nessun vincolo"
        feats.append({
            "type": "Feature",
            "properties": {
                "id": a.get("id", ""), "tipo": a.get("tipo", ""),
                "indirizzo": a.get("indirizzo", ""), "stato": stato,
                "competenza": a.get("competenza", ""),
            },
            "geometry": {"type": "Point", "coordinates": [a["lon"], a["lat"]]},
        })
    return {"type": "FeatureCollection", "features": feats}


def geojson_vincoli_sitap(geometrie):
    """Vincoli paesaggistici da mettere nel layer 'Vincoli SITAP': ESCLUDE Natura
    2000, parchi, aree boscate e fasce costa/fiumi (che hanno il loro layer dedicato).
    Tiene art.136 decretati, UNESCO, zone umide e simili."""
    feats = []
    for etichetta, f in geometrie or []:
        e = str(etichetta).lower()
        if (e.startswith("natura 2000") or e.startswith("parco")
                or "area boscata" in e or "aree boscate" in e or e.startswith("fascia")):
            continue
        if not f.get("geometry"):
            continue
        feats.append({"type": "Feature",
                      "properties": {"vincolo": etichetta},
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


# ---------------------------------------------------------------------------
# Restrizione all'area di progetto (es. ARLO AREA)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Analisi sul TRACCIATO reale con fasce di rispetto ufficiali
# ---------------------------------------------------------------------------
def _metrico(geom_wgs84):
    """Riproietta una geometria da WGS84 al UTM locale (metri) per misure di
    distanza corrette. Sceglie la zona UTM dal centroide. Se pyproj non è
    disponibile usa una proiezione equirettangolare locale (accurata su pochi
    km, più che sufficiente per le distanze di fascia di rispetto)."""
    from shapely.ops import transform as _shp_transform
    c = geom_wgs84.centroid
    if c.is_empty:
        # GeometryCollection con parti vuote, o geometria degenere: ripiega sul
        # centro del bounding box (sempre definito se la geom ha estensione)
        try:
            minx, miny, maxx, maxy = geom_wgs84.bounds
            from shapely.geometry import Point as _P
            c = _P((minx + maxx) / 2.0, (miny + maxy) / 2.0)
        except Exception:  # noqa: BLE001
            from shapely.geometry import Point as _P
            c = _P(0.0, 0.0)
    try:
        import pyproj
        zona = int((c.x + 180) / 6) + 1
        epsg = 32600 + zona if c.y >= 0 else 32700 + zona
        trasf = pyproj.Transformer.from_crs("EPSG:4326", "EPSG:%d" % epsg, always_xy=True).transform
        return _shp_transform(trasf, geom_wgs84), ("pyproj", epsg)
    except Exception:  # noqa: BLE001
        import math
        lat0 = math.radians(c.y)
        kx = 111320.0 * math.cos(lat0)   # m per grado di longitudine alla latitudine
        ky = 110540.0                     # m per grado di latitudine
        x0, y0 = c.x, c.y

        def _loc(x, y, z=None):
            return ((x - x0) * kx, (y - y0) * ky)
        return _shp_transform(_loc, geom_wgs84), ("locale", (x0, y0, kx, ky))


def _proiettore_metrico(info):
    """Ritorna una funzione shapely-transform coerente con _metrico(), per
    proiettare altre geometrie nello stesso sistema metrico locale."""
    tipo, dati = info
    if tipo == "pyproj":
        import pyproj
        return pyproj.Transformer.from_crs("EPSG:4326", "EPSG:%d" % dati, always_xy=True).transform
    x0, y0, kx, ky = dati

    def _loc(x, y, z=None):
        return ((x - x0) * kx, (y - y0) * ky)
    return _loc


def _classifica_distanza(dist_m, fascia_m):
    """Verdetto per una interferenza dato distanza e fascia di rispetto.
    Ritorna (stato, priorita) con priorita per l'ordinamento (0 = più grave)."""
    if dist_m <= 0.5:
        return "ATTRAVERSAMENTO", 0
    if fascia_m and dist_m <= fascia_m:
        return "entro fascia di rispetto (%.0f m)" % fascia_m, 1
    return "fuori fascia (%.0f m)" % dist_m, 2


def _rapporto_tracciato(tracciato_m, elemento_m, fascia_m):
    """Rapporto geometrico tra tracciato di progetto ed elemento (strada/lineare),
    entrambi gia' proiettati in metri. Ritorna dict con:
      - distanza_m: distanza minima
      - attraversamenti: n. di punti in cui il tracciato incrocia l'elemento
      - affiancamento_m: metri di tracciato che corrono entro la fascia
        (posa longitudinale — cio' che conta per canone e regime autorizzativo)
    Distingue l'attraversamento puntuale ('taglio la SP in un punto') dalla posa
    in affiancamento ('corro lungo la SP per N metri')."""
    out = {"distanza_m": None, "attraversamenti": 0, "affiancamento_m": 0.0}
    try:
        out["distanza_m"] = tracciato_m.distance(elemento_m)
    except Exception:  # noqa: BLE001
        return out
    # attraversamenti: intersezione geometrica tracciato x elemento (linee)
    try:
        inter = tracciato_m.intersection(elemento_m)
        if not inter.is_empty:
            from shapely.geometry import Point, MultiPoint, GeometryCollection
            if isinstance(inter, Point):
                out["attraversamenti"] = 1
            elif isinstance(inter, (MultiPoint, GeometryCollection)):
                out["attraversamenti"] = sum(
                    1 for g in getattr(inter, "geoms", []) if g.geom_type == "Point")
            elif inter.geom_type in ("LineString", "MultiLineString"):
                out["attraversamenti"] = 1  # sovrapposizione = almeno un contatto
    except Exception:  # noqa: BLE001
        pass
    # affiancamento: lunghezza del tracciato entro la fascia dell'elemento
    if fascia_m and fascia_m > 0:
        try:
            fascia_poly = elemento_m.buffer(fascia_m)
            dentro = tracciato_m.intersection(fascia_poly)
            if not dentro.is_empty and dentro.geom_type in ("LineString", "MultiLineString"):
                out["affiancamento_m"] = round(dentro.length, 1)
        except Exception:  # noqa: BLE001
            pass
    return out


def analizza_su_tracciato(rep, tracciato, buffer_m=0.0, nome_tracciato="tracciato di progetto"):
    """Ricalcola il report misurando la distanza REALE (in metri) tra il
    tracciato di progetto e ogni ente/vincolo, confrontandola con la fascia di
    rispetto ufficiale di quell'ente.

    `tracciato` = geometria shapely in EPSG:4326 (unione di 03 INFRASTRUTTURE +
    pozzetti + armadi). `buffer_m` = margine extra applicato al tracciato prima
    del test (0 = distanza pura). Richiede rep con raccogli_geometrie=True.

    Differenza da restringi_ad_area: non filtra per intersezione con un poligono,
    ma calcola distanze metriche e assegna a ogni interferenza uno STATO
    (attraversamento / entro fascia / fuori) in base alla fascia ufficiale. Ogni
    voce guadagna 'distanza_m', 'stato', 'fascia_m'. Le strade/vincoli entro la
    propria fascia restano nel report (le fasce di rispetto obbligano comunque);
    quelli oltre la fascia vengono scartati dagli enti ma restano tracciati come
    'fuori fascia' per trasparenza."""
    if "_elementi_strade" not in rep:
        raise ValueError("report senza geometrie: rilancia esegui() con raccogli_geometrie=True")
    from shapely.geometry import LineString, shape as _shape

    # tracciato in metri (UTM locale o proiezione locale se pyproj manca)
    tr_m_puro, info = _metrico(tracciato)   # senza buffer, per affiancamento/attraversamenti
    tr_m = tr_m_puro
    if buffer_m and buffer_m > 0:
        tr_m = tr_m_puro.buffer(buffer_m)
    to_m = _proiettore_metrico(info)
    from shapely.ops import transform as _t

    def dist_m(geom_wgs):
        try:
            return tr_m.distance(_t(to_m, geom_wgs))
        except Exception:  # noqa: BLE001
            return None

    nuovo = {k: v for k, v in rep.items()
             if k not in {"rete_stradale", "vincoli", "ferrovie", "ferrovie_dismesse",
                          "corsi_acqua", "boschi", "enti", "warning",
                          "_elementi_strade", "_elementi_lineari", "_geometrie_vincoli"}}
    nuovo["warning"] = list(rep.get("warning", []))
    nuovo["area_progetto"] = {"nome": nome_tracciato, "modalita": "tracciato",
                              "buffer_m": buffer_m}
    # salva il tracciato (WGS84) + buffer per l'attribuzione ARLO basata sul
    # tracciato reale: l'ARLO di una strada è la zona dove il tracciato di
    # progetto incontra la strada, non dove passa la geometria OSM (che sovrastima)
    try:
        nuovo["_tracciato_wgs"] = tracciato.wkt
        nuovo["_tracciato_buffer_m"] = buffer_m
    except Exception:  # noqa: BLE001
        pass

    def _geom_way(e):
        pts = e.get("geometry")
        if not pts or len(pts) < 2:
            return None
        try:
            return LineString([(p["lon"], p["lat"]) for p in pts])
        except Exception:  # noqa: BLE001
            return None

    # fasce per classe strada, dalla kb
    fasce_strada = {}
    for s in carica_kb()["strade"]:
        fasce_strada[s["classe"]] = s.get("fascia_rispetto_m", 0)

    # strade: per ogni ref aggrega distanza minima, metri di affiancamento
    # (posa longitudinale) e n. di attraversamenti puntuali
    el_strade = []
    dist_ref = {}     # (cls,ref) -> distanza minima
    aff_ref = {}      # (cls,ref) -> metri di affiancamento totali
    attr_ref = {}     # (cls,ref) -> n. attraversamenti
    for e in rep.get("_elementi_strade") or []:
        g = _geom_way(e)
        if g is None:
            continue
        parsed = normalizza_ref(e.get("tags", {}).get("ref", ""))
        if not parsed:
            continue
        cls = parsed[0]
        fascia = fasce_strada.get(cls, 0)
        try:
            g_m = _t(to_m, g)
        except Exception:  # noqa: BLE001
            continue
        rap = _rapporto_tracciato(tr_m_puro, g_m, fascia)
        d = rap["distanza_m"]
        if d is None:
            continue
        k = parsed
        if k not in dist_ref or d < dist_ref[k]:
            dist_ref[k] = d
        aff_ref[k] = aff_ref.get(k, 0.0) + rap["affiancamento_m"]
        attr_ref[k] = attr_ref.get(k, 0) + rap["attraversamenti"]
        el_strade.append(e)
    rete = {}
    rete_fuori = {}   # strade classificate del comune FUORI fascia dal tracciato
    rete_non_mis = {} # classificate ma senza geometria misurabile in questo run
    # se il comune è un grande centro (>10.000 ab) le fasce di rispetto DPR
    # 495/1992 NON valgono dentro il perimetro urbano (art.4 CdS): lì è
    # occupazione suolo, non fascia. Segnaliamo il caveat per non over-riportare
    grande_centro = ((rep.get("comune") or {}).get("popolazione") or 0) > 10000
    for cls, refs in rep.get("rete_stradale", {}).items():
        fascia = fasce_strada.get(cls, 0)
        tenuti = {}
        fuori = {}
        non_misurate = {}
        for ref, v in refs.items():
            d = dist_ref.get((cls, ref))
            if d is None:
                # la strada è classificata (OSM ha ref+tag) ma manca la geometria
                # in _elementi_strade (Overpass non l'ha restituita, o è oltre il
                # bbox): NON scartarla in silenzio — un affiancamento longitudinale
                # potrebbe esserci e non l'abbiamo potuto misurare. La teniamo con
                # stato esplicito e alziamo un warning, così finisce nel report.
                voce = dict(v)
                voce["distanza_m"] = None
                voce["stato"] = "non misurata (geometria assente in OSM)"
                voce["fascia_m"] = fascia
                non_misurate[ref] = voce
                continue
            stato, prio = _classifica_distanza(d, fascia)
            if prio == 2:   # fuori fascia: non genera obbligo, ma resta a titolo informativo
                voce = dict(v)
                voce["distanza_m"] = round(d, 1)
                voce["stato"] = "fuori fascia (%.0f m)" % d
                voce["fascia_m"] = fascia
                fuori[ref] = voce
                continue
            voce = dict(v)
            voce["distanza_m"] = round(d, 1)
            voce["stato"] = stato
            voce["fascia_m"] = fascia
            aff = round(aff_ref.get((cls, ref), 0.0))
            attr = attr_ref.get((cls, ref), 0)
            voce["affiancamento_m"] = aff
            voce["attraversamenti"] = attr
            # stato piu' informativo: distingue posa longitudinale da taglio
            if aff >= 5:
                voce["stato"] = "affiancamento ~%d m%s" % (
                    aff, " + %d attravers." % attr if attr else "")
            elif attr:
                voce["stato"] = "%d attraversament%s" % (attr, "o" if attr == 1 else "i")
            # caveat centro abitato: se è solo prossimità in fascia (non
            # attraversamento) in un grande centro, la fascia potrebbe non valere
            if grande_centro and prio == 1 and not attr and aff < 5:
                voce["stato"] += " (se fuori centro abitato)"
            tenuti[ref] = voce
        if tenuti:
            rete[cls] = tenuti
        if fuori:
            rete_fuori[cls] = fuori
        if non_misurate:
            rete_non_mis.setdefault(cls, {}).update(non_misurate)
            for ref in non_misurate:
                nuovo["warning"].append(
                    "%s: strada classificata in OSM ma senza geometria disponibile "
                    "in questo run — distanza/affiancamento NON misurati. Verificare "
                    "manualmente se il tracciato le corre a fianco (posa longitudinale)."
                    % ref)
    nuovo["rete_stradale"] = rete
    nuovo["rete_stradale_fuori"] = rete_fuori
    nuovo["rete_stradale_non_misurate"] = rete_non_mis
    nuovo["_elementi_strade"] = el_strade

    # vincoli SITAP: i poligoni SONO gia' l'area vincolata (art.136 decretati,
    # art.142 boschi/fasce mappate). Un vincolo areale conta se il tracciato lo
    # ATTRAVERSA (distanza ~0) o ricade entro il margine scelto (buffer_m): non
    # esiste una "fascia di rispetto" di 150 m attorno a un bosco o a un decreto.
    # I 150 m dell'art.142 lett.c sono gia' incorporati nei poligoni SITAP della
    # fascia fluviale. Margine di tolleranza per l'accuratezza posizionale SITAP.
    margine_vinc = max(buffer_m, 5.0)
    geometrie_tenute = []
    per_etichetta = {}
    for etichetta, f in rep.get("_geometrie_vincoli") or []:
        try:
            g = _shape(f["geometry"])
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        d = dist_m(g)
        if d is None:
            continue
        rec = per_etichetta.setdefault(etichetta, {"n": 0, "dmin": d})
        rec["n"] += 1
        rec["dmin"] = min(rec["dmin"], d)
        # CONSERVA TUTTE le geometrie dei vincoli comunali per lo shape (riscontro
        # visivo completo di ciò che è nell'Excel), non solo quelle attraversate dal
        # tracciato. Marca lo stato nella property così lo stile può distinguerle.
        f2 = dict(f)
        props = dict(f2.get("properties", {}))
        props["stato_tracc"] = ("attraversato" if d <= margine_vinc else "nel comune")
        props["dist_m"] = round(d, 1)
        f2["properties"] = props
        geometrie_tenute.append((etichetta, f2))
    vincoli = []
    for v in rep.get("vincoli", []):
        rec = per_etichetta.get(v["etichetta"])
        if not rec:
            continue
        voce = dict(v)
        voce["distanza_m"] = round(rec["dmin"], 1)
        if rec["dmin"] <= 0.5:
            voce["stato"] = "ATTRAVERSAMENTO"
        elif rec["dmin"] <= margine_vinc:
            voce["stato"] = "entro %.0f m dal vincolo (verificare)" % rec["dmin"]
        else:
            # il vincolo è nel comune ma il tracciato non lo tocca: lo teniamo
            # comunque (riscontro visivo + l'utente vuole vedere tutto in tabella)
            voce["stato"] = "presente nel comune (tracciato a %.0f m)" % rec["dmin"]
        vincoli.append(voce)
    nuovo["vincoli"] = vincoli
    nuovo["_geometrie_vincoli"] = geometrie_tenute

    # lineari: ferrovie (30 m) e corsi d'acqua (150 m paesagg.)
    el_lineari = []
    ferr, ferr_dism, acque = {}, {}, {}
    boschi = {}
    fascia_ferr = next((v.get("fascia_rispetto_m", 30) for v in carica_kb()["vincoli"]
                        if v["chiave"] == "ferrovia"), 30)
    fascia_idr = next((v.get("fascia_rispetto_m", 150) for v in carica_kb()["vincoli"]
                       if v["chiave"] == "idrico"), 150)
    for e in rep.get("_elementi_lineari") or []:
        g = _geom_way(e)
        if g is None:
            continue
        d = dist_m(g)
        if d is None:
            continue
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            stato, prio = _classifica_distanza(d, fascia_ferr)
            if prio == 2:
                continue
            nome = t.get("operator") or t.get("name") or "linea ferroviaria"
            if nome not in ferr or d < ferr[nome]:
                ferr[nome] = d
            el_lineari.append(e)
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            if d <= max(fascia_ferr, 5):
                nome = t.get("name") or "ex sedime ferroviario"
                ferr_dism[nome] = min(ferr_dism.get(nome, d), d)
                el_lineari.append(e)
        elif t.get("waterway") in {"river", "stream", "canal"}:
            stato, prio = _classifica_distanza(d, fascia_idr)
            if prio == 2:
                continue
            nome_acq = t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"]
            acque[nome_acq] = min(acque.get(nome_acq, d), d)
            el_lineari.append(e)
        elif t.get("natural") == "wood" or t.get("landuse") == "forest":
            # boschi: fascia paesaggistica art.142 lett.g = 150 m come i corsi
            stato, prio = _classifica_distanza(d, 150)
            if prio == 2:
                continue
            nome_b = t.get("name") or "area boscata senza nome"
            boschi[nome_b] = min(boschi.get(nome_b, d), d)
            el_lineari.append(e)
    nuovo["ferrovie"] = sorted(ferr)[:10]
    nuovo["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    nuovo["corsi_acqua"] = sorted(acque)[:15]
    nuovo["boschi"] = sorted(boschi)[:15]
    nuovo["_distanze_lineari"] = {"ferrovie": ferr, "corsi_acqua": acque, "boschi": boschi}
    nuovo["_elementi_lineari"] = el_lineari

    nuovo["warning"].append(
        "Analisi sul TRACCIATO '%s' (buffer %.0f m): le distanze sono misurate in "
        "metri dal tracciato reale (03 INFRASTRUTTURE + pozzetti + armadi) e "
        "confrontate con le fasce di rispetto ufficiali. 'ATTRAVERSAMENTO' = il "
        "tracciato interseca l'ente; 'entro fascia' = ricade nella fascia di rispetto "
        "(l'autorizzazione serve comunque). Le distanze OSM/SITAP hanno accuratezza "
        "posizionale variabile: per gli attraversamenti critici verificare in campo." %
        (nome_tracciato, buffer_m))
    nuovo["enti"] = componi_enti(nuovo)
    return nuovo


def restringi_ad_area(rep, area, nome_area="area di progetto"):
    """Ricalcola il report sull'intersezione con `area` (geometria shapely in
    EPSG:4326, tipicamente l'unione dei poligoni ARLO AREA).

    Richiede un report prodotto con raccogli_geometrie=True: il filtro avviene
    sulle geometrie vere, non sui conteggi. Ritorna un NUOVO report con:
    - rete_stradale: solo i ref con almeno un segmento che interseca l'area
      (ogni voce guadagna 'n_way_area');
    - vincoli: solo quelli che intersecano l'area, con pct ricalcolata
      sull'area (non sul comune);
    - ferrovie/ferrovie_dismesse/corsi_acqua: solo se intersecano l'area;
    - enti: ricomposti sui soli trigger sopravvissuti;
    - le Soprintendenze restano: la competenza è territoriale, non di tracciato.
    Le geometrie raccolte vengono a loro volta filtrate, così i layer caricati
    in mappa mostrano solo ciò che tocca l'area."""
    if "_elementi_strade" not in rep:
        raise ValueError("report senza geometrie: rilancia esegui() con raccogli_geometrie=True")

    nuovo = {k: v for k, v in rep.items()
             if k not in {"rete_stradale", "vincoli", "ferrovie", "ferrovie_dismesse",
                          "corsi_acqua", "boschi", "enti", "warning",
                          "_elementi_strade", "_elementi_lineari", "_geometrie_vincoli"}}
    nuovo["warning"] = list(rep.get("warning", []))
    nuovo["area_progetto"] = {"nome": nome_area}

    def _geom_way(e):
        pts = e.get("geometry")
        if not pts or len(pts) < 2:
            return None
        try:
            from shapely.geometry import LineString
            return LineString([(p["lon"], p["lat"]) for p in pts])
        except Exception:  # noqa: BLE001
            return None

    # strade: tiene il ref se almeno un segmento tocca l'area
    el_strade = []
    refs_in_area = {}
    for e in rep.get("_elementi_strade") or []:
        g = _geom_way(e)
        if g is None or not g.intersects(area):
            continue
        el_strade.append(e)
        parsed = normalizza_ref(e.get("tags", {}).get("ref", ""))
        if parsed:
            refs_in_area.setdefault(parsed[0], {}).setdefault(parsed[1], 0)
            refs_in_area[parsed[0]][parsed[1]] += 1
    rete = {}
    for cls, refs in rep.get("rete_stradale", {}).items():
        tenuti = {}
        for ref, v in refs.items():
            n_area = refs_in_area.get(cls, {}).get(ref, 0)
            if n_area:
                voce = dict(v)
                voce["n_way_area"] = n_area
                tenuti[ref] = voce
        if tenuti:
            rete[cls] = tenuti
    nuovo["rete_stradale"] = rete
    nuovo["_elementi_strade"] = el_strade

    # vincoli: pct ricalcolata sull'area di progetto
    geometrie_tenute = []
    per_etichetta = {}
    for etichetta, f in rep.get("_geometrie_vincoli") or []:
        try:
            from shapely.geometry import shape as _shape
            g = _shape(f["geometry"])
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        if not g.intersects(area):
            continue
        geometrie_tenute.append((etichetta, f))
        rec = per_etichetta.setdefault(etichetta, {"n": 0, "inters": []})
        rec["n"] += 1
        try:
            rec["inters"].append(g.intersection(area))
        except Exception:  # noqa: BLE001
            pass
    vincoli = []
    for v in rep.get("vincoli", []):
        rec = per_etichetta.get(v["etichetta"])
        if not rec:
            continue
        voce = dict(v)
        voce["n_poligoni"] = rec["n"]
        # union delle intersezioni: poligoni sovrapposti non gonfiano l'area
        area_int = 0.0
        if rec["inters"]:
            try:
                from shapely.ops import unary_union
                u = unary_union(rec["inters"])
                if not u.is_valid:
                    u = u.buffer(0)
                area_int = u.area
            except Exception:  # noqa: BLE001
                area_int = max((x.area for x in rec["inters"]), default=0.0)
        voce["pct_territorio"] = round(min(area_int / area.area * 100, 100.0), 1) if area.area else 0.0
        vincoli.append(voce)
    nuovo["vincoli"] = vincoli
    nuovo["_geometrie_vincoli"] = geometrie_tenute

    # lineari
    el_lineari = []
    ferr, ferr_dism, acque = set(), set(), set()
    boschi = set()
    for e in rep.get("_elementi_lineari") or []:
        g = _geom_way(e)
        if g is None or not g.intersects(area):
            continue
        el_lineari.append(e)
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            ferr.add(t.get("operator") or t.get("name") or "linea ferroviaria")
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            ferr_dism.add(t.get("name") or "ex sedime ferroviario")
        if t.get("waterway") in {"river", "stream", "canal"}:
            acque.add(t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"])
        if t.get("natural") == "wood" or t.get("landuse") == "forest":
            boschi.add(t.get("name") or "area boscata senza nome")
    nuovo["ferrovie"] = sorted(ferr)[:10]
    nuovo["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    nuovo["corsi_acqua"] = sorted(acque)[:15]
    nuovo["boschi"] = sorted(boschi)[:15]
    nuovo["_elementi_lineari"] = el_lineari

    nuovo["warning"].append(
        "Report ristretto a '%s': strade, vincoli e interferenze sono SOLO quelli "
        "che intersecano l'area; le percentuali dei vincoli sono riferite all'area, "
        "non al territorio comunale. Le fasce di rispetto (30 m ferrovia, 150 m "
        "corsi d'acqua) possono scattare anche per elementi appena FUORI dall'area." % nome_area)
    nuovo["enti"] = componi_enti(nuovo)
    return nuovo


# ---------------------------------------------------------------------------
# Attribuzione ARLO AREA: a ogni strada/vincolo/interferenza la zona che tocca
# ---------------------------------------------------------------------------
def attribuisci_arlo(rep, arlo_zone):
    """Assegna a ogni elemento del report la/le zona/e ARLO che interseca.

    `arlo_zone` = [(label, shapely_geom in EPSG:4326)] una per poligono ARLO.
    Aggiunge il campo 'arlo' (stringa, zone separate da ', ') a:
      - ogni voce di rep['rete_stradale'][cls][ref]  (via geometrie _elementi_strade)
      - ogni voce di rep['vincoli']                   (via _geometrie_vincoli)
      - rep['_arlo_ferrovie'] / ['_arlo_corsi'] per le interferenze lineari
    Non altera la logica degli enti: è puramente attributiva per il report.
    Modifica rep in-place e lo ritorna.
    """
    if not arlo_zone:
        return rep
    from shapely.geometry import LineString, shape as _shape

    def _zone_di(geom):
        """Etichette ARLO che intersecano una geometria (shapely, WGS84)."""
        if geom is None:
            return []
        out = []
        for lab, z in arlo_zone:
            try:
                if geom.intersects(z):
                    out.append(lab)
            except Exception:  # noqa: BLE001
                continue
        return out

    def _geom_way(e):
        pts = e.get("geometry")
        if not pts or len(pts) < 2:
            return None
        try:
            return LineString([(p["lon"], p["lat"]) for p in pts])
        except Exception:  # noqa: BLE001
            return None

    # tracciato di progetto (se presente): l'ARLO di una strada = le zone dove il
    # tracciato di scavo ricade ENTRO LA FASCIA DI RISPETTO di quella strada
    # (affiancamento/attraversamento), non dove passa la sola geometria OSM (che
    # sovrastima). La fascia dipende dalla classe (SP/SS/... da kb). Bufferizzo il
    # tracciato per fascia, con cache per non ricalcolare.
    _tracc = None
    if rep.get("_tracciato_wgs"):
        try:
            from shapely import wkt as _wktmod
            _tracc = _wktmod.loads(rep["_tracciato_wgs"])
        except Exception:  # noqa: BLE001
            _tracc = None
    _buf_cache = {}   # fascia_m -> tracciato bufferizzato (gradi)

    def _tracc_buf(fascia_m):
        if _tracc is None:
            return None
        key = round(fascia_m, 1)
        if key not in _buf_cache:
            try:
                _buf_cache[key] = _tracc.buffer(max(fascia_m, 5) / 111320.0)
            except Exception:  # noqa: BLE001
                _buf_cache[key] = None
        return _buf_cache[key]

    def _fascia_classe(cls):
        sc = scheda_strada(cls) or {}
        try:
            return float(sc.get("fascia_rispetto_m") or 30)
        except Exception:  # noqa: BLE001
            return 30.0

    # strade: raccogli le zone per ref (una way può stare in più ARLO)
    zone_per_ref = {}       # (cls,ref) -> set(label)
    for e in rep.get("_elementi_strade") or []:
        parsed = normalizza_ref(e.get("tags", {}).get("ref", ""))
        if not parsed:
            continue
        g_strada = _geom_way(e)
        if g_strada is None:
            continue
        # zona = dove la strada ricade nella fascia di rispetto attorno al
        # tracciato (= dove lo scavo è entro fascia di quella strada). Se non ho
        # il tracciato, ripiego sulla geometria della strada (comportamento pieno).
        g_valuta = g_strada
        tb = _tracc_buf(_fascia_classe(parsed[0]))
        if tb is not None:
            try:
                inter = g_strada.intersection(tb)
                if inter.is_empty:
                    continue   # lo scavo non è entro fascia di questa strada: niente ARLO
                g_valuta = inter
            except Exception:  # noqa: BLE001
                g_valuta = g_strada
        z = _zone_di(g_valuta)
        if z:
            zone_per_ref.setdefault(parsed, set()).update(z)
    for cls, refs in rep.get("rete_stradale", {}).items():
        for ref, v in refs.items():
            zz = zone_per_ref.get((cls, ref))
            if zz:
                v["arlo"] = ", ".join(sorted(zz))
    # anche le strade solo-OSM / non-misurate ricevono l'attribuzione ARLO:
    # senza questo il Riepilogo le mostrava con la colonna ARLO vuota pur
    # toccando le zone (Stornarella SP88 tocca ARLO 206/208 ma restava "—").
    for chiave in ("rete_stradale_fuori", "rete_stradale_solo_osm",
                   "rete_stradale_non_misurate"):
        for cls, refs in (rep.get(chiave) or {}).items():
            for ref, v in refs.items():
                zz = zone_per_ref.get((cls, ref))
                if zz:
                    v["arlo"] = ", ".join(sorted(zz))

    # vincoli: zone per etichetta vincolo
    zone_per_vinc = {}      # etichetta -> set(label)
    for etichetta, f in rep.get("_geometrie_vincoli") or []:
        try:
            g = _shape(f["geometry"])
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        z = _zone_di(g)
        if z:
            zone_per_vinc.setdefault(etichetta, set()).update(z)
    for v in rep.get("vincoli", []):
        zz = zone_per_vinc.get(v["etichetta"])
        if zz:
            v["arlo"] = ", ".join(sorted(zz))

    # interferenze lineari: zone per nome ferrovia/corso d'acqua
    zf, za = {}, {}
    for e in rep.get("_elementi_lineari") or []:
        t = e.get("tags", {})
        z = _zone_di(_geom_way(e))
        if not z:
            continue
        if t.get("railway") == "rail":
            nome = t.get("operator") or t.get("name") or "linea ferroviaria"
            zf.setdefault(nome, set()).update(z)
        elif t.get("waterway") in {"river", "stream", "canal"}:
            nome = t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"]
            za.setdefault(nome, set()).update(z)
    rep["_arlo_ferrovie"] = {k: ", ".join(sorted(v)) for k, v in zf.items()}
    rep["_arlo_corsi"] = {k: ", ".join(sorted(v)) for k, v in za.items()}
    rep["_arlo_zone_nomi"] = [lab for lab, _ in arlo_zone]

    # mappa INVERSA zona -> elementi che vi ricadono (per il foglio ARLO Area)
    dett = {lab: {"strade": [], "vincoli": [], "ferrovie": [], "corsi": []}
            for lab, _ in arlo_zone}
    for cls, refs in rep.get("rete_stradale", {}).items():
        for ref, v in refs.items():
            for lab in (v.get("arlo") or "").split(", "):
                if lab in dett:
                    stato = v.get("stato") or ""
                    dett[lab]["strade"].append((ref, cls, stato))
    for v in rep.get("vincoli", []):
        for lab in (v.get("arlo") or "").split(", "):
            if lab in dett:
                dett[lab]["vincoli"].append(v["etichetta"])
    for nome, labs in zf.items():
        for lab in labs:
            if lab in dett:
                dett[lab]["ferrovie"].append(nome)
    for nome, labs in za.items():
        for lab in labs:
            if lab in dett:
                dett[lab]["corsi"].append(nome)
    rep["_arlo_dettaglio"] = dett
    return rep


# ---------------------------------------------------------------------------
# Separazione enti impattati / presenti nel territorio, ed export XLSX
# ---------------------------------------------------------------------------
# Chi prepara la pratica deve sapere A CHI SCRIVERE: mescolare in un'unica
# tabella gli enti la cui competenza è toccata dal tracciato con quelli che
# esistono nel comune ma che il progetto non sfiora rende l'elenco inutile,
# perché non distingue le AZIONI dal CONTESTO.
IMPATTO_RETE = "impatto"        # competenza toccata dalla rete in progetto
IMPATTO_TERRITORIO = "territorio"  # presente nel comune, nessuna interferenza misurata
IMPATTO_IGNOTO = "ignoto"       # il dato per decidere non esiste in questo report


def modalita_screening(rep):
    """Dice su cosa è stato misurato il report: 'tracciato' (distanze metriche
    dalla rete reale), 'area' (intersezione con i poligoni di progetto) o
    'comune' (solo perimetro comunale). È il discriminante di tutto: senza
    tracciato né area NESSUN ente può essere dichiarato impattato."""
    ap = rep.get("area_progetto") or {}
    if not ap:
        return "comune"
    return "tracciato" if ap.get("modalita") == "tracciato" else "area"


def _motivo_strade(rep, classe, modo):
    """Perché questa classe di strade attiva (o no) il suo ente proprietario.
    Poggia sulla ripartizione che analizza_su_tracciato ha già fatto:
    rete_stradale = entro fascia o attraversata, rete_stradale_fuori = nel
    comune ma fuori fascia, rete_stradale_non_misurate = geometria mancante."""
    toccate, non_misurate = [], []
    for ref, v in (rep.get("rete_stradale") or {}).get(classe, {}).items():
        stato = v.get("stato")
        if modo == "area":
            toccate.append("%s (%s segmenti nell'area di progetto)"
                           % (ref, v.get("n_way_area") or "?"))
        elif stato:
            toccate.append("%s: %s" % (ref, stato))
        else:
            non_misurate.append(ref)
    # strade note solo a OSM: i dati sul tracciato ci sono lo stesso quando
    # Overpass ha restituito la geometria, e vanno trattati come gli altri
    for ref, v in (rep.get("rete_stradale_solo_osm") or {}).get(classe, {}).items():
        if v.get("stato"):
            toccate.append("%s: %s (strada solo in OSM)" % (ref, v["stato"]))
        elif v.get("distanza_m") is None:
            non_misurate.append("%s (solo OSM)" % ref)
    for ref in (rep.get("rete_stradale_non_misurate") or {}).get(classe, {}):
        non_misurate.append("%s (geometria assente in OSM)" % ref)

    if toccate:
        return IMPATTO_RETE, "; ".join(toccate[:10])
    if non_misurate:
        return IMPATTO_IGNOTO, ("interferenza NON misurata su: %s"
                                % ", ".join(non_misurate[:10]))
    return IMPATTO_TERRITORIO, "strade classificate presenti nel comune, nessuna interferenza rilevata"


def _motivo_vincoli(rep, etichette, modo):
    """Un vincolo attiva l'ente solo se il tracciato lo attraversa o ricade nel
    margine: analizza_su_tracciato scrive quel verdetto in vincoli[]['stato']."""
    stati = {v.get("etichetta"): v.get("stato") for v in rep.get("vincoli", [])}
    toccati, nel_comune, senza_stato = [], [], []
    for et in etichette or []:
        st = stati.get(et)
        if modo == "area":
            toccati.append("%s (interseca l'area di progetto)" % et)
        elif not st:
            senza_stato.append(et)
        elif st.startswith(("ATTRAVERSAMENTO", "entro")):
            toccati.append("%s: %s" % (et, st))
        else:
            nel_comune.append("%s: %s" % (et, st))
    if toccati:
        return IMPATTO_RETE, "; ".join(toccati[:8])
    if nel_comune:
        return IMPATTO_TERRITORIO, "; ".join(nel_comune[:8])
    if senza_stato:
        return IMPATTO_IGNOTO, "distanza dal tracciato non misurata: %s" % "; ".join(senza_stato[:8])
    return IMPATTO_TERRITORIO, ""


def classifica_enti_impatto(rep):
    """Separa gli enti del report in tre gruppi, usando SOLO dati che il report
    contiene davvero (nessuna euristica sul nome dell'ente):

      - IMPATTO_RETE: la competenza è toccata dalla rete in progetto
        (strada entro fascia/attraversata, vincolo intersecato, lineare entro
        la propria fascia di rispetto);
      - IMPATTO_TERRITORIO: l'ente esiste nel comune ma il tracciato misurato
        non lo interferisce;
      - IMPATTO_IGNOTO: il dato che servirebbe non è stato calcolato in questo
        run (geometria assente, livello informativo non ricalcolato sul
        tracciato). Mai spacciato per una delle due categorie precedenti.

    Ritorna (modo, gruppi) con gruppi = {categoria: [(ente, motivo), ...]},
    l'ordine gerarchico degli enti preservato dentro ciascun gruppo."""
    modo = modalita_screening(rep)
    gruppi = {IMPATTO_RETE: [], IMPATTO_TERRITORIO: [], IMPATTO_IGNOTO: []}
    dist_lin = rep.get("_distanze_lineari") or {}

    for e in rep.get("enti", []):
        org = e.get("_origine")
        if modo == "comune":
            # senza tracciato né area il confronto geometrico non esiste: tutto
            # è contesto territoriale, dichiararlo impattato sarebbe un falso
            gruppi[IMPATTO_TERRITORIO].append((e, ""))
            continue

        if org == "comune":
            cat, motivo = IMPATTO_RETE, ("lo scavo insiste sul suolo pubblico comunale: "
                                         "il Comune è sempre interessato")
        elif org == "strada":
            cat, motivo = _motivo_strade(rep, e.get("_classe_strada"), modo)
        elif org == "vincolo":
            cat, motivo = _motivo_vincoli(rep, e.get("_etichette"), modo)
        elif org == "ferrovia":
            d = dist_lin.get("ferrovie") or {}
            if d:
                vicina = min(d.items(), key=lambda kv: kv[1])
                cat, motivo = IMPATTO_RETE, ("%s a ~%.0f m dal tracciato (fascia di "
                                             "rispetto ferroviaria 30 m)" % (vicina[0], vicina[1]))
            else:
                cat, motivo = (IMPATTO_RETE, "linea entro la fascia di rispetto del tracciato") \
                    if modo == "area" else (IMPATTO_IGNOTO, "distanza dal tracciato non misurata")
        elif org == "ferrovia_dismessa":
            cat, motivo = IMPATTO_RETE, "ex sedime ferroviario entro la fascia di rispetto del tracciato"
        elif org in ("idrico_attraversato", "idrico_prossimita", "boschi_misurati"):
            # queste voci nascono già da distanze misurate sul tracciato: il
            # trigger che componi_enti ha scritto è il motivo, non ridirlo
            cat, motivo = IMPATTO_RETE, e.get("trigger") or ""
        elif org in ("idrico_non_misurato", "boschi_non_misurati"):
            cat, motivo = IMPATTO_IGNOTO, "presenza nota nel comune, distanza dal tracciato non misurata"
        elif org == "bonifica":
            # il reticolo di bonifica non viene ricalcolato sul tracciato:
            # resta il dato comunale, quindi non è deducibile l'interferenza
            cat, motivo = IMPATTO_IGNOTO, ("reticolo rilevato sul territorio comunale e non "
                                           "ricalcolato sul tracciato")
        elif org in ("natura2000", "parchi"):
            cat, motivo = IMPATTO_IGNOTO, ("perimetro rilevato sul territorio comunale e non "
                                           "ricalcolato sul tracciato: verificare l'intersezione")
        elif org == "idrogeologico":
            # le percentuali PAI sono riferite al territorio comunale, non al
            # tracciato: è contesto, non un'interferenza accertata
            cat, motivo = IMPATTO_TERRITORIO, ("pericolosità riferita al territorio comunale, "
                                               "non al tracciato")
        elif org == "soprintendenza":
            tocca = any((v.get("stato") or "").startswith(("ATTRAVERSAMENTO", "entro"))
                        for v in rep.get("vincoli", []))
            if tocca or modo == "area":
                cat, motivo = IMPATTO_RETE, "vincolo paesaggistico/culturale intercettato dal progetto"
            else:
                cat, motivo = IMPATTO_TERRITORIO, ("competenza territoriale: nessun vincolo "
                                                   "intercettato dal tracciato")
        else:
            cat, motivo = IMPATTO_IGNOTO, "origine della voce non tracciata nel report"
        gruppi[cat].append((e, motivo))

    # strade classificate che esistono nel comune ma restano fuori fascia: non
    # generano un ente da interpellare, ma l'utente vuole sapere che ci sono
    fuori = rep.get("rete_stradale_fuori") or {}
    gia_impattate = {e.get("_classe_strada") for e, _ in gruppi[IMPATTO_RETE]}
    for classe in ("A", "RA", "NSA", "SS", "SR", "SP", "SC"):
        refs = fuori.get(classe) or {}
        if not refs or classe in gia_impattate:
            continue
        sc = scheda_strada(classe) or {}
        det = ", ".join("%s (%s)" % (r, v.get("stato") or "fuori fascia")
                        for r, v in list(refs.items())[:8])
        gruppi[IMPATTO_TERRITORIO].append((
            {"ente": sc.get("ente_tipo") or classe,
             "ruolo": sc.get("descrizione") or "Ente proprietario strade classe %s" % classe,
             "scheda": sc,
             "trigger": "%d strade classificate nel comune, tutte fuori fascia" % len(refs)},
            det))
    return modo, gruppi


def esporta_xlsx(rep, percorso, nome_area=None):
    """Scrive il report enti in un .xlsx (openpyxl, incluso in QGIS).

    Foglio 1 'Enti da interpellare': diviso in sezioni — enti IMPATTATI dalla
    rete in progetto (quelli a cui scrivere davvero), enti solo PRESENTI nel
    territorio comunale (contesto) e voci non verificabili con i dati raccolti.
    La riga 3 dichiara su cosa è stata fatta la misura, perché cambia il senso
    di tutto il foglio.
    Foglio 2 'Strade classificate': una riga per strada (ref) con classe,
    gestore, denominazioni e segmenti.
    Foglio 3 'Vincoli e fonti': i vincoli intercettati e la tabella di
    provenienza/confidenza. Il disclaimer sta nella prima riga del foglio 1."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    KB = carica_kb()
    wb = Workbook()

    # ---- palette e stili condivisi (coerenti su tutti i fogli) ----
    VERDE = "2E5A34"; VERDE_CH = "6E8B4A"; ZEBRA = "EEF3E7"; GRIGIO = "F2F2F2"
    testa_font = Font(bold=True, color="FFFFFF", size=11)
    testa_fill = PatternFill("solid", fgColor=VERDE)
    sez_font = Font(bold=True, color="FFFFFF", size=11)
    sez_fill = PatternFill("solid", fgColor=VERDE_CH)
    zebra_fill = PatternFill("solid", fgColor=ZEBRA)
    a_capo = Alignment(wrap_text=True, vertical="top")
    centro = Alignment(horizontal="center", vertical="center", wrap_text=True)
    _thin = Side(style="thin", color="C8D2BC")
    bordo = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)

    def _intesta(ws, colonne, larghezze, riga=1):
        """Scrive una riga di intestazione stilizzata."""
        for j, nome in enumerate(colonne, 1):
            c = ws.cell(row=riga, column=j, value=nome)
            c.font = testa_font; c.fill = testa_fill
            c.alignment = centro; c.border = bordo
        for j, larg in enumerate(larghezze, 1):
            ws.column_dimensions[get_column_letter(j)].width = larg
        ws.row_dimensions[riga].height = 26

    def _stila_corpo(ws, r0, ncol, zebra=True):
        """Applica bordi, wrap e zebra alle righe dati da r0 a fine."""
        for i, row in enumerate(ws.iter_rows(min_row=r0, max_col=ncol)):
            for cell in row:
                cell.alignment = a_capo; cell.border = bordo
            if zebra and i % 2 == 1:
                for cell in row:
                    if cell.fill.fgColor.rgb in (None, "00000000"):
                        cell.fill = zebra_fill

    # ══ foglio 1: enti da interpellare ══
    ws = wb.active
    ws.title = "Enti da interpellare"
    c = rep.get("comune", {})
    titolo = "Screening scavi su suolo pubblico — %s (%s)" % (c.get("nome"), c.get("provincia") or "n/d")
    if nome_area:
        titolo += " — ambito: %s" % nome_area
    colonne = ["#", "Ente", "Ruolo", "Trigger (perché è coinvolto)", "Titolo richiesto",
               "Riferimenti", "PEC / contatti", "Documentazione tipica",
               "Criticità note", "Nota competenza"]
    larg = [4, 32, 26, 38, 30, 18, 28, 42, 42, 44]
    # riga titolo + riga disclaimer, fuse su tutta la larghezza
    ncol = len(colonne)
    ws.append([titolo])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    ws["A1"].font = Font(bold=True, size=14, color=VERDE)
    ws["A1"].alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 30
    ws.append(["PRE-ISTRUTTORIA (non certificazione). " + KB["meta"]["disclaimer"].strip().replace("\n", " ")])
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncol)
    ws["A2"].alignment = a_capo
    ws["A2"].font = Font(italic=True, size=9, color="7A7A7A")
    ws.row_dimensions[2].height = 40
    ws.append([])
    _intesta(ws, colonne, larg, riga=4)

    # La separazione sta in SEZIONI, non in una colonna: l'elenco si legge e si
    # stampa come tre blocchi (azioni / contesto / da verificare) senza che
    # l'utente debba filtrare, e il blocco delle azioni resta in cima.
    modo, gruppi = classifica_enti_impatto(rep)
    avviso = {
        "tracciato": ("Analisi sul TRACCIATO di progetto: gli enti impattati sono quelli le cui "
                      "competenze sono toccate dalla rete (strade entro fascia o attraversate, "
                      "vincoli intersecati, lineari entro la fascia di rispetto)."),
        "area": ("Analisi sull'AREA di progetto: gli enti impattati sono quelli i cui elementi "
                 "intersecano l'area. Le distanze metriche dal tracciato non sono state calcolate."),
        "comune": ("SCREENING SUL SOLO TERRITORIO COMUNALE (nessun tracciato né area di progetto): "
                   "NESSUN ente può essere dichiarato impattato dalla rete. Tutte le voci qui sotto "
                   "sono PRESENZE nel territorio, da verificare contro il tracciato reale."),
    }[modo]
    ws.cell(row=3, column=1, value=avviso)
    ws.merge_cells(start_row=3, start_column=1, end_row=3, end_column=ncol)
    c3 = ws.cell(row=3, column=1)
    c3.alignment = a_capo
    c3.font = Font(bold=True, size=10, color="FFFFFF")
    c3.fill = PatternFill("solid", fgColor=VERDE if modo != "comune" else "B00000")
    ws.row_dimensions[3].height = 34

    def _sezione_enti(testo, rosso=False):
        """Riga di stacco tra i gruppi, con lo stile sezione già in uso."""
        r = ws.max_row + 1
        ws.cell(row=r, column=1, value=testo)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
        cc = ws.cell(row=r, column=1)
        cc.font = Font(bold=True, color="FFFFFF", size=11) if not rosso else Font(bold=True, color="FFF2CC", size=11)
        cc.fill = sez_fill
        cc.alignment = Alignment(vertical="center", wrap_text=True)
        ws.row_dimensions[r].height = 24

    def _riga_ente(n, e, motivo):
        sc = e.get("scheda") or {}
        norme = ", ".join(KB["norme"][x]["id"] for x in sc.get("norme", []) if x in KB["norme"])
        contatti = e.get("contatti") or {}
        pec = "\n".join(filter(None, [contatti.get("pec"), contatti.get("sito")]))
        # il motivo concreto (quale strada, quale vincolo, a che distanza) vale
        # più del trigger generico: quando c'è, prende il posto in colonna
        ws.append([n, e.get("ente"), e.get("ruolo"), motivo or e.get("trigger"),
                   sc.get("titolo_richiesto") or "", norme, pec,
                   "\n".join("• %s" % d for d in sc.get("documentazione_tipica", [])),
                   "\n".join("• %s" % d for d in sc.get("criticita", [])),
                   "\n\n".join(filter(None, [e.get("nota_competenza"),
                                            e.get("nota_gestore")])) or ""])
        ws.cell(row=ws.max_row, column=1).alignment = centro

    blocchi = [
        (IMPATTO_RETE,
         "A) ENTI IMPATTATI DALLA RETE IN PROGETTO — DA INTERPELLARE (la competenza è toccata dal tracciato)",
         "Nessun ente risulta impattato dalla rete in progetto con i dati di questo screening."),
        (IMPATTO_TERRITORIO,
         "B) ENTI PRESENTI NEL TERRITORIO COMUNALE — contesto informativo, nessuna interferenza rilevata",
         "Nessun ente di solo contesto territoriale."),
        (IMPATTO_IGNOTO,
         "C) NON VERIFICABILE CON QUESTO SCREENING — dato mancante o non ricalcolato sul tracciato",
         "Nessuna voce non verificabile: tutte le competenze sono state classificate."),
    ]
    for chiave, intestazione, vuoto in blocchi:
        voci = gruppi.get(chiave) or []
        if chiave == IMPATTO_IGNOTO and not voci:
            continue   # non sporcare il foglio con una sezione sempre vuota
        _sezione_enti(intestazione, rosso=(chiave == IMPATTO_IGNOTO))
        if not voci:
            r = ws.max_row + 1
            ws.cell(row=r, column=1, value=vuoto)
            ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
            cc = ws.cell(row=r, column=1)
            cc.alignment = a_capo
            cc.font = Font(italic=True, color="7A7A7A")
            continue
        for n, (e, motivo) in enumerate(voci, 1):
            _riga_ente(n, e, motivo)
    _stila_corpo(ws, 5, ncol)
    ws.freeze_panes = "A5"

    # ══ foglio 2: strade classificate ══
    ws2 = wb.create_sheet("Strade classificate")
    etich = {"A": "Autostrada", "RA": "Raccordo", "NSA": "Nuova strada ANAS",
             "SS": "Statale", "SR": "Regionale", "SP": "Provinciale", "SC": "Comunale class."}
    sf = rep.get("stradario_fonte")
    modo_tracc = (rep.get("area_progetto") or {}).get("modalita") == "tracciato"
    ha_arlo = bool(rep.get("_arlo_zone_nomi"))
    colonne2 = ["Ref", "Classe", "Ente competente", "Gestore",
                "Denominazioni", "Segmenti (comune)", "Segmenti nell'area", "Conf. OSM"]
    larg2 = [11, 15, 32, 24, 40, 15, 15, 12]
    if ha_arlo:
        colonne2.append("ARLO AREA")
        larg2.append(22)
    if modo_tracc:
        colonne2 += ["Dist. (m)", "Stato", "Affianc. (m)", "Attrav.", "Fascia (m)"]
        larg2 += [11, 28, 13, 10, 11]
    ncol2 = len(colonne2)
    # riga fonte in testa (spiega da dove vengono le strade)
    if sf:
        nota_fonte = "Fonte primaria: %s%s. Colonna 'Conf. OSM' = confermata dai dati OpenStreetMap." % (
            sf["nome"], " (indipendente da OSM)" if sf.get("indipendente") else " — estratto OSM")
    else:
        nota_fonte = ("Fonte: OpenStreetMap (nessuno stradario di riferimento nel progetto). "
                      "OSM NON è autoritativo: classe ed ente vanno confermati presso il gestore.")
    ws2.append([nota_fonte])
    ws2.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol2)
    ws2["A1"].alignment = a_capo
    ws2["A1"].font = Font(italic=True, size=9, color="7A7A7A")
    ws2.row_dimensions[1].height = 30
    _intesta(ws2, colonne2, larg2, riga=2)

    regione_cc = (rep.get("comune") or {}).get("regione") or ""
    provincia_cc = (rep.get("comune") or {}).get("provincia") or ""

    def _riga_strada(cls, ref, v, conf, dati_tracc=True):
        # gestore: prima l'operator OSM; se assente, il gestore regionale
        # probabile (suggerimento da confermare, marcato con ~). Vale anche per
        # le SP: dove le Province sono soppresse (Friuli, Sicilia) l'ente è
        # l'EDR o il Libero Consorzio, non "la Provincia".
        gest = ", ".join(v.get("operator", []))
        if not gest and cls in ("SR", "SS", "SP"):
            gr, _nota = gestore_regionale(cls, regione_cc, provincia_cc)
            if gr:
                gest = "~ %s (da confermare)" % gr
        riga = [ref, etich.get(cls, cls), (scheda_strada(cls) or {}).get("ente_tipo") or "",
                gest or "—",
                "; ".join(v.get("nomi", [])) or "—",
                v.get("n_way"), v.get("n_way_area", ""), conf]
        if ha_arlo:
            riga.append(v.get("arlo") or "—")
        if modo_tracc:
            if dati_tracc:
                riga += [v.get("distanza_m", ""), v.get("stato", ""),
                         v.get("affiancamento_m", ""), v.get("attraversamenti", ""),
                         v.get("fascia_m", "")]
            else:
                riga += ["", "", "", "", ""]
        return riga

    n_scritte = 0
    for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
        for ref, v in rep.get("rete_stradale", {}).get(cls, {}).items():
            conf = ("sì" if v.get("confermato_osm") else "NO — verificare") if sf else "(fonte OSM)"
            ws2.append(_riga_strada(cls, ref, v, conf))
            n_scritte += 1
    # strade presenti solo in OSM (non nello stradario): i dati sul tracciato
    # (distanza/affiancamento/attraversamenti) sono comunque stati calcolati da
    # analizza_su_tracciato e vanno MOSTRATI — così un affiancamento longitudinale
    # su una SP/SR presente solo in OSM non resta invisibile solo perché lo
    # stradario locale non la copre.
    for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
        for ref, v in (rep.get("rete_stradale_solo_osm") or {}).get(cls, {}).items():
            ha_dati = v.get("distanza_m") is not None
            ws2.append(_riga_strada(cls, ref, v, "solo OSM — non nello stradario",
                                    dati_tracc=ha_dati))
            n_scritte += 1
    # strade classificate ma NON misurate (geometria assente in OSM in questo
    # run): non sappiamo se il tracciato le affianca — vanno evidenziate come
    # verifica manuale aperta, non nascoste.
    non_mis = rep.get("rete_stradale_non_misurate") or {}
    if non_mis:
        r_sez = ws2.max_row + 1
        ws2.cell(row=r_sez, column=1,
                 value="Strade classificate NON misurate (geometria assente in OSM in questo run): "
                       "verificare a mano un eventuale affiancamento longitudinale del tracciato")
        ws2.merge_cells(start_row=r_sez, start_column=1, end_row=r_sez, end_column=ncol2)
        cc = ws2.cell(row=r_sez, column=1)
        cc.font = Font(bold=True, color="B00000"); cc.fill = sez_fill; cc.alignment = a_capo
        for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
            for ref, v in non_mis.get(cls, {}).items():
                conf = ("—") if sf else "(fonte OSM)"
                ws2.append(_riga_strada(cls, ref, v, conf, dati_tracc=True))
                n_scritte += 1
    # strade classificate del comune FUORI fascia dal tracciato (informative):
    # così il foglio non è mai vuoto quando comunque esistono strade nel comune
    fuori = rep.get("rete_stradale_fuori") or {}
    if fuori:
        r_sez = ws2.max_row + 1
        ws2.cell(row=r_sez, column=1,
                 value="Strade classificate nel comune ma FUORI fascia dal tracciato (nessun obbligo, a titolo informativo)")
        ws2.merge_cells(start_row=r_sez, start_column=1, end_row=r_sez, end_column=ncol2)
        cc = ws2.cell(row=r_sez, column=1); cc.font = sez_font; cc.fill = sez_fill; cc.alignment = a_capo
        for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
            for ref, v in fuori.get(cls, {}).items():
                conf = ("sì" if v.get("confermato_osm") else "—") if sf else "(fonte OSM)"
                ws2.append(_riga_strada(cls, ref, v, conf))
    # foglio mai muto: se non c'è NESSUNA strada, spiega il perché reale
    if n_scritte == 0 and not fuori:
        r = ws2.max_row + 1
        st = rep.get("rete_stradale") or {}
        errore_rete = any(f.get("errore") for f in rep.get("fonti", [])
                          if f.get("stadio") == "rete stradale")
        if errore_rete:
            msg = ("NESSUNA strada rilevata perché la fonte OSM/Overpass non era "
                   "raggiungibile in questo run (non è un'assenza di strade). "
                   "Rilancia lo screening, oppure carica uno stradario (DBSN/regionale) "
                   "nel progetto e attivalo nella scheda: le strade verranno da lì.")
        else:
            msg = ("Nessuna strada classificata (SS/SP/SR/A) interseca il tracciato. "
                   "Le strade comunali non classificate non sono conteggiate qui: "
                   "l'interlocutore per quelle è comunque il Comune (foglio 1).")
        ws2.cell(row=r, column=1, value="⚠ " + msg)
        ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol2)
        ws2.cell(row=r, column=1).alignment = a_capo
        ws2.cell(row=r, column=1).font = Font(bold=True, color="B00000")
        ws2.row_dimensions[r].height = 60
    # avvertenza sempre presente sulla fonte (OSM può mancare provinciali)
    r_av = ws2.max_row + 2
    ws2.cell(row=r_av, column=1,
             value=("Avvertenza fonte: l'elenco strade (SS/SP/SR) deriva da OpenStreetMap, "
                    "che può essere incompleto o non aggiornato — singole provinciali possono "
                    "mancare o avere classificazione diversa da quella ufficiale. Prima della "
                    "richiesta di autorizzazione, verificare sul Catasto Strade / geoportale "
                    "della Provincia (o Città Metropolitana) competente e sullo stradario ANAS "
                    "per le statali."))
    ws2.merge_cells(start_row=r_av, start_column=1, end_row=r_av, end_column=ncol2)
    cav = ws2.cell(row=r_av, column=1)
    cav.font = Font(italic=True, color="7F6000"); cav.alignment = a_capo
    ws2.row_dimensions[r_av].height = 58
    _stila_corpo(ws2, 3, ncol2)
    ws2.freeze_panes = "A3"

    # ══ foglio 3: vincoli e fonti ══
    ws3 = wb.create_sheet("Vincoli e fonti")
    larg3 = [58, 22, 46]
    for j, larg in enumerate(larg3, 1):
        ws3.column_dimensions[get_column_letter(j)].width = larg

    def _sezione(ws, testo, ncol=3):
        r = ws.max_row + 1 if ws.max_row > 1 or ws.cell(1, 1).value else 1
        ws.cell(row=r, column=1, value=testo)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
        cc = ws.cell(row=r, column=1); cc.font = sez_font; cc.fill = sez_fill
        cc.alignment = Alignment(vertical="center", wrap_text=True)
        ws.row_dimensions[r].height = 22
        return r

    def _testa3(ws, colonne):
        r = ws.max_row + 1
        for j, nome in enumerate(colonne, 1):
            c = ws.cell(row=r, column=j, value=nome)
            c.font = testa_font; c.fill = testa_fill; c.alignment = centro; c.border = bordo
        return r

    # -- sezione A: vincoli paesaggistici (SITAP + geoportali regionali) --
    _sezione(ws3, "1) Vincoli paesaggistici e ambientali")
    # colonna 'Shape' = c'è un poligono in mappa (riscontro visivo) o no
    col_a = ["Vincolo", "Poligoni intersecanti", "% territorio di riferimento", "Riscontro shape"]
    if ha_arlo:
        col_a.append("ARLO AREA")
        ws3.column_dimensions[get_column_letter(5)].width = 24
    ws3.column_dimensions[get_column_letter(4)].width = 16
    r0 = _testa3(ws3, col_a)
    # etichette che hanno una geometria raccolta (=> generano shape)
    etich_con_shape = {str(et) for et, f in (rep.get("_geometrie_vincoli") or [])}
    # aggiungo anche natura2000/parchi (che sono in _geometrie_vincoli con prefissi)
    righe_vinc = []
    for v in rep.get("vincoli", []):
        has_shape = any(str(v["etichetta"]) in e or e in str(v["etichetta"]) for e in etich_con_shape)
        righe_vinc.append((v["etichetta"], v["n_poligoni"], "%.1f%%" % v["pct_territorio"],
                           "SÌ" if has_shape else "NO", v.get("arlo") or "—"))
    # Natura 2000 come vincolo (ha shape dedicato)
    for s in rep.get("natura2000", []):
        righe_vinc.append(("Rete Natura 2000: %s %s" % (s["codice"], s["nome"]),
                           1, "—", "SÌ", "—"))
    # parchi
    for p in rep.get("parchi", []):
        righe_vinc.append(("Area protetta: %s" % p["nome"], 1, "—", "SÌ", "—"))
    if righe_vinc:
        for et, npol, pct, shp, arlo in righe_vinc:
            riga = [et, npol, pct, shp]
            if ha_arlo:
                riga.append(arlo)
            ws3.append(riga)
    else:
        ws3.append(["Nessun vincolo paesaggistico intercettato (l'art. 142 vale anche se non cartografato)", "", "", "NO"])
    r_end = ws3.max_row
    for row in ws3.iter_rows(min_row=r0 + 1, max_row=r_end, max_col=len(col_a)):
        for cell in row:
            cell.alignment = a_capo; cell.border = bordo
    # evidenzia in rosso le righe con 'NO' shape (nessun riscontro visivo)
    col_shape = 4
    for r in range(r0 + 1, r_end + 1):
        cc = ws3.cell(row=r, column=col_shape)
        if str(cc.value).strip() == "NO":
            cc.font = Font(bold=True, color="C00000")
        elif str(cc.value).strip() == "SÌ":
            cc.font = Font(bold=True, color="107C10")

    # -- sezione B: interferenze lineari e rischio --
    _sezione(ws3, "2) Interferenze lineari e pericolosità")
    col_b = ["Elemento", "Quantità", "Dettaglio / fonte"]
    if ha_arlo:
        col_b.append("ARLO AREA")
    rb = _testa3(ws3, col_b)
    af = rep.get("_arlo_ferrovie") or {}
    ac = rep.get("_arlo_corsi") or {}
    righe_b = []
    if rep.get("ferrovie"):
        arlo_f = ", ".join(sorted({af[n] for n in rep["ferrovie"] if af.get(n)}))
        righe_b.append(["Ferrovie attive (fascia 30 m, DPR 753/1980)", len(rep["ferrovie"]), ", ".join(rep["ferrovie"]), arlo_f or "—"])
    if rep.get("ferrovie_dismesse"):
        righe_b.append(["Ex sedimi ferroviari (nulla osta proprietario)", len(rep["ferrovie_dismesse"]), ", ".join(rep["ferrovie_dismesse"]), "—"])
    if rep.get("corsi_acqua"):
        arlo_c = ", ".join(sorted({ac[n] for n in rep["corsi_acqua"] if ac.get(n)}))
        righe_b.append(["Corsi d'acqua", len(rep["corsi_acqua"]), ", ".join(rep["corsi_acqua"][:8]), arlo_c or "—"])
    if rep.get("boschi"):
        righe_b.append(["Aree boscate (vincolo paesaggistico art. 142 lett. g)",
                        len(rep["boschi"]), ", ".join(rep["boschi"][:8]), "—"])
    idg = rep.get("idrogeologico")
    if idg:
        idr = idg["idraulica"]; fr = idg["frane"]
        righe_b.append(["Pericolosità idraulica P3 elevata", "%.1f%%" % idr["P3_elevata_pct"], "ISPRA IdroGEO — PGRA (% comune)", "intero comune"])
        righe_b.append(["Pericolosità idraulica P2 media", "%.1f%%" % idr["P2_media_pct"], "ISPRA IdroGEO — PGRA (% comune)", "intero comune"])
        righe_b.append(["Pericolosità da frana P3+P4", "%.1f%%" % fr["P3P4_pct"], "ISPRA IdroGEO — PAI (% comune)", "intero comune"])
    if not righe_b:
        righe_b.append(["Nessuna interferenza lineare rilevata in OSM (non probante — verificare CTR/RFI/reticolo)", "", "", ""])
    for rg in righe_b:
        ws3.append(rg if ha_arlo else rg[:3])
    for row in ws3.iter_rows(min_row=rb + 1, max_row=ws3.max_row, max_col=len(col_b)):
        for cell in row:
            cell.alignment = a_capo; cell.border = bordo

    # -- sezione C: provenienza e affidabilità dei dati --
    _sezione(ws3, "3) Fonti dei dati e affidabilità")
    rc = _testa3(ws3, ["Stadio", "Fonte", "Confidenza / errore"])
    for f in rep.get("fonti", []):
        ws3.append([f["stadio"], f["fonte"],
                    f["confidenza"] + ((" — " + f["errore"]) if f.get("errore") else "")])
    for row in ws3.iter_rows(min_row=rc + 1, max_row=ws3.max_row, max_col=3):
        for cell in row:
            cell.alignment = a_capo; cell.border = bordo

    # -- sezione D: avvertenze --
    if rep.get("warning"):
        _sezione(ws3, "4) Avvertenze e limiti (leggere prima di usare il report)")
        for w in rep.get("warning", []):
            r = ws3.max_row + 1
            ws3.cell(row=r, column=1, value="⚠ " + w)
            ws3.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
            cell = ws3.cell(row=r, column=1)
            cell.alignment = a_capo; cell.font = Font(size=9, color="8A6D00")
    ws3.freeze_panes = "A1"

    # ══ foglio 4: Riepilogo (tabella piatta, una riga per ente/interferenza) ══
    # stile "Candia": Comune | Provincia | Regione | Ente | AREA ARMADIO | n° ARLO
    if rep.get("_arlo_zone_nomi"):
        wsr = wb.create_sheet("Riepilogo")
        col_r = ["Comune", "Provincia", "Regione", "Ente", "AREA ARMADIO", "n° ARLO"]
        larg_r = [24, 16, 16, 58, 18, 10]
        _intesta(wsr, col_r, larg_r, riga=1)
        cc = rep.get("comune", {})
        comune = (cc.get("nome") or "").split("/")[0].strip()
        provincia = cc.get("provincia") or ""
        regione = cc.get("regione") or ""
        etich_cls = {"A": "Autostrada", "RA": "Raccordo", "NSA": "NSA",
                     "SS": "Statale", "SR": "Regionale", "SP": "Provinciale", "SC": "Comunale"}

        def _aree_armadio(labels):
            """Codice area armadio dal suffisso della Label ARLO (es. 387-04 -> 04)."""
            aree = set()
            for lab in labels:
                if "-" in lab:
                    suf = lab.rsplit("-", 1)[-1].strip()
                    if suf.isdigit():
                        aree.add(suf)
            return sorted(aree)

        def _labels(arlo_str):
            return [x for x in (arlo_str or "").split(", ") if x and x != "—"]

        righe = []   # (ente_descr, [arlo labels])
        # Comune: sempre coinvolto, copre tutte le zone del progetto
        tutte_zone = list(rep["_arlo_zone_nomi"])
        # strade classificate: UNISCI rete primaria + solo-OSM + non-misurate,
        # altrimenti le strade presenti solo in OSM (SP/SS non nello stradario)
        # sparivano dal Riepilogo pur essendo enti da interpellare (stesso bug
        # gia' corretto in componi_enti: Stornarella SP81/SP88 solo-OSM).
        reti_str = {}
        for chiave in ("rete_stradale", "rete_stradale_solo_osm",
                       "rete_stradale_non_misurate"):
            for cls, refs in (rep.get(chiave) or {}).items():
                reti_str.setdefault(cls, {})
                for ref, v in refs.items():
                    reti_str[cls].setdefault(ref, v)
        # tengo le zone ARLO delle strade per abbinarle alle righe stradali
        arlo_strade = {}   # (cls,ref) -> [labels]
        righe_strade = []
        for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
            for ref, v in reti_str.get(cls, {}).items():
                stato = v.get("stato") or ""
                if str(stato).startswith("fuori fascia"):
                    continue
                ente = (scheda_strada(cls) or {}).get("ente_tipo") or etich_cls.get(cls, cls)
                gest = ", ".join(v.get("operator", []))
                cap = gest or ente
                descr = "%s — %s %s%s" % (cap, etich_cls.get(cls, cls), ref,
                                         " (%s)" % stato if stato else "")
                righe_strade.append((descr, _labels(v.get("arlo"))))
        # ferrovie / corsi d'acqua: zone ARLO se disponibili
        af = rep.get("_arlo_ferrovie") or {}
        ac = rep.get("_arlo_corsi") or {}

        # Il Riepilogo elenca TUTTI gli enti di componi_enti (rep["enti"]): cosi'
        # qualunque ente compaia nel foglio "Enti da interpellare" (Natura 2000,
        # parchi, aree boscate, idrogeologico, bonifica, vincoli paesaggistici…)
        # compare anche qui. Prima veniva ricostruita a mano una lista parziale che
        # ometteva parchi/Natura2000/boschi/idrogeologico (bug segnalato su Letojanni
        # e sul Parco del Gargano). Gli enti areali/comunali coprono tutte le zone.
        righe.append(("Comune di %s — occupazione suolo pubblico" % comune, tutte_zone))
        righe += righe_strade
        ruoli_gia = {"Ente proprietario del suolo pubblico comunale"}
        # aggiungo tutti gli altri enti non-stradali dalla lista completa
        for e in rep.get("enti", []):
            ruolo = e.get("ruolo", "")
            ente = e.get("ente", "")
            # salto Comune (gia' messo) e le strade (gia' messe con le loro zone ARLO)
            if ruolo in ruoli_gia:
                continue
            if any(k in ruolo for k in ("Strada ", "Autostrada", "Raccordo",
                                        "Strada statale", "Strada provinciale",
                                        "Strada regionale", "NSA")):
                continue
            # zone ARLO: ferrovie/corsi hanno mappe dedicate, gli altri vincoli sono
            # areali -> coprono tutto il progetto
            labs = tutte_zone
            trig = e.get("trigger", "")
            # per i corsi d'acqua prova ad abbinare la zona specifica
            for nome, zz in ac.items():
                if nome and nome in trig:
                    labs = _labels(zz) or tutte_zone
                    break
            descr = "%s — %s" % (ente, ruolo) if ente and ente not in ruolo else ruolo
            righe.append((descr, labs))

        for descr, labs in righe:
            aree = _aree_armadio(labs)
            wsr.append([comune, provincia, regione, descr,
                        ", ".join(aree) if aree else "—",
                        len(set(labs)) if labs else 0])
        _stila_corpo(wsr, 2, len(col_r))
        wsr.freeze_panes = "A2"

    # ══ foglio: Armadi ottici (manufatti fuori terra vs vincoli paesaggistici) ══
    armadi = rep.get("armadi_analisi") or []
    if armadi:
        wsa = wb.create_sheet("Armadi ottici")
        wsa.merge_cells("A1:F1")
        ca = wsa["A1"]
        ca.value = ("Armadi ottici (manufatti fuori terra) — valutazione paesaggistica. "
                    "Lo scavo interrato è di norma esente (art.149 D.Lgs 42/2004); "
                    "l'armadio è visibile e in area tutelata attiva l'autorizzazione "
                    "paesaggistica (art.146).")
        ca.alignment = Alignment(wrap_text=True, vertical="center")
        ca.font = Font(bold=True)
        wsa.row_dimensions[1].height = 46
        intest = ["Armadio", "Tipo", "Indirizzo",
                  "Vincoli 42/2004 (art.136/142)", "UCP regionali (PPTR)",
                  "Competenza autorizzativa"]
        wsa.append(intest)
        for c in wsa[2]:
            c.font = Font(bold=True)
            c.fill = PatternFill("solid", fgColor="D9E1F2")
        for a in armadi:
            ind = a.get("indirizzo") or ""
            if a.get("civico"):
                ind = ("%s %s" % (ind, a["civico"])).strip()
            wsa.append([
                a["id"], a.get("tipo", ""), ind or "—",
                "; ".join(a["gruppo_a"]) if a["gruppo_a"] else "—",
                "; ".join(a["gruppo_b"]) if a["gruppo_b"] else "—",
                a["competenza"],
            ])
            # evidenzia gli armadi vincolati
            r = wsa.max_row
            if a["gruppo_a"]:
                wsa.cell(r, 6).font = Font(color="9C0006", bold=True)  # Soprintendenza=rosso
            elif a["gruppo_b"]:
                wsa.cell(r, 6).font = Font(color="9C6500", bold=True)  # Regione/Comune=ambra
        widths = [12, 16, 24, 30, 26, 40]
        for i, w in enumerate(widths, 1):
            wsa.column_dimensions[chr(64 + i)].width = w
        _stila_corpo(wsa, 3, len(intest))
        wsa.freeze_panes = "A3"
        # nota DPR 31/2017 in coda
        wsa.append([])
        nr = wsa.max_row + 1
        wsa.merge_cells("A%d:F%d" % (nr, nr))
        cn = wsa.cell(nr, 1)
        cn.value = ("Nota: per armadi/ONU di piccole dimensioni verificare la procedura "
                    "semplificata o l'esenzione ex DPR 31/2017 (Allegati A/B). "
                    "La presente è pre-istruttoria ricognitiva, non certificazione.")
        cn.alignment = Alignment(wrap_text=True)
        cn.font = Font(italic=True, size=9)
        wsa.row_dimensions[nr].height = 34

    # ══ foglio: Fonti e affidabilità (statico — descrive le fonti dello strumento) ══
    wsf = wb.create_sheet("Fonti e affidabilità")
    wsf.merge_cells("A1:H1")
    cf = wsf["A1"]
    cf.value = "Screening scavi su suolo pubblico — Fonti dei dati e affidabilità"
    cf.font = Font(bold=True, color="FFFFFF", size=12)
    cf.fill = testa_fill
    cf.alignment = Alignment(horizontal="left", vertical="center")
    wsf.row_dimensions[1].height = 24
    wsf.merge_cells("A2:H2")
    cf2 = wsf["A2"]
    cf2.value = ("Pre-istruttoria, non certificazione. Ogni fonte porta il proprio livello di confidenza. "
                 "Il valore autoritativo pieno è solo su ISPRA IdroGEO; strade e vincoli vanno confermati "
                 "presso l'ente competente.")
    cf2.font = Font(italic=True, size=9, color="7A7A7A")
    cf2.alignment = a_capo
    wsf.row_dimensions[2].height = 30
    col_f = ["#", "Cosa fornisce", "Fonte", "Endpoint / origine", "Tipo",
             "Autoritativa", "Confidenza", "Note"]
    larg_f = [4, 28, 26, 30, 16, 15, 14, 40]
    _intesta(wsf, col_f, larg_f, riga=3)
    righe_f = [
        [1, "Pericolosità idrogeologica (frane PAI + alluvioni PGRA)",
         "ISPRA IdroGEO — API REST ufficiale", "idrogeo.isprambiente.it/api/pir/comuni",
         "Istituzionale nazionale", "SÌ", "alta",
         "Unica fonte marcata autoritativa nel codice. Dato per comune ISTAT."],
        [2, "Vincoli paesaggistici (art. 136 decretati; art. 142 fasce/boschi/coste; parchi; zone umide; UNESCO)",
         "SITAP — Ministero della Cultura (WFS)", "sitap.cultura.gov.it/geoserver/wfs",
         "Ministeriale", "Parziale", "media",
         "Perimetrazioni con accuratezza variabile. I vincoli ex lege art.142 valgono anche se non cartografati."],
        [3, "Soprintendenze ABAP competenti + PEC",
         "SITAP — MiC (WFS)", "sitap.cultura.gov.it/geoserver/wfs",
         "Ministeriale", "Parziale", "bassa",
         "Copertura del servizio incompleta; verificare la Soprintendenza territoriale."],
        [4, "Confine comunale + geocoding (ISTAT, regione, popolazione)",
         "Nominatim (OpenStreetMap)", "nominatim.openstreetmap.org/search",
         "Comunitaria", "NO", "media",
         "Usato per localizzare il comune e ricavare i dati anagrafici territoriali."],
        [5, "Rete stradale (SS/SP/SR/A, denominazioni, gestore)",
         "OpenStreetMap via Overpass", "overpass-api.de (+ 3 mirror di fallback)",
         "Comunitaria", "NO", "media",
         "OSM non è autoritativo: classe ed ente vanno confermati presso il gestore."],
        [6, "Interferenze lineari (corsi d'acqua, ferrovie attive/dismesse)",
         "OpenStreetMap via Overpass", "overpass-api.de (+ 3 mirror)",
         "Comunitaria", "NO", "media",
         "Copertura variabile; i corsi d'acqua demaniali possono non avere denominazione."],
        [7, "Rete stradale — fonte primaria opzionale",
         "Stradario caricato nel progetto (DBSN/regionale)", "layer locale del progetto QGIS",
         "Dipende dal layer", "SÌ se DBSN/IGM", "alta se indip.",
         "Se carichi il DBSN le strade passano da OSM (media) a fonte primaria (alta)."],
        [8, "Gestori regionali SR/SS (ASTRAL, Veneto Strade, FVG Strade, ...)",
         "Knowledge base interna del plugin", "procedimenti.yaml (file locale)",
         "Curata a mano", "Suggerimento", "da confermare",
         "Proposto solo quando OSM non porta il tag operator. Da verificare presso l'ente."],
    ]
    for riga in righe_f:
        wsf.append(riga)
    _stila_corpo(wsf, 4, len(col_f))
    # colora Autoritativa e Confidenza per lettura a colpo d'occhio
    for r in range(4, 4 + len(righe_f)):
        ac = wsf.cell(row=r, column=6); va = str(ac.value or "")
        if va.startswith("SÌ"):
            ac.font = Font(bold=True, color="2E7D32")
        elif va == "NO":
            ac.font = Font(bold=True, color="B00000")
        else:
            ac.font = Font(bold=True, color="B8860B")
        cc = wsf.cell(row=r, column=7); vc = str(cc.value or "").lower()
        if vc.startswith("alta"):
            cc.font = Font(bold=True, color="2E7D32")
        elif vc.startswith("media"):
            cc.font = Font(color="B8860B")
        elif vc.startswith("bassa"):
            cc.font = Font(color="B00000")
        wsf.row_dimensions[r].height = 46
    rlf = 4 + len(righe_f) + 1
    wsf.merge_cells(start_row=rlf, start_column=1, end_row=rlf, end_column=8)
    clf = wsf.cell(row=rlf, column=1,
                   value="Legenda — Autoritativa: SÌ = fonte istituzionale su cui fare affidamento · "
                         "Parziale = istituzionale ma da verificare · NO = comunitaria (OSM), da confermare "
                         "presso l'ente.   Confidenza: alta / media / bassa come dichiarata nel report.")
    clf.font = Font(italic=True, size=9, color="7A7A7A"); clf.alignment = a_capo
    wsf.row_dimensions[rlf].height = 30
    wsf.freeze_panes = "A4"

    wb.save(percorso)
    return percorso
