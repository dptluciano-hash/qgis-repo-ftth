# -*- coding: utf-8 -*-
"""Screening territoriale per richieste di scavo su suolo pubblico (reti TLC).

Modulo di LOGICA PURA del plugin FTTH Permessi Manager: non importa qgis né
PyQt, così è testabile fuori da QGIS (come ftth_core). Dato il nome di un
comune produce un report di PRE-ISTRUTTORIA: rete stradale classificata con
ente gestore, Soprintendenza ABAP competente (con PEC), vincoli paesaggistici
SITAP, interferenze lineari (ferrovie, corsi d'acqua) e l'elenco degli enti da
interpellare con titolo, norme e documentazione tipica.

NON certifica nulla: comprime la ricognizione da giorni a minuti, non
sostituisce l'istruttoria. La confidenza di ogni fonte è propagata fino al
report ed è ciò che distingue questo strumento da un certificatore.

Fonti: OSM/Nominatim (confine comunale), OSM/Overpass (strade, ferrovie,
acque), SITAP WFS del Ministero della Cultura (Soprintendenze e vincoli),
kb 'procedimenti.yaml' (mappa infrastruttura → ente → procedimento, curata a
mano e versionata: è la parte di valore).
"""
from __future__ import annotations

import json
import os
import re
import time
from collections import defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests
import yaml
from shapely.geometry import shape

UA = "ftth-permessi-screening/0.80 (pre-istruttoria autorizzativa; QGIS plugin)"

OVERPASS_ENDPOINTS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    "https://overpass.private.coffee/api/interpreter",
]
NOMINATIM = "https://nominatim.openstreetmap.org/search"
SITAP_WFS = "https://sitap.cultura.gov.it/geoserver/wfs"
CRS84 = "urn:ogc:def:crs:OGC:1.3:CRS84"

# Rete Natura 2000 (SIC/ZSC direttiva Habitat + ZPS direttiva Uccelli) dal
# servizio ArcGIS REST dell'Agenzia Europea per l'Ambiente (EEA): fonte europea
# autoritativa, copre tutta Italia, stabile e interrogabile per bbox in GeoJSON.
# Layer 4 = SIC/ZSC (scala di dettaglio), layer 8 = ZPS (scala di dettaglio).
EEA_N2000 = "https://bio.discomap.eea.europa.eu/arcgis/rest/services/ProtectedSites/Natura2000_Dyna_WM/MapServer"
EEA_N2000_LAYERS = [(4, "SIC/ZSC (Dir. Habitat 92/43/CEE)"), (8, "ZPS (Dir. Uccelli 2009/147/CE)")]

# Geoportale Regione Siciliana (SITR) — ArcGIS REST dei Piani Paesaggistici.
# La Sicilia NON è in SITAP nazionale per le fasce art.142, ma le pubblica qui,
# organizzate per ambito/provincia. Ogni servizio ha i suoi id-layer (variano),
# mappati sotto. Provincia (sigla) -> lista servizi candidati (Messina e Trapani
# hanno più ambiti: si prova finché il bbox restituisce feature).
SICILIA_REST = "https://map.sitr.regione.sicilia.it/gis/rest/services/piani_paesaggistici/%s_beni_paesaggistici/MapServer"
# servizio -> {chiave art.142: id layer}. Verificato via REST (2026-09).
SICILIA_142_LAYERS = {
    "ag":          {"a_costa": 6, "c_fiumi": 8, "g_boschi": 9, "art136": 10},
    "cl":          {"a_costa": 5, "c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "ct":          {"a_costa": 9, "c_fiumi": 11, "g_boschi": 12, "art136": 13},
    "egadi":       {"a_costa": 3, "g_boschi": 4, "art136": 5},
    "en":          {"c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "me_ambito9":  {"a_costa": 5, "c_fiumi": 8, "g_boschi": 9, "art136": 10},
    "pa":          {"a_costa": 12, "c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "pelagie":     {"g_boschi": 5, "a_costa": 6, "art136": 7},
    "rg":          {"a_costa": 4, "c_fiumi": 6, "g_boschi": 7, "art136": 8},
    "sr":          {"a_costa": 4, "c_fiumi": 6, "g_boschi": 7, "art136": 8},
    "tp_ambiti23": {"a_costa": 5, "c_fiumi": 7, "g_boschi": 8, "art136": 9},
    "tp_ambito1":  {"g_boschi": 4, "a_costa": 5, "art136": 7},
}
# provincia (da Nominatim 'county'/'state_district', lower) -> servizi candidati
SICILIA_PROV_SERVIZI = {
    "agrigento": ["ag", "pelagie"],
    "caltanissetta": ["cl"],
    "catania": ["ct"],
    "enna": ["en"],
    "messina": ["me_ambito9"],
    "palermo": ["pa"],
    "ragusa": ["rg"],
    "siracusa": ["sr"],
    "trapani": ["tp_ambiti23", "tp_ambito1", "egadi"],
}
SICILIA_142_DESC = {
    "a_costa": "Fascia costiera 300 m (art. 142 c.1 lett. a)",
    "c_fiumi": "Fascia di rispetto fiumi/corsi d'acqua 150 m (art. 142 c.1 lett. c)",
    "g_boschi": "Aree boscate (art. 142 c.1 lett. g)",
    "art136": "Immobili e aree di notevole interesse pubblico (art. 136)",
}

_KB_CACHE = None


def carica_kb() -> dict:
    """Knowledge base procedimenti.yaml, accanto a questo modulo."""
    global _KB_CACHE
    if _KB_CACHE is None:
        percorso = Path(__file__).parent / "procedimenti.yaml"
        _KB_CACHE = yaml.safe_load(percorso.read_text(encoding="utf-8"))
    return _KB_CACHE


@dataclass
class SourceResult:
    data: Any
    fonte: str
    url: str
    licenza: str
    autoritativo: bool
    confidenza: str
    note: list = field(default_factory=list)
    errore: str | None = None


# ---------------------------------------------------------------------------
# Normalizzazione dei riferimenti stradali
#
# La realtà di OSM: "SP006", "SP6", "SP 6", "SP45/Variante_C.V.", "SP5a",
# "SR71ter", "NSA 123". Senza normalizzazione si contano 3 volte le stesse
# strade e si sbaglia il conteggio nel report.
# ---------------------------------------------------------------------------
REF_RE = re.compile(
    r"^\s*(?P<cls>SS|SP|SR|SC|A|RA|NSA|T|E)\s*[-. ]?\s*(?P<num>\d{1,4})(?P<suf>[a-zA-Z]{0,6})",
    re.IGNORECASE,
)

# Declassamenti annotati in OSM con la convenzione "ex": una ex statale passata
# alla Provincia. Forme viste sui dati reali (Fino Mornasco CO, SS35->SP35):
# "SP ex SS35", "SPexSS35", "SP ex SS 35", "SPex SS35". Cattura il numero storico.
_EX_RE = re.compile(
    r"^\s*SP\s*ex\s*SS\s*[-. ]?\s*(?P<num>\d{1,4})",
    re.IGNORECASE,
)


def normalizza_ref(ref):
    """'SP006' -> ('SP', 'SP6');  'SR71ter' -> ('SR', 'SR71ter'); None se non classificabile.

    Una way OSM può portare più ref separati da ';' in ordine NON deterministico
    (es. 'E45;SS3bis' oppure 'SS3bis;E45'): li proviamo TUTTI e teniamo il primo
    che dà una classe con competenza (SS/SP/SR/A/RA/NSA/SC), così una statale non
    viene persa solo perché in OSM l'itinerario europeo E era scritto per primo.
    """
    if not ref:
        return None
    candidati = []
    for parte in ref.split(";"):
        primo = parte.split("/")[0]        # scarta "SP45/Variante_C.V."
        # --- declassamento annotato in OSM: "SP ex SS35", "SPexSS35", "SP ex SS 35"
        # Una statale trasferita alla Provincia spesso in OSM viene taggata con la
        # convenzione "ex": la strada NON è più ANAS/SS, è provinciale. La portiamo
        # a classe SP (competenza Provincia) tenendo il numero storico come sigla
        # leggibile, così l'ente indicato è corretto anche se OSM è a metà migrazione.
        mex = _EX_RE.match(primo.strip())
        if mex:
            num = str(int(mex.group("num")))
            candidati.append(("SP", "SPex SS%s" % num))
            continue
        m = REF_RE.match(primo)
        if not m:
            continue
        cls = m.group("cls").upper()
        num = str(int(m.group("num")))     # azzera lo zero-padding: 006 -> 6
        suf = m.group("suf").lower()
        if cls in {"T", "E"}:              # itinerari europei / tangenziali: non danno competenza
            continue
        candidati.append((cls, "%s%s%s" % (cls, num, suf)))
    if not candidati:
        return None
    # se un ramo dello stesso ref è annotato come declassato ("SPex SS<n>"), quella
    # è l'informazione più aggiornata: vince sul "SS<n>" grezzo dello stesso numero
    # (tratto misto tipico OSM a metà migrazione, es. "SS35;SPex SS35").
    ex_nums = {c[1].replace("SPex SS", "") for c in candidati if c[1].startswith("SPex SS")}
    if ex_nums:
        candidati = [c for c in candidati
                     if not (c[0] == "SS" and str(_solo_num(c[1])) in ex_nums)]
    # priorità alle classi con competenza sovracomunale piu' rilevante
    ordine = {"A": 0, "RA": 1, "NSA": 2, "SS": 3, "SR": 4, "SP": 5, "SC": 6}
    candidati.sort(key=lambda c: ordine.get(c[0], 9))
    return candidati[0]


def _solo_num(sigla):
    """Estrae il primo gruppo di cifre da una sigla ('SP35'->'35', 'SPex SS35'->'35')."""
    m = re.search(r"(\d{1,4})", sigla)
    return m.group(1) if m else ""


def tipo_corso_acqua(tags):
    """Classifica un corso d'acqua OSM in 'naturale' (fiume/torrente/rio, demanio
    idrico) o 'bonifica' (canale/fosso/scolina artificiale, tipicamente gestito da
    un Consorzio di bonifica). Ritorna (categoria, tipo_leggibile).

    Distinzione utile perché il regime cambia:
    - naturale demaniale -> R.D. 523/1904 (polizia idraulica 10 m dal piede argine)
      + Genio Civile/Regione, oltre alla fascia paesaggistica 150 m (art. 142 lett. c);
    - bonifica -> Consorzio di bonifica competente, fascia di rispetto stabilita dal
      REGOLAMENTO consortile (non i 150 m, non sempre i 10 m: spesso 4-10 m).
    OSM: 'canal' è ambiguo (può essere navigabile demaniale o consortile), lo
    trattiamo come bonifica salvo che il nome indichi un fiume/naviglio maggiore.
    """
    w = (tags or {}).get("waterway", "")
    if w in ("river", "stream"):
        return ("naturale", "fiume/torrente")
    if w in ("ditch", "drain"):
        return ("bonifica", "canale/scolina di bonifica")
    if w == "canal":
        # un canale grande demaniale vs canale consortile: OSM non lo dice.
        # Default prudente: reticolo di bonifica (competenza Consorzio), che è il
        # caso più frequente per i 'canal' minori in pianura.
        return ("bonifica", "canale")
    return ("naturale", w or "corso d'acqua")


def classifica_strade(elements):
    """Raggruppa le way OSM per classe amministrativa e ref normalizzato."""
    per_classe = defaultdict(lambda: defaultdict(
        lambda: {"n_way": 0, "operator": set(), "nomi": set()}))
    senza_ref = 0
    for e in elements:
        t = e.get("tags", {})
        parsed = normalizza_ref(t.get("ref", ""))
        if not parsed:
            if t.get("highway") in {"motorway", "trunk", "primary", "secondary"}:
                senza_ref += 1
            continue
        cls, ref_norm = parsed
        rec = per_classe[cls][ref_norm]
        rec["n_way"] += 1
        if t.get("operator"):
            rec["operator"].add(t["operator"])
        if t.get("name"):
            rec["nomi"].add(t["name"])

    out = {}
    for cls, refs in per_classe.items():
        out[cls] = {
            r: {"n_way": v["n_way"],
                "operator": sorted(v["operator"]),
                "nomi": sorted(v["nomi"])[:2]}
            for r, v in sorted(refs.items(), key=lambda kv: _sortkey(kv[0]))
        }
    return {"strade": out, "way_classificate_senza_ref": senza_ref}


def _sortkey(ref):
    m = re.match(r"([A-Z]+)(\d+)(.*)", ref)
    return (m.group(1), int(m.group(2)), m.group(3)) if m else (ref, 0, "")


def rileva_incoerenze(strade, comune_nome=None):
    """Segnala i casi in cui il dato OSM è internamente contraddittorio o obsoleto.

    Casi coperti:
    - SR con operator=Provincia (trasferimento non recepito);
    - SP senza operator;
    - SS/SR sempre: possibile declassamento a provinciale/comunale non ancora in
      OSM (OSM non rispecchia i declassamenti in tempo reale — verificato: SS35 a
      Fino Mornasco è oggi SP35, ma molte way OSM la portano ancora come SS);
    - declassamenti NOTI dalla kb (tabella `declassamenti`): correzione mirata.
    """
    warn = []
    for ref, v in strade.get("SR", {}).items():
        for op in v["operator"]:
            if "provincia" in op.lower():
                warn.append(
                    "%s: classificata come strada regionale ma OSM riporta "
                    "operator='%s'. Possibile trasferimento di competenza recente "
                    "non ancora recepito nei dati: verificare l'ente gestore attuale."
                    % (ref, op))
    for ref, v in strade.get("SP", {}).items():
        if not v["operator"]:
            warn.append("%s: nessun tag operator in OSM, ente gestore da confermare." % ref)
    for ref, v in strade.get("A", {}).items():
        if not v["operator"]:
            warn.append(
                "%s: concessionario autostradale non desumibile dai dati. "
                "Va identificato su elenco MIT/AISCAT prima di istruire la pratica." % ref)
    # avviso sistematico su ogni statale/regionale: OSM può essere obsoleto sul
    # declassamento (una SS/SR trasferita a Provincia/Comune resta a lungo "SS" in OSM)
    for cls in ("SS", "SR"):
        for ref in strade.get(cls, {}):
            warn.append(
                "%s: verificare l'eventuale DECLASSAMENTO a strada provinciale/comunale. "
                "OSM non rispecchia i declassamenti in tempo reale: una ex statale/"
                "regionale può risultare ancora '%s' in mappa pur essendo passata "
                "alla Provincia o al Comune (in tal caso l'ente competente cambia)." % (ref, cls))
    # correzione mirata dai declassamenti noti in kb
    warn += _declassamenti_noti(strade, comune_nome)
    return warn


def _declassamenti_noti(strade, comune_nome):
    """Confronta le strade rilevate con la tabella `declassamenti` della kb e, se
    una SS/SR nota come declassata compare nel comune indicato, avvisa con l'ente
    corretto. La tabella è una memoria dei casi incontrati, non un catasto."""
    avvisi = []
    try:
        tab = carica_kb().get("declassamenti") or []
    except Exception:  # noqa: BLE001
        return avvisi
    if not tab:
        return avvisi
    comune_l = (comune_nome or "").strip().lower()
    for voce in tab:
        vecchia = str(voce.get("da", "")).upper().replace(" ", "")
        cls_vecchia = vecchia[:2]
        refs_cls = strade.get(cls_vecchia, {})
        # match sul numero della sigla storica (SS35 -> '35')
        num = _solo_num(vecchia)
        presente = any(_solo_num(r) == num for r in refs_cls)
        com_voce = str(voce.get("comune", "")).strip().lower()
        if presente and (not com_voce or not comune_l or com_voce in comune_l or comune_l in com_voce):
            avvisi.append(
                "DECLASSAMENTO NOTO: %s risulta declassata a %s (%s%s). "
                "Ignorare la classe/operator ANAS di OSM: l'ente competente è %s."
                % (voce.get("da"), voce.get("a"), voce.get("ente", "ente provinciale/comunale"),
                   (" — %s" % voce["comune"]) if voce.get("comune") else "",
                   voce.get("ente", "l'ente subentrato")))
    return avvisi


# ---------------------------------------------------------------------------
# Connettori
# ---------------------------------------------------------------------------
def risolvi_comune(nome, provincia_hint=None):
    """Nome del comune -> geometria amministrativa (admin_level=8) + ISTAT.

    Gestisce le omonimie: se Nominatim restituisce più candidati di rango
    comunale li riporta tutti invece di scegliere silenziosamente il primo.
    """
    q = nome if not provincia_hint else "%s, %s" % (nome, provincia_hint)
    params = {"q": q, "countrycodes": "it", "format": "json", "limit": 10,
              "polygon_geojson": 1, "addressdetails": 1, "extratags": 1}
    try:
        r = requests.get(NOMINATIM, params=params, headers={"User-Agent": UA}, timeout=45)
        r.raise_for_status()
        raw = r.json()
    except Exception as e:  # noqa: BLE001
        return SourceResult(None, "OSM/Nominatim", NOMINATIM, "ODbL", False, "bassa", errore=str(e))

    cand = [x for x in raw
            if x.get("osm_type") == "relation" and x.get("class") == "boundary"
            and x.get("addresstype") in {"town", "city", "village", "municipality", "administrative"}]
    if not cand:
        return SourceResult(None, "OSM/Nominatim", NOMINATIM, "ODbL", False, "bassa",
                            errore="Nessun comune trovato per '%s'" % q)
    # preferisci i confini a livello COMUNALE (admin_level=8): 'administrative' è
    # un catch-all che intercetta anche Città Metropolitane/Province omonime dei
    # capoluoghi (Roma, Milano, Napoli...). Senza questo filtro cand[0] ordinato
    # per importance può risolvere sulla relation dell'area vasta (admin_level 6),
    # analizzando un territorio enormemente più grande del Comune.
    def _al(x):
        return str((x.get("extratags") or {}).get("admin_level") or "")
    comunali = [x for x in cand if _al(x) == "8"]
    if comunali:
        cand = comunali
    note = []
    if len(cand) > 1:
        alt = ", ".join(c["display_name"] for c in cand[1:4])
        note.append("OMONIMIA: %d candidati. Alternative scartate: %s" % (len(cand), alt))

    c = cand[0]
    addr = c.get("address", {})
    extra = c.get("extratags") or {}
    geom = shape(c["geojson"]) if c.get("geojson") else None
    pop = None
    for k in ("population", "population:date", "ref:ISTAT:population"):
        if extra.get(k) and str(extra[k]).replace(".", "").isdigit():
            pop = int(str(extra[k]).replace(".", ""))
            break
    out = {
        "nome": c.get("name"),
        "display_name": c.get("display_name"),
        "provincia": addr.get("county") or addr.get("state_district"),
        "regione": addr.get("state"),
        "cap": addr.get("postcode"),
        "osm_relation_id": c.get("osm_id"),
        "istat": extra.get("ref:ISTAT"),
        "popolazione": pop,
        "geometry": geom,
        "bbox": [float(v) for v in c["boundingbox"]],  # [S, N, W, E]
        "admin_level": _al(c),  # deve essere "8" (confine comunale); trasparenza
    }
    # confine non comunale: avvisa (area vasta = analisi su territorio sbagliato)
    if _al(c) and _al(c) != "8":
        note.append("ATTENZIONE: confine risolto con admin_level=%s (non 8=comunale): "
                    "l'area analizzata potrebbe non coincidere col Comune." % _al(c))
    return SourceResult(out, "OSM/Nominatim", NOMINATIM, "ODbL 1.0", False, "media", note)


OVERPASS_STRADE = """
[out:json][timeout:120];
rel({rel_id});map_to_area->.a;
(
  way["highway"]["ref"](area.a);
  way["highway"~"^(motorway|trunk|primary|secondary)"](area.a);
);
out tags{geom};
"""

OVERPASS_ALTRO = """
[out:json][timeout:120];
rel({rel_id});map_to_area->.a;
(
  way["railway"="rail"]["railway:traffic_mode"!="service"](area.a);
  way["railway"~"^(abandoned|disused|razed)$"](area.a);
  way["waterway"~"^(river|stream|canal)$"](area.a);
  way["waterway"~"^(ditch|drain)$"]["name"](area.a);
  way["natural"="wood"](area.a);
  way["landuse"="forest"](area.a);
  relation["natural"="wood"](area.a);
  relation["landuse"="forest"](area.a);
);
out tags{geom};
"""

NOTA_OSM = ("OSM non è fonte autoritativa: la classificazione e l'ente gestore "
            "vanno confermati presso il gestore della strada.")


def _overpass(query):
    """Esegue una query Overpass con failover tra endpoint."""
    last_err = None
    for ep in OVERPASS_ENDPOINTS:
        try:
            r = requests.post(ep, data=query.encode("utf-8"),
                              headers={"User-Agent": UA}, timeout=150)
            if r.status_code != 200:
                last_err = "%s -> HTTP %s" % (ep, r.status_code)
                continue
            j = r.json()
            # Overpass in overload/timeout risponde 200 con un 'remark' e
            # elements PARZIALI/vuoti: NON è un successo, va trattato come
            # errore per attivare il failover ed evitare falsa 'assenza'
            remark = j.get("remark")
            if remark and ("timed out" in remark.lower() or "runtime error" in remark.lower()
                           or not j.get("elements")):
                last_err = "%s -> remark: %s" % (ep, remark[:120])
                time.sleep(1)
                continue
            return j.get("elements", []), ep, None
        except Exception as e:  # noqa: BLE001
            last_err = "%s -> %s" % (ep, e)
            time.sleep(1)
    return [], "", last_err


def strade_nel_comune(rel_id, con_geometrie=False):
    q = OVERPASS_STRADE.format(rel_id=rel_id, geom=" geom" if con_geometrie else "")
    els, ep, err = _overpass(q)
    if err:
        return SourceResult([], "OpenStreetMap (Overpass)", ep or "n/d", "ODbL 1.0",
                            False, "bassa", errore=err)
    return SourceResult(els, "OpenStreetMap (Overpass)", ep, "ODbL 1.0", False, "media",
                        note=[NOTA_OSM])


def _comune_costiero(rel_id, bbox=None):
    """True se il territorio comunale tocca la linea di costa (natural=coastline).
    Serve per attivare il vincolo art.142 lett.a (fascia costiera 300 m) come
    probabile quando la regione non ha i layer SITAP.

    NB: la coastline OSM corre LUNGO il confine comunale, non dentro l'area, quindi
    map_to_area non la cattura: usiamo il bbox del comune (verificato su Letojanni,
    dove map_to_area dava 0 e il bbox 1). In caso di errore ritorna False (prudente).
    """
    try:
        if bbox is not None:
            S, N, W, E = bbox
            q = ("[out:json][timeout:60];"
                 "way[\"natural\"=\"coastline\"](%f,%f,%f,%f);out ids 1;" % (S, W, N, E))
        else:
            q = ("[out:json][timeout:60];rel(%s);>;"
                 "way[\"natural\"=\"coastline\"];out ids 1;" % rel_id)
        els, ep, err = _overpass(q)
        if err:
            return False
        return bool(els)
    except Exception:  # noqa: BLE001
        return False


def interferenze_lineari(rel_id, con_geometrie=False):
    q = OVERPASS_ALTRO.format(rel_id=rel_id, geom=" geom" if con_geometrie else "")
    els, ep, err = _overpass(q)
    if err:
        return SourceResult([], "OpenStreetMap (Overpass)", ep or "n/d", "ODbL 1.0",
                            False, "bassa", errore=err)
    return SourceResult(els, "OpenStreetMap (Overpass)", ep, "ODbL 1.0", False, "media")


# ---------------------------------------------------------------------------
# ISPRA IdroGEO — pericolosità idraulica e da frana (dato per comune ISTAT)
#
# API REST ufficiale ISPRA (idrogeo.isprambiente.it/api), OpenAPI 3.
# Dà le mosaicature nazionali PAI: aree a pericolosità idraulica (P1/P2/P3) e
# da frana (P1..P4) come kmq e % del territorio comunale. È un dato per COMUNE,
# non per area di progetto: non si interseca con l'ARLO ma vale come indicatore
# autoritativo "questo comune ha vincolo idrogeologico/rischio alluvioni".
# ---------------------------------------------------------------------------
IDROGEO_API = "https://idrogeo.isprambiente.it/api/pir/comuni"


def pericolosita_idrogeologica(istat):
    """Indicatori PAI del comune da ISPRA IdroGEO. `istat` = codice ISTAT
    comunale (es. '030101'). Ritorna SourceResult con dict di percentuali, o
    errore se il comune non è risolvibile."""
    if not istat:
        return SourceResult(None, "ISPRA IdroGEO", IDROGEO_API, "ISPRA", True, "bassa",
                            errore="codice ISTAT del comune non disponibile")
    try:
        target = int(str(istat).lstrip("0") or "0")
    except ValueError:
        target = None

    def _match(pro_com):
        # confronto robusto: normalizza entrambi a intero (gestisce lo zero
        # iniziale delle province 01-09, es. Genova '010032' -> 10032)
        if pro_com is None:
            return False
        try:
            return int(str(pro_com).lstrip("0") or "0") == target
        except (ValueError, TypeError):
            return str(pro_com) == str(istat)
    try:
        # 1) elenco comuni → trova l'uid dal pro_com (l'elenco NON porta le
        #    percentuali, che stanno solo nel dettaglio /comuni/{uid})
        r = requests.get(IDROGEO_API, headers={"User-Agent": UA}, timeout=60)
        r.raise_for_status()
        elenco = r.json()
        uid = None
        for c in elenco:
            if _match(c.get("pro_com")):
                uid = c.get("uid")
                break
        if uid is None:
            return SourceResult(None, "ISPRA IdroGEO", IDROGEO_API, "ISPRA", True, "bassa",
                                errore="comune ISTAT %s non trovato in IdroGEO" % istat)
        # 2) dettaglio comune → percentuali PAI/PGRA
        r2 = requests.get("%s/%s" % (IDROGEO_API, uid), headers={"User-Agent": UA}, timeout=60)
        r2.raise_for_status()
        rec = r2.json()
    except Exception as e:  # noqa: BLE001
        return SourceResult(None, "ISPRA IdroGEO", IDROGEO_API, "ISPRA", True, "bassa", errore=str(e))

    def _num(x):
        return x if isinstance(x, (int, float)) else 0.0
    dato = {
        "superficie_kmq": rec.get("ar_kmq"),
        "idraulica": {
            "P3_elevata_pct": _num(rec.get("aridp3_p")),
            "P2_media_pct": _num(rec.get("aridp2_p")),
            "P1_bassa_pct": _num(rec.get("aridp1_p")),
        },
        "frane": {
            "P4_molto_elevata_pct": _num(rec.get("ar_frp4_p")),
            "P3_elevata_pct": _num(rec.get("ar_frp3_p")),
            "P3P4_pct": _num(rec.get("ar_frp3p4p")),
            "P2_media_pct": _num(rec.get("ar_frp2_p")),
            "P1_pct": _num(rec.get("ar_frp1_p")),
        },
    }
    return SourceResult(dato, "ISPRA IdroGEO (mosaicatura nazionale PAI)", IDROGEO_API,
                        "ISPRA", autoritativo=True, confidenza="alta",
                        note=["Dato per COMUNE (non ristretto all'area di progetto): "
                              "indica se il territorio comunale ha aree a pericolosità "
                              "idraulica/da frana. La perimetrazione di dettaglio va letta "
                              "sul PAI del distretto e sul geoportale regionale."])


def _wfs_bbox(typename, bbox_snwe, count=400):
    """GetFeature con filtro bbox. bbox_snwe = [S, N, W, E] come da Nominatim.

    ATTENZIONE — trappola nota di GeoServer sull'ordine degli assi: con
    'EPSG:4326' questo server interpreta lon,lat (contro la spec), mentre con
    la forma urn si comporta secondo spec. CRS84 elimina l'ambiguità: è
    definito lon,lat per costruzione. I layer SITAP sono nativamente in
    EPSG:32632/23032 (mixed): la riproiezione la fa il server.

    Pagina con startIndex fino a esaurire il dataset: senza paginazione un
    comune denso di vincoli (centinaia di poligoni art.142) veniva TRONCATO
    silenziosamente al tetto `count`, dichiarando assente un vincolo cogente
    realmente intersecante (falso negativo su dato autoritativo).
    """
    s_, n_, w_, e_ = bbox_snwe
    tutte = []
    start = 0
    MAX_PAGINE = 40   # guardia: fino a 40*count features
    for _ in range(MAX_PAGINE):
        params = {"service": "WFS", "version": "2.0.0", "request": "GetFeature",
                  "typeNames": typename, "outputFormat": "application/json",
                  "srsName": CRS84, "count": count, "startIndex": start,
                  "bbox": "%s,%s,%s,%s,%s" % (w_, s_, e_, n_, CRS84)}
        try:
            r = requests.get(SITAP_WFS, params=params, headers={"User-Agent": UA}, timeout=120)
            if r.status_code != 200:
                if tutte:
                    break   # abbiamo già dati parziali: li teniamo
                return [], "HTTP %s" % r.status_code
            j = r.json()
        except Exception as e:  # noqa: BLE001
            if tutte:
                break
            return [], str(e)
        pagina = j.get("features", [])
        tutte.extend(pagina)
        # WFS 2.0.0 espone numberMatched (totale) e numberReturned (pagina)
        n_match = j.get("numberMatched")
        if len(pagina) < count:
            break   # ultima pagina
        if isinstance(n_match, int) and len(tutte) >= n_match:
            break
        start += count
    return tutte, None


# cache di sessione: le giurisdizioni delle soprintendenze cambiano di rado e
# il download completo (senza bbox) e' pesante ma affidabile — lo paghiamo una
# volta sola per run del processo.
_WFS_TUTTE_CACHE = {}

# cache SU DISCO: le soprintendenze SITAP (~16 MB) sono il pezzo piu' lento dello
# screening e cambiano una volta ogni anni. Le salviamo in un file locale con
# scadenza, cosi' dal secondo screening in poi il download non serve.
_CACHE_GIORNI = 30


def _cache_dir():
    """Cartella cache nella TEMP di sistema (…/ftth_screening_cache/): dato
    nazionale riutilizzabile tra tutti i progetti, NON dentro la cartella del
    plugin (si perderebbe a ogni aggiornamento e sporcherebbe il pacchetto).
    Creata se assente."""
    import os as _os, tempfile
    d = _os.path.join(tempfile.gettempdir(), "ftth_screening_cache")
    try:
        _os.makedirs(d, exist_ok=True)
    except Exception:  # noqa: BLE001
        return None
    return d


def _cache_path(chiave):
    """Percorso file cache per una chiave (typename[, propertyName])."""
    import os as _os, hashlib
    d = _cache_dir()
    if not d:
        return None
    h = hashlib.md5(("|".join(chiave)).encode("utf-8")).hexdigest()[:16]
    return _os.path.join(d, "wfs_%s.json" % h)


def _cache_leggi(chiave):
    """Legge le feature dalla cache su disco se presente e non scaduta."""
    import os as _os, json as _json
    p = _cache_path(chiave)
    if not p or not _os.path.exists(p):
        return None
    try:
        eta_giorni = (time.time() - _os.path.getmtime(p)) / 86400.0
        if eta_giorni > _CACHE_GIORNI:
            return None
        with open(p, "r", encoding="utf-8") as fh:
            return _json.load(fh)
    except Exception:  # noqa: BLE001
        return None


def _cache_scrivi(chiave, feats):
    """Salva le feature nella cache su disco (best-effort, errori ignorati)."""
    import json as _json
    p = _cache_path(chiave)
    if not p:
        return
    try:
        with open(p, "w", encoding="utf-8") as fh:
            _json.dump(feats, fh)
    except Exception:  # noqa: BLE001
        pass


def _wfs_tutte(typename, propertyName=None):
    """Scarica TUTTE le feature di un layer WFS senza filtro spaziale.

    Necessario per i layer soprintendenze SITAP: il filtro `bbox` su quelle viste
    (poligoni giurisdizionali molto grandi) restituisce sistematicamente HTTP 400
    e anche il CQL spaziale server-side non risponde. Scaricare l'intero layer
    (poche decine di poligoni) e fare il match in locale e' l'unica via robusta.
    Risultato in cache di sessione E su disco (30 giorni) per (typename, propertyName)."""
    chiave = (typename, propertyName or "")
    if chiave in _WFS_TUTTE_CACHE:
        return _WFS_TUTTE_CACHE[chiave], None
    # cache su disco: evita il download da 16 MB nei run successivi
    su_disco = _cache_leggi(chiave)
    if su_disco is not None:
        _WFS_TUTTE_CACHE[chiave] = su_disco
        return su_disco, None
    params = {"service": "WFS", "version": "2.0.0", "request": "GetFeature",
              "typeNames": typename, "outputFormat": "application/json",
              "srsName": CRS84}
    if propertyName:
        params["propertyName"] = propertyName
    # SITAP è lento (~16 MB, 30-40 s) e sotto carico risponde 502/503/timeout in
    # modo intermittente: 3 tentativi con backoff prima di arrendersi (misurato:
    # tentativi che alternano 502/503 e 200 sullo stesso layer nello stesso minuto).
    ultimo_err = None
    for tentativo in range(3):
        try:
            r = requests.get(SITAP_WFS, params=params, headers={"User-Agent": UA}, timeout=180)
            if r.status_code == 200:
                feats = r.json().get("features", [])
                _WFS_TUTTE_CACHE[chiave] = feats
                _cache_scrivi(chiave, feats)
                return feats, None
            ultimo_err = "HTTP %s" % r.status_code
            # 4xx diverso da 429 non è transitorio: inutile ritentare
            if 400 <= r.status_code < 500 and r.status_code != 429:
                if tentativo == 0:
                    # un 400 al primo colpo può dipendere dal carico: un retry
                    time.sleep(3)
                    continue
                return [], ultimo_err
        except Exception as e:  # noqa: BLE001
            ultimo_err = str(e)
        if tentativo < 2:
            time.sleep(4 * (tentativo + 1))  # 4s, 8s
    return [], ultimo_err


def soprintendenza_competente(comune_geom, bbox):
    """Individua la/le Soprintendenza/e ABAP territorialmente competenti.

    Layer nazionali di giurisdizione del SITAP: espongono denominazione, sito
    e PEC — l'unico dato autoritativo davvero riutilizzabile della catena.

    Il filtro `bbox` su queste viste dà HTTP 400 (poligoni giurisdizionali troppo
    grandi per il server): scarichiamo l'intero layer (poche decine di poligoni)
    e facciamo il match spaziale in LOCALE contro la geometria del comune. Se il
    download completo non è disponibile, si ripiega sul vecchio filtro bbox.
    """
    risultati = {}
    errori = []
    for tn, etichetta in [
        ("sitap_ws:vw_sitap_soprintendenze_paesaggio", "paesaggio"),
        ("sitap_ws:vw_sitap_soprintendenze_no_paesaggio", "beni culturali/archeologia"),
    ]:
        feats, err = _wfs_tutte(tn)
        if err or not feats:
            # ripiego sul vecchio metodo bbox (potrebbe comunque fallire con 400)
            feats2, err2 = _wfs_bbox(tn, bbox, count=50)
            if err2 and err:
                errori.append("%s: %s (fallback bbox: %s)" % (tn, err, err2))
                continue
            feats = feats2 or feats
            if err2 and not feats:
                errori.append("%s: %s" % (tn, err or err2))
                continue
        for f in feats:
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is not None and not g.intersects(comune_geom):
                continue
            p = f.get("properties", {})
            # quota del territorio comunale coperta: nei comuni di confine il
            # comune può ricadere su più giurisdizioni e serve capire quale prevale
            try:
                quota = g.intersection(comune_geom).area / comune_geom.area * 100
            except Exception:  # noqa: BLE001
                quota = 0.0
            if quota < 0.5:
                continue
            key = (p.get("codice"), etichetta)
            risultati[key] = {
                "ambito": etichetta,
                "codice": p.get("codice"),
                "denominazione": p.get("denominazione"),
                "sito": p.get("sito"),
                "pec": p.get("pec"),
                "quota_territorio": round(quota, 1),
                "marginale": quota < 15.0,
            }
    ordinati = sorted(risultati.values(), key=lambda x: -x["quota_territorio"])
    return SourceResult(ordinati, "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                        "Dati MiC", autoritativo=True,
                        confidenza="alta" if risultati else "bassa", note=errori)


VINCOLI_LAYERS = [
    ("sitap_ws:v1497pol_wgs84", "art136", "Vincolo paesaggistico decretato (art. 136)"),
    ("sitap_ws:vw_vasvia_boschi", "art142", "Aree boscate ex art. 142 lett. g"),
    ("sitap_ws:vw_vasvia_zone_umide", "art142", "Zone umide ex art. 142 lett. i"),
    ("sitap_ws:vw_unesco_sito", "unesco", "Sito UNESCO"),
    ("sitap_ws:vw_unesco_buffer", "unesco", "Buffer zone UNESCO"),
]

# Fasce art.142 lett.a (territori costieri 300 m) e lett.c (rispetto fiumi 150 m):
# in SITAP NON esiste un layer nazionale funzionante (vw_vasvia_aree_di_rispetto
# restituisce record vuoti col solo campo 'inside'). Esistono invece layer REGIONALI
# nel workspace 'sitap_ws_clone' (nomi eterogenei), ma solo per ALCUNE regioni —
# la Sicilia, ad esempio, NON è pubblicata. Mappa regione(lower) -> {a: layer costa,
# c: layer fiumi}. Per le regioni assenti si ricade sul fallback attivo (vedi
# fasce_142_probabili): lett.a se comune costiero, lett.c se ci sono corsi d'acqua.
# Typename verificati via GetCapabilities (2026-09).
SITAP_142_REGIONALE = {
    "basilicata":      {"a": "sitap_ws_clone:basilicata_art_142_c_1_a_territori_costieri",
                        "c": "sitap_ws_clone:BASILICATA_art142_c_fiumi"},
    "calabria":        {"a": "sitap_ws_clone:calabria_142_territori_costieri",
                        "c": "sitap_ws_clone:calabria_art142_corsi_acqua"},
    "campania":        {"a": "sitap_ws_clone:CAMPANIA_art_142_a_coste",
                        "c": "sitap_ws_clone:CAMPANIA_art_142_c_fiumi"},
    "emilia-romagna":  {"a": "sitap_ws_clone:emiliaromagna_art_142_c_1_a_territori_costieri",
                        "c": "sitap_ws_clone:emiliaromagna_art_142_c_1_c_aree_rispetto_fiumi"},
    "friuli-venezia giulia": {"c": "sitap_ws_clone:FVG_art_142_c_1_c_aree_rispetto_fiumi"},
    "friuli venezia giulia": {"c": "sitap_ws_clone:FVG_art_142_c_1_c_aree_rispetto_fiumi"},
    "lazio":           {"a": "sitap_ws_clone:LAZIO_art_142_c_1_a_territori_costieri",
                        "c": "sitap_ws_clone:LAZIO_art_142_fascia_150m_fiumi"},
    "lombardia":       {"c": "sitap_ws_clone:lombardia_142_rispetto_fiumi"},
    "piemonte":        {"c": "sitap_ws_clone:PIEMONTE_art_142_fascia_150m_fiumi"},
    "sardegna":        {"a": "sitap_ws_clone:SARDEGNA_art_142_territori_costieri_300m",
                        "c": "sitap_ws_clone:SARDEGNA_art_142_fascia_150m_fiumi"},
    "toscana":         {"a": "sitap_ws_clone:toscana_art142_territori_costieri",
                        "c": "sitap_ws_clone:toscana_art142_rispetto_fiumi"},
    "veneto":          {"a": "sitap_wms_bounce:VENETO_art_142_new_a_coste",
                        "c": "sitap_wms_bounce:VENETO_art_142_new_c_fiumi"},
}


def vincoli_paesaggistici(comune_geom, bbox, raccogli_geometrie=False):
    trovati = []
    errori = []
    geometrie = []          # [(etichetta, geojson_feature)] se richiesto
    for tn, chiave, etichetta in VINCOLI_LAYERS:
        feats, err = _wfs_bbox(tn, bbox, count=800)
        if err:
            errori.append("%s: %s" % (tn, err))
            continue
        n_int = 0
        inters = []             # intersezioni col comune, da unire (no doppie aree)
        for f in feats:
            if not f.get("geometry"):
                continue
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is not None and g.intersects(comune_geom):
                n_int += 1
                gi = None
                try:
                    gi = g.intersection(comune_geom)
                    inters.append(gi)
                except Exception:  # noqa: BLE001
                    pass
                if raccogli_geometrie:
                    # salva la geometria RITAGLIATA sul confine comunale, non la
                    # feature intera: altrimenti lo shapefile dei vincoli sfora
                    # nei comuni confinanti (il WFS interroga per bbox, non per
                    # confine). Se il ritaglio fallisce, ripiega sulla feature.
                    if gi is not None and not gi.is_empty:
                        import json as _json
                        from shapely.geometry import mapping as _mapping
                        f_clip = dict(f)
                        try:
                            f_clip["geometry"] = _json.loads(_json.dumps(_mapping(gi)))
                        except Exception:  # noqa: BLE001
                            f_clip = f
                        geometrie.append((etichetta, f_clip))
                    else:
                        geometrie.append((etichetta, f))
        if n_int:
            # unione delle intersezioni: poligoni sovrapposti NON gonfiano l'area
            # (senza union la % puo' superare il 100% del territorio comunale)
            area_int = 0.0
            if inters:
                try:
                    from shapely.ops import unary_union
                    u = unary_union(inters)
                    if not u.is_valid:
                        u = u.buffer(0)
                    area_int = u.area
                except Exception:  # noqa: BLE001
                    area_int = max((x.area for x in inters), default=0.0)
            pct = (area_int / comune_geom.area * 100) if comune_geom and comune_geom.area else 0.0
            pct = min(pct, 100.0)
            trovati.append({"chiave": chiave, "layer": tn, "etichetta": etichetta,
                            "n_poligoni": n_int, "pct_territorio": round(pct, 1)})
    res = SourceResult(trovati, "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                       "Dati MiC", autoritativo=False, confidenza="media",
                       note=errori + [
                           "SITAP è ricognitivo e non certificativo: la copertura per "
                           "regione è fortemente disomogenea e i vincoli ex art. 142 "
                           "operano anche se non cartografati."])
    res.geometrie = geometrie
    return res


def _norm_regione(nome):
    """Normalizza il nome regione per il match con SITAP_142_REGIONALE."""
    n = (nome or "").strip().lower()
    n = n.replace("'", " ").replace("-", "-")
    # alias comuni
    alias = {"friuli-venezia giulia": "friuli-venezia giulia",
             "friuli venezia giulia": "friuli-venezia giulia",
             "emilia romagna": "emilia-romagna",
             "trentino-alto adige": "trentino-alto adige"}
    return alias.get(n, n)


def fasce_142_regionali(comune_geom, bbox, regione, raccogli_geometrie=False):
    """Fasce art.142 lett.a (territori costieri 300 m) e lett.c (rispetto fiumi
    150 m) dai layer SITAP REGIONALI, quando la regione è coperta.

    Ritorna (trovati, geometrie, coperta, errori). `coperta`=False se la regione
    non ha layer in SITAP (es. Sicilia): il chiamante attiverà il fallback.
    """
    reg = _norm_regione(regione)
    mapping = SITAP_142_REGIONALE.get(reg)
    if not mapping:
        return [], [], False, []
    trovati = []
    geometrie = []
    errori = []
    lett_desc = {"a": ("Fascia costiera 300 m (art. 142 c.1 lett. a)", "art142"),
                 "c": ("Fascia di rispetto fiumi/corsi d'acqua 150 m (art. 142 c.1 lett. c)", "art142")}
    for lettera, tn in mapping.items():
        desc, chiave = lett_desc.get(lettera, ("Fascia art. 142", "art142"))
        feats, err = _wfs_bbox(tn, bbox, count=800)
        if err:
            errori.append("%s (%s): %s" % (desc, tn, err))
            continue
        n_int = 0
        inters = []
        for f in feats:
            if not f.get("geometry"):
                continue
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is not None and g.intersects(comune_geom):
                n_int += 1
                try:
                    gi = g.intersection(comune_geom)
                    inters.append(gi)
                except Exception:  # noqa: BLE001
                    gi = None
                if raccogli_geometrie:
                    if gi is not None and not gi.is_empty:
                        import json as _json
                        from shapely.geometry import mapping as _mapping
                        f_clip = dict(f)
                        try:
                            f_clip["geometry"] = _json.loads(_json.dumps(_mapping(gi)))
                        except Exception:  # noqa: BLE001
                            f_clip = f
                        geometrie.append((desc, f_clip))
                    else:
                        geometrie.append((desc, f))
        if n_int:
            area_int = 0.0
            if inters:
                try:
                    from shapely.ops import unary_union
                    u = unary_union(inters)
                    if not u.is_valid:
                        u = u.buffer(0)
                    area_int = u.area
                except Exception:  # noqa: BLE001
                    area_int = max((x.area for x in inters), default=0.0)
            pct = (area_int / comune_geom.area * 100) if comune_geom and comune_geom.area else 0.0
            trovati.append({"chiave": chiave, "layer": tn, "etichetta": desc,
                            "n_poligoni": n_int, "pct_territorio": round(min(pct, 100.0), 1)})
    return trovati, geometrie, True, errori


def fasce_142_probabili(comune_geom, bbox, costiero, ha_corsi_acqua):
    """Fallback per le regioni SENZA layer SITAP art.142 (es. Sicilia): segnala i
    vincoli come PROBABILI in base a segnali oggettivi (comune costiero -> lett.a;
    presenza di corsi d'acqua -> lett.c). Non sono i poligoni esatti, ma evitano il
    falso negativo "nessun vincolo" quando il vincolo ex lege quasi certamente esiste.
    Ritorna una lista di avvisi (stringhe)."""
    avvisi = []
    if costiero:
        avvisi.append(
            "PROBABILE fascia costiera 300 m (art. 142 c.1 lett. a): il comune è "
            "costiero e la fascia opera EX LEGE anche se non cartografata in SITAP. "
            "La perimetrazione esatta va letta sul geoportale/PPTR regionale.")
    if ha_corsi_acqua:
        avvisi.append(
            "PROBABILE fascia di rispetto 150 m dei corsi d'acqua (art. 142 c.1 lett. c): "
            "sono presenti corsi d'acqua nel territorio; la fascia opera EX LEGE per i "
            "corsi iscritti negli elenchi delle acque pubbliche (R.D. 1775/1933). "
            "Verificare l'iscrizione e la perimetrazione sul geoportale regionale.")
    return avvisi


def _arcgis_query(base_url, layer_id, bbox, timeout=90):
    """Interroga un layer ArcGIS REST (MapServer) per bbox, ritorna (features_geojson, err).
    bbox = [S, N, W, E]. Usato per il geoportale Sicilia (SITR)."""
    S, N, W, E = bbox
    envelope = "%f,%f,%f,%f" % (W, S, E, N)
    params = {"f": "geojson", "where": "1=1", "geometry": envelope,
              "geometryType": "esriGeometryEnvelope", "inSR": "4326",
              "spatialRel": "esriSpatialRelIntersects", "outFields": "*",
              "outSR": "4326", "returnGeometry": "true"}
    url = "%s/%d/query" % (base_url, layer_id)
    for tentativo in range(3):
        try:
            r = requests.get(url, params=params, headers={"User-Agent": UA}, timeout=timeout)
            if r.status_code == 200:
                try:
                    return r.json().get("features", []), None
                except Exception:  # noqa: BLE001
                    return [], "risposta non-JSON"
            ultimo = "HTTP %s" % r.status_code
        except Exception as e:  # noqa: BLE001
            ultimo = str(e)
        if tentativo < 2:
            time.sleep(2 * (tentativo + 1))
    return [], ultimo


def vincoli_142_sicilia(comune_geom, bbox, provincia, raccogli_geometrie=False):
    """Fasce/vincoli art.142 e art.136 dal geoportale Regione Siciliana (SITR),
    quando il comune è in Sicilia. La Sicilia non è in SITAP: qui i vincoli sono
    poligoni VERI (costa 300 m lett.a, fiumi 150 m lett.c, boschi lett.g, art.136).

    Ritorna (trovati, geometrie, coperta, errori). `coperta`=False se la provincia
    non è mappata (allora il chiamante usa il fallback ex lege).
    """
    prov = (provincia or "").strip().lower()
    # normalizza 'città metropolitana di messina' -> 'messina', 'libero consorzio…'
    for k in SICILIA_PROV_SERVIZI:
        if k in prov:
            prov = k
            break
    servizi = SICILIA_PROV_SERVIZI.get(prov)
    if not servizi:
        return [], [], False, []
    trovati = []
    geometrie = []
    errori = []
    visti = set()   # (chiave) per non duplicare se più ambiti rispondono
    for serv in servizi:
        base = SICILIA_REST % serv
        layers = SICILIA_142_LAYERS.get(serv, {})
        for chiave_l, lid in layers.items():
            if chiave_l in visti:
                continue
            desc = SICILIA_142_DESC.get(chiave_l, chiave_l)
            feats, err = _arcgis_query(base, lid, bbox)
            if err:
                errori.append("%s (%s id %d): %s" % (desc, serv, lid, err))
                continue
            n_int = 0
            inters = []
            for f in feats:
                if not f.get("geometry"):
                    continue
                try:
                    g = shape(f["geometry"])
                    if not g.is_valid:
                        g = g.buffer(0)
                except Exception:  # noqa: BLE001
                    continue
                if comune_geom is not None and g.intersects(comune_geom):
                    n_int += 1
                    try:
                        gi = g.intersection(comune_geom)
                        inters.append(gi)
                    except Exception:  # noqa: BLE001
                        gi = None
                    if raccogli_geometrie:
                        etich_geo = "%s%s" % (
                            "Fascia costiera 300 m" if chiave_l == "a_costa" else
                            "Fascia fiumi 150 m" if chiave_l == "c_fiumi" else
                            "Area boscata art.142g" if chiave_l == "g_boschi" else
                            "Vincolo art.136", "")
                        if gi is not None and not gi.is_empty:
                            import json as _json
                            from shapely.geometry import mapping as _mapping
                            f_clip = {"type": "Feature",
                                      "properties": {"vincolo": desc},
                                      "geometry": _json.loads(_json.dumps(_mapping(gi)))}
                            geometrie.append((desc, f_clip))
                        else:
                            geometrie.append((desc, f))
            if n_int:
                visti.add(chiave_l)
                area_int = 0.0
                if inters:
                    try:
                        from shapely.ops import unary_union
                        u = unary_union(inters)
                        if not u.is_valid:
                            u = u.buffer(0)
                        area_int = u.area
                    except Exception:  # noqa: BLE001
                        area_int = max((x.area for x in inters), default=0.0)
                pct = (area_int / comune_geom.area * 100) if comune_geom and comune_geom.area else 0.0
                chiave_v = "art136" if chiave_l == "art136" else "art142"
                trovati.append({"chiave": chiave_v, "layer": "SITR:%s/%d" % (serv, lid),
                                "etichetta": desc, "n_poligoni": n_int,
                                "pct_territorio": round(min(pct, 100.0), 1)})
    return trovati, geometrie, True, errori


def _eea_query(layer_id, bbox):
    """Interroga un layer del servizio EEA Natura2000 (ArcGIS REST) per bbox.
    bbox = [S, N, W, E] (come da risolvi_comune). Ritorna (features_geojson, err).
    Con retry: il servizio EEA è generalmente stabile ma può avere picchi."""
    S, N, W, E = bbox
    envelope = "%f,%f,%f,%f" % (W, S, E, N)   # xmin,ymin,xmax,ymax
    params = {"f": "geojson", "where": "1=1", "geometry": envelope,
              "geometryType": "esriGeometryEnvelope", "inSR": "4326",
              "spatialRel": "esriSpatialRelIntersects", "outFields": "*",
              "outSR": "4326", "returnGeometry": "true"}
    url = "%s/%d/query" % (EEA_N2000, layer_id)
    ultimo = None
    for tentativo in range(3):
        try:
            r = requests.get(url, params=params, headers={"User-Agent": UA}, timeout=90)
            if r.status_code == 200:
                return r.json().get("features", []), None
            ultimo = "HTTP %s" % r.status_code
        except Exception as e:  # noqa: BLE001
            ultimo = str(e)
        if tentativo < 2:
            time.sleep(3 * (tentativo + 1))
    return [], ultimo


def natura2000_intercettati(comune_geom, bbox, raccogli_geometrie=False):
    """Siti Rete Natura 2000 (SIC/ZSC + ZPS) che intersecano il comune, da EEA.

    Ogni sito porta codice (SITECODE) e denominazione (SITENAME). Distingue i due
    regimi (Habitat/Uccelli). Il trigger della Valutazione di Incidenza (VIncA)
    scatta anche in PROSSIMITÀ, non solo dentro il sito: qui riportiamo i siti che
    intersecano il territorio comunale; l'analisi sul tracciato affina la distanza.
    """
    trovati = []
    errori = []
    geometrie = []
    for layer_id, etichetta in EEA_N2000_LAYERS:
        feats, err = _eea_query(layer_id, bbox)
        if err:
            errori.append("EEA layer %d (%s): %s" % (layer_id, etichetta, err))
            continue
        for f in feats:
            if not f.get("geometry"):
                continue
            try:
                g = shape(f["geometry"])
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if comune_geom is None or not g.intersects(comune_geom):
                continue
            p = f.get("properties", {}) or {}
            codice = (p.get("SITECODE") or p.get("sitecode") or p.get("CODE")
                      or p.get("code") or "?")
            nome = (p.get("SITENAME") or p.get("sitename") or p.get("NAME")
                    or p.get("name") or "sito senza nome")
            trovati.append({"tipo": etichetta, "codice": codice, "nome": nome})
            if raccogli_geometrie:
                try:
                    gi = g.intersection(comune_geom)
                    import json as _json
                    from shapely.geometry import mapping as _mapping
                    f_clip = {"type": "Feature",
                              "properties": {"vincolo": "Natura 2000 %s" % etichetta,
                                             "codice": codice, "nome": nome},
                              "geometry": _json.loads(_json.dumps(_mapping(
                                  gi if not gi.is_empty else g)))}
                    geometrie.append(("Natura 2000 — %s" % etichetta, f_clip))
                except Exception:  # noqa: BLE001
                    pass
    res = SourceResult(trovati, "EEA - Rete Natura 2000 (Agenzia Europea Ambiente)",
                       EEA_N2000, "EEA/Copernicus", autoritativo=True,
                       confidenza="alta" if trovati else "media",
                       note=errori + [
                           "La Valutazione di Incidenza (VIncA) può essere richiesta "
                           "anche per interventi in PROSSIMITÀ del sito, non solo "
                           "all'interno: verificare con l'ente gestore."])
    res.geometrie = geometrie
    return res


# Aree naturali protette (parchi) — SITAP: come le soprintendenze, il filtro bbox
# su questi poligoni giganti dà HTTP 400, quindi si scarica tutto il layer
# (poche decine di poligoni nazionali/regionali) e si fa il match spaziale locale.
PARCHI_LAYERS = [
    ("sitap_ws:vw_vasvia_parchi_nazionali", "Parco nazionale"),
    ("sitap_ws:vw_vasvia_parchi_regionali", "Parco regionale"),
]


def parchi_intercettati(comune_geom, raccogli_geometrie=False):
    """Aree naturali protette (parchi nazionali/regionali) che intersecano il
    comune, da SITAP. Scarica-tutte + match locale (il bbox rompe la query, 400).

    Ogni parco porta denominazione e codice EUAP. L'ente gestore va contattato
    per il nulla osta ex art. 13 L. 394/1991 (aree protette)."""
    if comune_geom is None:
        return SourceResult([], "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                            "Dati MiC", autoritativo=True, confidenza="bassa",
                            note=["Confine comunale non disponibile: parchi non verificabili."])
    trovati = []
    errori = []
    geometrie = []
    for typename, etichetta in PARCHI_LAYERS:
        feats, err = _wfs_tutte(typename)
        if err:
            errori.append("%s: %s" % (etichetta, err))
            continue
        for f in feats:
            g_raw = f.get("geometry")
            if not g_raw:
                continue
            try:
                g = shape(g_raw)
                if not g.is_valid:
                    g = g.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            if not g.intersects(comune_geom):
                continue
            p = f.get("properties", {}) or {}
            nome = (p.get("denominazione") or p.get("denominazi")
                    or p.get("nome") or "parco senza nome")
            euap = p.get("euap") or ""
            trovati.append({"tipo": etichetta, "nome": nome, "euap": euap})
            if raccogli_geometrie:
                try:
                    gi = g.intersection(comune_geom)
                    import json as _json
                    from shapely.geometry import mapping as _mapping
                    f_clip = {"type": "Feature",
                              "properties": {"vincolo": etichetta,
                                             "codice": euap, "nome": nome},
                              "geometry": _json.loads(_json.dumps(_mapping(
                                  gi if not gi.is_empty else g)))}
                    geometrie.append(("%s — %s" % (etichetta, nome), f_clip))
                except Exception:  # noqa: BLE001
                    pass
    res = SourceResult(trovati, "SITAP - Ministero della Cultura (WFS)", SITAP_WFS,
                       "Dati MiC", autoritativo=True,
                       confidenza="alta" if trovati else "media", note=errori)
    res.geometrie = geometrie
    return res


# ---------------------------------------------------------------------------
# Composizione del report
# ---------------------------------------------------------------------------
def scheda_strada(classe):
    for s in carica_kb()["strade"]:
        if s["classe"] == classe:
            return s
    return None


def scheda_vincolo(chiave):
    for v in carica_kb()["vincoli"]:
        if v["chiave"] == chiave:
            return v
    return None


def gestore_regionale(classe, regione):
    """Gestore stradale probabile per una strada di classe `classe` nella
    regione `regione` (nome, case-insensitive), da kb 'gestori_regionali'.
    Ritorna (gestore, nota) o (None, None) se non mappato. È un SUGGERIMENTO da
    confermare, usato solo quando OSM non porta il tag operator."""
    if not regione:
        return None, None
    reg = str(regione).strip().lower()
    for g in carica_kb().get("gestori_regionali", []) or []:
        if g.get("regione", "").strip().lower() == reg:
            val = g.get(classe)
            if val:
                return val, g.get("note")
            return None, None
    return None, None


def geoportale_regionale(regione):
    """Ritorna (portale_url, wfs_url) del geoportale della regione dalla kb
    'geoportali_regionali', per la verifica manuale dei vincoli quando SITAP non
    risponde. wfs_url e' '' se non c'e' un endpoint pubblico verificato.
    (None, None) se la regione non e' mappata."""
    if not regione:
        return None, None
    reg = str(regione).strip().lower()
    for g in carica_kb().get("geoportali_regionali", []) or []:
        if g.get("regione", "").strip().lower() == reg:
            return g.get("portale") or None, g.get("wfs") or ""
    return None, None


def rfi_struttura(regione):
    """Ritorna la scheda della struttura territoriale RFI competente per la
    regione (dict con struttura/citta/pgos_range) dalla kb 'rfi_strutture', o
    None se non mappata. Usata per associare la struttura RFI corretta quando
    nel territorio c'e' una linea ferroviaria RFI."""
    if not regione:
        return None
    reg = str(regione).strip().lower()
    for r in carica_kb().get("rfi_strutture", []) or []:
        if r.get("regione", "").strip().lower() == reg:
            return r
    return None


def esegui(nome, provincia=None, avanzamento=None, raccogli_geometrie=False):
    """Screening completo. `avanzamento(testo)` è chiamata tra gli stadi (il
    pannello la usa per il log e per tenere viva l'interfaccia).
    Con raccogli_geometrie=True il risultato porta anche gli elementi con
    geometria (strade/lineari da Overpass, vincoli da SITAP) per il
    caricamento in mappa."""
    def _av(msg):
        if avanzamento:
            avanzamento(msg)

    rep = {"input": {"comune": nome, "provincia_hint": provincia}, "warning": [], "fonti": []}

    _av("Risoluzione del confine comunale (Nominatim)…")
    c = risolvi_comune(nome, provincia)
    rep["fonti"].append({"stadio": "confine comunale", "fonte": c.fonte,
                         "confidenza": c.confidenza, "errore": c.errore})
    if c.errore or not c.data:
        rep["errore"] = c.errore or "comune non risolto"
        return rep
    rep["warning"] += c.note
    geom = c.data["geometry"]
    rep["comune"] = {k: v for k, v in c.data.items() if k != "geometry"}
    rep["_geometria_comune"] = geom
    _av("Comune: %s (%s, %s) — ISTAT %s" % (
        c.data["nome"], c.data["provincia"] or "n/d",
        c.data["regione"] or "n/d", c.data["istat"] or "n/d"))

    _av("Rete stradale classificata (Overpass, con failover)…")
    st = strade_nel_comune(c.data["osm_relation_id"], con_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "rete stradale", "fonte": st.fonte,
                         "confidenza": st.confidenza, "errore": st.errore})
    cls = classifica_strade(st.data) if st.data else {"strade": {}, "way_classificate_senza_ref": 0}
    rep["rete_stradale"] = cls["strade"]
    rep["warning"] += rileva_incoerenze(cls["strade"], (rep.get("comune") or {}).get("nome"))
    if st.errore:
        rep["warning"].append("Rete stradale NON verificata (Overpass irraggiungibile): %s" % st.errore)
    if raccogli_geometrie:
        rep["_elementi_strade"] = st.data
    n_str = sum(len(v) for v in cls["strade"].values())
    _av("Strade classificate: %d (classi: %s)" % (
        n_str, ", ".join("%s×%d" % (k, len(v)) for k, v in sorted(cls["strade"].items())) or "nessuna"))

    _av("Soprintendenze ABAP competenti (SITAP WFS)…")
    so = soprintendenza_competente(geom, c.data["bbox"])
    rep["fonti"].append({"stadio": "soprintendenze", "fonte": so.fonte,
                         "confidenza": so.confidenza, "errore": so.errore})
    rep["soprintendenze"] = so.data
    rep["warning"] += [n for n in so.note if n]
    for s in so.data or []:
        _av("  %s: %s (%s%% del territorio)" % (s["ambito"], s["denominazione"], s["quota_territorio"]))

    _av("Vincoli paesaggistici nazionali (SITAP WFS, %d layer)…" % len(VINCOLI_LAYERS))
    vi = vincoli_paesaggistici(geom, c.data["bbox"], raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "vincoli paesaggistici", "fonte": vi.fonte,
                         "confidenza": vi.confidenza, "errore": vi.errore})
    rep["vincoli"] = vi.data
    if raccogli_geometrie:
        rep["_geometrie_vincoli"] = getattr(vi, "geometrie", [])
    for v in vi.data:
        _av("  %s: %d poligoni (%s%% del territorio)" % (v["etichetta"], v["n_poligoni"], v["pct_territorio"]))
    # se SITAP ha avuto errori sui vincoli, rimanda al geoportale regionale per
    # la verifica manuale (fallback): meglio un link giusto che un buco muto
    if vi.errore or getattr(vi, "note", None):
        portale, wfs = geoportale_regionale(c.data.get("regione"))
        if portale:
            msg = ("Vincoli SITAP con errori/parziali per questo run: verificare i "
                   "vincoli paesaggistici (art. 136/142) sul geoportale di %s → %s"
                   % (c.data.get("regione") or "regione", portale))
            if wfs:
                msg += " (WFS: %s)" % wfs
            rep.setdefault("warning", []).append(msg)
            _av("  ⚠ SITAP incompleto: fallback geoportale %s" % (c.data.get("regione") or ""))

    _av("Rete Natura 2000 (SIC/ZSC e ZPS — EEA)…")
    n2k = natura2000_intercettati(geom, c.data["bbox"], raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "rete natura 2000", "fonte": n2k.fonte,
                         "confidenza": n2k.confidenza, "errore": n2k.errore})
    rep["natura2000"] = n2k.data
    rep["warning"] += [x for x in n2k.note if x and x not in rep["warning"]]
    if raccogli_geometrie and getattr(n2k, "geometrie", None):
        rep.setdefault("_geometrie_vincoli", [])
        rep["_geometrie_vincoli"] += n2k.geometrie
    for s in n2k.data or []:
        _av("  %s — %s (%s)" % (s["codice"], s["nome"], s["tipo"]))
    if not n2k.data and not n2k.errore:
        _av("  nessun sito Natura 2000 nel territorio comunale")

    _av("Aree naturali protette (parchi nazionali/regionali — SITAP)…")
    prc = parchi_intercettati(geom, raccogli_geometrie=raccogli_geometrie)
    rep["fonti"].append({"stadio": "aree protette (parchi)", "fonte": prc.fonte,
                         "confidenza": prc.confidenza, "errore": prc.errore})
    rep["parchi"] = prc.data
    rep["warning"] += [x for x in prc.note if x and x not in rep["warning"]]
    if raccogli_geometrie and getattr(prc, "geometrie", None):
        rep.setdefault("_geometrie_vincoli", [])
        rep["_geometrie_vincoli"] += prc.geometrie
    for s in prc.data or []:
        _av("  %s%s (%s)" % (s["nome"], (" [%s]" % s["euap"]) if s.get("euap") else "", s["tipo"]))
    if not prc.data and not prc.errore:
        _av("  nessuna area protetta nel territorio comunale")

    _av("Interferenze lineari: ferrovie e corsi d'acqua (Overpass)…")
    il = interferenze_lineari(c.data["osm_relation_id"], con_geometrie=raccogli_geometrie)
    ferr, ferr_dism, acque = set(), set(), set()
    acque_nat, bonifica = set(), set()
    boschi = set()
    for e in il.data or []:
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            ferr.add(t.get("operator") or t.get("name") or "linea ferroviaria")
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            ferr_dism.add(t.get("name") or "ex sedime ferroviario")
        if t.get("waterway") in {"river", "stream", "canal", "ditch", "drain"}:
            # anche i rii demaniali senza nome sono corsi d'acqua rilevanti:
            # scartarli per assenza di 'name' perdeva interferenze reali.
            # Distinguiamo il reticolo NATURALE (demanio idrico, R.D. 523 + fascia
            # paesaggistica 150 m) dal reticolo di BONIFICA (Consorzio, fascia da
            # regolamento consortile): il regime e l'ente competente sono diversi.
            cat, tipo_l = tipo_corso_acqua(t)
            nome_acq = t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"]
            acque.add(nome_acq)
            if cat == "bonifica":
                bonifica.add(nome_acq)
            else:
                acque_nat.add(nome_acq)
        if t.get("natural") == "wood" or t.get("landuse") == "forest":
            # aree boscate: vincolo paesaggistico ex lege art.142 lett.g D.Lgs
            # 42/2004 (i boschi sono vincolati per legge, cartografati o meno)
            nome_b = t.get("name") or "area boscata senza nome"
            boschi.add(nome_b)
            # raccogli la geometria del bosco per lo shape delle tavole (art.142g):
            # gli elementi Overpass 'way' con natural=wood portano 'geometry' (lista
            # di nodi) quando la query è stata fatta con 'out geom'. Chiudiamo l'anello
            # in un poligono. Le relation (multipolygon) non hanno geom diretta: saltate.
            if raccogli_geometrie:
                geo = e.get("geometry")
                if geo and len(geo) >= 3:
                    coords = [[p["lon"], p["lat"]] for p in geo if "lon" in p and "lat" in p]
                    if len(coords) >= 3:
                        if coords[0] != coords[-1]:
                            coords.append(coords[0])   # chiudi l'anello
                        f_b = {"type": "Feature",
                               "properties": {"vincolo": "Area boscata art.142 lett.g",
                                              "nome": nome_b},
                               "geometry": {"type": "Polygon", "coordinates": [coords]}}
                        rep.setdefault("_geometrie_vincoli", [])
                        rep["_geometrie_vincoli"].append(
                            ("Area boscata (art.142 lett.g) — %s" % nome_b, f_b))
    rep["ferrovie"] = sorted(ferr)[:10]
    rep["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    rep["corsi_acqua"] = sorted(acque)[:15]
    rep["corsi_acqua_naturali"] = sorted(acque_nat)[:15]
    rep["canali_bonifica"] = sorted(bonifica)[:15]
    rep["boschi"] = sorted(boschi)[:15]
    rep["fonti"].append({"stadio": "interferenze lineari", "fonte": il.fonte,
                         "confidenza": il.confidenza, "errore": il.errore})
    if il.errore:
        rep["warning"].append(
            "Ferrovie e corsi d'acqua NON verificati (Overpass irraggiungibile): "
            "%s — un elenco vuoto qui non significa assenza di interferenze." % il.errore)
    elif not ferr and not acque and not ferr_dism:
        # query riuscita ma nulla trovato: in una pre-istruttoria l'assenza in
        # OSM non è probante (OSM non è esaustivo su reticolo idrografico/RFI)
        rep["warning"].append(
            "Nessuna interferenza lineare (ferrovie/corsi d'acqua) rilevata in OSM: "
            "OSM NON è esaustivo — verificare su CTR/RFI e sul reticolo idrografico "
            "regionale prima di escludere nulla osta idraulici o ferroviari.")
    if raccogli_geometrie:
        rep["_elementi_lineari"] = il.data
    _av("Ferrovie: %d gestori/linee · corsi d'acqua denominati: %d" % (len(ferr), len(acque)))

    # -- fasce art.142 lett.a (costa 300 m) e lett.c (fiumi 150 m) --
    # SITAP le pubblica come layer REGIONALI (solo alcune regioni). Dove la regione
    # è coperta, interroghiamo il layer giusto; dove non lo è (es. Sicilia) attiviamo
    # il fallback "vincolo probabile" (costiero -> lett.a; corsi d'acqua -> lett.c).
    _av("Fasce paesaggistiche art.142 (costa 300 m / fiumi 150 m)…")
    ha_corsi = bool(rep.get("corsi_acqua"))
    costiero = _comune_costiero(c.data["osm_relation_id"], c.data["bbox"])
    regione_l = (c.data.get("regione") or "").strip().lower()

    # 1) Sicilia: NON è in SITAP ma pubblica i vincoli art.142/136 come poligoni veri
    #    sul geoportale SITR (per provincia/ambito). Provalo per primo.
    f142, geom142, err142 = [], [], []
    coperta142 = False
    fonte142 = None
    if "sicilia" in regione_l:
        prov = (c.data.get("provincia") or "")
        fs, gs, cop_sic, es = vincoli_142_sicilia(
            geom, c.data["bbox"], prov, raccogli_geometrie=raccogli_geometrie)
        if cop_sic and fs:
            f142, geom142, err142, coperta142 = fs, gs, es, True
            fonte142 = "Geoportale Regione Siciliana (SITR)"

    # 2) altre regioni: layer SITAP regionali art.142
    if not coperta142 and "sicilia" not in regione_l:
        f142, geom142, coperta142, err142 = fasce_142_regionali(
            geom, c.data["bbox"], c.data.get("regione"), raccogli_geometrie=raccogli_geometrie)
        if coperta142:
            fonte142 = "SITAP - layer regionali art.142"

    rep["fonti"].append({"stadio": "fasce art.142 (costa/fiumi)",
                         "fonte": fonte142 or "fallback ex lege (regione non coperta)",
                         "confidenza": "media" if coperta142 else "bassa",
                         "errore": "; ".join(err142) if err142 else None})
    if coperta142:
        # aggiungi le fasce trovate ai vincoli (così finiscono in enti, Excel, shape)
        rep.setdefault("vincoli", [])
        rep["vincoli"] += f142
        if raccogli_geometrie and geom142:
            rep.setdefault("_geometrie_vincoli", [])
            rep["_geometrie_vincoli"] += geom142
        for v in f142:
            _av("  %s: %d poligoni (%s%% del territorio)" % (v["etichetta"], v["n_poligoni"], v["pct_territorio"]))
        if not f142:
            _av("  nessuna fascia art.142 (costa/fiumi) intercettata nei layer regionali")
    else:
        # regione senza layer art.142: fallback attivo (avviso ex lege)
        probabili = fasce_142_probabili(geom, c.data["bbox"], costiero, ha_corsi)
        for p in probabili:
            rep.setdefault("warning", []).append(p)
            _av("  ⚠ %s" % p.split(":")[0])
        if not probabili:
            _av("  nessun segnale di fascia art.142 (comune non costiero, nessun corso d'acqua)")
        portale, _wfs = geoportale_regionale(c.data.get("regione"))
        if portale:
            rep.setdefault("warning", []).append(
                "Le fasce art.142 (costa 300 m / fiumi 150 m) per %s non sono in SITAP: "
                "verificare la perimetrazione sul geoportale/PPTR regionale → %s"
                % (c.data.get("regione") or "questa regione", portale))
    rep["_costiero"] = costiero

    # -- pericolosità idrogeologica (ISPRA IdroGEO, per comune ISTAT) --
    _av("Pericolosità idraulica e da frana (ISPRA IdroGEO)…")
    pg = pericolosita_idrogeologica(c.data.get("istat"))
    rep["fonti"].append({"stadio": "pericolosità idrogeologica", "fonte": pg.fonte,
                         "confidenza": pg.confidenza, "errore": pg.errore})
    if pg.data:
        rep["idrogeologico"] = pg.data
        rep["warning"] += [n for n in pg.note if n]
        idr = pg.data["idraulica"]; fr = pg.data["frane"]
        _av("  idraulica: P3 %.1f%% · P2 %.1f%% · P1 %.1f%% del territorio"
            % (idr["P3_elevata_pct"], idr["P2_media_pct"], idr["P1_bassa_pct"]))
        _av("  frane: P3+P4 %.1f%% del territorio" % fr["P3P4_pct"])
    elif pg.errore:
        rep["warning"].append("Pericolosità idrogeologica non verificata (ISPRA IdroGEO): %s" % pg.errore)

    rep["enti"] = componi_enti(rep)
    _av("Enti da interpellare: %d" % len(rep["enti"]))
    return rep


def componi_enti(rep):
    enti = []
    sc = scheda_strada("COMUNALE")   # il Comune c'è sempre
    enti.append({"ruolo": "Ente proprietario del suolo pubblico comunale",
                 "ente": "Comune di %s" % rep["comune"]["nome"], "scheda": sc,
                 "trigger": "sempre", "livello": 4})

    pop = (rep.get("comune") or {}).get("popolazione")
    grande_centro = pop is not None and pop > 10000

    for classe in ["A", "SS", "SR", "SP"]:
        # unisci la rete primaria (DBSN/stradario) con le strade presenti solo in
        # OSM e con quelle non misurate: una SP che il tracciato attraversa NON
        # deve sparire dagli enti solo perché lo stradario di riferimento non la
        # copre (caso Montelabbate: SP423 con 3 attraversamenti stava solo in OSM
        # e la Provincia non veniva generata come ente da interpellare).
        refs = dict(rep["rete_stradale"].get(classe, {}))
        for extra in ("rete_stradale_solo_osm", "rete_stradale_non_misurate"):
            for r, v in (rep.get(extra) or {}).get(classe, {}).items():
                refs.setdefault(r, v)
        if not refs:
            continue
        sc = scheda_strada(classe)
        ops = sorted({o for v in refs.values() for o in v.get("operator", [])})
        voce = {
            "ruolo": sc["descrizione"],
            "ente": ", ".join(ops) if ops else sc["ente_tipo"],
            "scheda": sc,
            "trigger": "%d strade: %s%s" % (len(refs), ", ".join(list(refs)[:12]),
                                            " ..." if len(refs) > 12 else ""),
        }
        # competenza art.2 c.7 CdS: i tratti di SS/SR/SP che attraversano un
        # centro abitato con >10.000 abitanti sono strade COMUNALI ex lege
        # (Cons. Stato 403/2014). Il criterio e' sul centro abitato attraversato,
        # non sull'intero Comune: qui usiamo la pop. comunale come proxy e lo
        # dichiariamo, perche' il perimetro del centro abitato (delibera di
        # delimitazione ex art.4 CdS) non e' un dato nazionale interrogabile.
        if grande_centro and classe in ("SS", "SR", "SP"):
            voce["nota_competenza"] = (
                "Comune con %s ab. (>10.000): ai sensi dell'art. 2 c. 7 CdS i "
                "TRATTI INTERNI al centro abitato di questa strada sono comunali "
                "ex lege (competenza del Comune, non di %s). Fuori dal centro "
                "abitato la competenza resta dell'ente proprietario. Verificare "
                "sul verbale di delimitazione del centro abitato quali tratti "
                "ricadono dentro/fuori." % ("{:,}".format(pop).replace(",", "."),
                                            sc["ente_tipo"]))
        # livello gerarchico dell'ente (per l'ordinamento nazionale->comunale)
        _liv_strada = {"A": 1, "SS": 1, "SR": 2, "SP": 3}.get(classe, 3)
        voce["livello"] = _liv_strada
        enti.append(voce)

    for s in rep.get("soprintendenze", []):
        sc = scheda_vincolo("sopr_paesaggio" if s["ambito"] == "paesaggio" else "archeologia")
        enti.append({"ruolo": "Soprintendenza (%s)" % s["ambito"], "ente": s["denominazione"],
                     "contatti": {"pec": s.get("pec"), "sito": s.get("sito")},
                     "scheda": sc, "trigger": "competenza territoriale", "livello": 1})

    chiavi = {v["chiave"] for v in rep.get("vincoli", [])}
    for k in sorted(chiavi):
        sc = scheda_vincolo(k)
        if sc and k not in {"sopr_paesaggio"}:
            et = [v["etichetta"] for v in rep["vincoli"] if v["chiave"] == k]
            # livello: UNESCO e beni statali = nazionale(1); paesaggistici e
            # ambientali delegati = regionale(2)
            _liv_v = 1 if k in {"unesco"} else 2
            enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"],
                         "scheda": sc, "trigger": "; ".join(et), "livello": _liv_v})
        elif not sc and k not in {"sopr_paesaggio"}:
            # vincolo intercettato ma senza scheda in kb: NON silenziarlo, o il
            # report mostrerebbe la criticità senza dire a chi rivolgersi
            et = [v["etichetta"] for v in rep["vincoli"] if v["chiave"] == k]
            rep.setdefault("warning", []).append(
                "Vincolo '%s' rilevato ma privo di scheda ente in procedimenti.yaml "
                "(%s): l'interlocutore va individuato manualmente." % (k, "; ".join(et)))

    # Rete Natura 2000 (SIC/ZSC + ZPS): genera l'ente con la Valutazione di
    # Incidenza (VIncA). Livello 2 (regionale/ente gestore). Elenca i codici siti.
    if rep.get("natura2000"):
        sc_n = scheda_vincolo("natura2000")
        if sc_n:
            siti = ["%s %s (%s)" % (s["codice"], s["nome"], s["tipo"].split(" ")[0])
                    for s in rep["natura2000"]]
            enti.append({"ruolo": sc_n["descrizione"], "ente": sc_n["ente_tipo"],
                         "scheda": sc_n, "trigger": "; ".join(siti[:6]), "livello": 2})

    # Aree naturali protette (parchi nazionali/regionali): nulla osta dell'Ente
    # gestore ex art. 13 L. 394/1991. Livello 2. Elenca i parchi intercettati.
    if rep.get("parchi"):
        sc_p = scheda_vincolo("aree_protette")
        if sc_p:
            nomi = ["%s%s" % (p["nome"], (" [%s]" % p["euap"]) if p.get("euap") else "")
                    for p in rep["parchi"]]
            enti.append({"ruolo": sc_p["descrizione"], "ente": sc_p["ente_tipo"],
                         "scheda": sc_p, "trigger": "; ".join(nomi[:6]), "livello": 2})

    if rep.get("ferrovie"):
        sc = scheda_vincolo("ferrovia")
        # associa la struttura territoriale RFI competente per regione (punto 4):
        # la linea RFI implica interfaccia con la DTP/struttura RFI di zona
        rfi = rfi_struttura((rep.get("comune") or {}).get("regione"))
        ente_rfi = ", ".join(rep["ferrovie"][:3])
        trig_rfi = "linea ferroviaria nel territorio comunale"
        if rfi:
            ente_rfi = "%s — %s" % (rfi["struttura"], ", ".join(rep["ferrovie"][:3]))
            trig_rfi += " · Fascicolo Circolazione Linee (PGOS Art.2) %s" % rfi.get("pgos_range", "")
        enti.append({"ruolo": sc["descrizione"], "ente": ente_rfi,
                     "scheda": sc, "trigger": trig_rfi, "livello": 1,
                     "rfi": rfi})
    if rep.get("ferrovie_dismesse"):
        sc = scheda_vincolo("ferrovia_dismessa")
        if sc:
            enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"], "scheda": sc,
                         "trigger": "ex sedime: %s" % ", ".join(rep["ferrovie_dismesse"][:3]),
                         "livello": 2})
    if rep.get("corsi_acqua"):
        sc = scheda_vincolo("idrico")
        # distingui l'ATTRAVERSAMENTO demaniale (il tracciato tocca l'alveo,
        # dist ~0 → serve concessione/nulla osta idraulico R.D. 523/1904) dalla
        # semplice PROSSIMITÀ entro la fascia paesaggistica 150 m (art. 142 lett. c
        # → rileva ai fini paesaggistici, NON è occupazione del demanio idrico).
        dist_corsi = (rep.get("_distanze_lineari") or {}).get("corsi_acqua") or {}
        if not dist_corsi:
            # nessuna distanza misurata (modalità comune, senza analisi sul
            # tracciato): comportamento generico, la distinzione non è possibile
            enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"], "scheda": sc,
                         "trigger": "%d corsi d'acqua denominati (distanza non misurata: "
                                    "usare l'analisi sul tracciato per distinguere "
                                    "attraversamento da prossimità)" % len(rep["corsi_acqua"]),
                         "livello": 2})
        else:
            attraversati = [n for n in rep["corsi_acqua"] if dist_corsi.get(n, 999) <= 0.5]
            vicini = [n for n in rep["corsi_acqua"]
                      if 0.5 < dist_corsi.get(n, 999) <= 150]
            if attraversati:
                trig = "%d corso/i attraversato/i (alveo demaniale): %s" % (
                    len(attraversati), ", ".join(attraversati))
                if vicini:
                    trig += " · entro fascia 150 m (solo paesaggistico): %s" % ", ".join(vicini)
                enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"],
                             "scheda": sc, "trigger": trig, "livello": 2})
            elif vicini:
                # nessun attraversamento: NON è competenza demaniale, è solo la
                # fascia paesaggistica dei 150 m. Segnaliamo il vincolo
                # paesaggistico, non la concessione demaniale (che richiederebbe
                # di toccare l'alveo).
                sc_p = scheda_vincolo("sopr_paesaggio") or sc
                det = ", ".join("%s (~%.0f m)" % (n, dist_corsi.get(n, 0)) for n in vicini)
                enti.append({
                    "ruolo": "Corso d'acqua entro la fascia paesaggistica di 150 m (art. 142 lett. c) — NON attraversato",
                    "ente": "Autorizzazione paesaggistica (fascia fluviale); nessuna concessione demaniale se non si tocca l'alveo",
                    "scheda": sc_p,
                    "trigger": "prossimità (nessun attraversamento demaniale): %s" % det,
                    "livello": 2})

    # Canali del reticolo di BONIFICA: competenza del Consorzio di bonifica, con
    # fascia di rispetto stabilita dal regolamento consortile (non i 150 m). OSM non
    # dice quale Consorzio: segnaliamo il reticolo e rimandiamo all'identificazione.
    if rep.get("canali_bonifica"):
        sc_bon = scheda_vincolo("bonifica")
        if sc_bon:
            elenco = ", ".join(rep["canali_bonifica"][:8])
            enti.append({
                "ruolo": sc_bon["descrizione"],
                "ente": sc_bon["ente_tipo"],
                "scheda": sc_bon,
                "trigger": "reticolo di bonifica nel territorio (%d canali/scoline denominati): %s"
                           " · fascia di rispetto da REGOLAMENTO consortile (non i 150 m paesaggistici),"
                           " Consorzio da identificare (OSM non lo riporta)"
                           % (len(rep["canali_bonifica"]), elenco),
                "livello": 2})

    # boschi / aree forestali: vincolo paesaggistico ex lege art.142 lett.g. Se
    # nel comune (o sul tracciato, in modalità tracciato) ci sono aree boscate,
    # segnala il vincolo. Distingue attraversamento da presenza nel comune.
    if rep.get("boschi"):
        sc_b = scheda_vincolo("art142")
        if sc_b:
            dist_b = (rep.get("_distanze_lineari") or {}).get("boschi") or {}
            if dist_b:
                # modalità tracciato: usa le distanze misurate
                attr_b = [n for n in rep["boschi"] if dist_b.get(n, 999) <= 0.5]
                vic_b = [n for n in rep["boschi"] if 0.5 < dist_b.get(n, 999) <= 150]
                if attr_b or vic_b:
                    parti = []
                    if attr_b:
                        parti.append("attraversati/interni: %s" % ", ".join(attr_b[:5]))
                    if vic_b:
                        parti.append("entro 150 m: %s" % ", ".join(vic_b[:5]))
                    enti.append({"ruolo": "Vincolo paesaggistico su aree boscate (art. 142 lett. g)",
                                 "ente": sc_b["ente_tipo"], "scheda": sc_b,
                                 "trigger": "; ".join(parti), "livello": 2})
            else:
                # modalità comune: nessuna distanza, segnala la presenza
                enti.append({"ruolo": "Vincolo paesaggistico su aree boscate (art. 142 lett. g)",
                             "ente": sc_b["ente_tipo"], "scheda": sc_b,
                             "trigger": "%d aree boscate nel territorio comunale (verificare se il "
                                        "tracciato le interseca o vi ricade entro 150 m)" % len(rep["boschi"]),
                             "livello": 2})
    # pericolosità significativa (idraulica P2/P3 o frane P3/P4). Soglia bassa
    # di proposito: in pre-istruttoria meglio segnalare e far verificare.
    idg = rep.get("idrogeologico")
    if idg:
        idr = idg["idraulica"]; fr = idg["frane"]
        trig = []
        if idr["P3_elevata_pct"] >= 1.0:
            trig.append("pericolosità idraulica ELEVATA (P3) sul %.1f%% del territorio" % idr["P3_elevata_pct"])
        elif idr["P2_media_pct"] >= 1.0:
            trig.append("pericolosità idraulica media (P2) sul %.1f%% del territorio" % idr["P2_media_pct"])
        if fr["P3P4_pct"] >= 1.0:
            trig.append("pericolosità da frana elevata (P3-P4) sul %.1f%% del territorio" % fr["P3P4_pct"])
        if trig:
            sc = scheda_vincolo("idrogeologico")
            if sc:
                enti.append({"ruolo": sc["descrizione"], "ente": sc["ente_tipo"], "scheda": sc,
                             "trigger": "; ".join(trig), "livello": 2})

    # Ordinamento GERARCHICO nazionale -> comunale (punto 3): livello 1=Stato/
    # nazionale (ANAS/autostrade, RFI, MiC/UNESCO), 2=regionale (SR, vincoli
    # paesaggistici/ambientali, corsi d'acqua, idrogeologico), 3=provinciale (SP,
    # Province), 4=comunale. Ordinamento STABILE: a parità di livello resta
    # l'ordine di inserimento, così nessun ente viene perso o riordinato a caso.
    for e in enti:
        e.setdefault("livello", 3)
    enti.sort(key=lambda e: e.get("livello", 3))
    return enti


# ---------------------------------------------------------------------------
# Rendering markdown
# ---------------------------------------------------------------------------
def _fmt_stato(v):
    """Cella 'stato/distanza' per la modalità tracciato."""
    st = v.get("stato")
    if not st:
        return "—"
    aff = v.get("affiancamento_m")
    attr = v.get("attraversamenti")
    # stato gia' arricchito (affiancamento/attraversamenti) in analizza_su_tracciato
    if aff and aff >= 5:
        s = "**affianc. ~%d m**" % aff
        if attr:
            s += " +%d attr." % attr
        return s
    if attr:
        return "**%d attravers.**" % attr
    if st == "ATTRAVERSAMENTO":
        return "**ATTRAVERSAMENTO**"
    d = v.get("distanza_m")
    return "%s (%.0f m)" % (st.split(" (")[0], d) if d is not None else st


def to_markdown(rep):
    KB = carica_kb()
    if rep.get("errore"):
        return "# Errore\n\n%s\n" % rep["errore"]
    c = rep["comune"]
    L = ["# Screening scavi su suolo pubblico — %s" % c["nome"], ""]
    if rep.get("area_progetto"):
        L[0] += " (ristretto a: %s)" % rep["area_progetto"]["nome"]
    L.append("**%s**  " % c["display_name"])
    L.append("Provincia: %s · Regione: %s · ISTAT: %s · OSM rel: %s" % (
        c["provincia"] or "n/d", c["regione"] or "n/d", c["istat"] or "n/d", c["osm_relation_id"]))
    L += ["", "> Documento di **pre-istruttoria**. " + KB["meta"]["disclaimer"].strip(), ""]

    L += ["## 1. Rete stradale classificata", ""]
    etich = {"A": "Autostrade", "SS": "Strade statali", "SR": "Strade regionali",
             "SP": "Strade provinciali", "SC": "Strade comunali classificate",
             "RA": "Raccordi autostradali", "NSA": "Nuove strade ANAS"}
    sf = rep.get("stradario_fonte")
    modo_tracc = (rep.get("area_progetto") or {}).get("modalita") == "tracciato"
    if sf:
        L += ["_Fonte primaria: **%s**%s. Colonna 'OSM' = la stessa strada è "
              "confermata anche dai dati OpenStreetMap._" % (
                  sf["nome"],
                  " (indipendente da OSM)" if sf["indipendente"]
                  else " — estratto OSM, non indipendente"), ""]
    if modo_tracc:
        L += ["_Analisi sul tracciato: colonna 'Stato/distanza' = rapporto tra il "
              "tracciato e la strada (attraversamento o distanza entro fascia di rispetto)._", ""]
    if not rep["rete_stradale"]:
        L.append("_Nessuna strada classificata rilevata (o fonte non raggiungibile)._")
    for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
        refs = rep["rete_stradale"].get(cls)
        if not refs:
            continue
        col_extra = ""
        if modo_tracc:
            col_extra = " Stato/distanza |"
        if sf:
            L += ["### %s — %d" % (etich.get(cls, cls), len(refs)), "",
                  "| Ref | Segmenti | Confermata OSM | Gestore | Denominazione |%s" % col_extra,
                  "|---|---:|:---:|---|---|%s" % ("---|" if modo_tracc else "")]
            for r, v in refs.items():
                riga = "| **%s** | %s | %s | %s | %s |" % (
                    r, v["n_way"], "sì" if v.get("confermato_osm") else "**no**",
                    ", ".join(v["operator"]) or "—", "; ".join(v["nomi"]) or "—")
                if modo_tracc:
                    riga += " %s |" % _fmt_stato(v)
                L.append(riga)
            L.append("")
        else:
            L += ["### %s — %d" % (etich.get(cls, cls), len(refs)), "",
                  "| Ref | Segmenti OSM | Gestore da OSM | Denominazione |%s" % col_extra,
                  "|---|---:|---|---|%s" % ("---|" if modo_tracc else "")]
            for r, v in refs.items():
                riga = "| **%s** | %s | %s | %s |" % (
                    r, v["n_way"], ", ".join(v["operator"]) or "—", "; ".join(v["nomi"]) or "—")
                if modo_tracc:
                    riga += " %s |" % _fmt_stato(v)
                L.append(riga)
            L.append("")
    # strade che OSM ha ma lo stradario di riferimento no
    solo_osm = rep.get("rete_stradale_solo_osm") or {}
    if solo_osm:
        tutte = ", ".join(r for cls in solo_osm for r in solo_osm[cls])
        L += ["**Presenti in OSM ma non nello stradario di riferimento** "
              "(riclassificazioni o copertura mancante — da verificare): %s" % tutte, ""]

    L += ["## 2. Tutela beni culturali e paesaggio", ""]
    if rep.get("soprintendenze"):
        L += ["| Ambito | Soprintendenza | % territorio | PEC |", "|---|---|---:|---|"]
        for s in rep["soprintendenze"]:
            flag = " ⚠︎" if s.get("marginale") else ""
            L.append("| %s | %s%s | %s%% | `%s` |" % (
                s["ambito"], s["denominazione"], flag,
                s.get("quota_territorio", "—"), s.get("pec") or "—"))
        if any(s.get("marginale") for s in rep["soprintendenze"]):
            L += ["", "⚠︎ = giurisdizione marginale. Comune di confine: verificare la "
                  "competenza sul tratto specifico, non sull'intero territorio."]
        L.append("")
    else:
        L += ["_Soprintendenza non determinata dai servizi SITAP._", ""]

    if rep.get("vincoli"):
        L += ["| Vincolo | Poligoni intersecanti | % territorio |", "|---|---:|---:|"]
        for v in rep["vincoli"]:
            L.append("| %s | %s | %s%% |" % (v["etichetta"], v["n_poligoni"], v["pct_territorio"]))
        L.append("")
    else:
        L += ["_Nessun vincolo intercettato nei layer nazionali SITAP interrogati — "
              "**non equivale ad assenza di vincoli**._", ""]

    if rep.get("ferrovie") or rep.get("ferrovie_dismesse") or rep.get("corsi_acqua"):
        L += ["## 3. Altre interferenze", ""]
        if rep.get("ferrovie"):
            L.append("- **Ferrovie**: %s — fascia di rispetto 30 m ex D.P.R. 753/1980"
                     % ", ".join(rep["ferrovie"]))
        if rep.get("ferrovie_dismesse"):
            L.append("- **Ex sedimi ferroviari** (linee dismesse): %s — il sedime resta "
                     "di norma di proprietà RFI anche se riconvertito: serve il nulla osta"
                     % ", ".join(rep["ferrovie_dismesse"]))
        if rep.get("corsi_acqua"):
            L.append("- **Corsi d'acqua** (%d): %s%s" % (
                len(rep["corsi_acqua"]), ", ".join(rep["corsi_acqua"][:8]),
                " …" if len(rep["corsi_acqua"]) > 8 else ""))
        L.append("")

    idg = rep.get("idrogeologico")
    if idg:
        idr = idg["idraulica"]; fr = idg["frane"]
        L += ["## 3-bis. Pericolosità idrogeologica (ISPRA IdroGEO — dato comunale)", "",
              "| Tipo | Classe | % del territorio comunale |", "|---|---|---:|",
              "| Idraulica (PGRA) | P3 elevata | %.1f%% |" % idr["P3_elevata_pct"],
              "| Idraulica (PGRA) | P2 media | %.1f%% |" % idr["P2_media_pct"],
              "| Idraulica (PGRA) | P1 bassa | %.1f%% |" % idr["P1_bassa_pct"],
              "| Frane (PAI) | P4+P3 | %.1f%% |" % fr["P3P4_pct"], "",
              "_Percentuali riferite all'**intero comune** (fonte ISPRA, mosaicatura "
              "nazionale PAI/PGRA), non all'area di progetto: indicano se il territorio "
              "ha aree vincolate. Se il tracciato ricade in una di queste aree va verificato "
              "sul PAI del distretto / geoportale regionale._", ""]

    L += ["## 4. Enti da interpellare", ""]
    for i, e in enumerate(rep["enti"], 1):
        sc = e["scheda"] or {}
        L.append("### %d. %s" % (i, e["ente"]))
        L.append("*%s* — trigger: %s" % (e["ruolo"], e["trigger"]))
        if e.get("nota_competenza"):
            L.append("\n> ⚠️ **Competenza**: %s" % e["nota_competenza"])
        if e.get("contatti", {}).get("pec"):
            L.append("PEC: `%s` · %s" % (e["contatti"]["pec"], e["contatti"].get("sito", "")))
        if sc.get("titolo_richiesto"):
            L.append("\n**Titolo**: %s" % sc["titolo_richiesto"])
        if sc.get("norme"):
            nn = [KB["norme"][n]["id"] for n in sc["norme"] if n in KB["norme"]]
            L.append("**Riferimenti**: %s" % ", ".join(nn))
        if sc.get("documentazione_tipica"):
            L.append("\n**Documentazione tipica**:")
            L += ["- %s" % d for d in sc["documentazione_tipica"]]
        if sc.get("criticita"):
            L.append("\n**Criticità note**:")
            L += ["- %s" % d for d in sc["criticita"]]
        L.append("")

    if rep.get("warning"):
        L += ["## 5. Warning e incoerenze rilevate", ""]
        L += ["- %s" % w for w in rep["warning"]]
        L.append("")

    L += ["## 6. Provenienza e affidabilità dei dati", "",
          "| Stadio | Fonte | Confidenza | Errore |", "|---|---|---|---|"]
    for f in rep["fonti"]:
        L.append("| %s | %s | %s | %s |" % (f["stadio"], f["fonte"], f["confidenza"], f.get("errore") or "—"))
    L += ["", "---", "",
          "**Non coperto da questo screening** (richiede fonti regionali/locali): "
          "vincolo idrogeologico, PAI e fasce di pericolosità, usi civici, PUGSS e "
          "regolamento scavi comunale, sottoservizi esistenti (SINFI), reti Natura 2000, "
          "servitù militari, piani di rischio aeroportuale."]
    return "\n".join(L)


# ---------------------------------------------------------------------------
# GeoJSON per il caricamento in mappa (consumato dal pannello QGIS)
# ---------------------------------------------------------------------------
def geojson_strade(elementi, rep=None):
    """Way Overpass (con 'geometry') -> FeatureCollection di LineString con
    classe/ref/operator/name. Solo le way classificate. Se `rep` è dato, aggiunge
    lo 'stato' dell'analisi sul tracciato (ATTRAVERSAMENTO/entro fascia/fuori
    fascia) per ref, così lo stile QGIS può categorizzare per stato."""
    # mappa ref -> stato dalle reti analizzate (se disponibili)
    stato_per_ref = {}
    if rep is not None:
        for chiave in ("rete_stradale", "rete_stradale_solo_osm",
                       "rete_stradale_non_misurate", "rete_stradale_fuori"):
            for cls, refs in (rep.get(chiave) or {}).items():
                for ref, v in refs.items():
                    st = v.get("stato")
                    if st and ref not in stato_per_ref:
                        stato_per_ref[ref] = st
    feats = []
    for e in elementi or []:
        geomtr = e.get("geometry")
        if not geomtr:
            continue
        t = e.get("tags", {})
        parsed = normalizza_ref(t.get("ref", ""))
        if not parsed:
            continue
        cls, ref_norm = parsed
        # stato sintetico per lo stile: attraversamento / entro fascia / fuori / n.d.
        st_raw = stato_per_ref.get(ref_norm, "")
        if "ATTRAVERS" in st_raw.upper() or "attravers" in st_raw:
            stato_cls = "attraversamento"
        elif "fuori fascia" in st_raw:
            stato_cls = "fuori fascia"
        elif st_raw:
            stato_cls = "entro fascia"
        else:
            stato_cls = "n.d."
        feats.append({
            "type": "Feature",
            "properties": {"classe": cls, "ref": ref_norm,
                           "operator": t.get("operator") or "",
                           "name": t.get("name") or "",
                           "stato": stato_cls, "stato_dett": st_raw},
            "geometry": {"type": "LineString",
                         "coordinates": [[p["lon"], p["lat"]] for p in geomtr]},
        })
    return {"type": "FeatureCollection", "features": feats}


def geojson_lineari(elementi):
    """Ferrovie e corsi d'acqua Overpass -> FeatureCollection di LineString."""
    feats = []
    for e in elementi or []:
        geomtr = e.get("geometry")
        if not geomtr:
            continue
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            tipo = "ferrovia"
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            tipo = "ex sedime ferroviario"
        elif t.get("waterway") in {"river", "stream", "canal"}:
            tipo = "corso d'acqua"
        else:
            continue
        feats.append({
            "type": "Feature",
            "properties": {"tipo": tipo, "name": t.get("name") or "",
                           "operator": t.get("operator") or "",
                           "etichetta": (t.get("name") or "").strip() or tipo},
            "geometry": {"type": "LineString",
                         "coordinates": [[p["lon"], p["lat"]] for p in geomtr]},
        })
    return {"type": "FeatureCollection", "features": feats}


def geojson_comune(rep):
    """Confine comunale (da Nominatim) -> FeatureCollection con un poligono."""
    from shapely.geometry import mapping
    g = rep.get("_geometria_comune")
    if g is None:
        return {"type": "FeatureCollection", "features": []}
    c = rep.get("comune", {})
    return {"type": "FeatureCollection", "features": [{
        "type": "Feature",
        "properties": {"nome": c.get("nome"), "istat": c.get("istat"),
                       "provincia": c.get("provincia"), "regione": c.get("regione")},
        "geometry": mapping(g),
    }]}


# ---------------------------------------------------------------------------
# Override da stradario locale (layer scelto dall'utente)
# ---------------------------------------------------------------------------
def rete_da_stradario(records):
    """records = [{"ref": <valore campo classificazione>, "name": str,
    "operator": str, "distanza_m": float|None}] estratti da un layer locale e
    già filtrati sull'area. Ritorna {classe: {ref_norm: {n_way, operator, nomi,
    [distanza_m, stato, fascia_m]}}}. Se i record portano 'distanza_m' (modalità
    tracciato), ogni ref riceve la distanza minima, lo stato rispetto alla
    fascia di rispetto della sua classe, e i ref oltre fascia vengono scartati."""
    finti = []
    dist_per = {}   # (cls,ref_norm) -> distanza minima
    for r in records:
        tags = {}
        if r.get("ref"):
            tags["ref"] = str(r["ref"])
        if r.get("name"):
            tags["name"] = str(r["name"])
        if r.get("operator"):
            tags["operator"] = str(r["operator"])
        finti.append({"tags": tags})
        d = r.get("distanza_m")
        if d is not None:
            parsed = normalizza_ref(str(r.get("ref") or ""))
            if parsed:
                k = parsed
                if k not in dist_per or d < dist_per[k]:
                    dist_per[k] = d
    rete = classifica_strade(finti)["strade"]
    if not dist_per:
        return rete
    # applica distanza/stato/fascia e scarta i ref oltre la fascia di rispetto
    fasce = {s["classe"]: s.get("fascia_rispetto_m", 0) for s in carica_kb()["strade"]}
    out = {}
    for cls, refs in rete.items():
        fascia = fasce.get(cls, 0)
        tenuti = {}
        for ref, v in refs.items():
            d = dist_per.get((cls, ref))
            if d is None:
                tenuti[ref] = v
                continue
            stato, prio = _classifica_distanza(d, fascia)
            if prio == 2:
                continue   # oltre fascia: non genera obbligo
            v["distanza_m"] = round(d, 1)
            v["stato"] = stato
            v["fascia_m"] = fascia
            tenuti[ref] = v
        if tenuti:
            out[cls] = tenuti
    return out


def fondi_stradario(rep, rete_stradario, nome_fonte, fonte_indipendente):
    """Fonde nel report la rete stradale da un layer locale (fonte primaria)
    con quella già presente da OSM/Overpass (controprova).

    - rep["rete_stradale"] diventa quella dello stradario, con ogni ref marcato
      'confermato_osm' True/False;
    - i ref presenti in OSM ma non nello stradario finiscono in
      rep["rete_stradale_solo_osm"] (potenziali strade che lo stradario locale
      non copre: NON vanno perse, vanno segnalate);
    - warning esplicito per ogni discordanza;
    - la fonte 'rete stradale' nel report è aggiornata a 'stradario locale …';
    - gli enti vengono ricomposti sulla rete fusa.
    fonte_indipendente=True quando il layer NON è un estratto OSM (DBSN, grafi
    regionali): allora la conferma incrociata ha valore; se False (ANAS_Italia,
    Stradario Provincia Italia = estratti OSM) il report lo dichiara."""
    osm = rep.get("rete_stradale", {})
    fusa = {}
    solo_osm = {}
    discordanze = []

    classi = set(rete_stradario) | set(osm)
    for cls in classi:
        refs_str = rete_stradario.get(cls, {})
        refs_osm = osm.get(cls, {})
        tenuti = {}
        for ref, v in refs_str.items():
            voce = dict(v)
            voce["confermato_osm"] = ref in refs_osm
            # se il report era già stato analizzato sul tracciato, la voce OSM
            # porta distanza_m/stato/fascia_m: propagali alla voce fusa così
            # non si perdono (fondi_stradario gira dopo analizza_su_tracciato)
            if ref in refs_osm:
                for campo in ("distanza_m", "stato", "fascia_m"):
                    # riempi dalla voce OSM SOLO se lo stradario primario (DBSN)
                    # non ha gia' calcolato il valore sulla propria geometria:
                    # la fonte primaria e' piu' accurata, non va sovrascritta
                    if campo not in voce and campo in refs_osm[ref]:
                        voce[campo] = refs_osm[ref][campo]
            tenuti[ref] = voce
            if ref not in refs_osm:
                discordanze.append("%s presente nello stradario '%s' ma non tra le "
                                   "strade OSM del comune: verificare." % (ref, nome_fonte))
        if tenuti:
            fusa[cls] = tenuti
        # ref che OSM ha e lo stradario no
        mancanti = {ref: v for ref, v in refs_osm.items() if ref not in refs_str}
        if mancanti:
            solo_osm[cls] = mancanti
            for ref in mancanti:
                discordanze.append("%s presente in OSM ma non nello stradario '%s': "
                                   "possibile riclassificazione o copertura mancante." % (ref, nome_fonte))

    rep["rete_stradale"] = fusa
    rep["rete_stradale_solo_osm"] = solo_osm
    rep["stradario_fonte"] = {"nome": nome_fonte, "indipendente": fonte_indipendente}
    rep["warning"] += discordanze

    # aggiorna la riga di provenienza della rete stradale
    et = ("stradario locale '%s' (fonte indipendente da OSM)" if fonte_indipendente
          else "stradario locale '%s' (ATTENZIONE: estratto OSM, stessa origine di Overpass)")
    trovato = False
    for f in rep.get("fonti", []):
        if f["stadio"] == "rete stradale":
            f["fonte"] = et % nome_fonte
            f["confidenza"] = "alta" if fonte_indipendente else "media"
            trovato = True
            break
    if not trovato:
        rep.setdefault("fonti", []).append(
            {"stadio": "rete stradale (stradario)", "fonte": et % nome_fonte,
             "confidenza": "alta" if fonte_indipendente else "media", "errore": None})

    if not fonte_indipendente:
        rep["warning"].append(
            "Lo stradario di riferimento '%s' è un estratto OpenStreetMap (campo osm_id): "
            "la conferma incrociata con Overpass NON aggiunge una fonte indipendente. "
            "Per una verifica indipendente usare come riferimento il DBSN (IGM) o un grafo "
            "regionale." % nome_fonte)

    rep["enti"] = componi_enti(rep)
    return rep


def geojson_vincoli(geometrie):
    """[(etichetta, feature SITAP)] -> FeatureCollection con l'etichetta del vincolo."""
    feats = []
    for etichetta, f in geometrie or []:
        if not f.get("geometry"):
            continue
        feats.append({"type": "Feature",
                      "properties": {"vincolo": etichetta},
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_natura2000(geometrie):
    """Estrae dai _geometrie_vincoli i soli poligoni Natura 2000 (etichetta che
    inizia per 'Natura 2000') -> FeatureCollection con tipo/codice/nome, per uno
    stile e uno shape dedicati distinti dai vincoli paesaggistici SITAP."""
    feats = []
    for etichetta, f in geometrie or []:
        if not str(etichetta).startswith("Natura 2000"):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_parchi(geometrie):
    """Estrae dai _geometrie_vincoli i soli poligoni delle aree protette (etichetta
    che inizia per 'Parco') -> FeatureCollection, per uno shape/stile dedicati."""
    feats = []
    for etichetta, f in geometrie or []:
        if not str(etichetta).startswith("Parco"):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_boschi(geometrie):
    """Estrae dai _geometrie_vincoli i poligoni delle aree boscate (art.142 lett.g).
    Cattura sia 'Area boscata' (OSM) sia 'Aree boscate' (geoportale Sicilia)."""
    feats = []
    for etichetta, f in geometrie or []:
        e = str(etichetta).lower()
        if not ("area boscata" in e or "aree boscate" in e):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_fasce142(geometrie):
    """Estrae dai _geometrie_vincoli le fasce art.142 costa/fiumi (etichetta che
    inizia per 'Fascia') -> FeatureCollection, per uno shape/stile dedicati."""
    feats = []
    for etichetta, f in geometrie or []:
        if not str(etichetta).startswith("Fascia"):
            continue
        if not f.get("geometry"):
            continue
        props = dict(f.get("properties", {}))
        props.setdefault("vincolo", etichetta)
        feats.append({"type": "Feature", "properties": props,
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


def geojson_vincoli_sitap(geometrie):
    """Vincoli paesaggistici da mettere nel layer 'Vincoli SITAP': ESCLUDE Natura
    2000, parchi, aree boscate e fasce costa/fiumi (che hanno il loro layer dedicato).
    Tiene art.136 decretati, UNESCO, zone umide e simili."""
    feats = []
    for etichetta, f in geometrie or []:
        e = str(etichetta).lower()
        if (e.startswith("natura 2000") or e.startswith("parco")
                or "area boscata" in e or "aree boscate" in e or e.startswith("fascia")):
            continue
        if not f.get("geometry"):
            continue
        feats.append({"type": "Feature",
                      "properties": {"vincolo": etichetta},
                      "geometry": f["geometry"]})
    return {"type": "FeatureCollection", "features": feats}


# ---------------------------------------------------------------------------
# Restrizione all'area di progetto (es. ARLO AREA)
# ---------------------------------------------------------------------------
# ---------------------------------------------------------------------------
# Analisi sul TRACCIATO reale con fasce di rispetto ufficiali
# ---------------------------------------------------------------------------
def _metrico(geom_wgs84):
    """Riproietta una geometria da WGS84 al UTM locale (metri) per misure di
    distanza corrette. Sceglie la zona UTM dal centroide. Se pyproj non è
    disponibile usa una proiezione equirettangolare locale (accurata su pochi
    km, più che sufficiente per le distanze di fascia di rispetto)."""
    from shapely.ops import transform as _shp_transform
    c = geom_wgs84.centroid
    if c.is_empty:
        # GeometryCollection con parti vuote, o geometria degenere: ripiega sul
        # centro del bounding box (sempre definito se la geom ha estensione)
        try:
            minx, miny, maxx, maxy = geom_wgs84.bounds
            from shapely.geometry import Point as _P
            c = _P((minx + maxx) / 2.0, (miny + maxy) / 2.0)
        except Exception:  # noqa: BLE001
            from shapely.geometry import Point as _P
            c = _P(0.0, 0.0)
    try:
        import pyproj
        zona = int((c.x + 180) / 6) + 1
        epsg = 32600 + zona if c.y >= 0 else 32700 + zona
        trasf = pyproj.Transformer.from_crs("EPSG:4326", "EPSG:%d" % epsg, always_xy=True).transform
        return _shp_transform(trasf, geom_wgs84), ("pyproj", epsg)
    except Exception:  # noqa: BLE001
        import math
        lat0 = math.radians(c.y)
        kx = 111320.0 * math.cos(lat0)   # m per grado di longitudine alla latitudine
        ky = 110540.0                     # m per grado di latitudine
        x0, y0 = c.x, c.y

        def _loc(x, y, z=None):
            return ((x - x0) * kx, (y - y0) * ky)
        return _shp_transform(_loc, geom_wgs84), ("locale", (x0, y0, kx, ky))


def _proiettore_metrico(info):
    """Ritorna una funzione shapely-transform coerente con _metrico(), per
    proiettare altre geometrie nello stesso sistema metrico locale."""
    tipo, dati = info
    if tipo == "pyproj":
        import pyproj
        return pyproj.Transformer.from_crs("EPSG:4326", "EPSG:%d" % dati, always_xy=True).transform
    x0, y0, kx, ky = dati

    def _loc(x, y, z=None):
        return ((x - x0) * kx, (y - y0) * ky)
    return _loc


def _classifica_distanza(dist_m, fascia_m):
    """Verdetto per una interferenza dato distanza e fascia di rispetto.
    Ritorna (stato, priorita) con priorita per l'ordinamento (0 = più grave)."""
    if dist_m <= 0.5:
        return "ATTRAVERSAMENTO", 0
    if fascia_m and dist_m <= fascia_m:
        return "entro fascia di rispetto (%.0f m)" % fascia_m, 1
    return "fuori fascia (%.0f m)" % dist_m, 2


def _rapporto_tracciato(tracciato_m, elemento_m, fascia_m):
    """Rapporto geometrico tra tracciato di progetto ed elemento (strada/lineare),
    entrambi gia' proiettati in metri. Ritorna dict con:
      - distanza_m: distanza minima
      - attraversamenti: n. di punti in cui il tracciato incrocia l'elemento
      - affiancamento_m: metri di tracciato che corrono entro la fascia
        (posa longitudinale — cio' che conta per canone e regime autorizzativo)
    Distingue l'attraversamento puntuale ('taglio la SP in un punto') dalla posa
    in affiancamento ('corro lungo la SP per N metri')."""
    out = {"distanza_m": None, "attraversamenti": 0, "affiancamento_m": 0.0}
    try:
        out["distanza_m"] = tracciato_m.distance(elemento_m)
    except Exception:  # noqa: BLE001
        return out
    # attraversamenti: intersezione geometrica tracciato x elemento (linee)
    try:
        inter = tracciato_m.intersection(elemento_m)
        if not inter.is_empty:
            from shapely.geometry import Point, MultiPoint, GeometryCollection
            if isinstance(inter, Point):
                out["attraversamenti"] = 1
            elif isinstance(inter, (MultiPoint, GeometryCollection)):
                out["attraversamenti"] = sum(
                    1 for g in getattr(inter, "geoms", []) if g.geom_type == "Point")
            elif inter.geom_type in ("LineString", "MultiLineString"):
                out["attraversamenti"] = 1  # sovrapposizione = almeno un contatto
    except Exception:  # noqa: BLE001
        pass
    # affiancamento: lunghezza del tracciato entro la fascia dell'elemento
    if fascia_m and fascia_m > 0:
        try:
            fascia_poly = elemento_m.buffer(fascia_m)
            dentro = tracciato_m.intersection(fascia_poly)
            if not dentro.is_empty and dentro.geom_type in ("LineString", "MultiLineString"):
                out["affiancamento_m"] = round(dentro.length, 1)
        except Exception:  # noqa: BLE001
            pass
    return out


def analizza_su_tracciato(rep, tracciato, buffer_m=0.0, nome_tracciato="tracciato di progetto"):
    """Ricalcola il report misurando la distanza REALE (in metri) tra il
    tracciato di progetto e ogni ente/vincolo, confrontandola con la fascia di
    rispetto ufficiale di quell'ente.

    `tracciato` = geometria shapely in EPSG:4326 (unione di 03 INFRASTRUTTURE +
    pozzetti + armadi). `buffer_m` = margine extra applicato al tracciato prima
    del test (0 = distanza pura). Richiede rep con raccogli_geometrie=True.

    Differenza da restringi_ad_area: non filtra per intersezione con un poligono,
    ma calcola distanze metriche e assegna a ogni interferenza uno STATO
    (attraversamento / entro fascia / fuori) in base alla fascia ufficiale. Ogni
    voce guadagna 'distanza_m', 'stato', 'fascia_m'. Le strade/vincoli entro la
    propria fascia restano nel report (le fasce di rispetto obbligano comunque);
    quelli oltre la fascia vengono scartati dagli enti ma restano tracciati come
    'fuori fascia' per trasparenza."""
    if "_elementi_strade" not in rep:
        raise ValueError("report senza geometrie: rilancia esegui() con raccogli_geometrie=True")
    from shapely.geometry import LineString, shape as _shape

    # tracciato in metri (UTM locale o proiezione locale se pyproj manca)
    tr_m_puro, info = _metrico(tracciato)   # senza buffer, per affiancamento/attraversamenti
    tr_m = tr_m_puro
    if buffer_m and buffer_m > 0:
        tr_m = tr_m_puro.buffer(buffer_m)
    to_m = _proiettore_metrico(info)
    from shapely.ops import transform as _t

    def dist_m(geom_wgs):
        try:
            return tr_m.distance(_t(to_m, geom_wgs))
        except Exception:  # noqa: BLE001
            return None

    nuovo = {k: v for k, v in rep.items()
             if k not in {"rete_stradale", "vincoli", "ferrovie", "ferrovie_dismesse",
                          "corsi_acqua", "boschi", "enti", "warning",
                          "_elementi_strade", "_elementi_lineari", "_geometrie_vincoli"}}
    nuovo["warning"] = list(rep.get("warning", []))
    nuovo["area_progetto"] = {"nome": nome_tracciato, "modalita": "tracciato",
                              "buffer_m": buffer_m}
    # salva il tracciato (WGS84) + buffer per l'attribuzione ARLO basata sul
    # tracciato reale: l'ARLO di una strada è la zona dove il tracciato di
    # progetto incontra la strada, non dove passa la geometria OSM (che sovrastima)
    try:
        nuovo["_tracciato_wgs"] = tracciato.wkt
        nuovo["_tracciato_buffer_m"] = buffer_m
    except Exception:  # noqa: BLE001
        pass

    def _geom_way(e):
        pts = e.get("geometry")
        if not pts or len(pts) < 2:
            return None
        try:
            return LineString([(p["lon"], p["lat"]) for p in pts])
        except Exception:  # noqa: BLE001
            return None

    # fasce per classe strada, dalla kb
    fasce_strada = {}
    for s in carica_kb()["strade"]:
        fasce_strada[s["classe"]] = s.get("fascia_rispetto_m", 0)

    # strade: per ogni ref aggrega distanza minima, metri di affiancamento
    # (posa longitudinale) e n. di attraversamenti puntuali
    el_strade = []
    dist_ref = {}     # (cls,ref) -> distanza minima
    aff_ref = {}      # (cls,ref) -> metri di affiancamento totali
    attr_ref = {}     # (cls,ref) -> n. attraversamenti
    for e in rep.get("_elementi_strade") or []:
        g = _geom_way(e)
        if g is None:
            continue
        parsed = normalizza_ref(e.get("tags", {}).get("ref", ""))
        if not parsed:
            continue
        cls = parsed[0]
        fascia = fasce_strada.get(cls, 0)
        try:
            g_m = _t(to_m, g)
        except Exception:  # noqa: BLE001
            continue
        rap = _rapporto_tracciato(tr_m_puro, g_m, fascia)
        d = rap["distanza_m"]
        if d is None:
            continue
        k = parsed
        if k not in dist_ref or d < dist_ref[k]:
            dist_ref[k] = d
        aff_ref[k] = aff_ref.get(k, 0.0) + rap["affiancamento_m"]
        attr_ref[k] = attr_ref.get(k, 0) + rap["attraversamenti"]
        el_strade.append(e)
    rete = {}
    rete_fuori = {}   # strade classificate del comune FUORI fascia dal tracciato
    rete_non_mis = {} # classificate ma senza geometria misurabile in questo run
    # se il comune è un grande centro (>10.000 ab) le fasce di rispetto DPR
    # 495/1992 NON valgono dentro il perimetro urbano (art.4 CdS): lì è
    # occupazione suolo, non fascia. Segnaliamo il caveat per non over-riportare
    grande_centro = ((rep.get("comune") or {}).get("popolazione") or 0) > 10000
    for cls, refs in rep.get("rete_stradale", {}).items():
        fascia = fasce_strada.get(cls, 0)
        tenuti = {}
        fuori = {}
        non_misurate = {}
        for ref, v in refs.items():
            d = dist_ref.get((cls, ref))
            if d is None:
                # la strada è classificata (OSM ha ref+tag) ma manca la geometria
                # in _elementi_strade (Overpass non l'ha restituita, o è oltre il
                # bbox): NON scartarla in silenzio — un affiancamento longitudinale
                # potrebbe esserci e non l'abbiamo potuto misurare. La teniamo con
                # stato esplicito e alziamo un warning, così finisce nel report.
                voce = dict(v)
                voce["distanza_m"] = None
                voce["stato"] = "non misurata (geometria assente in OSM)"
                voce["fascia_m"] = fascia
                non_misurate[ref] = voce
                continue
            stato, prio = _classifica_distanza(d, fascia)
            if prio == 2:   # fuori fascia: non genera obbligo, ma resta a titolo informativo
                voce = dict(v)
                voce["distanza_m"] = round(d, 1)
                voce["stato"] = "fuori fascia (%.0f m)" % d
                voce["fascia_m"] = fascia
                fuori[ref] = voce
                continue
            voce = dict(v)
            voce["distanza_m"] = round(d, 1)
            voce["stato"] = stato
            voce["fascia_m"] = fascia
            aff = round(aff_ref.get((cls, ref), 0.0))
            attr = attr_ref.get((cls, ref), 0)
            voce["affiancamento_m"] = aff
            voce["attraversamenti"] = attr
            # stato piu' informativo: distingue posa longitudinale da taglio
            if aff >= 5:
                voce["stato"] = "affiancamento ~%d m%s" % (
                    aff, " + %d attravers." % attr if attr else "")
            elif attr:
                voce["stato"] = "%d attraversament%s" % (attr, "o" if attr == 1 else "i")
            # caveat centro abitato: se è solo prossimità in fascia (non
            # attraversamento) in un grande centro, la fascia potrebbe non valere
            if grande_centro and prio == 1 and not attr and aff < 5:
                voce["stato"] += " (se fuori centro abitato)"
            tenuti[ref] = voce
        if tenuti:
            rete[cls] = tenuti
        if fuori:
            rete_fuori[cls] = fuori
        if non_misurate:
            rete_non_mis.setdefault(cls, {}).update(non_misurate)
            for ref in non_misurate:
                nuovo["warning"].append(
                    "%s: strada classificata in OSM ma senza geometria disponibile "
                    "in questo run — distanza/affiancamento NON misurati. Verificare "
                    "manualmente se il tracciato le corre a fianco (posa longitudinale)."
                    % ref)
    nuovo["rete_stradale"] = rete
    nuovo["rete_stradale_fuori"] = rete_fuori
    nuovo["rete_stradale_non_misurate"] = rete_non_mis
    nuovo["_elementi_strade"] = el_strade

    # vincoli SITAP: i poligoni SONO gia' l'area vincolata (art.136 decretati,
    # art.142 boschi/fasce mappate). Un vincolo areale conta se il tracciato lo
    # ATTRAVERSA (distanza ~0) o ricade entro il margine scelto (buffer_m): non
    # esiste una "fascia di rispetto" di 150 m attorno a un bosco o a un decreto.
    # I 150 m dell'art.142 lett.c sono gia' incorporati nei poligoni SITAP della
    # fascia fluviale. Margine di tolleranza per l'accuratezza posizionale SITAP.
    margine_vinc = max(buffer_m, 5.0)
    geometrie_tenute = []
    per_etichetta = {}
    for etichetta, f in rep.get("_geometrie_vincoli") or []:
        try:
            g = _shape(f["geometry"])
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        d = dist_m(g)
        if d is None:
            continue
        rec = per_etichetta.setdefault(etichetta, {"n": 0, "dmin": d})
        rec["n"] += 1
        rec["dmin"] = min(rec["dmin"], d)
        # CONSERVA TUTTE le geometrie dei vincoli comunali per lo shape (riscontro
        # visivo completo di ciò che è nell'Excel), non solo quelle attraversate dal
        # tracciato. Marca lo stato nella property così lo stile può distinguerle.
        f2 = dict(f)
        props = dict(f2.get("properties", {}))
        props["stato_tracc"] = ("attraversato" if d <= margine_vinc else "nel comune")
        props["dist_m"] = round(d, 1)
        f2["properties"] = props
        geometrie_tenute.append((etichetta, f2))
    vincoli = []
    for v in rep.get("vincoli", []):
        rec = per_etichetta.get(v["etichetta"])
        if not rec:
            continue
        voce = dict(v)
        voce["distanza_m"] = round(rec["dmin"], 1)
        if rec["dmin"] <= 0.5:
            voce["stato"] = "ATTRAVERSAMENTO"
        elif rec["dmin"] <= margine_vinc:
            voce["stato"] = "entro %.0f m dal vincolo (verificare)" % rec["dmin"]
        else:
            # il vincolo è nel comune ma il tracciato non lo tocca: lo teniamo
            # comunque (riscontro visivo + l'utente vuole vedere tutto in tabella)
            voce["stato"] = "presente nel comune (tracciato a %.0f m)" % rec["dmin"]
        vincoli.append(voce)
    nuovo["vincoli"] = vincoli
    nuovo["_geometrie_vincoli"] = geometrie_tenute

    # lineari: ferrovie (30 m) e corsi d'acqua (150 m paesagg.)
    el_lineari = []
    ferr, ferr_dism, acque = {}, {}, {}
    boschi = {}
    fascia_ferr = next((v.get("fascia_rispetto_m", 30) for v in carica_kb()["vincoli"]
                        if v["chiave"] == "ferrovia"), 30)
    fascia_idr = next((v.get("fascia_rispetto_m", 150) for v in carica_kb()["vincoli"]
                       if v["chiave"] == "idrico"), 150)
    for e in rep.get("_elementi_lineari") or []:
        g = _geom_way(e)
        if g is None:
            continue
        d = dist_m(g)
        if d is None:
            continue
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            stato, prio = _classifica_distanza(d, fascia_ferr)
            if prio == 2:
                continue
            nome = t.get("operator") or t.get("name") or "linea ferroviaria"
            if nome not in ferr or d < ferr[nome]:
                ferr[nome] = d
            el_lineari.append(e)
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            if d <= max(fascia_ferr, 5):
                nome = t.get("name") or "ex sedime ferroviario"
                ferr_dism[nome] = min(ferr_dism.get(nome, d), d)
                el_lineari.append(e)
        elif t.get("waterway") in {"river", "stream", "canal"}:
            stato, prio = _classifica_distanza(d, fascia_idr)
            if prio == 2:
                continue
            nome_acq = t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"]
            acque[nome_acq] = min(acque.get(nome_acq, d), d)
            el_lineari.append(e)
        elif t.get("natural") == "wood" or t.get("landuse") == "forest":
            # boschi: fascia paesaggistica art.142 lett.g = 150 m come i corsi
            stato, prio = _classifica_distanza(d, 150)
            if prio == 2:
                continue
            nome_b = t.get("name") or "area boscata senza nome"
            boschi[nome_b] = min(boschi.get(nome_b, d), d)
            el_lineari.append(e)
    nuovo["ferrovie"] = sorted(ferr)[:10]
    nuovo["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    nuovo["corsi_acqua"] = sorted(acque)[:15]
    nuovo["boschi"] = sorted(boschi)[:15]
    nuovo["_distanze_lineari"] = {"ferrovie": ferr, "corsi_acqua": acque, "boschi": boschi}
    nuovo["_elementi_lineari"] = el_lineari

    nuovo["warning"].append(
        "Analisi sul TRACCIATO '%s' (buffer %.0f m): le distanze sono misurate in "
        "metri dal tracciato reale (03 INFRASTRUTTURE + pozzetti + armadi) e "
        "confrontate con le fasce di rispetto ufficiali. 'ATTRAVERSAMENTO' = il "
        "tracciato interseca l'ente; 'entro fascia' = ricade nella fascia di rispetto "
        "(l'autorizzazione serve comunque). Le distanze OSM/SITAP hanno accuratezza "
        "posizionale variabile: per gli attraversamenti critici verificare in campo." %
        (nome_tracciato, buffer_m))
    nuovo["enti"] = componi_enti(nuovo)
    return nuovo


def restringi_ad_area(rep, area, nome_area="area di progetto"):
    """Ricalcola il report sull'intersezione con `area` (geometria shapely in
    EPSG:4326, tipicamente l'unione dei poligoni ARLO AREA).

    Richiede un report prodotto con raccogli_geometrie=True: il filtro avviene
    sulle geometrie vere, non sui conteggi. Ritorna un NUOVO report con:
    - rete_stradale: solo i ref con almeno un segmento che interseca l'area
      (ogni voce guadagna 'n_way_area');
    - vincoli: solo quelli che intersecano l'area, con pct ricalcolata
      sull'area (non sul comune);
    - ferrovie/ferrovie_dismesse/corsi_acqua: solo se intersecano l'area;
    - enti: ricomposti sui soli trigger sopravvissuti;
    - le Soprintendenze restano: la competenza è territoriale, non di tracciato.
    Le geometrie raccolte vengono a loro volta filtrate, così i layer caricati
    in mappa mostrano solo ciò che tocca l'area."""
    if "_elementi_strade" not in rep:
        raise ValueError("report senza geometrie: rilancia esegui() con raccogli_geometrie=True")

    nuovo = {k: v for k, v in rep.items()
             if k not in {"rete_stradale", "vincoli", "ferrovie", "ferrovie_dismesse",
                          "corsi_acqua", "boschi", "enti", "warning",
                          "_elementi_strade", "_elementi_lineari", "_geometrie_vincoli"}}
    nuovo["warning"] = list(rep.get("warning", []))
    nuovo["area_progetto"] = {"nome": nome_area}

    def _geom_way(e):
        pts = e.get("geometry")
        if not pts or len(pts) < 2:
            return None
        try:
            from shapely.geometry import LineString
            return LineString([(p["lon"], p["lat"]) for p in pts])
        except Exception:  # noqa: BLE001
            return None

    # strade: tiene il ref se almeno un segmento tocca l'area
    el_strade = []
    refs_in_area = {}
    for e in rep.get("_elementi_strade") or []:
        g = _geom_way(e)
        if g is None or not g.intersects(area):
            continue
        el_strade.append(e)
        parsed = normalizza_ref(e.get("tags", {}).get("ref", ""))
        if parsed:
            refs_in_area.setdefault(parsed[0], {}).setdefault(parsed[1], 0)
            refs_in_area[parsed[0]][parsed[1]] += 1
    rete = {}
    for cls, refs in rep.get("rete_stradale", {}).items():
        tenuti = {}
        for ref, v in refs.items():
            n_area = refs_in_area.get(cls, {}).get(ref, 0)
            if n_area:
                voce = dict(v)
                voce["n_way_area"] = n_area
                tenuti[ref] = voce
        if tenuti:
            rete[cls] = tenuti
    nuovo["rete_stradale"] = rete
    nuovo["_elementi_strade"] = el_strade

    # vincoli: pct ricalcolata sull'area di progetto
    geometrie_tenute = []
    per_etichetta = {}
    for etichetta, f in rep.get("_geometrie_vincoli") or []:
        try:
            from shapely.geometry import shape as _shape
            g = _shape(f["geometry"])
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        if not g.intersects(area):
            continue
        geometrie_tenute.append((etichetta, f))
        rec = per_etichetta.setdefault(etichetta, {"n": 0, "inters": []})
        rec["n"] += 1
        try:
            rec["inters"].append(g.intersection(area))
        except Exception:  # noqa: BLE001
            pass
    vincoli = []
    for v in rep.get("vincoli", []):
        rec = per_etichetta.get(v["etichetta"])
        if not rec:
            continue
        voce = dict(v)
        voce["n_poligoni"] = rec["n"]
        # union delle intersezioni: poligoni sovrapposti non gonfiano l'area
        area_int = 0.0
        if rec["inters"]:
            try:
                from shapely.ops import unary_union
                u = unary_union(rec["inters"])
                if not u.is_valid:
                    u = u.buffer(0)
                area_int = u.area
            except Exception:  # noqa: BLE001
                area_int = max((x.area for x in rec["inters"]), default=0.0)
        voce["pct_territorio"] = round(min(area_int / area.area * 100, 100.0), 1) if area.area else 0.0
        vincoli.append(voce)
    nuovo["vincoli"] = vincoli
    nuovo["_geometrie_vincoli"] = geometrie_tenute

    # lineari
    el_lineari = []
    ferr, ferr_dism, acque = set(), set(), set()
    boschi = set()
    for e in rep.get("_elementi_lineari") or []:
        g = _geom_way(e)
        if g is None or not g.intersects(area):
            continue
        el_lineari.append(e)
        t = e.get("tags", {})
        if t.get("railway") == "rail":
            ferr.add(t.get("operator") or t.get("name") or "linea ferroviaria")
        elif t.get("railway") in {"abandoned", "disused", "razed"}:
            ferr_dism.add(t.get("name") or "ex sedime ferroviario")
        if t.get("waterway") in {"river", "stream", "canal"}:
            acque.add(t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"])
        if t.get("natural") == "wood" or t.get("landuse") == "forest":
            boschi.add(t.get("name") or "area boscata senza nome")
    nuovo["ferrovie"] = sorted(ferr)[:10]
    nuovo["ferrovie_dismesse"] = sorted(ferr_dism)[:10]
    nuovo["corsi_acqua"] = sorted(acque)[:15]
    nuovo["boschi"] = sorted(boschi)[:15]
    nuovo["_elementi_lineari"] = el_lineari

    nuovo["warning"].append(
        "Report ristretto a '%s': strade, vincoli e interferenze sono SOLO quelli "
        "che intersecano l'area; le percentuali dei vincoli sono riferite all'area, "
        "non al territorio comunale. Le fasce di rispetto (30 m ferrovia, 150 m "
        "corsi d'acqua) possono scattare anche per elementi appena FUORI dall'area." % nome_area)
    nuovo["enti"] = componi_enti(nuovo)
    return nuovo


# ---------------------------------------------------------------------------
# Attribuzione ARLO AREA: a ogni strada/vincolo/interferenza la zona che tocca
# ---------------------------------------------------------------------------
def attribuisci_arlo(rep, arlo_zone):
    """Assegna a ogni elemento del report la/le zona/e ARLO che interseca.

    `arlo_zone` = [(label, shapely_geom in EPSG:4326)] una per poligono ARLO.
    Aggiunge il campo 'arlo' (stringa, zone separate da ', ') a:
      - ogni voce di rep['rete_stradale'][cls][ref]  (via geometrie _elementi_strade)
      - ogni voce di rep['vincoli']                   (via _geometrie_vincoli)
      - rep['_arlo_ferrovie'] / ['_arlo_corsi'] per le interferenze lineari
    Non altera la logica degli enti: è puramente attributiva per il report.
    Modifica rep in-place e lo ritorna.
    """
    if not arlo_zone:
        return rep
    from shapely.geometry import LineString, shape as _shape

    def _zone_di(geom):
        """Etichette ARLO che intersecano una geometria (shapely, WGS84)."""
        if geom is None:
            return []
        out = []
        for lab, z in arlo_zone:
            try:
                if geom.intersects(z):
                    out.append(lab)
            except Exception:  # noqa: BLE001
                continue
        return out

    def _geom_way(e):
        pts = e.get("geometry")
        if not pts or len(pts) < 2:
            return None
        try:
            return LineString([(p["lon"], p["lat"]) for p in pts])
        except Exception:  # noqa: BLE001
            return None

    # tracciato di progetto (se presente): l'ARLO di una strada = le zone dove il
    # tracciato di scavo ricade ENTRO LA FASCIA DI RISPETTO di quella strada
    # (affiancamento/attraversamento), non dove passa la sola geometria OSM (che
    # sovrastima). La fascia dipende dalla classe (SP/SS/... da kb). Bufferizzo il
    # tracciato per fascia, con cache per non ricalcolare.
    _tracc = None
    if rep.get("_tracciato_wgs"):
        try:
            from shapely import wkt as _wktmod
            _tracc = _wktmod.loads(rep["_tracciato_wgs"])
        except Exception:  # noqa: BLE001
            _tracc = None
    _buf_cache = {}   # fascia_m -> tracciato bufferizzato (gradi)

    def _tracc_buf(fascia_m):
        if _tracc is None:
            return None
        key = round(fascia_m, 1)
        if key not in _buf_cache:
            try:
                _buf_cache[key] = _tracc.buffer(max(fascia_m, 5) / 111320.0)
            except Exception:  # noqa: BLE001
                _buf_cache[key] = None
        return _buf_cache[key]

    def _fascia_classe(cls):
        sc = scheda_strada(cls) or {}
        try:
            return float(sc.get("fascia_rispetto_m") or 30)
        except Exception:  # noqa: BLE001
            return 30.0

    # strade: raccogli le zone per ref (una way può stare in più ARLO)
    zone_per_ref = {}       # (cls,ref) -> set(label)
    for e in rep.get("_elementi_strade") or []:
        parsed = normalizza_ref(e.get("tags", {}).get("ref", ""))
        if not parsed:
            continue
        g_strada = _geom_way(e)
        if g_strada is None:
            continue
        # zona = dove la strada ricade nella fascia di rispetto attorno al
        # tracciato (= dove lo scavo è entro fascia di quella strada). Se non ho
        # il tracciato, ripiego sulla geometria della strada (comportamento pieno).
        g_valuta = g_strada
        tb = _tracc_buf(_fascia_classe(parsed[0]))
        if tb is not None:
            try:
                inter = g_strada.intersection(tb)
                if inter.is_empty:
                    continue   # lo scavo non è entro fascia di questa strada: niente ARLO
                g_valuta = inter
            except Exception:  # noqa: BLE001
                g_valuta = g_strada
        z = _zone_di(g_valuta)
        if z:
            zone_per_ref.setdefault(parsed, set()).update(z)
    for cls, refs in rep.get("rete_stradale", {}).items():
        for ref, v in refs.items():
            zz = zone_per_ref.get((cls, ref))
            if zz:
                v["arlo"] = ", ".join(sorted(zz))
    # anche le strade solo-OSM / non-misurate ricevono l'attribuzione ARLO:
    # senza questo il Riepilogo le mostrava con la colonna ARLO vuota pur
    # toccando le zone (Stornarella SP88 tocca ARLO 206/208 ma restava "—").
    for chiave in ("rete_stradale_fuori", "rete_stradale_solo_osm",
                   "rete_stradale_non_misurate"):
        for cls, refs in (rep.get(chiave) or {}).items():
            for ref, v in refs.items():
                zz = zone_per_ref.get((cls, ref))
                if zz:
                    v["arlo"] = ", ".join(sorted(zz))

    # vincoli: zone per etichetta vincolo
    zone_per_vinc = {}      # etichetta -> set(label)
    for etichetta, f in rep.get("_geometrie_vincoli") or []:
        try:
            g = _shape(f["geometry"])
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        z = _zone_di(g)
        if z:
            zone_per_vinc.setdefault(etichetta, set()).update(z)
    for v in rep.get("vincoli", []):
        zz = zone_per_vinc.get(v["etichetta"])
        if zz:
            v["arlo"] = ", ".join(sorted(zz))

    # interferenze lineari: zone per nome ferrovia/corso d'acqua
    zf, za = {}, {}
    for e in rep.get("_elementi_lineari") or []:
        t = e.get("tags", {})
        z = _zone_di(_geom_way(e))
        if not z:
            continue
        if t.get("railway") == "rail":
            nome = t.get("operator") or t.get("name") or "linea ferroviaria"
            zf.setdefault(nome, set()).update(z)
        elif t.get("waterway") in {"river", "stream", "canal"}:
            nome = t.get("name") or "corso d'acqua senza nome (%s)" % t["waterway"]
            za.setdefault(nome, set()).update(z)
    rep["_arlo_ferrovie"] = {k: ", ".join(sorted(v)) for k, v in zf.items()}
    rep["_arlo_corsi"] = {k: ", ".join(sorted(v)) for k, v in za.items()}
    rep["_arlo_zone_nomi"] = [lab for lab, _ in arlo_zone]

    # mappa INVERSA zona -> elementi che vi ricadono (per il foglio ARLO Area)
    dett = {lab: {"strade": [], "vincoli": [], "ferrovie": [], "corsi": []}
            for lab, _ in arlo_zone}
    for cls, refs in rep.get("rete_stradale", {}).items():
        for ref, v in refs.items():
            for lab in (v.get("arlo") or "").split(", "):
                if lab in dett:
                    stato = v.get("stato") or ""
                    dett[lab]["strade"].append((ref, cls, stato))
    for v in rep.get("vincoli", []):
        for lab in (v.get("arlo") or "").split(", "):
            if lab in dett:
                dett[lab]["vincoli"].append(v["etichetta"])
    for nome, labs in zf.items():
        for lab in labs:
            if lab in dett:
                dett[lab]["ferrovie"].append(nome)
    for nome, labs in za.items():
        for lab in labs:
            if lab in dett:
                dett[lab]["corsi"].append(nome)
    rep["_arlo_dettaglio"] = dett
    return rep


# ---------------------------------------------------------------------------
# Export XLSX degli enti da interpellare
# ---------------------------------------------------------------------------
def esporta_xlsx(rep, percorso, nome_area=None):
    """Scrive il report enti in un .xlsx (openpyxl, incluso in QGIS).

    Foglio 1 'Enti da interpellare': una riga per ente con ruolo, trigger,
    titolo richiesto, norme, PEC, documentazione e criticità.
    Foglio 2 'Strade classificate': una riga per strada (ref) con classe,
    gestore, denominazioni e segmenti.
    Foglio 3 'Vincoli e fonti': i vincoli intercettati e la tabella di
    provenienza/confidenza. Il disclaimer sta nella prima riga del foglio 1."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    KB = carica_kb()
    wb = Workbook()

    # ---- palette e stili condivisi (coerenti su tutti i fogli) ----
    VERDE = "2E5A34"; VERDE_CH = "6E8B4A"; ZEBRA = "EEF3E7"; GRIGIO = "F2F2F2"
    testa_font = Font(bold=True, color="FFFFFF", size=11)
    testa_fill = PatternFill("solid", fgColor=VERDE)
    sez_font = Font(bold=True, color="FFFFFF", size=11)
    sez_fill = PatternFill("solid", fgColor=VERDE_CH)
    zebra_fill = PatternFill("solid", fgColor=ZEBRA)
    a_capo = Alignment(wrap_text=True, vertical="top")
    centro = Alignment(horizontal="center", vertical="center", wrap_text=True)
    _thin = Side(style="thin", color="C8D2BC")
    bordo = Border(left=_thin, right=_thin, top=_thin, bottom=_thin)

    def _intesta(ws, colonne, larghezze, riga=1):
        """Scrive una riga di intestazione stilizzata."""
        for j, nome in enumerate(colonne, 1):
            c = ws.cell(row=riga, column=j, value=nome)
            c.font = testa_font; c.fill = testa_fill
            c.alignment = centro; c.border = bordo
        for j, larg in enumerate(larghezze, 1):
            ws.column_dimensions[get_column_letter(j)].width = larg
        ws.row_dimensions[riga].height = 26

    def _stila_corpo(ws, r0, ncol, zebra=True):
        """Applica bordi, wrap e zebra alle righe dati da r0 a fine."""
        for i, row in enumerate(ws.iter_rows(min_row=r0, max_col=ncol)):
            for cell in row:
                cell.alignment = a_capo; cell.border = bordo
            if zebra and i % 2 == 1:
                for cell in row:
                    if cell.fill.fgColor.rgb in (None, "00000000"):
                        cell.fill = zebra_fill

    # ══ foglio 1: enti da interpellare ══
    ws = wb.active
    ws.title = "Enti da interpellare"
    c = rep.get("comune", {})
    titolo = "Screening scavi su suolo pubblico — %s (%s)" % (c.get("nome"), c.get("provincia") or "n/d")
    if nome_area:
        titolo += " — ambito: %s" % nome_area
    colonne = ["#", "Ente", "Ruolo", "Trigger", "Titolo richiesto",
               "Riferimenti", "PEC / contatti", "Documentazione tipica",
               "Criticità note", "Nota competenza"]
    larg = [4, 32, 26, 26, 30, 18, 28, 42, 42, 44]
    # riga titolo + riga disclaimer, fuse su tutta la larghezza
    ncol = len(colonne)
    ws.append([titolo])
    ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol)
    ws["A1"].font = Font(bold=True, size=14, color=VERDE)
    ws["A1"].alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 30
    ws.append(["PRE-ISTRUTTORIA (non certificazione). " + KB["meta"]["disclaimer"].strip().replace("\n", " ")])
    ws.merge_cells(start_row=2, start_column=1, end_row=2, end_column=ncol)
    ws["A2"].alignment = a_capo
    ws["A2"].font = Font(italic=True, size=9, color="7A7A7A")
    ws.row_dimensions[2].height = 40
    ws.append([])
    _intesta(ws, colonne, larg, riga=4)
    for n, e in enumerate(rep.get("enti", []), 1):
        sc = e.get("scheda") or {}
        norme = ", ".join(KB["norme"][x]["id"] for x in sc.get("norme", []) if x in KB["norme"])
        contatti = e.get("contatti") or {}
        pec = "\n".join(filter(None, [contatti.get("pec"), contatti.get("sito")]))
        ws.append([n, e.get("ente"), e.get("ruolo"), e.get("trigger"),
                   sc.get("titolo_richiesto") or "", norme, pec,
                   "\n".join("• %s" % d for d in sc.get("documentazione_tipica", [])),
                   "\n".join("• %s" % d for d in sc.get("criticita", [])),
                   e.get("nota_competenza") or ""])
        ws.cell(row=ws.max_row, column=1).alignment = centro
    _stila_corpo(ws, 5, ncol)
    ws.freeze_panes = "A5"

    # ══ foglio 2: strade classificate ══
    ws2 = wb.create_sheet("Strade classificate")
    etich = {"A": "Autostrada", "RA": "Raccordo", "NSA": "Nuova strada ANAS",
             "SS": "Statale", "SR": "Regionale", "SP": "Provinciale", "SC": "Comunale class."}
    sf = rep.get("stradario_fonte")
    modo_tracc = (rep.get("area_progetto") or {}).get("modalita") == "tracciato"
    ha_arlo = bool(rep.get("_arlo_zone_nomi"))
    colonne2 = ["Ref", "Classe", "Ente competente", "Gestore",
                "Denominazioni", "Segmenti (comune)", "Segmenti nell'area", "Conf. OSM"]
    larg2 = [11, 15, 32, 24, 40, 15, 15, 12]
    if ha_arlo:
        colonne2.append("ARLO AREA")
        larg2.append(22)
    if modo_tracc:
        colonne2 += ["Dist. (m)", "Stato", "Affianc. (m)", "Attrav.", "Fascia (m)"]
        larg2 += [11, 28, 13, 10, 11]
    ncol2 = len(colonne2)
    # riga fonte in testa (spiega da dove vengono le strade)
    if sf:
        nota_fonte = "Fonte primaria: %s%s. Colonna 'Conf. OSM' = confermata dai dati OpenStreetMap." % (
            sf["nome"], " (indipendente da OSM)" if sf.get("indipendente") else " — estratto OSM")
    else:
        nota_fonte = ("Fonte: OpenStreetMap (nessuno stradario di riferimento nel progetto). "
                      "OSM NON è autoritativo: classe ed ente vanno confermati presso il gestore.")
    ws2.append([nota_fonte])
    ws2.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncol2)
    ws2["A1"].alignment = a_capo
    ws2["A1"].font = Font(italic=True, size=9, color="7A7A7A")
    ws2.row_dimensions[1].height = 30
    _intesta(ws2, colonne2, larg2, riga=2)

    regione_cc = (rep.get("comune") or {}).get("regione") or ""

    def _riga_strada(cls, ref, v, conf, dati_tracc=True):
        # gestore: prima l'operator OSM; se assente, il gestore regionale
        # probabile per SR/SS (suggerimento da confermare, marcato con ~)
        gest = ", ".join(v.get("operator", []))
        if not gest and cls in ("SR", "SS"):
            gr, _nota = gestore_regionale(cls, regione_cc)
            if gr:
                gest = "~ %s (da confermare)" % gr
        riga = [ref, etich.get(cls, cls), (scheda_strada(cls) or {}).get("ente_tipo") or "",
                gest or "—",
                "; ".join(v.get("nomi", [])) or "—",
                v.get("n_way"), v.get("n_way_area", ""), conf]
        if ha_arlo:
            riga.append(v.get("arlo") or "—")
        if modo_tracc:
            if dati_tracc:
                riga += [v.get("distanza_m", ""), v.get("stato", ""),
                         v.get("affiancamento_m", ""), v.get("attraversamenti", ""),
                         v.get("fascia_m", "")]
            else:
                riga += ["", "", "", "", ""]
        return riga

    n_scritte = 0
    for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
        for ref, v in rep.get("rete_stradale", {}).get(cls, {}).items():
            conf = ("sì" if v.get("confermato_osm") else "NO — verificare") if sf else "(fonte OSM)"
            ws2.append(_riga_strada(cls, ref, v, conf))
            n_scritte += 1
    # strade presenti solo in OSM (non nello stradario): i dati sul tracciato
    # (distanza/affiancamento/attraversamenti) sono comunque stati calcolati da
    # analizza_su_tracciato e vanno MOSTRATI — così un affiancamento longitudinale
    # su una SP/SR presente solo in OSM non resta invisibile solo perché lo
    # stradario locale non la copre.
    for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
        for ref, v in (rep.get("rete_stradale_solo_osm") or {}).get(cls, {}).items():
            ha_dati = v.get("distanza_m") is not None
            ws2.append(_riga_strada(cls, ref, v, "solo OSM — non nello stradario",
                                    dati_tracc=ha_dati))
            n_scritte += 1
    # strade classificate ma NON misurate (geometria assente in OSM in questo
    # run): non sappiamo se il tracciato le affianca — vanno evidenziate come
    # verifica manuale aperta, non nascoste.
    non_mis = rep.get("rete_stradale_non_misurate") or {}
    if non_mis:
        r_sez = ws2.max_row + 1
        ws2.cell(row=r_sez, column=1,
                 value="Strade classificate NON misurate (geometria assente in OSM in questo run): "
                       "verificare a mano un eventuale affiancamento longitudinale del tracciato")
        ws2.merge_cells(start_row=r_sez, start_column=1, end_row=r_sez, end_column=ncol2)
        cc = ws2.cell(row=r_sez, column=1)
        cc.font = Font(bold=True, color="B00000"); cc.fill = sez_fill; cc.alignment = a_capo
        for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
            for ref, v in non_mis.get(cls, {}).items():
                conf = ("—") if sf else "(fonte OSM)"
                ws2.append(_riga_strada(cls, ref, v, conf, dati_tracc=True))
                n_scritte += 1
    # strade classificate del comune FUORI fascia dal tracciato (informative):
    # così il foglio non è mai vuoto quando comunque esistono strade nel comune
    fuori = rep.get("rete_stradale_fuori") or {}
    if fuori:
        r_sez = ws2.max_row + 1
        ws2.cell(row=r_sez, column=1,
                 value="Strade classificate nel comune ma FUORI fascia dal tracciato (nessun obbligo, a titolo informativo)")
        ws2.merge_cells(start_row=r_sez, start_column=1, end_row=r_sez, end_column=ncol2)
        cc = ws2.cell(row=r_sez, column=1); cc.font = sez_font; cc.fill = sez_fill; cc.alignment = a_capo
        for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
            for ref, v in fuori.get(cls, {}).items():
                conf = ("sì" if v.get("confermato_osm") else "—") if sf else "(fonte OSM)"
                ws2.append(_riga_strada(cls, ref, v, conf))
    # foglio mai muto: se non c'è NESSUNA strada, spiega il perché reale
    if n_scritte == 0 and not fuori:
        r = ws2.max_row + 1
        st = rep.get("rete_stradale") or {}
        errore_rete = any(f.get("errore") for f in rep.get("fonti", [])
                          if f.get("stadio") == "rete stradale")
        if errore_rete:
            msg = ("NESSUNA strada rilevata perché la fonte OSM/Overpass non era "
                   "raggiungibile in questo run (non è un'assenza di strade). "
                   "Rilancia lo screening, oppure carica uno stradario (DBSN/regionale) "
                   "nel progetto e attivalo nella scheda: le strade verranno da lì.")
        else:
            msg = ("Nessuna strada classificata (SS/SP/SR/A) interseca il tracciato. "
                   "Le strade comunali non classificate non sono conteggiate qui: "
                   "l'interlocutore per quelle è comunque il Comune (foglio 1).")
        ws2.cell(row=r, column=1, value="⚠ " + msg)
        ws2.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol2)
        ws2.cell(row=r, column=1).alignment = a_capo
        ws2.cell(row=r, column=1).font = Font(bold=True, color="B00000")
        ws2.row_dimensions[r].height = 60
    _stila_corpo(ws2, 3, ncol2)
    ws2.freeze_panes = "A3"

    # ══ foglio 3: vincoli e fonti ══
    ws3 = wb.create_sheet("Vincoli e fonti")
    larg3 = [58, 22, 46]
    for j, larg in enumerate(larg3, 1):
        ws3.column_dimensions[get_column_letter(j)].width = larg

    def _sezione(ws, testo, ncol=3):
        r = ws.max_row + 1 if ws.max_row > 1 or ws.cell(1, 1).value else 1
        ws.cell(row=r, column=1, value=testo)
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncol)
        cc = ws.cell(row=r, column=1); cc.font = sez_font; cc.fill = sez_fill
        cc.alignment = Alignment(vertical="center", wrap_text=True)
        ws.row_dimensions[r].height = 22
        return r

    def _testa3(ws, colonne):
        r = ws.max_row + 1
        for j, nome in enumerate(colonne, 1):
            c = ws.cell(row=r, column=j, value=nome)
            c.font = testa_font; c.fill = testa_fill; c.alignment = centro; c.border = bordo
        return r

    # -- sezione A: vincoli paesaggistici (SITAP + geoportali regionali) --
    _sezione(ws3, "1) Vincoli paesaggistici e ambientali")
    # colonna 'Shape' = c'è un poligono in mappa (riscontro visivo) o no
    col_a = ["Vincolo", "Poligoni intersecanti", "% territorio di riferimento", "Riscontro shape"]
    if ha_arlo:
        col_a.append("ARLO AREA")
        ws3.column_dimensions[get_column_letter(5)].width = 24
    ws3.column_dimensions[get_column_letter(4)].width = 16
    r0 = _testa3(ws3, col_a)
    # etichette che hanno una geometria raccolta (=> generano shape)
    etich_con_shape = {str(et) for et, f in (rep.get("_geometrie_vincoli") or [])}
    # aggiungo anche natura2000/parchi (che sono in _geometrie_vincoli con prefissi)
    righe_vinc = []
    for v in rep.get("vincoli", []):
        has_shape = any(str(v["etichetta"]) in e or e in str(v["etichetta"]) for e in etich_con_shape)
        righe_vinc.append((v["etichetta"], v["n_poligoni"], "%.1f%%" % v["pct_territorio"],
                           "SÌ" if has_shape else "NO", v.get("arlo") or "—"))
    # Natura 2000 come vincolo (ha shape dedicato)
    for s in rep.get("natura2000", []):
        righe_vinc.append(("Rete Natura 2000: %s %s" % (s["codice"], s["nome"]),
                           1, "—", "SÌ", "—"))
    # parchi
    for p in rep.get("parchi", []):
        righe_vinc.append(("Area protetta: %s" % p["nome"], 1, "—", "SÌ", "—"))
    if righe_vinc:
        for et, npol, pct, shp, arlo in righe_vinc:
            riga = [et, npol, pct, shp]
            if ha_arlo:
                riga.append(arlo)
            ws3.append(riga)
    else:
        ws3.append(["Nessun vincolo paesaggistico intercettato (l'art. 142 vale anche se non cartografato)", "", "", "NO"])
    r_end = ws3.max_row
    for row in ws3.iter_rows(min_row=r0 + 1, max_row=r_end, max_col=len(col_a)):
        for cell in row:
            cell.alignment = a_capo; cell.border = bordo
    # evidenzia in rosso le righe con 'NO' shape (nessun riscontro visivo)
    col_shape = 4
    for r in range(r0 + 1, r_end + 1):
        cc = ws3.cell(row=r, column=col_shape)
        if str(cc.value).strip() == "NO":
            cc.font = Font(bold=True, color="C00000")
        elif str(cc.value).strip() == "SÌ":
            cc.font = Font(bold=True, color="107C10")

    # -- sezione B: interferenze lineari e rischio --
    _sezione(ws3, "2) Interferenze lineari e pericolosità")
    col_b = ["Elemento", "Quantità", "Dettaglio / fonte"]
    if ha_arlo:
        col_b.append("ARLO AREA")
    rb = _testa3(ws3, col_b)
    af = rep.get("_arlo_ferrovie") or {}
    ac = rep.get("_arlo_corsi") or {}
    righe_b = []
    if rep.get("ferrovie"):
        arlo_f = ", ".join(sorted({af[n] for n in rep["ferrovie"] if af.get(n)}))
        righe_b.append(["Ferrovie attive (fascia 30 m, DPR 753/1980)", len(rep["ferrovie"]), ", ".join(rep["ferrovie"]), arlo_f or "—"])
    if rep.get("ferrovie_dismesse"):
        righe_b.append(["Ex sedimi ferroviari (nulla osta proprietario)", len(rep["ferrovie_dismesse"]), ", ".join(rep["ferrovie_dismesse"]), "—"])
    if rep.get("corsi_acqua"):
        arlo_c = ", ".join(sorted({ac[n] for n in rep["corsi_acqua"] if ac.get(n)}))
        righe_b.append(["Corsi d'acqua", len(rep["corsi_acqua"]), ", ".join(rep["corsi_acqua"][:8]), arlo_c or "—"])
    if rep.get("boschi"):
        righe_b.append(["Aree boscate (vincolo paesaggistico art. 142 lett. g)",
                        len(rep["boschi"]), ", ".join(rep["boschi"][:8]), "—"])
    idg = rep.get("idrogeologico")
    if idg:
        idr = idg["idraulica"]; fr = idg["frane"]
        righe_b.append(["Pericolosità idraulica P3 elevata", "%.1f%%" % idr["P3_elevata_pct"], "ISPRA IdroGEO — PGRA (% comune)", "intero comune"])
        righe_b.append(["Pericolosità idraulica P2 media", "%.1f%%" % idr["P2_media_pct"], "ISPRA IdroGEO — PGRA (% comune)", "intero comune"])
        righe_b.append(["Pericolosità da frana P3+P4", "%.1f%%" % fr["P3P4_pct"], "ISPRA IdroGEO — PAI (% comune)", "intero comune"])
    if not righe_b:
        righe_b.append(["Nessuna interferenza lineare rilevata in OSM (non probante — verificare CTR/RFI/reticolo)", "", "", ""])
    for rg in righe_b:
        ws3.append(rg if ha_arlo else rg[:3])
    for row in ws3.iter_rows(min_row=rb + 1, max_row=ws3.max_row, max_col=len(col_b)):
        for cell in row:
            cell.alignment = a_capo; cell.border = bordo

    # -- sezione C: provenienza e affidabilità dei dati --
    _sezione(ws3, "3) Fonti dei dati e affidabilità")
    rc = _testa3(ws3, ["Stadio", "Fonte", "Confidenza / errore"])
    for f in rep.get("fonti", []):
        ws3.append([f["stadio"], f["fonte"],
                    f["confidenza"] + ((" — " + f["errore"]) if f.get("errore") else "")])
    for row in ws3.iter_rows(min_row=rc + 1, max_row=ws3.max_row, max_col=3):
        for cell in row:
            cell.alignment = a_capo; cell.border = bordo

    # -- sezione D: avvertenze --
    if rep.get("warning"):
        _sezione(ws3, "4) Avvertenze e limiti (leggere prima di usare il report)")
        for w in rep.get("warning", []):
            r = ws3.max_row + 1
            ws3.cell(row=r, column=1, value="⚠ " + w)
            ws3.merge_cells(start_row=r, start_column=1, end_row=r, end_column=3)
            cell = ws3.cell(row=r, column=1)
            cell.alignment = a_capo; cell.font = Font(size=9, color="8A6D00")
    ws3.freeze_panes = "A1"

    # ══ foglio 4: Riepilogo (tabella piatta, una riga per ente/interferenza) ══
    # stile "Candia": Comune | Provincia | Regione | Ente | AREA ARMADIO | n° ARLO
    if rep.get("_arlo_zone_nomi"):
        wsr = wb.create_sheet("Riepilogo")
        col_r = ["Comune", "Provincia", "Regione", "Ente", "AREA ARMADIO", "n° ARLO"]
        larg_r = [24, 16, 16, 58, 18, 10]
        _intesta(wsr, col_r, larg_r, riga=1)
        cc = rep.get("comune", {})
        comune = (cc.get("nome") or "").split("/")[0].strip()
        provincia = cc.get("provincia") or ""
        regione = cc.get("regione") or ""
        etich_cls = {"A": "Autostrada", "RA": "Raccordo", "NSA": "NSA",
                     "SS": "Statale", "SR": "Regionale", "SP": "Provinciale", "SC": "Comunale"}

        def _aree_armadio(labels):
            """Codice area armadio dal suffisso della Label ARLO (es. 387-04 -> 04)."""
            aree = set()
            for lab in labels:
                if "-" in lab:
                    suf = lab.rsplit("-", 1)[-1].strip()
                    if suf.isdigit():
                        aree.add(suf)
            return sorted(aree)

        def _labels(arlo_str):
            return [x for x in (arlo_str or "").split(", ") if x and x != "—"]

        righe = []   # (ente_descr, [arlo labels])
        # Comune: sempre coinvolto, copre tutte le zone del progetto
        tutte_zone = list(rep["_arlo_zone_nomi"])
        # strade classificate: UNISCI rete primaria + solo-OSM + non-misurate,
        # altrimenti le strade presenti solo in OSM (SP/SS non nello stradario)
        # sparivano dal Riepilogo pur essendo enti da interpellare (stesso bug
        # gia' corretto in componi_enti: Stornarella SP81/SP88 solo-OSM).
        reti_str = {}
        for chiave in ("rete_stradale", "rete_stradale_solo_osm",
                       "rete_stradale_non_misurate"):
            for cls, refs in (rep.get(chiave) or {}).items():
                reti_str.setdefault(cls, {})
                for ref, v in refs.items():
                    reti_str[cls].setdefault(ref, v)
        # tengo le zone ARLO delle strade per abbinarle alle righe stradali
        arlo_strade = {}   # (cls,ref) -> [labels]
        righe_strade = []
        for cls in ["A", "RA", "NSA", "SS", "SR", "SP", "SC"]:
            for ref, v in reti_str.get(cls, {}).items():
                stato = v.get("stato") or ""
                if str(stato).startswith("fuori fascia"):
                    continue
                ente = (scheda_strada(cls) or {}).get("ente_tipo") or etich_cls.get(cls, cls)
                gest = ", ".join(v.get("operator", []))
                cap = gest or ente
                descr = "%s — %s %s%s" % (cap, etich_cls.get(cls, cls), ref,
                                         " (%s)" % stato if stato else "")
                righe_strade.append((descr, _labels(v.get("arlo"))))
        # ferrovie / corsi d'acqua: zone ARLO se disponibili
        af = rep.get("_arlo_ferrovie") or {}
        ac = rep.get("_arlo_corsi") or {}

        # Il Riepilogo elenca TUTTI gli enti di componi_enti (rep["enti"]): cosi'
        # qualunque ente compaia nel foglio "Enti da interpellare" (Natura 2000,
        # parchi, aree boscate, idrogeologico, bonifica, vincoli paesaggistici…)
        # compare anche qui. Prima veniva ricostruita a mano una lista parziale che
        # ometteva parchi/Natura2000/boschi/idrogeologico (bug segnalato su Letojanni
        # e sul Parco del Gargano). Gli enti areali/comunali coprono tutte le zone.
        righe.append(("Comune di %s — occupazione suolo pubblico" % comune, tutte_zone))
        righe += righe_strade
        ruoli_gia = {"Ente proprietario del suolo pubblico comunale"}
        # aggiungo tutti gli altri enti non-stradali dalla lista completa
        for e in rep.get("enti", []):
            ruolo = e.get("ruolo", "")
            ente = e.get("ente", "")
            # salto Comune (gia' messo) e le strade (gia' messe con le loro zone ARLO)
            if ruolo in ruoli_gia:
                continue
            if any(k in ruolo for k in ("Strada ", "Autostrada", "Raccordo",
                                        "Strada statale", "Strada provinciale",
                                        "Strada regionale", "NSA")):
                continue
            # zone ARLO: ferrovie/corsi hanno mappe dedicate, gli altri vincoli sono
            # areali -> coprono tutto il progetto
            labs = tutte_zone
            trig = e.get("trigger", "")
            # per i corsi d'acqua prova ad abbinare la zona specifica
            for nome, zz in ac.items():
                if nome and nome in trig:
                    labs = _labels(zz) or tutte_zone
                    break
            descr = "%s — %s" % (ente, ruolo) if ente and ente not in ruolo else ruolo
            righe.append((descr, labs))

        for descr, labs in righe:
            aree = _aree_armadio(labs)
            wsr.append([comune, provincia, regione, descr,
                        ", ".join(aree) if aree else "—",
                        len(set(labs)) if labs else 0])
        _stila_corpo(wsr, 2, len(col_r))
        wsr.freeze_panes = "A2"

    # ══ foglio: Fonti e affidabilità (statico — descrive le fonti dello strumento) ══
    wsf = wb.create_sheet("Fonti e affidabilità")
    wsf.merge_cells("A1:H1")
    cf = wsf["A1"]
    cf.value = "Screening scavi su suolo pubblico — Fonti dei dati e affidabilità"
    cf.font = Font(bold=True, color="FFFFFF", size=12)
    cf.fill = testa_fill
    cf.alignment = Alignment(horizontal="left", vertical="center")
    wsf.row_dimensions[1].height = 24
    wsf.merge_cells("A2:H2")
    cf2 = wsf["A2"]
    cf2.value = ("Pre-istruttoria, non certificazione. Ogni fonte porta il proprio livello di confidenza. "
                 "Il valore autoritativo pieno è solo su ISPRA IdroGEO; strade e vincoli vanno confermati "
                 "presso l'ente competente.")
    cf2.font = Font(italic=True, size=9, color="7A7A7A")
    cf2.alignment = a_capo
    wsf.row_dimensions[2].height = 30
    col_f = ["#", "Cosa fornisce", "Fonte", "Endpoint / origine", "Tipo",
             "Autoritativa", "Confidenza", "Note"]
    larg_f = [4, 28, 26, 30, 16, 15, 14, 40]
    _intesta(wsf, col_f, larg_f, riga=3)
    righe_f = [
        [1, "Pericolosità idrogeologica (frane PAI + alluvioni PGRA)",
         "ISPRA IdroGEO — API REST ufficiale", "idrogeo.isprambiente.it/api/pir/comuni",
         "Istituzionale nazionale", "SÌ", "alta",
         "Unica fonte marcata autoritativa nel codice. Dato per comune ISTAT."],
        [2, "Vincoli paesaggistici (art. 136 decretati; art. 142 fasce/boschi/coste; parchi; zone umide; UNESCO)",
         "SITAP — Ministero della Cultura (WFS)", "sitap.cultura.gov.it/geoserver/wfs",
         "Ministeriale", "Parziale", "media",
         "Perimetrazioni con accuratezza variabile. I vincoli ex lege art.142 valgono anche se non cartografati."],
        [3, "Soprintendenze ABAP competenti + PEC",
         "SITAP — MiC (WFS)", "sitap.cultura.gov.it/geoserver/wfs",
         "Ministeriale", "Parziale", "bassa",
         "Copertura del servizio incompleta; verificare la Soprintendenza territoriale."],
        [4, "Confine comunale + geocoding (ISTAT, regione, popolazione)",
         "Nominatim (OpenStreetMap)", "nominatim.openstreetmap.org/search",
         "Comunitaria", "NO", "media",
         "Usato per localizzare il comune e ricavare i dati anagrafici territoriali."],
        [5, "Rete stradale (SS/SP/SR/A, denominazioni, gestore)",
         "OpenStreetMap via Overpass", "overpass-api.de (+ 3 mirror di fallback)",
         "Comunitaria", "NO", "media",
         "OSM non è autoritativo: classe ed ente vanno confermati presso il gestore."],
        [6, "Interferenze lineari (corsi d'acqua, ferrovie attive/dismesse)",
         "OpenStreetMap via Overpass", "overpass-api.de (+ 3 mirror)",
         "Comunitaria", "NO", "media",
         "Copertura variabile; i corsi d'acqua demaniali possono non avere denominazione."],
        [7, "Rete stradale — fonte primaria opzionale",
         "Stradario caricato nel progetto (DBSN/regionale)", "layer locale del progetto QGIS",
         "Dipende dal layer", "SÌ se DBSN/IGM", "alta se indip.",
         "Se carichi il DBSN le strade passano da OSM (media) a fonte primaria (alta)."],
        [8, "Gestori regionali SR/SS (ASTRAL, Veneto Strade, FVG Strade, ...)",
         "Knowledge base interna del plugin", "procedimenti.yaml (file locale)",
         "Curata a mano", "Suggerimento", "da confermare",
         "Proposto solo quando OSM non porta il tag operator. Da verificare presso l'ente."],
    ]
    for riga in righe_f:
        wsf.append(riga)
    _stila_corpo(wsf, 4, len(col_f))
    # colora Autoritativa e Confidenza per lettura a colpo d'occhio
    for r in range(4, 4 + len(righe_f)):
        ac = wsf.cell(row=r, column=6); va = str(ac.value or "")
        if va.startswith("SÌ"):
            ac.font = Font(bold=True, color="2E7D32")
        elif va == "NO":
            ac.font = Font(bold=True, color="B00000")
        else:
            ac.font = Font(bold=True, color="B8860B")
        cc = wsf.cell(row=r, column=7); vc = str(cc.value or "").lower()
        if vc.startswith("alta"):
            cc.font = Font(bold=True, color="2E7D32")
        elif vc.startswith("media"):
            cc.font = Font(color="B8860B")
        elif vc.startswith("bassa"):
            cc.font = Font(color="B00000")
        wsf.row_dimensions[r].height = 46
    rlf = 4 + len(righe_f) + 1
    wsf.merge_cells(start_row=rlf, start_column=1, end_row=rlf, end_column=8)
    clf = wsf.cell(row=rlf, column=1,
                   value="Legenda — Autoritativa: SÌ = fonte istituzionale su cui fare affidamento · "
                         "Parziale = istituzionale ma da verificare · NO = comunitaria (OSM), da confermare "
                         "presso l'ente.   Confidenza: alta / media / bassa come dichiarata nel report.")
    clf.font = Font(italic=True, size=9, color="7A7A7A"); clf.alignment = a_capo
    wsf.row_dimensions[rlf].height = 30
    wsf.freeze_panes = "A4"

    wb.save(percorso)
    return percorso
