# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Simboli del sinottico nella PL comunale (pulsanti della consegna comunale).

- Colonnina PTE: i punti dello shape ROE PTE con TIPO = «Colonnina» (tutte) o
  solo quelli con NewColoninn = Si/True (solo le nuove) prendono il simbolo
  «PTE a colonnina» del sinottico; in legenda la voce «PTE A COLONNINA».
- Armadi: ogni armadio dello shape ARMADIO OTTICO prende il simbolo della sua
  taglia dal campo FO_USCENTI (128 SMALL, 384 LARGE, 576 EXTRA LARGE); in
  legenda solo le taglie presenti.

Gli stili del progetto cambiano SOLO durante l'esportazione dei PDF e poi
tornano com'erano (il progetto non si salva). Le legende dei layout collegate
ai layer si aggiornano da sole; quelle bloccate a mano ricevono le voci per
l'esportazione e poi tornano come prima.
"""
import os

CARTELLA_SIMBOLI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "simboli")
SVG_PTE_COLONNINA = os.path.join(CARTELLA_SIMBOLI, "pte_colonnina.svg")
SVG_ARMADIO = {128: os.path.join(CARTELLA_SIMBOLI, "armadio_small.svg"),
               384: os.path.join(CARTELLA_SIMBOLI, "armadio_large.svg"),
               576: os.path.join(CARTELLA_SIMBOLI, "armadio_xl.svg")}
TAGLIE = {128: "SMALL", 384: "LARGE", 576: "EXTRA LARGE"}
MODO_TUTTE, MODO_NUOVE, MODO_BASAMENTO = "tutte", "nuove", "basamento"
DIM_SIMBOLO_MM = 4.5
_SI = "IN ('SI', 'SÌ', 'TRUE', '1', 'S', 'YES')"

ESPR_COLONNINA = {
    MODO_TUTTE: "upper(trim(coalesce(\"TIPO\", ''))) = 'COLONNINA'",
    MODO_NUOVE: "upper(trim(coalesce(to_string(\"NewColoninn\"), ''))) " + _SI,
    # scelta dell'utente (2026-11-27): solo le colonnine con NewBasament = Si
    MODO_BASAMENTO: "upper(trim(coalesce(to_string(\"NewBasament\"), ''))) " + _SI,
}
MODO_PREDEFINITO = MODO_BASAMENTO


def _ha_campi(lyr, *nomi):
    try:
        n = {f.name().upper() for f in lyr.fields()}
    except Exception:  # noqa: BLE001
        return False
    return all(x.upper() in n for x in nomi)


def layer_pte(project):
    """Lo shape ROE PTE del progetto (per nome, o dai campi TIPO e NewColoninn)."""
    from qgis.core import QgsVectorLayer
    cand = [l for l in project.mapLayers().values() if isinstance(l, QgsVectorLayer)]
    for l in cand:
        n = l.name().upper()
        if "ROE" in n and "PTE" in n and _ha_campi(l, "TIPO"):
            return l
    return next((l for l in cand if _ha_campi(l, "TIPO", "NewColoninn")), None)


def layer_armadi(project):
    """Lo shape ARMADIO OTTICO del progetto (quello con FO_USCENTI)."""
    from qgis.core import QgsVectorLayer
    cand = [l for l in project.mapLayers().values()
            if isinstance(l, QgsVectorLayer) and _ha_campi(l, "FO_USCENTI")]
    cand.sort(key=lambda l: ("ARMADIO" not in l.name().upper(), l.name()))
    return cand[0] if cand else None


def taglia(valore):
    """128/384/576 da FO_USCENTI (anche testo «384», «384 fo»); None se altro."""
    import re
    try:
        m = re.search(r"\d+", str(valore))
        v = int(m.group(0)) if m else None
    except Exception:  # noqa: BLE001
        v = None
    return v if v in TAGLIE else None


def taglie_presenti(lyr):
    if lyr is None:
        return []
    i = lyr.fields().indexOf("FO_USCENTI")
    if i < 0:
        i = next((k for k, f in enumerate(lyr.fields()) if f.name().upper() == "FO_USCENTI"), -1)
    if i < 0:
        return []
    out = set()
    for f in lyr.getFeatures():
        t = taglia(f.attribute(i))
        if t:
            out.add(t)
    return sorted(out)


def conta(lyr, espr):
    from qgis.core import QgsFeatureRequest
    if lyr is None:
        return 0
    try:
        return sum(1 for _ in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(espr)))
    except Exception:  # noqa: BLE001
        return 0


def _simbolo_svg(path, dim=DIM_SIMBOLO_MM):
    from qgis.core import QgsMarkerSymbol, QgsSvgMarkerSymbolLayer
    sym = QgsMarkerSymbol()
    sym.changeSymbolLayer(0, QgsSvgMarkerSymbolLayer(path, dim, 0))
    return sym


def _renderer_con_regole(orig, regole, resto_serve=True):
    """Renderer a regole: prima le `regole` [(etichetta, espressione,
    simbolo)], poi (se `resto_serve`) lo stile di prima per tutto il resto
    (le sue voci di legenda restano)."""
    from qgis.core import QgsRuleBasedRenderer
    root = QgsRuleBasedRenderer.Rule(None)
    for etich, espr, sym in regole:
        root.appendChild(QgsRuleBasedRenderer.Rule(sym, 0, 0, espr, etich))
    resto = QgsRuleBasedRenderer.Rule(None, 0, 0, "ELSE", "")
    try:
        conv = QgsRuleBasedRenderer.convertFromRenderer(orig.clone()) \
            if (orig and resto_serve) else None
    except Exception:  # noqa: BLE001
        conv = None
    if conv is not None:
        for c in conv.rootRule().children():
            resto.appendChild(c.clone())
        root.appendChild(resto)
    return QgsRuleBasedRenderer(root)


class Simboli:
    """Applica i simboli (colonnina e/o armadi) e li toglie: da usare con
    `with Simboli(project, colonnina=..., armadi=...) as s:` attorno
    all'esportazione. s.righe = cosa è stato fatto (per il registro)."""

    def __init__(self, project, colonnina=None, armadi=False):
        self.project = project
        self.colonnina = colonnina          # None o un MODO_* (di solito MODO_BASAMENTO)
        self.armadi = armadi
        self.righe = []
        self._vecchi = []                   # (layer, renderer di prima)
        self._legende = []                  # (legenda, autoUpdate di prima)

    def __enter__(self):
        try:
            self.applica()
        except Exception as e:  # noqa: BLE001
            self.righe.append("Simboli del sinottico non applicati: %s" % e)
        return self

    def __exit__(self, *_a):
        self.ripristina()
        return False

    def applica(self):
        cambiati = []
        if self.colonnina in ESPR_COLONNINA:
            lyr = layer_pte(self.project)
            espr = ESPR_COLONNINA[self.colonnina]
            n = conta(lyr, espr)
            if lyr is None:
                self.righe.append("Colonnina PTE: nel progetto non c'è lo shape ROE PTE.")
            elif not os.path.isfile(SVG_PTE_COLONNINA):
                self.righe.append("Colonnina PTE: simbolo non trovato nel plugin.")
            else:
                self._metti(lyr, [("PTE A COLONNINA", espr, _simbolo_svg(SVG_PTE_COLONNINA))])
                cambiati.append(lyr)
                self.righe.append("Colonnina PTE: %d %s col simbolo del sinottico (%s)." % (
                    n, "colonnina" if n == 1 else "colonnine",
                    {MODO_NUOVE: "solo NewColoninn = Si",
                     MODO_BASAMENTO: "solo NewBasament = Si"}.get(
                        self.colonnina, "tutte, TIPO = Colonnina")))
        if self.armadi:
            lyr = layer_armadi(self.project)
            pres = taglie_presenti(lyr)
            if lyr is None:
                self.righe.append("Armadi: nel progetto non c'è lo shape ARMADIO OTTICO con "
                                  "FO_USCENTI.")
            elif not pres:
                self.righe.append("Armadi: FO_USCENTI vuoto o diverso da 128/384/576: simboli "
                                  "non cambiati.")
            else:
                campo = next(f.name() for f in lyr.fields() if f.name().upper() == "FO_USCENTI")
                regole = [("ARMADIO OTTICO %s (%d fo)" % (TAGLIE[t], t),
                           "regexp_substr(to_string(\"%s\"), '\\\\d+') = '%d'" % (campo, t),
                           _simbolo_svg(SVG_ARMADIO[t], DIM_SIMBOLO_MM * 1.2))
                          for t in pres if os.path.isfile(SVG_ARMADIO[t])]
                # armadi senza taglia valida: restano con lo stile di prima
                senza = sum(1 for f in lyr.getFeatures() if not taglia(f[campo]))
                self._metti(lyr, regole, resto_serve=senza > 0)
                if senza:
                    self.righe.append("Armadi: %d senza FO_USCENTI 128/384/576, restano con lo "
                                      "stile di prima." % senza)
                cambiati.append(lyr)
                self.righe.append("Armadi: simbolo per taglia (%s)." % ", ".join(
                    "%s %d" % (TAGLIE[t], t) for t in pres))
        if cambiati:
            self._legende_bloccate(cambiati)

    def _metti(self, lyr, regole, resto_serve=True):
        orig = lyr.renderer().clone() if lyr.renderer() else None
        self._vecchi.append((lyr, orig))
        lyr.setRenderer(_renderer_con_regole(orig, regole, resto_serve))
        lyr.triggerRepaint()
        try:
            from qgis.core import QgsProject  # noqa: F401
            lyr.emitStyleChanged()
        except Exception:  # noqa: BLE001
            pass

    def _legende_bloccate(self, layers):
        """Legende dei layout bloccate a mano: per l'esportazione si
        sbloccano (prendono i layer e le voci nuove), poi tornano com'erano."""
        try:
            from qgis.core import QgsLayoutItemLegend
        except Exception:  # noqa: BLE001
            return
        for lay in self.project.layoutManager().layouts():
            for it in lay.items():
                if not isinstance(it, QgsLayoutItemLegend):
                    continue
                try:
                    if it.autoUpdateModel():
                        it.updateLegend()
                        continue
                    root = it.model().rootGroup()
                    stato = root.clone()
                    toccata = False
                    for l in layers:
                        nodo = root.findLayer(l.id())
                        if nodo is None:
                            nodo = root.addLayer(l)       # la voce deve esserci
                        # voci della legenda rifatte dallo stile nuovo
                        nodo.removeCustomProperty("legend/node-order")
                        toccata = True
                    if toccata:
                        self._legende.append((it, stato))
                        it.updateLegend()
                except Exception:  # noqa: BLE001
                    continue

    def ripristina(self):
        for lyr, orig in reversed(self._vecchi):
            try:
                if orig is not None:
                    lyr.setRenderer(orig)
                lyr.triggerRepaint()
                lyr.emitStyleChanged()
            except Exception:  # noqa: BLE001
                pass
        self._vecchi = []
        for it, stato in self._legende:
            try:
                root = it.model().rootGroup()
                root.clear()
                for c in stato.children():
                    root.addChildNode(c.clone())
                it.updateLegend()
            except Exception:  # noqa: BLE001
                pass
        self._legende = []
