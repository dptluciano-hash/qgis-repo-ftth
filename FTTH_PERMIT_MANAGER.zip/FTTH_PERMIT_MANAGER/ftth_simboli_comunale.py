# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Colonnina PTE e armadi nella PL comunale (riquadro «Colonnina PTE e armadi»
della consegna comunale).

- Colonnina PTE: i punti dello shape ROE PTE con NewBasament = Si prendono il
  simbolo «PTE a colonnina» del sinottico, con la voce in legenda; il
  particolare della colonnina entra nella tavola PARTICOLARI COSTRUTTIVI.
- Armadi: ogni armadio dello shape ARMADIO OTTICO prende il simbolo della sua
  taglia dal campo FO_USCENTI (128 SMALL, 384 LARGE, 576 EXTRA LARGE), in
  legenda solo le taglie presenti; i particolari delle taglie presenti entrano
  nella tavola PARTICOLARI COSTRUTTIVI al posto dell'armadio generico (PC-06).

La tavola PARTICOLARI COSTRUTTIVI è l'immagine con id «PARTICOLARI
COSTRUTTIVI» dei layout (file 05_Particolari Costruttivi\\Particolari
Costruttivi-PC.svg del progetto, fatto col compositore): per l'esportazione
se ne fa una copia con i pezzi in più, reimpaginata e centrata nel riquadro.

Tutto vale SOLO durante l'esportazione: stili, legende e immagine tornano
come prima (il progetto non si salva).
"""
import os

CARTELLA_SIMBOLI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "simboli")
SVG_PTE_COLONNINA = os.path.join(CARTELLA_SIMBOLI, "pte_colonnina.svg")
SVG_ARMADIO = {128: os.path.join(CARTELLA_SIMBOLI, "armadio_small.svg"),
               384: os.path.join(CARTELLA_SIMBOLI, "armadio_large.svg"),
               576: os.path.join(CARTELLA_SIMBOLI, "armadio_xl.svg")}
TAGLIE = {128: "SMALL", 384: "LARGE", 576: "EXTRA LARGE"}
MODO_TUTTE, MODO_NUOVE, MODO_BASAMENTO = "tutte", "nuove", "basamento"
DIM_SIMBOLO_MM = 4.5
_SI = "IN ('SI', 'SÌ', 'TRUE', '1', 'S', 'YES')"

ESPR_COLONNINA = {
    MODO_TUTTE: "upper(trim(coalesce(\"TIPO\", ''))) = 'COLONNINA'",
    MODO_NUOVE: "upper(trim(coalesce(to_string(\"NewColoninn\"), ''))) " + _SI,
    # scelta dell'utente (2026-11-27): solo le colonnine con NewBasament = Si
    MODO_BASAMENTO: "upper(trim(coalesce(to_string(\"NewBasament\"), ''))) " + _SI,
}
MODO_PREDEFINITO = MODO_BASAMENTO

ID_PARTICOLARI = "PARTICOLARI COSTRUTTIVI"
PC_ARMADIO_GENERICO = "PC-06"         # armadio ONUCAB del compositore
VERDE_TITOLI = "#2bb24c"


def _ha_campi(lyr, *nomi):
    try:
        n = {f.name().upper() for f in lyr.fields()}
    except Exception:  # noqa: BLE001
        return False
    return all(x.upper() in n for x in nomi)


def layer_pte(project):
    """Lo shape ROE PTE del progetto (per nome, o dai campi TIPO e NewColoninn)."""
    from qgis.core import QgsVectorLayer
    cand = [l for l in project.mapLayers().values() if isinstance(l, QgsVectorLayer)]
    for l in cand:
        n = l.name().upper()
        if "ROE" in n and "PTE" in n and _ha_campi(l, "TIPO"):
            return l
    return next((l for l in cand if _ha_campi(l, "TIPO", "NewColoninn")), None)


def layer_armadi(project):
    """Lo shape ARMADIO OTTICO del progetto (quello con FO_USCENTI)."""
    from qgis.core import QgsVectorLayer
    cand = [l for l in project.mapLayers().values()
            if isinstance(l, QgsVectorLayer) and _ha_campi(l, "FO_USCENTI")]
    cand.sort(key=lambda l: ("ARMADIO" not in l.name().upper(), l.name()))
    return cand[0] if cand else None


def taglia(valore):
    """128/384/576 da FO_USCENTI (anche testo «384», «384 fo»); None se altro."""
    import re
    try:
        m = re.search(r"\d+", str(valore))
        v = int(m.group(0)) if m else None
    except Exception:  # noqa: BLE001
        v = None
    return v if v in TAGLIE else None


def _campo_fo(lyr):
    return next((f.name() for f in lyr.fields() if f.name().upper() == "FO_USCENTI"), None)


def taglie_presenti(lyr):
    if lyr is None or _campo_fo(lyr) is None:
        return []
    c = _campo_fo(lyr)
    return sorted({t for t in (taglia(f[c]) for f in lyr.getFeatures()) if t})


def conta(lyr, espr):
    from qgis.core import QgsFeatureRequest
    if lyr is None:
        return 0
    try:
        return sum(1 for _ in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(espr)))
    except Exception:  # noqa: BLE001
        return 0


DIM_ARMADIO_MM = 7.0      # cupola FO del sinottico (a 5,4 mm si leggeva appena)


def _simbolo_svg(path, dim=None, base_sul_punto=False, espr_angolo=None):
    """Simbolo SVG. `base_sul_punto`: la base della cupola sta sul punto
    dell'armadio (non il centro); `espr_angolo`: rotazione per elemento
    (cupola girata dalla parte opposta allo scavo che arriva all'armadio,
    così scavo e pozzetto restano visibili)."""
    from qgis.core import (QgsMarkerSymbol, QgsMarkerSymbolLayer, QgsProperty,
                           QgsSvgMarkerSymbolLayer, QgsSymbolLayer)
    sl = QgsSvgMarkerSymbolLayer(path, dim or DIM_SIMBOLO_MM, 0)
    if base_sul_punto:
        sl.setVerticalAnchorPoint(QgsMarkerSymbolLayer.Bottom)
        # stacco lungo lo scavo (lo spostamento gira con il simbolo): 0 fino a
        # 1:1500 (la base resta sullo scavo), poi cresce fino a 3 mm
        # (1:5000 ≈ 2,5 mm: libera il pozzetto vicino, che a quella scala
        # sta sotto la cupola)
        sl.setDataDefinedProperty(QgsSymbolLayer.PropertyOffset, QgsProperty.fromExpression(
            "array(0, -min(3, max(0, (coalesce(@map_scale, 1000) - 1500) / 1400.0)))"))
    if espr_angolo:
        sl.setDataDefinedProperty(QgsSymbolLayer.PropertyAngle,
                                  QgsProperty.fromExpression(espr_angolo))
    sym = QgsMarkerSymbol()
    sym.changeSymbolLayer(0, sl)
    return sym


def layer_scavi(project):
    """Le infrastrutture (scavi) del progetto: layer di linee con
    «INFRASTRUTTURE» nel nome (es. «03 INFRASTRUTTURE»)."""
    from qgis.core import QgsVectorLayer, QgsWkbTypes
    cand = [l for l in project.mapLayers().values() if isinstance(l, QgsVectorLayer)
            and l.geometryType() == QgsWkbTypes.LineGeometry
            and "INFRASTRUTTUR" in l.name().upper()]
    cand.sort(key=lambda l: (l.providerType() == "memory", len(l.name())))
    return cand[0] if cand else None


def angoli_armadi(project, arm, scavi, soglia_m=15.0):
    """{id armadio: gradi} — direzione che va dallo scavo verso l'armadio e
    oltre (la cupola si apre da quella parte, la base resta sullo scavo).
    Gli armadi senza scavo vicino non sono nel dizionario (cupola dritta)."""
    import math
    from qgis.core import QgsCoordinateTransform, QgsFeature, QgsGeometry, QgsSpatialIndex
    if arm is None or scavi is None:
        return {}
    from qgis.core import QgsCoordinateReferenceSystem
    crs = project.crs() if (project.crs().isValid() and not project.crs().isGeographic()) \
        else QgsCoordinateReferenceSystem("EPSG:3857")          # metri (anche shape in gradi)
    tr = QgsCoordinateTransform(scavi.crs(), crs, project)
    tra = QgsCoordinateTransform(arm.crs(), crs, project)
    geoms = {}
    for f in scavi.getFeatures():
        if f.hasGeometry():
            g = QgsGeometry(f.geometry())
            g.transform(tr)
            geoms[f.id()] = g
    idx = QgsSpatialIndex()
    for fid, g in geoms.items():
        ff = QgsFeature(fid)
        ff.setGeometry(g)
        idx.addFeature(ff)
    out = {}
    for f in arm.getFeatures():
        if not f.hasGeometry():
            continue
        g = QgsGeometry(f.geometry())
        g.transform(tra)
        a = g.asPoint() if not g.isMultipart() else g.asMultiPoint()[0]
        ga = QgsGeometry.fromPointXY(a)
        vicini = [fid for fid in idx.nearestNeighbor(a, 3) if fid in geoms]
        vicini = [fid for fid in vicini if geoms[fid].distance(ga) <= soglia_m]
        if not vicini:
            continue
        gs = min((geoms[fid] for fid in vicini), key=lambda x: x.distance(ga))
        d0 = gs.lineLocatePoint(gs.nearestPoint(ga))
        passo = min(2.0, gs.length() / 2.0)
        # punto dello scavo poco prima dell'armadio (verso l'interno dello scavo)
        dentro = d0 - passo if d0 >= gs.length() / 2.0 else d0 + passo
        p1 = gs.interpolate(max(0.0, min(gs.length(), dentro))).asPoint()
        dx, dy = a.x() - p1.x(), a.y() - p1.y()
        if abs(dx) + abs(dy) < 1e-6:
            p2 = gs.interpolate(d0).asPoint()
            dx, dy = a.x() - p2.x(), a.y() - p2.y()
        if abs(dx) + abs(dy) < 1e-6:
            continue
        out[f.id()] = (math.degrees(math.atan2(dx, dy)) + 360.0) % 360.0
    return out


def espressione_angoli(angoli):
    """Espressione QGIS che dà a ogni armadio ($id) il suo angolo."""
    if not angoli:
        return None
    coppie = ", ".join("'%d', %.1f" % (k, v) for k, v in sorted(angoli.items()))
    return "coalesce(map_get(map(%s), to_string($id)), 0)" % coppie


def _renderer_con_regole(orig, regole, resto_serve=True, etichetta_resto=""):
    """Renderer a regole: prima le `regole` [(etichetta, espressione,
    simbolo)], poi (se `resto_serve`) lo stile di prima per tutto il resto;
    le sue voci senza nome prendono `etichetta_resto` (il nome del layer, che
    in legenda prima era il titolo)."""
    from qgis.core import QgsRuleBasedRenderer
    root = QgsRuleBasedRenderer.Rule(None)
    for etich, espr, sym in regole:
        root.appendChild(QgsRuleBasedRenderer.Rule(sym, 0, 0, espr, etich))
    resto = QgsRuleBasedRenderer.Rule(None, 0, 0, "ELSE", "")
    try:
        conv = QgsRuleBasedRenderer.convertFromRenderer(orig.clone()) \
            if (orig and resto_serve) else None
    except Exception:  # noqa: BLE001
        conv = None
    if conv is not None:
        for c in conv.rootRule().children():
            c2 = c.clone()
            if not (c2.label() or "").strip():
                c2.setLabel(etichetta_resto)
            resto.appendChild(c2)
        root.appendChild(resto)
    return QgsRuleBasedRenderer(root)


# ---------------------------------------------------------------- particolari
def pezzi_nuovi(colonnina=False, taglie=()):
    """Particolari da aggiungere alla tavola: [(sigla, titolo, file svg)]."""
    try:
        from . import ftth_comunale as CM
    except ImportError:
        import ftth_comunale as CM
    out = []
    for fo in taglie:
        f = CM.file_particolare_armadio(fo)
        if f:
            out.append(("PC-AO%d" % fo, "ARMADIO OTTICO %d fo (%s)" % (fo, TAGLIE[fo]), f))
    if colonnina:
        f = CM.file_particolare_colonnina()
        if f:
            out.append(("PC-20", "PARTICOLARE COLONNINA PTE", f))
    return out


def _svg_xml():
    import xml.etree.ElementTree as ET
    ET.register_namespace("", "http://www.w3.org/2000/svg")
    ET.register_namespace("xlink", "http://www.w3.org/1999/xlink")
    return ET


def _misura_vb(root):
    """(larghezza mm, altezza mm, viewBox) di un <svg>."""
    import re
    vb = [float(v) for v in re.split(r"[ ,]+", (root.get("viewBox") or "").strip()) if v]

    def _mm(v, dflt):
        m = re.match(r"\s*([\d.]+)\s*(mm|cm|px|pt|in)?", v or "")
        if not m:
            return dflt
        k = {"mm": 1.0, "cm": 10.0, "in": 25.4, "pt": 25.4 / 72, None: 25.4 / 96,
             "px": 25.4 / 96}[m.group(2)]
        return float(m.group(1)) * k
    if len(vb) != 4:
        vb = [0, 0, _mm(root.get("width"), 100), _mm(root.get("height"), 100)]
    return _mm(root.get("width"), vb[2]), _mm(root.get("height"), vb[3]), vb


def _pezzo_nuovo(titolo, path, lato=40.0):
    """Gruppo SVG del particolare con il riquadro titolo verde come quelli del
    compositore (titolo a sinistra, «non in scala» in basso a destra), alla
    stessa grandezza dei suoi pezzi. Ritorna (xml, larghezza, altezza) in
    unità della tavola."""
    from xml.sax.saxutils import escape
    ET = _svg_xml()
    root = ET.parse(path).getroot()
    wmm, hmm, vb = _misura_vb(root)
    k = lato / max(wmm, hmm)
    w, h = wmm * k, hmm * k
    fs = 1.45                                   # come i titoli del compositore
    tw = len(titolo) * fs * 0.62 + 3.0
    th = 4.4
    sx, sy = w / vb[2], h / vb[3]
    corpo = "".join(ET.tostring(c, encoding="unicode") for c in root)
    W = max(w, tw)
    g = ('<g><rect x="0" y="0" width="%.2f" height="%.2f" fill="#ffffff" stroke="%s" '
         'stroke-width="0.25"/><line x1="0.6" y1="%.2f" x2="%.2f" y2="%.2f" stroke="#999999" '
         'stroke-width="0.1"/><text x="1.2" y="2.25" font-family="Arial" font-size="%.2f" '
         'font-weight="bold" fill="#000000">%s</text><text x="%.2f" y="%.2f" '
         'font-family="Arial" font-size="0.8" fill="#000000" text-anchor="end">non in scala'
         '</text><g transform="translate(%.3f %.3f) scale(%.5f %.5f) translate(%.3f %.3f)">'
         '%s</g></g>'
         % (tw, th, VERDE_TITOLI, th - 1.3, tw - 0.6, th - 1.3, fs, escape(titolo),
            tw - 0.8, th - 0.35, (W - w) / 2, th + 2.5, sx, sy, -vb[0], -vb[1], corpo))
    return g, W, h + th + 2.5


def componi_particolari(sorgente, uscita, area_w, area_h, nuovi, togli=()):
    """Tavola dei particolari per la PL: i pezzi del file del compositore
    (gruppi PC-xx; `togli` esclusi) più i `nuovi` [(sigla, titolo, svg)],
    reimpaginati nell'area area_w × area_h mm e centrati. Ritorna il numero
    di pezzi, o None se la sorgente non si può ricomporre (non SVG)."""
    from qgis.PyQt.QtSvg import QSvgRenderer
    try:
        from . import ftth_rfi_layout as L
    except ImportError:
        import ftth_rfi_layout as L
    if not sorgente or not sorgente.lower().endswith(".svg") or not os.path.isfile(sorgente):
        return None
    ET = _svg_xml()
    root = ET.parse(sorgente).getroot()
    _w, _h, vb = _misura_vb(root)
    r = QSvgRenderer(sorgente)
    pezzi = {}          # sigla -> (xml, bx, by, bw, bh)
    ordine = []
    for el in root:
        sid = el.get("id") or ""
        if not el.tag.endswith("g") or not sid.upper().startswith("PC-") or sid in togli:
            continue
        b = r.boundsOnElement(sid)
        if b.width() <= 0 or b.height() <= 0:
            continue
        pezzi[sid] = (ET.tostring(el, encoding="unicode"), b.x(), b.y(), b.width(), b.height())
        ordine.append(sid)
    if not pezzi:      # file senza gruppi PC-: tutta la tavola come un pezzo
        corpo = "".join(ET.tostring(c, encoding="unicode") for c in root)
        pezzi["TAVOLA"] = ("<g>%s</g>" % corpo, vb[0], vb[1], vb[2], vb[3])
        ordine.append("TAVOLA")
    for sigla, titolo, f in nuovi:
        try:
            xml, w, h = _pezzo_nuovo(titolo, f)
        except Exception:  # noqa: BLE001
            continue
        pezzi[sigla] = (xml, 0.0, 0.0, w, h)
        ordine.append(sigla)
    lista = [(k, k, pezzi[k][3], pezzi[k][4]) for k in ordine]
    _s, pagine = L.impagina_particolari(lista, area_w - 4, area_h - 4, gap=3.0, scala_max=3.0,
                                        scala_min=0.15)
    posti = pagine[0] if pagine else []
    parti = []
    for k, _f, x, y, W, H in posti:
        xml, bx, by, bw, bh = pezzi[k]
        s = min(W / bw, H / bh)
        parti.append('<g transform="translate(%.3f %.3f) scale(%.5f) translate(%.3f %.3f)">%s</g>'
                     % (x + 2 + (W - bw * s) / 2, y + 2 + (H - bh * s) / 2, s, -bx, -by, xml))
    testo = ('<?xml version="1.0" encoding="UTF-8"?>\n<svg xmlns="http://www.w3.org/2000/svg" '
             'xmlns:xlink="http://www.w3.org/1999/xlink" width="%.2fmm" height="%.2fmm" '
             'viewBox="0 0 %.2f %.2f"><rect width="%.2f" height="%.2f" fill="#ffffff"/>%s</svg>'
             % (area_w, area_h, area_w, area_h, area_w, area_h, "".join(parti)))
    with open(uscita, "w", encoding="utf-8") as fh:
        fh.write(testo)
    return len(posti)


def riquadri_particolari(project):
    """Immagini «PARTICOLARI COSTRUTTIVI» dei layout: [(layout, item)]."""
    from qgis.core import QgsLayoutItemPicture
    out = []
    for lay in project.layoutManager().layouts():
        for it in lay.items():
            if not isinstance(it, QgsLayoutItemPicture):
                continue
            testo = " ".join([it.id() or "", it.picturePath() or "", _espressione_sorgente(it)])
            if ID_PARTICOLARI in testo.upper() or "PARTICOLARI_COSTRUTTIVI" in testo.upper():
                out.append((lay, it))
    return out


def _espressione_sorgente(it):
    from qgis.core import QgsLayoutObject
    try:
        p = it.dataDefinedProperties().property(QgsLayoutObject.PictureSource)
        return p.expressionString() if p.isActive() else ""
    except Exception:  # noqa: BLE001
        return ""


def sorgente_attuale(it):
    """Il file che l'immagine mostra adesso (espressione del layout, se c'è),
    con il percorso assoluto (nei progetti è spesso relativo: «../../00_Base/…»)."""
    from qgis.core import QgsLayoutObject
    try:
        prj = it.layout().project()
    except Exception:  # noqa: BLE001
        prj = None

    def _assoluto(v):
        if v and not os.path.isabs(v) and prj is not None:
            a = prj.pathResolver().readPath(v)
            return a if os.path.isfile(a) else os.path.normpath(os.path.join(prj.absolutePath(), v))
        return v

    def _espr(solo_attiva):
        try:
            p = it.dataDefinedProperties().property(QgsLayoutObject.PictureSource)
            if p.expressionString() and (p.isActive() or not solo_attiva):
                v, ok = p.valueAsString(it.createExpressionContext(), "")
                return _assoluto(v) if ok and v else ""
        except Exception:  # noqa: BLE001
            pass
        return ""
    candidati = [_espr(True), _assoluto(it.picturePath() or "")]
    if prj is not None:
        candidati.append(os.path.join(prj.absolutePath(), "05_Particolari Costruttivi",
                                      "Particolari Costruttivi-PC.svg"))
    candidati.append(_espr(False))
    for v in candidati:
        if v and os.path.isfile(v):
            return v
    return next((v for v in candidati if v), "")


class Simboli:
    """Applica colonnina e armadi per l'esportazione e li toglie: da usare
    con `with Simboli(project, colonnina=..., armadi=...) as s:` oppure
    applica()/ripristina(). s.righe = cosa è stato fatto (per il registro)."""

    def __init__(self, project, colonnina=None, armadi=False, cartella_tmp=None):
        import tempfile
        self.project = project
        self.colonnina = colonnina          # None o un MODO_* (di solito MODO_BASAMENTO)
        self.armadi = armadi
        self.cartella_tmp = cartella_tmp or tempfile.mkdtemp(prefix="ftth_pc_")
        self.righe = []
        self._vecchi = []                   # (layer, renderer di prima)
        self._nodi = []                     # (nodo legenda, proprietà, valore di prima)
        self._legende_bloccate_stato = []   # (legenda bloccata, albero di prima)
        self._immagini = []                 # (item, proprietà dati, percorso di prima)
        self._accesi = []                   # (nodo albero, spunta di prima)
        self._mappe = []                    # (mappa layout, layer di prima)
        self._etichette = []                # (layer, etichette accese prima)

    def __enter__(self):
        try:
            self.applica()
        except Exception as e:  # noqa: BLE001
            self.righe.append("Colonnina/armadi non applicati: %s" % e)
        return self

    def __exit__(self, *_a):
        self.ripristina()
        return False

    def applica(self):
        cambiati = []
        aggiunti = {}           # layer id -> indici delle voci da mostrare se il layer manca
        taglie = []
        if self.colonnina in ESPR_COLONNINA:
            lyr = layer_pte(self.project)
            espr = ESPR_COLONNINA[self.colonnina]
            n = conta(lyr, espr)
            if lyr is None:
                self.righe.append("Colonnina PTE: nel progetto non c'è lo shape ROE PTE.")
            elif not os.path.isfile(SVG_PTE_COLONNINA):
                self.righe.append("Colonnina PTE: simbolo non trovato nel plugin.")
            else:
                # ROE PTE spento nel progetto (di solito): si accende per
                # l'esportazione con le SOLE colonnine, gli altri PTE no
                acceso = self._accendi(lyr)
                self._metti(lyr, [("PTE A COLONNINA", espr, _simbolo_svg(SVG_PTE_COLONNINA))],
                            resto_serve=acceso)
                cambiati.append(lyr)
                aggiunti[lyr.id()] = [0]     # legenda senza ROE PTE: solo la colonnina
                self.righe.append("Colonnina PTE: %d %s col simbolo del sinottico (%s)." % (
                    n, "colonnina" if n == 1 else "colonnine",
                    {MODO_NUOVE: "solo NewColoninn = Si",
                     MODO_BASAMENTO: "solo NewBasament = Si"}.get(
                        self.colonnina, "tutte, TIPO = Colonnina")))
        if self.armadi:
            lyr = layer_armadi(self.project)
            taglie = taglie_presenti(lyr)
            if lyr is None:
                self.righe.append("Armadi: nel progetto non c'è lo shape ARMADIO OTTICO con "
                                  "FO_USCENTI.")
            elif not taglie:
                self.righe.append("Armadi: FO_USCENTI vuoto o diverso da 128/384/576: simboli "
                                  "non cambiati.")
            else:
                campo = _campo_fo(lyr)
                try:
                    angoli = angoli_armadi(self.project, lyr, layer_scavi(self.project))
                except Exception:  # noqa: BLE001
                    angoli = {}
                espr_ang = espressione_angoli(angoli)
                regole = [("ARMADIO OTTICO %s (%d fo)" % (TAGLIE[t], t),
                           "regexp_substr(to_string(\"%s\"), '\\\\d+') = '%d'" % (campo, t),
                           _simbolo_svg(SVG_ARMADIO[t], DIM_ARMADIO_MM, base_sul_punto=True,
                                        espr_angolo=espr_ang))
                          for t in taglie if os.path.isfile(SVG_ARMADIO[t])]
                senza = sum(1 for f in lyr.getFeatures() if not taglia(f[campo]))
                self._metti(lyr, regole, resto_serve=senza > 0)
                if senza:
                    self.righe.append("Armadi: %d senza FO_USCENTI 128/384/576, restano con lo "
                                      "stile di prima." % senza)
                cambiati.append(lyr)
                self.righe.append("Armadi: simbolo per taglia (%s)." % ", ".join(
                    "%s %d" % (TAGLIE[t], t) for t in taglie))
        if cambiati:
            self._sistema_legende(cambiati, aggiunti)
        if self.colonnina in ESPR_COLONNINA or taglie:
            self._particolari(bool(self.colonnina in ESPR_COLONNINA), taglie)

    def _accendi(self, lyr):
        """Il layer deve vedersi nelle tavole: acceso nell'albero dei layer e
        aggiunto alle mappe dei layout con i layer bloccati. Ritorna True se
        era già acceso (allora gli altri suoi elementi restano com'erano)."""
        from qgis.core import QgsLayoutItemMap
        nodo = self.project.layerTreeRoot().findLayer(lyr.id())
        era = bool(nodo is not None and nodo.isVisible())
        if not era and lyr.labelsEnabled():
            # acceso solo per le colonnine: niente etichette dei PTE (codici)
            self._etichette.append((lyr, True))
            lyr.setLabelsEnabled(False)
        if nodo is not None and not era:
            catena = []
            n = nodo
            while n is not None and n.parent() is not None:
                catena.append((n, n.itemVisibilityChecked()))
                n.setItemVisibilityChecked(True)
                n = n.parent()
            self._accesi.extend(catena)
        for lay in self.project.layoutManager().layouts():
            for it in lay.items():
                if isinstance(it, QgsLayoutItemMap) and it.keepLayerSet() \
                        and lyr not in it.layers():
                    self._mappe.append((it, list(it.layers())))
                    it.setLayers([lyr] + list(it.layers()))
        return era

    def _metti(self, lyr, regole, resto_serve=True):
        orig = lyr.renderer().clone() if lyr.renderer() else None
        self._vecchi.append((lyr, orig))
        lyr.setRenderer(_renderer_con_regole(orig, regole, resto_serve, lyr.name()))
        lyr.triggerRepaint()
        lyr.emitStyleChanged()

    def _proprieta(self, nodo, chiave, valore):
        """Proprietà del nodo di legenda cambiata e ricordata per ripristinarla."""
        self._nodi.append((nodo, chiave, nodo.customProperty(chiave)))
        if valore is None:
            nodo.removeCustomProperty(chiave)
        else:
            nodo.setCustomProperty(chiave, valore)

    def _sistema_legende(self, layers, aggiunti):
        """In ogni legenda dei layout: niente titolo del layer sopra le voci
        (prima compariva «ARMADIO OTTICO NUOVA POSA» sopra le taglie), voci
        rifatte dallo stile nuovo; nelle legende bloccate che non avevano il
        layer, il layer si aggiunge con le sole voci nuove."""
        from qgis.core import QgsLayoutItemLegend
        for lay in self.project.layoutManager().layouts():
            for it in lay.items():
                if not isinstance(it, QgsLayoutItemLegend):
                    continue
                try:
                    root = it.model().rootGroup()
                    bloccata = not it.autoUpdateModel()
                    if bloccata:
                        self._legende_bloccate_stato.append((it, root.clone()))
                    for l in layers:
                        nodo = root.findLayer(l.id())
                        if nodo is None and bloccata:
                            nodo = root.addLayer(l)
                            if aggiunti.get(l.id()) is not None:
                                from qgis.core import QgsMapLayerLegendUtils
                                QgsMapLayerLegendUtils.setLegendNodeOrder(nodo,
                                                                          aggiunti[l.id()])
                                it.model().refreshLayerLegend(nodo)
                        elif nodo is not None:
                            self._proprieta(nodo, "legend/node-order", None)
                        if nodo is not None:
                            self._proprieta(nodo, "legend/title-style", "hidden")
                    it.updateLegend()
                except Exception:  # noqa: BLE001
                    continue

    def _particolari(self, colonnina, taglie):
        """La tavola PARTICOLARI COSTRUTTIVI dei layout con colonnina e armadi."""
        from qgis.core import QgsLayoutObject
        riq = riquadri_particolari(self.project)
        nuovi = pezzi_nuovi(colonnina, taglie)
        mancanti = [t for t in taglie if not any(s == "PC-AO%d" % t for s, _t, _f in nuovi)]
        for t in mancanti:
            self.righe.append("Particolari: armadio %s (%d fo) senza disegno quotato: resta il "
                              "particolare generico ONUCAB." % (TAGLIE[t], t))
        if not riq:
            self.righe.append("Particolari: nei layout non c'è l'immagine «%s»: colonnina e "
                              "armadi non aggiunti alla tavola." % ID_PARTICOLARI)
            return
        if not nuovi:
            return
        # l'armadio generico ONUCAB (PC-06) si toglie solo se tutte le taglie
        # presenti hanno il loro particolare (il 128 SMALL non ce l'ha ancora:
        # allora resta l'ONUCAB)
        togli = (PC_ARMADIO_GENERICO,) if (taglie and not mancanti) else ()
        fatti = {}
        for lay, it in riq:
            src = sorgente_attuale(it)
            sz = it.sizeWithUnits()
            chiave = (src, round(sz.width(), 1), round(sz.height(), 1))
            if chiave not in fatti:
                out = os.path.join(self.cartella_tmp, "Particolari_PL_%d.svg" % len(fatti))
                try:
                    n = componi_particolari(src, out, sz.width(), sz.height(), nuovi, togli)
                except Exception as e:  # noqa: BLE001
                    n = None
                    self.righe.append("Particolari: tavola non ricomposta (%s)." % e)
                fatti[chiave] = out if n else None
                if n:
                    self.righe.append(
                        "Particolari: tavola ricomposta con %s (%d pezzi, centrati nel riquadro "
                        "%.0f×%.0f mm)%s." % (", ".join(t for _s, t, _f in nuovi), n, sz.width(),
                                              sz.height(),
                                              "; tolto l'armadio generico ONUCAB" if togli else ""))
                elif n is None and src:
                    self.righe.append("Particolari: la tavola «%s» non è un SVG del compositore: "
                                      "colonnina e armadi non aggiunti." % os.path.basename(src))
            nuovo = fatti[chiave]
            if not nuovo:
                continue
            props = it.dataDefinedProperties()
            prop = props.property(QgsLayoutObject.PictureSource)
            era_attiva = prop.isActive()
            self._immagini.append((it, era_attiva, it.picturePath()))
            if era_attiva:
                prop.setActive(False)
                props.setProperty(QgsLayoutObject.PictureSource, prop)
                it.setDataDefinedProperties(props)
            it.setPicturePath(nuovo)
            it.refreshPicture()

    def ripristina(self):
        from qgis.core import QgsLayoutObject
        for lyr, orig in reversed(self._vecchi):
            try:
                if orig is not None:
                    lyr.setRenderer(orig)
                lyr.triggerRepaint()
                lyr.emitStyleChanged()
            except Exception:  # noqa: BLE001
                pass
        self._vecchi = []
        for nodo, prima in reversed(self._accesi):
            try:
                nodo.setItemVisibilityChecked(prima)
            except Exception:  # noqa: BLE001
                pass
        self._accesi = []
        for lyr, prima in self._etichette:
            try:
                lyr.setLabelsEnabled(prima)
            except Exception:  # noqa: BLE001
                pass
        self._etichette = []
        for it, layers in self._mappe:
            try:
                it.setLayers(layers)
            except Exception:  # noqa: BLE001
                pass
        self._mappe = []
        for nodo, chiave, prima in reversed(self._nodi):
            try:
                if prima is None:
                    nodo.removeCustomProperty(chiave)
                else:
                    nodo.setCustomProperty(chiave, prima)
            except Exception:  # noqa: BLE001
                pass
        self._nodi = []
        for it, stato in self._legende_bloccate_stato:
            try:
                root = it.model().rootGroup()
                root.clear()
                for c in stato.children():
                    root.addChildNode(c.clone())
                it.updateLegend()
            except Exception:  # noqa: BLE001
                pass
        self._legende_bloccate_stato = []
        for it, era_attiva, percorso in self._immagini:
            try:
                if era_attiva:
                    props = it.dataDefinedProperties()
                    prop = props.property(QgsLayoutObject.PictureSource)
                    prop.setActive(True)
                    props.setProperty(QgsLayoutObject.PictureSource, prop)
                    it.setDataDefinedProperties(props)
                it.setPicturePath(percorso)
                it.refreshPicture()
            except Exception:  # noqa: BLE001
                pass
        self._immagini = []
