# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Riquadri delle tavole della PL in mappa, per ogni scheda istanze.

«Calcola numero di tavole» (passo 5) disegna un poligono per tavola nel layer
«Tavole PL (riquadri) - <ente>» (su file, resta nel progetto). La stampa usa
quei riquadri: un poligono cancellato è una tavola in meno, uno spostato
sposta la tavola (conta il centro: la dimensione la fa la scala). Senza
riquadri in mappa per un'istanza la stampa divide le tavole da sola.
"""
BASE = "Tavole PL (riquadri)"


def _L():
    try:
        from . import ftth_rfi_layout as L
    except ImportError:
        import ftth_rfi_layout as L
    return L


def nome_layer(ente):
    return _L().nome_layer_ente(BASE, ente)


def layer(project, ente):
    for l in project.mapLayersByName(nome_layer(ente)):
        return l
    return None


def scrivi(project, ente, voci, crs, permanente=True):
    """voci = [(nome istanza, n tavola, scala, QgsRectangle nel crs, etichetta,
    sezioni)]. Sostituisce il layer dell'ente (tutte le istanze). Ritorna il
    layer."""
    from qgis.core import (QgsFeature, QgsField, QgsFillSymbol, QgsGeometry,
                           QgsPalLayerSettings, QgsSingleSymbolRenderer, QgsTextBufferSettings,
                           QgsTextFormat, QgsVectorLayer, QgsVectorLayerSimpleLabeling)
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtGui import QColor
    nome = nome_layer(ente)
    lyr = QgsVectorLayer("Polygon?crs=%s" % crs.authid(), nome, "memory")
    lyr.dataProvider().addAttributes([QgsField("tavola", QVariant.String),
                                      QgsField("istanza", QVariant.String),
                                      QgsField("n", QVariant.Int),
                                      QgsField("scala", QVariant.Int),
                                      QgsField("sezione", QVariant.String)])
    lyr.updateFields()
    feats = []
    for ist, n, scala, rect, etich, sez in voci:
        f = QgsFeature(lyr.fields())
        f.setGeometry(QgsGeometry.fromRect(rect))
        f["tavola"] = etich
        f["istanza"] = ist
        f["n"] = int(n)
        f["scala"] = int(scala)
        f["sezione"] = sez or ""
        feats.append(f)
    lyr.dataProvider().addFeatures(feats)
    lyr.updateExtents()
    lyr.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
        {"color": "230,60,60,30", "outline_color": "220,40,40,255", "outline_width": "0.6",
         "outline_style": "dash"})))
    pal = QgsPalLayerSettings()
    pal.fieldName = "tavola"
    tf = QgsTextFormat()
    tf.setSize(9)
    tf.setColor(QColor(200, 0, 0))
    b = QgsTextBufferSettings()
    b.setEnabled(True)
    b.setSize(1)
    tf.setBuffer(b)
    pal.setFormat(tf)
    lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    lyr.setLabelsEnabled(True)
    stile_numero(lyr)
    for vecchio in project.mapLayersByName(nome):
        project.removeMapLayer(vecchio.id())
    if permanente:
        try:
            from . import ftth_memoria as MEM
        except ImportError:
            import ftth_memoria as MEM
        lyr = MEM.permanente(project, lyr)
    try:
        from . import ftth_gruppi_istanze as GR
    except ImportError:
        import ftth_gruppi_istanze as GR
    project.addMapLayer(lyr, False)
    try:
        GR.gruppo_sezione(project.layerTreeRoot(), ente).insertLayer(0, lyr)
    except Exception:  # noqa: BLE001
        project.layerTreeRoot().insertLayer(0, lyr)
    return lyr


ESPR_ETICHETTA = ("'TAV. ' || coalesce(to_string(\"n\"), '?') || "
                  "regexp_replace(coalesce(\"tavola\", ''), '^\\\\s*TAV\\\\.?\\\\s*\\\\d*', '')")


def stile_numero(lyr):
    """L'etichetta del riquadro mostra il campo «n» (alias «Numero tavola»):
    cambi il numero nella tabella attributi e in mappa cambia subito; la
    stampa segue quei numeri. Non tocca niente se è già così."""
    from qgis.core import QgsVectorLayerSimpleLabeling
    i_n = lyr.fields().indexOf("n")
    if i_n < 0:
        return False
    if lyr.attributeAlias(i_n) != "Numero tavola":
        lyr.setFieldAlias(i_n, "Numero tavola")
    lab = lyr.labeling()
    if isinstance(lab, QgsVectorLayerSimpleLabeling):
        pal = lab.settings()
        if pal.isExpression and pal.fieldName == ESPR_ETICHETTA:
            return False
        pal.fieldName = ESPR_ETICHETTA
        pal.isExpression = True
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        lyr.setLabelsEnabled(True)
        lyr.triggerRepaint()
        return True
    return False


def numero_etichetta(testo):
    """18 da «TAV. 18 - 1:1000 - SP31», «Tav 18», «18»; None se non c'è."""
    import re
    if testo is None:
        return None
    m = re.match(r"\s*(?:TAV(?:OLA)?\.?\s*)?(\d+)", str(testo), re.I)
    return int(m.group(1)) if m else None


def leggi(project, ente, istanza, crs):
    """Riquadri in mappa di un'istanza: [(n, scala, centro QgsPointXY nel crs)]
    in ordine di numero, o None se per l'istanza non ce ne sono (la stampa
    allora divide da sola)."""
    from qgis.core import QgsCoordinateTransform
    lyr = layer(project, ente)
    if lyr is None or not lyr.isValid():
        return None
    idx = lyr.fields().indexOf("istanza")
    if idx < 0:
        return None
    tr = QgsCoordinateTransform(lyr.crs(), crs, project)
    try:
        stile_numero(lyr)      # layer fatti prima: anche lì l'etichetta mostra «n»
    except Exception:  # noqa: BLE001
        pass
    out = []
    for f in lyr.getFeatures():
        if str(f[idx] or "").strip() != istanza or not f.hasGeometry():
            continue
        try:
            c = tr.transform(f.geometry().boundingBox().center())
        except Exception:  # noqa: BLE001
            continue
        # numero della tavola = campo «n» (Numero tavola, modificabile: la
        # mappa lo mostra e la stampa segue quell'ordine); vuoto → il numero
        # scritto nel testo «tavola»
        try:
            n = int(f["n"])
        except (TypeError, ValueError, KeyError):
            n = numero_etichetta(f["tavola"] if "tavola" in f.fields().names() else None)
            if n is None:
                n = 10 ** 6
        try:
            s = int(f["scala"])
        except (TypeError, ValueError, KeyError):
            s = 0
        out.append((n, s, c))
    if not out:
        return None
    out.sort(key=lambda t: (t[0], t[2].x()))
    return out


def dividi(interferenze, finestre, punto, punti_elementi=None):
    """Interferenze per finestra (QgsRectangle): fra le finestre che la
    contengono, quella col centro più vicino (prima era la prima trovata: con
    riquadri sovrapposti un riquadro tenuto dall'utente poteva restare vuoto
    e la tavola spariva). Con `punti_elementi(i)` (punti di scavi e pozzetti
    dell'interferenza) l'interferenza entra ANCHE in ogni altra finestra dove
    cade un suo elemento: una perforazione lunga che attraversa due riquadri
    ha le etichette in tutti e due (prima il secondo riquadro restava vuoto,
    la tavola veniva saltata e i suoi pozzetti senza etichetta: SP22 Terni).
    Ritorna ([lista per finestra], [interferenze fuori])."""
    gruppi = [[] for _ in finestre]
    fuori = []
    for i in interferenze:
        p = punto(i)
        dentro = [k for k, r in enumerate(finestre) if r.contains(p)]
        if not dentro:
            fuori.append(i)
            continue
        k = min(dentro, key=lambda k: finestre[k].center().sqrDist(p))
        gruppi[k].append(i)
        if punti_elementi is None:
            continue
        try:
            pts = list(punti_elementi(i) or [])
        except Exception:  # noqa: BLE001
            pts = []
        for k2, r in enumerate(finestre):
            if k2 != k and any(r.contains(q) for q in pts):
                gruppi[k2].append(i)
    return gruppi, fuori


def punti_elementi_fn(tr):
    """Funzione per dividi(): i punti (nel crs delle finestre) degli elementi
    dell'interferenza (lon/lat di scavi e pozzetti). Il bbox no: i suoi
    angoli possono cadere in riquadri dove l'interferenza non c'è."""
    from qgis.core import QgsPointXY

    def _f(i):
        out = []
        for e in getattr(i, "elementi", None) or []:
            try:
                if e.get("lon") is not None and e.get("lat") is not None:
                    out.append(tr.transform(QgsPointXY(e["lon"], e["lat"])))
            except Exception:  # noqa: BLE001
                continue
        return out
    return _f


def sezioni_nei_riquadri(project, ente, ist, crs, riquadri):
    """Per ogni riquadro (QgsRectangle nel crs) le sigle delle sezioni
    dell'istanza disegnate dentro (centro della linea)."""
    from qgis.core import QgsCoordinateTransform, QgsGeometry
    L = _L()
    out = [[] for _ in riquadri]
    sez_l = L.layer_rilievo(project, L.NOMI_LAYER_SEZIONI, L.nomi_istanza(ist), ente)
    if sez_l is None:
        return out
    a_s = QgsCoordinateTransform(sez_l.crs(), crs, project)
    c_i = L._campo(sez_l, L.CAMPO_ISTANZA)
    for f in sez_l.getFeatures():
        sig = L.sigla_sezione(sez_l, f)
        if not sig or not f.hasGeometry():
            continue
        if c_i and not L.istanza_corrisponde(f[c_i], L.nomi_istanza(ist)):
            continue
        g = QgsGeometry(f.geometry())
        g.transform(a_s)
        c = g.centroid().asPoint()
        for k, r in enumerate(riquadri):
            if r.contains(c):
                out[k].append(sig)
                break
    return out


def mostra(dlg, ente, risultati, etichetta_ist=None, sez_per_tavola=1, iface=None):
    """Riquadri di tutte le istanze in mappa e sintesi.
    risultati = [(istanza, crs, [(scala, QgsRectangle nel crs)])]. Ritorna
    (sintesi breve, testo completo)."""
    from qgis.core import QgsCoordinateTransform
    project = dlg.project
    if not risultati:
        return "", ""
    crs_l = risultati[0][1]
    voci, righe, scale = [], [], {}
    tot = mancano = troppe = 0
    for ist, crs, tavole in risultati:
        a = QgsCoordinateTransform(crs, crs_l, project)
        sez = sezioni_nei_riquadri(project, ente, ist, crs, [r for _s, r in tavole]) \
            if sez_per_tavola else [[] for _ in tavole]
        breve = etichetta_ist(ist) if etichetta_ist else ist.nome_base
        for n, ((s, r), sg) in enumerate(zip(tavole, sez), 1):
            scale[s] = scale.get(s, 0) + 1
            voci.append((ist.nome_base, n, s, a.transformBoundingBox(r),
                         "TAV. %d - 1:%d - %s" % (n, s, breve), ", ".join(sg)))
            if sez_per_tavola:
                mancano += 0 if sg else 1
                troppe += max(0, len(sg) - sez_per_tavola)
        tot += len(tavole)
        righe.append("%s: %d tavole (%s)" % (ist.nome_base, len(tavole),
                                              ", ".join("1:%d" % s for s, _r in tavole)))
    lyr = scrivi(project, ente, voci, crs_l)
    try:
        canvas = (iface or dlg.iface).mapCanvas()
        est = QgsCoordinateTransform(lyr.crs(), canvas.mapSettings().destinationCrs(),
                                     project).transformBoundingBox(lyr.extent())
        est.scale(1.1)
        canvas.setExtent(est)
        canvas.refresh()
    except Exception:  # noqa: BLE001
        pass
    sintesi = "%d tavole in %d istanze (%s)" % (
        tot, len(risultati), ", ".join("%d a 1:%d" % (n, s) for s, n in sorted(scale.items())))
    if sez_per_tavola:
        sintesi += (": %s%s." % (("senza sezione %d" % mancano) if mancano else
                                 "sezioni presenti in tutte",
                                 (", %d sezioni in più (tavole aggiunte in stampa)" % troppe)
                                 if troppe else ""))
    else:
        sintesi += "."
    testo = (sintesi + "\n\n" + "\n".join(righe) +
             "\n\nIn mappa i riquadri rossi (layer «%s») sono le tavole, con numero e scala. "
             "La stampa usa questi riquadri: cancella un poligono per togliere quella tavola, "
             "spostalo per spostarla. Senza riquadri di un'istanza la stampa divide da sola; "
             "per rifarli premi di nuovo «Calcola numero di tavole»." % nome_layer(ente))
    return sintesi, testo


def finestra(centro, w, h):
    from qgis.core import QgsRectangle
    return QgsRectangle(centro.x() - w / 2.0, centro.y() - h / 2.0,
                        centro.x() + w / 2.0, centro.y() + h / 2.0)
