# -*- coding: utf-8 -*-
"""Verifica interferenze del permesso comunale: logica senza QGIS.

Le tratte di infrastruttura vicine a ferrovie, corsi d'acqua e strade ANAS
vanno guardate già nel permesso comunale: lì servirà un'istanza a un altro
ente (RFI, demanio idrico / consorzio, ANAS) e spesso conviene spostare il
tracciato. Qui: interrogazione OpenStreetMap, distanze, esiti salvati nel
progetto (come la Verifica armadi), elenco CSV.
"""
import csv
import json
import math

# categorie: distanza di attenzione proposta (m) e a chi fa capo l'istanza
CATEGORIE = {
    "ferrovia": {"nome": "Ferrovia", "dist": 30.0, "ente": "RFI / gestore ferroviario",
                 "colore": "#7a3db8"},
    "acqua": {"nome": "Corso d'acqua", "dist": 10.0,
              "ente": "Demanio idrico / Consorzio di bonifica", "colore": "#1f78c8"},
    "anas": {"nome": "Strada ANAS", "dist": 30.0, "ente": "ANAS", "colore": "#d93025"},
    "provinciale": {"nome": "Strada provinciale/regionale", "dist": 30.0,
                    "ente": "Provincia / Città metropolitana / Regione", "colore": "#e8710a"},
    "autostrada": {"nome": "Autostrada", "dist": 60.0, "ente": "Concessionario autostradale",
                   "colore": "#0b8043"},
}
ESITI = ["Da verificare", "OK, si lascia", "Da modificare", "Modificata"]
ESITO_INIZIALE = ESITI[0]
COLORI = {"Da verificare": "#8a919a", "OK, si lascia": "#2e9e44", "Da modificare": "#d93025",
          "Modificata": "#ff7c02"}
PRJ_SCOPE = "ftth_verifica_rete"
PRJ_CHIAVE = "esiti"


def query_overpass(sud, ovest, nord, est) -> str:
    """Ferrovie, corsi d'acqua, strade ANAS (statali / operatore ANAS),
    provinciali e regionali (SP, SR) e autostrade nel riquadro, con geometria."""
    bb = "%.6f,%.6f,%.6f,%.6f" % (sud, ovest, nord, est)
    return ("[out:json][timeout:120];("
            'way["railway"~"^(rail|light_rail|narrow_gauge|subway|tram|preserved)$"](%s);'
            'way["waterway"~"^(river|stream|canal|ditch|drain|brook)$"](%s);'
            'way["highway"]["ref"~"^(SS|NSA|RA|SP|SR|A) ?[0-9]"](%s);'
            'way["highway"="motorway"](%s);'
            'way["highway"]["operator"~"ANAS",i](%s);'
            ");out body geom qt;" % (bb, bb, bb, bb, bb))


def categoria_strada(tags: dict):
    """'anas', 'provinciale', 'autostrada' o None dai tag OSM della strada."""
    import re
    ref = (tags.get("ref") or "").upper().replace(".", "").strip()
    if tags.get("highway") == "motorway" or re.match(r"^A ?\d", ref):
        return "autostrada"
    if re.match(r"^(SS|NSA|RA) ?\d", ref) or "ANAS" in (tags.get("operator") or "").upper():
        return "anas"
    if re.match(r"^(SP|SR) ?\d", ref):
        return "provinciale"
    return None


def elementi_osm(elements: list) -> list:
    """[(categoria, nome, LineString WGS84)] dagli elementi Overpass."""
    from shapely.geometry import LineString
    out = []
    for e in elements or []:
        g = e.get("geometry")
        if e.get("type") != "way" or not g or len(g) < 2:
            continue
        t = e.get("tags") or {}
        if "railway" in t:
            cat = "ferrovia"
            nome = t.get("name") or t.get("ref") or "Linea ferroviaria"
        elif "waterway" in t:
            cat = "acqua"
            nome = t.get("name") or ("Canale" if t["waterway"] in ("canal", "ditch", "drain")
                                     else "Corso d'acqua senza nome")
        elif "highway" in t:
            cat = categoria_strada(t)
            if cat is None:
                continue
            nome = " ".join(x for x in (t.get("ref"), t.get("name")) if x) or \
                CATEGORIE[cat]["nome"]
        else:
            continue
        out.append((cat, nome, LineString([(p["lon"], p["lat"]) for p in g])))
    return out


def analizza(tratte: list, elementi: list, soglie: dict = None) -> list:
    """tratte = [{'fid', 'geom' (shapely WGS84), 'stato', 'tipologia', 'via'}],
    elementi = elementi_osm(). Una voce per tratta e categoria, entro la
    distanza di attenzione: {'chiave', 'fid', 'categoria', 'nome', 'dist',
    'attraversa', 'lat', 'lon', 'stato', 'tipologia', 'lunghezza'}. In ordine
    di categoria e distanza."""
    from shapely.ops import nearest_points
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    soglie = soglie or {k: v["dist"] for k, v in CATEGORIE.items()}
    if not tratte or not elementi:
        return []
    bb = [t["geom"].bounds for t in tratte]
    lon0 = sum((b[0] + b[2]) / 2.0 for b in bb) / len(bb)
    lat0 = sum((b[1] + b[3]) / 2.0 for b in bb) / len(bb)
    pr = rfi._Proiezione(lon0, lat0)
    from shapely.strtree import STRtree
    per_cat = {}
    for cat, nome, g in elementi:
        per_cat.setdefault(cat, []).append((nome, pr.avanti(g)))
    alberi = {}
    for cat, lista in per_cat.items():
        geoms = [g for _n, g in lista]
        alberi[cat] = (STRtree(geoms), geoms)

    def _candidati(cat, area):
        albero, geoms = alberi[cat]
        ris = albero.query(area)
        # shapely 2: indici; shapely 1.8: geometrie
        idx = [int(r) for r in ris] if len(ris) and not hasattr(ris[0], "geom_type") else \
            [geoms.index(r) for r in ris]
        return [per_cat[cat][i] for i in idx]
    out = []
    for t in tratte:
        gm = pr.avanti(t["geom"])
        for cat in per_cat:
            soglia = float(soglie.get(cat, CATEGORIE[cat]["dist"]))
            if soglia <= 0:
                continue
            vicini = [(gm.distance(g), nome, g) for nome, g in _candidati(cat, gm.buffer(soglia))
                      if gm.distance(g) <= soglia]
            if not vicini:
                continue
            d, nome, g = min(vicini, key=lambda x: x[0])
            p_tr, _p = nearest_points(gm, g)
            w = pr.indietro(p_tr)
            out.append({"chiave": "%s|%s" % (t["fid"], cat), "fid": t["fid"], "categoria": cat,
                        "nome": nome, "dist": round(d, 1), "attraversa": gm.intersects(g),
                        "lat": w.y, "lon": w.x, "stato": t.get("stato", ""),
                        "tipologia": t.get("tipologia", ""), "via": t.get("via", ""),
                        "lunghezza": round(gm.length, 1)})
    ordine = list(CATEGORIE)
    out.sort(key=lambda v: (ordine.index(v["categoria"]), v["dist"], v["fid"]))
    return out


def descrizione(v: dict) -> str:
    c = CATEGORIE[v["categoria"]]
    rel = "attraversa" if v["attraversa"] else "a %.1f m da" % v["dist"]
    return "%s %s m %s %s «%s» → istanza %s" % (
        v.get("tipologia") or "Tratta", ("%.0f" % v["lunghezza"]), rel, c["nome"].lower(),
        v["nome"], c["ente"])


def riepilogo_categorie(voci: list) -> dict:
    out = {k: 0 for k in CATEGORIE}
    for v in voci:
        out[v["categoria"]] += 1
    return out


# ------------------------------------------------------------- esiti
def esiti_da_testo(testo: str) -> dict:
    try:
        d = json.loads(testo or "{}")
    except (ValueError, TypeError):
        return {}
    out = {}
    for k, v in (d.items() if isinstance(d, dict) else []):
        if isinstance(v, dict):
            e = v.get("esito") if v.get("esito") in ESITI else ESITO_INIZIALE
            out[str(k)] = {"esito": e, "nota": str(v.get("nota") or "")}
    return out


def esiti_in_testo(esiti: dict) -> str:
    pulito = {k: v for k, v in esiti.items()
              if v.get("esito") != ESITO_INIZIALE or (v.get("nota") or "").strip()}
    return json.dumps(pulito, ensure_ascii=False, sort_keys=True)


def riepilogo(chiavi: list, esiti: dict) -> dict:
    out = {e: 0 for e in ESITI}
    for k in chiavi:
        out[(esiti.get(k) or {}).get("esito", ESITO_INIZIALE)] += 1
    return out


def scrivi_csv(percorso: str, voci: list, esiti: dict) -> int:
    try:
        from . import ftth_armadi as AR
    except ImportError:
        import ftth_armadi as AR
    with open(percorso, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Fonte OpenStreetMap: attendibilità sempre da verificare sulle cartografie "
                    "ufficiali e con l'ente competente"])
        w.writerow(["Tratta (fid)", "Tipologia", "Stato", "Lunghezza (m)", "Vicino a",
                    "Nome", "Distanza (m)", "Attraversa", "Istanza a", "Latitudine",
                    "Longitudine", "Esito", "Note", "Street View"])
        for v in voci:
            e = esiti.get(v["chiave"]) or {}
            c = CATEGORIE[v["categoria"]]
            w.writerow([v["fid"], v.get("tipologia", ""), v.get("stato", ""),
                        ("%.1f" % v["lunghezza"]).replace(".", ","), c["nome"], v["nome"],
                        ("%.1f" % v["dist"]).replace(".", ","),
                        "sì" if v["attraversa"] else "no", c["ente"],
                        "%.7f" % v["lat"], "%.7f" % v["lon"],
                        e.get("esito", ESITO_INIZIALE), (e.get("nota") or "").replace("\n", " "),
                        AR.link_streetview(v["lat"], v["lon"])])
    return len(voci)
