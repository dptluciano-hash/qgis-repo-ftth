"""Barra di avanzamento per le ricerche lunghe (OSM, SITAP, ...).

Le richieste ai server non dicono quanto manca: la barra procede per FASI e,
dentro una fase, avanza piano verso la fine della fase senza raggiungerla
(salta avanti quando la fase finisce). Serve a far vedere che il lavoro sta
andando, non a stimare il tempo.

Due modi d'uso:
- ciclo di attesa nel thread dell'interfaccia: chiamare `avanza()` a ogni giro;
- lavoro in un thread a parte (interfaccia libera): `avvia_timer()` fa
  avanzare la barra da sola finche' non si chiama `fine()` o `interrotta()`.
"""
from qgis.PyQt.QtCore import QTimer
from qgis.PyQt.QtWidgets import QApplication, QProgressBar


class BarraAvanzamento(QProgressBar):
    def __init__(self, parent=None, larghezza_min=300):
        super().__init__(parent)
        self.setRange(0, 100)
        self.setTextVisible(True)
        # al massimo 140 px di minimo: con 300 la riga «Scarica + barra +
        # Interrompi» impediva di restringere la finestra
        self.setMinimumWidth(min(larghezza_min, 140))
        self.setFormat("")
        self.setValue(0)
        self.setVisible(False)
        self._pos = 0.0
        self._fine_fase = None
        self._timer = QTimer(self)
        self._timer.setInterval(250)
        self._timer.timeout.connect(self.avanza)

    def fase(self, da, a, testo, eventi=True):
        """Nuova fase: la barra parte da `da` e si avvicina ad `a`."""
        self.setVisible(True)
        self._pos = float(max(da, self._pos if self._fine_fase is not None else 0))
        self._fine_fase = float(a)
        self.setValue(int(self._pos))
        self.setFormat("%p%  —  " + testo)
        if eventi:
            QApplication.processEvents()

    def avanza(self):
        if self._fine_fase is None:
            return
        self._pos += (self._fine_fase - 1 - self._pos) * 0.02
        self.setValue(int(self._pos))

    def avvia_timer(self):
        self._timer.start()

    def fine(self, testo):
        self._timer.stop()
        self._fine_fase = None
        self.setVisible(True)
        self.setValue(100)
        self.setFormat(testo)

    def interrotta(self, testo):
        self._timer.stop()
        self._fine_fase = None
        self.setFormat(testo)

    def azzera(self):
        self._timer.stop()
        self._pos = 0.0
        self._fine_fase = 0.0
        self.setValue(0)
        self.setVisible(True)


def in_sottofondo(barra, funzione, *args, **kw):
    """Esegue `funzione` (calcolo puro, senza toccare layer o interfaccia) in
    un thread, tenendo viva QGIS e facendo avanzare la barra."""
    import concurrent.futures as cf
    import time
    ex = cf.ThreadPoolExecutor(max_workers=1)
    fut = ex.submit(funzione, *args, **kw)
    try:
        while not fut.done():
            QApplication.processEvents()
            if barra is not None:
                barra.avanza()
            time.sleep(0.05)
        return fut.result()
    finally:
        ex.shutdown(wait=False)


def crea_barra(riga):
    """Barra nascosta aggiunta a una riga di pulsanti (None se non riesce)."""
    try:
        b = BarraAvanzamento()
        riga.addWidget(b, 1)
        return b
    except Exception:  # noqa: BLE001
        return None


def riga_spunte(tabella, colonna=0, cosa="le righe"):
    """Pulsanti «Seleziona tutte» / «Nessuna» per la colonna di spunta di una
    tabella (stessa riga in tutte le schede istanze)."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHBoxLayout, QPushButton

    def spunta(si):
        for r in range(tabella.rowCount()):
            it = tabella.item(r, colonna)
            if it is not None and (it.flags() & Qt.ItemIsUserCheckable):
                it.setCheckState(Qt.Checked if si else Qt.Unchecked)
    riga = QHBoxLayout()
    for testo, si, tip in (("Seleziona tutte", True, "Spunta tutte %s dell'elenco." % cosa),
                           ("Nessuna", False, "Toglie tutte le spunte.")):
        b = QPushButton(testo)
        b.setToolTip(tip)
        b.clicked.connect(lambda _=False, v=si: spunta(v))
        riga.addWidget(b)
    riga.addStretch()
    return riga
