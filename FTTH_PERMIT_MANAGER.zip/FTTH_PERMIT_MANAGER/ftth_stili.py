# -*- coding: utf-8 -*-
"""Stili portatili: l'SVG viaggia DENTRO lo stile, non come collegamento.

Il problema, misurato sui file reali: '02_POZZETTO.qml' referenzia gli SVG
con percorsi assoluti alla cartella di un utente, e 'POZZETTO.qml' a quella
di un altro (OneDrive). Ogni stile funziona solo sul PC di chi l'ha creato;
sugli altri il simbolo sparisce. I percorsi relativi non bastano, perche'
richiedono che tutti tengano la stessa struttura di cartelle, e nella
pratica non e' cosi'.

Rimedio: l'SVG viene letto e scritto dentro lo stile come 'base64:...'.
Verificato che QGIS lo disegni in modo identico al file (stesso numero di
pixel, test _test_svg_base64.py).

Costo da sapere: ogni stile porta la propria copia del disegno. Se un
domani il simbolo cambia, va riapplicato agli stili, perche' non c'e' piu'
un file unico da aggiornare. E' la contropartita del non dipendere da
collegamenti.

(C) Beexact S.r.l. - Tutti i diritti riservati.
"""

import base64
import os
import re

RE_SVG = re.compile(r'(?P<pre>(?:v|value)=")(?P<path>[^"]*?\.svg)(?P<post>")', re.I)
PREFISSO = "base64:"


def _dexml(s):
    """Il percorso nell'XML e' scappato: '&amp;' per '&'. Le cartelle dei
    simboli si chiamano '03_Simbologia & Layout', quindi senza questo
    passaggio il file non si trova mai."""
    return (s.replace("&amp;", "&").replace("&quot;", '"')
             .replace("&lt;", "<").replace("&gt;", ">").replace("&apos;", "'"))


def costruisci_catalogo(cartelle, escludi_cartelle=("OLD", "old", "_backup"),
                        profondita_max=3):
    """Indice nome-file -> percorso, per ritrovare un SVG spostato.

    Serve agli stili che citano la cartella di un altro utente (es. il
    MODELLO BASE punta al OneDrive di chi l'ha creato): il percorso non
    esiste da nessuna parte, ma il disegno sul disco c'e', con lo stesso
    nome.

    Un nome entra nel catalogo SOLO se tutte le copie trovate hanno
    contenuto identico. Se due file omonimi sono disegni diversi, la
    corrispondenza per nome e' un'ipotesi, e un'ipotesi non va incollata
    dentro uno stile: quel nome viene scartato e il simbolo resta da
    sistemare a mano.
    """
    import hashlib
    trovati = {}
    for base in cartelle:
        if not base or not os.path.isdir(base):
            continue
        for root, dirs, files in os.walk(base):
            dirs[:] = [d for d in dirs if d not in escludi_cartelle]
            if root[len(base):].count(os.sep) >= profondita_max:
                dirs[:] = []   # oltre questa profondita' non si scende
            for f in files:
                if f.lower().endswith(".svg"):
                    trovati.setdefault(f.lower(), []).append(os.path.join(root, f))
    catalogo, scartati = {}, []
    for nome, perc in trovati.items():
        impronte = set()
        for p in perc:
            try:
                with open(p, "rb") as fh:
                    impronte.add(hashlib.sha256(fh.read()).hexdigest())
            except Exception:
                pass
        if len(impronte) == 1:
            catalogo[nome] = perc[0]
        else:
            scartati.append(nome)
    return catalogo, scartati


def catalogo_per_stile(cartelle, salite=2):
    """Catalogo dei simboli nei dintorni di uno stile.

    Il caso da coprire: il collega ha la cartella dei simboli sul proprio
    PC, ma il file .qml che applica e' una copia e cita i percorsi della
    macchina d'origine. I disegni sono li', a due passi dal .qml: basta
    cercarli per nome partendo dalla cartella dello stile e risalendo di
    poco.

    Si risale al massimo di 'salite' livelli e si scende di pochi livelli
    (vedi profondita_max): scandire l'intero disco per trovare un'icona
    bloccherebbe l'interfaccia.
    """
    radici = []
    for c in cartelle:
        if not c:
            continue
        cur = os.path.abspath(c)
        for _ in range(salite + 1):
            if os.path.isdir(cur) and cur not in radici:
                radici.append(cur)
            padre = os.path.dirname(cur)
            if padre == cur:
                break
            cur = padre
    return costruisci_catalogo(radici)


def risolvi_svg(riferimento, cartelle=(), catalogo=None):
    """Percorso reale di un SVG citato in uno stile, o None.

    Cerca, nell'ordine: percorso assoluto, cartelle indicate (di norma
    quella del progetto e quella dello .qml), cartelle di ricerca SVG di
    QGIS, e infine il catalogo per nome-file, se fornito. Restituire None
    NON e' un dettaglio: significa che quel simbolo e' gia' invisibile su
    questa macchina, e va detto.
    """
    rif = _dexml((riferimento or "").strip())
    if not rif or rif.startswith(PREFISSO):
        return None
    rif_norm = rif.replace("\\", "/")
    if os.path.isabs(rif_norm) and os.path.exists(rif_norm):
        return rif_norm
    for base in list(cartelle):
        if not base:
            continue
        cand = os.path.normpath(os.path.join(base, rif_norm))
        if os.path.exists(cand):
            return cand
    try:
        from qgis.core import QgsApplication
        for base in QgsApplication.svgPaths():
            cand = os.path.normpath(os.path.join(base, rif_norm))
            if os.path.exists(cand):
                return cand
    except Exception:
        pass
    if catalogo:
        # ultima risorsa: stesso nome file, disegno verificato identico
        cand = catalogo.get(os.path.basename(rif_norm).lower())
        if cand and os.path.exists(cand):
            return cand
    return None


def incorpora_in_xml(xml, cartelle=(), catalogo=None):
    """Sostituisce i riferimenti SVG con il disegno incorporato.

    Restituisce (xml_nuovo, incorporati, gia_dentro, mancanti) dove
    'mancanti' elenca i riferimenti non risolti: quelli restano come sono,
    perche' inventarli sarebbe peggio che lasciarli rotti in modo visibile.
    """
    incorporati, gia_dentro, mancanti = [], [], []
    cache = {}

    def _sost(m):
        rif = m.group("path")
        if rif.startswith(PREFISSO):
            gia_dentro.append(rif[:24]); return m.group(0)
        if rif in cache:
            return m.group("pre") + cache[rif] + m.group("post")
        vero = risolvi_svg(rif, cartelle, catalogo)
        if not vero:
            mancanti.append(_dexml(rif)); return m.group(0)
        try:
            with open(vero, "rb") as fh:
                dati = fh.read()
        except Exception:
            mancanti.append(_dexml(rif)); return m.group(0)
        b64 = PREFISSO + base64.b64encode(dati).decode("ascii")
        cache[rif] = b64
        incorporati.append(os.path.basename(vero))
        return m.group("pre") + b64 + m.group("post")

    return RE_SVG.sub(_sost, xml), incorporati, gia_dentro, mancanti


def conta_riferimenti(xml):
    """Quanti SVG cita questo stile, e quanti sono gia' incorporati."""
    esterni = [m.group("path") for m in RE_SVG.finditer(xml)
               if not m.group("path").startswith(PREFISSO)]
    return esterni, xml.count('"' + PREFISSO)


def rendi_layer_portatile(layer, cartelle=(), catalogo=None):
    """Incorpora gli SVG nello stile di un layer caricato.

    Restituisce un riassunto. Non salva il progetto: la decisione di
    scrivere su disco resta all'utente.
    """
    from qgis.PyQt.QtXml import QDomDocument
    doc = QDomDocument()
    layer.exportNamedStyle(doc)
    xml = doc.toString()
    esterni, gia = conta_riferimenti(xml)
    if not esterni:
        return {"layer": layer.name(), "modificato": False, "incorporati": [],
                "mancanti": [], "gia_incorporati": gia}
    nuovo, inc, _g, mancanti = incorpora_in_xml(xml, cartelle, catalogo)
    esito = {"layer": layer.name(), "modificato": False, "incorporati": inc,
             "mancanti": mancanti, "gia_incorporati": gia}
    if not inc:
        return esito
    doc2 = QDomDocument()
    if not doc2.setContent(nuovo):
        esito["errore"] = "XML dello stile non rileggibile dopo l'incorporamento"
        return esito
    ok, msg = layer.importNamedStyle(doc2)
    if not ok:
        esito["errore"] = msg or "importNamedStyle ha rifiutato lo stile"
        return esito
    layer.triggerRepaint()
    esito["modificato"] = True
    return esito


def rendi_qml_portatile(percorso_qml, fai_backup=True, catalogo=None):
    """Incorpora gli SVG in un file .qml su disco (gli stili modello).

    Sono questi i file che si applicano ai progetti nuovi: finche' restano
    con i percorsi di un utente, il problema si ripresenta a ogni progetto.
    """
    with open(percorso_qml, encoding="utf-8", errors="replace") as fh:
        xml = fh.read()
    esterni, gia = conta_riferimenti(xml)
    esito = {"file": percorso_qml, "modificato": False, "incorporati": [],
             "mancanti": [], "gia_incorporati": gia, "backup": None}
    if not esterni:
        return esito
    cartelle = (os.path.dirname(os.path.abspath(percorso_qml)),)
    nuovo, inc, _g, mancanti = incorpora_in_xml(xml, cartelle, catalogo)
    esito["incorporati"] = inc
    esito["mancanti"] = mancanti
    if not inc:
        return esito
    if fai_backup:
        import datetime
        bk = "%s_backup_%s.qml" % (percorso_qml[:-4],
                                   datetime.datetime.now().strftime("%Y%m%d_%H%M%S"))
        with open(bk, "w", encoding="utf-8") as fh:
            fh.write(xml)
        esito["backup"] = bk
    with open(percorso_qml, "w", encoding="utf-8") as fh:
        fh.write(nuovo)
    esito["modificato"] = True
    return esito
