# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Scheda 'Fasce di rispetto' (Altri Enti): dato uno shape (di solito lineare:
strada, ferrovia, fiume, canale...) genera il buffer della fascia di rispetto
dell'ente scelto. Il menu ente imposta la distanza di default (modificabile).

Mixin senza dipendenze dal dialog principale se non i helper _gruppo/_desc/
_lcombo/_dspin/_scrollable e self.project/self.iface, già presenti in
FTTHPermessiDialog.
"""
from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsField, QgsFields, QgsProject,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
    QgsWkbTypes, QgsFillSymbol, QgsPalLayerSettings, QgsTextFormat,
    QgsVectorLayerSimpleLabeling, QgsMapLayerProxyModel,
)
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QComboBox, QPushButton, QMessageBox,
    QPlainTextEdit, QLabel, QCheckBox,
)


class FasceMixin:
    # ente -> (distanza_default_m, riferimento normativo/nota)
    # Le voci sono raggruppate: FUORI centro abitato (art. 26 DPR 495/92),
    # DENTRO centro abitato (art. 28 DPR 495/92), poi gli altri enti.
    # Il discriminante è la delimitazione del centro abitato ex art. 4 CdS.
    ENTI_FASCE = [
        # ---- fuori centro abitato (art. 26 DPR 495/92) ----
        ("FUORI c.a. — Autostrada (tipo A)",        60, "Art. 26 DPR 495/92: 60 m, tipo A"),
        ("FUORI c.a. — ANAS / statale (tipo B)",    40, "Art. 26 DPR 495/92: 40 m, extraurbana principale"),
        ("FUORI c.a. — Provinciale (tipo C)",       30, "Art. 26 DPR 495/92: 30 m, extraurbana secondaria"),
        ("FUORI c.a. — Comunale/locale (tipo F)",   20, "Art. 26 DPR 495/92: 20 m, strade locali"),
        ("FUORI c.a. — Strada vicinale (tipo F)",   10, "Art. 26 DPR 495/92: 10 m, vicinali"),
        # ---- dentro centro abitato (art. 28 DPR 495/92) ----
        ("DENTRO c.a. — Autostrada (tipo A)",       30, "Art. 28 DPR 495/92: 30 m, tipo A"),
        ("DENTRO c.a. — Urbana scorrimento (D)",    20, "Art. 28 DPR 495/92: 20 m, tipo D"),
        ("DENTRO c.a. — Urbana quartiere (E)",      20, "Art. 28 c.3 DPR 495/92: 20 m SOLO senza strumento urbanistico; con PRG vigente non è stabilita (vale il PRG)"),
        ("DENTRO c.a. — Locale (tipo F)",           10, "Art. 28 c.3 DPR 495/92: 10 m SOLO senza strumento urbanistico; con PRG vigente non è stabilita (vale il PRG)"),
        ("DENTRO c.a. — Muri di cinta (tipo A)",     3, "Art. 28 c.4 DPR 495/92: 3 m, muri di cinta tipo A"),
        ("DENTRO c.a. — Muri di cinta (tipo D)",     2, "Art. 28 c.4 DPR 495/92: 2 m, muri di cinta tipo D"),
        # ---- zone edificabili fuori c.a. (art. 26 c.3 DPR 495/92) ----
        ("Zona edificabile f.c.a. — tipo A",        30, "Art. 26 c.3 DPR 495/92: 30 m in zone edificabili/PRG attuativo"),
        ("Zona edificabile f.c.a. — tipo B",        20, "Art. 26 c.3 DPR 495/92: 20 m in zone edificabili/PRG attuativo"),
        ("Zona edificabile f.c.a. — tipo C",        10, "Art. 26 c.3 DPR 495/92: 10 m in zone edificabili/PRG attuativo"),
        # ---- altri enti ----
        ("RFI - Ferrovia",                          30, "DPR 753/1980 art.49 (fascia 6-30 m)"),
        ("Fiume / Corso d'acqua",                   10, "R.D. 523/1904 (dal piede argine/sponda)"),
        ("Consorzio di bonifica",                   10, "Canale/opere (spesso 4-10 m)"),
        ("Cimitero",                               200, "R.D. 1265/1934 art.338"),
        ("Personalizzato",                          10, "Distanza libera"),
    ]

    def _tab_fasce(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Genera la fascia di rispetto di un ente attorno a uno shape (di norma "
            "lineare: strada, ferrovia, fiume, canale). Scegli l'ente — la distanza "
            "di default si imposta da sola ed è modificabile — poi il layer sorgente "
            "e premi Genera. Il buffer è calcolato dal bordo dello shape. Le aree "
            "poligonali sono bufferizzate dal perimetro.\n\n"
            "Le voci stradali sono divise fra FUORI centro abitato (art. 26 DPR "
            "495/92) e DENTRO il centro abitato (art. 28): il discriminante è la "
            "delimitazione del centro abitato ex art. 4 CdS, da verificare sulla "
            "delibera comunale. Dentro il centro abitato, per le strade di tipo E "
            "ed F con PRG vigente la norma non fissa una distanza minima: vale lo "
            "strumento urbanistico. Verifica sempre la distanza con la norma o "
            "l'ente competente: i valori sono un punto di partenza."
        ))

        gb = self._gruppo("Fascia di rispetto", compresso=False)
        f = QFormLayout(gb)
        self.cb_fasce_ente = QComboBox()
        _ultimo_gruppo = None
        for nome, dist, nota in self.ENTI_FASCE:
            # separatore solo al cambio di macro-gruppo (FUORI / DENTRO / zona
            # edificabile / altri enti), non fra i singoli enti finali
            if nome.startswith("FUORI"):
                g = "fuori"
            elif nome.startswith("DENTRO"):
                g = "dentro"
            elif nome.startswith("Zona edificabile"):
                g = "zona"
            else:
                g = "altri"
            if _ultimo_gruppo is not None and g != _ultimo_gruppo:
                self.cb_fasce_ente.insertSeparator(self.cb_fasce_ente.count())
            _ultimo_gruppo = g
            self.cb_fasce_ente.addItem(nome, (dist, nota))
        self.cb_fasce_ente.currentIndexChanged.connect(self._fasce_ente_cambiato)
        f.addRow("Ente:", self.cb_fasce_ente)

        self.lbl_fasce_nota = QLabel("")
        self.lbl_fasce_nota.setWordWrap(True)
        self.lbl_fasce_nota.setStyleSheet("color: palette(mid); font-size: 11px;")
        f.addRow("", self.lbl_fasce_nota)

        self.spin_fasce_dist = self._dspin(0.5, 1000, 30, 1, " m", step=0.5)
        f.addRow("Distanza fascia:", self.spin_fasce_dist)

        self.cb_fasce_layer = self._lcombo(
            QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer)
        f.addRow("Shape sorgente (linea/poligono):", self.cb_fasce_layer)

        self.chk_fasce_solo_sel = QCheckBox(
            "Solo geometrie selezionate (se ce ne sono)")
        f.addRow("", self.chk_fasce_solo_sel)
        v.addWidget(gb)

        b = QPushButton("Genera fascia di rispetto")
        b.setStyleSheet("font-weight:bold")
        b.clicked.connect(self._fasce_genera)
        v.addWidget(b)

        self.log_fasce = QPlainTextEdit(); self.log_fasce.setReadOnly(True)
        self.log_fasce.setMinimumHeight(110)
        v.addWidget(self.log_fasce)
        v.addStretch()
        # inizializza nota/distanza sull'ente corrente
        self._fasce_ente_cambiato()
        return w

    def _log_fasce(self, msg):
        try:
            self.log_fasce.appendPlainText(str(msg))
        except Exception:
            pass

    def _fasce_ente_cambiato(self, *args):
        dato = self.cb_fasce_ente.currentData()
        if not dato:
            return
        dist, nota = dato
        # imposta la distanza di default solo se l'ente NON è 'Personalizzato'
        nome = self.cb_fasce_ente.currentText()
        if nome != "Personalizzato":
            self.spin_fasce_dist.setValue(dist)
        self.lbl_fasce_nota.setText("Riferimento: %s" % nota)

    def _fasce_genera(self):
        lyr = self.cb_fasce_layer.currentLayer()
        if lyr is None:
            QMessageBox.warning(self, "Nessuno shape",
                "Seleziona il layer sorgente (linea o poligono)."); return
        dist = self.spin_fasce_dist.value()
        if dist <= 0:
            QMessageBox.warning(self, "Distanza non valida",
                "La distanza della fascia deve essere maggiore di zero."); return
        ente = self.cb_fasce_ente.currentText()
        if not ente.strip() or self.cb_fasce_ente.currentData() is None:
            QMessageBox.warning(self, "Ente non valido",
                "Seleziona una voce dell'elenco enti (non un separatore)."); return
        solo_sel = self.chk_fasce_solo_sel.isChecked()

        # CRS di lavoro: metrico. Se il progetto è geografico (gradi) il buffer
        # in "metri" sarebbe sbagliato: uso il CRS del layer se metrico, altrimenti
        # riproietto in un CRS metrico (25832, coerente col resto del plugin).
        crs_lyr = lyr.crs()
        crs_prog = self.project.crs()
        if crs_lyr.isValid() and crs_lyr.mapUnits() == 0:  # 0 = metri
            crs_work = crs_lyr
        elif crs_prog.isValid() and crs_prog.mapUnits() == 0:
            crs_work = crs_prog
        else:
            crs_work = QgsCoordinateReferenceSystem("EPSG:25832")

        ctx = self.project.transformContext()
        tr_in = None
        if crs_lyr.isValid() and crs_lyr != crs_work:
            tr_in = QgsCoordinateTransform(crs_lyr, crs_work, ctx)

        feats = (lyr.selectedFeatures() if (solo_sel and lyr.selectedFeatureCount() > 0)
                 else lyr.getFeatures())
        geoms = []
        n_in = 0
        for ft in feats:
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            if tr_in is not None:
                g = QgsGeometry(g)
                g.transform(tr_in)
            geoms.append(g)
            n_in += 1
        if not geoms:
            QMessageBox.warning(self, "Nessuna geometria",
                "Lo shape sorgente non contiene geometrie valide."); return

        # unione + buffer unico (fascia continua). segments=12 = arco liscio.
        unione = QgsGeometry.unaryUnion(geoms)
        if unione is None or unione.isEmpty():
            QMessageBox.warning(self, "Buffer non calcolabile",
                "Impossibile unire le geometrie sorgente."); return
        buff = unione.buffer(dist, 12)
        if buff is None or buff.isEmpty():
            QMessageBox.warning(self, "Buffer vuoto",
                "Il buffer risultante è vuoto."); return

        # nome layer compatto: toglie il prefisso di gruppo e la classe fra parentesi
        et = ente
        for pref in ("FUORI c.a. — ", "DENTRO c.a. — ", "Zona edificabile f.c.a. — "):
            if et.startswith(pref):
                sigla = "fuori c.a." if pref.startswith("FUORI") else (
                    "in c.a." if pref.startswith("DENTRO") else "zona edif.")
                et = "%s (%s)" % (et[len(pref):], sigla)
                break
        else:
            et = et.split(" - ")[0]
        nome_layer = "Fascia di rispetto — %s %g m" % (et, dist)
        vl = QgsVectorLayer("Polygon?crs=" + crs_work.authid(), nome_layer, "memory")
        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("ente", QVariant.String),
            QgsField("distanza_m", QVariant.Double),
            QgsField("sorgente", QVariant.String),
        ])
        vl.updateFields()
        nf = QgsFeature(vl.fields())
        nf.setGeometry(buff)
        nf.setAttribute("ente", ente)
        nf.setAttribute("distanza_m", float(dist))
        nf.setAttribute("sorgente", lyr.name())
        pr.addFeatures([nf])
        vl.updateExtents()

        self._fasce_stile(vl, ente, dist)
        # rimuove un eventuale layer omonimo precedente, poi aggiunge in cima
        for l in list(self.project.mapLayers().values()):
            if l.name() == nome_layer:
                self.project.removeMapLayer(l.id())
        self.project.addMapLayer(vl)

        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
        self._log_fasce("Creata '%s' da %d geometrie di '%s' (CRS lavoro %s)."
                        % (nome_layer, n_in, lyr.name(), crs_work.authid()))
        QMessageBox.information(self, "Fascia creata",
            "Layer '%s' aggiunto al progetto.\n\nRicorda: la distanza è un valore "
            "di riferimento, verifica sempre con la norma o l'ente competente."
            % nome_layer)

    def _fasce_stile(self, vl, ente, dist):
        """Riempimento trasparente + bordo tratteggiato + etichetta ente/distanza,
        coerente con la fascia RFI."""
        try:
            sym = QgsFillSymbol.createSimple({
                "color": "255,60,60,30",          # rosso molto trasparente
                "outline_color": "200,0,0,255",
                "outline_width": "0.5",
                "outline_style": "dash",
            })
            vl.renderer().setSymbol(sym)
        except Exception:
            pass
        # etichetta: ente + distanza
        try:
            settings = QgsPalLayerSettings()
            settings.fieldName = "concat(\"ente\", ' — ', format_number(\"distanza_m\",0), ' m')"
            settings.isExpression = True
            tf = QgsTextFormat()
            fnt = QFont("Arial", 9); fnt.setBold(True)
            tf.setFont(fnt)
            tf.setColor(QColor(120, 0, 0))
            settings.setFormat(tf)
            settings.placement = QgsPalLayerSettings.PolygonInterior \
                if hasattr(QgsPalLayerSettings, "PolygonInterior") else 0
            vl.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            vl.setLabelsEnabled(True)
        except Exception:
            pass
        vl.triggerRepaint()
