# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Scheda 'Fasce di rispetto' (Altri Enti): dato uno shape (di solito lineare:
strada, ferrovia, fiume, canale...) genera il buffer della fascia di rispetto
dell'ente scelto. Il menu ente imposta la distanza di default (modificabile).

Mixin senza dipendenze dal dialog principale se non i helper _gruppo/_desc/
_lcombo/_dspin/_scrollable e self.project/self.iface, già presenti in
FTTHPermessiDialog.
"""
import re

from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsField, QgsFields, QgsProject,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
    QgsWkbTypes, QgsFillSymbol, QgsPalLayerSettings, QgsTextFormat,
    QgsVectorLayerSimpleLabeling, QgsMapLayerProxyModel,
)
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QComboBox, QPushButton, QMessageBox,
    QPlainTextEdit, QLabel, QCheckBox,
)


def _log_avviso(contesto, errore):
    """Traccia nel pannello 'Log dei messaggi' di QGIS le eccezioni non fatali
    di questa scheda. È una copia locale dell'omonima funzione del dialog
    principale: importarla da lì creerebbe un import circolare (il dialog
    importa questo mixin), e un errore ingoiato in silenzio qui significherebbe
    una fascia generata sul layer sbagliato senza che nessuno se ne accorga."""
    try:
        from qgis.core import Qgis, QgsMessageLog
        QgsMessageLog.logMessage("%s: %s" % (contesto, errore),
                                 "FTTH Permessi", level=Qgis.Warning)
    except Exception:
        pass  # il logging non deve mai diventare a sua volta causa di errore


class FasceMixin:
    # ente -> (distanza_default_m, riferimento normativo/nota)
    # Le voci sono raggruppate: FUORI centro abitato (art. 26 DPR 495/92),
    # DENTRO centro abitato (art. 28 DPR 495/92), poi gli altri enti.
    # Il discriminante è la delimitazione del centro abitato ex art. 4 CdS.
    ENTI_FASCE = [
        # ---- fuori centro abitato (art. 26 DPR 495/92) ----
        ("FUORI c.a. — Autostrada (tipo A)",        60, "Art. 26 DPR 495/92: 60 m, tipo A"),
        ("FUORI c.a. — ANAS / statale (tipo B)",    40, "Art. 26 DPR 495/92: 40 m, extraurbana principale"),
        ("FUORI c.a. — Provinciale (tipo C)",       30, "Art. 26 DPR 495/92: 30 m, extraurbana secondaria"),
        ("FUORI c.a. — Comunale/locale (tipo F)",   20, "Art. 26 DPR 495/92: 20 m, strade locali"),
        ("FUORI c.a. — Strada vicinale (tipo F)",   10, "Art. 26 DPR 495/92: 10 m, vicinali"),
        # ---- dentro centro abitato (art. 28 DPR 495/92) ----
        ("DENTRO c.a. — Autostrada (tipo A)",       30, "Art. 28 DPR 495/92: 30 m, tipo A"),
        ("DENTRO c.a. — Urbana scorrimento (D)",    20, "Art. 28 DPR 495/92: 20 m, tipo D"),
        ("DENTRO c.a. — Urbana quartiere (E)",      20, "Art. 28 c.3 DPR 495/92: 20 m SOLO senza strumento urbanistico; con PRG vigente non è stabilita (vale il PRG)"),
        ("DENTRO c.a. — Locale (tipo F)",           10, "Art. 28 c.3 DPR 495/92: 10 m SOLO senza strumento urbanistico; con PRG vigente non è stabilita (vale il PRG)"),
        ("DENTRO c.a. — Muri di cinta (tipo A)",     3, "Art. 28 c.4 DPR 495/92: 3 m, muri di cinta tipo A"),
        ("DENTRO c.a. — Muri di cinta (tipo D)",     2, "Art. 28 c.4 DPR 495/92: 2 m, muri di cinta tipo D"),
        # ---- zone edificabili fuori c.a. (art. 26 c.3 DPR 495/92) ----
        ("Zona edificabile f.c.a. — tipo A",        30, "Art. 26 c.3 DPR 495/92: 30 m in zone edificabili/PRG attuativo"),
        ("Zona edificabile f.c.a. — tipo B",        20, "Art. 26 c.3 DPR 495/92: 20 m in zone edificabili/PRG attuativo"),
        ("Zona edificabile f.c.a. — tipo C",        10, "Art. 26 c.3 DPR 495/92: 10 m in zone edificabili/PRG attuativo"),
        # ---- altri enti ----
        ("RFI - Ferrovia",                          30, "DPR 753/1980 art.49 (fascia 6-30 m)"),
        ("Fiume / Corso d'acqua",                   10, "R.D. 523/1904 (dal piede argine/sponda)"),
        ("Consorzio di bonifica",                   10, "Canale/opere (spesso 4-10 m)"),
        ("Cimitero",                               200, "R.D. 1265/1934 art.338"),
        ("Personalizzato",                          10, "Distanza libera"),
    ]

    # ------------------------------------------------------------------
    # Coerenza ente <-> layer sorgente.
    #
    # La fascia di rispetto si misura SEMPRE dall'opera dell'ente — la rotaia
    # più esterna per la ferrovia (DPR 753/1980 art. 49), il confine stradale
    # per le strade, la sponda/il piede d'argine per i corsi d'acqua — e MAI
    # dalla rete del richiedente. Bufferizzando per errore il layer
    # INFRASTRUTTURE con l'ente 'RFI - Ferrovia' esce un poligono ramificato
    # che ricalca la rete FTTH: non ha senso cartografico e, allegato a
    # un'istanza all'ente, è un errore grave. Da qui i due automatismi:
    # proporre il layer giusto quando si sceglie l'ente, e chiedere conferma
    # esplicita se si genera comunque sul layer sbagliato.
    # ------------------------------------------------------------------
    # tipo dedotto dal NOME dell'ente scelto in tendina
    _FASCE_RE_ENTE = (
        ("ferrovia", r"rfi|ferrovi|binari"),
        ("idro",     r"fiume|corso d'acqua|canale|bonifica"),
        # le voci stradali sono tutte quelle dei gruppi DPR 495/92
        ("strada",   r"autostrad|anas|statale|provincial|comunal|vicinal|"
                     r"urbana|locale|muri di cinta|strada|zona edificabile"),
    )
    # tipo dedotto dal NOME del layer sorgente. Un nome può ricadere in più
    # tipi ('Ferrovie e corsi acqua' dello screening è ferrovia E idro): la
    # coerenza si valuta per appartenenza, non per esclusione.
    _FASCE_RE_LAYER = (
        ("ferrovia",      r"ferrovi|binari|railway|\brail\b|\brfi\b|sedime ferroviar"),
        ("idro",          r"corsi acqua|corso d'acqua|fiume|torrente|canal|idro|"
                          r"reticolo|bonific|waterway"),
        ("strada",        r"strad|stradario|dbsn|viabilit|\banas\b|\bsp\b|\bss\b|"
                          r"\bsr\b|highway|\broad\b"),
        # rete del richiedente: è il layer che NON va mai bufferizzato come
        # fascia di rispetto di un ente terzo
        ("rete_progetto", r"infrastruttur|pozzett|armadi|\broe\b|civic|\bconi\b|"
                          r"\bcono\b|tratt|giunzion|cavid|minitub|sottotub|"
                          r"rete ftth|planimetr"),
    )
    # layer prodotti dallo screening territorio: sono la sorgente naturale,
    # scaricata da OpenStreetMap (ferrovie: way["railway"="rail"] della query
    # OVERPASS_ALTRO; strade: way["highway"]["ref"] di OVERPASS_STRADE).
    _FASCE_LAYER_SCREENING = {
        "ferrovia": "ferrovie e corsi acqua",
        "idro":     "ferrovie e corsi acqua",
        "strada":   "strade classificate",
    }
    # classe OSM/CdS del layer 'Strade classificate' -> lettera del tipo di
    # strada usata nelle voci di ENTI_FASCE. SR (regionale) è assimilata alla
    # extraurbana secondaria tipo C come la provinciale: cambia l'ente titolare
    # (Regione invece di Provincia), non la geometria della fascia.
    _FASCE_CLASSE_CDS = {
        "A": "A", "RA": "A",
        "SS": "B", "NSA": "B",
        "SP": "C", "SR": "C",
        "SC": "F",
    }
    # campi del layer stradale da cui leggere la classificazione, in ordine di
    # affidabilità: 'classe' è quello scritto dallo screening (già normalizzato),
    # 'ref' è la sigla grezza OSM/stradario da cui si ricava il prefisso.
    _FASCE_CAMPI_CLASSE = ("classe", "CLASSE", "ref", "REF")

    def _tab_fasce(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Genera la fascia di rispetto di un ente attorno a uno shape (di norma "
            "lineare: strada, ferrovia, fiume, canale). Scegli l'ente — la distanza "
            "di default si imposta da sola ed è modificabile — poi il layer sorgente "
            "e premi Genera. Il buffer è calcolato dal bordo dello shape. Le aree "
            "poligonali sono bufferizzate dal perimetro.\n\n"
            "Il layer sorgente dev'essere l'opera dell'ente — i binari per la "
            "ferrovia, l'asse/il sedime stradale per le strade, il corso "
            "d'acqua per il reticolo idrico — e MAI la rete in progetto "
            "(INFRASTRUTTURE, pozzetti, armadi, ROE): la fascia si misura "
            "dall'opera dell'ente. Scegliendo l'ente il layer coerente viene "
            "proposto da solo, se presente nel progetto (lo screening "
            "territorio crea 'Ferrovie e corsi acqua' e 'Strade "
            "classificate').\n\n"
            "Le voci stradali sono divise fra FUORI centro abitato (art. 26 DPR "
            "495/92) e DENTRO il centro abitato (art. 28): il discriminante è la "
            "delimitazione del centro abitato ex art. 4 CdS, da verificare sulla "
            "delibera comunale. Dentro il centro abitato, per le strade di tipo E "
            "ed F con PRG vigente la norma non fissa una distanza minima: vale lo "
            "strumento urbanistico. Verifica sempre la distanza con la norma o "
            "l'ente competente: i valori sono un punto di partenza."
        ))

        gb = self._gruppo("Fascia di rispetto", compresso=False)
        f = QFormLayout(gb)
        self.cb_fasce_ente = QComboBox()
        self._fasce_popola_enti(self.cb_fasce_ente)
        self.cb_fasce_ente.currentIndexChanged.connect(self._fasce_ente_cambiato)
        f.addRow("Ente:", self.cb_fasce_ente)

        self.lbl_fasce_nota = QLabel("")
        self.lbl_fasce_nota.setWordWrap(True)
        self.lbl_fasce_nota.setStyleSheet("color: palette(mid); font-size: 11px;")
        f.addRow("", self.lbl_fasce_nota)

        self.spin_fasce_dist = self._dspin(0.5, 1000, 30, 1, " m", step=0.5)
        f.addRow("Distanza fascia:", self.spin_fasce_dist)

        self.cb_fasce_layer = self._lcombo(
            QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer)
        # cambiando il layer stradale si prova a riallineare la voce dell'ente
        # alla classe della strada letta dagli attributi
        try:
            self.cb_fasce_layer.layerChanged.connect(self._fasce_layer_cambiato)
        except Exception as e:
            _log_avviso("aggancio layerChanged della scheda fasce non riuscito", e)
        f.addRow("Shape sorgente (linea/poligono):", self.cb_fasce_layer)

        self.chk_fasce_solo_sel = QCheckBox(
            "Solo geometrie selezionate (se ce ne sono)")
        f.addRow("", self.chk_fasce_solo_sel)
        v.addWidget(gb)

        b = QPushButton("Genera fascia di rispetto")
        b.setStyleSheet("font-weight:bold")
        b.clicked.connect(self._fasce_genera)
        v.addWidget(b)

        self.log_fasce = QPlainTextEdit(); self.log_fasce.setReadOnly(True)
        self.log_fasce.setMinimumHeight(110)
        v.addWidget(self.log_fasce)
        v.addStretch()
        # inizializza nota/distanza sull'ente corrente
        self._fasce_ente_cambiato()
        return w

    def _log_fasce(self, msg):
        try:
            self.log_fasce.appendPlainText(str(msg))
        except Exception:
            pass

    def _fasce_popola_enti(self, combo):
        """Riempie la tendina degli enti con i separatori fra i macro-gruppi
        (FUORI / DENTRO centro abitato / zona edificabile / altri enti).
        Estratta dal costruttore della scheda perché la stessa tendina serve
        anche fuori dall'interfaccia completa (test headless)."""
        _ultimo_gruppo = None
        for nome, dist, nota in self.ENTI_FASCE:
            # separatore solo al cambio di macro-gruppo, non fra i singoli enti
            if nome.startswith("FUORI"):
                g = "fuori"
            elif nome.startswith("DENTRO"):
                g = "dentro"
            elif nome.startswith("Zona edificabile"):
                g = "zona"
            else:
                g = "altri"
            if _ultimo_gruppo is not None and g != _ultimo_gruppo:
                combo.insertSeparator(combo.count())
            _ultimo_gruppo = g
            combo.addItem(nome, (dist, nota))

    # ------------------------------------------------------------------
    # riconoscimento ente / layer
    # ------------------------------------------------------------------
    def _fasce_tipo_ente(self, nome_ente):
        """Tipo di opera da cui si misura la fascia: 'ferrovia', 'strada',
        'idro' o None (es. 'Cimitero', 'Personalizzato': nessun vincolo di
        coerenza sensato, quindi nessun automatismo)."""
        n = (nome_ente or "").lower()
        for tipo, pat in self._FASCE_RE_ENTE:
            if re.search(pat, n):
                return tipo
        return None

    def _fasce_tipi_layer(self, nome_layer):
        """Insieme dei tipi riconosciuti dal nome del layer. Un nome può
        valerne più d'uno ('Ferrovie e corsi acqua' dello screening contiene
        sia le rotaie sia i corsi d'acqua), e 'rete_progetto' marca i layer
        del richiedente (INFRASTRUTTURE, pozzetti, armadi, ROE, civici, coni)
        che non sono mai la sorgente di una fascia di rispetto altrui."""
        n = (nome_layer or "").lower()
        return {tipo for tipo, pat in self._FASCE_RE_LAYER if re.search(pat, n)}

    def _fasce_layer_candidati(self, tipo):
        """Layer vettoriali linea/poligono del progetto coerenti col tipo di
        ente, in ordine di preferenza: prima quelli dello screening territorio
        (scaricati da OpenStreetMap: 'Ferrovie e corsi acqua' per la ferrovia,
        'Strade classificate' per le strade), poi gli altri nomi coerenti.
        I layer della rete in progetto sono esclusi a priori."""
        preferito = self._FASCE_LAYER_SCREENING.get(tipo, "")
        scelti = []
        try:
            layers = list(self.project.mapLayers().values())
        except Exception as e:
            _log_avviso("lettura dei layer di progetto per la scheda fasce", e)
            return []
        for lyr in layers:
            try:
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                    continue
                if lyr.geometryType() not in (QgsWkbTypes.LineGeometry,
                                              QgsWkbTypes.PolygonGeometry):
                    continue
                tipi = self._fasce_tipi_layer(lyr.name())
                if tipo not in tipi or "rete_progetto" in tipi:
                    continue
                punteggio = 0 if preferito and preferito in lyr.name().lower() else 1
                scelti.append((punteggio, lyr.name().lower(), lyr))
            except Exception as e:
                _log_avviso("valutazione del layer '%s' per la scheda fasce"
                            % getattr(lyr, "name", lambda: "?")(), e)
        scelti.sort(key=lambda t: (t[0], t[1]))
        return [t[2] for t in scelti]

    def _fasce_ente_cambiato(self, *args):
        dato = self.cb_fasce_ente.currentData()
        if not dato:
            return
        dist, nota = dato
        # imposta la distanza di default solo se l'ente NON è 'Personalizzato'
        nome = self.cb_fasce_ente.currentText()
        if nome != "Personalizzato":
            self.spin_fasce_dist.setValue(dist)
        self.lbl_fasce_nota.setText("Riferimento: %s" % nota)
        self._fasce_proponi_layer(nome)

    def _fasce_proponi_layer(self, nome_ente):
        """Propone il layer sorgente coerente con l'ente appena scelto.

        Serve a non arrivare al pulsante Genera con la rete in progetto
        selezionata: scegliendo 'RFI - Ferrovia' il candidato naturale è il
        layer delle ferrovie (quello dello screening territorio, se c'è),
        non INFRASTRUTTURE. Se il layer già selezionato è coerente non si
        tocca nulla, e se non esiste alcun candidato si lascia la scelta
        dell'utente com'è: la proposta non deve mai peggiorare la situazione."""
        tipo = self._fasce_tipo_ente(nome_ente)
        if tipo is None:
            return
        try:
            attuale = self.cb_fasce_layer.currentLayer()
            if attuale is not None:
                tipi = self._fasce_tipi_layer(attuale.name())
                if tipo in tipi and "rete_progetto" not in tipi:
                    return  # già coerente: nessun motivo di cambiarlo
            candidati = self._fasce_layer_candidati(tipo)
            if not candidati:
                return
            self._fasce_in_preselezione = True
            try:
                self.cb_fasce_layer.setLayer(candidati[0])
            finally:
                self._fasce_in_preselezione = False
            self._log_fasce("Layer sorgente proposto per '%s': '%s'."
                            % (nome_ente, candidati[0].name()))
        except Exception as e:
            _log_avviso("proposta del layer sorgente per l'ente '%s'" % nome_ente, e)

    # ------------------------------------------------------------------
    # classificazione stradale dedotta dagli attributi
    # ------------------------------------------------------------------
    def _fasce_classe_strada(self, lyr):
        """Lettera del tipo di strada (A/B/C/F del CdS) deducibile DAGLI
        ATTRIBUTI del layer, oppure None.

        Legge il campo 'classe' prodotto dallo screening territorio (valori
        normalizzati A/RA/SS/NSA/SP/SR/SC) o, in mancanza, il prefisso del
        campo 'ref'. Se ci sono geometrie selezionate guarda solo quelle,
        altrimenti tutto il layer: se le classi presenti non sono tutte uguali
        non si deduce niente, perché una fascia unica su classi diverse
        sarebbe sbagliata per qualcuna di esse.

        Attenzione: dagli attributi NON si ricava se la strada è dentro o
        fuori il centro abitato (art. 4 CdS). La proposta è quindi sempre la
        voce FUORI centro abitato, che è la distanza maggiore e va confermata
        dal progettista sulla delibera comunale."""
        if lyr is None:
            return None
        try:
            nomi = [f.name() for f in lyr.fields()]
        except Exception as e:
            _log_avviso("lettura dei campi del layer stradale", e)
            return None
        campo = next((c for c in self._FASCE_CAMPI_CLASSE if c in nomi), None)
        if campo is None:
            return None
        try:
            feats = (lyr.selectedFeatures() if lyr.selectedFeatureCount() > 0
                     else lyr.getFeatures())
            lettere = set()
            for i, ft in enumerate(feats):
                if i > 20000:      # limite di guardia su stradari molto grandi
                    break
                v = ft[campo]
                if v is None:
                    continue
                sigla = re.match(r"\s*([A-Za-z]+)", str(v))
                if not sigla:
                    continue
                lettere.add(self._FASCE_CLASSE_CDS.get(sigla.group(1).upper()))
            lettere.discard(None)
            if len(lettere) == 1:
                return lettere.pop()
        except Exception as e:
            _log_avviso("deduzione della classe stradale dagli attributi", e)
        return None

    def _fasce_layer_cambiato(self, *args):
        """Allinea la voce dell'ente alla classe della strada selezionata.

        Vale solo per i layer stradali con la classificazione negli attributi
        (es. 'Strade classificate' dello screening): senza quel dato la classe
        resta una scelta manuale e non si inventa nulla. Non sovrascrive una
        scelta già coerente: se l'utente ha indicato DENTRO il centro abitato
        per la stessa classe, quella informazione non è negli attributi e deve
        restare la sua."""
        if getattr(self, "_fasce_in_preselezione", False):
            return
        try:
            lyr = self.cb_fasce_layer.currentLayer()
            if lyr is None or "strada" not in self._fasce_tipi_layer(lyr.name()):
                return
            lettera = self._fasce_classe_strada(lyr)
            if lettera is None:
                return
            corrente = self.cb_fasce_ente.currentText()
            if self._fasce_tipo_ente(corrente) == "strada" \
                    and "(tipo %s)" % lettera in corrente:
                return  # classe già giusta: fuori/dentro c.a. lo decide l'utente
            voce = next((n for n, _d, _nt in self.ENTI_FASCE
                         if n.startswith("FUORI") and "(tipo %s)" % lettera in n), None)
            if voce is None:
                return
            idx = self.cb_fasce_ente.findText(voce)
            if idx < 0:
                return
            self._fasce_in_preselezione = True
            try:
                self.cb_fasce_ente.setCurrentIndex(idx)
            finally:
                self._fasce_in_preselezione = False
            dato = self.cb_fasce_ente.currentData()
            if dato:
                self.spin_fasce_dist.setValue(dato[0])
                self.lbl_fasce_nota.setText("Riferimento: %s" % dato[1])
            self._log_fasce(
                "Classe letta dagli attributi di '%s': tipo %s -> proposta '%s'. "
                "Verifica se il tratto è dentro il centro abitato (art. 4 CdS): "
                "dagli attributi non si ricava."
                % (lyr.name(), lettera, voce))
        except Exception as e:
            _log_avviso("preselezione dell'ente dalla classe stradale", e)

    def _fasce_conferma_incoerenza(self, ente, lyr):
        """True se si può procedere. Blocca con una domanda esplicita il caso
        che ha motivato il controllo: fascia ferroviaria (o stradale, o
        idraulica) bufferizzata sulla rete FTTH in progetto. Non è un divieto:
        chi sa cosa sta facendo conferma e va avanti, ma il default è No."""
        tipo_ente = self._fasce_tipo_ente(ente)
        if tipo_ente is None or lyr is None:
            return True
        tipi = self._fasce_tipi_layer(lyr.name())
        if tipo_ente in tipi and "rete_progetto" not in tipi:
            return True
        origine = {"ferrovia": "dalla rotaia più esterna dei binari",
                   "strada": "dal confine stradale",
                   "idro": "dalla sponda o dal piede dell'argine"}[tipo_ente]
        if "rete_progetto" in tipi:
            testo = (
                "Ente scelto: «%s».\nLayer sorgente: «%s».\n\n"
                "«%s» è la rete in progetto, non l'opera dell'ente: la fascia "
                "di rispetto si misura %s, non dalla rete del richiedente.\n\n"
                "Procedendo ottieni un poligono che segue il tracciato FTTH: "
                "non è la fascia di rispetto e in un'istanza all'ente è un "
                "errore.\n\nGenerare lo stesso la fascia su «%s»?"
                % (ente, lyr.name(), lyr.name(), origine, lyr.name()))
        else:
            testo = (
                "Ente scelto: «%s».\nLayer sorgente: «%s».\n\n"
                "Il nome del layer non sembra quello dell'opera da cui si "
                "misura la fascia (%s). Controlla di non aver lasciato "
                "selezionato il layer di un'altra scheda.\n\n"
                "Generare lo stesso la fascia su «%s»?"
                % (ente, lyr.name(), origine, lyr.name()))
        risposta = QMessageBox.question(
            self, "Layer sorgente incoerente con l'ente", testo,
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if risposta != QMessageBox.Yes:
            self._log_fasce("Generazione annullata: '%s' non è coerente con "
                            "l'ente '%s'." % (lyr.name(), ente))
            return False
        self._log_fasce("Forzatura confermata dall'utente: fascia '%s' generata "
                        "su '%s'." % (ente, lyr.name()))
        return True

    def _fasce_genera(self):
        lyr = self.cb_fasce_layer.currentLayer()
        if lyr is None:
            QMessageBox.warning(self, "Nessuno shape",
                "Seleziona il layer sorgente (linea o poligono)."); return
        dist = self.spin_fasce_dist.value()
        if dist <= 0:
            QMessageBox.warning(self, "Distanza non valida",
                "La distanza della fascia deve essere maggiore di zero."); return
        ente = self.cb_fasce_ente.currentText()
        if not ente.strip() or self.cb_fasce_ente.currentData() is None:
            QMessageBox.warning(self, "Ente non valido",
                "Seleziona una voce dell'elenco enti (non un separatore)."); return
        solo_sel = self.chk_fasce_solo_sel.isChecked()

        # ultimo filtro prima di scrivere il layer: se il layer sorgente non è
        # l'opera dell'ente (tipicamente è la rete in progetto) la fascia che
        # ne esce è priva di senso, quindi serve una conferma esplicita
        if not self._fasce_conferma_incoerenza(ente, lyr):
            return

        # CRS di lavoro: metrico. Se il progetto è geografico (gradi) il buffer
        # in "metri" sarebbe sbagliato: uso il CRS del layer se metrico, altrimenti
        # riproietto in un CRS metrico (25832, coerente col resto del plugin).
        crs_lyr = lyr.crs()
        crs_prog = self.project.crs()
        if crs_lyr.isValid() and crs_lyr.mapUnits() == 0:  # 0 = metri
            crs_work = crs_lyr
        elif crs_prog.isValid() and crs_prog.mapUnits() == 0:
            crs_work = crs_prog
        else:
            crs_work = QgsCoordinateReferenceSystem("EPSG:25832")

        ctx = self.project.transformContext()
        tr_in = None
        if crs_lyr.isValid() and crs_lyr != crs_work:
            tr_in = QgsCoordinateTransform(crs_lyr, crs_work, ctx)

        feats = (lyr.selectedFeatures() if (solo_sel and lyr.selectedFeatureCount() > 0)
                 else lyr.getFeatures())
        geoms = []
        n_in = 0
        for ft in feats:
            g = ft.geometry()
            if not g or g.isEmpty():
                continue
            if tr_in is not None:
                g = QgsGeometry(g)
                g.transform(tr_in)
            geoms.append(g)
            n_in += 1
        if not geoms:
            QMessageBox.warning(self, "Nessuna geometria",
                "Lo shape sorgente non contiene geometrie valide."); return

        # unione + buffer unico (fascia continua). segments=12 = arco liscio.
        unione = QgsGeometry.unaryUnion(geoms)
        if unione is None or unione.isEmpty():
            QMessageBox.warning(self, "Buffer non calcolabile",
                "Impossibile unire le geometrie sorgente."); return
        buff = unione.buffer(dist, 12)
        if buff is None or buff.isEmpty():
            QMessageBox.warning(self, "Buffer vuoto",
                "Il buffer risultante è vuoto."); return

        # nome layer compatto: toglie il prefisso di gruppo e la classe fra parentesi
        et = ente
        for pref in ("FUORI c.a. — ", "DENTRO c.a. — ", "Zona edificabile f.c.a. — "):
            if et.startswith(pref):
                sigla = "fuori c.a." if pref.startswith("FUORI") else (
                    "in c.a." if pref.startswith("DENTRO") else "zona edif.")
                et = "%s (%s)" % (et[len(pref):], sigla)
                break
        else:
            et = et.split(" - ")[0]
        nome_layer = "Fascia di rispetto — %s %g m" % (et, dist)
        vl = QgsVectorLayer("Polygon?crs=" + crs_work.authid(), nome_layer, "memory")
        pr = vl.dataProvider()
        pr.addAttributes([
            QgsField("ente", QVariant.String),
            QgsField("distanza_m", QVariant.Double),
            QgsField("sorgente", QVariant.String),
        ])
        vl.updateFields()
        nf = QgsFeature(vl.fields())
        nf.setGeometry(buff)
        nf.setAttribute("ente", ente)
        nf.setAttribute("distanza_m", float(dist))
        nf.setAttribute("sorgente", lyr.name())
        pr.addFeatures([nf])
        vl.updateExtents()

        self._fasce_stile(vl, ente, dist)
        # rimuove un eventuale layer omonimo precedente, poi aggiunge in cima
        for l in list(self.project.mapLayers().values()):
            if l.name() == nome_layer:
                self.project.removeMapLayer(l.id())
        self.project.addMapLayer(vl)

        try:
            self.iface.mapCanvas().refresh()
        except Exception:
            pass
        self._log_fasce("Creata '%s' da %d geometrie di '%s' (CRS lavoro %s)."
                        % (nome_layer, n_in, lyr.name(), crs_work.authid()))
        QMessageBox.information(self, "Fascia creata",
            "Layer '%s' aggiunto al progetto.\n\nRicorda: la distanza è un valore "
            "di riferimento, verifica sempre con la norma o l'ente competente."
            % nome_layer)

    def _fasce_stile(self, vl, ente, dist):
        """Riempimento trasparente + bordo tratteggiato + etichetta ente/distanza,
        coerente con la fascia RFI."""
        try:
            sym = QgsFillSymbol.createSimple({
                "color": "255,60,60,30",          # rosso molto trasparente
                "outline_color": "200,0,0,255",
                "outline_width": "0.5",
                "outline_style": "dash",
            })
            vl.renderer().setSymbol(sym)
        except Exception:
            pass
        # etichetta: ente + distanza
        try:
            settings = QgsPalLayerSettings()
            settings.fieldName = "concat(\"ente\", ' — ', format_number(\"distanza_m\",0), ' m')"
            settings.isExpression = True
            tf = QgsTextFormat()
            fnt = QFont("Arial", 9); fnt.setBold(True)
            tf.setFont(fnt)
            tf.setColor(QColor(120, 0, 0))
            settings.setFormat(tf)
            settings.placement = QgsPalLayerSettings.PolygonInterior \
                if hasattr(QgsPalLayerSettings, "PolygonInterior") else 0
            vl.setLabeling(QgsVectorLayerSimpleLabeling(settings))
            vl.setLabelsEnabled(True)
        except Exception:
            pass
        vl.triggerRepaint()
