# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Pannello Layer di QGIS in ordine: i gruppi e i layer creati dal plugin
stanno in due gruppi, «Comunale» e «Altri enti» (con un sottogruppo per ente:
Strade, RFI, Acque, Soprintendenza, Parchi e Natura 2000, Rilievo, Screening).

I layer principali del progetto (03 INFRASTRUTTURE, 02_POZZETTO, …) non si
spostano. Si spostano solo i gruppi/layer del plugin che stanno al primo
livello del pannello: quelli che l'utente ha già messo altrove restano dove
sono. Il codice del plugin trova i suoi gruppi anche dentro i nuovi gruppi
(la ricerca per nome di QGIS guarda in tutto l'albero)."""

import re

COMUNALE = "Comunale"
ALTRI = "Altri enti"
ENTI = {"strade": "Strade", "rfi": "RFI", "acque": "Acque", "sopr": "Soprintendenza",
        "parchi": "Parchi e Natura 2000", "rilievo": "Rilievo (foto, sezioni, etichette)",
        "screening": "Screening"}

# gruppi del plugin al primo livello -> dove vanno
_GRUPPI = {
    "Elementi su suolo comunale": (COMUNALE, None),
    "RFI - Ferrovie": (ALTRI, "rfi"),
    "RFI - basi per le tavole": (ALTRI, None),      # nome di prima
    "Basi per le tavole (PL)": (ALTRI, None),
    "Acque - Demanio idrico e marittimo": (ALTRI, "acque"),
    "Soprintendenza - Aree vincolate": (ALTRI, "sopr"),
    "Parchi e Natura 2000": (ALTRI, "parchi"),
}
# layer del plugin al primo livello -> dove vanno
_LAYER = {
    "Cono di Ripresa": (COMUNALE, None),
    "Verifica interferenze - ferrovie, acque, ANAS (OSM)": (COMUNALE, None),
    "Verifica interferenze - fasce di rispetto": (COMUNALE, None),
    "Punto di Ripresa Fotografico": (COMUNALE, None),
    "Sezioni": (COMUNALE, None),
    "Cono di Ripresa (istanze)": (ALTRI, "rilievo"),
    "Etichette PL (spostabili)": (ALTRI, "rilievo"),
    "Cippi_Ferrovia": (ALTRI, "rfi"),
    "Cippi_Chilometrici": (ALTRI, "strade"),
}


def gruppo(radice, principale, ente=None):
    """Gruppo «Comunale» / «Altri enti» (e il sottogruppo dell'ente),
    creato se manca. Cerca solo fra i figli diretti, per non confondersi con
    gruppi omonimi altrove."""
    g = next((c for c in radice.children()
              if hasattr(c, "name") and c.name() == principale and _e_gruppo(c)), None)
    if g is None:
        g = radice.insertGroup(0, principale)
        g.setExpanded(False)        # gruppi nuovi chiusi: il pannello non si apre da solo
    if ente is None:
        return g
    nome = ENTI.get(ente, ente)
    s = next((c for c in g.children() if _e_gruppo(c) and c.name() == nome), None)
    if s is None:
        s = g.addGroup(nome)
        s.setExpanded(False)
    return s


def _e_gruppo(n):
    from qgis.core import QgsLayerTree
    return QgsLayerTree.isGroup(n)


def _sposta(nodo, dest):
    """Sposta un nodo dell'albero dentro `dest` (in coda), mantenendo
    visibilità e stato aperto/chiuso."""
    padre = nodo.parent()
    copia = nodo.clone()
    dest.addChildNode(copia)
    padre.removeChildNode(nodo)


def _unisci(nodo, dest):
    """Mette `nodo` dentro `dest`; se lì c'è già un gruppo con lo stesso nome,
    ne unisce il contenuto (niente «Strade» dentro «Strade»)."""
    from qgis.core import QgsLayerTree
    if QgsLayerTree.isGroup(nodo):
        gemello = next((c for c in dest.children() if _e_gruppo(c) and c.name() == nodo.name()),
                       None)
        if gemello is not None:
            for c in list(nodo.children()):
                _unisci(c, gemello)
            nodo.parent().removeChildNode(nodo)
            return
    _sposta(nodo, dest)


def ordina_pannello(project):
    """Sposta i gruppi e i layer del plugin che stanno al primo livello.
    Ritorna quanti nodi ha spostato."""
    from qgis.core import QgsLayerTree
    radice = project.layerTreeRoot()
    try:
        from . import ftth_gruppi_istanze as GR
        radice_ist = GR.RADICE
        sezioni = {v: k for k, v in GR.SEZIONI.items()}
    except Exception:  # noqa: BLE001
        radice_ist, sezioni = "Istanze", {}
    n = 0
    for nodo in list(radice.children()):
        nome = nodo.name()
        if QgsLayerTree.isGroup(nodo):
            if nome in (COMUNALE, ALTRI):
                continue
            if nome == radice_ist:
                # «Istanze» del plugin: ogni sezione nel suo ente
                for sub in list(nodo.children()):
                    ente = sezioni.get(sub.name())
                    if QgsLayerTree.isGroup(sub) and ente:
                        # il contenuto della sezione va direttamente nell'ente
                        dest = gruppo(radice, ALTRI, ente)
                        for c in list(sub.children()):
                            _unisci(c, dest)
                        nodo.removeChildNode(sub)
                        n += 1
                if not nodo.children():
                    radice.removeChildNode(nodo)
                continue
            if nome in _GRUPPI:
                p, e = _GRUPPI[nome]
                if nome == "RFI - basi per le tavole":
                    nodo.setName("Basi per le tavole (PL)")
                _unisci(nodo, gruppo(radice, p, e))
                n += 1
            elif nome.startswith("Screening "):
                _sposta(nodo, gruppo(radice, ALTRI, "screening"))
                n += 1
        elif QgsLayerTree.isLayer(nodo) and nome in _LAYER:
            p, e = _LAYER[nome]
            _sposta(nodo, gruppo(radice, p, e))
            n += 1
        elif QgsLayerTree.isLayer(nodo) and nome.startswith(_PER_ENTE):
            # foto, sezioni, coni ed etichette di un ente (o di una sua
            # istanza) nel gruppo dell'ente: dentro RFI tutto ciò che è di RFI
            _sposta(nodo, gruppo(radice, ALTRI, _ente_del_nome(nome) or "rilievo"))
            n += 1
    # quelli già finiti in «Rilievo» (versioni precedenti) vanno nel loro ente
    alt = next((c for c in radice.children() if _e_gruppo(c) and c.name() == ALTRI), None)
    ril = next((c for c in alt.children() if _e_gruppo(c) and c.name() == ENTI["rilievo"]),
               None) if alt is not None else None
    if ril is not None:
        for nodo in list(ril.children()):
            if QgsLayerTree.isLayer(nodo) and nodo.name().startswith(_PER_ENTE):
                ente = _ente_del_nome(nodo.name())
                if ente:
                    _sposta(nodo, gruppo(radice, ALTRI, ente))
                    n += 1
        if not ril.children():
            alt.removeChildNode(ril)
    return n


_PER_ENTE = ("Punto di Ripresa Fotografico - ", "Sezioni - ", "Etichette PL (spostabili) - ",
             "Cono di Ripresa (istanze) - ")


def _ente_del_nome(nome):
    """Ente di «<layer> - RFI» o «<layer> - <istanza di RFI>»; None se non si sa."""
    resto = nome.split(" - ", 1)[1] if " - " in nome else ""
    try:
        from . import ftth_rfi_layout as _L
        return next((e for e, s in _L.ENTI_LAYER.items()
                     if resto == s or _L.di_ente(e, resto)), None)
    except Exception:  # noqa: BLE001
        return None


_STATO = {"collegato": False, "in_attesa": False}


def collega(project):
    """Riordina a ogni layer aggiunto (dopo che il plugin l'ha messo nel suo
    gruppo) e all'apertura del progetto."""
    if _STATO["collegato"]:
        return
    from qgis.PyQt.QtCore import QTimer

    def _dopo(*_a):
        if _STATO["in_attesa"]:
            return
        _STATO["in_attesa"] = True

        def _fai():
            _STATO["in_attesa"] = False
            try:
                ordina_pannello(project)
            except Exception:  # noqa: BLE001
                pass
        QTimer.singleShot(0, _fai)
    try:
        project.layersAdded.connect(_dopo)
        project.readProject.connect(_dopo)
        _STATO["collegato"] = True
    except Exception:  # noqa: BLE001
        pass


# gruppi di cartografia comune a tutti: restano fuori da «Comunale»
_BASI = re.compile(r"mappa|cartograf|sfondo|catast|confin|layout|basemap|ortofoto|"
                   r"rete stradale|openstreetmap|google|esri", re.I)


def dividi_per_gruppi(project):
    """«Dividi per gruppi» (Vista istanze): tutto il progetto comunale
    (Permesso, Ottico, Foto…) va nel gruppo «Comunale»; nasce «Altri enti»
    per le istanze; le cartografie comuni restano fuori. Ritorna
    (spostati in Comunale, rimasti fuori)."""
    from qgis.core import QgsLayerTree
    ordina_pannello(project)                   # gruppi/layer del plugin
    radice = project.layerTreeRoot()
    com = gruppo(radice, COMUNALE)
    gruppo(radice, ALTRI)
    spostati, fuori = [], []
    for nodo in list(radice.children()):
        nome = nodo.name()
        if nome in (COMUNALE, ALTRI):
            continue
        if _BASI.search(nome):
            fuori.append(nome)
            continue
        _sposta(nodo, com)
        spostati.append(nome)
    # i due gruppi in cima, nell'ordine Comunale, Altri enti
    for nome in (ALTRI, COMUNALE):
        g = next((c for c in radice.children() if QgsLayerTree.isGroup(c) and c.name() == nome),
                 None)
        if g is not None and radice.children().index(g) != 0:
            copia = g.clone()
            radice.insertChildNode(0, copia)
            radice.removeChildNode(g)
    return spostati, fuori


# --------------------------------------------------- «Solo comunale»
_ORIG = {}          # id layer -> renderer originale (per rimetterlo)
PROP_FILTRO = "ftth/filtro_comunale_orig"


def _condizione(lyr):
    """Elementi senza nessuna istanza: tutti i campi IST_* vuoti."""
    try:
        from . import ftth_gruppi_istanze as GR
        campi = list(GR.CAMPI.values())
    except Exception:  # noqa: BLE001
        campi = ["IST_STRADE", "IST_ACQUE", "IST_FERROV", "IST_SOPR", "IST_PARCHI"]
    pezzi = ['("%s" IS NULL OR trim("%s") = \'\')' % (c, c) for c in campi
             if lyr.fields().indexOf(c) >= 0]
    return " AND ".join(pezzi)


def filtro_comunale(project, attivo: bool):
    """Mostra sui layer VERI (03 INFRASTRUTTURE, 02_POZZETTO, 01_ARMADIO
    OTTICO) solo gli elementi comunali, cioè senza istanza: è solo un filtro
    di disegno (regola della simbologia), i dati restano tutti e generazioni ed
    esportazioni continuano a vederli. Con attivo=False rimette la simbologia
    originale (anche se il progetto era stato salvato con il filtro)."""
    from qgis.core import QgsMapLayerStyle, QgsRuleBasedRenderer
    try:
        from . import ftth_gruppi_istanze as GR
        nomi = [n for _c, n, _t in GR.LAYER]
        principale = lambda n: GR.layer_principale(project, n)  # noqa: E731
    except Exception:  # noqa: BLE001
        nomi = ["03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO"]
        principale = lambda n: next(iter(project.mapLayersByName(n)), None)  # noqa: E731
    n = 0
    for nome in nomi:
        lyr = principale(nome)
        if lyr is None:
            continue
        salvato = lyr.customProperty(PROP_FILTRO)
        # prima si rimette sempre la simbologia originale
        if lyr.id() in _ORIG:
            lyr.setRenderer(_ORIG.pop(lyr.id()))
        elif salvato:
            st = QgsMapLayerStyle(salvato)
            st.writeToLayer(lyr)
        if salvato:
            lyr.removeCustomProperty(PROP_FILTRO)
        if attivo:
            cond = _condizione(lyr)
            if not cond or lyr.renderer() is None:
                lyr.triggerRepaint()
                continue
            st = QgsMapLayerStyle()
            st.readFromLayer(lyr)
            lyr.setCustomProperty(PROP_FILTRO, st.xmlData())
            _ORIG[lyr.id()] = lyr.renderer().clone()
            rb = QgsRuleBasedRenderer.convertFromRenderer(lyr.renderer())
            if rb is None:
                continue
            for regola in rb.rootRule().children():
                f = regola.filterExpression()
                regola.setFilterExpression(cond if not f else "(%s) AND (%s)" % (cond, f))
            lyr.setRenderer(rb)
            n += 1
        lyr.triggerRepaint()
    return n
