# -*- coding: utf-8 -*-
"""FTTH Permessi Manager  v0.71"""
import os, math, json, re, unicodedata, urllib.request, urllib.parse, urllib.error

# versione ricavata dalla docstring del modulo, che è l'unico posto in cui va
# aggiornata (e che lo script di rilascio riscrive da sé): compare nel titolo
# della finestra, così a colpo d'occhio si sa quale versione sta girando
_m_versione = re.search(r"v(\d+(?:\.\d+)*)", __doc__ or "")
VERSIONE = _m_versione.group(1) if _m_versione else "sconosciuta"

from qgis.PyQt.QtCore import Qt, QVariant, QSettings, QSizeF
from qgis.PyQt.QtGui import QTransform, QFont, QColor
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QTabWidget, QWidget,
    QLabel, QPushButton, QCheckBox, QDoubleSpinBox, QSpinBox, QPlainTextEdit,
    QGroupBox, QMessageBox, QSizePolicy, QFileDialog, QLineEdit, QComboBox,
    QScrollArea, QApplication, QListWidget, QListWidgetItem, QAbstractItemView,
    QToolButton, QGridLayout, QFontComboBox, QTextBrowser,
)
from qgis.core import (
    QgsWkbTypes, QgsSpatialIndex, QgsFeatureRequest, QgsFeature,
    QgsPointXY, QgsRectangle, QgsGeometry, QgsCoordinateTransform,
    QgsVectorLayer, QgsField, QgsVectorFileWriter, QgsCoordinateReferenceSystem,
    QgsExpression, QgsExpressionContext, QgsExpressionContextUtils,
    QgsLayoutExporter, QgsLayoutRenderContext,
    QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QgsTextFormat,
    QgsTextBufferSettings, QgsTextBackgroundSettings, QgsTextShadowSettings,
    QgsUnitTypes,
    QgsLineSymbol, QgsFillSymbol, QgsSingleSymbolRenderer,
)
from qgis.gui import QgsMapLayerComboBox, QgsMapTool, QgsFieldComboBox
from qgis.core import QgsMapLayerProxyModel

# ── costanti modello dati ──────────────────────────────────────────
CAMPO_TIP_INFRA   = "TIPOLOGIA"
VAL_AEREA         = "Aerea"
CAMPO_STATO       = "STATO"
VAL_NUOVO         = "Nuovo"
CAMPO_TIPO_PTE    = "TIPO"
VALORI_PTE_INT    = ["Interno Edificio", "Muro Interno"]
CAMPO_TIP_PTE     = "TIPOLOGIA"
VAL_PTE_LIGHT     = "PTE Light Diramatore"
CAMPO_ROT         = "Rotazione"
CAMPO_ID_TAVOLA   = "ID_Tavola"
CAMPO_LUNGHEZZA   = "LUNGHEZZA"
CAMPO_LUNGH_NEW   = "Lungh"
VAL_NO_DIG        = "No Dig"
CAMPO_CIVICO      = "CIVICO"
VAL_CIVICO_999    = "999"
VAL_CIVICO_SNC    = "SNC"


class _UF:
    def __init__(self, ids):
        self._p = {i: i for i in ids}
    def find(self, i):
        while self._p[i] != i:
            self._p[i] = self._p[self._p[i]]; i = self._p[i]
        return i
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb: self._p[rb] = ra
    def groups(self):
        out = {}
        for i in self._p:
            out.setdefault(self.find(i), []).append(i)
        return out


class _StrumentoClicPunto(QgsMapTool):
    """Strumento mappa temporaneo: cattura UN click sulla canvas e lo passa
    a `callback` come QgsPointXY nel CRS del progetto, poi ripristina lo
    strumento mappa precedente da solo. Usato per i punti di controllo
    manuali (es. un punto sulla rete e il corrispondente sul WMS)."""
    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self._canvas = canvas
        self._callback = callback
        self._precedente = canvas.mapTool()

    def canvasReleaseEvent(self, event):
        pt = self.toMapCoordinates(event.pos())
        self._canvas.setMapTool(self._precedente)
        self._callback(QgsPointXY(pt))

    def deactivate(self):
        super().deactivate()


class FTTHPermessiDialog(QDialog):

    def __init__(self, iface, project, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.project = project
        self.setWindowTitle(f"Gestione Permessi FTTH  —  v{VERSIONE}")
        # finestra ridimensionabile in entrambe le direzioni (allarga e
        # stringi), con dimensione iniziale contenuta e un minimo ragionevole
        # così entra anche su schermi piccoli; il contenuto di ogni scheda è
        # inoltre scorrevole (vedi _scrollable), quindi stringere la finestra
        # sotto la dimensione naturale del contenuto non taglia nulla: compare
        # una barra di scorrimento invece di clippare i controlli
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)
        self.setSizeGripEnabled(True)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(420, 320)
        self.resize(700, 680)
        self._last_layers = []
        self._output_layers = {}   # 'keyplan' / 'inquadramento' -> ultimo layer memory generato
        self._punti_controllo = []  # [(sorgente: QgsPointXY, riferimento: QgsPointXY), ...]
        self._trasformazione = None  # (a: complex, b: complex) o None se non ancora calcolata
        self._tool_clic = None  # riferimento allo strumento mappa attivo, se in attesa di un click
        self._contesti_consegna = []  # una voce per ogni copia della scheda 'Esportazione'
        self._impostazioni = QSettings("TerraLab", "FTTHPermessiManager")
        self._nota_grafica = ""  # avvisi dalla costruzione del formato etichette
        self._guide_aperte = []  # finestre di guida aperte, tenute in vita
        self._gruppi = []        # tutti i riquadri comprimibili creati
        # titoli dei gruppi in grassetto e spaziatura uniforme: senza colori
        # espliciti, così resta leggibile anche con i temi scuri di QGIS
        self.setStyleSheet(
            "QGroupBox { font-weight: bold; margin-top: 8px; padding-top: 6px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; }")
        self._build_ui()
        self._ripristina_stato_finestra()
        self._ripristina_impostazioni()

    def _ripristina_stato_finestra(self):
        """Riapre il plugin come lo si è lasciato: dimensione della finestra e
        schede attive. Su un pannello che ha quattro schede annidate, ritrovare
        ogni volta la prima è una piccola tassa a ogni apertura."""
        try:
            geometria = self._impostazioni.value("geometria")
            if geometria:
                self.restoreGeometry(geometria)
            for nome, tabs in (("tab_principale", self._tabs_principali),
                               ("tab_comune", self._tabs_comune),
                               ("tab_altri", self._tabs_altri_enti)):
                indice = self._impostazioni.value(nome, type=int)
                if indice is not None and 0 <= indice < tabs.count():
                    tabs.setCurrentIndex(indice)
        except Exception:
            pass  # impostazioni illeggibili: si riparte dai valori di default

    def _salva_stato_finestra(self):
        try:
            self._impostazioni.setValue("geometria", self.saveGeometry())
            self._impostazioni.setValue("tab_principale", self._tabs_principali.currentIndex())
            self._impostazioni.setValue("tab_comune", self._tabs_comune.currentIndex())
            self._impostazioni.setValue("tab_altri", self._tabs_altri_enti.currentIndex())
        except Exception:
            pass

    def closeEvent(self, evento):
        self._salva_stato_finestra()
        self._salva_impostazioni()
        super().closeEvent(evento)

    @staticmethod
    def _scrollable(widget):
        """Avvolge `widget` in una QScrollArea: permette di stringere la
        finestra del plugin sotto la dimensione naturale del contenuto senza
        tagliare nulla (compare una barra di scorrimento)."""
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QScrollArea.NoFrame)
        area.setWidget(widget)
        return area

    # ═══════════════════════════════════════════════════════════ UI
    def _build_ui(self):
        m = QVBoxLayout(self)
        tabs_principali = QTabWidget()
        self._tabs_principali = tabs_principali
        m.addWidget(tabs_principali)

        tabs_comune = QTabWidget()
        self._tabs_comune = tabs_comune
        tabs_comune.addTab(self._scrollable(self._tab_pulizia()),  "Seleziona elementi")
        tabs_comune.addTab(self._scrollable(self._tab_allinea()),  "Allinea cartografia")
        tabs_comune.addTab(self._scrollable(self._tab_keyplan()),  "Keyplan e tavole")
        tabs_comune.addTab(self._scrollable(self._tab_coni()),     "Punti di ripresa")
        tabs_comune.addTab(self._scrollable(self._tab_consegna()), "Esportazione")
        tabs_principali.addTab(tabs_comune, "Comune")

        tabs_altri_enti = QTabWidget()
        self._tabs_altri_enti = tabs_altri_enti
        tabs_altri_enti.addTab(self._scrollable(self._tab_chilometriche()), "Chilometriche")
        tabs_altri_enti.addTab(self._scrollable(self._tab_etichette()), "Etichette")
        tabs_altri_enti.addTab(self._scrollable(self._tab_suolo()), "Suolo comunale")
        # stessa scheda 'Esportazione' del ramo Comune, costruita una seconda
        # volta: è una copia indipendente (widget propri, impostazioni proprie)
        # e non un alias della prima, così puoi tenere per gli Altri Enti layer
        # e layout diversi da quelli del Comune senza che una scheda sovrascriva
        # i campi dell'altra
        tabs_altri_enti.addTab(self._scrollable(self._tab_consegna()), "Esportazione")
        tabs_principali.addTab(tabs_altri_enti, "Altri Enti")

        riga_fondo = QHBoxLayout()
        richiudi = QPushButton("Chiudi tutte le sezioni")
        richiudi.setToolTip(
            "Riporta tutte le schede alla vista d'insieme, come all'apertura del plugin.")
        richiudi.clicked.connect(self._chiudi_tutte_le_sezioni)
        riga_fondo.addWidget(richiudi)
        azzera = QPushButton("Ripristina i valori iniziali")
        azzera.setToolTip(
            "Il pannello ricorda i valori dei campi da una sessione all'altra: questo "
            "pulsante li riporta ai predefiniti del plugin.")
        azzera.clicked.connect(self._azzera_impostazioni)
        riga_fondo.addWidget(azzera)
        riga_fondo.addStretch()
        b = QPushButton("Chiudi"); b.clicked.connect(self.close)
        riga_fondo.addWidget(b)
        m.addLayout(riga_fondo)

    # ─── TAB 1 ────────────────────────────────────────────────────
    def _tab_pulizia(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("pulizia"))

        gb = self._gruppo("Layer"); f = QFormLayout(gb)
        self.cb_infra    = self._lcombo(QgsMapLayerProxyModel.LineLayer);   f.addRow("Infrastrutture:", self.cb_infra)
        self.cb_civici   = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Civici:", self.cb_civici)
        self.cb_pte      = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("ROE PTE:", self.cb_pte)
        self.cb_pozzetto = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Pozzetto:", self.cb_pozzetto)
        self.cb_cavo     = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True); f.addRow("Cavo ottico:", self.cb_cavo)
        self.cb_cavo_raccordo = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True); f.addRow("Cavo Raccordo (bretelle tra PTE):", self.cb_cavo_raccordo)
        self.spin_tol    = self._dspin(0.001, 100, 0.05, 3, " unità CRS progetto"); f.addRow("Tolleranza:", self.spin_tol)
        v.addWidget(gb)

        btn_d = QPushButton("Diagnostica tolleranza"); btn_d.clicked.connect(self._diagnostica)
        v.addWidget(btn_d)

        # R1
        gb1 = self._gruppo("1)  Tratte nuove Civico → PTE  (+  pozzetti compresi)"); l1 = QVBoxLayout(gb1)
        l1.addWidget(self._desc(
            "Seleziona la catena di tratte STATO='Nuovo' (Aerea compresa) da un Civico "
            "a un ROE PTE, fermandosi al primo PTE incontrato (incluso PTE Light). Se "
            "quel PTE Light è a sua volta collegato via Cavo Raccordo a un ALTRO PTE, "
            "l'intera catena è esclusa (raccordo condiviso con un altro permesso)."
        ))
        self.chk_no_cavo  = QCheckBox("Escludi tratte che corrono lungo il Cavo Ottico"); self.chk_no_cavo.setChecked(True);  l1.addWidget(self.chk_no_cavo)
        self.chk_pte_light = QCheckBox("Ferma la catena a qualsiasi ROE PTE (incluso PTE Light Diramatore)"); self.chk_pte_light.setChecked(True); l1.addWidget(self.chk_pte_light)
        b1 = QPushButton("Seleziona tratte Civico ↔ PTE + pozzetti compresi"); b1.clicked.connect(self._r1); l1.addWidget(b1)
        v.addWidget(gb1)

        # R1b — tratte a contatto diretto col Civico, indipendente dalla catena
        gb1b = self._gruppo("1b)  Tratte a contatto diretto col Civico (qualsiasi tipologia/stato) + pozzetto successivo"); l1b = QVBoxLayout(gb1b)
        l1b.addWidget(self._desc(
            "Indipendente dalla Regola 1: aggiunge alla selezione ogni tratta a "
            f"contatto col Civico (qualsiasi tipo/stato) + il Pozzetto successivo, "
            f"escluso se la tratta è TIPOLOGIA='{VAL_NO_DIG}', sede di un ROE PTE o "
            "toccata dal Cavo Ottico."
        ))
        b1b = QPushButton("Aggiungi tratte a contatto col Civico + pozzetto successivo"); b1b.clicked.connect(self._r1b); l1b.addWidget(b1b)
        v.addWidget(gb1b)

        # R2
        gb2 = self._gruppo("2)  Tratte che toccano PTE interno"); l2 = QVBoxLayout(gb2)
        l2.addWidget(QLabel(f"Tratte che toccano ROE PTE con TIPO in {VALORI_PTE_INT}."))
        self.chk_r2_nuovo = QCheckBox("Solo tratte STATO='Nuovo'"); self.chk_r2_nuovo.setChecked(True); l2.addWidget(self.chk_r2_nuovo)
        b2 = QPushButton("Seleziona tratte PTE interno"); b2.clicked.connect(self._r2); l2.addWidget(b2)
        v.addWidget(gb2)

        # R3
        gb3 = self._gruppo("3)  Pozzetti toccati solo da infrastruttura esistente"); l3 = QVBoxLayout(gb3)
        l3.addWidget(self._desc(
            f"Pozzetti con almeno una tratta ma nessuna interrata STATO='Nuovo' "
            f"(TIPOLOGIA='{VAL_AEREA}' Nuovo non conta come tratta nuova ai fini di "
            "questa regola)."
        ))
        b3 = QPushButton("Seleziona pozzetti solo su esistente"); b3.clicked.connect(self._r3); l3.addWidget(b3)
        v.addWidget(gb3)

        # R4
        gb4 = self._gruppo("4)  Tratte Infrastrutture + Pozzetti toccati da Edifici"); l4 = QVBoxLayout(gb4)
        self.cb_ed_edifici = self._lcombo(QgsMapLayerProxyModel.PolygonLayer | QgsMapLayerProxyModel.LineLayer)
        l4.addWidget(QLabel("Edifici/Fabbricati:")); l4.addWidget(self.cb_ed_edifici)
        l4.addWidget(self._desc(
            "Seleziona tratte e Pozzetti che toccano lo shape Edifici (entro la "
            f"Tolleranza sopra), indipendentemente l'uno dall'altro. TIPOLOGIA="
            f"'{VAL_AEREA}' sempre esclusa dalle tratte, a prescindere dalla spunta sotto."
        ))
        self.chk_r4_nuovo = QCheckBox("Tratte Infrastrutture: solo STATO='Nuovo' (i Pozzetti restano senza filtro)")
        l4.addWidget(self.chk_r4_nuovo)
        b4 = QPushButton("Seleziona tratte + pozzetti toccati da Edifici"); b4.clicked.connect(self._r4); l4.addWidget(b4)
        v.addWidget(gb4)

        # R5 — Proprietà privata (automatico via OSM)
        gb5 = self._gruppo("5)  Possibile proprietà privata (fuori dal sedime stradale)"); l5 = QVBoxLayout(gb5)
        l5.addWidget(self._desc(
            "Preselezione automatica (NON una classificazione legale) di tratte/"
            "pozzetti interamente fuori dal sedime stradale pubblico — da verificare "
            "sempre a vista. Il Sedime Pubblico si genera da OSM (copertura ovunque in "
            "Italia, ma serve rete) oppure da uno shape locale già disponibile (es. "
            "Stradario Italia, nessuna rete); in entrambi i casi le aree poligonali "
            "(piazze) sono prese piene, il resto bufferizzato. In alternativa, un "
            "sedime già pronto impostato sotto sostituisce del tutto la generazione."
        ))
        f5 = QFormLayout()
        self.spin_osm_largh = self._dspin(0.5, 50, 7, 1, " m larghezza sedime stradale", step=0.5)
        f5.addRow("Larghezza sedime stradale:", self.spin_osm_largh)
        self.spin_osm_margine = self._dspin(0, 500, 30, 0, " m margine area di lavoro")
        f5.addRow("Margine area di lavoro:", self.spin_osm_margine)
        self.cb_sedime_locale = self._lcombo(QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        f5.addRow("Stradario locale (opzionale, alternativa a OSM):", self.cb_sedime_locale)
        self.cb_sedime_custom = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        f5.addRow("Sedime già pronto (opzionale, sostituisce la generazione):", self.cb_sedime_custom)
        l5.addLayout(f5)
        b5a = QPushButton("1a) Scarica strade OSM e genera Sedime Pubblico"); b5a.clicked.connect(self._genera_sedime_osm); l5.addWidget(b5a)
        b5a2 = QPushButton("1b) Genera Sedime Pubblico da Stradario locale (nessuna rete)"); b5a2.clicked.connect(self._genera_sedime_locale); l5.addWidget(b5a2)
        b5b = QPushButton("2) Seleziona tratte/pozzetti fuori dal Sedime (possibile privato)"); b5b.clicked.connect(self._r5_privata); l5.addWidget(b5b)
        v.addWidget(gb5)

        self.log_p = self._log_widget(110)
        v.addWidget(self._blocco_log(self.log_p))
        br = QPushButton("Rimuovi elementi selezionati (ultima operazione)")
        br.setStyleSheet("font-weight:bold"); br.clicked.connect(self._rimuovi); v.addWidget(br)
        v.addStretch(); return w

    # ─── TAB ALLINEA CARTOGRAFIA ──────────────────────────────────
    def _tab_allinea(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("allinea"))
        v.addWidget(self._desc(
            "Sposta in blocco gli elementi della rete per allinearli alla cartografia "
            "ufficiale (WMS o shapefile). Un'unica trasformazione (traslazione + "
            "rotazione + scala) viene applicata a tutti i layer scelti insieme, non "
            "elemento per elemento, per non rompere i collegamenti della rete."
        ))

        gbl = self._gruppo("Layer da spostare insieme"); fl = QFormLayout(gbl)
        self.cb_al_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True); fl.addRow("Armadio Ottico:", self.cb_al_armadio)
        self.cb_al_infra   = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  fl.addRow("Infrastrutture:", self.cb_al_infra)
        self.cb_al_poz     = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True);  fl.addRow("Pozzetto:", self.cb_al_poz)
        self.cb_al_pte     = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True);  fl.addRow("ROE PTE:", self.cb_al_pte)
        self.cb_al_cavo    = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);   fl.addRow("Cavo Ottico:", self.cb_al_cavo)
        self.cb_al_raccordo = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  fl.addRow("Cavo Raccordo:", self.cb_al_raccordo)
        self.chk_al_solo_sel = QCheckBox("Sposta SOLO gli elementi selezionati (i layer senza selezione attiva vengono saltati per intero, non spostati tutti)")
        fl.addRow(self.chk_al_solo_sel)
        v.addWidget(gbl)

        gbb = self._gruppo("Punti di controllo manuali (es. sopra un WMS)"); fb = QVBoxLayout(gbb)
        fb.addWidget(self._desc(
            "Clicca coppie di punti corrispondenti: uno sulla TUA rete, uno sulla "
            "cartografia di riferimento. Servono almeno 2 coppie; con più coppie la "
            "trasformazione calcolata è più precisa."
        ))
        self.lst_al_punti = QListWidget(); self.lst_al_punti.setMaximumHeight(100); fb.addWidget(self.lst_al_punti)
        self.lbl_al_stato = QLabel(""); fb.addWidget(self.lbl_al_stato)
        rb = QHBoxLayout()
        bb_add = QPushButton("Aggiungi coppia di punti sulla mappa"); bb_add.clicked.connect(self._avvia_cattura_coppia); rb.addWidget(bb_add)
        bb_del = QPushButton("Rimuovi ultima coppia"); bb_del.clicked.connect(self._rimuovi_ultima_coppia); rb.addWidget(bb_del)
        bb_clr = QPushButton("Svuota"); bb_clr.clicked.connect(self._svuota_coppie); rb.addWidget(bb_clr)
        fb.addLayout(rb)
        bb_calc = QPushButton("Calcola trasformazione da punti di controllo"); bb_calc.clicked.connect(self._calcola_trasf_punti)
        fb.addWidget(bb_calc)
        v.addWidget(gbb)

        self.lbl_al_preview = QLabel("Nessuna trasformazione calcolata."); self.lbl_al_preview.setWordWrap(True)
        v.addWidget(self.lbl_al_preview)
        bapply = QPushButton("Applica trasformazione ai layer selezionati sopra")
        bapply.setStyleSheet("font-weight:bold"); bapply.clicked.connect(self._applica_trasformazione)
        v.addWidget(bapply)
        self.log_al = self._log_widget(130)
        v.addWidget(self._blocco_log(self.log_al))
        v.addStretch(); return w

    # ─── TAB 2 ────────────────────────────────────────────────────
    # widget che compongono UNA copia della scheda 'Esportazione'. La scheda è
    # costruita due volte (ramo Comune e ramo Altri Enti): ogni copia registra
    # i propri widget in un contesto e, prima di eseguire l'azione di un
    # pulsante, il contesto della copia da cui è arrivato il click viene reso
    # quello "attivo" (_attiva_consegna). Così la logica di _genera_consegna /
    # _esporta_atlante / merge PDF resta scritta una volta sola su self.<attr>,
    # ma legge sempre i valori della scheda che l'utente sta effettivamente
    # usando, invece di quelli dell'ultima copia costruita.
    _ATTR_CONSEGNA = (
        "cb_c_foto", "cb_c_armadio", "cb_c_infra", "cb_c_strada", "cb_c_poz",
        "spin_c_dist", "chk_c_join_armadio", "chk_c_join_strada",
        "chk_c_carica", "log_c",
        "lst_atlante", "chk_atlante_vettoriale", "chk_atlante_semplifica",
        "chk_atlante_jpeg_lossy", "log_atlante",
        "lst_merge_pdf", "log_merge",
        "spin_ev_larghezza", "spin_ev_tolleranza", "spin_ev_opacita",
        "chk_ev_solo_selez", "chk_ev_solo_nuovo", "log_ev",
        "spin_ev_margine", "spin_ev_vuoto", "chk_ev_salda", "chk_ev_intere",
        "btn_ev_colore", "chk_ev_etichetta", "spin_ev_corpo_nome",
        "chk_ev_spegni_stradario",
        "cb_ev_stradario", "cb_ev_stile", "spin_ev_passo", "spin_ev_spessore",
        "spin_ev_angolo",
    )

    def _attiva_consegna(self, ctx):
        for nome, widget in ctx.items():
            setattr(self, nome, widget)

    def _collega_consegna(self, bottone, azione, ctx):
        """Collega il pulsante all'azione attivando prima il contesto (cioè il
        set di widget) della copia di scheda a cui il pulsante appartiene."""
        bottone.clicked.connect(lambda *_: (self._attiva_consegna(ctx), azione()))

    def _tab_consegna(self):
        ctx = {}  # riempito in fondo, quando tutti i widget esistono
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("consegna"))
        f = QFormLayout()
        self.cb_c_foto    = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Punti di ripresa (Foto):", self.cb_c_foto)
        self.cb_c_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True); f.addRow("Armadio Ottico:", self.cb_c_armadio)
        self.cb_c_infra   = self._lcombo(QgsMapLayerProxyModel.LineLayer);   f.addRow("Infrastrutture (Scavi):", self.cb_c_infra)
        self.cb_c_strada  = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  f.addRow("Stradario:", self.cb_c_strada)
        self.cb_c_poz     = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Pozzetto:", self.cb_c_poz)
        self.spin_c_dist  = self._dspin(0, 1e6, 0, 1, " (0=nessun limite)"); f.addRow("Distanza max join:", self.spin_c_dist)
        v.addLayout(f)

        v.addWidget(self._desc(
            "Join 'vettore più vicino' → 3 shape: ARMADI_FOTO (un Armadio + Punto di "
            "Ripresa più vicino; CIVICO='999' diventa 'SNC'), SCAVI_STRADE (Infra + "
            "Stradario + Armadio, con LUNGHEZZA/Lungh calcolati su '03 INFRASTRUTTURE'), "
            "POZZETTI_STRADE (Pozzetto + Stradario + Armadio). Campi duplicati "
            "diventano 'fid_2' ecc.; righe con 'n'≠1 (pareggio di distanza) rimosse."
        ))

        gbj = self._gruppo("Shape da joinare (plus: l'automatismo resta attivo di default)")
        lj = QVBoxLayout(gbj)
        lj.addWidget(self._desc(
            "Un layer impostato sopra entra automaticamente nel join; deseleziona qui "
            "solo per escluderlo senza rimuoverlo dal campo."
        ))
        self.chk_c_join_armadio = QCheckBox("Includi Armadio Ottico nel join"); self.chk_c_join_armadio.setChecked(True); lj.addWidget(self.chk_c_join_armadio)
        self.chk_c_join_strada  = QCheckBox("Includi Stradario nel join");     self.chk_c_join_strada.setChecked(True);  lj.addWidget(self.chk_c_join_strada)
        v.addWidget(gbj)

        self.chk_c_carica = QCheckBox("Carica i 3 shape nel progetto al termine"); self.chk_c_carica.setChecked(True)
        v.addWidget(self.chk_c_carica)
        b = QPushButton("Seleziona cartella e genera i 3 shape")
        b.setStyleSheet("font-weight:bold")
        self._collega_consegna(b, self._genera_consegna, ctx); v.addWidget(b)
        self.log_c = self._log_widget(130)
        v.addWidget(self._blocco_log(self.log_c))

        gba = self._gruppo("Esporta PDF (Atlante)"); va = QVBoxLayout(gba)
        va.addWidget(self._desc(
            "Esporta in PDF, via Atlante, i layout già presenti nel progetto (layer di "
            "copertura configurato nel Compositore, non da qui). Seleziona uno o più "
            "layout, poi genera: l'Atlante viene attivato e verificato (elementi > 0) "
            "prima di ogni esportazione, un PDF per layout nella cartella scelta."
        ))
        ra = QHBoxLayout()
        self.lst_atlante = QListWidget(); self.lst_atlante.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_atlante.setMaximumHeight(110); ra.addWidget(self.lst_atlante)
        va.addLayout(ra)
        self._popola_elenco_layout()
        baggiorna = QPushButton("Aggiorna elenco layout")
        self._collega_consegna(baggiorna, self._aggiorna_elenco_layout, ctx); va.addWidget(baggiorna)
        self.chk_atlante_vettoriale = QCheckBox("PDF vettoriale (più veloce, consigliato)")
        self.chk_atlante_vettoriale.setChecked(True)
        self.chk_atlante_vettoriale.setToolTip(
            "Evita la rasterizzazione automatica di ogni pagina: esportazione più "
            "rapida e file più leggeri. Disattiva solo se nel layout usi modalità di "
            "fusione/trasparenza (blend mode) che richiedono il rendering raster."
        )
        va.addWidget(self.chk_atlante_vettoriale)
        self.chk_atlante_semplifica = QCheckBox("Semplifica geometrie in esportazione (più veloce)")
        self.chk_atlante_semplifica.setChecked(True)
        self.chk_atlante_semplifica.setToolTip(
            "Riduce i vertici delle geometrie complesse in base alla scala di stampa: "
            "accelera il rendering, differenza visiva trascurabile alla scala della tavola."
        )
        va.addWidget(self.chk_atlante_semplifica)
        self.chk_atlante_jpeg_lossy = QCheckBox("Comprimi immagini con JPEG lossy (più veloce/leggero, come nell'esportazione standard di QGIS)")
        self.chk_atlante_jpeg_lossy.setChecked(True)
        self.chk_atlante_jpeg_lossy.setToolTip(
            "Corrisponde alla casella 'Compressione immagini senza perdita' della "
            "finestra 'Esporta come PDF' di QGIS, qui lasciata DESELEZIONATA (quindi "
            "compressione JPEG con perdita): immagini raster incorporate (es. sfondi "
            "WMS/ortofoto) più leggere e rendering più rapido. Disattiva questa "
            "opzione — cioè attiva la compressione senza perdita — solo se ti serve "
            "la massima qualità delle immagini raster nel PDF finale."
        )
        va.addWidget(self.chk_atlante_jpeg_lossy)
        besporta = QPushButton("Esporta PDF dei layout selezionati"); besporta.setStyleSheet("font-weight:bold")
        self._collega_consegna(besporta, self._esporta_atlante, ctx); va.addWidget(besporta)
        self.log_atlante = self._log_widget(130)
        va.addWidget(self._blocco_log(self.log_atlante))
        v.addWidget(gba)

        gbm = self._gruppo("Unisci PDF in un ordine stabilito"); vm = QVBoxLayout(gbm)
        vm.addWidget(self._desc(
            "Unisce più PDF in un unico file, nell'ordine mostrato in elenco. Dopo "
            "un'esportazione qui sopra l'elenco si popola da solo, nello stesso ordine "
            "di esportazione; puoi anche aggiungere altri PDF a mano e riordinare o "
            "rimuovere con i pulsanti sotto. Richiede il pacchetto Python 'pypdf' (o "
            "'PyPDF2') nell'ambiente di QGIS."
        ))
        self.lst_merge_pdf = QListWidget()
        self.lst_merge_pdf.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_merge_pdf.setMaximumHeight(110)
        vm.addWidget(self.lst_merge_pdf)
        rm = QHBoxLayout()
        bm_add = QPushButton("Aggiungi PDF…")
        self._collega_consegna(bm_add, self._merge_pdf_aggiungi, ctx); rm.addWidget(bm_add)
        bm_up = QPushButton("↑ Su")
        self._collega_consegna(bm_up, lambda: self._merge_pdf_sposta(-1), ctx); rm.addWidget(bm_up)
        bm_down = QPushButton("↓ Giù")
        self._collega_consegna(bm_down, lambda: self._merge_pdf_sposta(1), ctx); rm.addWidget(bm_down)
        bm_rm = QPushButton("Rimuovi")
        self._collega_consegna(bm_rm, self._merge_pdf_rimuovi, ctx); rm.addWidget(bm_rm)
        vm.addLayout(rm)
        bm_merge = QPushButton("Unisci PDF nell'ordine mostrato"); bm_merge.setStyleSheet("font-weight:bold")
        self._collega_consegna(bm_merge, self._merge_pdf_unisci, ctx); vm.addWidget(bm_merge)
        self.log_merge = self._log_widget(90)
        vm.addWidget(self._blocco_log(self.log_merge))
        v.addWidget(gbm)

        v.addWidget(self._gruppo_evidenza_strade(ctx))

        ctx.update({nome: getattr(self, nome) for nome in self._ATTR_CONSEGNA})
        self._contesti_consegna.append(ctx)

        v.addStretch(); return w

    # ─── TAB 3 ────────────────────────────────────────────────────
    def _tab_coni(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("coni"))

        gbt = self._gruppo("Coni per Tavola di Inquadramento (3 a tavola, di più se servono per gli Armadi)"); vt = QVBoxLayout(gbt)
        vt.addWidget(self._desc(
            "Per ogni tavola: un cono per OGNI Armadio Ottico presente (priorità "
            "assoluta, anche oltre 3), poi fino a un totale di 3 con, in ordine di "
            "priorità, attraversamenti Provinciale, ANAS, Stradario (generici — la "
            "maggioranza dei casi), Pozzetto Nuovo e infine punto medio della tratta "
            "Infrastruttura Nuova; a parità vince il candidato più vicino al centro "
            "tavola. Infrastrutture considerate: solo STATO='Nuovo', esclusa TIPOLOGIA="
            f"'{VAL_AEREA}' o vuota. Ogni cono è la proiezione perpendicolare del "
            "soggetto sulla tratta di Stradario più vicina realmente dentro la tavola "
            "(raggio di ricerca che si allarga se serve), riportato dentro il "
            "perimetro se necessario. Se il soggetto giace già sulla strada stessa "
            "(attraversamenti), la camera resta sulla stessa linea della strada ma "
            "spostata della Distanza di ripresa, con inquadratura perpendicolare — "
            "non 'sopra' il soggetto. Due controlli anti-duplicato indipendenti "
            "evitano sia coni sullo stesso soggetto sia sulla stessa posizione-camera. "
            "Stradario, Provinciali e ANAS vengono letti solo entro ARLO AREA (dalla "
            "scheda 'Keyplan e tavole') allargata del margine sotto — utile con shape "
            "nazionali (es. Stradario Italia) per non caricarli per intero."
        ))
        ft = QFormLayout()
        self.cb_kf_tavole = self._lcombo(QgsMapLayerProxyModel.PolygonLayer); ft.addRow("Tavole di Inquadramento:", self.cb_kf_tavole)
        self.cb_kf_infra  = self._lcombo(QgsMapLayerProxyModel.LineLayer);    ft.addRow("Infrastrutture:", self.cb_kf_infra)
        self.cb_kf_pozzetto = self._lcombo(QgsMapLayerProxyModel.PointLayer); ft.addRow("Pozzetto:", self.cb_kf_pozzetto)
        self.cb_k_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer);  ft.addRow("Armadio Ottico:", self.cb_k_armadio)
        self.cb_k_foto    = self._lcombo(QgsMapLayerProxyModel.PointLayer);  ft.addRow("Punto di Ripresa (output):", self.cb_k_foto)
        self.cb_k_stradario = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        ft.addRow("Stradario o altro shape lineare di riferimento (opzionale):", self.cb_k_stradario)
        self.cb_k_sedime = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        ft.addRow("Sedime Pubblico (opzionale, evita punti non accessibili):", self.cb_k_sedime)
        self.cb_kf_prov   = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  ft.addRow("Strade Provinciali (opzionale):", self.cb_kf_prov)
        self.cb_kf_anas   = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  ft.addRow("Strade ANAS (opzionale):", self.cb_kf_anas)
        self.spin_k_rag   = self._dspin(1, 5000, 50.0, 1, " raggio ricerca strada"); ft.addRow("Raggio ricerca strada (iniziale):", self.spin_k_rag)
        self.spin_k_dist  = self._dspin(0.1, 500, 3.0, 1, " unità progetto"); ft.addRow("Distanza di riserva (nessuna strada trovata):", self.spin_k_dist)
        self.spin_kf_dist = self._dspin(0.1, 500, 3.0, 1, " unità progetto"); ft.addRow("Distanza di ripresa (standoff da attraversamenti):", self.spin_kf_dist)
        self.spin_kf_margine_arlo = self._dspin(0, 200000, 500.0, 0, " margine attorno ad ARLO AREA")
        ft.addRow("Ritaglia Stradario/Provinciali/ANAS a: ARLO AREA + margine:", self.spin_kf_margine_arlo)
        vt.addLayout(ft)
        bt = QPushButton("Genera coni per Tavole di Inquadramento"); bt.setStyleSheet("font-weight:bold")
        bt.clicked.connect(self._coni_tavole); vt.addWidget(bt)
        self.log_kf = self._log_widget(130)
        vt.addWidget(self._blocco_log(self.log_kf))
        v.addWidget(gbt)

        gbn = self._gruppo("Numerazione automatica Foto"); vn = QVBoxLayout(gbn)
        vn.addWidget(self._desc(
            "Numera le Foto a blocchi fissi di 3 per Tavola (nell'ordine del suo "
            "numero); richiede le Tavole già numerate nel campo sotto. Il blocco resta "
            "fisso a 3 anche con meno coni: i numeri mancanti si saltano, la tavola "
            "successiva riparte comunque dal blocco pieno. Le Foto sono riconosciute "
            "tramite il campo 'ID_Tavola', non geometricamente."
        ))
        fn = QFormLayout()
        self.txt_num_tav = QLineEdit("Numero Tav"); fn.addRow("Campo numerazione Tavole (esistente):", self.txt_num_tav)
        self.txt_num_foto = QLineEdit("NumeroFoto"); fn.addRow("Campo numerazione Foto (creato se manca):", self.txt_num_foto)
        vn.addLayout(fn)
        bn = QPushButton("Numera Foto automaticamente"); bn.setStyleSheet("font-weight:bold")
        bn.clicked.connect(self._numera_foto); vn.addWidget(bn)
        self.log_n = self._log_widget(130)
        vn.addWidget(self._blocco_log(self.log_n))
        v.addWidget(gbn)

        v.addStretch(); return w

    # ─── TAB CHILOMETRICHE ──────────────────────────────────────────
    def _tab_chilometriche(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("chilometriche"))

        v.addWidget(self._desc(
            "Per le tratte che ricadono su strade ANAS/Provinciali non si usa lo "
            "stradario ma la chilometrica. Workflow: 1) crei/apri il layer Ancore, "
            "e per ogni punto di cui conosci la chilometrica reale (letta da Maps, "
            "da un cippo chilometrico o da un documento ANAS) ci clicchi sopra e "
            "scrivi il valore, es. 12+300; 2) selezioni i Pozzetto/Infrastrutture "
            "target; 3) il plugin trova la linea di riferimento più vicina a ognuno, "
            "misura la distanza reale lungo quella linea dall'ancora più vicina (o "
            "interpola fra le due ancore più vicine se ce ne sono almeno due sulla "
            "stessa linea) e scrive la chilometrica calcolata nel campo indicato."
        ))

        gb0 = self._gruppo("1) Crea il campo 'Chilometrica' sugli shape selezionati"); g0 = QVBoxLayout(gb0)
        g0.addWidget(self._desc(
            "Seleziona nel pannello Livelli (Ctrl+click) gli shape su cui ti serve "
            "il campo — tipicamente Pozzetto e/o Infrastrutture — poi genera il "
            "campo qui: se manca lo crea col tipo scelto, se esiste già lo lascia "
            "invariato. Usa lo stesso nome che poi userai come 'Campo di output' "
            "qui sotto. Attenzione: negli shapefile (DBF) i nomi campo non "
            "possono superare i 10 caratteri, quindi 'Chilometrica' viene creato "
            "come 'Chilometri' — è normale e non serve correggere nulla, il "
            "calcolo qui sotto riconosce entrambe le forme."
        ))
        riga_campo = QHBoxLayout()
        self.txt_km_nuovo_campo = QLineEdit("Chilometrica")
        riga_campo.addWidget(self.txt_km_nuovo_campo)
        self.cb_km_tipo_campo = QComboBox()
        self.cb_km_tipo_campo.addItems(["Testo (es. 12+300)", "Numerico (metri)"])
        riga_campo.addWidget(self.cb_km_tipo_campo)
        g0.addLayout(riga_campo)
        btn_crea_campo = QPushButton("Crea campo sugli shape selezionati nel pannello Livelli")
        btn_crea_campo.clicked.connect(self._crea_campo_chilometrica)
        g0.addWidget(btn_crea_campo)
        v.addWidget(gb0)

        gb1 = self._gruppo("2) Cippi di riferimento"); g1 = QVBoxLayout(gb1)
        g1.addWidget(self._desc(
            "Va bene sia il layer creato col pulsante qui sotto sia uno shape di cippi "
            "che già possiedi (es. 'Cippi Chilometrici'): in quel caso indica quale "
            "campo contiene il valore chilometrico — il plugin non presume più che si "
            "chiami 'Chilometrica'. Sono accettati i formati 12+300, 12,3 (km) e 12300 "
            "(metri)."
        ))
        riga_ancore = QHBoxLayout()
        self.cb_km_ancore = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        riga_ancore.addWidget(self.cb_km_ancore)
        btn_crea_ancore = QPushButton("Crea nuovo layer Ancore…")
        btn_crea_ancore.clicked.connect(self._crea_layer_ancore_km)
        riga_ancore.addWidget(btn_crea_ancore)
        g1.addLayout(riga_ancore)
        f1 = QFormLayout()
        self.cb_km_campo_ancora = QgsFieldComboBox()
        self.cb_km_campo_ancora.setAllowEmptyFieldName(True)
        f1.addRow("Campo con il valore chilometrico del cippo:", self.cb_km_campo_ancora)
        self.cb_km_formato = QComboBox()
        for _, etichetta in self._FORMATI_KM:
            self.cb_km_formato.addItem(etichetta)
        self.cb_km_formato.setToolTip(
            "Come leggere le due parti attorno al '+'. Il prefisso 'KM' o 'PK' viene "
            "ignorato in automatico. Scegli 'INVERTITO' se nello shape hai digitato "
            "prima i metri e poi i chilometri.")
        f1.addRow("Formato del valore scritto sul cippo:", self.cb_km_formato)
        g1.addLayout(f1)
        self.cb_km_ancore.layerChanged.connect(self._aggiorna_campi_ancore)
        self._aggiorna_campi_ancore(self.cb_km_ancore.currentLayer())
        v.addWidget(gb1)

        gb2 = self._gruppo("3) Calcolo"); g2 = QVBoxLayout(gb2)
        g2.addWidget(self._desc(
            "Uno stradario è spezzato in tantissimi segmenti: misurare la progressiva "
            "sul singolo segmento non ha senso, perciò il plugin prima ricuce i "
            "segmenti contigui in 'corridoi' continui, poi misura cippi e target lungo "
            "lo stesso corridoio. La chilometrica di ogni elemento è poi il valore del "
            "cippo di riferimento più la distanza reale percorsa lungo la strada da quel "
            "cippo, un metro per un metro: i valori crescono nel verso della strada, "
            "come i cippi veri. Non serve disegnare nulla a mano fra i cippi. Se lo "
            "stradario copre mezza provincia conviene selezionare in mappa le sole "
            "tratte della strada che ti interessa e spuntare l'opzione qui sotto: è più "
            "rapido e togli ogni ambiguità nei bivi e nelle rotatorie."
        ))
        f = QFormLayout()
        self.cb_km_riferimento = self._lcombo(QgsMapLayerProxyModel.LineLayer)
        f.addRow("Linea di riferimento (strada/tracciato):", self.cb_km_riferimento)
        self.cb_km_campo_gruppo = QgsFieldComboBox()
        self.cb_km_campo_gruppo.setAllowEmptyFieldName(True)
        f.addRow("Ricuci solo segmenti con uguale valore di (opzionale):", self.cb_km_campo_gruppo)
        self.cb_km_target = self._lcombo(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.LineLayer)
        f.addRow("Layer target (Pozzetto o Infrastrutture):", self.cb_km_target)
        self.txt_km_campo = QLineEdit("Chilometrica")
        f.addRow("Campo di output sul target:", self.txt_km_campo)
        self.spin_km_raggio = self._dspin(0.5, 5000, 50.0, 1, " unità progetto")
        f.addRow("Raggio ricerca target → corridoio:", self.spin_km_raggio)
        self.spin_km_tol_cippi = self._dspin(0.5, 5000, 50.0, 1, " unità progetto")
        f.addRow("Tolleranza cippo → corridoio:", self.spin_km_tol_cippi)
        self.spin_km_cucitura = self._dspin(0, 100, 1.0, 2, " unità progetto")
        self.spin_km_cucitura.setToolTip(
            "Distanza entro cui due tronchi di strada che non si toccano vengono "
            "comunque ricuciti in un unico corridoio. Negli stradari i tronchi si "
            "chiudono spesso a qualche centimetro di distanza: senza questa tolleranza "
            "la strada resta spezzata e gli elementi dei due tronchi contano da origini "
            "diverse. Alzala se la diagnostica segnala più di un corridoio.")
        f.addRow("Tolleranza di ricucitura fra tronchi:", self.spin_km_cucitura)
        self.cb_km_misura = QComboBox()
        for _, etichetta in self._MISURE_KM:
            self.cb_km_misura.addItem(etichetta)
        self.cb_km_misura.setToolTip(
            "Vale solo per i target lineari (Infrastrutture): una tratta ha due capi con "
            "chilometriche diverse. Il punto medio faceva sembrare incoerenti due scavi "
            "consecutivi, perché il primo finiva dove il secondo cominciava ma i valori "
            "scritti distavano mezza tratta.")
        f.addRow("Su una tratta misura:", self.cb_km_misura)
        g2.addLayout(f)
        self.cb_km_riferimento.layerChanged.connect(self._aggiorna_campi_riferimento)
        self._aggiorna_campi_riferimento(self.cb_km_riferimento.currentLayer())

        riga_modo = QHBoxLayout()
        riga_modo.addWidget(QLabel("Come contare:"))
        self.cb_km_modo = QComboBox()
        for _, etichetta in self._MODI_KM:
            self.cb_km_modo.addItem(etichetta)
        self.cb_km_modo.setToolTip(
            "In progressione la chilometrica di un elemento è il valore del cippo di "
            "riferimento più la distanza reale percorsa lungo la strada, un metro per "
            "un metro: i valori crescono nel verso della strada e restano monotoni. "
            "L'interpolazione invece riscala le distanze sui valori dei cippi, quindi un "
            "cippo mal posizionato deforma tutto il tratto che lo riguarda. Solo la "
            "prima modalità garantisce valori sempre crescenti: contando dal cippo più "
            "vicino, al cambio di riferimento i valori possono fare un salto indietro se "
            "due cippi non sono coerenti fra loro.")
        riga_modo.addWidget(self.cb_km_modo, 1)
        g2.addLayout(riga_modo)
        self.chk_km_inverti = QCheckBox("Inverti il verso di progressione")
        self.chk_km_inverti.setToolTip(
            "Il verso viene ricavato dai cippi (dal valore più basso verso il più alto). "
            "Serve solo quando c'è un unico cippo utile e il verso non è deducibile: se i "
            "valori risultano decrescenti, spunta qui.")
        g2.addWidget(self.chk_km_inverti)

        self.chk_km_solo_selez_rif = QCheckBox(
            "Usa solo le tratte selezionate in mappa nella linea di riferimento")
        self.chk_km_solo_selez_rif.setToolTip(
            "Consigliato con uno stradario provinciale: seleziona in mappa le tratte "
            "della strada su cui stanno i cippi e il calcolo userà solo quelle.")
        g2.addWidget(self.chk_km_solo_selez_rif)
        self.chk_km_tutte_feature = QCheckBox(
            "Se non c'è nessuna feature selezionata nel target, elabora tutte le sue feature")
        g2.addWidget(self.chk_km_tutte_feature)
        self.chk_km_multi_target = QCheckBox(
            "Applica anche agli altri layer selezionati nel pannello Livelli "
            "(Armadio + Pozzetto + Infrastrutture in un colpo)")
        self.chk_km_multi_target.setToolTip(
            "Ogni layer vettoriale selezionato nel pannello Livelli che abbia il campo "
            "di output viene elaborato con gli stessi cippi e lo stesso riferimento. "
            "Il layer di riferimento, se selezionato lì, viene comunque escluso.")
        g2.addWidget(self.chk_km_multi_target)
        v.addWidget(gb2)

        riga_bottoni = QHBoxLayout()
        btn_diag = QPushButton("Diagnostica (perché non calcola?)")
        btn_diag.setToolTip("Controlla cippi, corridoi e distanze senza modificare nulla.")
        btn_diag.clicked.connect(self._diagnostica_chilometriche)
        riga_bottoni.addWidget(btn_diag)
        riga_bottoni.addStretch()
        btn = QPushButton("Calcola le chilometriche")
        btn.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        btn.clicked.connect(self._calcola_chilometriche)
        riga_bottoni.addWidget(btn)
        v.addLayout(riga_bottoni)

        self.stato_km = self._etichetta_stato()
        v.addWidget(self.stato_km)
        self.log_km = self._log_widget(140)
        v.addWidget(self._blocco_log(self.log_km))

        v.addStretch(); return w

    # ─── chilometriche: helper UI ───────────────────────────────────
    _INDIZI_CAMPO_KM = ("chilometr", "km", "progr", "pk", "cippo")

    def _aggiorna_campi_ancore(self, layer):
        """Popola il combo dei campi del layer cippi e preseleziona quello che
        con ogni probabilità contiene la chilometrica (nome che contiene
        'chilometr', 'km', 'progr'…), incluso il caso in cui lo shapefile
        l'abbia troncato a 'Chilometri'."""
        self.cb_km_campo_ancora.setLayer(layer)
        if layer is None:
            return
        nomi = [c.name() for c in layer.fields()]
        for indizio in self._INDIZI_CAMPO_KM:
            for nome in nomi:
                if indizio in nome.lower():
                    self.cb_km_campo_ancora.setField(nome)
                    return

    def _aggiorna_campi_riferimento(self, layer):
        self.cb_km_campo_gruppo.setLayer(layer)
        self.cb_km_campo_gruppo.setField("")

    def _campo_ancora(self, ancore_lyr):
        """Campo da leggere sul layer cippi: quello scelto nel combo, altrimenti
        ripiego sul vecchio comportamento ('Chilometrica' o la sua forma
        troncata dallo shapefile)."""
        nome = self.cb_km_campo_ancora.currentField()
        if nome:
            i = self._indice_campo(ancore_lyr, nome)
            if i >= 0:
                return i, ancore_lyr.fields().at(i).name()
        i = self._indice_campo(ancore_lyr, "Chilometrica")
        if i >= 0:
            return i, ancore_lyr.fields().at(i).name()
        return -1, ""

    def _crea_campo_chilometrica(self):
        campo = self.txt_km_nuovo_campo.text().strip()
        if not campo:
            QMessageBox.warning(self, "Nome campo mancante", "Indica il nome del campo da creare."); return
        layers = [l for l in self.iface.layerTreeView().selectedLayers()
                  if isinstance(l, QgsVectorLayer)]
        if not layers:
            QMessageBox.warning(self, "Nessuno shape selezionato",
                "Seleziona uno o più layer vettoriali nel pannello Livelli (Ctrl+click) e riprova."); return

        testo = self.cb_km_tipo_campo.currentIndex() == 0

        righe = []; creati = 0; presenti = 0; falliti = 0; troncati = []
        for lyr in layers:
            i, nome_reale, esito = self._assicura_campo(lyr, campo, tipo_testo=testo)
            if esito.startswith("fallito"):
                falliti += 1
                righe.append(f"'{lyr.name()}': {esito[8:].strip()}."); continue
            if nome_reale != campo:
                troncati.append(f"{lyr.name()} → '{nome_reale}'")
            if esito == "presente":
                presenti += 1
                righe.append(f"'{lyr.name()}': campo '{nome_reale}' già presente, nessuna modifica.")
            else:
                creati += 1
                righe.append(f"'{lyr.name()}': campo '{nome_reale}' creato "
                             f"({'testo' if testo else 'numerico'}).")

        msg = (f"{creati} campi creati, {presenti} già presenti, {falliti} falliti "
               f"su {len(layers)} shape selezionati.\n\n" + "\n".join(righe))
        if troncati:
            msg += ("\n\nNota: gli shapefile (formato DBF) ammettono nomi di campo di "
                    "massimo 10 caratteri, quindi il nome è stato adattato: "
                    + "; ".join(troncati) +
                    ". Al punto 2 puoi lasciare scritto il nome per esteso: il plugin "
                    "riconosce da solo il campo abbreviato.")
        self.log_km.setPlainText(msg)
        self._mostra_stato(self.stato_km, msg.split("\n")[0], ok=falliti == 0)

    def _crea_layer_ancore_km(self):
        crs = self.project.crs().authid()
        lyr = QgsVectorLayer(
            f"Point?crs={crs}&field=Chilometrica:string(12)&field=Strada:string(60)",
            "Ancore Chilometriche", "memory")
        self.project.addMapLayer(lyr)
        self.cb_km_ancore.setLayer(lyr)
        lyr.startEditing()
        self.iface.setActiveLayer(lyr)
        QMessageBox.information(
            self, "Layer Ancore creato",
            "Layer 'Ancore Chilometriche' creato e in modifica.\n\n"
            "Aggiungi un punto per ogni riferimento di cui conosci la chilometrica "
            "reale (da Maps, cippo o documento ANAS), scrivendo il valore nel campo "
            "Chilometrica in formato km+m, es. 12+300, e opzionalmente il nome/codice "
            "strada nel campo Strada. Poi salva le modifiche prima di calcolare."
        )

    # ─── TAB 4 ────────────────────────────────────────────────────
    def _tab_keyplan(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("keyplan"))
        f = QFormLayout()
        self.cb_kp_arlo    = self._lcombo(QgsMapLayerProxyModel.VectorLayer)
        f.addRow("ARLO AREA (poligono con TUTTE le aree armadio da coprire):", self.cb_kp_arlo)
        self.spin_margine  = self._dspin(0, 50000, 100, 0, " m")
        f.addRow("Margine estensione (buffer attorno al confine ARLO AREA):", self.spin_margine)
        v.addLayout(f)

        v.addWidget(self._desc(
            "L'area da coprire è la forma reale di ARLO AREA (feature fuse, non il "
            "bounding box), allargata del margine sopra. Infrastrutture/Pozzetto/"
            "Armadio non la definiscono: servono più sotto per la copertura mirata "
            "alla sola rete nuova."
        ))
        bdiag = QPushButton("Diagnostica estensione (verifica ARLO AREA)")
        bdiag.clicked.connect(self._diagnostica_estensione)
        v.addWidget(bdiag)


        v.addWidget(self._desc(
            "Le tavole si posizionano una 'toppa' alla volta sul buco scoperto più "
            "grande, seguendo il contorno reale dell'area (non una griglia rigida). Il "
            "Keyplan non si sovrappone mai; le Tavole di inquadramento possono, del "
            "margine impostato. I layer modello non vengono mai modificati. Ogni "
            "generazione crea un layer temporaneo 'memory' (RAM): usa 'Salva su disco' "
            "più sotto per renderlo permanente."
        ))

        gbk = self._gruppo("Keyplan – copertura automatica (segue la forma, MAI sovrapposta)"); fk = QFormLayout(gbk)
        self.cb_kp_keyplan = self._lcombo(QgsMapLayerProxyModel.VectorLayer); fk.addRow("Layer Keyplan modello A (shape / GeoPackage):", self.cb_kp_keyplan)
        self.cb_kp_keyplan2 = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True); fk.addRow("Layer Keyplan modello B (opzionale, es. l'altra forma):", self.cb_kp_keyplan2)
        self.spin_kp_gap = self._dspin(0, 500, 0, 2, " m gap minimo tra tavole", step=0.01); fk.addRow("Margine di sicurezza (gap):", self.spin_kp_gap)
        self.cb_kp_tavole = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        fk.addRow("Tavole di Inquadramento (se impostato, il Keyplan copre SOLO queste — non ARLO AREA):", self.cb_kp_tavole)
        fk.addRow(self._desc(
            "La feature selezionata (o la prima) di ciascun layer modello è presa come "
            "MODELLO di tavola. Solo A → copertura di sole copie di A; anche B → ad "
            "ogni tavola si sceglie la forma che copre più area utile. Il campo sopra "
            "è un margine di sicurezza aggiuntivo oltre al non-sovrapporsi. Se imposti "
            "un layer di Tavole di Inquadramento, il Keyplan copre ESATTAMENTE la loro "
            "impronta (ARLO AREA ignorata); altrimenti copre l'intero ARLO AREA."
        ))
        bkp = QPushButton("Genera copertura Keyplan sull'area di progetto")
        bkp.setStyleSheet("font-weight:bold"); bkp.clicked.connect(self._posiziona_keyplan)
        fk.addRow(bkp)
        v.addWidget(gbk)

        gbt = self._gruppo("Tavole di inquadramento – copertura automatica (modelli propri)"); ft = QFormLayout(gbt)
        self.cb_ti_tmpl_a = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True); ft.addRow("Layer Inquadramento modello A (es. Tavole_Inquadramento.gpkg):", self.cb_ti_tmpl_a)
        self.cb_ti_tmpl_b = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True); ft.addRow("Layer Inquadramento modello B (opzionale):", self.cb_ti_tmpl_b)
        self.spin_ti_gap = self._dspin(0, 500, 0, 2, " m gap minimo tra tavole", step=0.01); ft.addRow("Margine di sicurezza (gap):", self.spin_ti_gap)
        ft.addRow(self._desc(
            "Copertura indipendente dal Keyplan (scala diversa), stesso automatismo A/B "
            "(riusa i modelli del Keyplan se non ne imposti qui). Mai sovrapposte; le "
            "tavole quasi del tutto ridondanti vengono rimosse in automatico."
        ))
        btv = QPushButton("Genera copertura tavole di inquadramento"); btv.setStyleSheet("font-weight:bold"); btv.clicked.connect(self._genera_griglia)
        ft.addRow(btv)
        v.addWidget(gbt)

        gbo = self._gruppo("Rigenera solo sulla rete (opzionale, riduce drasticamente il numero di tavole)"); fo = QFormLayout(gbo)
        self.cb_kp_infra = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        fo.addRow("Infrastrutture (STATO='Nuovo'):", self.cb_kp_infra)
        self.cb_kp_poz = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        fo.addRow("Pozzetto (STATO='Nuovo', usato dalle Tavole di inquadramento):", self.cb_kp_poz)
        self.spin_kp_raggio = self._dspin(0, 100, 2, 2, " m raggio attorno ai tratti nuovi", step=0.5)
        fo.addRow("Raggio target:", self.spin_kp_raggio)
        fo.addRow(self._desc(
            "Rigenera la copertura, con gli stessi modelli A/B, nel minor numero di "
            "tavole possibile. Tavole di inquadramento: solo su Infrastrutture STATO="
            f"'Nuovo' (escluse TIPOLOGIA='{VAL_AEREA}' o vuota) + Pozzetto 'Nuovo' — "
            "vanno generate PER PRIME. Keyplan: copre solo quelle tavole, va rigenerato "
            "DOPO. Parti senza rete nuova restano scoperte: è voluto."
        ))
        bo2 = QPushButton("1) Rigenera tavole di inquadramento solo sulla rete nuova")
        bo2.clicked.connect(lambda: self._ottimizza_griglia('inquadramento', 'Poligoni Inquadramento'))
        fo.addRow(bo2)
        bo1 = QPushButton("2) Rigenera Keyplan (rete nuova + tavole di inquadramento)")
        bo1.clicked.connect(lambda: self._ottimizza_griglia('keyplan', 'Keyplan'))
        fo.addRow(bo1)
        v.addWidget(gbo)

        gbn = self._gruppo("Numerazione Keyplan e Tavole di Inquadramento"); fn = QFormLayout(gbn)
        fn.addRow(self._desc(
            "Numera le tavole in ordine di lettura (righe nord→sud, ovest→est), "
            "indipendentemente per Keyplan e Tavole. Campo creato se manca; vuoto = "
            "quel layer non viene numerato."
        ))
        self.cb_num_keyplan = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        fn.addRow("Layer Keyplan:", self.cb_num_keyplan)
        self.txt_num_keyplan_campo = QLineEdit("Numero Tav")
        fn.addRow("Campo numerazione Keyplan:", self.txt_num_keyplan_campo)
        self.cb_num_tavole = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        fn.addRow("Layer Tavole di Inquadramento:", self.cb_num_tavole)
        self.txt_num_tavole_campo = QLineEdit("Numero Tav")
        fn.addRow("Campo numerazione Tavole:", self.txt_num_tavole_campo)
        bnum = QPushButton("Numera Keyplan e Tavole"); bnum.setStyleSheet("font-weight:bold")
        bnum.clicked.connect(self._numera_keyplan_e_tavole); fn.addRow(bnum)
        v.addWidget(gbn)

        gbs = self._gruppo("Salva su disco"); fs = QFormLayout(gbs)
        fs.addRow(self._desc(
            "I layer generati sopra sono temporanei (memory). Questi pulsanti salvano "
            "UN layer alla volta nel GeoPackage scelto, con lo stile del plugin."
        ))
        bsalva_kp = QPushButton("Salva Keyplan su GeoPackage…")
        bsalva_kp.setStyleSheet("font-weight:bold")
        bsalva_kp.clicked.connect(lambda: self._salva_uno('keyplan', 'Keyplan', 'keyplan.qml'))
        fs.addRow(bsalva_kp)
        bsalva_ti = QPushButton("Salva Poligoni Inquadramento su GeoPackage…")
        bsalva_ti.setStyleSheet("font-weight:bold")
        bsalva_ti.clicked.connect(lambda: self._salva_uno('inquadramento', 'Poligoni Inquadramento', 'poligoni_inquadramento.qml'))
        fs.addRow(bsalva_ti)
        v.addWidget(gbs)

        self.log_kp = self._log_widget(130)
        v.addWidget(self._blocco_log(self.log_kp))
        v.addStretch(); return w

    # ═══════════════════════════════════════════════════ HELPERS UI
    def _lcombo(self, filtro, allow_empty=False):
        c = QgsMapLayerComboBox(); c.setFilters(filtro)
        if allow_empty: c.setAllowEmptyLayer(True)
        return c

    def _dspin(self, lo, hi, val, dec, suf="", step=None):
        s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec)
        s.setValue(val); s.setSuffix(suf)
        if step is not None: s.setSingleStep(step)
        return s

    def _ispin(self, lo, hi, val):
        s = QSpinBox(); s.setRange(lo, hi); s.setValue(val); return s

    @staticmethod
    def _desc(testo, soglia=170):
        """Blocco di aiuto: la prima frase resta sempre visibile, il resto si
        apre su richiesta con '▸ dettagli'.

        Prima ogni scheda si apriva con un paragrafo giustificato di otto o dieci
        righe che spingeva i controlli sotto la piega e costringeva a leggere
        tutto per trovare il pulsante: chi conosce già la funzione vuole solo il
        promemoria di una riga, chi non la conosce apre i dettagli. I testi
        restano quelli, cambia solo quanto ne vedi subito."""
        testo = " ".join(str(testo).split())
        if len(testo) <= soglia:
            etichetta = QLabel(testo)
            etichetta.setWordWrap(True)
            etichetta.setAlignment(Qt.AlignJustify)
            return etichetta

        # taglio alla fine della prima frase "vera": il punto deve essere
        # seguito da spazio e maiuscola, così non si spezza su 'es. 12+300'
        taglio = -1
        for m in re.finditer(r"(?<=[a-z0-9àèéìòù\)\]])\.\s+(?=[A-Z0-9])", testo):
            if m.start() >= 50:
                taglio = m.start() + 1
                break
        if taglio < 0 or taglio > soglia * 1.6:
            taglio = testo.rfind(" ", 0, soglia)
            if taglio < 50:
                taglio = soglia
        sommario, resto = testo[:taglio].strip(), testo[taglio:].strip()

        contenitore = QWidget()
        v = QVBoxLayout(contenitore)
        v.setContentsMargins(0, 0, 0, 4); v.setSpacing(2)

        capo = QLabel(sommario)
        capo.setWordWrap(True); capo.setAlignment(Qt.AlignJustify)
        v.addWidget(capo)

        dettagli = QLabel(resto)
        dettagli.setWordWrap(True); dettagli.setAlignment(Qt.AlignJustify)
        dettagli.setVisible(False)

        interruttore = QToolButton()
        interruttore.setText("dettagli")
        interruttore.setCheckable(True)
        interruttore.setAutoRaise(True)
        interruttore.setArrowType(Qt.RightArrow)
        interruttore.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        interruttore.setCursor(Qt.PointingHandCursor)
        interruttore.setStyleSheet("QToolButton { border: none; padding: 0px; }")

        def _apri(aperto):
            dettagli.setVisible(aperto)
            interruttore.setArrowType(Qt.DownArrow if aperto else Qt.RightArrow)
            interruttore.setText("nascondi" if aperto else "dettagli")
        interruttore.toggled.connect(_apri)

        riga = QHBoxLayout(); riga.setContentsMargins(0, 0, 0, 0)
        riga.addWidget(interruttore); riga.addStretch()
        v.addLayout(riga)
        v.addWidget(dettagli)
        return contenitore

    def _gruppo(self, titolo, compresso=True):
        """Riquadro comprimibile, chiuso all'apertura del plugin.

        Ogni scheda si presenta come un elenco di titoli: si apre quello che
        serve e il resto resta fuori dai piedi.

        Il salvataggio automatico dello stato va disattivato di proposito.
        QgsCollapsibleGroupBox memorizza in QgsSettings se il riquadro era aperto
        e lo ripristina quando il widget viene mostrato, sovrascrivendo il
        setCollapsed() fatto qui: senza disattivarlo, i riquadri lasciati aperti
        nella sessione precedente si riaprirebbero da soli e la richiesta di
        trovarli tutti chiusi non sarebbe rispettata."""
        try:
            from qgis.gui import QgsCollapsibleGroupBox
            gb = QgsCollapsibleGroupBox(titolo)
            gb.setObjectName("ftth_" + re.sub(r"[^0-9A-Za-z]+", "_", titolo).strip("_").lower())
            if hasattr(gb, "setSaveCollapsedState"):
                gb.setSaveCollapsedState(False)
            gb.setCollapsed(compresso)
            self._gruppi.append(gb)
            return gb
        except Exception:
            return QGroupBox(titolo)

    def _chiudi_tutte_le_sezioni(self):
        """Richiude ogni riquadro, per tornare alla vista d'insieme senza
        chiudere e riaprire il pannello."""
        chiusi = 0
        for gb in self._gruppi:
            try:
                if not gb.isCollapsed():
                    gb.setCollapsed(True)
                    chiusi += 1
            except Exception:
                continue
        return chiusi

    def _barra_guida(self, chiave):
        """Riga con il pulsante Guida, da mettere in cima a ogni scheda."""
        riga = QHBoxLayout()
        riga.addStretch()
        b = QPushButton("  ?  Guida")
        b.setToolTip("Come si usa questa scheda, passo per passo.")
        b.clicked.connect(lambda: self._mostra_guida(chiave))
        riga.addWidget(b)
        contenitore = QWidget()
        contenitore.setLayout(riga)
        return contenitore

    @staticmethod
    def _intestazione(testo):
        """Intestazione di sezione dentro un riquadro: serve a spezzare gli
        elenchi lunghi di controlli, che altrimenti si leggono come una fila
        indistinta in cui non si trova più niente."""
        etichetta = QLabel(testo.upper())
        etichetta.setStyleSheet(
            "font-weight: bold; color: palette(mid); margin-top: 6px;")
        return etichetta

    @staticmethod
    def _log_widget(altezza=150):
        """Riquadro di log a larghezza fissa di carattere: le colonne degli
        elenchi (campi, valori di esempio) restano allineate, e l'altezza
        massima evita che il log si mangi la scheda."""
        log = QPlainTextEdit()
        log.setReadOnly(True)
        log.setMaximumHeight(altezza)
        carattere = QFont("Monospace")
        carattere.setStyleHint(QFont.TypeWriter)
        carattere.setPointSize(max(7, QFont().pointSize() - 1))
        log.setFont(carattere)
        return log

    def _blocco_log(self, log, titolo="Registro dell'operazione"):
        """Avvolge un riquadro di log in un blocco richiudibile, chiuso all'avvio.

        I log occupavano spazio verticale anche quando erano vuoti — nelle schede
        più cariche erano tre o quattro rettangoli bianchi che allontanavano i
        controlli fra loro. Ora restano chiusi e si aprono da sé quando c'è
        qualcosa da leggere, così lo spazio è occupato solo se serve."""
        contenitore = QWidget()
        v = QVBoxLayout(contenitore)
        v.setContentsMargins(0, 0, 0, 0); v.setSpacing(2)

        interruttore = QToolButton()
        interruttore.setText(titolo)
        interruttore.setCheckable(True)
        interruttore.setAutoRaise(True)
        interruttore.setArrowType(Qt.RightArrow)
        interruttore.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        interruttore.setCursor(Qt.PointingHandCursor)
        interruttore.setStyleSheet("QToolButton { border: none; padding: 0px; }")
        log.setVisible(False)

        def _apri(aperto):
            log.setVisible(aperto)
            interruttore.setArrowType(Qt.DownArrow if aperto else Qt.RightArrow)
        interruttore.toggled.connect(_apri)

        def _contenuto_cambiato():
            if log.toPlainText().strip() and not interruttore.isChecked():
                interruttore.setChecked(True)
        log.textChanged.connect(_contenuto_cambiato)

        riga = QHBoxLayout(); riga.setContentsMargins(0, 0, 0, 0)
        riga.addWidget(interruttore); riga.addStretch()
        v.addLayout(riga)
        v.addWidget(log)
        return contenitore

    @staticmethod
    def _etichetta_stato():
        """Riga di esito accanto ai pulsanti: sostituisce il popup di conferma
        per le operazioni andate a buon fine, che obbligava a un click in più
        per leggere poi la stessa cosa nel log."""
        stato = QLabel("")
        stato.setWordWrap(True)
        stato.setTextInteractionFlags(Qt.TextSelectableByMouse)
        return stato

    def _mostra_stato(self, etichetta, testo, ok=True):
        etichetta.setText(("✔ " if ok else "⚠ ") + testo)
        etichetta.setStyleSheet("font-weight: bold;" if ok else
                                "font-weight: bold; color: #b35c00;")
        self.repaint()

    # ═══════════════════════════════════════════════ HELPERS SPAZIALI
    def _to_proj(self, geom, lyr):
        """Trasforma geom (nel CRS di lyr) nel CRS di progetto. Ritorna None
        se la geometria è vuota/assente o se la trasformazione fallisce
        (CRS non validi/non compatibili), invece di interrompere il plugin
        con un'eccezione non gestita."""
        if geom is None or geom.isEmpty(): return None
        src = lyr.crs(); dst = self.project.crs()
        if src == dst: return QgsGeometry(geom)
        g = QgsGeometry(geom)
        try:
            g.transform(QgsCoordinateTransform(src, dst, self.project))
        except Exception as e:
            self._crs_errors = getattr(self, "_crs_errors", 0) + 1
            print(f"[FTTH Permessi] Errore trasformazione CRS ({lyr.name()}): {e}")
            return None
        return g

    @staticmethod
    def _valida(geom):
        """Ritorna una geometria valida (make-valid) se GEOS la considera
        non valida, altrimenti la geometria originale. Evita che una feature
        corrotta faccia fallire intersection()/combine()/distance()."""
        if geom is None or geom.isEmpty(): return geom
        if not geom.isGeosValid():
            fixed = geom.makeValid()
            if fixed and not fixed.isEmpty(): return fixed
        return geom

    def _req_area(self, lyr, area_geom):
        """QgsFeatureRequest con bbox limitato ad area_geom (già nel CRS
        di progetto), trasformato nel CRS di lyr se serve. Ritorna None
        se area_geom o lyr mancano (nessun filtro, layer letto per
        intero)."""
        if area_geom is None or lyr is None:
            return None
        bb = area_geom.boundingBox()
        req = QgsFeatureRequest()
        if lyr.crs() != self.project.crs():
            trasf = QgsCoordinateTransform(self.project.crs(), lyr.crs(), self.project)
            req.setFilterRect(trasf.transformBoundingBox(bb))
        else:
            req.setFilterRect(bb)
        return req

    def _build_idx(self, lyr, req=None):
        idx = QgsSpatialIndex(); by_id = {}
        it = lyr.getFeatures(req) if req else lyr.getFeatures()
        for f in it:
            g = self._to_proj(f.geometry(), lyr)
            if not g or g.isEmpty(): continue
            ff = QgsFeature(f.id()); ff.setGeometry(g)
            idx.addFeature(ff); by_id[f.id()] = (g, f)
        return idx, by_id

    @staticmethod
    def _endpoints(geom):
        """Estremi (primo/ultimo vertice) delle parti lineari di geom.
        Tipi non lineari (punti, poligoni, o geometrie/collection miste
        senza parti lineari) vengono ignorati invece di produrre risultati
        imprevedibili da asPolyline()."""
        eps = []
        if not geom or geom.isEmpty(): return eps
        if geom.type() != QgsWkbTypes.LineGeometry: return eps
        if geom.isMultipart():
            for p in geom.asGeometryCollection(): eps.extend(FTTHPermessiDialog._endpoints(p))
        else:
            pl = geom.asPolyline()
            if len(pl) >= 2: eps.append((QgsPointXY(pl[0]), QgsPointXY(pl[-1])))
        return eps

    @staticmethod
    def _trova_vicino(pt, idx, by_id, tol):
        bb = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
        for cid in idx.intersects(bb):
            e = by_id.get(cid)
            if e and pt.distance(e[0].asPoint()) <= tol: return e[1]
        return None

    @staticmethod
    def _pte_al_nodo(pa, pb, idx_pte, pte_by, tol):
        """Come _trova_vicino, ma verifica che il ROE PTE trovato sia
        realmente il NODO condiviso fra le due tratte: deve essere entro
        tolleranza sia da pa sia da pb, non solo dal primo estremo. Con
        tolleranze elevate, cercare solo vicino a pa può far scambiare per
        barriera un PTE che in realtà non è il punto di giunzione reale
        fra le due tratte."""
        bb = QgsRectangle(pa.x()-tol, pa.y()-tol, pa.x()+tol, pa.y()+tol)
        for cid in idx_pte.intersects(bb):
            e = pte_by.get(cid)
            if not e: continue
            p_pte = e[0].asPoint()
            if pa.distance(p_pte) <= tol and pb.distance(p_pte) <= tol:
                return e[1]
        return None

    def _unione_layer(self, lyr):
        """Unione di tutte le geometrie del layer in un'unica geometria,
        usata per i test di intersezione/distanza (es. dorsale Cavo Ottico).
        unaryUnion() calcola l'unione in un solo passaggio, molto più
        veloce del combine() ripetuto in loop su layer con molte feature."""
        gs = []
        for f in lyr.getFeatures():
            g = self._to_proj(f.geometry(), lyr)
            if g and not g.isEmpty(): gs.append(self._valida(g))
        if not gs: return None
        return QgsGeometry.unaryUnion(gs)

    # ═════════════════════════════════ CAMPI – COMPATIBILITÀ PROVIDER
    @staticmethod
    def _limite_nome_campo(layer):
        """Lunghezza massima ammessa per un nome di campo su questo layer, o
        None se il provider non ha un limite stretto.

        Serve perché il formato Shapefile/DBF tronca i nomi a 10 caratteri:
        se si chiede di creare 'Chilometrica' (12 caratteri) OGR crea davvero
        'Chilometri' e QGIS, che al commit confronta il campo atteso con quello
        riletto dal provider, fallisce con 'il campo con indice N non è
        uguale!' e fa rollback. Troncando il nome PRIMA di aggiungerlo,
        atteso e riletto coincidono e il salvataggio va a buon fine."""
        try:
            tipo = (layer.dataProvider().storageType() or "").lower()
        except Exception:
            return None
        if "shapefile" in tipo or "dbf" in tipo or "mapinfo" in tipo:
            return 10
        return None

    @staticmethod
    def _nome_campo_compatibile(layer, nome):
        """Nome di campo effettivamente creabile su `layer`: accenti rimossi,
        caratteri non alfanumerici sostituiti con '_', e troncatura al limite
        del provider (10 caratteri su Shapefile). Su GeoPackage/PostGIS/memory
        il nome resta invariato."""
        pulito = unicodedata.normalize("NFKD", str(nome).strip())
        pulito = "".join(c for c in pulito if not unicodedata.combining(c))
        pulito = re.sub(r"[^0-9A-Za-z_]", "_", pulito).strip("_")
        if not pulito:
            return ""
        if pulito[0].isdigit():
            pulito = "f" + pulito
        limite = FTTHPermessiDialog._limite_nome_campo(layer)
        if limite:
            pulito = pulito[:limite]
        return pulito

    def _indice_campo(self, layer, nome):
        """Indice del campo `nome` sul layer, tollerante alle differenze che i
        provider introducono da soli: confronto senza distinzione di
        maiuscole (lookupField) e ripiego sul nome troncato/normalizzato, così
        un campo scritto su Shapefile come 'Chilometri' viene trovato anche
        cercando 'Chilometrica'."""
        campi = layer.fields()
        for candidato in (nome, self._nome_campo_compatibile(layer, nome)):
            if not candidato:
                continue
            i = campi.indexOf(candidato)
            if i >= 0:
                return i
            i = campi.lookupField(candidato)
            if i >= 0:
                return i
        return -1

    def _assicura_campo(self, lyr, nome, tipo_testo=True, lunghezza=20, precisione=2):
        """Garantisce che `lyr` abbia il campo `nome`, creandolo se manca.

        Ritorna (indice, nome_reale, esito) dove esito è 'presente', 'creato'
        oppure un testo che inizia con 'fallito'. Il nome viene adattato al
        provider prima dell'aggiunta (vedi _nome_campo_compatibile): sugli
        shapefile 'Chilometrica' diventa 'Chilometri', altrimenti il commit
        fallirebbe perché QGIS confronta il campo atteso con quello riletto dal
        file. Usato sia dal punto 0 delle chilometriche sia dalla scheda
        Etichette, così la regola sta scritta in un solo posto."""
        i = self._indice_campo(lyr, nome)
        if i >= 0:
            return i, lyr.fields().at(i).name(), "presente"

        nome_eff = self._nome_campo_compatibile(lyr, nome)
        if not nome_eff:
            return -1, "", f"fallito: '{nome}' non è un nome di campo valido"
        if not self._start_edit(lyr):
            return -1, nome_eff, "fallito: impossibile avviare la modifica"

        campo = (QgsField(nome_eff, QVariant.String, "string", lunghezza) if tipo_testo
                 else QgsField(nome_eff, QVariant.Double, "double", 15, precisione))
        if not lyr.addAttribute(campo):
            lyr.rollBack()
            return -1, nome_eff, "fallito: il provider ha rifiutato l'aggiunta del campo"
        lyr.updateFields()
        if not self._commit(lyr, f"Creazione campo su {lyr.name()}"):
            return -1, nome_eff, "fallito: commit rifiutato (vedi popup)"
        lyr.updateFields()
        i = self._indice_campo(lyr, nome_eff)
        if i < 0:
            return -1, nome_eff, "fallito: commit riuscito ma il campo non risulta presente"
        return i, lyr.fields().at(i).name(), "creato"

    def _start_edit(self, layer):
        """Avvia l'editing se non già attivo. Ritorna True se il layer è
        (o è diventato) editabile."""
        return layer.isEditable() or layer.startEditing()

    def _commit(self, layer, titolo="Errore salvataggio"):
        """commitChanges() con dettaglio degli errori: se il commit fallisce
        mostra layer.commitErrors() (spesso indica subito la causa reale,
        es. vincoli del provider) invece del solo esito booleano, e fa
        rollback per non lasciare il layer in uno stato inconsistente."""
        if layer.commitChanges():
            return True
        dettagli = layer.commitErrors()
        msg = "\n".join(dettagli) if dettagli else "Errore sconosciuto durante il salvataggio."
        QMessageBox.critical(self, titolo, f"Impossibile salvare le modifiche su '{layer.name()}':\n{msg}")
        layer.rollBack()
        return False

    def _crea_layer_output(self, nome, wkb_type_str, attr_fields, chiave):
        """Crea da zero un layer 'memory' (RAM, nessun file coinvolto) con
        questo nome e questi campi, lo aggiunge al progetto, e rimuove
        l'eventuale layer generato in precedenza dalla stessa chiave
        ('keyplan' / 'inquadramento'). Un layer 'memory' fresco ad ogni
        generazione non ha NESSUNO dei problemi di fid/cache che affliggono
        i provider su file (GeoPackage/Shapefile): niente viene mai scritto
        dentro un GeoPackage, quindi il problema del fid non può più
        presentarsi. Per salvare il risultato in modo permanente, l'utente
        userà la funzione nativa di QGIS 'Esporta → Salva le entità con
        nome…' sul layer generato, quando è soddisfatto del risultato."""
        vecchio = self._output_layers.get(chiave)
        if vecchio is not None:
            try:
                if vecchio.id() in self.project.mapLayers():
                    self.project.removeMapLayer(vecchio.id())
            except Exception:
                pass
        crs = self.project.crs().authid()
        lyr = QgsVectorLayer(f"{wkb_type_str}?crs={crs}", nome, "memory")
        pr = lyr.dataProvider()
        pr.addAttributes(list(attr_fields))
        lyr.updateFields()
        self.project.addMapLayer(lyr)
        self._output_layers[chiave] = lyr
        return lyr

    def _su_cavo(self, geom_tratta, cavo_union, tol):
        """True se la tratta corre LUNGO il cavo ottico (intersezione lineare,
        non solo incrocio puntuale). Un incrocio a 90° dà lunghezza ~0."""
        if not cavo_union or cavo_union.isEmpty(): return False
        try:
            inter = self._valida(geom_tratta).intersection(cavo_union)
        except Exception:
            return False
        if not inter or inter.isEmpty(): return False
        return inter.length() > tol

    def _find_layer(self, nome):
        for l in self.project.mapLayers().values():
            if l.name() == nome: return l
        for l in self.project.mapLayers().values():
            if l.name().strip().lower() == nome.strip().lower(): return l
        return None

    def refresh_layers(self):
        """Assegna ad ogni combo il layer con il nome atteso (convenzione di
        progetto), se esiste. NON si limita più al caso 'combo vuoto'
        (currentLayer() is None): un QgsMapLayerComboBox con
        allow_empty=False seleziona da solo un layer qualsiasi (il primo
        disponibile) appena creato o quando cambia l'elenco dei layer nel
        progetto, quindi currentLayer() può risultare 'valorizzato' con il
        layer SBAGLIATO senza che questo venga mai corretto — causa concreta
        di un'estensione calcolata sul layer sbagliato (es. su un modello
        Keyplan invece che su ARLO AREA). Ora il nome atteso ha sempre la
        precedenza quando il layer esiste nel progetto."""
        preset = {
            self.cb_infra:    "03 INFRASTRUTTURE",
            self.cb_civici:   "CIVICI",
            self.cb_pte:      "ROE PTE",
            self.cb_pozzetto: "02_POZZETTO",
            self.cb_cavo:     "CAVO OTTICO",
            self.cb_cavo_raccordo: "CAVO RACCORDO",
            self.cb_k_armadio: "01_ARMADIO OTTICO",
            self.cb_k_foto:    "Punto di Ripresa Fotografico",
            self.cb_kp_infra:  "03 INFRASTRUTTURE",
            self.cb_kp_poz:    "02_POZZETTO",
            self.cb_kp_arlo:   "ARLO AREA",
            self.cb_kf_tavole:   "Poligoni Inquadramento",
            self.cb_kp_tavole:   "Poligoni Inquadramento",
            self.cb_num_keyplan: "Keyplan",
            self.cb_num_tavole:  "Poligoni Inquadramento",
            self.cb_kf_infra:    "03 INFRASTRUTTURE",
            self.cb_kf_pozzetto: "02_POZZETTO",
            self.cb_al_armadio:  "01_ARMADIO OTTICO",
            self.cb_al_infra:    "03 INFRASTRUTTURE",
            self.cb_al_poz:      "02_POZZETTO",
            self.cb_al_pte:      "ROE PTE",
            self.cb_al_cavo:     "CAVO OTTICO",
            self.cb_al_raccordo: "CAVO RACCORDO",
            self.cb_et_armadio:  "01_ARMADIO OTTICO",
            self.cb_et_poz:      "02_POZZETTO",
            self.cb_et_infra:    "03 INFRASTRUTTURE",
        }
        # i combo della scheda 'Esportazione' esistono in più copie (Comune e
        # Altri Enti): il preset va applicato ad ognuna, non solo all'ultima
        # costruita, altrimenti la prima scheda resta con il layer sbagliato
        for ctx in self._contesti_consegna:
            # lo stradario dell'evidenza non deve mai partire da un layer
            # qualsiasi: se nessuno di questi nomi esiste il combo resta come sta
            # e l'utente lo scegli a mano
            for nome_stradario in ("Stradario Provincia Italia", "Stradario",
                                   "Rete stradale", "Grafo stradale"):
                strada = self._find_layer(nome_stradario)
                if strada is not None:
                    preset[ctx["cb_ev_stradario"]] = nome_stradario
                    break
            preset[ctx["cb_c_foto"]]    = "Punto di Ripresa Fotografico"
            preset[ctx["cb_c_infra"]]   = "03 INFRASTRUTTURE"
            preset[ctx["cb_c_poz"]]     = "02_POZZETTO"
            preset[ctx["cb_c_armadio"]] = "01_ARMADIO OTTICO"

        try:
            self._popola_elenchi_suolo()
        except Exception:
            pass

        for cb, nome in preset.items():
            l = self._find_layer(nome)
            if l and cb.currentLayer() != l:
                cb.setLayer(l)

    # ═══════════════════════════════════════════════ PULIZIA – LOGICA
    def _diagnostica(self):
        infra = self.cb_infra.currentLayer()
        if not infra: QMessageBox.warning(self, "Attenzione", "Seleziona Infrastrutture."); return
        tol = self.spin_tol.value(); righe = [f"CRS progetto: {self.project.crs().authid()}  |  Tolleranza: {tol}"]
        eps = []
        for f in infra.getFeatures():
            g = self._to_proj(f.geometry(), infra)
            for p1, p2 in self._endpoints(g): eps.extend([p1, p2])
        for nome, lyr in (("Civici", self.cb_civici.currentLayer()), ("ROE PTE", self.cb_pte.currentLayer())):
            if not lyr: continue
            md = None
            for f in lyr.getFeatures():
                g = self._to_proj(f.geometry(), lyr)
                if not g: continue
                p = QgsPointXY(g.asPoint())
                for ep in eps:
                    d = p.distance(ep)
                    if md is None or d < md: md = d
            righe.append(f"Dist. min estremi Infra → {nome}: {md:.5f}" if md is not None else f"{nome}: nessun dato")
        self.log_p.setPlainText("\n".join(righe))

    @staticmethod
    def _pte_light_collegato(pt_light, idx_pte, pte_by, racc_eps, tol, trova_vicino):
        """True se pt_light (posizione di un ROE PTE 'PTE Light Diramatore') è
        collegato, tramite una tratta dello shape Cavo Raccordo, a un ALTRO
        ROE PTE (di qualsiasi tipologia) diverso da se stesso."""
        for pa, pb in racc_eps:
            for estremo, altro in ((pa, pb), (pb, pa)):
                if pt_light.distance(estremo) > tol: continue
                if pt_light.distance(altro) <= tol: continue
                if trova_vicino(altro, idx_pte, pte_by, tol):
                    return True
        return False

    def _trova_tratte(self, infra, civici, pte, tol, cavo, ferma_a_pte, cavo_racc=None):
        expr = f'"{CAMPO_STATO}" = \'{VAL_NUOVO}\''
        dati = {}
        for feat in infra.getFeatures(QgsFeatureRequest().setFilterExpression(expr)):
            g = self._to_proj(feat.geometry(), infra)
            eps = self._endpoints(g)
            if not eps: continue
            p1, p2 = eps[0]
            dati[feat.id()] = {"g": g, "p1": p1, "p2": p2}
        if not dati: return {}, 0, 0, 0

        # indici civici e PTE
        idx_civ, civ_by = self._build_idx(civici)
        idx_pte, pte_by = self._build_idx(pte)
        campo_tip_pte_ok = pte.fields().indexOf(CAMPO_TIP_PTE) >= 0

        # estremi delle tratte dello shape Cavo Raccordo (bretelle tra PTE),
        # usate per individuare un PTE Light Diramatore condiviso con un
        # altro PTE
        racc_eps = []
        if cavo_racc:
            for f in cavo_racc.getFeatures():
                g = self._to_proj(f.geometry(), cavo_racc)
                racc_eps.extend(self._endpoints(g))

        # tratte che toccano civico direttamente (SEMPRE selezionate)
        su_civico = set()
        for fid, d in dati.items():
            for pt in (d["p1"], d["p2"]):
                if self._trova_vicino(pt, idx_civ, civ_by, tol):
                    su_civico.add(fid); break

        # unione cavo ottico per check intersezione lineare
        cavo_u = self._unione_layer(cavo) if cavo else None

        # tratte che corrono lungo il cavo (escluse dalla catena, ma NON se su_civico)
        su_cavo = set()
        if cavo_u:
            for fid, d in dati.items():
                if fid not in su_civico and self._su_cavo(d["g"], cavo_u, tol):
                    su_cavo.add(fid)

        # union-find sulla connettività degli estremi: un ROE PTE di QUALSIASI
        # tipologia (compreso "PTE Light Diramatore") funge da BARRIERA — la
        # catena non viene unita oltre un punto in cui è presente un PTE,
        # perché da lì la tratta può proseguire condivisa verso un altro PTE.
        uf = _UF(list(dati.keys()))
        ep_idx = QgsSpatialIndex(); ep_own = {}; eid = 0
        for fid, d in dati.items():
            for pt in (d["p1"], d["p2"]):
                ef = QgsFeature(eid); ef.setGeometry(QgsGeometry.fromPointXY(pt))
                ep_idx.addFeature(ef); ep_own[eid] = (fid, pt); eid += 1
        n_barriera = 0
        for ea, (ta, pa) in ep_own.items():
            bb = QgsRectangle(pa.x()-tol, pa.y()-tol, pa.x()+tol, pa.y()+tol)
            for eb in ep_idx.intersects(bb):
                if eb == ea: continue
                tb, pb = ep_own[eb]
                if tb == ta or pa.distance(pb) > tol: continue
                if ferma_a_pte and self._pte_al_nodo(pa, pb, idx_pte, pte_by, tol):
                    n_barriera += 1; continue
                uf.union(ta, tb)

        result = {}; n_cat = 0; n_escl_light = 0
        for _, membri in uf.groups().items():
            ha_civico = any(m in su_civico for m in membri)
            if not ha_civico: continue
            # il gruppo è una catena valida solo se tocca un PTE da qualche
            # parte; teniamo traccia di TUTTI i PTE toccati (non solo il
            # primo) per poter verificare l'eventuale PTE Light condiviso
            pte_tocchi = {}
            for m in membri:
                for pt in (dati[m]["p1"], dati[m]["p2"]):
                    fp = self._trova_vicino(pt, idx_pte, pte_by, tol)
                    if fp: pte_tocchi[fp.id()] = (fp, pt)
            pte_ok = bool(pte_tocchi)
            n_cat += 1

            # se la catena arriva a un PTE Light Diramatore che è a sua volta
            # collegato, tramite il Cavo Raccordo, a un ALTRO ROE PTE, si
            # tratta di un raccordo condiviso con un altro permesso: l'intera
            # catena (tratte + pozzetti) va esclusa dalla selezione
            escludi_light = False
            if pte_ok and racc_eps and campo_tip_pte_ok:
                for fp, pt_pte in pte_tocchi.values():
                    if fp[CAMPO_TIP_PTE] == VAL_PTE_LIGHT and self._pte_light_collegato(
                        pt_pte, idx_pte, pte_by, racc_eps, tol, self._trova_vicino
                    ):
                        escludi_light = True; break
            if escludi_light:
                n_escl_light += 1
                continue

            for m in membri:
                # la tratta che tocca direttamente il Civico è SEMPRE
                # selezionata. Le altre tratte della stessa catena vengono
                # selezionate anche se la catena non raggiunge ancora un PTE
                # (non è più richiesto pte_ok): l'unico motivo di esclusione,
                # a parte il raccordo condiviso già gestito sopra, è correre
                # lungo il Cavo Ottico (dorsale condivisa con altri permessi).
                if m in su_civico or m not in su_cavo:
                    result[m] = dati[m]["g"]
        return result, n_cat, n_barriera // 2, len(su_cavo), n_escl_light

    def _trova_pozzetti(self, poz_lyr, tratte, tol, pte=None, cavo=None):
        if not tratte: return [], 0, 0
        idx = QgsSpatialIndex()
        for fid, g in tratte.items():
            f = QgsFeature(fid); f.setGeometry(g); idx.addFeature(f)
        idx_pte, pte_by = self._build_idx(pte) if pte else (None, None)
        cavo_u = self._unione_layer(cavo) if cavo else None
        ids = []; n_pte = 0; n_cavo = 0
        for fp in poz_lyr.getFeatures():
            gp = self._to_proj(fp.geometry(), poz_lyr)
            if not gp or gp.isEmpty(): continue
            pt = QgsPointXY(gp.asPoint())
            g_pt = QgsGeometry.fromPointXY(pt)  # costruita una sola volta per pozzetto
            bb = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
            hit = any(
                g_pt.distance(tratte[cid]) <= tol
                for cid in idx.intersects(bb) if cid in tratte
            )
            if not hit: continue
            # escludi il pozzetto sede di un PTE
            if idx_pte and self._trova_vicino(pt, idx_pte, pte_by, tol):
                n_pte += 1; continue
            # escludi il pozzetto toccato dal Cavo Ottico (dorsale condivisa)
            if cavo_u and not cavo_u.isEmpty() and g_pt.distance(cavo_u) <= tol:
                n_cavo += 1; continue
            ids.append(fp.id())
        return ids, n_pte, n_cavo

    def _r1(self):
        infra = self.cb_infra.currentLayer(); civici = self.cb_civici.currentLayer()
        pte   = self.cb_pte.currentLayer();   poz    = self.cb_pozzetto.currentLayer()
        cavo  = self.cb_cavo.currentLayer()
        cavo_racc = self.cb_cavo_raccordo.currentLayer()
        if not infra or not civici or not pte:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture, Civici e ROE PTE."); return
        tol = self.spin_tol.value()
        tratte, n_cat, n_barriera, n_cavo, n_escl_light = self._trova_tratte(
            infra, civici, pte, tol,
            cavo if self.chk_no_cavo.isChecked() else None,
            self.chk_pte_light.isChecked(),
            cavo_racc,
        )
        infra.removeSelection(); infra.selectByIds(list(tratte.keys()))
        layers = [infra]; msg = [
            f"Tratte selezionate: {len(tratte)}  (catene: {n_cat})",
            f"Punti di barriera a un PTE (catena fermata): {n_barriera}",
            f"Tratte escluse perché corrono lungo il CAVO OTTICO: {n_cavo}",
            f"Catene escluse: PTE Light collegato via Cavo Raccordo ad altro PTE: {n_escl_light}",
        ]
        if poz:
            ids_p, n_pte, n_cavo_poz = self._trova_pozzetti(
                poz, tratte, tol, pte,
                cavo if self.chk_no_cavo.isChecked() else None,
            )
            poz.removeSelection(); poz.selectByIds(ids_p)
            layers.append(poz)
            msg.append(
                f"Pozzetti compresi: {len(ids_p)}  "
                f"(esclusi sede-PTE: {n_pte}, esclusi su CAVO OTTICO: {n_cavo_poz})"
            )
        if tratte: self.iface.mapCanvas().zoomToSelected(infra)
        self._last_layers = layers; self.log_p.setPlainText("\n".join(msg))

    def _r1b(self):
        """Regola indipendente dalla Regola 1: seleziona OGNI tratta
        Infrastrutture (qualsiasi TIPOLOGIA e STATO, nessun filtro) che
        tocca/interseca direttamente un Civico su almeno un estremo, più il
        Pozzetto vicino all'estremo OPPOSTO della stessa tratta (il pozzetto
        "subito dopo" il Civico). A differenza della Regola 1, non segue la
        catena oltre la prima tratta e non si ferma a un PTE: serve proprio
        a coprire i casi che la Regola 1 (STATO='Nuovo' + logica di
        catena/PTE) lascia fuori. Si AGGIUNGE alla selezione corrente invece
        di sostituirla, così può essere usata insieme alla Regola 1.
        Il pozzetto candidato viene escluso se è vera ALMENO UNA di tre
        condizioni indipendenti (basta una sola, non serve che siano tutte
        vere): la tratta di provenienza ha TIPOLOGIA='No Dig', il pozzetto
        è sede di un ROE PTE (di qualsiasi tipologia), oppure il pozzetto è
        toccato dal layer Cavo Ottico (dorsale condivisa)."""
        infra = self.cb_infra.currentLayer(); civici = self.cb_civici.currentLayer()
        poz = self.cb_pozzetto.currentLayer(); pte = self.cb_pte.currentLayer()
        cavo = self.cb_cavo.currentLayer()
        if not infra or not civici:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e Civici."); return
        tol = self.spin_tol.value()
        idx_civ, civ_by = self._build_idx(civici)
        idx_pte, pte_by = self._build_idx(pte) if pte else (None, None)
        cavo_u = self._unione_layer(cavo) if cavo else None
        campo_tip_infra_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0

        ids_infra = []
        estremi_opposti = []  # (punto, TIPOLOGIA tratta) da cui cercare il Pozzetto "subito dopo"
        for feat in infra.getFeatures():  # nessun filtro TIPOLOGIA/STATO
            g = self._to_proj(feat.geometry(), infra)
            eps = self._endpoints(g)
            if not eps: continue
            p1, p2 = eps[0]
            tocca1 = self._trova_vicino(p1, idx_civ, civ_by, tol) is not None
            tocca2 = self._trova_vicino(p2, idx_civ, civ_by, tol) is not None
            if not (tocca1 or tocca2): continue
            ids_infra.append(feat.id())
            tip = feat[CAMPO_TIP_INFRA] if campo_tip_infra_ok else None
            if tocca1 and not tocca2: estremi_opposti.append((p2, tip))
            elif tocca2 and not tocca1: estremi_opposti.append((p1, tip))
            else: estremi_opposti.extend([(p1, tip), (p2, tip)])  # tratta tra due Civici

        ids_infra_prima = set(infra.selectedFeatureIds())
        ids_infra_finali = sorted(ids_infra_prima | set(ids_infra))
        infra.selectByIds(ids_infra_finali)
        layers = [infra]
        msg = [
            f"Tratte a contatto diretto col Civico (qualsiasi tipologia/stato): {len(ids_infra)} "
            f"(selezione Infrastrutture totale: {len(ids_infra_finali)})"
        ]

        if poz and estremi_opposti:
            idx_poz, poz_by = self._build_idx(poz)
            ids_poz = set(); ids_no_dig = set(); ids_sede_pte = set(); ids_cavo = set()
            for pt, tip in estremi_opposti:
                fp = self._trova_vicino(pt, idx_poz, poz_by, tol)
                if not fp: continue
                escludi = False
                if tip == VAL_NO_DIG:
                    ids_no_dig.add(fp.id()); escludi = True
                g_poz = poz_by[fp.id()][0]
                p_poz = QgsPointXY(g_poz.asPoint())
                if idx_pte and self._trova_vicino(p_poz, idx_pte, pte_by, tol) is not None:
                    ids_sede_pte.add(fp.id()); escludi = True
                if cavo_u and not cavo_u.isEmpty() and QgsGeometry.fromPointXY(p_poz).distance(cavo_u) <= tol:
                    ids_cavo.add(fp.id()); escludi = True
                if escludi: continue  # esclusione indipendente: basta UNA delle tre condizioni
                ids_poz.add(fp.id())
            ids_poz_prima = set(poz.selectedFeatureIds())
            ids_poz_finali = sorted(ids_poz_prima | ids_poz)
            poz.selectByIds(ids_poz_finali)
            layers.append(poz)
            dettaglio_escl = []
            if ids_no_dig: dettaglio_escl.append(f"tratta '{VAL_NO_DIG}': {len(ids_no_dig)}")
            if ids_sede_pte: dettaglio_escl.append(f"sede-PTE: {len(ids_sede_pte)}")
            if ids_cavo: dettaglio_escl.append(f"su CAVO OTTICO: {len(ids_cavo)}")
            msg.append(
                f"Pozzetti subito dopo la tratta: {len(ids_poz)} "
                f"(selezione Pozzetto totale: {len(ids_poz_finali)}"
                + (f", esclusi — {', '.join(dettaglio_escl)}" if dettaglio_escl else "")
                + ")"
            )

        if ids_infra: self.iface.mapCanvas().zoomToSelected(infra)
        # si aggiunge (non sostituisce) ai layer dell'ultima operazione, così
        # "Rimuovi elementi selezionati" tiene conto anche di questa regola
        # se usata insieme alla Regola 1 nella stessa sessione
        self._last_layers = list(dict.fromkeys(self._last_layers + layers))
        self.log_p.setPlainText("\n".join(msg))

    def _r2(self):
        infra = self.cb_infra.currentLayer(); pte = self.cb_pte.currentLayer()
        if not infra or not pte:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e ROE PTE."); return
        if pte.fields().indexOf(CAMPO_TIPO_PTE) < 0:
            QMessageBox.critical(self, "Campo mancante", f"ROE PTE non ha il campo '{CAMPO_TIPO_PTE}'."); return
        tol = self.spin_tol.value()
        idx_pte, pte_by = self._build_idx(pte)
        pte_int = {f.id() for f in pte.getFeatures() if f[CAMPO_TIPO_PTE] in VALORI_PTE_INT}
        req = QgsFeatureRequest().setFilterExpression(f'"{CAMPO_STATO}" = \'{VAL_NUOVO}\'') if self.chk_r2_nuovo.isChecked() else None
        ids = []
        for feat in (infra.getFeatures(req) if req else infra.getFeatures()):
            g = self._to_proj(feat.geometry(), infra)
            for p1, p2 in self._endpoints(g):
                for pt in (p1, p2):
                    fp = self._trova_vicino(pt, idx_pte, pte_by, tol)
                    if fp and fp.id() in pte_int: ids.append(feat.id()); break
                else: continue; break
        infra.removeSelection(); infra.selectByIds(ids)
        if ids: self.iface.mapCanvas().zoomToSelected(infra)
        self._last_layers = [infra]; self.log_p.setPlainText(f"Tratte che toccano PTE interno: {len(ids)}")

    def _r3(self):
        infra = self.cb_infra.currentLayer(); poz = self.cb_pozzetto.currentLayer()
        if not infra or not poz:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e Pozzetto."); return
        tol = self.spin_tol.value()
        idx_i, i_by = self._build_idx(infra)
        campo_tip_infra_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0
        ids = []
        for fp in poz.getFeatures():
            gp = self._to_proj(fp.geometry(), poz)
            if not gp or gp.isEmpty(): continue
            pt = QgsPointXY(gp.asPoint())
            bb = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
            tocca = tocca_n = False
            for cid in idx_i.intersects(bb):
                e = i_by.get(cid)
                if not e: continue
                g_i, f_i = e
                for pp1, pp2 in self._endpoints(g_i):
                    if pt.distance(pp1) <= tol or pt.distance(pp2) <= tol:
                        tocca = True
                        # una tratta Aerea 'Nuovo' NON conta come "nuova
                        # interrata": non deve escludere il pozzetto
                        is_aerea = campo_tip_infra_ok and f_i[CAMPO_TIP_INFRA] == VAL_AEREA
                        if f_i[CAMPO_STATO] == VAL_NUOVO and not is_aerea:
                            tocca_n = True
                        break
            if tocca and not tocca_n: ids.append(fp.id())
        poz.removeSelection(); poz.selectByIds(ids)
        if ids: self.iface.mapCanvas().zoomToSelected(poz)
        self._last_layers = [poz]; self.log_p.setPlainText(f"Pozzetti solo su esistente: {len(ids)}")

    def _r4(self):
        infra = self.cb_infra.currentLayer(); poz = self.cb_pozzetto.currentLayer(); ed = self.cb_ed_edifici.currentLayer()
        if not infra or not poz or not ed:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture, Pozzetto ed Edifici."); return
        tol = self.spin_tol.value()

        # Il layer Edifici può essere molto grande (es. un WFS/basemap con
        # decine o centinaia di migliaia di fabbricati su tutto il
        # territorio): leggerlo e riproiettarlo TUTTO, come fanno le altre
        # regole con i loro layer (piccoli, già circoscritti all'area di
        # progetto), è quello che bloccava l'interfaccia. Qui invece si
        # legge da Edifici SOLO quello che ricade nel rettangolo che
        # contiene Infrastrutture + Pozzetto (più la tolleranza) — un
        # filtro sul rettangolo (BBOX), che per un layer WFS viene anche
        # mandato al server invece di scaricare tutto.
        try:
            trasf_i = QgsCoordinateTransform(infra.crs(), self.project.crs(), self.project)
            trasf_p = QgsCoordinateTransform(poz.crs(), self.project.crs(), self.project)
            bbox = trasf_i.transformBoundingBox(infra.extent())
            bbox.combineExtentWith(trasf_p.transformBoundingBox(poz.extent()))
        except Exception:
            bbox = None
        if bbox is None or bbox.isEmpty():
            QMessageBox.warning(self, "Area non determinabile", "Impossibile calcolare l'estensione di Infrastrutture/Pozzetto."); return
        bbox.grow(tol)

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            req_ed = QgsFeatureRequest()
            if ed.crs() != self.project.crs():
                trasf_ed = QgsCoordinateTransform(self.project.crs(), ed.crs(), self.project)
                req_ed.setFilterRect(trasf_ed.transformBoundingBox(bbox))
            else:
                req_ed.setFilterRect(bbox)
            idx_ed, ed_by = self._build_idx(ed, req=req_ed)
        finally:
            QApplication.restoreOverrideCursor()

        if not ed_by:
            QMessageBox.information(
                self, "Nessun edificio nell'area",
                "Nessun elemento del layer Edifici ricade nell'area di Infrastrutture/Pozzetto\n"
                "(con la Tolleranza impostata)."
            ); return

        def toccato(geom):
            bb = geom.boundingBox(); bb.grow(tol)
            for cid in idx_ed.intersects(bb):
                e = ed_by.get(cid)
                if not e: continue
                g_ed, _f_ed = e
                if geom.intersects(g_ed) or geom.distance(g_ed) <= tol:
                    return True
            return False

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            filtro_nuovo = self.chk_r4_nuovo.isChecked()
            campo_stato_ok = infra.fields().indexOf(CAMPO_STATO) >= 0
            campo_tip_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0
            val_nuovo_norm = VAL_NUOVO.strip().lower()
            val_aerea_norm = VAL_AEREA.strip().lower()
            ids_infra = []
            for i, feat in enumerate(infra.getFeatures()):
                if filtro_nuovo and campo_stato_ok:
                    st = feat[CAMPO_STATO]
                    if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                        continue
                if campo_tip_ok:
                    # TIPOLOGIA='Aerea' esclusa sempre, a prescindere dalla
                    # spunta STATO='Nuovo' qui sopra: una tratta aerea non
                    # va selezionata da questa regola in nessun caso.
                    tip = feat[CAMPO_TIP_INFRA]
                    if isinstance(tip, str) and tip.strip().lower() == val_aerea_norm:
                        continue
                g = self._to_proj(feat.geometry(), infra)
                if g and not g.isEmpty() and toccato(g):
                    ids_infra.append(feat.id())
                if i % 200 == 0: QApplication.processEvents()
            infra.removeSelection(); infra.selectByIds(ids_infra)

            ids_poz = []
            for i, feat in enumerate(poz.getFeatures()):
                g = self._to_proj(feat.geometry(), poz)
                if g and not g.isEmpty() and toccato(g):
                    ids_poz.append(feat.id())
                if i % 200 == 0: QApplication.processEvents()
            poz.removeSelection(); poz.selectByIds(ids_poz)
        finally:
            QApplication.restoreOverrideCursor()

        con_sel = [l for l in (infra, poz) if l.selectedFeatureCount() > 0]
        if con_sel: self.iface.mapCanvas().zoomToSelected(con_sel[0])
        self._last_layers = [infra, poz]
        self.log_p.setPlainText(
            f"Edifici letti nell'area di interesse: {len(ed_by)}\n"
            f"Tratte Infrastrutture toccate da Edifici (esclusa TIPOLOGIA='{VAL_AEREA}'"
            + (", solo STATO='Nuovo'" if filtro_nuovo else "") + f"): {len(ids_infra)}\n"
            f"Pozzetti toccati da Edifici: {len(ids_poz)}"
        )

    # ═══════════════════════════════════════ PROPRIETÀ PRIVATA (OSM)
    _OVERPASS_MIRRORS = [
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass.openstreetmap.ru/api/interpreter",
    ]

    def _scarica_strade_osm(self, sud, ovest, nord, est):
        """Interroga Overpass API (con mirror di riserva se il primo non
        risponde) per le strade (highway=*) nel bbox WGS84 dato, con
        'out geom' così ogni via arriva già con le coordinate dei suoi nodi
        incluse: non serve una seconda passata per risolvere i riferimenti
        ai nodi. highway=* comprende già marciapiedi e aree pedonali
        (footway, pedestrian, living_street, ecc.), non solo le strade
        carrabili. Ritorna (linee, aree): `linee` sono le liste di
        coordinate (lon, lat) delle vie aperte, da bufferizzare come
        strade; `aree` sono gli anelli chiusi (es. piazze/aree pedonali
        mappate come poligono, primo e ultimo nodo coincidenti) — vanno
        prese come superficie piena, non come una sottile fascia
        bufferizzata attorno al solo perimetro, altrimenti una piazza
        larga risulterebbe quasi tutta 'privata' per errore.
        Solleva RuntimeError con un messaggio leggibile se tutti i mirror
        falliscono (rete assente, timeout, area troppo grande…)."""
        query = (
            f"[out:json][timeout:50];"
            f"way[\"highway\"]({sud:.6f},{ovest:.6f},{nord:.6f},{est:.6f});"
            f"out geom;"
        )
        dati = urllib.parse.urlencode({"data": query}).encode("utf-8")
        ultimo_errore = None
        for url in self._OVERPASS_MIRRORS:
            try:
                req = urllib.request.Request(url, data=dati, headers={"User-Agent": "FTTH-Permessi-Manager-QGIS-plugin"})
                with urllib.request.urlopen(req, timeout=55) as resp:
                    body = json.loads(resp.read().decode("utf-8"))
                linee = []; aree = []
                for el in body.get("elements", []):
                    if el.get("type") != "way": continue
                    geom = el.get("geometry")
                    if not geom or len(geom) < 2: continue
                    coords = [(pt["lon"], pt["lat"]) for pt in geom]
                    chiusa = len(coords) >= 4 and coords[0] == coords[-1]
                    if chiusa: aree.append(coords)
                    else: linee.append(coords)
                return linee, aree
            except Exception as e:
                ultimo_errore = e
                continue
        raise RuntimeError(
            f"Impossibile contattare Overpass API (nessuno dei {len(self._OVERPASS_MIRRORS)} mirror ha risposto).\n"
            f"Verifica la connessione a internet. Dettaglio ultimo tentativo: {ultimo_errore}"
        )

    def _genera_sedime_osm(self):
        infra = self.cb_infra.currentLayer(); poz = self.cb_pozzetto.currentLayer()
        if not infra or not poz:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e Pozzetto."); return

        try:
            trasf_i = QgsCoordinateTransform(infra.crs(), self.project.crs(), self.project)
            trasf_p = QgsCoordinateTransform(poz.crs(), self.project.crs(), self.project)
            bbox = trasf_i.transformBoundingBox(infra.extent())
            bbox.combineExtentWith(trasf_p.transformBoundingBox(poz.extent()))
        except Exception:
            bbox = None
        if bbox is None or bbox.isEmpty():
            QMessageBox.warning(self, "Area non determinabile", "Impossibile calcolare l'estensione di Infrastrutture/Pozzetto."); return
        bbox.grow(self.spin_osm_margine.value())

        wgs84 = QgsCoordinateReferenceSystem("EPSG:4326")
        try:
            bbox_wgs = QgsCoordinateTransform(self.project.crs(), wgs84, self.project).transformBoundingBox(bbox)
        except Exception as e:
            QMessageBox.critical(self, "Errore trasformazione", f"Impossibile convertire l'area in EPSG:4326: {e}"); return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            try:
                linee_ll, aree_ll = self._scarica_strade_osm(bbox_wgs.yMinimum(), bbox_wgs.xMinimum(), bbox_wgs.yMaximum(), bbox_wgs.xMaximum())
            except RuntimeError as e:
                QMessageBox.critical(self, "Errore download OSM", str(e)); return

            if not linee_ll and not aree_ll:
                QMessageBox.information(self, "Nessuna strada trovata", "Overpass non ha restituito nessuna strada (highway) in quest'area."); return

            trasf_osm = QgsCoordinateTransform(wgs84, self.project.crs(), self.project)
            largh = self.spin_osm_largh.value()
            parti_sedime = []
            for coords in linee_ll:
                g = QgsGeometry.fromPolylineXY([QgsPointXY(lon, lat) for lon, lat in coords])
                try:
                    g.transform(trasf_osm)
                except Exception:
                    continue
                if g.isEmpty(): continue
                parti_sedime.append(g.buffer(largh / 2.0, 5))

            # Piazze/aree pedonali (vie chiuse, es. highway=pedestrian con
            # area=yes): prese come superficie piena, non come una fascia
            # bufferizzata attorno al solo perimetro — altrimenti una
            # piazza larga risulterebbe quasi tutta scoperta (e quindi
            # segnalata come possibile privato) per un limite del solo
            # buffer stradale.
            n_aree_valide = 0
            for coords in aree_ll:
                g = QgsGeometry.fromPolygonXY([[QgsPointXY(lon, lat) for lon, lat in coords]])
                try:
                    g.transform(trasf_osm)
                except Exception:
                    continue
                if g.isEmpty(): continue
                if not g.isGeosValid():
                    g = g.buffer(0, 5)
                    if not g or g.isEmpty(): continue
                parti_sedime.append(g)
                n_aree_valide += 1

            if not parti_sedime:
                QMessageBox.warning(self, "Nessuna geometria valida", "Le strade scaricate non hanno prodotto geometrie valide dopo la trasformazione."); return

            sedime = QgsGeometry.unaryUnion(parti_sedime)
            sedime.convertToMultiType()
            lyr = self._crea_layer_output("Sedime Pubblico", "MultiPolygon", [], "sedime_osm")
            nf = QgsFeature(lyr.fields()); nf.setGeometry(sedime)
            lyr.dataProvider().addFeatures([nf])
            lyr.updateExtents(); lyr.triggerRepaint()
        finally:
            QApplication.restoreOverrideCursor()

        msg = (
            f"Sedime Pubblico generato da OSM: {len(linee_ll)} strade (bufferizzate "
            f"a {largh:g} m) + {n_aree_valide} piazze/aree pedonali (prese come superficie "
            "piena, non bufferizzate).\nRicorda: è una stima automatica (OSM può essere "
            "incompleto), non un confine legale — verifica sempre a vista."
        )
        self.log_p.setPlainText(msg)
        QMessageBox.information(self, "Sedime generato", msg)

    def _genera_sedime_locale(self):
        """Come '_genera_sedime_osm', ma legge le strade da un layer già
        caricato in locale (es. uno Stradario Italia) invece di scaricarle
        da OSM: stessa bufferizzazione (elementi lineari bufferizzati,
        elementi poligonali — piazze/aree pedonali — presi come superficie
        piena), stesso layer temporaneo risultante ('Sedime Pubblico'),
        ma senza nessuna chiamata di rete e con dati sotto il controllo
        dell'utente. Il layer locale può contenere sia linee sia poligoni
        mescolati: ogni feature viene trattata secondo il proprio tipo di
        geometria."""
        infra = self.cb_infra.currentLayer(); poz = self.cb_pozzetto.currentLayer()
        locale = self.cb_sedime_locale.currentLayer()
        if not infra or not poz or not locale:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture, Pozzetto e lo Stradario locale."); return

        try:
            trasf_i = QgsCoordinateTransform(infra.crs(), self.project.crs(), self.project)
            trasf_p = QgsCoordinateTransform(poz.crs(), self.project.crs(), self.project)
            bbox = trasf_i.transformBoundingBox(infra.extent())
            bbox.combineExtentWith(trasf_p.transformBoundingBox(poz.extent()))
        except Exception:
            bbox = None
        if bbox is None or bbox.isEmpty():
            QMessageBox.warning(self, "Area non determinabile", "Impossibile calcolare l'estensione di Infrastrutture/Pozzetto."); return
        bbox.grow(self.spin_osm_margine.value())

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            req = QgsFeatureRequest()
            if locale.crs() != self.project.crs():
                trasf_l = QgsCoordinateTransform(self.project.crs(), locale.crs(), self.project)
                req.setFilterRect(trasf_l.transformBoundingBox(bbox))
            else:
                req.setFilterRect(bbox)

            largh = self.spin_osm_largh.value()
            parti_sedime = []; n_linee = 0; n_aree = 0
            for f in locale.getFeatures(req):
                g = self._to_proj(f.geometry(), locale)
                if not g or g.isEmpty(): continue
                if QgsWkbTypes.geometryType(g.wkbType()) == QgsWkbTypes.PolygonGeometry:
                    if not g.isGeosValid():
                        g = g.buffer(0, 5)
                        if not g or g.isEmpty(): continue
                    parti_sedime.append(g); n_aree += 1
                else:
                    parti_sedime.append(g.buffer(largh / 2.0, 5)); n_linee += 1

            if not parti_sedime:
                QMessageBox.information(self, "Nessun elemento trovato", "Il layer Stradario locale non ha elementi nell'area di Infrastrutture/Pozzetto (con il margine impostato)."); return

            sedime = QgsGeometry.unaryUnion(parti_sedime)
            sedime.convertToMultiType()
            lyr = self._crea_layer_output("Sedime Pubblico", "MultiPolygon", [], "sedime_osm")
            nf = QgsFeature(lyr.fields()); nf.setGeometry(sedime)
            lyr.dataProvider().addFeatures([nf])
            lyr.updateExtents(); lyr.triggerRepaint()
        finally:
            QApplication.restoreOverrideCursor()

        msg = (
            f"Sedime Pubblico generato da '{locale.name()}' (locale, nessuna chiamata di "
            f"rete): {n_linee} elementi lineari bufferizzati a {largh:g} m + {n_aree} "
            "elementi poligonali presi come superficie piena."
        )
        self.log_p.setPlainText(msg)
        QMessageBox.information(self, "Sedime generato", msg)

    def _r5_privata(self):
        infra = self.cb_infra.currentLayer(); poz = self.cb_pozzetto.currentLayer()
        if not infra or not poz:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e Pozzetto."); return
        custom_lyr = self.cb_sedime_custom.currentLayer()
        if custom_lyr:
            sedime_lyr = custom_lyr; nome_sedime = f"'{custom_lyr.name()}' (sedime alternativo)"
        else:
            sedime_lyr = self._output_layers.get("sedime_osm")
            if sedime_lyr is None or sedime_lyr.id() not in self.project.mapLayers():
                QMessageBox.warning(self, "Sedime non generato", "Genera prima il Sedime Pubblico (pulsante '1a' o '1b' qui sopra), oppure imposta un sedime già pronto."); return
            nome_sedime = "Sedime Pubblico"
        sedime = self._unione_layer(sedime_lyr)
        if not sedime or sedime.isEmpty():
            QMessageBox.warning(self, "Sedime vuoto", f"Il layer {nome_sedime} non contiene geometrie valide."); return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            ids_infra = []
            for i, feat in enumerate(infra.getFeatures()):
                g = self._to_proj(feat.geometry(), infra)
                if g and not g.isEmpty() and g.disjoint(sedime):
                    ids_infra.append(feat.id())
                if i % 200 == 0: QApplication.processEvents()
            infra.removeSelection(); infra.selectByIds(ids_infra)

            ids_poz = []
            for i, feat in enumerate(poz.getFeatures()):
                g = self._to_proj(feat.geometry(), poz)
                if g and not g.isEmpty() and g.disjoint(sedime):
                    ids_poz.append(feat.id())
                if i % 200 == 0: QApplication.processEvents()
            poz.removeSelection(); poz.selectByIds(ids_poz)
        finally:
            QApplication.restoreOverrideCursor()

        con_sel = [l for l in (infra, poz) if l.selectedFeatureCount() > 0]
        if con_sel: self.iface.mapCanvas().zoomToSelected(con_sel[0])
        self._last_layers = [infra, poz]
        self.log_p.setPlainText(
            f"Possibile proprietà privata (fuori dal sedime {nome_sedime}):\n"
            f"Tratte: {len(ids_infra)}\nPozzetti: {len(ids_poz)}\n"
            "Preselezione da verificare sempre a vista, non è una classificazione legale."
        )

    # ═══════════════════════════════════════ ALLINEA CARTOGRAFIA
    @staticmethod
    def _fit_similarity(coppie):
        """Miglior trasformazione di similitudine (traslazione + rotazione
        + scala uniforme, NESSUNA deformazione locale) che porta i punti
        sorgente sui punti di riferimento, ai minimi quadrati. Ogni punto è
        trattato come numero complesso (x+iy): la trasformazione è
        z' = a*z + b, dove |a| è la scala e arg(a) la rotazione. Con 2
        coppie la soluzione è esatta; con più coppie minimizza lo scarto
        complessivo (coppie imprecise si compensano a vicenda). Ritorna
        (a, b, residuo_rms_metri) o None se le coppie sono meno di 2 o
        tutte coincidenti (nessuna informazione di scala/rotazione)."""
        if len(coppie) < 2: return None
        s = [complex(p.x(), p.y()) for p, _ in coppie]
        t = [complex(p.x(), p.y()) for _, p in coppie]
        n = len(s)
        ms = sum(s) / n; mt = sum(t) / n
        num = sum((ti - mt) * (si - ms).conjugate() for si, ti in zip(s, t))
        den = sum(abs(si - ms) ** 2 for si in s)
        if den == 0: return None
        a = num / den
        b = mt - a * ms
        residui = [abs(ti - (a * si + b)) for si, ti in zip(s, t)]
        rms = (sum(r * r for r in residui) / n) ** 0.5
        return a, b, rms

    def _mostra_anteprima_trasformazione(self, ris, n_punti, fonte):
        if ris is None:
            self._trasformazione = None
            self.lbl_al_preview.setText("Trasformazione non calcolabile con questi dati (punti insufficienti o tutti coincidenti).")
            return
        a, b, rms = ris
        self._trasformazione = (a, b)
        scala = abs(a); rot = math.degrees(math.atan2(a.imag, a.real))
        self.lbl_al_preview.setText(
            f"Trasformazione calcolata da {fonte} ({n_punti} punti): rotazione {rot:.2f}°, "
            f"scala {scala:.5f}, traslazione ({b.real:.2f}, {b.imag:.2f}) m, "
            f"errore residuo RMS {rms:.2f} m. Verifica che sia plausibile prima di applicarla."
        )

    def _avvia_cattura_coppia(self):
        canvas = self.iface.mapCanvas()
        self.lbl_al_stato.setText("Clicca sulla mappa il punto sulla TUA rete…")
        def su_primo_punto(pt_sorgente):
            self.lbl_al_stato.setText("Ora clicca il punto corrispondente sul riferimento (es. WMS)…")
            def su_secondo_punto(pt_riferimento):
                self._punti_controllo.append((pt_sorgente, pt_riferimento))
                d = pt_sorgente.distance(pt_riferimento)
                self.lst_al_punti.addItem(
                    f"{len(self._punti_controllo)}) rete ({pt_sorgente.x():.2f}, {pt_sorgente.y():.2f}) → "
                    f"riferimento ({pt_riferimento.x():.2f}, {pt_riferimento.y():.2f})  [{d:.2f} m]"
                )
                self.lbl_al_stato.setText(f"Coppia {len(self._punti_controllo)} aggiunta. Puoi aggiungerne un'altra.")
                self._tool_clic = None
            self._tool_clic = _StrumentoClicPunto(canvas, su_secondo_punto)
            canvas.setMapTool(self._tool_clic)
        self._tool_clic = _StrumentoClicPunto(canvas, su_primo_punto)
        canvas.setMapTool(self._tool_clic)

    def _rimuovi_ultima_coppia(self):
        if not self._punti_controllo: return
        self._punti_controllo.pop()
        self.lst_al_punti.takeItem(self.lst_al_punti.count() - 1)
        self.lbl_al_stato.setText(f"{len(self._punti_controllo)} coppie rimaste.")

    def _svuota_coppie(self):
        self._punti_controllo = []
        self.lst_al_punti.clear()
        self.lbl_al_stato.setText("")

    def _calcola_trasf_punti(self):
        if len(self._punti_controllo) < 2:
            QMessageBox.warning(self, "Punti insufficienti", "Servono almeno 2 coppie di punti di controllo."); return
        ris = self._fit_similarity(self._punti_controllo)
        self._mostra_anteprima_trasformazione(ris, len(self._punti_controllo), "punti di controllo")

    def _applica_trasformazione(self):
        if self._trasformazione is None:
            QMessageBox.warning(self, "Nessuna trasformazione", "Calcola prima la trasformazione (sezione A o B sopra)."); return
        a, b = self._trasformazione
        qt = QTransform(a.real, a.imag, -a.imag, a.real, b.real, b.imag)

        layers = [l for l in (
            self.cb_al_armadio.currentLayer(), self.cb_al_infra.currentLayer(),
            self.cb_al_poz.currentLayer(), self.cb_al_pte.currentLayer(),
            self.cb_al_cavo.currentLayer(), self.cb_al_raccordo.currentLayer(),
        ) if l is not None]
        if not layers:
            QMessageBox.warning(self, "Nessun layer", "Imposta almeno un layer da spostare nella sezione 'Layer da spostare insieme'."); return

        risposta = QMessageBox.question(
            self, "Conferma spostamento",
            f"Stai per spostare {len(layers)} layer applicando la trasformazione calcolata "
            "(traslazione + rotazione + scala). L'operazione modifica le geometrie sul posto "
            "e non è annullabile da questo plugin (solo con Annulla di QGIS, se il layer è "
            "ancora in editing). Procedere?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if risposta != QMessageBox.Yes: return

        solo_sel = self.chk_al_solo_sel.isChecked()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        totali = {}
        try:
            for lyr in layers:
                if solo_sel and lyr.selectedFeatureCount() == 0:
                    totali[lyr.name()] = "saltato: nessun elemento selezionato"
                    continue
                era = lyr.isEditable()
                if not self._start_edit(lyr):
                    totali[lyr.name()] = "ERRORE avvio editing"; continue
                ids = lyr.selectedFeatureIds() if solo_sel else [f.id() for f in lyr.getFeatures()]
                n = 0
                for fid in ids:
                    feat = lyr.getFeature(fid)
                    g = QgsGeometry(feat.geometry())
                    if lyr.crs() != self.project.crs():
                        g.transform(QgsCoordinateTransform(lyr.crs(), self.project.crs(), self.project))
                    g.transform(qt)
                    if lyr.crs() != self.project.crs():
                        g.transform(QgsCoordinateTransform(self.project.crs(), lyr.crs(), self.project))
                    lyr.changeGeometry(fid, g)
                    n += 1
                if not era and not self._commit(lyr, f"Errore salvataggio su '{lyr.name()}'"):
                    totali[lyr.name()] = "ERRORE commit"; continue
                lyr.triggerRepaint()
                totali[lyr.name()] = f"{n} elementi spostati"
        finally:
            QApplication.restoreOverrideCursor()

        testo = "\n".join(f"{nome}: {esito}" for nome, esito in totali.items())
        self.log_al.setPlainText(testo)
        QMessageBox.information(self, "Allineamento applicato", testo)

    def _rimuovi(self):
        if not self._last_layers:
            QMessageBox.information(self, "Nessuna operazione", "Esegui prima una delle regole."); return
        det = []; tot = 0; ls = []
        for l in self._last_layers:
            n = l.selectedFeatureCount()
            if n > 0: det.append(f"- {l.name()}: {n}"); tot += n; ls.append(l)
        if not tot:
            QMessageBox.information(self, "Nessuna selezione", "Nessun elemento selezionato."); return
        if QMessageBox.question(self, "Conferma", "Eliminare definitivamente:\n"+"\n".join(det),
                QMessageBox.Yes|QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
        err = []
        for l in ls:
            era = l.isEditable()
            if not self._start_edit(l): err.append(f"{l.name()}: impossibile avviare l'editing"); continue
            if not l.deleteSelectedFeatures(): err.append(f"{l.name()}: eliminazione fallita"); continue
            if not era and not self._commit(l, "Errore eliminazione"): err.append(f"{l.name()}: commit fallito (dettagli nel popup)"); continue
            l.triggerRepaint()
        if err: QMessageBox.critical(self, "Errori", "\n".join(err))
        else:   QMessageBox.information(self, "OK", f"{tot} elementi rimossi.")

    # ═══════════════════════════════════════════════ CONSEGNA – LOGICA
    def _join_nn(self, inp, join, out, prefix, max_d, scarta_non_corrispondenti=False):
        """Esegue il join by nearest e scrive il risultato in 'out' come
        Shapefile in modo esplicito. Non ci si fida del parametro OUTPUT
        passato direttamente all'algoritmo di processing: a seconda dei
        casi (es. ARMADI_FOTO) l'algoritmo può restituire un output con un
        formato/provider diverso da quello atteso dall'estensione .shp e il
        file risultante non viene poi caricato correttamente nel progetto.
        Si esegue quindi il join su un output in memoria e si scrive il
        layer risultante su disco con QgsVectorFileWriter, stesso approccio
        già usato per il salvataggio su GeoPackage.
        Se `scarta_non_corrispondenti` è True, gli elementi di 'inp' senza
        un elemento di 'join' entro la Distanza max vengono ESCLUSI
        dall'output invece di comparire con i campi uniti vuoti."""
        import processing
        risultato = processing.run("native:joinbynearest", {
            'INPUT': inp, 'INPUT_2': join, 'FIELDS_TO_COPY': [],
            'DISCARD_NONMATCHING': scarta_non_corrispondenti, 'PREFIX': prefix, 'NEIGHBORS': 1,
            'MAX_DISTANCE': max_d if max_d > 0 else None, 'OUTPUT': 'memory:',
        })
        lyr = risultato.get('OUTPUT')
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            raise RuntimeError(f"Join fallito: impossibile ottenere un risultato valido per '{os.path.basename(out)}'.")
        opzioni = QgsVectorFileWriter.SaveVectorOptions()
        opzioni.driverName = "ESRI Shapefile"
        opzioni.fileEncoding = "UTF-8"
        opzioni.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        errore = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, out, self.project.transformContext(), opzioni)
        codice_errore = errore[0] if isinstance(errore, tuple) else errore
        if codice_errore != QgsVectorFileWriter.NoError:
            dettaglio = errore[1] if isinstance(errore, tuple) and len(errore) > 1 else str(errore)
            raise RuntimeError(f"Scrittura shapefile fallita per '{os.path.basename(out)}':\n{dettaglio}")

    @staticmethod
    def _rm_shp(path):
        base = os.path.splitext(path)[0]
        for ext in (".shp",".shx",".dbf",".prj",".cpg",".qix"):
            p = base+ext
            if os.path.exists(p):
                try: os.remove(p)
                except OSError: pass

    def _doppio_join(self, inp, j1, pref1, j2, pref2, out, max_d):
        import tempfile, uuid
        tmp = os.path.join(tempfile.gettempdir(), f"ftth_{uuid.uuid4().hex}.shp")
        self._join_nn(inp, j1, tmp, pref1, max_d)
        lyr = QgsVectorLayer(tmp, "tmp", "ogr")
        if not lyr.isValid(): raise RuntimeError(f"Join intermedio fallito: {tmp}")
        self._join_nn(lyr, j2, out, pref2, max_d)
        del lyr; self._rm_shp(tmp)

    def _aggiorna_lunghezza_infra(self, infra_lyr):
        """Aggiorna i valori di LUNGHEZZA e Lungh nel layer Infrastrutture,
        usando la stessa espressione '$Length' del calcolatore di campi di
        QGIS (non un semplice geometry().length()): il valore scritto
        coincide con quello del calcolatore di campi (compresa l'eventuale
        misura ellissoidica di progetto). Se uno dei due campi esiste già
        nello shape, viene SOLO aggiornato; se manca, viene creato ora."""
        era = infra_lyr.isEditable()
        if not self._start_edit(infra_lyr):
            raise RuntimeError(f"Impossibile avviare la modifica su '{infra_lyr.name()}'.")
        fields = infra_lyr.fields()
        if fields.indexOf(CAMPO_LUNGHEZZA) < 0:
            infra_lyr.addAttribute(QgsField(CAMPO_LUNGHEZZA, QVariant.Double, "double", 15, 2))
            infra_lyr.updateFields(); fields = infra_lyr.fields()
        if fields.indexOf(CAMPO_LUNGH_NEW) < 0:
            infra_lyr.addAttribute(QgsField(CAMPO_LUNGH_NEW, QVariant.Double, "double", 15, 2))
            infra_lyr.updateFields(); fields = infra_lyr.fields()
        idx_lungh    = fields.indexOf(CAMPO_LUNGHEZZA)
        idx_lungh_new = fields.indexOf(CAMPO_LUNGH_NEW)
        espressione = QgsExpression("$Length")
        contesto = QgsExpressionContext()
        contesto.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(infra_lyr))
        if espressione.hasParserError():
            raise RuntimeError(f"Espressione '$Length' non valida: {espressione.parserErrorString()}")
        for feat in infra_lyr.getFeatures():
            contesto.setFeature(feat)
            valore = espressione.evaluate(contesto)
            if espressione.hasEvalError():
                # ripiego robusto: calcolo diretto dalla geometria
                valore = feat.geometry().length() if feat.geometry() else 0.0
            try:
                valore = round(float(valore), 2)
            except (TypeError, ValueError):
                valore = 0.0
            if idx_lungh >= 0:     infra_lyr.changeAttributeValue(feat.id(), idx_lungh,     valore)
            if idx_lungh_new >= 0: infra_lyr.changeAttributeValue(feat.id(), idx_lungh_new, valore)
        if not era and not self._commit(infra_lyr, "Errore aggiornamento LUNGHEZZA"):
            raise RuntimeError(f"Commit fallito su '{infra_lyr.name()}' (vedi dettagli nel popup).")

    @staticmethod
    def _conta_feature(path):
        """Numero di feature nello shapefile scritto su disco in `path`,
        o None se non è possibile riaprirlo."""
        l = QgsVectorLayer(path, "conta", "ogr")
        return l.featureCount() if l.isValid() else None

    def _civico_999_a_snc(self, path):
        """Nello shape ARMADI_FOTO, sostituisce i valori '999' del campo
        CIVICO con 'SNC'. Se il campo è numerico viene convertito in campo
        testo (serve per poter scrivere 'SNC'), preservando gli altri
        valori. Ritorna il numero di valori sostituiti (0 se il campo
        CIVICO non esiste o non contiene nessun '999')."""
        l = QgsVectorLayer(path, "ARMADI_FOTO", "ogr")
        if not l.isValid():
            raise RuntimeError("Impossibile riaprire 'ARMADI_FOTO' per la sostituzione del CIVICO.")
        idx = l.fields().indexOf(CAMPO_CIVICO)
        if idx < 0:
            return 0
        campo_testo = l.fields().at(idx).type() == QVariant.String
        if not self._start_edit(l):
            raise RuntimeError("Impossibile avviare la modifica su 'ARMADI_FOTO' (campo CIVICO).")
        n = 0
        if campo_testo:
            for f in l.getFeatures():
                v = f[CAMPO_CIVICO]
                if v is not None and str(v).strip() == VAL_CIVICO_999:
                    l.changeAttributeValue(f.id(), idx, VAL_CIVICO_SNC); n += 1
        else:
            # campo numerico: serve un campo testo per poter scrivere 'SNC'
            tmp = "CIVICO_T"
            l.addAttribute(QgsField(tmp, QVariant.String, "string", 20))
            l.updateFields()
            idx_tmp = l.fields().indexOf(tmp)
            for f in l.getFeatures():
                v = f[CAMPO_CIVICO]
                if v is None:
                    testo = None
                elif float(v) == float(VAL_CIVICO_999):
                    testo = VAL_CIVICO_SNC; n += 1
                else:
                    testo = str(int(v)) if float(v).is_integer() else str(v)
                l.changeAttributeValue(f.id(), idx_tmp, testo)
            l.deleteAttribute(idx)
            l.updateFields()
            idx_tmp = l.fields().indexOf(tmp)
            if l.dataProvider().capabilities() & l.dataProvider().RenameAttributes:
                l.renameAttribute(idx_tmp, CAMPO_CIVICO)
        if not self._commit(l, "Errore sostituzione CIVICO in ARMADI_FOTO"):
            raise RuntimeError("Commit fallito sostituendo CIVICO in 'ARMADI_FOTO'.")
        del l
        return n


    def _pulisci_campo_n(self, path, nome_layer):
        """Dopo il join, elimina dallo shape le feature con l'attributo 'n'
        diverso da 1 (incluso mancante/NULL): con NEIGHBORS=1 dovrebbe
        essere sempre 1, ma se più elementi si trovano esattamente alla
        STESSA distanza minima il join può restituire più righe per lo
        stesso elemento di partenza — se ne tiene solo una. Se il campo
        'n' non esiste (nessun join effettuato per questo shape) non fa
        nulla. Ritorna il numero di feature eliminate."""
        l = QgsVectorLayer(path, nome_layer, "ogr")
        if not l.isValid():
            raise RuntimeError(f"Impossibile riaprire '{nome_layer}' per il controllo del campo 'n'.")
        if l.fields().indexOf("n") < 0:
            return 0
        req = QgsFeatureRequest().setFilterExpression('"n" IS NULL OR "n" <> 1').setSubsetOfAttributes([])
        ids = [f.id() for f in l.getFeatures(req)]
        if not ids:
            return 0
        if not self._start_edit(l):
            raise RuntimeError(f"Impossibile avviare la modifica su '{nome_layer}' per pulire il campo 'n'.")
        if not l.deleteFeatures(ids):
            raise RuntimeError(f"Eliminazione fallita ripulendo '{nome_layer}' (campo 'n').")
        if not self._commit(l, f"Errore pulizia campo 'n' su {nome_layer}"):
            raise RuntimeError(f"Commit fallito ripulendo '{nome_layer}' (vedi dettagli nel popup).")
        del l
        return len(ids)

    def _genera_consegna(self):
        foto    = self.cb_c_foto.currentLayer()
        armadio = self.cb_c_armadio.currentLayer() if self.chk_c_join_armadio.isChecked() else None
        # Base SEMPRE il layer '03 INFRASTRUTTURE' del progetto (per nome,
        # non quello che capita di avere selezionato la combo in questo
        # momento): sia l'aggiornamento di LUNGHEZZA/Lungh sia il join
        # partono da questo stesso layer, così i due passaggi lavorano
        # sempre sullo stesso oggetto.
        infra = self._find_layer("03 INFRASTRUTTURE")
        if infra:
            if self.cb_c_infra.currentLayer() != infra: self.cb_c_infra.setLayer(infra)
        else:
            infra = self.cb_c_infra.currentLayer()  # ripiego se il progetto non ha un layer con quel nome esatto
        strada  = self.cb_c_strada.currentLayer() if self.chk_c_join_strada.isChecked() else None
        poz     = self.cb_c_poz.currentLayer()
        mancanti = [n for n, l in (("Foto", foto), ("Infrastrutture", infra), ("Pozzetto", poz)) if not l]
        if mancanti:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona:\n- "+"\n- ".join(mancanti)); return
        cartella = QFileDialog.getExistingDirectory(self, "Cartella di destinazione")
        if not cartella: return
        max_d = self.spin_c_dist.value()
        p1 = os.path.join(cartella, "ARMADI_FOTO.shp")
        p2 = os.path.join(cartella, "SCAVI_STRADE.shp")
        p3 = os.path.join(cartella, "POZZETTI_STRADE.shp")
        self.log_c.setPlainText("Aggiorno LUNGHEZZA/Lungh in Infrastrutture (03 INFRASTRUTTURE)…"); self.repaint()
        try:
            # aggiorna campi lunghezza nel layer sorgente '03 INFRASTRUTTURE'
            self._aggiorna_lunghezza_infra(infra)
            # 1) ARMADI_FOTO = Armadio Ottico + Foto (nearest), UN SOLO
            # elemento per Armadio Ottico: la base del join deve essere
            # l'Armadio (non il Punto di Ripresa), altrimenti si ottiene
            # una riga per OGNI punto di ripresa (compresi quelli generati
            # per attraversamenti/tavole, non legati a un armadio) invece
            # che una per ogni armadio. Confermato dallo schema di
            # riferimento: i campi dell'Armadio Ottico vengono per primi,
            # seguiti da quelli del Punto di Ripresa più vicino.
            n_armadi = armadio.featureCount() if armadio else None
            if armadio:
                self._join_nn(armadio, foto, p1, "", max_d)
            else:
                QgsVectorFileWriter.writeAsVectorFormat(foto, p1, "UTF-8")
            n_civico = self._civico_999_a_snc(p1)
            # 2) SCAVI_STRADE = Infra + Stradario + Armadio Ottico
            if strada and armadio:
                self._doppio_join(infra, strada, "", armadio, "", p2, max_d)
            elif strada:
                self._join_nn(infra, strada, p2, "", max_d)
            elif armadio:
                self._join_nn(infra, armadio, p2, "", max_d)
            else:
                QgsVectorFileWriter.writeAsVectorFormat(infra, p2, "UTF-8")
            # 3) POZZETTI_STRADE = Pozzetto + Stradario + Armadio Ottico
            if strada and armadio:
                self._doppio_join(poz, strada, "", armadio, "", p3, max_d)
            elif strada:
                self._join_nn(poz, strada, p3, "", max_d)
            elif armadio:
                self._join_nn(poz, armadio, p3, "", max_d)
            else:
                QgsVectorFileWriter.writeAsVectorFormat(poz, p3, "UTF-8")
            # prima di considerarli pronti: ripulisce da SCAVI_STRADE e
            # POZZETTI_STRADE le eventuali righe doppie prodotte da un pareggio
            # di distanza nel join (campo 'n' diverso da 1)
            self.log_c.setPlainText("Controllo campo 'n' su SCAVI_STRADE e POZZETTI_STRADE…"); self.repaint()
            n_rim_2 = self._pulisci_campo_n(p2, "SCAVI_STRADE")
            n_rim_3 = self._pulisci_campo_n(p3, "POZZETTI_STRADE")
        except Exception as e:
            QMessageBox.critical(self, "Errore", str(e)); return
        righe = [f"Generati:\n- {p1}\n- {p2}\n- {p3}"]
        if armadio:
            n_dopo = self._conta_feature(p1)
            righe.append(
                f"ARMADI_FOTO: {n_dopo if n_dopo is not None else n_armadi} elementi — uno per ogni Armadio Ottico "
                f"({n_armadi} nel layer), ciascuno con gli attributi del Punto di Ripresa più vicino entro la Distanza max join."
            )
        else:
            righe.append("ARMADI_FOTO: nessun layer Armadio Ottico impostato, contiene tutti i punti di ripresa senza filtro.")
        if n_civico: righe.append(f"ARMADI_FOTO: {n_civico} valori '{VAL_CIVICO_999}' del campo '{CAMPO_CIVICO}' sostituiti con '{VAL_CIVICO_SNC}'.")
        if n_rim_2: righe.append(f"SCAVI_STRADE: {n_rim_2} righe con 'n' diverso da 1 rimosse.")
        if n_rim_3: righe.append(f"POZZETTI_STRADE: {n_rim_3} righe con 'n' diverso da 1 rimosse.")
        self.log_c.setPlainText("\n".join(righe))
        if self.chk_c_carica.isChecked():
            for nome, path in (("ARMADI_FOTO",p1),("SCAVI_STRADE",p2),("POZZETTI_STRADE",p3)):
                l = QgsVectorLayer(path, nome, "ogr")
                if l.isValid(): self.project.addMapLayer(l)
        QMessageBox.information(self, "OK", "\n".join(righe))

    # ═══════════════════════════════════════════════ ATLANTE – LOGICA
    def _popola_elenco_layout(self):
        self.lst_atlante.clear()
        for layout in self.project.layoutManager().printLayouts():
            self.lst_atlante.addItem(layout.name())

    def _aggiorna_elenco_layout(self):
        self._popola_elenco_layout()

    def _esporta_atlante(self):
        items = self.lst_atlante.selectedItems()
        if not items:
            QMessageBox.warning(self, "Nessun layout selezionato", "Seleziona almeno un layout dall'elenco (Ctrl/Maiusc per più di uno)."); return
        cartella = QFileDialog.getExistingDirectory(self, "Cartella di destinazione PDF")
        if not cartella: return

        vettoriale = self.chk_atlante_vettoriale.isChecked()
        semplifica = self.chk_atlante_semplifica.isChecked()
        jpeg_lossy = self.chk_atlante_jpeg_lossy.isChecked()

        self.log_atlante.clear()
        risultati = []
        pdf_esportati = []
        gestore = self.project.layoutManager()
        for item in items:
            nome = item.text()
            # Log incrementale + processEvents PRIMA di ogni passo lento:
            # se l'esportazione si blocca davvero (non solo "lenta"), qui
            # si vede subito su quale layout e a quale fase (attivazione
            # Atlante / aggiornamento feature / rendering PDF), invece di
            # avere solo il cursore di attesa fermo senza indicazioni.
            self.log_atlante.appendPlainText(f"{nome}: avvio…")
            QApplication.processEvents()
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                layout = gestore.layoutByName(nome)
                if layout is None:
                    risultati.append(f"{nome}: layout non trovato (elenco non aggiornato?)."); continue
                atlas = layout.atlas()
                if atlas is None or atlas.coverageLayer() is None:
                    risultati.append(f"{nome}: nessun layer di copertura Atlante configurato in questo layout — configuralo nel Compositore (scheda Atlante) prima di usare questa funzione."); continue

                era_abilitato = atlas.enabled()
                if not era_abilitato:
                    atlas.setEnabled(True)
                try:
                    # setEnabled(True) non garantisce da solo che l'elenco
                    # feature dell'Atlante sia aggiornato (es. layer di
                    # copertura filtrato/modificato dopo l'ultima apertura
                    # del layout): updateFeatures() forza il refresh, così
                    # verifichiamo per davvero che l'Atlante sia attivo E
                    # popolato PRIMA di esportare, invece di scoprirlo solo
                    # dal risultato dell'export.
                    self.log_atlante.appendPlainText(f"{nome}: aggiornamento elenco elementi Atlante…")
                    QApplication.processEvents()
                    atlas.updateFeatures()
                    if atlas.count() == 0:
                        risultati.append(f"{nome}: Atlante attivato ma 0 elementi da coprire — controlla il layer/filtro di copertura nel Compositore (scheda Atlante).")
                        continue

                    percorso = os.path.join(cartella, f"{nome}.pdf")
                    settings = QgsLayoutExporter.PdfExportSettings()
                    # Vettoriale invece di rasterizzare ogni pagina: molto
                    # più veloce e file più leggeri, salvo layout con
                    # modalità di fusione/trasparenza che impongono comunque
                    # il rendering raster internamente.
                    settings.forceVectorOutput = vettoriale
                    # Semplifica le geometrie in base alla scala di stampa:
                    # riduce il lavoro di rendering su layer con geometrie
                    # complesse (es. infrastrutture molto dettagliate).
                    settings.simplifyGeometries = semplifica
                    # Stessa opzione della finestra "Esporta come PDF" di
                    # QGIS ("Compressione immagini senza perdita"): qui di
                    # default la lasciamo DISATTIVATA (quindi JPEG con
                    # perdita) per immagini raster incorporate più leggere
                    # e rendering più rapido. I due flag di base replicano
                    # i default del costruttore di PdfExportSettings.
                    flag = QgsLayoutRenderContext.FlagAntialiasing | QgsLayoutRenderContext.FlagUseAdvancedEffects
                    if not jpeg_lossy:
                        flag |= QgsLayoutRenderContext.FlagLosslessImageRendering
                    settings.flags = flag

                    self.log_atlante.appendPlainText(f"{nome}: rendering ed esportazione di {atlas.count()} pagine…")
                    QApplication.processEvents()
                    # Questo overload statico (con un Atlante, non un
                    # semplice layout) ritorna una TUPLA (risultato,
                    # messaggio d'errore), non il solo codice come le
                    # esportazioni non-Atlante: confrontare la tupla
                    # intera con Success falliva sempre, segnalando un
                    # errore anche quando il PDF veniva scritto bene.
                    esito, errore_msg = QgsLayoutExporter.exportToPdf(atlas, percorso, settings)
                finally:
                    if not era_abilitato:
                        atlas.setEnabled(False)  # ripristina lo stato originale del layout

                if esito == QgsLayoutExporter.Success:
                    risultati.append(f"{nome}: esportato in '{percorso}' ({atlas.count()} pagine/elementi).")
                    pdf_esportati.append(percorso)
                else:
                    risultati.append(f"{nome}: errore nell'esportazione (codice {esito}{': '+errore_msg if errore_msg else ''}) — verifica che l'Atlante abbia elementi da coprire.")
            except Exception as e:
                # Prima un'eccezione qui risaliva silenziosamente fino allo
                # slot Qt: il cursore di attesa restava impostato e non
                # comparivano né il PDF né alcun messaggio d'errore visibile
                # ("resta in caricamento"). Ora l'errore reale viene
                # mostrato nel log invece di sparire.
                risultati.append(f"{nome}: ERRORE IMPREVISTO — {type(e).__name__}: {e}")
            finally:
                QApplication.restoreOverrideCursor()
            self.log_atlante.appendPlainText(risultati[-1] if risultati else f"{nome}: nessun risultato registrato.")
            QApplication.processEvents()

        testo = "\n".join(risultati)
        self.log_atlante.setPlainText(testo)
        QMessageBox.information(self, "Esportazione completata", testo)

        # I PDF appena esportati con successo popolano subito l'elenco
        # da unire qui sotto, nello stesso ordine di esportazione —
        # l'utente può comunque aggiungerne altri o riordinare a mano.
        if pdf_esportati:
            self.lst_merge_pdf.clear()
            for p in pdf_esportati:
                self.lst_merge_pdf.addItem(p)

    def _merge_pdf_aggiungi(self):
        percorsi, _ = QFileDialog.getOpenFileNames(self, "Aggiungi PDF", "", "PDF (*.pdf)")
        for p in percorsi:
            self.lst_merge_pdf.addItem(p)

    def _merge_pdf_sposta(self, delta):
        riga = self.lst_merge_pdf.currentRow()
        if riga < 0: return
        nuova = riga + delta
        if nuova < 0 or nuova >= self.lst_merge_pdf.count(): return
        item = self.lst_merge_pdf.takeItem(riga)
        self.lst_merge_pdf.insertItem(nuova, item)
        self.lst_merge_pdf.setCurrentRow(nuova)

    def _merge_pdf_rimuovi(self):
        for item in self.lst_merge_pdf.selectedItems():
            self.lst_merge_pdf.takeItem(self.lst_merge_pdf.row(item))

    def _merge_pdf_unisci(self):
        n = self.lst_merge_pdf.count()
        if n < 2:
            QMessageBox.warning(self, "Elenco insufficiente", "Aggiungi almeno due PDF da unire, nell'ordine desiderato (usa ↑/↓ per riordinare)."); return
        try:
            from pypdf import PdfWriter
        except ImportError:
            try:
                from PyPDF2 import PdfWriter
            except ImportError:
                QMessageBox.critical(self, "Libreria mancante",
                    "Serve il pacchetto Python 'pypdf' (o 'PyPDF2') nell'ambiente "
                    "Python di QGIS. Installalo ad es. dalla OSGeo4W Shell con "
                    "'pip install pypdf' e riprova."); return

        percorso_out, _ = QFileDialog.getSaveFileName(self, "Salva PDF unito", "unito.pdf", "PDF (*.pdf)")
        if not percorso_out: return
        if not percorso_out.lower().endswith(".pdf"):
            percorso_out += ".pdf"

        percorsi = [self.lst_merge_pdf.item(i).text() for i in range(n)]
        writer = PdfWriter()
        saltati = []
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            for p in percorsi:
                if not os.path.isfile(p):
                    saltati.append(p); continue
                writer.append(p)
            with open(percorso_out, "wb") as fh:
                writer.write(fh)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Errore unione", f"Errore durante l'unione dei PDF: {e}"); return
        finally:
            QApplication.restoreOverrideCursor()

        msg = f"PDF unito creato: '{percorso_out}' ({n - len(saltati)} di {n} file, nell'ordine mostrato)."
        if saltati:
            msg += "\nSaltati (file non trovato): " + "; ".join(saltati)
        self.log_merge.setPlainText(msg)
        QMessageBox.information(self, "Unione completata", msg)

    # ═══════════════════════════════════════════════ CONI – LOGICA
    def _aggiungi_cono(self, foto_lyr, pt_ripresa, pt_verso, extra=None, rot_forzata=None):
        if rot_forzata is not None:
            rot = rot_forzata % 360
        else:
            dx = pt_verso.x()-pt_ripresa.x(); dy = pt_verso.y()-pt_ripresa.y()
            rot = math.degrees(math.atan2(dx, dy)) % 360
        g_out = QgsGeometry.fromPointXY(pt_ripresa)
        if foto_lyr.crs() != self.project.crs():
            g_out.transform(QgsCoordinateTransform(self.project.crs(), foto_lyr.crs(), self.project))
        nf = QgsFeature(foto_lyr.fields()); nf.setGeometry(g_out)
        nf[CAMPO_ROT] = round(rot, 1)
        if extra:
            for campo, valore in extra.items():
                idx = foto_lyr.fields().indexOf(campo)
                if idx >= 0: nf.setAttribute(idx, valore)
        foto_lyr.addFeature(nf)

    @staticmethod
    def _piede_perpendicolare_segmento(pt, p1, p2):
        """Scompone pt rispetto al segmento p1->p2 nella componente
        PARALLELA (t: posizione lungo il segmento, 0=p1, 1=p2 — la
        direzione della strada) e PERPENDICOLARE (lo scarto laterale) —
        coerente col fatto che lo Stradario è uno shape lineare. Ritorna
        (piede, distanza_quadra, t_non_clampato): t fuori da [0,1] segnala
        che pt non ha un vero piede perpendicolare dentro QUESTO segmento
        (cade oltre uno dei due estremi) — il chiamante preferisce un
        segmento con un vero piede perpendicolare (anche se un filo più
        lontano) a un punto d'estremo clampato, che non sarebbe una vera
        perpendicolare alla strada ma solo il punto più vicino in senso
        stretto."""
        dx = p2.x()-p1.x(); dy = p2.y()-p1.y()
        L2 = dx*dx + dy*dy
        if L2 == 0:
            piede = QgsPointXY(p1.x(), p1.y())
            return piede, (pt.x()-p1.x())**2+(pt.y()-p1.y())**2, 0.0
        t = ((pt.x()-p1.x())*dx + (pt.y()-p1.y())*dy) / L2
        t_clamp = max(0.0, min(1.0, t))
        piede = QgsPointXY(p1.x()+t_clamp*dx, p1.y()+t_clamp*dy)
        d2 = (pt.x()-piede.x())**2 + (pt.y()-piede.y())**2
        return piede, d2, t

    def _cerca_piede_stradario(self, pt_target, strad_idx, strad_geoms, raggio, g_tile=None, n_vicini=20):
        """Cerca il piede perpendicolare più vicino a pt_target usando un
        indice spaziale già costruito su Stradario (strad_idx/strad_geoms,
        vedi `_coni_tavole`) invece di re-interrogare il layer con un
        raggio che raddoppia ogni volta: con un indice in memoria basta
        chiedere le `n_vicini` feature più vicine, molto più veloce su
        Stradario grandi (es. uno Stradario Italia). Se `g_tile` è
        passato, un segmento che intersaca la tavola ha SEMPRE priorità
        su uno che non la intersaca, anche se quest'ultimo è più vicino:
        senza questa priorità il piede più vicino in assoluto poteva
        stare su una strada fuori tavola, e il punto — poi riportato
        dentro il perimetro per non uscirne — finiva agganciato a un
        lato qualunque del bordo, senza nessun legame con una strada
        reale di quella tavola. Ritorna (piede, tangente_unitaria) del
        segmento scelto, o (None, None) se nulla è entro il raggio: la
        tangente (versore lungo la strada in quel punto) serve al
        chiamante per tenere la camera sulla stessa linea della strada
        quando il soggetto vi giace già sopra (attraversamenti)."""
        pulito_in = None; pulito_in_d2 = None; pulito_in_tg = None
        pulito_out = None; pulito_out_d2 = None; pulito_out_tg = None
        scorta_in = None; scorta_in_d2 = None; scorta_in_tg = None
        scorta_out = None; scorta_out_d2 = None; scorta_out_tg = None
        for cid in strad_idx.nearestNeighbor(pt_target, n_vicini):
            g = strad_geoms.get(cid)
            if not g: continue
            in_tavola = bool(g_tile) and g.intersects(g_tile)
            linee = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for linea in linee:
                for i in range(len(linea) - 1):
                    p1 = QgsPointXY(linea[i]); p2 = QgsPointXY(linea[i + 1])
                    piede, d2, t = self._piede_perpendicolare_segmento(pt_target, p1, p2)
                    dx = p2.x() - p1.x(); dy = p2.y() - p1.y()
                    L = math.hypot(dx, dy)
                    tg = (dx / L, dy / L) if L > 0 else (1.0, 0.0)
                    if 0.0 <= t <= 1.0:
                        if in_tavola:
                            if pulito_in_d2 is None or d2 < pulito_in_d2:
                                pulito_in_d2 = d2; pulito_in = piede; pulito_in_tg = tg
                        else:
                            if pulito_out_d2 is None or d2 < pulito_out_d2:
                                pulito_out_d2 = d2; pulito_out = piede; pulito_out_tg = tg
                    else:
                        if in_tavola:
                            if scorta_in_d2 is None or d2 < scorta_in_d2:
                                scorta_in_d2 = d2; scorta_in = piede; scorta_in_tg = tg
                        else:
                            if scorta_out_d2 is None or d2 < scorta_out_d2:
                                scorta_out_d2 = d2; scorta_out = piede; scorta_out_tg = tg
        # Priorità: vero piede in tavola > vero piede fuori tavola >
        # punto d'estremo in tavola > punto d'estremo fuori tavola.
        for scelto, scelto_d2, scelto_tg in (
            (pulito_in, pulito_in_d2, pulito_in_tg), (pulito_out, pulito_out_d2, pulito_out_tg),
            (scorta_in, scorta_in_d2, scorta_in_tg), (scorta_out, scorta_out_d2, scorta_out_tg),
        ):
            if scelto is not None and scelto_d2 <= raggio * raggio:
                return scelto, scelto_tg
        return None, None

    def _pt_cono_stradario(self, pt_target, strad_idx, strad_geoms, raggio, dist_riserva, sedime_lyr=None, g_tile=None):
        """Punto di ripresa per un soggetto, proiettato perpendicolarmente
        sul segmento Stradario più vicino tramite l'indice spaziale già
        costruito (strad_idx/strad_geoms), preferendo un segmento
        realmente dentro la tavola (vedi `_cerca_piede_stradario`). La
        ricerca allarga sia il raggio sia il numero di vicini interrogati
        se non trova nulla, fino a un tetto, per non ricadere troppo
        spesso sul ripiego 'a Nord'.
        Se il soggetto giace già (quasi) sulla strada stessa — il caso
        degli attraversamenti, che per costruzione sono intersezioni
        Infrastruttura×Strada — la proiezione perpendicolare ricadrebbe
        sul soggetto stesso: distanza zero, camera 'sopra' l'oggetto,
        rotazione indefinita. In quel caso la camera viene invece
        spostata di `dist_riserva` LUNGO la strada (resta sulla sua
        stessa linea, non se ne allontana) e la ripresa è forzata
        PERPENDICOLARE alla strada (verso il lato che guarda più al
        centro della tavola) — una vera foto di attraversamento, non un
        cono piazzato sul soggetto.
        Se lo Stradario non trova nulla e `sedime_lyr` è impostato, il
        ripiego 'a Nord' viene spostato al punto più vicino dentro il
        Sedime Pubblico. Ritorna (pt_ripresa, senza_strada: bool,
        rotazione_forzata: gradi o None — se None il chiamante calcola
        la rotazione normalmente, guardando verso il soggetto)."""
        scelto = None; tangente = None
        if strad_idx is not None:
            r = raggio; n_vic = 20
            for _tentativo in range(7):
                scelto, tangente = self._cerca_piede_stradario(pt_target, strad_idx, strad_geoms, r, g_tile=g_tile, n_vicini=n_vic)
                if scelto is not None: break
                r *= 2; n_vic = min(n_vic * 3, 800)

        if scelto is not None:
            distanza_min = max(1.5, dist_riserva * 0.5)
            if scelto.distance(pt_target) < distanza_min:
                dx, dy = tangente
                spostato = QgsPointXY(scelto.x() + dx * dist_riserva, scelto.y() + dy * dist_riserva)
                perp1 = (-dy, dx); perp2 = (dy, -dx)
                if g_tile:
                    centro = g_tile.centroid().asPoint()
                    v = (centro.x() - spostato.x(), centro.y() - spostato.y())
                    perp = perp1 if (perp1[0]*v[0] + perp1[1]*v[1]) >= (perp2[0]*v[0] + perp2[1]*v[1]) else perp2
                else:
                    perp = perp1
                rot = math.degrees(math.atan2(perp[0], perp[1])) % 360
                return spostato, False, rot
            return scelto, False, None

        scelto = QgsPointXY(pt_target.x(), pt_target.y()+dist_riserva)
        if sedime_lyr:
            g_pt = QgsGeometry.fromPointXY(scelto)
            dentro = False
            bb = QgsRectangle(scelto.x()-0.01, scelto.y()-0.01, scelto.x()+0.01, scelto.y()+0.01)
            for f in sedime_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb)):
                g_s = self._to_proj(f.geometry(), sedime_lyr)
                if g_s and g_s.intersects(g_pt):
                    dentro = True; break
            if not dentro:
                migliore = None; migliore_d = None
                bb_ampio = QgsRectangle(scelto.x()-raggio, scelto.y()-raggio, scelto.x()+raggio, scelto.y()+raggio)
                for f in sedime_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb_ampio)):
                    g_s = self._to_proj(f.geometry(), sedime_lyr)
                    if not g_s or g_s.isEmpty(): continue
                    d = g_s.distance(g_pt)
                    if migliore_d is None or d < migliore_d:
                        migliore_d = d; migliore = g_s.nearestPoint(g_pt)
                if migliore is not None and not migliore.isEmpty():
                    scelto = QgsPointXY(migliore.asPoint())
        return scelto, True, None

    # m: sotto questa distanza due posizioni-camera sono considerate lo
    # stesso punto. Era 0.10 (praticamente solo coincidenze esatte):
    # troppo stretto per accorgersi di coni ravvicinati ma non identici
    # (es. due proiezioni sullo stesso tratto di strada a 30-40 cm
    # l'una dall'altra) — alzata a 1.0 m, un valore inferiore alla
    # spaziatura minima ragionevole tra due riprese diverse.
    _SOGLIA_DUPLICATO = 1.0

    def _indice_punti_foto(self, foto_lyr):
        """Indice spaziale sui Punti di Ripresa già presenti nel layer,
        usato per evitare di piazzare più coni esattamente sullo stesso
        punto — capita eseguendo sia 'Coni Armadi' sia 'Coni per Tavola di
        Inquadramento' sullo stesso Armadio (o rieseguendo la stessa
        funzione due volte): entrambe calcolano la STESSA posizione dalla
        STESSA proiezione sullo Stradario, quindi senza questo controllo
        risultano due Foto diverse impilate sul punto identico. Ritorna
        (idx, prossimo_id): prossimo_id è il primo id libero per
        registrare via via, con `_registra_punto_foto`, i nuovi punti
        aggiunti in questa esecuzione (l'indice non si aggiorna da solo)."""
        idx = QgsSpatialIndex(); n = 0
        for f in foto_lyr.getFeatures():
            g = self._to_proj(f.geometry(), foto_lyr)
            if not g or g.isEmpty(): continue
            nf = QgsFeature(); nf.setId(n); nf.setGeometry(g)
            idx.addFeature(nf); n += 1
        return idx, n

    @classmethod
    def _punto_occupato(cls, pt, idx):
        s = cls._SOGLIA_DUPLICATO
        bb = QgsRectangle(pt.x()-s, pt.y()-s, pt.x()+s, pt.y()+s)
        return len(idx.intersects(bb)) > 0

    @staticmethod
    def _registra_punto_foto(pt, idx, prossimo_id):
        nf = QgsFeature(); nf.setId(prossimo_id); nf.setGeometry(QgsGeometry.fromPointXY(pt))
        idx.addFeature(nf)
        return prossimo_id + 1

    @staticmethod
    def _clip_in_poligono(pt, g_poly):
        """Se pt è già dentro g_poly lo ritorna invariato; altrimenti lo
        sposta al punto più vicino sul perimetro di g_poly — così un
        punto di ripresa calcolato sullo Stradario (che può cadere oltre
        il bordo di una tavola stretta) resta sempre dentro la tavola,
        invece di finire fuori dal suo perimetro. Non usa
        QgsGeometry.boundary() (non disponibile in tutte le versioni di
        QGIS/PyQGIS): il punto più vicino di un poligono a un punto
        esterno cade comunque sul suo bordo."""
        g_pt = QgsGeometry.fromPointXY(pt)
        if g_poly.contains(g_pt):
            return pt
        vicino = g_poly.nearestPoint(g_pt)
        if vicino and not vicino.isEmpty():
            return QgsPointXY(vicino.asPoint())
        return pt

    def _coni_tavole(self):
        """Genera fino a 3 coni per ogni Tavola di Inquadramento (di più se
        servono per gli Armadi, vedi sotto): un cono per OGNI Armadio
        Ottico che ricade nella tavola — priorità assoluta, mai saltato,
        anche se sono più di 3 nella stessa tavola — poi, con il budget
        rimasto fino a un totale di 3, agli attraversamenti
        Infrastrutture×Provinciale, Infrastrutture×ANAS,
        Infrastrutture×Stradario (attraversamenti generici, non solo
        Provinciale/ANAS: coprono la maggioranza dei casi reali) e, in
        mancanza, ai Pozzetti Nuovi che toccano un'Infrastruttura Nuova e
        infine, in ultima istanza, un punto lungo le tratte Infrastrutture
        Nuove stesse (un attraversamento da un Pozzetto a un ROE PTE, o
        tra due Pozzetti) che ricadono nella tavola, in quest'ordine di
        priorità; a parità di tipo vince il candidato più vicino al centro
        della tavola. Non punta più al PTE dentro un Pozzetto come
        ripiego. TUTTI i coni (Armadio compreso) sono ancorati allo stesso
        modo: la proiezione perpendicolare del soggetto sulla tratta di
        Stradario (o altro shape lineare a scelta) più vicina, RIPORTATA
        dentro il perimetro della tavola se cadesse fuori (proiezione sul
        bordo più vicino) — così ogni cono resta sempre dentro la tavola
        che deve documentare. Ogni cono creato viene inoltre collegato
        alla sua tavola tramite il campo interno 'ID_Tavola' (creato se
        manca): un aggancio esplicito, non geometrico, così la
        numerazione automatica (pulsante più sotto) trova sempre il cono.
        Due controlli anti-duplicato indipendenti: un candidato il cui
        SOGGETTO (non solo la posizione della camera) coincide con uno già
        inquadrato in questa esecuzione viene scartato prima ancora di
        calcolarne la posizione; una posizione-camera calcolata che
        coincide (entro pochi cm) con un cono già esistente non viene
        comunque duplicata — per un Armadio conta come 'coperto', per gli
        altri tipi si scarta e si prova il candidato successivo senza
        consumare budget."""
        tavole = self.cb_kf_tavole.currentLayer()
        infra  = self.cb_kf_infra.currentLayer()
        poz    = self.cb_kf_pozzetto.currentLayer()
        arm_lyr  = self.cb_k_armadio.currentLayer()
        foto_lyr = self.cb_k_foto.currentLayer()
        strad_lyr = self.cb_k_stradario.currentLayer()
        sedime_lyr = self.cb_k_sedime.currentLayer()
        prov   = self.cb_kf_prov.currentLayer()
        anas   = self.cb_kf_anas.currentLayer()
        if not tavole or not infra or not arm_lyr or not foto_lyr:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Tavole di Inquadramento, Infrastrutture, Armadio Ottico e Punto di Ripresa."); return
        if foto_lyr.fields().indexOf(CAMPO_ROT) < 0:
            QMessageBox.critical(self, "Campo mancante", f"Punto di Ripresa non ha '{CAMPO_ROT}'."); return

        dist_riserva = self.spin_k_dist.value(); rag = self.spin_k_rag.value()
        dist_kf = self.spin_kf_dist.value()

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            idx_arm, arm_by = self._build_idx(arm_lyr)

            # Ritaglio su ARLO AREA (+ margine): Stradario, Provinciali e
            # ANAS sono spesso shape a scala nazionale (es. Stradario
            # Italia) letti per intero anche se il permesso copre
            # un'area minuscola — qui li limitiamo, con un semplice
            # filtro bbox lato provider, all'intorno di ARLO AREA.
            area_arlo = self._dissolvi_arlo()
            margine_arlo = self.spin_kf_margine_arlo.value()
            area_filtro = area_arlo.buffer(margine_arlo, 8) if area_arlo else None

            # Indice spaziale su Stradario costruito UNA volta sola,
            # prima del ciclo sulle tavole: prima veniva re-interrogato
            # il layer via bbox con raggio raddoppiato fino a 9 volte
            # PER OGNI candidato di OGNI tavola, il vero collo di
            # bottiglia su uno Stradario grande. Con l'indice in RAM
            # (già ritagliato ad ARLO AREA sopra) ogni ricerca costa una
            # nearestNeighbor(), non una nuova scansione del layer.
            strad_idx = None; strad_geoms = {}
            if strad_lyr:
                strad_idx = QgsSpatialIndex()
                req_strad = self._req_area(strad_lyr, area_filtro)
                it_strad = strad_lyr.getFeatures(req_strad) if req_strad is not None else strad_lyr.getFeatures()
                for i, f in enumerate(it_strad):
                    g = self._to_proj(f.geometry(), strad_lyr)
                    if not g or g.isEmpty(): continue
                    nf_idx = QgsFeature(); nf_idx.setId(i); nf_idx.setGeometry(g)
                    strad_idx.addFeature(nf_idx); strad_geoms[i] = g

            # Infrastrutture di interesse per i punti di ripresa: sempre
            # solo STATO='Nuovo', escluse TIPOLOGIA='Aerea' e TIPOLOGIA
            # vuota/NULL (non più un filtro opzionale). Confronto tollerante
            # a maiuscole/minuscole e spazi (' Aerea ', 'AEREA', 'nuovo'...):
            # un confronto esatto lasciava passare l'infrastruttura aerea
            # ogni volta che il dato non era scritto esattamente 'Aerea'.
            campo_stato_ok = infra.fields().indexOf(CAMPO_STATO) >= 0
            campo_tip_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0
            val_nuovo_norm = VAL_NUOVO.strip().lower()
            val_aerea_norm = VAL_AEREA.strip().lower()
            feat_infra = []
            for f in infra.getFeatures():
                if campo_stato_ok:
                    st = f[CAMPO_STATO]
                    if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                        continue
                if campo_tip_ok:
                    tip = f[CAMPO_TIP_INFRA]
                    if tip is None or not isinstance(tip, str) or not tip.strip() or tip.strip().lower() == val_aerea_norm:
                        continue
                feat_infra.append(f)

            def punti_attraversamento(lyr_strada):
                """Punti di intersezione (proiettati) fra Infrastrutture e
                lyr_strada, con indice spaziale su lyr_strada (letto solo
                entro ARLO AREA + margine, vedi sopra) per non fare un
                confronto O(n×m) su layer grandi."""
                pts = []
                if not lyr_strada: return pts
                req_s = self._req_area(lyr_strada, area_filtro)
                idx_s, s_by = self._build_idx(lyr_strada, req=req_s)
                for f in feat_infra:
                    g = self._to_proj(f.geometry(), infra)
                    if not g or g.isEmpty(): continue
                    for cid in idx_s.intersects(g.boundingBox()):
                        g2, _f2 = s_by[cid]
                        try:
                            inter = self._valida(g).intersection(self._valida(g2))
                        except Exception:
                            continue
                        if not inter or inter.isEmpty(): continue
                        if inter.type() == QgsWkbTypes.PointGeometry:
                            if inter.isMultipart():
                                pts.extend(QgsPointXY(p) for p in inter.asMultiPoint())
                            else:
                                pts.append(QgsPointXY(inter.asPoint()))
                return pts

            pool_prov = punti_attraversamento(prov)
            pool_anas = punti_attraversamento(anas)
            # Attraversamenti perpendicolari allo Stradario stesso (non
            # solo Provinciale/ANAS): la maggior parte delle tratte nuove
            # attraversa strade comunali "generiche", mai classificate
            # come Provinciale/ANAS — senza questo tier quegli
            # attraversamenti (probabilmente i più numerosi) non
            # venivano mai individuati.
            pool_stradario = punti_attraversamento(strad_lyr) if strad_lyr else []

            # Ripiego intermedio: Pozzetti Nuovi che toccano un'Infrastruttura
            # Nuova (priorità più bassa degli attraversamenti Provinciale/
            # ANAS, ma più alta della tratta generica sotto — un pozzetto è
            # un punto fisico riconoscibile, più utile da fotografare di un
            # punto arbitrario a metà di una tratta).
            pool_pozzetti_nuovi = []
            if poz:
                idx_fi = QgsSpatialIndex(); fi_geoms = {}
                for i, f in enumerate(feat_infra):
                    g = self._to_proj(f.geometry(), infra)
                    if not g or g.isEmpty(): continue
                    nf_idx = QgsFeature(); nf_idx.setId(i); nf_idx.setGeometry(g)
                    idx_fi.addFeature(nf_idx); fi_geoms[i] = g
                campo_stato_poz_ok = poz.fields().indexOf(CAMPO_STATO) >= 0
                for f in poz.getFeatures():
                    if campo_stato_poz_ok:
                        st = f[CAMPO_STATO]
                        if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                            continue
                    g = self._to_proj(f.geometry(), poz)
                    if not g or g.isEmpty(): continue
                    p = QgsPointXY(g.asPoint())
                    bb = QgsRectangle(p.x()-0.5, p.y()-0.5, p.x()+0.5, p.y()+0.5)
                    tocca = any(fi_geoms[cid].distance(g) <= 0.5 for cid in idx_fi.intersects(bb))
                    if tocca:
                        pool_pozzetti_nuovi.append(p)

            # Ripiego finale: un punto a metà lunghezza di ciascuna tratta
            # Infrastruttura Nuova (l'attraversamento realizzato dalla
            # tratta stessa, da un Pozzetto a un ROE PTE o tra due
            # Pozzetti), non più il PTE dentro un Pozzetto.
            pool_tratte = []
            for f in feat_infra:
                g = self._to_proj(f.geometry(), infra)
                if not g or g.isEmpty(): continue
                lung = g.length()
                if lung <= 0: continue
                pm = g.interpolate(lung / 2.0)
                if pm and not pm.isEmpty():
                    pool_tratte.append(QgsPointXY(pm.asPoint()))

            era = foto_lyr.isEditable()
            if not self._start_edit(foto_lyr):
                QMessageBox.critical(self, "Errore", "Impossibile avviare la modifica su Punto di Ripresa."); return
            if foto_lyr.fields().indexOf(CAMPO_ID_TAVOLA) < 0:
                foto_lyr.addAttribute(QgsField(CAMPO_ID_TAVOLA, QVariant.LongLong))
                foto_lyr.updateFields()
            idx_usati, prossimo_id = self._indice_punti_foto(foto_lyr)
            # Oggetti già inquadrati in questa esecuzione (non solo
            # posizioni-camera già occupate, ma i SOGGETTI stessi): un
            # incrocio Stradario molto vicino a un Pozzetto Nuovo, o due
            # tavole adiacenti che vedono lo stesso incrocio, potevano
            # produrre due coni diversi puntati allo stesso oggetto.
            bersagli_usati = []
            # Era 0.5 m: bastava che due incroci calcolati da pool diversi
            # (es. stesso incrocio fisico digitalizzato leggermente
            # diverso su Provinciale e su Stradario) fossero a 1-2 m
            # l'uno dall'altro per sfuggire al controllo e produrre due
            # coni puntati, di fatto, allo stesso oggetto. Alzata a 3 m
            # (poco meno della metà larghezza sedime stradale di default).
            SOGLIA_BERSAGLIO = 3.0

            def bersaglio_libero(pt):
                return not any(pt.distance(b) <= SOGLIA_BERSAGLIO for b in bersagli_usati)

            n_tavole = 0; n_arm = 0; n_prov = 0; n_anas = 0; n_strada = 0; n_poz = 0; n_tratta = 0
            n_incomplete = 0; n_vuote = 0; n_tavole_extra_armadi = 0; n_duplicati = 0
            for ft in tavole.getFeatures():
                g_tile = self._to_proj(ft.geometry(), tavole)
                if not g_tile or g_tile.isEmpty(): continue
                n_tavole += 1
                centro = g_tile.centroid().asPoint()
                extra = {CAMPO_ID_TAVOLA: ft.id()}

                def dentro(pt):
                    return g_tile.intersects(QgsGeometry.fromPointXY(pt))

                # 1) Armadio: un cono per OGNI Armadio nella tavola, sempre
                # — priorità assoluta, anche oltre il tetto di 3 se ce ne
                # sono di più. Se un cono esiste già esattamente sullo
                # stesso punto (es. da un'esecuzione precedente), l'Armadio
                # conta comunque come 'coperto' ma non si crea un duplicato.
                bb_tile = g_tile.boundingBox()
                armadi_in_tile = []
                for cid in idx_arm.intersects(bb_tile):
                    g_a, _fa = arm_by[cid]
                    pa = QgsPointXY(g_a.asPoint())
                    if dentro(pa):
                        armadi_in_tile.append(pa)
                coni_tile = 0
                for pa in armadi_in_tile:
                    pt_rip, _, rot_forzata = self._pt_cono_stradario(pa, strad_idx, strad_geoms, rag, dist_riserva, sedime_lyr=sedime_lyr, g_tile=g_tile)
                    pt_rip = self._clip_in_poligono(pt_rip, g_tile)
                    if self._punto_occupato(pt_rip, idx_usati):
                        n_duplicati += 1
                    else:
                        self._aggiungi_cono(foto_lyr, pt_rip, pa, extra=extra, rot_forzata=rot_forzata)
                        prossimo_id = self._registra_punto_foto(pt_rip, idx_usati, prossimo_id)
                        bersagli_usati.append(pa)
                        n_arm += 1
                    coni_tile += 1
                if len(armadi_in_tile) > 3: n_tavole_extra_armadi += 1
                budget = max(0, 3 - coni_tile)

                # 2) Pool attraversamenti/pozzetti/tratte nella tavola, in
                # ordine di priorità — stesso ancoraggio via Stradario
                # dell'Armadio, sempre tenuto DENTRO la tavola. Un
                # candidato che finirebbe duplicato (stessa posizione-
                # camera, o stesso oggetto già inquadrato) viene scartato
                # senza consumare budget: si passa al successivo.
                for pool, tag in ((pool_prov, 'prov'), (pool_anas, 'anas'), (pool_stradario, 'strada'), (pool_pozzetti_nuovi, 'poz'), (pool_tratte, 'tratta')):
                    if budget <= 0: break
                    candidati = sorted(
                        (p for p in pool if dentro(p) and bersaglio_libero(p)),
                        key=lambda p: p.distance(centro),
                    )
                    for p in candidati:
                        if budget <= 0: break
                        if not bersaglio_libero(p): continue  # potrebbe essere stato preso da un candidato precedente in questo stesso ciclo
                        pt_rip, _, rot_forzata = self._pt_cono_stradario(p, strad_idx, strad_geoms, rag, dist_kf, sedime_lyr=sedime_lyr, g_tile=g_tile)
                        pt_rip = self._clip_in_poligono(pt_rip, g_tile)
                        if self._punto_occupato(pt_rip, idx_usati):
                            n_duplicati += 1; continue
                        self._aggiungi_cono(foto_lyr, pt_rip, p, extra=extra, rot_forzata=rot_forzata)
                        prossimo_id = self._registra_punto_foto(pt_rip, idx_usati, prossimo_id)
                        bersagli_usati.append(p)
                        budget -= 1; coni_tile += 1
                        if tag == 'prov': n_prov += 1
                        elif tag == 'anas': n_anas += 1
                        elif tag == 'strada': n_strada += 1
                        elif tag == 'poz': n_poz += 1
                        else: n_tratta += 1

                if coni_tile == 0: n_vuote += 1
                elif coni_tile < 3: n_incomplete += 1

            if not era and not self._commit(foto_lyr, "Errore salvataggio Punti di Ripresa"):
                return
            foto_lyr.triggerRepaint()
        finally:
            QApplication.restoreOverrideCursor()

        tot = n_arm + n_prov + n_anas + n_strada + n_poz + n_tratta
        msg = [
            f"Tavole esaminate: {n_tavole}. Coni creati: {tot} "
            f"(Armadio: {n_arm}, Provinciale: {n_prov}, ANAS: {n_anas}, Stradario: {n_strada}, Pozzetto Nuovo: {n_poz}, Tratta Infrastruttura Nuova: {n_tratta}).",
        ]
        if n_duplicati: msg.append(f"{n_duplicati} coni scartati: punto già occupato da un cono esistente.")
        if n_tavole_extra_armadi: msg.append(f"{n_tavole_extra_armadi} tavole con più di 3 Armadi: tutti fotografati, oltre il tetto di 3 coni.")
        if n_incomplete: msg.append(f"{n_incomplete} tavole con meno di 3 coni (candidati insufficienti).")
        if n_vuote: msg.append(f"{n_vuote} tavole senza nessun candidato.")
        if area_filtro is None:
            msg.append("ARLO AREA non impostata (scheda 'Keyplan e tavole'): Stradario/Provinciali/ANAS letti per intero, senza ritaglio — su shape nazionali può essere lento.")
        testo = "\n".join(msg)
        self.log_kf.setPlainText(testo)
        QMessageBox.information(self, "Coni Tavole generati", testo)

    def _numera_foto(self):
        """Numera le Foto da 1 a N a blocchi FISSI di 3 per Tavola di
        Inquadramento (base = (numero_tav-1)*3 + 1), nell'ordine del
        rispettivo numero tavola. Richiede che le Tavole di Inquadramento
        siano già numerate nel campo indicato (non generato da questo
        plugin, va numerato altrove, es. nel software di impaginazione):
        se il campo manca, o non è valorizzato ovunque, o contiene
        duplicati, non numera nulla e spiega il motivo. Se una tavola ha
        meno di 3 coni, il/i numero/i mancante/i del suo blocco vengono
        semplicemente saltati — non riassegnati né riutilizzati dalla
        tavola successiva, che parte comunque dal proprio blocco pieno.
        Le Foto generate da 'Coni per Tavola di Inquadramento' sono
        associate alla loro tavola tramite il campo 'ID_Tavola' (aggancio
        esplicito): serve perché il punto di ripresa può finire fuori dal
        perimetro della tavola una volta spostato sullo Stradario più
        vicino, e un semplice test geometrico "dentro la tavola" non le
        troverebbe più. Le Foto senza questo campo valorizzato (es. dal
        pulsante Coni Armadi, non legato a nessuna tavola) usano ancora
        il ripiego geometrico."""
        tavole = self.cb_kf_tavole.currentLayer()
        foto_lyr = self.cb_k_foto.currentLayer()
        if not tavole or not foto_lyr:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Tavole di Inquadramento e Punto di Ripresa."); return
        campo_tav = self.txt_num_tav.text().strip()
        campo_foto = self.txt_num_foto.text().strip()
        if not campo_tav or not campo_foto:
            QMessageBox.warning(self, "Campi mancanti", "Indica il nome dei due campi di numerazione."); return

        idx_campo_tav = tavole.fields().indexOf(campo_tav)
        if idx_campo_tav < 0:
            QMessageBox.warning(
                self, "Tavole non numerate",
                f"Le Tavole di Inquadramento non hanno il campo '{campo_tav}': numera "
                "prima le tavole (es. nel software di impaginazione), poi riprova."
            ); return

        tavole_num = []; mancanti = 0
        for f in tavole.getFeatures():
            v = f[campo_tav]
            if v is None or (isinstance(v, str) and not v.strip()):
                mancanti += 1; continue
            try:
                n = int(round(float(v)))
            except (TypeError, ValueError):
                mancanti += 1; continue
            tavole_num.append((n, f))
        if not tavole_num:
            QMessageBox.warning(self, "Tavole non numerate", f"Nessuna tavola ha un valore valido nel campo '{campo_tav}': numera prima le tavole, poi riprova."); return
        if mancanti:
            QMessageBox.warning(
                self, "Numerazione incompleta",
                f"{mancanti} tavole non hanno un valore valido nel campo '{campo_tav}'. "
                "Completa la numerazione di TUTTE le tavole prima di procedere."
            ); return
        numeri = [n for n, _ in tavole_num]
        if len(numeri) != len(set(numeri)):
            QMessageBox.warning(self, "Numeri duplicati", f"Il campo '{campo_tav}' contiene valori duplicati tra le tavole: correggi prima di procedere."); return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # Le Foto generate da "Coni per Tavola di Inquadramento" sono
            # collegate alla loro tavola tramite il campo 'ID_Tavola'
            # (aggancio esplicito, non geometrico): usarlo qui evita di
            # perdere i coni che lo spostamento verso lo Stradario ha
            # portato fuori dal perimetro della tavola (altrimenti un test
            # di contenimento geometrico non li troverebbe più). Le Foto
            # senza questo campo valorizzato (es. generate col vecchio
            # pulsante Coni Armadi, non legato a nessuna tavola) usano
            # ancora il ripiego geometrico.
            idx_campo_id_tav_foto = foto_lyr.fields().indexOf(CAMPO_ID_TAVOLA)
            per_tavola = {}
            foto_non_collegate = []
            for f in foto_lyr.getFeatures():
                v = f[CAMPO_ID_TAVOLA] if idx_campo_id_tav_foto >= 0 else None
                collegata = False
                if v is not None:
                    try:
                        if not (hasattr(v, "isNull") and v.isNull()):
                            per_tavola.setdefault(int(v), []).append(f)
                            collegata = True
                    except (TypeError, ValueError):
                        pass
                if not collegata:
                    foto_non_collegate.append(f)

            idx_foto_libere = QgsSpatialIndex(); foto_libere_by = {}
            for i, f in enumerate(foto_non_collegate):
                g = self._to_proj(f.geometry(), foto_lyr)
                if not g or g.isEmpty(): continue
                nf_idx = QgsFeature(); nf_idx.setId(i); nf_idx.setGeometry(g)
                idx_foto_libere.addFeature(nf_idx); foto_libere_by[i] = (g, f)

            era = foto_lyr.isEditable()
            if not self._start_edit(foto_lyr):
                QMessageBox.critical(self, "Errore", "Impossibile avviare la modifica su Punto di Ripresa."); return
            idx_campo_foto = foto_lyr.fields().indexOf(campo_foto)
            if idx_campo_foto < 0:
                foto_lyr.addAttribute(QgsField(campo_foto, QVariant.Int))
                foto_lyr.updateFields()
                idx_campo_foto = foto_lyr.fields().indexOf(campo_foto)

            assegnati = 0; tavole_incomplete = 0
            for n_tav, ft in sorted(tavole_num, key=lambda x: x[0]):
                candidati = list(per_tavola.get(ft.id(), []))
                if len(candidati) < 3:
                    g_tile = self._to_proj(ft.geometry(), tavole)
                    if g_tile and not g_tile.isEmpty():
                        bb = g_tile.boundingBox()
                        extra = []
                        for cid in idx_foto_libere.intersects(bb):
                            g_f, f_f = foto_libere_by[cid]
                            if g_tile.intersects(g_f):
                                extra.append(f_f)
                        candidati.extend(extra)
                candidati.sort(key=lambda f: f.id())
                candidati = candidati[:3]
                if len(candidati) < 3: tavole_incomplete += 1
                base = (n_tav - 1) * 3 + 1
                for i, f in enumerate(candidati):
                    foto_lyr.changeAttributeValue(f.id(), idx_campo_foto, base + i)
                    assegnati += 1

            if not era and not self._commit(foto_lyr, "Errore salvataggio numerazione Foto"):
                return
            foto_lyr.triggerRepaint()
        finally:
            QApplication.restoreOverrideCursor()

        msg = f"Numerate {assegnati} foto su {len(tavole_num)} tavole (campo '{campo_foto}')."
        if tavole_incomplete:
            msg += f"\n{tavole_incomplete} tavole con meno di 3 coni: i numeri mancanti del loro blocco sono stati saltati."
        self.log_n.setPlainText(msg)
        QMessageBox.information(self, "Numerazione completata", msg)

    # ═══════════════════════════════════════════════ CHILOMETRICHE – LOGICA
    # formati ammessi per il valore scritto sul cippo: chiave interna e
    # etichetta mostrata nel combo del punto 1
    _FORMATI_KM = (
        ("km_m",       "km+metri, es. 17+100 (standard)"),
        ("invertito",  "metri+km INVERTITO, es. 100+17 = km 17+100"),
        ("metri",      "solo metri, es. 17100"),
        ("km_dec",     "km decimali, es. 17,1"),
    )
    _PREFISSI_KM = r"^(k\.?m\.?t?|p\.?k\.?|progr(\.|essiva)?|cippo|prog)\s*[:=]?\s*"

    @staticmethod
    def _parse_chilometrica(testo, formato="km_m"):
        """Valore del cippo → metri. Ritorna None se il testo non è
        interpretabile.

        Tollera il prefisso descrittivo con cui i cippi vengono normalmente
        etichettati ('KM 17+100', 'PK 17+100', 'progr. 17+100'): senza questa
        pulizia 'KM 17+100' finiva in float('KM17') e il cippo veniva scartato
        in silenzio, quindi il calcolo non partiva affatto.

        `formato` sceglie come leggere le due parti attorno al '+': 'km_m' è lo
        standard (17+100 = km 17 e 100 m), 'invertito' serve quando il valore è
        stato digitato al rovescio (100+17 significa km 17+100), 'metri' e
        'km_dec' per i valori senza '+'."""
        if testo is None:
            return None
        t = str(testo).strip().lower().replace(" ", "")
        t = re.sub(FTTHPermessiDialog._PREFISSI_KM, "", t)
        t = t.lstrip("+:=.")
        if not t:
            return None

        if "+" in t:
            sinistra, destra = t.split("+", 1)
            try:
                a = float(sinistra.replace(",", "."))
                b = float(destra.replace(",", "."))
            except ValueError:
                return None
            if formato == "invertito":
                a, b = b, a
            return a * 1000 + b

        try:
            valore = float(t.replace(",", "."))
        except ValueError:
            return None
        if formato == "metri":
            return valore
        if formato == "km_dec":
            return valore * 1000
        # senza '+' e senza formato esplicito: valori piccoli sono km decimali
        # (es. "17,1"), non metri — un pozzetto non sta al metro 17 di una SP
        return valore * 1000 if valore < 1000 else valore

    @staticmethod
    def _format_chilometrica(metri):
        segno = "-" if metri < 0 else ""
        assoluto = abs(metri)
        km = int(assoluto // 1000)
        m = assoluto - km * 1000
        return f"{segno}{km}+{m:03.0f}"

    # ═════════════════════════════════════════ CHILOMETRICHE – LOGICA
    @staticmethod
    def _punto_riferimento(geom):
        """Punto rappresentativo con cui cercare il corridoio: il punto stesso
        se la geometria è puntuale, il punto medio misurato lungo la linea se
        è lineare (il centroide di una linea curva può cadere fuori dalla
        strada)."""
        if geom is None or geom.isEmpty():
            return None
        if geom.type() == QgsWkbTypes.PointGeometry:
            return geom.asPoint()
        lunghezza = geom.length()
        if lunghezza <= 0:
            centro = geom.centroid()
            return centro.asPoint() if centro and not centro.isEmpty() else None
        medio = geom.interpolate(lunghezza / 2.0)
        if medio is None or medio.isEmpty():
            centro = geom.centroid()
            return centro.asPoint() if centro and not centro.isEmpty() else None
        return medio.asPoint()

    def _costruisci_corridoi(self, rif_lyr, solo_selezionate, campo_gruppo,
                             area_interesse, cucitura=1.0):
        """Ricuce le tratte della linea di riferimento in 'corridoi' continui e
        ritorna [(etichetta, geometria_linea_continua), …].

        È il cuore della correzione: uno stradario (es. 'Stradario Provincia
        Italia') non è UNA linea ma centinaia di segmenti, uno per tronco o
        per civico. Sul singolo segmento lineLocatePoint() misura una
        progressiva relativa a quel pezzetto, e un cippo e un pozzetto distanti
        50 m ricadono quasi sempre su due segmenti DIVERSI: la vecchia versione
        pretendeva invece che ricadessero sulla stessa feature, quindi
        scartava praticamente tutto con 'nessuna ancora sulla stessa linea di
        riferimento'. Qui i segmenti che si toccano vengono fusi (mergeLines)
        in polilinee continue, così la progressiva è misurata lungo l'intera
        strada e cippi e target stanno sullo stesso sistema di riferimento.

        `solo_selezionate` limita alle tratte selezionate in mappa (consigliato
        con stradari estesi), `campo_gruppo` ricuce solo tratte che condividono
        lo stesso valore (es. codice o nome strada), `area_interesse` limita la
        lettura all'intorno di cippi e target per non caricare l'intera
        provincia."""
        if rif_lyr is None:
            return []
        if solo_selezionate:
            iteratore = rif_lyr.getSelectedFeatures()
        else:
            richiesta = self._req_area(rif_lyr, area_interesse)
            iteratore = rif_lyr.getFeatures(richiesta) if richiesta else rif_lyr.getFeatures()

        idx_gruppo = self._indice_campo(rif_lyr, campo_gruppo) if campo_gruppo else -1
        gruppi = {}
        for f in iteratore:
            g = self._to_proj(f.geometry(), rif_lyr)
            if not g or g.isEmpty():
                continue
            chiave = str(f[idx_gruppo]) if idx_gruppo >= 0 else "tutte le tratte"
            # molti stradari sono di tipo MultiLineString: le parti vanno
            # esplose prima di raccoglierle, altrimenti collectGeometry()
            # produce una geometria annidata su cui mergeLines() non ricuce
            for parte in (g.asGeometryCollection() if g.isMultipart() else [g]):
                if parte is not None and not parte.isEmpty():
                    gruppi.setdefault(chiave, []).append(parte)

        corridoi = []
        for chiave, geometrie in gruppi.items():
            unite = QgsGeometry.collectGeometry(geometrie)
            if unite is None or unite.isEmpty():
                continue
            try:
                # mergeLines() fonde le linee che condividono un estremo: da N
                # segmenti contigui ottiene una sola polilinea continua
                fuse = unite.mergeLines()
                if fuse is None or fuse.isEmpty():
                    fuse = unite
            except Exception:
                fuse = unite
            parti = fuse.asGeometryCollection() if fuse.isMultipart() else [fuse]
            parti = self._ricuci_con_tolleranza(parti, cucitura)
            multi = len(parti) > 1
            for n, parte in enumerate(parti, start=1):
                if parte is None or parte.isEmpty() or parte.length() <= 0:
                    continue
                etichetta = f"{chiave} – tronco {n}" if multi else str(chiave)
                corridoi.append((etichetta, parte))
        return corridoi

    def _ricuci_con_tolleranza(self, parti, tolleranza):
        """Concatena le polilinee i cui estremi distano meno di `tolleranza`,
        restituendo il minor numero possibile di tracciati continui.

        mergeLines() unisce solo le linee che condividono un vertice ESATTO,
        mentre negli stradari reali i tronchi si chiudono spesso a pochi
        centimetri l'uno dall'altro: il risultato è una strada spezzata in più
        corridoi. Ogni corridoio ha un proprio sistema di progressive e un
        proprio cippo di riferimento, quindi due elementi vicini ma su corridoi
        diversi ricevono chilometriche non confrontabili — è la seconda causa
        degli errori di conteggio. L'ordine di partenza è deterministico
        (coordinate del primo vertice) perché a parità di dati il risultato
        deve essere identico a ogni lancio."""
        linee = []
        for g in parti:
            try:
                punti = list(g.asPolyline())
            except Exception:
                punti = []
            if len(punti) >= 2:
                linee.append(punti)
        if tolleranza <= 0 or len(linee) < 2:
            return [QgsGeometry.fromPolylineXY(l) for l in linee]

        linee.sort(key=lambda l: (round(l[0].x(), 3), round(l[0].y(), 3)))
        usate = [False] * len(linee)
        risultato = []

        def direzione(a, b):
            return math.atan2(b.y() - a.y(), b.x() - a.x())

        def scarto_angolare(entrante, uscente):
            """Differenza fra due direzioni, riportata in 0..pi."""
            delta = abs(entrante - uscente) % (2 * math.pi)
            return min(delta, 2 * math.pi - delta)

        # oltre questo scarto la candidata non è la prosecuzione della strada ma
        # una laterale: agli incroci mergeLines() consegna tre tronconi che si
        # toccano nello stesso punto, e agganciare quello sbagliato produrrebbe
        # progressive che a un certo punto svoltano in un'altra via
        MAX_SCARTO = math.radians(75)

        for i in range(len(linee)):
            if usate[i]:
                continue
            catena = list(linee[i]); usate[i] = True
            while True:
                migliore = None  # (indice, rovesciata, in_coda, scarto, distanza)
                coda, testa = catena[-1], catena[0]
                dir_coda = direzione(catena[-2], catena[-1])
                dir_testa = direzione(catena[1], catena[0])
                for j, altra in enumerate(linee):
                    if usate[j]:
                        continue
                    for rovesciata in (False, True):
                        a = altra[::-1] if rovesciata else altra
                        d = math.hypot(coda.x() - a[0].x(), coda.y() - a[0].y())
                        if d <= tolleranza:
                            scarto = scarto_angolare(dir_coda, direzione(a[0], a[1]))
                            if scarto <= MAX_SCARTO and (migliore is None or
                                                         (scarto, d) < migliore[3:5]):
                                migliore = (j, rovesciata, True, scarto, d)
                        d = math.hypot(testa.x() - a[-1].x(), testa.y() - a[-1].y())
                        if d <= tolleranza:
                            scarto = scarto_angolare(dir_testa, direzione(a[-1], a[-2]))
                            if scarto <= MAX_SCARTO and (migliore is None or
                                                         (scarto, d) < migliore[3:5]):
                                migliore = (j, rovesciata, False, scarto, d)
                if migliore is None:
                    break
                j, rovesciata, in_coda, _, distanza = migliore
                a = linee[j][::-1] if rovesciata else list(linee[j])
                usate[j] = True
                coincidente = distanza <= 1e-6
                if in_coda:
                    catena.extend(a[1:] if coincidente else a)
                else:
                    catena = (a[:-1] if coincidente else a) + catena
            risultato.append(QgsGeometry.fromPolylineXY(catena))
        return risultato

    def _leggi_cippi(self, ancore_lyr, idx_campo_ancora, formato="km_m"):
        """[(geometria_punto, valore_metri, etichetta), …] per i cippi
        leggibili, più l'elenco dei motivi di scarto."""
        cippi = []; scartati = []
        for a in ancore_lyr.getFeatures():
            g = self._to_proj(a.geometry(), ancore_lyr)
            if not g or g.isEmpty():
                scartati.append(f"id {a.id()}: geometria mancante o non trasformabile.")
                continue
            grezzo = a[idx_campo_ancora]
            valore = self._parse_chilometrica(grezzo, formato)
            if valore is None:
                scartati.append(f"id {a.id()}: valore '{grezzo}' non interpretabile come chilometrica.")
                continue
            cippi.append((g, valore, str(grezzo)))
        return cippi, scartati

    @staticmethod
    def _cippi_sul_corridoio(corridoio, cippi, tolleranza):
        """Cippi entro `tolleranza` dal corridoio, proiettati su di esso e
        ordinati per progressiva: [(progressiva, valore, etichetta, distanza)].

        Un cippo può servire più corridoi (vicino a un bivio è normale che sia
        prossimo a due strade): non viene assegnato in esclusiva a quello più
        vicino, altrimenti in prossimità di rotatorie e incroci si perderebbe
        proprio il riferimento che serve."""
        intorno = corridoio.boundingBox()
        intorno.grow(tolleranza)
        trovati = []
        for g, valore, etichetta in cippi:
            punto = g.asPoint()
            if not intorno.contains(punto):
                continue
            d = corridoio.distance(g)
            if d > tolleranza:
                continue
            trovati.append((corridoio.lineLocatePoint(g), valore, etichetta, d))
        trovati.sort(key=lambda t: t[0])
        return trovati

    # modalità di calcolo: chiave interna ed etichetta nel combo
    _MODI_KM = (
        ("basso", "Progressione dal cippo più basso (1 m di strada = 1 m di chilometrica)"),
        ("vicino", "Progressione dal cippo più vicino all'elemento"),
        ("interpolazione", "Interpolazione fra i cippi (adatta la scala ai loro valori)"),
    )

    @staticmethod
    def _verso_progressione(cippi_corridoio):
        """+1 se le chilometriche crescono nel senso in cui il corridoio è stato
        ricucito, -1 se calano, 0 se i cippi non permettono di stabilirlo.

        Il verso in cui mergeLines() concatena i segmenti è arbitrario e non ha
        nulla a che vedere con il verso di crescita delle chilometriche: lo si
        ricava confrontando la posizione del cippo con il valore più basso con
        quella del cippo con il valore più alto."""
        if len(cippi_corridoio) < 2:
            return 0
        piu_basso = min(cippi_corridoio, key=lambda c: c[1])
        piu_alto = max(cippi_corridoio, key=lambda c: c[1])
        if piu_alto[1] == piu_basso[1] or piu_alto[0] == piu_basso[0]:
            return 0
        return 1 if piu_alto[0] > piu_basso[0] else -1

    def _chilometrica_da_cippi(self, prog_target, cippi_corridoio,
                               modo="basso", inverti=False):
        """(valore_metri, nota) per un elemento che sta a `prog_target` metri
        lungo il corridoio.

        Nelle due modalità di progressione la chilometrica è il valore del cippo
        di riferimento più la distanza REALE percorsa lungo la strada, un metro
        di strada per un metro di chilometrica: una strada ha un verso e i
        chilometri crescono in quel verso, quindi i valori risultano monotoni e
        confrontabili fra loro. L'interpolazione invece riscala le distanze sui
        valori dichiarati dai cippi: è più fedele quando i cippi sono precisi,
        ma se un cippo è posizionato male o trascritto male comprime o dilata
        tutto il tratto che lo riguarda, e la progressione si perde."""
        if not cippi_corridoio:
            return None, "nessun cippo sul corridoio"

        verso = self._verso_progressione(cippi_corridoio)
        avviso_verso = ""
        if verso == 0:
            verso = 1
            avviso_verso = (" — VERSO NON DETERMINABILE con un solo cippo utile: "
                            "se i valori crescono al contrario spunta 'Inverti il verso'")
        if inverti:
            verso = -verso

        if modo == "interpolazione" and len(cippi_corridoio) >= 2:
            valore, nota = self._interpola_fra_cippi(prog_target, cippi_corridoio)
            return valore, nota

        if modo == "vicino":
            base = min(cippi_corridoio, key=lambda c: abs(c[0] - prog_target))
        else:
            base = min(cippi_corridoio, key=lambda c: c[1])

        scostamento = verso * (prog_target - base[0])
        return (base[1] + scostamento,
                f"progressione da '{base[2]}' {scostamento:+.0f} m lungo la strada"
                + avviso_verso)

    @staticmethod
    def _interpola_fra_cippi(prog_target, cippi_corridoio):
        """Vecchia modalità: interpolazione lineare fra i due cippi che
        racchiudono il punto, estrapolazione con la pendenza della coppia più
        esterna quando il punto cade fuori dal tratto coperto."""
        prima = [c for c in cippi_corridoio if c[0] <= prog_target]
        dopo = [c for c in cippi_corridoio if c[0] > prog_target]
        if prima and dopo:
            prog_p, val_p, nome_p, _ = prima[-1]
            prog_d, val_d, nome_d = dopo[0][0], dopo[0][1], dopo[0][2]
            campata = prog_d - prog_p
            t = (prog_target - prog_p) / campata if campata else 0.0
            return val_p + t * (val_d - val_p), f"interpolato fra '{nome_p}' e '{nome_d}'"

        if dopo:
            a, b = cippi_corridoio[0], cippi_corridoio[1]
        else:
            a, b = cippi_corridoio[-2], cippi_corridoio[-1]
        campata = b[0] - a[0]
        pendenza = ((b[1] - a[1]) / campata) if campata else 1.0
        base = cippi_corridoio[0] if dopo else cippi_corridoio[-1]
        return (base[1] + pendenza * (prog_target - base[0]),
                f"estrapolato oltre '{base[2]}' con la pendenza fra '{a[2]}' e '{b[2]}'")

    def _verifica_coerenza_cippi(self, cippi_corridoio, modo="basso"):
        """Avvisi sui cippi di un corridoio che non stanno dove la loro
        chilometrica dice.

        In progressione il riferimento è il cippo più basso e la strada si
        misura 1:1, quindi ogni altro cippo dovrebbe trovarsi esattamente alla
        distanza pari alla differenza fra le due chilometriche. Lo scarto fra
        posizione dichiarata e posizione reale è l'errore che gli elementi di
        quel tratto si porteranno dietro, quindi conviene vederlo prima."""
        avvisi = []
        if len(cippi_corridoio) < 2:
            return avvisi

        # scarto di unità: nessuna coppia con una pendenza plausibile
        for a, b in zip(cippi_corridoio, cippi_corridoio[1:]):
            campata = b[0] - a[0]
            if campata <= 0.5:
                avvisi.append(f"i cippi '{a[2]}' e '{b[2]}' cadono nello stesso punto "
                              f"della strada ({campata:.1f} unità): impossibile "
                              "stabilire il verso di progressione.")
                continue
            pendenza = abs(b[1] - a[1]) / campata
            if not 0.2 <= pendenza <= 5:
                avvisi.append(
                    f"fra '{a[2]}' e '{b[2]}' ci sono {campata:.0f} unità di strada ma "
                    f"{abs(b[1] - a[1]):.0f} m di chilometrica ({pendenza:.2f} m per "
                    "metro): il valore dei cippi non è nell'unità che il plugin sta "
                    "leggendo. Controlla il 'Formato del valore scritto sul cippo' — se "
                    "hai digitato prima i metri e poi i km (100+17 per km 17+100) scegli "
                    "la voce INVERTITO.")
                return avvisi  # inutile controllare gli scarti con l'unità sbagliata

        verso = self._verso_progressione(cippi_corridoio) or 1
        base = min(cippi_corridoio, key=lambda c: c[1])
        for prog, valore, nome, _ in cippi_corridoio:
            if nome == base[2]:
                continue
            previsto = base[1] + verso * (prog - base[0])
            scarto = valore - previsto
            tolleranza = max(15.0, abs(valore - base[1]) * 0.1)
            if abs(scarto) > tolleranza:
                avvisi.append(
                    f"il cippo '{nome}' sta dove la progressione da '{base[2]}' dà "
                    f"{self._format_chilometrica(previsto)}: scarto {scarto:+.0f} m. "
                    + ("In progressione il cippo non viene usato come riferimento, "
                       "quindi il risultato non ne è influenzato, ma uno dei due cippi "
                       "è mal posizionato o trascritto male."
                       if modo != "interpolazione" else
                       "In interpolazione questo scarto viene distribuito sugli elementi "
                       "del tratto: passa alla progressione o correggi il cippo."))
        return avvisi

    # punto in cui misurare la chilometrica di una TRATTA (per i punti non serve)
    _MISURE_KM = (
        ("inizio", "Inizio della tratta (il capo con la chilometrica minore)"),
        ("medio", "Punto medio della tratta"),
        ("intervallo", "Intervallo: da inizio a fine (es. 17+100 / 17+145)"),
    )

    @staticmethod
    def _estremi_linea(geom):
        """Primo e ultimo vertice della geometria lineare, o None."""
        try:
            if geom.isMultipart():
                parti = geom.asMultiPolyline()
                punti = [p for parte in parti for p in parte]
            else:
                punti = list(geom.asPolyline())
        except Exception:
            return None
        if len(punti) < 2:
            return None
        return punti[0], punti[-1]

    def _valore_su_corridoio(self, geom, corridoio, cippi_corridoio, p):
        """(valore_numerico, testo, nota) per un elemento sul corridoio.

        Su una tratta la chilometrica dei due capi è diversa, e misurare il
        punto medio faceva sembrare incoerenti tratte adiacenti: due scavi
        consecutivi di 40 m ricevevano valori distanti 40 m mentre il primo
        finiva dove il secondo cominciava. Ora l'impostazione predefinita è il
        capo con la chilometrica minore, cioè il punto in cui la tratta inizia
        nel verso di crescita della strada, e c'è la possibilità di scrivere
        l'intervallo completo."""
        def km(punto):
            prog = corridoio.lineLocatePoint(QgsGeometry.fromPointXY(punto))
            return self._chilometrica_da_cippi(prog, cippi_corridoio,
                                               p["modo"], p["inverti"])

        if geom.type() == QgsWkbTypes.PointGeometry:
            valore, nota = km(geom.asPoint())
            return valore, (self._format_chilometrica(valore) if valore is not None else ""), nota

        estremi = self._estremi_linea(geom)
        if estremi is None or p["misura"] == "medio":
            punto = self._punto_riferimento(geom)
            if punto is None:
                return None, "", "geometria non misurabile"
            valore, nota = km(punto)
            return valore, (self._format_chilometrica(valore) if valore is not None else ""), nota

        valore_a, nota = km(estremi[0])
        valore_b, _ = km(estremi[1])
        if valore_a is None or valore_b is None:
            return None, "", nota
        minore, maggiore = sorted((valore_a, valore_b))
        if p["misura"] == "intervallo":
            testo = (f"{self._format_chilometrica(minore)} / "
                     f"{self._format_chilometrica(maggiore)}")
            return minore, testo, nota + f" — tratta lunga {maggiore - minore:.0f} m"
        return minore, self._format_chilometrica(minore), nota

    def _target_chilometriche(self):
        """Layer su cui scrivere: il layer del combo e, se richiesto, gli altri
        layer vettoriali selezionati nel pannello Livelli (esclusi il layer di
        riferimento e quello dei cippi)."""
        principale = self.cb_km_target.currentLayer()
        target = [principale] if principale else []
        if self.chk_km_multi_target.isChecked():
            esclusi = {l.id() for l in (self.cb_km_riferimento.currentLayer(),
                                        self.cb_km_ancore.currentLayer()) if l}
            for l in self.iface.layerTreeView().selectedLayers():
                if not isinstance(l, QgsVectorLayer):
                    continue
                if l.id() in esclusi or any(t.id() == l.id() for t in target):
                    continue
                if l.geometryType() not in (QgsWkbTypes.PointGeometry, QgsWkbTypes.LineGeometry):
                    continue
                target.append(l)
        return target

    def _estensione_proj(self, lyr):
        """Estensione del layer nel CRS di progetto, letta dai metadati senza
        scorrere le feature."""
        try:
            bb = lyr.extent()
            if lyr.crs() != self.project.crs():
                trasf = QgsCoordinateTransform(lyr.crs(), self.project.crs(), self.project)
                bb = trasf.transformBoundingBox(bb)
            return bb
        except Exception:
            return None

    def _area_interesse_km(self, cippi, target_lyrs, margine):
        """Bounding box entro cui leggere la linea di riferimento: cippi più
        ESTENSIONE COMPLETA dei layer target, allargata di `margine`.

        Deve essere indipendente dalla selezione, ed è il motivo per cui usa
        l'estensione dei layer e non le feature scelte: prima l'area cambiava a
        ogni lancio, quindi cambiava anche l'insieme di tratte lette dallo
        stradario e con esso il corridoio ricucito. La progressiva è misurata
        lungo il corridoio, quindi lo stesso pozzetto elaborato con la selezione
        della Tavola 1 e poi con quella della Tavola 2 otteneva due
        chilometriche diverse. Così invece il sistema di riferimento è sempre lo
        stesso e i valori sono confrontabili fra tratte, pozzetti e lanci
        successivi."""
        bb = QgsRectangle(); bb.setMinimal()
        for g, _, _ in cippi:
            bb.combineExtentWith(g.boundingBox())
        for lyr in target_lyrs:
            estensione = self._estensione_proj(lyr)
            if estensione is not None and not estensione.isEmpty():
                bb.combineExtentWith(estensione)
        if bb.isNull() or bb.isEmpty():
            return None
        bb.grow(max(margine, bb.width() * 0.25, bb.height() * 0.25))
        return QgsGeometry.fromRect(bb)

    def _feature_da_elaborare(self, lyr):
        """Feature selezionate del layer; tutte se non c'è selezione e l'utente
        ha spuntato l'opzione."""
        selezionate = list(lyr.getSelectedFeatures())
        if selezionate:
            return selezionate
        if self.chk_km_tutte_feature.isChecked():
            return list(lyr.getFeatures())
        return []

    def _parametri_chilometriche(self):
        """Controlli comuni a calcolo e diagnostica: ritorna un dizionario con
        i parametri già validati, oppure None dopo aver mostrato l'errore."""
        ancore_lyr = self.cb_km_ancore.currentLayer()
        rif_lyr = self.cb_km_riferimento.currentLayer()
        if not ancore_lyr or not rif_lyr:
            QMessageBox.warning(self, "Layer mancanti",
                "Imposta il layer dei cippi e la linea di riferimento."); return None

        idx_ancora, nome_ancora = self._campo_ancora(ancore_lyr)
        if idx_ancora < 0:
            nomi = ", ".join(c.name() for c in ancore_lyr.fields()) or "(nessun campo)"
            QMessageBox.critical(self, "Campo del cippo non indicato",
                f"Su '{ancore_lyr.name()}' non trovo il campo con il valore "
                f"chilometrico.\n\nScegli il campo giusto nel punto 1: i campi "
                f"disponibili sono:\n{nomi}"); return None

        target_lyrs = self._target_chilometriche()
        if not target_lyrs:
            QMessageBox.warning(self, "Target mancante", "Imposta il layer target."); return None

        formato = self._FORMATI_KM[max(0, self.cb_km_formato.currentIndex())][0]
        cippi, scartati = self._leggi_cippi(ancore_lyr, idx_ancora, formato)
        return {
            "ancore_lyr": ancore_lyr, "rif_lyr": rif_lyr, "target_lyrs": target_lyrs,
            "idx_ancora": idx_ancora, "nome_ancora": nome_ancora, "formato": formato,
            "cippi": cippi, "scartati": scartati,
            "raggio": self.spin_km_raggio.value(),
            "tolleranza": self.spin_km_tol_cippi.value(),
            "solo_selez_rif": self.chk_km_solo_selez_rif.isChecked(),
            "campo_gruppo": self.cb_km_campo_gruppo.currentField(),
            "campo_out": self.txt_km_campo.text().strip(),
            "modo": self._MODI_KM[max(0, self.cb_km_modo.currentIndex())][0],
            "inverti": self.chk_km_inverti.isChecked(),
            "cucitura": self.spin_km_cucitura.value(),
            "misura": self._MISURE_KM[max(0, self.cb_km_misura.currentIndex())][0],
        }

    def _corridoio_piu_vicino(self, punto, corridoi_con_cippi, raggio):
        """(indice, distanza) del corridoio più vicino al punto entro raggio."""
        geom_punto = QgsGeometry.fromPointXY(punto)
        migliore = -1; dist_migliore = None
        for i, (_, corridoio, _) in enumerate(corridoi_con_cippi):
            d = corridoio.distance(geom_punto)
            if d > raggio:
                continue
            if dist_migliore is None or d < dist_migliore:
                migliore = i; dist_migliore = d
        return migliore, dist_migliore

    def _diagnostica_chilometriche(self):
        """Spiega, numeri alla mano, perché il calcolo non produce risultati:
        CRS, cippi letti e scartati, corridoi ricuciti, distanze reali fra
        cippi/target e corridoi. Sostituisce il vecchio 'nessuna ancora sulla
        stessa linea di riferimento', che non diceva quale delle cinque cause
        possibili fosse quella vera."""
        p = self._parametri_chilometriche()
        if p is None:
            return

        r = []
        crs_prog = self.project.crs()
        r.append(f"CRS di progetto: {crs_prog.authid()} "
                 f"({'gradi — le distanze in metri NON funzionano, riproietta il progetto in UTM' if crs_prog.isGeographic() else 'unità lineari, ok'})")
        r.append(f"Cippi: '{p['ancore_lyr'].name()}' [{p['ancore_lyr'].crs().authid()}], "
                 f"campo letto: '{p['nome_ancora']}'")
        r.append(f"Riferimento: '{p['rif_lyr'].name()}' [{p['rif_lyr'].crs().authid()}], "
                 f"{p['rif_lyr'].featureCount()} tratte totali, "
                 f"{p['rif_lyr'].selectedFeatureCount()} selezionate in mappa")
        r.append("")

        r.append(f"Cippi con valore leggibile: {len(p['cippi'])} "
                 f"(formato: {dict(self._FORMATI_KM)[p['formato']]})")
        alternativo = "invertito" if p["formato"] == "km_m" else "km_m"
        for g, valore, etichetta in p["cippi"][:15]:
            riga = f"  • '{etichetta}' → {self._format_chilometrica(valore)} ({valore:.0f} m)"
            alt = self._parse_chilometrica(etichetta, alternativo)
            if alt is not None and abs(alt - valore) > 0.5:
                riga += f"   [leggendolo al contrario sarebbe {self._format_chilometrica(alt)}]"
            r.append(riga)
        if len(p["cippi"]) > 15:
            r.append(f"  … e altri {len(p['cippi']) - 15}")
        for s in p["scartati"][:10]:
            r.append(f"  ✗ {s}")
        if not p["cippi"]:
            r.append("  → senza cippi leggibili il calcolo non può partire: controlla il "
                     "campo scelto al punto 1 e il formato dei valori (12+300 / 12,3 / 12300).")
            self.log_km.setPlainText("\n".join(r)); return
        r.append("")

        area = self._area_interesse_km(p["cippi"], p["target_lyrs"], p["raggio"] * 10)
        corridoi = self._costruisci_corridoi(p["rif_lyr"], p["solo_selez_rif"],
                                             p["campo_gruppo"], area, p["cucitura"])
        origine = min(p["cippi"], key=lambda c: c[1])
        r.append(f"PUNTO 0 (cippo più basso fra tutti): '{origine[2]}' = "
                 f"{self._format_chilometrica(origine[1])}")
        r.append(f"Corridoi continui ricuciti dallo stradario: {len(corridoi)} "
                 f"(tolleranza di ricucitura {p['cucitura']:g})")
        if not corridoi:
            r.append("  → nessuna tratta di riferimento letta. Se hai spuntato 'usa solo le "
                     "tratte selezionate' devi prima selezionarle in mappa; altrimenti "
                     "controlla che lo stradario copra la zona dei cippi.")
            self.log_km.setPlainText("\n".join(r)); return

        utili = []
        for etichetta, corridoio in corridoi:
            sopra = self._cippi_sul_corridoio(corridoio, p["cippi"], p["tolleranza"])
            if sopra:
                utili.append((etichetta, corridoio, sopra))
        r.append(f"Corridoi che hanno almeno un cippo entro {p['tolleranza']:g}: {len(utili)}")
        r.append(f"Modalità: {dict(self._MODI_KM)[p['modo']]}"
                 + ("  [verso invertito a mano]" if p["inverti"] else ""))
        for etichetta, corridoio, sopra in utili[:10]:
            verso = self._verso_progressione(sopra)
            base = min(sopra, key=lambda c: c[1])
            descrizione_verso = {1: "concorde al tracciato ricucito",
                                 -1: "opposto al tracciato ricucito",
                                 0: "NON DETERMINABILE (serve un secondo cippo)"}[verso]
            r.append(f"  • {etichetta}: lunghezza {corridoio.length():.0f}, "
                     f"{len(sopra)} cippi ({', '.join(c[2] for c in sopra[:6])})")
            r.append(f"    conta da '{base[2]}', verso di crescita {descrizione_verso}")
            for a in self._verifica_coerenza_cippi(sopra, p["modo"]):
                r.append(f"    ⚠ {a}")
        if not utili:
            distanze = []
            for _, corridoio in corridoi:
                for g, _, etichetta in p["cippi"]:
                    distanze.append((corridoio.distance(g), etichetta))
            distanze.sort()
            if distanze:
                r.append(f"  → il cippo più vicino a un corridoio dista "
                         f"{distanze[0][0]:.1f} unità ('{distanze[0][1]}'): alza la "
                         f"'Tolleranza cippo → corridoio' oltre questo valore.")
            self.log_km.setPlainText("\n".join(r)); return
        r.append("")

        for lyr in p["target_lyrs"]:
            feature = self._feature_da_elaborare(lyr)
            i_out = self._indice_campo(lyr, p["campo_out"])
            r.append(f"Target '{lyr.name()}': {len(feature)} feature da elaborare, "
                     f"campo '{p['campo_out']}' "
                     f"{'presente come ' + lyr.fields().at(i_out).name() if i_out >= 0 else 'ASSENTE (crealo al punto 0)'}")
            if not feature:
                r.append("  → nessuna feature selezionata in mappa: selezionale, oppure "
                         "spunta 'elabora tutte le sue feature'.")
                continue
            agganciate = 0; fuori = []
            for f in feature:
                g = self._to_proj(f.geometry(), lyr)
                punto = self._punto_riferimento(g)
                if punto is None:
                    continue
                i, d = self._corridoio_piu_vicino(punto, utili, p["raggio"])
                if i >= 0:
                    agganciate += 1
                else:
                    tutte = [c[1].distance(QgsGeometry.fromPointXY(punto)) for c in utili]
                    if tutte:
                        fuori.append(min(tutte))
            r.append(f"  agganciate a un corridoio con cippi: {agganciate}/{len(feature)}")
            if fuori:
                r.append(f"  → le altre distano da {min(fuori):.1f} a {max(fuori):.1f} unità dal "
                         f"corridoio più vicino: alza 'Raggio ricerca target → corridoio' "
                         f"(ora {p['raggio']:g}).")

        self.log_km.setPlainText("\n".join(r))
        self._mostra_stato(self.stato_km, "Diagnostica eseguita: nessun dato modificato.")

    def _calcola_chilometriche(self):
        p = self._parametri_chilometriche()
        if p is None:
            return
        if not p["campo_out"]:
            QMessageBox.warning(self, "Campo di output mancante",
                "Indica il nome del campo su cui scrivere la chilometrica."); return
        if not p["cippi"]:
            QMessageBox.critical(self, "Nessun cippo leggibile",
                f"Nessuna feature di '{p['ancore_lyr'].name()}' ha un valore "
                f"chilometrico interpretabile nel campo '{p['nome_ancora']}'.\n\n"
                "Usa 'Diagnostica' per l'elenco degli scarti."); return

        area = self._area_interesse_km(p["cippi"], p["target_lyrs"], p["raggio"] * 10)
        corridoi = self._costruisci_corridoi(p["rif_lyr"], p["solo_selez_rif"],
                                             p["campo_gruppo"], area, p["cucitura"])
        utili = []
        for etichetta, corridoio in corridoi:
            sopra = self._cippi_sul_corridoio(corridoio, p["cippi"], p["tolleranza"])
            if sopra:
                utili.append((etichetta, corridoio, sopra))
        if not utili:
            QMessageBox.critical(self, "Nessun corridoio utilizzabile",
                f"Ho ricucito {len(corridoi)} corridoi dalla linea di riferimento, ma "
                f"nessuno ha un cippo entro {p['tolleranza']:g} unità.\n\n"
                "Premi 'Diagnostica' per vedere le distanze reali e capire quale "
                "tolleranza serve."); return

        righe = []; totale_aggiornati = 0; totale_feature = 0

        # punto 0: il cippo con la chilometrica più bassa fra tutti quelli letti.
        # È il riferimento da cui si conta, e va dichiarato in testa al log perché
        # è l'unico modo di accorgersi se fra due lanci è cambiato.
        origine = min(p["cippi"], key=lambda c: c[1])
        righe.append(f"PUNTO 0: cippo '{origine[2]}' = "
                     f"{self._format_chilometrica(origine[1])}. Da qui si conta la "
                     f"distanza reale lungo la strada, 1 m per 1 m.")
        if len(utili) > 1:
            righe.append(f"ATTENZIONE: la linea di riferimento risulta spezzata in "
                         f"{len(utili)} corridoi separati, ognuno con la propria origine: "
                         f"gli elementi che stanno su corridoi diversi NON sono "
                         f"confrontabili fra loro. Alza la 'Tolleranza di ricucitura' "
                         f"oppure seleziona in mappa le sole tratte della strada.")
        righe.append("")

        avvisi = []
        for etichetta, _, cippi_corr in utili:
            for a in self._verifica_coerenza_cippi(cippi_corr, p["modo"]):
                avvisi.append(f"⚠ {etichetta}: {a}")
        if avvisi:
            righe.append("CONTROVERIFICA SUI CIPPI (gli altri cippi non spostano il "
                         "conteggio, servono a confermarlo):")
            righe.extend("  " + a for a in avvisi)
            righe.append("")

        for lyr in p["target_lyrs"]:
            feature = self._feature_da_elaborare(lyr)
            righe.append(f"── {lyr.name()} ──")
            if not feature:
                righe.append("  nessuna feature selezionata (e opzione 'tutte' non attiva): saltato.")
                continue
            idx_out = self._indice_campo(lyr, p["campo_out"])
            if idx_out < 0:
                righe.append(f"  campo '{p['campo_out']}' assente: crealo al punto 0. Saltato.")
                continue
            nome_out = lyr.fields().at(idx_out).name()
            campo_e_testo = lyr.fields().at(idx_out).type() == QVariant.String
            if not self._start_edit(lyr):
                righe.append("  impossibile avviare la modifica: saltato.")
                continue

            aggiornati = 0; origini_usate = {}
            for f in feature:
                totale_feature += 1
                g = self._to_proj(f.geometry(), lyr)
                punto = self._punto_riferimento(g)
                if punto is None:
                    righe.append(f"  id {f.id()}: geometria mancante, saltata."); continue
                i_corr, dist = self._corridoio_piu_vicino(punto, utili, p["raggio"])
                if i_corr < 0:
                    righe.append(f"  id {f.id()}: nessun corridoio con cippi entro "
                                 f"{p['raggio']:g} unità."); continue
                etichetta_corr, corridoio, cippi_corr = utili[i_corr]
                valore, testo_km, nota = self._valore_su_corridoio(
                    g, corridoio, cippi_corr, p)
                if valore is None:
                    righe.append(f"  id {f.id()}: {nota}."); continue
                da_scrivere = (self._testo_scrivibile(lyr, testo_km) if campo_e_testo
                               else round(valore, 2))
                origini_usate[etichetta_corr] = origini_usate.get(etichetta_corr, 0) + 1
                if lyr.changeAttributeValue(f.id(), idx_out, da_scrivere):
                    aggiornati += 1
                    righe.append(f"  id {f.id()}: {testo_km} — {nota} "
                                 f"[corridoio: {etichetta_corr}, scostamento {dist:.1f}]")
                else:
                    righe.append(f"  id {f.id()}: scrittura rifiutata dal provider.")

            if self._commit(lyr, f"Salvataggio chilometriche su {lyr.name()}"):
                totale_aggiornati += aggiornati
                righe.append(f"  → {aggiornati} feature scritte nel campo '{nome_out}'.")
                if len(origini_usate) > 1:
                    righe.append("     ATTENZIONE: le feature di questo layer sono state "
                                 "misurate su corridoi diversi — "
                                 + ", ".join(f"{quante} su '{corr}'"
                                             for corr, quante in origini_usate.items()))
            else:
                righe.append("  → SALVATAGGIO ANNULLATO (rollback): nessun valore scritto.")

        intestazione = (f"{totale_aggiornati} feature valorizzate su {totale_feature} "
                        f"elaborate, usando {len(p['cippi'])} cippi su "
                        f"{len(utili)} corridoi.\n")
        self.log_km.setPlainText(intestazione + "\n" + "\n".join(righe))
        self._mostra_stato(self.stato_km, intestazione.strip(),
                           ok=totale_aggiornati > 0)

    # ─── TAB ETICHETTE ──────────────────────────────────────────────
    # ruolo -> (etichetta nel pannello, filtro layer)
    _SEPARATORI_ET = (("trattino ( - )", " - "), ("spazio", " "), ("a capo", "\n"))

    # caratteri tipografici che i DBF in codepage ANSI/Latin-1 non sanno scrivere
    # (li sostituisce con '?') e loro equivalenti ASCII
    _SOSTITUZIONI_ASCII = {
        "\u2013": "-", "\u2014": "-", "\u2212": "-",   # en dash, em dash, meno
        "\u00f7": "-",                                  # segno di divisione
        "\u00d7": "x", "\u2019": "'", "\u2018": "'",
        "\u201c": '"', "\u201d": '"', "\u2026": "...",
        "\u00a0": " ", "\u2022": "-",
    }

    def _testo_scrivibile(self, lyr, testo):
        """Adatta il testo alla codifica con cui il layer verrà scritto.

        Uno shapefile senza file .cpg dichiara una codepage ANSI e QGIS scrive
        con quella: ogni carattere fuori tabella diventa un punto interrogativo
        nell'attributo, ed è il motivo per cui nelle etichette compariva un '?'
        al posto del trattino tipografico. Qui i caratteri tipografici più
        comuni vengono ricondotti all'equivalente ASCII e, se resta qualcosa di
        non codificabile, gli accenti vengono rimossi anziché lasciare che il
        provider li rovini."""
        for originale, sostituto in self._SOSTITUZIONI_ASCII.items():
            testo = testo.replace(originale, sostituto)
        try:
            codifica = lyr.dataProvider().encoding() or "UTF-8"
        except Exception:
            codifica = "UTF-8"
        try:
            testo.encode(codifica)
            return testo
        except (UnicodeEncodeError, LookupError):
            pass
        senza_accenti = unicodedata.normalize("NFKD", testo)
        senza_accenti = "".join(c for c in senza_accenti if not unicodedata.combining(c))
        try:
            senza_accenti.encode(codifica)
            return senza_accenti
        except (UnicodeEncodeError, LookupError):
            return senza_accenti.encode("ascii", "replace").decode("ascii")

    def _tab_etichette(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("etichette"))

        v.addWidget(self._desc(
            "Compila un campo di testo (per default 'Etichette') su Armadio, Pozzetto e "
            "Infrastrutture, componendolo dalla chilometrica dell'elemento più la "
            "dicitura di posa. Il campo viene creato se manca. Le diciture e i campi di "
            "origine sono modificabili qui sotto, così se il modello dati cambia non "
            "serve rimettere mano al codice. Richiede la chilometrica già calcolata "
            "nella scheda Chilometriche."
        ))

        gb1 = self._gruppo("1) Layer da etichettare"); f1 = QFormLayout(gb1)
        self.cb_et_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        f1.addRow("Armadio Ottico:", self.cb_et_armadio)
        self.cb_et_poz = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        f1.addRow("Pozzetto:", self.cb_et_poz)
        self.cb_et_infra = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        f1.addRow("Infrastrutture:", self.cb_et_infra)
        riga_campi = QHBoxLayout()
        self.txt_et_campo = QLineEdit("Etichette")
        riga_campi.addWidget(QLabel("campo da scrivere:")); riga_campi.addWidget(self.txt_et_campo)
        self.txt_et_km = QLineEdit("Chilometrica")
        riga_campi.addWidget(QLabel("chilometrica da:")); riga_campi.addWidget(self.txt_et_km)
        f1.addRow(riga_campi)
        v.addWidget(gb1)

        gb2 = self._gruppo("2) Testo dell'etichetta"); v2 = QVBoxLayout(gb2)
        riga_forma = QHBoxLayout()
        riga_forma.addWidget(QLabel("prima della chilometrica:"))
        self.txt_et_prefisso = QLineEdit("KM ")
        self.txt_et_prefisso.setMaximumWidth(70)
        self.txt_et_prefisso.setToolTip(
            "Se il valore nel campo di origine già inizia con questo prefisso non viene "
            "ripetuto.")
        riga_forma.addWidget(self.txt_et_prefisso)
        riga_forma.addWidget(QLabel("   separatore:"))
        self.cb_et_sep = QComboBox()
        for etichetta, _ in self._SEPARATORI_ET:
            self.cb_et_sep.addItem(etichetta)
        riga_forma.addWidget(self.cb_et_sep)
        riga_forma.addStretch()
        v2.addLayout(riga_forma)

        griglia = QGridLayout()
        griglia.setHorizontalSpacing(8)
        for colonna, titolo in enumerate(("", "dicitura", "campo che la completa",
                                          "chilometrica")):
            capo = QLabel(titolo)
            capo.setStyleSheet("color: palette(mid);")
            griglia.addWidget(capo, 0, colonna)

        griglia.addWidget(QLabel("Armadio:"), 1, 0)
        self.txt_et_dic_armadio = QLineEdit("POSA ARMADIO F.O.")
        griglia.addWidget(self.txt_et_dic_armadio, 1, 1)
        nessuno = QLabel("—"); nessuno.setStyleSheet("color: palette(mid);")
        griglia.addWidget(nessuno, 1, 2)
        self.chk_et_km_armadio = QCheckBox(); self.chk_et_km_armadio.setChecked(True)
        self.chk_et_km_armadio.setToolTip("Includi la chilometrica nell'etichetta dell'armadio.")
        griglia.addWidget(self.chk_et_km_armadio, 1, 3)

        griglia.addWidget(QLabel("Pozzetto:"), 2, 0)
        self.txt_et_dic_poz = QLineEdit("POSA POZZETTO")
        griglia.addWidget(self.txt_et_dic_poz, 2, 1)
        self.cb_et_campo_tipo_poz = QgsFieldComboBox()
        self.cb_et_campo_tipo_poz.setAllowEmptyFieldName(True)
        self.cb_et_campo_tipo_poz.setToolTip("Campo con il tipo/misura del pozzetto.")
        griglia.addWidget(self.cb_et_campo_tipo_poz, 2, 2)
        self.chk_et_km_poz = QCheckBox(); self.chk_et_km_poz.setChecked(True)
        self.chk_et_km_poz.setToolTip("Includi la chilometrica nell'etichetta del pozzetto.")
        griglia.addWidget(self.chk_et_km_poz, 2, 3)

        griglia.addWidget(QLabel("Infrastrutture:"), 3, 0)
        self.txt_et_dic_infra = QLineEdit("SCAVO")
        self.txt_et_dic_infra.setToolTip(
            "Seguita dal valore della tecnica: 'SCAVO' dà 'SCAVO TRADIZIONALE' e "
            "'SCAVO MINI TRINCEA'.")
        griglia.addWidget(self.txt_et_dic_infra, 3, 1)
        self.cb_et_campo_scavo = QgsFieldComboBox()
        self.cb_et_campo_scavo.setAllowEmptyFieldName(True)
        self.cb_et_campo_scavo.setToolTip(
            "Il campo con la TECNICA di scavo (tradizionale, mini trincea, no dig…). "
            "Il plugin lo indovina guardando i valori contenuti, non il nome del campo; "
            "con 'Ispeziona i campi' vedi cosa contiene ciascun campo.")
        griglia.addWidget(self.cb_et_campo_scavo, 3, 2)
        self.chk_et_km_infra = QCheckBox()
        self.chk_et_km_infra.setToolTip(
            "Spenta: sulle tratte l'etichetta riporta solo la lavorazione. La "
            "chilometrica resta comunque scritta nel suo campo dalla scheda "
            "Chilometriche, semplicemente non compare in etichetta.")
        griglia.addWidget(self.chk_et_km_infra, 3, 3)

        griglia.addWidget(QLabel("…se Aerea:"), 4, 0)
        self.txt_et_dic_aerea = QLineEdit("POSA AEREA")
        self.txt_et_dic_aerea.setToolTip(
            f"Usata al posto di 'SCAVO' quando la tecnica vale '{VAL_AEREA}': una tratta "
            "aerea non è uno scavo. Svuota il campo per trattarle come le altre.")
        griglia.addWidget(self.txt_et_dic_aerea, 4, 1)
        v2.addLayout(griglia)

        riga_lungh = QHBoxLayout()
        riga_lungh.addWidget(QLabel("Lunghezza da:"))
        self.cb_et_campo_lungh = QgsFieldComboBox()
        self.cb_et_campo_lungh.setAllowEmptyFieldName(True)
        self.cb_et_campo_lungh.setToolTip(
            f"Se lasciato vuoto, o se il valore manca, ripiega su '{CAMPO_LUNGH_NEW}' e "
            "poi sulla lunghezza geometrica reale della tratta.")
        riga_lungh.addWidget(self.cb_et_campo_lungh)
        riga_lungh.addWidget(QLabel("decimali:"))
        self.spin_et_decimali = self._ispin(0, 3, 0)
        self.spin_et_decimali.setToolTip(
            "0 = metri interi, arrotondati (es. 100 m). Sulle tavole di permesso i "
            "centimetri non servono.")
        riga_lungh.addWidget(self.spin_et_decimali)
        riga_lungh.addWidget(QLabel("unità:"))
        self.txt_et_unita = QLineEdit("m")
        self.txt_et_unita.setMaximumWidth(50)
        riga_lungh.addWidget(self.txt_et_unita)
        riga_lungh.addStretch()
        v2.addLayout(riga_lungh)
        v.addWidget(gb2)

        self.cb_et_poz.layerChanged.connect(self._aggiorna_campi_poz_et)
        self.cb_et_infra.layerChanged.connect(self._aggiorna_campi_infra_et)
        self._aggiorna_campi_poz_et(self.cb_et_poz.currentLayer())
        self._aggiorna_campi_infra_et(self.cb_et_infra.currentLayer())

        gb3 = self._gruppo("3) Quali elementi"); v3 = QVBoxLayout(gb3)
        self.chk_et_solo_selez = QCheckBox(
            "Solo le feature selezionate (se non c'è selezione elabora tutte)")
        self.chk_et_solo_selez.setChecked(True)
        v3.addWidget(self.chk_et_solo_selez)
        self.chk_et_solo_nuovo = QCheckBox(f"Solo gli elementi con {CAMPO_STATO} = '{VAL_NUOVO}'")
        self.chk_et_solo_nuovo.setToolTip(
            "Nei layer di progetto convivono le tratte in progetto e quelle esistenti: "
            "senza questo filtro anche l'esistente riceverebbe un'etichetta di posa.")
        v3.addWidget(self.chk_et_solo_nuovo)
        self.chk_et_sovrascrivi = QCheckBox("Sovrascrivi le etichette già compilate")
        self.chk_et_sovrascrivi.setChecked(True)
        v3.addWidget(self.chk_et_sovrascrivi)
        self.chk_et_senza_km = QCheckBox("Scrivi l'etichetta anche senza chilometrica")
        self.chk_et_senza_km.setToolTip(
            "Per default le feature senza chilometrica vengono saltate e contate nel "
            "log, invece di produrre etichette mutile senza che te ne accorga.")
        v3.addWidget(self.chk_et_senza_km)
        self.chk_et_km_in_fondo = QCheckBox("Chilometrica in fondo all'etichetta")
        self.chk_et_km_in_fondo.setToolTip(
            "Come nelle tavole: prima la lavorazione, per ultima la chilometrica.")
        v3.addWidget(self.chk_et_km_in_fondo)
        self.chk_et_maiuscolo = QCheckBox("Valori degli attributi in MAIUSCOLO")
        self.chk_et_maiuscolo.setToolTip(
            "Riguarda solo i valori letti dai campi (tipo pozzetto, tecnica di scavo), "
            "non le diciture che scrivi tu.")
        v3.addWidget(self.chk_et_maiuscolo)
        v.addWidget(gb3)

        gb4 = self._gruppo("4) Grafica delle etichette in mappa"); v4 = QVBoxLayout(gb4)
        v4.addWidget(self._desc(
            "La leggibilità dipende da cosa c'è sotto: su una CTR il testo nero cade su "
            "un intreccio di linee nere e diventa illeggibile, su ortofoto si perde "
            "sull'asfalto. Il riquadro bianco semitrasparente è la soluzione delle tavole "
            "professionali perché stacca il testo da qualunque sfondo restando discreto, "
            "e l'ombra sottile lo solleva dal disegno senza appesantirlo. L'alone è più "
            "leggero e lascia vedere la mappa, ma su sfondi molto disegnati non basta."
        ))
        self.chk_et_attiva_label = QCheckBox("Mostra le etichette in mappa")
        self.chk_et_attiva_label.setChecked(True)
        v4.addWidget(self.chk_et_attiva_label)
        f4 = QFormLayout()
        riga_f = QHBoxLayout()
        self.cb_et_font = QFontComboBox()
        self.cb_et_font.setCurrentFont(QFont("Arial"))
        riga_f.addWidget(self.cb_et_font, 1)
        self.spin_et_font = self._dspin(4, 40, 9.0, 1, " pt")
        riga_f.addWidget(self.spin_et_font)
        self.chk_et_grassetto = QCheckBox("grassetto")
        riga_f.addWidget(self.chk_et_grassetto)
        f4.addRow("Carattere:", riga_f)
        self.cb_et_leggibilita = QComboBox()
        for _, etichetta in self._SFONDI_ET:
            self.cb_et_leggibilita.addItem(etichetta)
        self.cb_et_leggibilita.setCurrentIndex(3)
        f4.addRow("Leggibilità sullo sfondo:", self.cb_et_leggibilita)
        riga_o = QHBoxLayout()
        self.spin_et_opacita_sfondo = self._ispin(10, 100, 85)
        self.spin_et_opacita_sfondo.setToolTip(
            "Opacità del riquadro bianco: sotto il 70% la CTR traspare e disturba la "
            "lettura, al 100% il riquadro copre del tutto la mappa.")
        riga_o.addWidget(QLabel("opacità riquadro (%):")); riga_o.addWidget(self.spin_et_opacita_sfondo)
        riga_o.addWidget(QLabel("   distanza dall'elemento:"))
        self.spin_et_scostamento = self._dspin(0, 50, 8.0, 1, " mm")
        riga_o.addWidget(self.spin_et_scostamento)
        riga_o.addStretch()
        f4.addRow(riga_o)
        v4.addLayout(f4)
        self.chk_et_richiamo = QCheckBox("Linea di richiamo verso l'elemento")
        self.chk_et_richiamo.setChecked(True)
        v4.addWidget(self.chk_et_richiamo)
        self.chk_et_conserva_label = QCheckBox(
            "Conserva l'etichettatura già presente sul layer (aggiunge una regola)")
        self.chk_et_conserva_label.setToolTip(
            "QGIS ammette una sola etichettatura per layer: assegnandone una nuova, "
            "quella che c'era viene cancellata. Con questa spunta l'etichettatura "
            "esistente viene convertita in regola e conservata, e la nuova si aggiunge "
            "come seconda regola. Le regole si gestiscono poi da Proprietà layer → "
            "Etichette.")
        v4.addWidget(self.chk_et_conserva_label)
        v.addWidget(gb4)

        riga_b = QHBoxLayout()
        bisp = QPushButton("Ispeziona i campi")
        bisp.setToolTip("Elenca i campi dei layer con alcuni valori di esempio: serve a "
                        "capire quale campo contiene davvero la tecnica di scavo.")
        bisp.clicked.connect(self._ispeziona_campi_etichette)
        riga_b.addWidget(bisp)
        bant = QPushButton("Anteprima")
        bant.setToolTip("Mostra le etichette che verrebbero scritte, senza modificare nulla.")
        bant.clicked.connect(self._anteprima_etichette)
        riga_b.addWidget(bant)
        riga_b.addStretch()
        bgen = QPushButton("Crea il campo e scrivi le etichette")
        bgen.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        bgen.clicked.connect(self._genera_etichette)
        riga_b.addWidget(bgen)
        v.addLayout(riga_b)

        self.stato_et = self._etichetta_stato()
        v.addWidget(self.stato_et)
        self.log_et = self._log_widget(140)
        v.addWidget(self._blocco_log(self.log_et))

        v.addStretch(); return w


    # ═══════════════════════════════════════════════ ETICHETTE – LOGICA
    # indizi per riconoscere da solo il campo giusto. Quelli sui VALORI contano
    # più di quelli sul nome: in questo modello dati 'TIPOLOGIA' esiste ma
    # contiene Aerea/Interrata, non la tecnica di scavo, quindi cercare per nome
    # porta sul campo sbagliato — è proprio l'errore da evitare.
    _NOMI_SCAVO = ("scav", "tecnic", "tecnolog", "posa", "modal", "sistem", "metod")
    _VALORI_SCAVO = ("tradizional", "trincea", "no dig", "nodig", "no-dig", "fresat",
                     "spingitub", "perforaz", "trivell", "aratro", "microtrincea",
                     "minitrincea", "mini-trincea", "sottopass", "staffagg", "aereo")
    _NOMI_TIPO_POZZ = ("tipo", "pozz", "dimens", "misur", "modell", "formato")
    _VALORI_TIPO_POZZ = ("x", "cm", "125", "80", "40", "prefabbric", "botola", "chiusin")
    _NOMI_LUNGHEZZA = ("lungh", "length", "metri", "misura", "sviluppo")

    def _campioni_valori(self, lyr, limite=300):
        """{nome_campo: [valori distinti come testo]} su un campione di feature.
        Una sola lettura del layer, riusata sia dall'auto-riconoscimento sia dal
        pulsante 'Ispeziona i campi'."""
        campioni = {c.name(): [] for c in lyr.fields()}
        if not campioni:
            return campioni
        nomi = list(campioni)
        try:
            richiesta = QgsFeatureRequest().setLimit(limite)
        except Exception:
            richiesta = QgsFeatureRequest()
        letti = 0
        for f in lyr.getFeatures(richiesta):
            for i, nome in enumerate(nomi):
                valore = self._valore_testo(f, i)
                if valore and valore not in campioni[nome] and len(campioni[nome]) < 12:
                    campioni[nome].append(valore)
            letti += 1
            if letti >= limite:
                break
        return campioni

    def _campo_piu_probabile(self, lyr, indizi_nome, indizi_valore=(), solo_numerici=False):
        """Nome del campo che più probabilmente contiene il dato cercato, o ''.

        Il punteggio premia soprattutto le corrispondenze sui valori reali
        (3 punti) rispetto a quelle sul nome (1 punto), perché il nome può
        ingannare: 'TIPOLOGIA' sembra il campo della tecnica di scavo ma qui
        contiene Aerea/Interrata."""
        if lyr is None:
            return ""
        campioni = self._campioni_valori(lyr)
        migliore = ""; punteggio_migliore = 0
        for campo in lyr.fields():
            nome = campo.name()
            if solo_numerici and campo.type() not in (QVariant.Double, QVariant.Int,
                                                     QVariant.LongLong):
                continue
            punteggio = 0
            minuscolo = nome.lower()
            if any(indizio in minuscolo for indizio in indizi_nome):
                punteggio += 1
            for valore in campioni.get(nome, []):
                v = valore.lower()
                if any(indizio in v for indizio in indizi_valore):
                    punteggio += 3
                    break
            if punteggio > punteggio_migliore:
                punteggio_migliore = punteggio; migliore = nome
        return migliore

    def _aggiorna_campi_poz_et(self, layer):
        self.cb_et_campo_tipo_poz.setLayer(layer)
        if layer is None:
            return
        scelto = self._campo_piu_probabile(layer, self._NOMI_TIPO_POZZ,
                                           self._VALORI_TIPO_POZZ)
        self.cb_et_campo_tipo_poz.setField(scelto or "")

    def _aggiorna_campi_infra_et(self, layer):
        self.cb_et_campo_scavo.setLayer(layer)
        self.cb_et_campo_lungh.setLayer(layer)
        if layer is None:
            return
        self.cb_et_campo_scavo.setField(
            self._campo_piu_probabile(layer, self._NOMI_SCAVO, self._VALORI_SCAVO) or "")
        lungh = self._campo_piu_probabile(layer, self._NOMI_LUNGHEZZA, solo_numerici=True)
        if not lungh:
            lungh = self._campo_piu_probabile(layer, self._NOMI_LUNGHEZZA)
        self.cb_et_campo_lungh.setField(lungh or "")

    def _ispeziona_campi_etichette(self):
        """Elenca i campi dei layer impostati con qualche valore di esempio.
        Serve esattamente a rispondere alla domanda 'quale campo contiene
        tradizionale / mini trincea?' senza aprire la tabella attributi."""
        ruoli = [("Armadio", self.cb_et_armadio.currentLayer()),
                 ("Pozzetto", self.cb_et_poz.currentLayer()),
                 ("Infrastrutture", self.cb_et_infra.currentLayer())]
        ruoli = [(r, l) for r, l in ruoli if l is not None]
        if not ruoli:
            QMessageBox.warning(self, "Nessun layer", "Imposta almeno un layer."); return
        righe = []
        for ruolo, lyr in ruoli:
            righe.append(f"── {ruolo}: {lyr.name()} ({lyr.featureCount()} feature) ──")
            campioni = self._campioni_valori(lyr)
            for campo in lyr.fields():
                valori = campioni.get(campo.name(), [])
                esempi = ", ".join(valori[:6]) if valori else "(sempre vuoto nel campione)"
                righe.append(f"  {campo.name():<14} [{campo.typeName()}]  {esempi}")
            righe.append("")
        self.log_et.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_et,
                           "Campi elencati con i valori di esempio: scegli sopra quello giusto.")

    def _cfg_etichette(self):
        """Parametri della scheda Etichette, con i tre layer nei rispettivi
        ruoli. Ritorna None (dopo il messaggio) se non c'è nulla da fare."""
        ruoli = [("armadio", self.cb_et_armadio.currentLayer()),
                 ("pozzetto", self.cb_et_poz.currentLayer()),
                 ("infrastrutture", self.cb_et_infra.currentLayer())]
        ruoli = [(r, l) for r, l in ruoli if l is not None]
        if not ruoli:
            QMessageBox.warning(self, "Nessun layer",
                "Imposta almeno uno dei tre layer (Armadio, Pozzetto, Infrastrutture)."); return None
        campo = self.txt_et_campo.text().strip()
        if not campo:
            QMessageBox.warning(self, "Campo mancante",
                "Indica il nome del campo da creare/compilare."); return None
        return {
            "ruoli": ruoli,
            "campo": campo,
            "campo_km": self.txt_et_km.text().strip() or "Chilometrica",
            "prefisso": self.txt_et_prefisso.text(),
            "sep": self._SEPARATORI_ET[max(0, self.cb_et_sep.currentIndex())][1],
            "dic_armadio": self.txt_et_dic_armadio.text().strip(),
            "dic_poz": self.txt_et_dic_poz.text().strip(),
            "campo_tipo_poz": self.cb_et_campo_tipo_poz.currentField(),
            "dic_infra": self.txt_et_dic_infra.text().strip(),
            "dic_aerea": self.txt_et_dic_aerea.text().strip(),
            "campo_tipologia": self.cb_et_campo_scavo.currentField(),
            "campo_lungh": self.cb_et_campo_lungh.currentField(),
            "decimali": self.spin_et_decimali.value(),
            "unita": self.txt_et_unita.text().strip(),
            "maiuscolo": self.chk_et_maiuscolo.isChecked(),
            "km_in_fondo": self.chk_et_km_in_fondo.isChecked(),
            "km_per_ruolo": {"armadio": self.chk_et_km_armadio.isChecked(),
                             "pozzetto": self.chk_et_km_poz.isChecked(),
                             "infrastrutture": self.chk_et_km_infra.isChecked()},
            "conserva_label": self.chk_et_conserva_label.isChecked(),
            "font_dim": self.spin_et_font.value(),
            "font_nome": self.cb_et_font.currentFont().family(),
            "grassetto": self.chk_et_grassetto.isChecked(),
            "scostamento": self.spin_et_scostamento.value(),
            "sfondo": self._SFONDI_ET[max(0, self.cb_et_leggibilita.currentIndex())][0],
            "opacita_sfondo": self.spin_et_opacita_sfondo.value() / 100.0,
            "richiamo": self.chk_et_richiamo.isChecked(),
            "senza_km": self.chk_et_senza_km.isChecked(),
            "sovrascrivi": self.chk_et_sovrascrivi.isChecked(),
        }

    @staticmethod
    def _valore_testo(feat, indice):
        """Attributo come testo pulito, o '' se assente/NULL. Serve perché un
        campo vuoto in uno shapefile può arrivare come None, come QVariant
        nullo o come stringa di soli spazi, e nessuno dei tre va finire
        nell'etichetta."""
        if indice is None or indice < 0:
            return ""
        valore = feat[indice]
        if valore is None:
            return ""
        try:
            if hasattr(valore, "isNull") and valore.isNull():
                return ""
        except Exception:
            pass
        testo = str(valore).strip()
        return "" if testo.upper() in ("NULL", "NONE") else testo

    def _testo_chilometrica(self, feat, lyr, indice, prefisso):
        """Chilometrica formattata per l'etichetta. Un campo numerico (metri)
        viene reso in km+m; un campo di testo è già nella forma '17+100' e si
        usa così com'è. Il prefisso non viene duplicato se il valore lo ha già
        (es. i cippi scritti come 'KM 17+100')."""
        if indice is None or indice < 0:
            return ""
        grezzo = feat[indice]
        if grezzo is None or str(grezzo).strip() == "" or str(grezzo).upper() == "NULL":
            return ""
        if lyr.fields().at(indice).type() in (QVariant.Double, QVariant.Int, QVariant.LongLong):
            try:
                testo = self._format_chilometrica(float(grezzo))
            except (TypeError, ValueError):
                return ""
        else:
            testo = str(grezzo).strip()
        if prefisso and not testo.upper().startswith(prefisso.strip().upper()):
            testo = prefisso + testo
        return testo

    def _testo_lunghezza(self, feat, lyr, indici, cfg):
        """Lunghezza della tratta come testo: prima il campo indicato, poi il
        campo alternativo del modello dati, infine la lunghezza geometrica
        reale — così l'etichetta non resta senza metri solo perché il campo
        non è stato ancora calcolato."""
        for chiave in ("lungh", "lungh_alt"):
            i = indici.get(chiave, -1)
            if i is None or i < 0:
                continue
            grezzo = self._valore_testo(feat, i)
            if not grezzo:
                continue
            try:
                valore = float(grezzo.replace(",", "."))
            except ValueError:
                continue
            if valore > 0:
                return self._formatta_numero(valore, cfg["decimali"])
        g = self._to_proj(feat.geometry(), lyr)
        if g and not g.isEmpty() and g.length() > 0:
            return self._formatta_numero(g.length(), cfg["decimali"])
        return ""

    @staticmethod
    def _formatta_numero(valore, decimali):
        """Numero con la virgola decimale italiana, come si scrive sulle tavole.

        Arrotonda per eccesso a metà (8,5 → 9): la formattazione nativa di
        Python arrotonda al pari più vicino e darebbe 8, che su una misura
        stampata in tavola sembra un errore."""
        fattore = 10 ** decimali
        arrotondato = math.floor(abs(valore) * fattore + 0.5) / fattore
        if valore < 0:
            arrotondato = -arrotondato
        return f"{arrotondato:.{decimali}f}".replace(".", ",")

    def _indici_etichette(self, ruolo, lyr, cfg):
        """Indici dei campi di origine per questo ruolo, risolti in modo
        tollerante (maiuscole e nomi troncati dallo shapefile)."""
        indici = {"km": self._indice_campo(lyr, cfg["campo_km"])}
        if ruolo == "pozzetto":
            indici["tipo"] = self._indice_campo(lyr, cfg["campo_tipo_poz"])
        elif ruolo == "infrastrutture":
            indici["tipologia"] = self._indice_campo(lyr, cfg["campo_tipologia"])
            indici["lungh"] = self._indice_campo(lyr, cfg["campo_lungh"])
            indici["lungh_alt"] = self._indice_campo(lyr, CAMPO_LUNGH_NEW)
        return indici

    def _componi_etichetta(self, ruolo, feat, lyr, cfg, indici):
        """(testo_etichetta, motivo_scarto). Il motivo è valorizzato solo
        quando la feature va saltata."""
        usa_km = cfg.get("km_per_ruolo", {}).get(ruolo, True)
        km = (self._testo_chilometrica(feat, lyr, indici.get("km", -1), cfg["prefisso"])
              if usa_km else "")
        if usa_km and not km and not cfg["senza_km"]:
            return "", "chilometrica assente"

        if ruolo == "armadio":
            coda = cfg["dic_armadio"]
        elif ruolo == "pozzetto":
            tipo = self._valore_testo(feat, indici.get("tipo", -1))
            if cfg.get("maiuscolo"):
                tipo = tipo.upper()
            coda = " ".join(p for p in (cfg["dic_poz"], tipo) if p)
        else:
            tecnica = self._valore_testo(feat, indici.get("tipologia", -1))
            lunghezza = self._testo_lunghezza(feat, lyr, indici, cfg)
            misura = f"{lunghezza} {cfg['unita']}".strip() if lunghezza else ""
            if cfg.get("dic_aerea") and VAL_AEREA.lower() in tecnica.lower():
                # una tratta aerea non è uno scavo: 'SCAVO AEREA' non vuol dire nulla
                coda = " ".join(p for p in (cfg["dic_aerea"], misura) if p)
            else:
                if cfg.get("maiuscolo"):
                    tecnica = tecnica.upper()
                coda = " ".join(p for p in (cfg["dic_infra"], tecnica, misura) if p)

        ordine = (coda, km) if cfg.get("km_in_fondo") else (km, coda)
        parti = [p for p in ordine if p]
        if not parti:
            return "", "nessun dato disponibile per comporre l'etichetta"
        return cfg["sep"].join(parti), ""

    def _anteprima_etichette(self):
        """Mostra l'etichetta che verrebbe scritta sulla prima feature utile di
        ogni layer, senza modificare nulla: conviene guardarla prima di
        scrivere su tre shape."""
        cfg = self._cfg_etichette()
        if cfg is None:
            return
        righe = []
        for ruolo, lyr in cfg["ruoli"]:
            indici = self._indici_etichette(ruolo, lyr, cfg)
            righe.append(f"── {lyr.name()} ({ruolo}) ──")
            mancanti = ([f"'{cfg['campo_km']}'"]
                        if indici.get("km", -1) < 0
                        and cfg.get("km_per_ruolo", {}).get(ruolo, True) else [])
            if ruolo == "pozzetto" and indici.get("tipo", -1) < 0:
                mancanti.append(f"'{cfg['campo_tipo_poz']}'" if cfg["campo_tipo_poz"]
                                else "tipo di pozzetto non indicato")
            if ruolo == "infrastrutture":
                if indici.get("tipologia", -1) < 0:
                    mancanti.append(f"'{cfg['campo_tipologia']}'" if cfg["campo_tipologia"]
                                    else "tecnica di scavo non indicata")
                if indici.get("lungh", -1) < 0 and indici.get("lungh_alt", -1) < 0:
                    mancanti.append("lunghezza: userò quella geometrica")
            if mancanti:
                righe.append("  campi non usati: " + ", ".join(mancanti))
            feature = self._feature_etichette(lyr)
            if not feature:
                righe.append("  nessuna feature da elaborare."); continue
            mostrate = 0
            for f in feature:
                testo, scarto = self._componi_etichetta(ruolo, f, lyr, cfg, indici)
                righe.append(f"  id {f.id()}: " +
                             (repr(testo) if testo else f"SALTATA ({scarto})"))
                mostrate += 1
                if mostrate >= 3:
                    break
            if len(feature) > mostrate:
                righe.append(f"  … altre {len(feature) - mostrate} feature")
        self.log_et.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_et, "Anteprima: nessun dato è stato modificato.")

    def _feature_etichette(self, lyr):
        selezionate = list(lyr.getSelectedFeatures())
        if selezionate and self.chk_et_solo_selez.isChecked():
            feature = selezionate
        else:
            feature = list(lyr.getFeatures())
        if self.chk_et_solo_nuovo.isChecked():
            i = self._indice_campo(lyr, CAMPO_STATO)
            if i >= 0:
                atteso = VAL_NUOVO.lower()
                feature = [f for f in feature
                           if self._valore_testo(f, i).lower() == atteso]
        return feature

    # descrizione con cui la regola di etichettatura del plugin si riconosce
    # fra le altre: serve a sostituire la propria a ogni lancio senza toccare
    # le regole che l'utente ha configurato a mano
    NOME_REGOLA_ET = "FTTH Etichette permessi"

    # varianti di leggibilità del testo sullo sfondo della tavola
    _SFONDI_ET = (
        ("nessuno", "Solo testo (sfondi chiari e puliti)"),
        ("alone", "Alone bianco (leggero, lascia vedere la mappa)"),
        ("riquadro", "Riquadro bianco semitrasparente (consigliato su CTR)"),
        ("riquadro_ombra", "Riquadro bianco con ombra sottile (tavole professionali)"),
    )

    def _formato_testo_etichette(self, cfg):
        """QgsTextFormat con la resa richiesta.

        Su una CTR il testo nero cade su un intreccio di linee nere: l'alone
        bianco da solo non basta perché il tratteggio continua a leggersi dentro
        le lettere, mentre il riquadro semitrasparente stacca il testo da
        qualunque sfondo restando discreto. L'ombra è tenuta volutamente breve e
        poco opaca: serve a sollevare il riquadro dal disegno, non a fare
        effetto."""
        formato = QgsTextFormat()
        carattere = QFont(cfg.get("font_nome") or "Arial")
        carattere.setBold(bool(cfg.get("grassetto")))
        formato.setFont(carattere)
        formato.setSize(cfg.get("font_dim", 9.0))
        formato.setSizeUnit(QgsUnitTypes.RenderPoints)
        formato.setColor(QColor(0, 0, 0))

        sfondo = cfg.get("sfondo", "riquadro_ombra")
        opacita = cfg.get("opacita_sfondo", 0.85)

        if sfondo == "alone":
            alone = QgsTextBufferSettings()
            alone.setEnabled(True)
            alone.setSize(1.0)
            alone.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            alone.setColor(QColor(255, 255, 255))
            alone.setOpacity(1.0)
            formato.setBuffer(alone)

        try:
            self._aggiungi_riquadro(formato, sfondo, opacita)
        except Exception as e:
            # se una costante è cambiata in questa versione di QGIS si rinuncia
            # al riquadro, ma testo e alone restano validi
            self._nota_grafica = f"riquadro non applicato ({e})"
        return formato

    def _aggiungi_riquadro(self, formato, sfondo, opacita):
        """Riquadro e ombra, isolati dal resto: sono le parti che usano le
        costanti più soggette a cambiare fra le versioni di QGIS."""
        if sfondo in ("riquadro", "riquadro_ombra"):
            # un filo d'alone sotto al riquadro compensa l'antialiasing dei
            # caratteri sul bordo, altrimenti il testo appare sporco in stampa
            alone = QgsTextBufferSettings()
            alone.setEnabled(True)
            alone.setSize(0.4)
            alone.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            alone.setColor(QColor(255, 255, 255))
            formato.setBuffer(alone)

            riquadro = QgsTextBackgroundSettings()
            riquadro.setEnabled(True)
            riquadro.setType(QgsTextBackgroundSettings.ShapeRectangle)
            riquadro.setFillColor(QColor(255, 255, 255))
            riquadro.setStrokeColor(QColor(90, 90, 90))
            riquadro.setStrokeWidth(0.15)
            riquadro.setStrokeWidthUnit(QgsUnitTypes.RenderMillimeters)
            riquadro.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
            riquadro.setSize(QSizeF(1.0, 0.6))
            riquadro.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            riquadro.setRadii(QSizeF(0.4, 0.4))
            riquadro.setRadiiUnit(QgsUnitTypes.RenderMillimeters)
            riquadro.setOpacity(opacita)
            formato.setBackground(riquadro)

        if sfondo == "riquadro_ombra":
            ombra = QgsTextShadowSettings()
            ombra.setEnabled(True)
            # ShadowLowest: l'ombra va sotto la componente più bassa disegnata,
            # cioè sotto il riquadro e non dietro le singole lettere
            ombra.setShadowPlacement(QgsTextShadowSettings.ShadowLowest)
            ombra.setOffsetAngle(135)
            ombra.setOffsetDistance(0.7)
            ombra.setOffsetUnit(QgsUnitTypes.RenderMillimeters)
            ombra.setBlurRadius(0.6)
            ombra.setBlurRadiusUnit(QgsUnitTypes.RenderMillimeters)
            ombra.setColor(QColor(70, 70, 70))
            ombra.setOpacity(0.45)
            formato.setShadow(ombra)

    def _applica_etichettatura(self, lyr, impostazioni, conserva):
        """Applica le impostazioni di etichettatura al layer.

        Con `conserva` l'etichettatura viene aggiunta come REGOLA a quella
        esistente invece di sostituirla: QGIS ammette una sola etichettatura per
        layer, e assegnarne una nuova con setLabeling() cancella quella che c'era
        — è il motivo per cui l'etichetta già attiva su Infrastrutture spariva.
        L'unico modo di averne due contemporaneamente è l'etichettatura basata su
        regole, quindi quella semplice preesistente viene prima convertita in
        regola e conservata. Ritorna il testo da mettere nel log."""
        if not conserva:
            lyr.setLabeling(QgsVectorLayerSimpleLabeling(impostazioni))
            lyr.setLabelsEnabled(True)
            lyr.triggerRepaint()
            return "etichettatura impostata (quella precedente è stata sostituita)"

        from qgis.core import QgsRuleBasedLabeling
        esistente = lyr.labeling()
        conservate = 0
        if isinstance(esistente, QgsRuleBasedLabeling):
            radice = esistente.rootRule().clone()
            conservate = len(radice.children())
        elif esistente is not None:
            radice = None
            try:
                convertita = QgsRuleBasedLabeling.convertFromSimpleLabeling(esistente)
                if convertita is not None:
                    radice = convertita.rootRule().clone()
                    conservate = len(radice.children())
            except Exception:
                radice = None
            if radice is None:
                # ripiego: ricostruisco a mano la regola dall'etichettatura semplice
                radice = QgsRuleBasedLabeling.Rule(None)
                try:
                    precedenti = QgsPalLayerSettings(esistente.settings())
                    regola_vecchia = QgsRuleBasedLabeling.Rule(precedenti)
                    regola_vecchia.setDescription("etichettatura preesistente")
                    radice.appendChild(regola_vecchia)
                    conservate = 1
                except Exception:
                    conservate = 0
        else:
            radice = QgsRuleBasedLabeling.Rule(None)

        # via la nostra regola del lancio precedente, per non accumularne una
        # a ogni compilazione
        figli = list(radice.children())
        for indice in range(len(figli) - 1, -1, -1):
            if figli[indice].description() == self.NOME_REGOLA_ET:
                radice.removeChildAt(indice)
                conservate -= 1
        regola = QgsRuleBasedLabeling.Rule(impostazioni)
        regola.setDescription(self.NOME_REGOLA_ET)
        radice.appendChild(regola)

        lyr.setLabeling(QgsRuleBasedLabeling(radice))
        lyr.setLabelsEnabled(True)
        lyr.triggerRepaint()
        if conservate > 0:
            return (f"etichettatura aggiunta come regola '{self.NOME_REGOLA_ET}', "
                    f"conservate le {conservate} regole già presenti")
        return f"etichettatura aggiunta come regola '{self.NOME_REGOLA_ET}'"

    def _attiva_etichettatura(self, lyr, campo, cfg):
        """Imposta l'etichettatura QGIS del layer sul campo compilato, con la
        grafica delle tavole: testo nero multiriga allineato a sinistra,
        scostato dall'elemento e collegato da una linea di richiamo.

        Le costanti di posizionamento e allineamento sono state spostate di
        modulo fra le versioni di QGIS, quindi vengono cercate a runtime con
        dei ripieghi: se una non esiste si rinuncia a quel dettaglio invece di
        far fallire tutta l'operazione."""
        def costante(*percorsi):
            for percorso in percorsi:
                oggetto = QgsPalLayerSettings
                for pezzo in percorso.split("."):
                    oggetto = getattr(oggetto, pezzo, None)
                    if oggetto is None:
                        break
                if oggetto is not None:
                    return oggetto
            return None

        try:
            impostazioni = QgsPalLayerSettings()
            impostazioni.fieldName = campo
            impostazioni.enabled = True
            impostazioni.isExpression = False

            impostazioni.setFormat(self._formato_testo_etichette(cfg))

            allineamento = costante("MultiLineLeft", "MultiLineAlign.MultiLineLeft")
            if allineamento is not None:
                impostazioni.multilineAlign = allineamento

            if lyr.geometryType() == QgsWkbTypes.PointGeometry:
                piazzamento = costante("AroundPoint", "Placement.AroundPoint")
            else:
                piazzamento = costante("Line", "Placement.Line")
            if piazzamento is not None:
                impostazioni.placement = piazzamento
            impostazioni.dist = cfg.get("scostamento", 8.0)
            impostazioni.distUnits = QgsUnitTypes.RenderMillimeters
            # le etichette dei permessi devono uscire tutte, anche se si
            # sovrappongono: meglio spostarle a mano che non vederle
            impostazioni.obstacle = False
            impostazioni.priority = 10

            if cfg.get("richiamo", True):
                try:
                    from qgis.core import QgsSimpleLineCallout
                    richiamo = QgsSimpleLineCallout()
                    richiamo.setEnabled(True)
                    linea = QgsLineSymbol.createSimple(
                        {"color": "60,60,60,255", "width": "0.2"})
                    richiamo.setLineSymbol(linea)
                    if hasattr(richiamo, "setMinimumLength"):
                        richiamo.setMinimumLength(2.0)
                        richiamo.setMinimumLengthUnit(QgsUnitTypes.RenderMillimeters)
                    impostazioni.setCallout(richiamo)
                except Exception as e:
                    self.log_et.appendPlainText(
                        f"    linea di richiamo non disponibile in questa versione di QGIS ({e})")

            esito = self._applica_etichettatura(lyr, impostazioni,
                                                cfg.get("conserva_label", False))
            if self._nota_grafica:
                esito += f" — {self._nota_grafica}"
                self._nota_grafica = ""
            return esito
        except Exception as e:
            self.log_et.appendPlainText(f"  etichettatura non attivata: {e}")
            return ""

    def _genera_etichette(self):
        cfg = self._cfg_etichette()
        if cfg is None:
            return

        righe = []; totale_scritte = 0; totale_saltate = 0
        for ruolo, lyr in cfg["ruoli"]:
            righe.append(f"── {lyr.name()} ({ruolo}) ──")
            idx_out, nome_out, esito = self._assicura_campo(
                lyr, cfg["campo"], tipo_testo=True, lunghezza=254)
            if esito.startswith("fallito"):
                righe.append(f"  campo '{cfg['campo']}': {esito[8:].strip()}. Layer saltato.")
                continue
            righe.append(f"  campo '{nome_out}': {esito}"
                         + (" (nome adattato dal formato del file)"
                            if nome_out != cfg["campo"] else ""))

            indici = self._indici_etichette(ruolo, lyr, cfg)
            if indici.get("km", -1) < 0 and cfg.get("km_per_ruolo", {}).get(ruolo, True):
                righe.append(f"  ATTENZIONE: campo chilometrica '{cfg['campo_km']}' non "
                             f"trovato su questo layer: calcolalo nella scheda "
                             f"Chilometriche, oppure togli la spunta 'chilometrica' per "
                             f"questo layer. Layer saltato.")
                continue

            feature = self._feature_etichette(lyr)
            if not feature:
                righe.append("  nessuna feature da elaborare."); continue
            if not self._start_edit(lyr):
                righe.append("  impossibile avviare la modifica: layer saltato."); continue

            scritte = 0; saltate = 0; motivi = {}
            for f in feature:
                if not cfg["sovrascrivi"] and self._valore_testo(f, idx_out):
                    saltate += 1
                    motivi["etichetta già presente"] = motivi.get("etichetta già presente", 0) + 1
                    continue
                testo, scarto = self._componi_etichetta(ruolo, f, lyr, cfg, indici)
                if not testo:
                    saltate += 1
                    motivi[scarto] = motivi.get(scarto, 0) + 1
                    continue
                testo = self._testo_scrivibile(lyr, testo)
                if lyr.changeAttributeValue(f.id(), idx_out, testo):
                    scritte += 1
                else:
                    saltate += 1
                    motivi["scrittura rifiutata dal provider"] = \
                        motivi.get("scrittura rifiutata dal provider", 0) + 1

            if self._commit(lyr, f"Salvataggio etichette su {lyr.name()}"):
                totale_scritte += scritte; totale_saltate += saltate
                righe.append(f"  {scritte} etichette scritte, {saltate} saltate "
                             f"su {len(feature)} feature.")
                for motivo, quante in motivi.items():
                    righe.append(f"    – {quante} × {motivo}")
                esempio = next((f for f in feature), None)
                if esempio is not None and scritte:
                    testo, _ = self._componi_etichetta(ruolo, esempio, lyr, cfg, indici)
                    if testo:
                        righe.append(f"    esempio: {testo!r}")
                if self.chk_et_attiva_label.isChecked():
                    esito_label = self._attiva_etichettatura(lyr, nome_out, cfg)
                    if esito_label:
                        righe.append(f"    {esito_label}, campo '{nome_out}'.")
            else:
                righe.append("  SALVATAGGIO ANNULLATO (rollback): nessuna etichetta scritta.")

        intestazione = (f"{totale_scritte} etichette scritte, {totale_saltate} saltate "
                        f"su {len(cfg['ruoli'])} layer.")
        self.log_et.setPlainText(intestazione + "\n\n" + "\n".join(righe))
        self._mostra_stato(self.stato_et, intestazione, ok=totale_scritte > 0)

    # ═════════════════════════════════ EVIDENZA STRADE INTERESSATE
    NOME_LAYER_EVIDENZA = "Strade interessate (evidenza)"

    def _gruppo_evidenza_strade(self, ctx):
        """Gruppo di controlli per l'evidenza delle strade toccate dal progetto.

        Diviso in due sezioni perché era diventato un elenco di tredici controlli
        in fila, in fondo alla quarta sezione di una scheda lunga: le opzioni che
        riguardano la resa in stampa — colore, retino, nome della strada — stanno
        ora insieme, dove chi le cerca va a guardare.

        Riceve `ctx` perché la scheda Esportazione esiste in due copie (Comune e
        Altri Enti) e ogni copia deve avere i propri widget."""
        gb = self._gruppo("Evidenza delle strade interessate")
        v = QVBoxLayout(gb)
        v.addWidget(self._desc(
            "Copre con un retino le sole tratte dello stradario (ANAS, provinciale, "
            "comunale) su cui ricadono Infrastrutture, Pozzetto o Armadio Ottico, così "
            "in stampa si vede subito di quale strada si sta chiedendo il permesso. Il "
            "retino va sulla STRADA, non sugli elementi di progetto: quelli servono solo "
            "a stabilire quali tratte sono interessate, e sono i tre layer impostati in "
            "cima alla scheda. Il layer prodotto si chiama sempre allo stesso modo e "
            "viene rigenerato a ogni lancio, quindi non se ne accumulano copie, e viene "
            "messo in fondo all'elenco dei livelli per non coprire il progetto."
        ))

        # ── quali strade ──
        v.addWidget(self._intestazione("Quali strade"))
        f1 = QFormLayout()
        self.cb_ev_stradario = self._lcombo(
            QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer)
        self.cb_ev_stradario.setToolTip(
            "Il layer delle STRADE da coprire con il retino: stradario ANAS, provinciale "
            "o comunale. Non è un layer di progetto — se qui metti Infrastrutture il "
            "retino finisce sugli scavi invece che sulla strada, e il plugin te lo "
            "impedisce.")
        f1.addRow("Stradario da evidenziare:", self.cb_ev_stradario)
        self.spin_ev_tolleranza = self._dspin(0, 100, 8.0, 1, " m")
        self.spin_ev_tolleranza.setToolTip(
            "Quanto può distare un elemento dall'asse dello stradario perché quel punto "
            "sia considerato interessato. È il parametro che più spesso causa buchi nel "
            "retino: gli scavi corrono a bordo strada mentre lo stradario è l'asse, "
            "quindi su una carreggiata di 8-10 m il bordo dista 4-5 m dall'asse e con "
            "una tolleranza di 2 m quei tratti verrebbero scartati. Il log elenca gli "
            "elementi rimasti fuori e la loro distanza reale.")
        f1.addRow("Distanza max elemento → tratta:", self.spin_ev_tolleranza)
        riga_v = QHBoxLayout()
        riga_v.addWidget(QLabel("colma i vuoti fino a:"))
        self.spin_ev_vuoto = self._dspin(0, 5000, 60.0, 0, " m")
        self.spin_ev_vuoto.setToolTip(
            "Due tratti evidenziati separati da meno di questa distanza vengono uniti in "
            "uno solo. È il parametro che dà continuità al retino: senza, ogni scavo "
            "produce la sua fascetta e fra due scavi consecutivi resta un buco. Alzalo "
            "se il retino risulta ancora interrotto; abbassalo se collega tratti di "
            "strada che con i lavori non hanno nulla a che vedere.")
        riga_v.addWidget(self.spin_ev_vuoto)
        riga_v.addWidget(QLabel("   estendi oltre i lavori:"))
        self.spin_ev_margine = self._dspin(0, 200, 10.0, 1, " m")
        riga_v.addWidget(self.spin_ev_margine)
        riga_v.addStretch()
        f1.addRow("Continuità:", riga_v)
        v.addLayout(f1)

        self.chk_ev_solo_selez = QCheckBox(
            "Considera solo le feature selezionate dei layer di progetto")
        v.addWidget(self.chk_ev_solo_selez)
        self.chk_ev_solo_nuovo = QCheckBox(f"Solo gli elementi con {CAMPO_STATO} = '{VAL_NUOVO}'")
        v.addWidget(self.chk_ev_solo_nuovo)
        self.chk_ev_salda = QCheckBox(
            "Salda le fasce che si sfiorano (chiude i vuoti agli incroci)")
        self.chk_ev_salda.setChecked(True)
        self.chk_ev_salda.setToolTip(
            "Agli incroci due strade sono due corridoi distinti e fra le rispettive "
            "fasce resta una fessura. Questa opzione la chiude dilatando e ricontraendo "
            "il retino, con un raggio limitato a metà larghezza per non fondere strade "
            "parallele vicine.")
        v.addWidget(self.chk_ev_salda)
        self.chk_ev_intere = QCheckBox(
            "Copri le tratte intere dello stradario, non solo il tratto dei lavori")
        self.chk_ev_intere.setChecked(True)
        self.chk_ev_intere.setToolTip(
            "Con questa spunta ogni tratta toccata viene evidenziata per tutta la sua "
            "lunghezza, anche se gli scavi ne interessano pochi metri.")
        v.addWidget(self.chk_ev_intere)

        # ── aspetto in stampa ──
        v.addWidget(self._intestazione("Aspetto in stampa"))
        f2 = QFormLayout()
        riga_c = QHBoxLayout()
        self.btn_ev_colore = self._bottone_colore(QColor(255, 200, 0))
        riga_c.addWidget(self.btn_ev_colore)
        self.cb_ev_stile = QComboBox()
        for _, etichetta in self._STILI_EVIDENZA:
            self.cb_ev_stile.addItem(etichetta)
        chiavi_stile = [c for c, _ in self._STILI_EVIDENZA]
        self.cb_ev_stile.setCurrentIndex(chiavi_stile.index(self.STILE_EVIDENZA_DEFAULT))
        riga_c.addWidget(self.cb_ev_stile, 1)
        f2.addRow("Colore e stile:", riga_c)
        riga_l = QHBoxLayout()
        self.spin_ev_larghezza = self._dspin(0.5, 200, 8.0, 1, " m")
        self.spin_ev_larghezza.setToolTip(
            "Larghezza totale della fascia, in metri reali: si adatta alla scala della "
            "tavola perché è misurata a terra, non sul foglio.")
        riga_l.addWidget(self.spin_ev_larghezza)
        riga_l.addWidget(QLabel("   opacità:"))
        self.spin_ev_opacita = self._ispin(5, 100, 80)
        riga_l.addWidget(self.spin_ev_opacita)
        riga_l.addWidget(QLabel("%"))
        riga_l.addStretch()
        f2.addRow("Larghezza della fascia:", riga_l)
        riga_ret = QHBoxLayout()
        riga_ret.addWidget(QLabel("passo:"))
        self.spin_ev_passo = self._dspin(0.3, 20, 2.5, 1, " mm")
        self.spin_ev_passo.setToolTip(
            "Distanza fra le linee del retino, misurata sul foglio: resta uguale in "
            "stampa a qualunque scala.")
        riga_ret.addWidget(self.spin_ev_passo)
        riga_ret.addWidget(QLabel("spessore:"))
        self.spin_ev_spessore = self._dspin(0.05, 3, 0.4, 2, " mm")
        riga_ret.addWidget(self.spin_ev_spessore)
        riga_ret.addWidget(QLabel("angolo:"))
        self.spin_ev_angolo = self._ispin(0, 179, 45)
        riga_ret.addWidget(self.spin_ev_angolo)
        riga_ret.addStretch()
        f2.addRow("Retino:", riga_ret)
        riga_n = QHBoxLayout()
        self.chk_ev_etichetta = QCheckBox("Scrivi il nome della strada")
        self.chk_ev_etichetta.setChecked(True)
        self.chk_ev_etichetta.setToolTip(
            "Una sola scritta per strada, in grassetto con alone bianco, ruotata per "
            "seguire la fascia. Il nome è preso dal campo dello stradario riconosciuto "
            "come denominazione.")
        riga_n.addWidget(self.chk_ev_etichetta)
        riga_n.addWidget(QLabel("corpo:"))
        self.spin_ev_corpo_nome = self._dspin(4, 60, 16.0, 1, " pt")
        riga_n.addWidget(self.spin_ev_corpo_nome)
        riga_n.addStretch()
        f2.addRow("Nome della strada:", riga_n)
        v.addLayout(f2)
        self.chk_ev_spegni_stradario = QCheckBox(
            "Spegni le etichette dello stradario (le sigle minute ripetute)")
        self.chk_ev_spegni_stradario.setToolTip(
            "Le sigle ripetute lungo la strada vengono dall'etichettatura del layer "
            "stradario, non dall'evidenza. Questa spunta le disattiva; si riattivano "
            "da Proprietà layer → Etichette.")
        v.addWidget(self.chk_ev_spegni_stradario)

        btn = QPushButton("Evidenzia le strade interessate")
        btn.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        self._collega_consegna(btn, self._evidenzia_strade, ctx)
        v.addWidget(btn)
        self.log_ev = self._log_widget(110)
        v.addWidget(self._blocco_log(self.log_ev))
        return gb

    def _geometrie_progetto_evidenza(self):
        """Geometrie (nel CRS di progetto) dei layer di progetto da cui ricavare
        le strade interessate, con il conteggio per layer."""
        geometrie = []; conteggio = {}
        for combo in (self.cb_c_infra, self.cb_c_poz, self.cb_c_armadio):
            lyr = combo.currentLayer()
            if lyr is None:
                continue
            selezionate = list(lyr.getSelectedFeatures())
            if selezionate and self.chk_ev_solo_selez.isChecked():
                feature = selezionate
            else:
                feature = list(lyr.getFeatures())
            if self.chk_ev_solo_nuovo.isChecked():
                i = self._indice_campo(lyr, CAMPO_STATO)
                if i >= 0:
                    atteso = VAL_NUOVO.lower()
                    feature = [f for f in feature
                               if self._valore_testo(f, i).lower() == atteso]
            quante = 0
            for f in feature:
                g = self._to_proj(f.geometry(), lyr)
                if g and not g.isEmpty():
                    geometrie.append(g); quante += 1
            conteggio[lyr.name()] = quante
        return geometrie, conteggio

    def _rimuovi_layer_evidenza(self):
        """Elimina l'eventuale evidenza generata in precedenza, così i lanci
        successivi non lasciano copie sovrapposte che scuriscono il giallo."""
        for lyr in list(self.project.mapLayers().values()):
            if lyr.name() == self.NOME_LAYER_EVIDENZA:
                self.project.removeMapLayer(lyr.id())

    def _evidenzia_strade(self):
        rif = self.cb_ev_stradario.currentLayer() or self.cb_c_strada.currentLayer()
        if rif is None:
            QMessageBox.warning(self, "Stradario mancante",
                "Scegli il layer dello stradario da evidenziare (ANAS, provinciale, "
                "comunale): è quello da cui viene ricavato il retino."); return

        # il retino deve coprire la STRADA, non il progetto: se qui finisce uno
        # dei layer di progetto si otterrebbe un retino sopra gli scavi, che è
        # esattamente l'errore da evitare
        layer_progetto = {l.id(): l.name() for l in
                          (self.cb_c_infra.currentLayer(), self.cb_c_poz.currentLayer(),
                           self.cb_c_armadio.currentLayer()) if l is not None}
        if rif.id() in layer_progetto:
            QMessageBox.critical(self, "Layer sbagliato",
                f"'{rif.name()}' è uno dei layer di progetto, non lo stradario: il "
                "retino coprirebbe gli scavi invece della strada.\n\nIn 'Stradario da "
                "evidenziare' scegli il layer delle strade (es. Stradario Provincia, "
                "Rete stradale, grafo ANAS)."); return

        geometrie, conteggio = self._geometrie_progetto_evidenza()
        if not geometrie:
            QMessageBox.warning(self, "Nessun elemento",
                "Nessuna geometria nei layer Infrastrutture, Pozzetto e Armadio Ottico. "
                "Controlla i layer impostati e i filtri qui sotto."); return

        tolleranza = self.spin_ev_tolleranza.value()
        larghezza = self.spin_ev_larghezza.value()

        # Area di lettura: l'intorno degli elementi di progetto. Senza questo
        # filtro veniva scorso lo stradario INTERO, che su un grafo provinciale
        # significa centinaia di migliaia di geometrie tenute in memoria — e se
        # il layer è servito via WFS anche altrettante righe scaricate dalla rete.
        intorno = QgsRectangle(); intorno.setMinimal()
        for g in geometrie:
            intorno.combineExtentWith(g.boundingBox())
        if intorno.isNull() or intorno.isEmpty():
            QMessageBox.warning(self, "Estensione non calcolabile",
                "Non riesco a determinare l'area degli elementi di progetto."); return
        intorno.grow(max(tolleranza * 2, larghezza, 10.0))
        richiesta = self._req_area(rif, QgsGeometry.fromRect(intorno))

        try:
            provider = (rif.dataProvider().name() or "").lower()
        except Exception:
            provider = ""
        avviso_provider = ""
        if provider in ("wfs", "arcgisfeatureserver", "oapif"):
            avviso_provider = (f"Lo stradario è un layer remoto ({provider}): la lettura "
                               "passa dalla rete e può essere lenta. Se lo usi spesso, "
                               "salvane una copia locale in GeoPackage.")

        # indice spaziale sulle tratte lette, poi per ogni elemento di progetto
        # si interrogano solo quelle del suo intorno: senza indice il confronto
        # sarebbe elementi × tratte
        indice = QgsSpatialIndex()
        tratte = {}
        LIMITE_TRATTE = 100000
        for f in (rif.getFeatures(richiesta) if richiesta else rif.getFeatures()):
            g = self._to_proj(f.geometry(), rif)
            if not g or g.isEmpty():
                continue
            tratte[f.id()] = (g, f)
            try:
                indice.addFeature(f.id(), g.boundingBox())
            except TypeError:
                # versioni in cui esiste solo la firma con la feature intera
                copia = QgsFeature(f)
                copia.setGeometry(g)
                indice.addFeature(copia)
            if len(tratte) > LIMITE_TRATTE:
                QMessageBox.critical(self, "Troppe tratte",
                    f"Nell'area di lavoro ci sono più di {LIMITE_TRATTE} tratte di "
                    "stradario: probabilmente gli elementi di progetto selezionati "
                    "coprono un'area enorme, o il layer di riferimento non è uno "
                    "stradario. Restringi la selezione."); return
        if not tratte:
            QMessageBox.information(self, "Nessuna tratta nell'area",
                f"Lo stradario '{rif.name()}' non ha tratte nell'intorno degli elementi "
                "di progetto. Controlla di aver scelto il layer giusto e che i due "
                "layer siano nella stessa zona."); return

        toccate = set()
        for g in geometrie:
            area = g.boundingBox()
            area.grow(max(tolleranza, 0.001))
            for fid in indice.intersects(area):
                if fid in toccate:
                    continue
                g_tratta = tratte.get(fid, (None, None))[0]
                if g_tratta is None:
                    continue
                if g_tratta.distance(g) <= tolleranza:
                    toccate.add(fid)

        if not toccate:
            QMessageBox.information(self, "Nessuna tratta interessata",
                f"Nessuna tratta dello stradario risulta entro {tolleranza:g} m dagli "
                "elementi di progetto. Se gli scavi corrono a bordo strada prova ad "
                "alzare la distanza massima."); return

        # nomi delle strade e tratte toccate, che servono agli attributi e alla
        # modalità "tratte intere"
        nomi = {}; tratte_toccate = []
        campo_nome = self._campo_nome_strada(rif)
        for fid in toccate:
            g, f = tratte[fid]
            tratte_toccate.append((g, f))
            if campo_nome >= 0:
                nome = self._valore_testo(f, campo_nome)
                if nome:
                    nomi[nome] = nomi.get(nome, 0) + 1

        parametri = {
            "area": QgsGeometry.fromRect(intorno),
            "tolleranza": tolleranza,
            "larghezza": larghezza,
            "margine": self.spin_ev_margine.value(),
            "vuoto": self.spin_ev_vuoto.value(),
            "intere": self.chk_ev_intere.isChecked(),
            "campo_nome_strada": (rif.fields().at(campo_nome).name()
                                  if campo_nome >= 0 else ""),
        }

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            if rif.geometryType() == QgsWkbTypes.PolygonGeometry:
                # stradario già poligonale: la sede stradale è disegnata, non
                # serve ricucire nulla né bufferizzare
                fasce = [(g, self._valore_testo(f, campo_nome) if campo_nome >= 0 else "",
                          0.0)
                         for g, f in tratte_toccate if g and not g.isEmpty()]
                lunghezza_totale = 0.0
                corridoi_usati = len(fasce)
                fuori = []
            else:
                fasce, lunghezza_totale, corridoi_usati, fuori = self._fasce_da_corridoi(
                    rif, richiesta, geometrie, tratte_toccate, parametri)
        finally:
            QApplication.restoreOverrideCursor()

        if not fasce:
            QMessageBox.critical(self, "Evidenza non creata",
                "Le tratte interessate non hanno prodotto alcuna fascia utilizzabile."); return
        # Una feature per strada, non una sola geometria dissolta: è ciò che
        # permette di scrivere il nome UNA volta per strada. Con un'unica feature
        # l'etichetta sarebbe una sola per tutta l'evidenza, e con le fasce
        # separate si ripeterebbe su ogni frammento.
        per_strada = {}; metri_strada = {}
        for fascia, nome, metri in fasce:
            per_strada.setdefault(nome, []).append(fascia)
            metri_strada[nome] = metri_strada.get(nome, 0.0) + metri

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            geometrie_finali = {}
            raggio = min(larghezza / 2.0, 5.0)
            for nome, elenco in per_strada.items():
                unita = QgsGeometry.unaryUnion(elenco) if len(elenco) > 1 else elenco[0]
                if self.chk_ev_salda.isChecked() and unita and not unita.isEmpty():
                    # chiusura morfologica: dilata e ricontrae. Salda le fasce che
                    # si sfiorano — tipicamente agli incroci — con raggio limitato
                    # a metà larghezza per non fondere strade parallele vicine.
                    saldata = unita.buffer(raggio, 8).buffer(-raggio, 8)
                    if saldata and not saldata.isEmpty():
                        unita = saldata
                if unita and not unita.isEmpty():
                    geometrie_finali[nome] = unita
        finally:
            QApplication.restoreOverrideCursor()
        if not geometrie_finali:
            QMessageBox.critical(self, "Evidenza non creata",
                "L'unione delle fasce non ha prodotto una geometria valida."); return

        self._rimuovi_layer_evidenza()
        crs = self.project.crs().authid()
        if not crs:
            # CRS di progetto personalizzato: l'authid è vuoto e l'URI del layer
            # in memoria risulterebbe malformato
            crs = self.project.crs().toWkt()
        lyr = QgsVectorLayer(
            f"Polygon?crs={crs}&field=Strada:string(120)&field=Lunghezza:double(12,1)",
            self.NOME_LAYER_EVIDENZA, "memory")
        nuove = []
        for nome, geometria in sorted(geometrie_finali.items()):
            feat = QgsFeature(lyr.fields())
            feat.setGeometry(geometria)
            feat.setAttributes([
                self._testo_scrivibile(lyr, nome)[:120] if nome else "",
                round(metri_strada.get(nome, 0.0), 1)])
            nuove.append(feat)
        lyr.dataProvider().addFeatures(nuove)
        lyr.updateExtents()
        stile_usato = self._stile_evidenza(lyr)
        esito_nome = ""
        if self.chk_ev_etichetta.isChecked():
            esito_nome = self._etichetta_evidenza(lyr)

        self.project.addMapLayer(lyr, False)
        # addLayer() accoda, cioè mette il layer in fondo all'elenco dei livelli,
        # che è dove serve perché l'evidenza stia sotto gli elementi di progetto.
        # NON usare insertLayer(-1): l'indice finisce in QList::insert(), che
        # pretende 0 <= indice <= numero di figli. Con -1 Qt scrive fuori
        # dall'array e il processo muore di corruzione dell'heap — un crash
        # nativo, che nessun try/except Python può intercettare.
        self.project.layerTreeRoot().addLayer(lyr)

        righe = [f"Stradario usato: '{rif.name()}'.",
                 f"{len(toccate)} tratte dello stradario interessate, "
                 f"{lunghezza_totale:.0f} m evidenziati su {corridoi_usati} "
                 f"corridoi continui"
                 + (" (tratte intere)." if parametri["intere"]
                    else f", vuoti fino a {parametri['vuoto']:g} m colmati."),
                 f"Fascia larga {larghezza:g} m, stile '{stile_usato}', "
                 f"opacità {self.spin_ev_opacita.value()}%.",
                 "Elementi di progetto considerati: "
                 + ", ".join(f"{nome}: {quante}" for nome, quante in conteggio.items())]
        if fuori:
            valide = [d for d in fuori if d is not None]
            dettaglio = (f" Il più vicino dista {min(valide):.1f} m, il più lontano "
                         f"{max(valide):.1f} m." if valide else "")
            righe.append(f"ATTENZIONE: {len(fuori)} elementi di progetto non ricadono su "
                         f"nessun corridoio entro {tolleranza:g} m e non hanno prodotto "
                         f"retino — è la causa tipica delle interruzioni.{dettaglio} "
                         f"Alza 'Distanza max elemento → tratta' oltre quel valore.")
        if esito_nome:
            righe.append(esito_nome)
        if self.chk_ev_spegni_stradario.isChecked():
            esito_spegni = self._spegni_etichette_stradario(rif)
            if esito_spegni:
                righe.append(esito_spegni)
        if avviso_provider:
            righe.append(avviso_provider)
        if nomi:
            righe.append("Strade: " + ", ".join(f"{n} ({q} tratte)"
                                                for n, q in sorted(nomi.items())))
        righe.append(f"Layer '{self.NOME_LAYER_EVIDENZA}' aggiunto in fondo all'elenco "
                     "dei livelli: se ti serve nella tavola, ricordati che è un layer "
                     "temporaneo e va reso permanente (clic destro → Rendi permanente) "
                     "prima di chiudere il progetto.")
        self.log_ev.setPlainText("\n".join(righe))

    # ── geometria dell'evidenza: continuità lungo il corridoio ──────
    @staticmethod
    def _vertici_geometria(geom):
        """Vertici della geometria come QgsPointXY, qualunque sia il tipo."""
        punti = []
        try:
            for v in geom.vertices():
                punti.append(QgsPointXY(v.x(), v.y()))
            if punti:
                return punti
        except Exception:
            pass
        try:
            if geom.type() == QgsWkbTypes.PointGeometry:
                return [geom.asPoint()]
            if geom.isMultipart():
                for parte in geom.asMultiPolyline():
                    punti.extend(parte)
            else:
                punti.extend(geom.asPolyline())
        except Exception:
            return punti
        return punti

    @staticmethod
    def _sottolinea(geom, da, a):
        """Porzione di polilinea compresa fra due progressive, con i vertici
        intermedi conservati e i due estremi interpolati.

        Serve perché l'evidenza deve seguire la strada per il tratto richiesto:
        prendere solo i due punti agli estremi taglierebbe le curve in linea
        retta e la fascia uscirebbe dalla carreggiata."""
        try:
            punti = list(geom.asPolyline())
        except Exception:
            return None
        if len(punti) < 2:
            return None
        lunghezza = geom.length()
        da = max(0.0, min(da, lunghezza))
        a = max(0.0, min(a, lunghezza))
        if a - da <= 1e-9:
            return None

        risultato = []
        percorso = 0.0
        for i in range(len(punti) - 1):
            p, q = punti[i], punti[i + 1]
            segmento = math.hypot(q.x() - p.x(), q.y() - p.y())
            if segmento <= 0:
                continue
            inizio, fine = percorso, percorso + segmento
            percorso = fine
            if fine < da or inizio > a:
                continue
            if inizio < da:
                t = (da - inizio) / segmento
                risultato.append(QgsPointXY(p.x() + (q.x() - p.x()) * t,
                                            p.y() + (q.y() - p.y()) * t))
            elif not risultato:
                risultato.append(QgsPointXY(p.x(), p.y()))
            if fine <= a:
                risultato.append(QgsPointXY(q.x(), q.y()))
            else:
                t = (a - inizio) / segmento
                risultato.append(QgsPointXY(p.x() + (q.x() - p.x()) * t,
                                            p.y() + (q.y() - p.y()) * t))
                break
        if len(risultato) < 2:
            return None
        return QgsGeometry.fromPolylineXY(risultato)

    def _intervalli_toccati(self, corridoio, geometrie, tolleranza):
        """Intervalli di progressiva del corridoio interessati dagli elementi:
        [(da, a), …]. Di ogni elemento si proiettano TUTTI i vertici, non solo
        gli estremi, perché uno scavo curvo può allontanarsi dall'asse nel
        mezzo e verrebbe misurato più corto di quello che è."""
        intervalli = []
        for g in geometrie:
            if corridoio.distance(g) > tolleranza:
                continue
            progressive = [corridoio.lineLocatePoint(QgsGeometry.fromPointXY(p))
                           for p in self._vertici_geometria(g)]
            if progressive:
                intervalli.append((min(progressive), max(progressive)))
        return intervalli

    @staticmethod
    def _unisci_intervalli(intervalli, vuoto_max):
        """Fonde gli intervalli separati da meno di `vuoto_max`.

        È il punto che dà continuità al retino: senza questo passaggio ogni
        elemento produce la sua fascetta e fra due scavi consecutivi, o dove il
        progetto si scosta dall'asse oltre la tolleranza, restano buchi."""
        if not intervalli:
            return []
        ordinati = sorted(intervalli)
        uniti = [list(ordinati[0])]
        for da, a in ordinati[1:]:
            if da - uniti[-1][1] <= vuoto_max:
                uniti[-1][1] = max(uniti[-1][1], a)
            else:
                uniti.append([da, a])
        return [tuple(x) for x in uniti]

    @staticmethod
    def _nome_da_chiave(chiave):
        """Il nome della strada dalla chiave del corridoio, che può essere
        'SR56' oppure 'SR56 – tronco 2' quando la strada si spezza."""
        testo = str(chiave)
        pezzo = testo.split(" – tronco ")[0].strip()
        return "" if pezzo in ("tutte le tratte", "None", "") else pezzo

    def _fasce_da_corridoi(self, rif, richiesta, geometrie, tratte_toccate, p):
        """Fasce continue lungo i corridoi dello stradario.

        Ritorna (fasce, lunghezza_evidenziata, numero_corridoi_usati). Lo
        stradario viene prima ricucito in corridoi continui, poi su ciascuno si
        calcolano gli intervalli interessati e si colmano i vuoti: l'evidenza
        risulta un tratto unico invece di una collana di frammenti."""
        # raggruppando per nome strada, ogni corridoio appartiene a una sola
        # strada: serve sia a non ricucire due strade diverse fra loro, sia a
        # poter scrivere il nome corretto su ciascuna fascia
        campo_gruppo = p.get("campo_nome_strada", "")
        corridoi = self._costruisci_corridoi(
            rif, False, campo_gruppo, p["area"] if richiesta is not None else None, 1.0)

        fasce = []; lunghezza = 0.0; usati = 0
        agganciati = set()  # indici delle geometrie di progetto effettivamente usate
        for chiave, corridoio in corridoi:
            if p["intere"]:
                # copertura per tratte intere: si proietta sul corridoio
                # l'estensione completa di ogni tratta toccata
                intervalli = []
                for g, _ in tratte_toccate:
                    if corridoio.distance(g) > 0.5:
                        continue
                    progressive = [corridoio.lineLocatePoint(QgsGeometry.fromPointXY(pt))
                                   for pt in self._vertici_geometria(g)]
                    if progressive:
                        intervalli.append((min(progressive), max(progressive)))
            else:
                intervalli = []
                for indice, g in enumerate(geometrie):
                    if corridoio.distance(g) > p["tolleranza"]:
                        continue
                    progressive = [corridoio.lineLocatePoint(QgsGeometry.fromPointXY(pt))
                                   for pt in self._vertici_geometria(g)]
                    if progressive:
                        intervalli.append((min(progressive), max(progressive)))
                        agganciati.add(indice)
            if not intervalli:
                continue

            margine = p["margine"]
            intervalli = [(da - margine, a + margine) for da, a in intervalli]
            intervalli = self._unisci_intervalli(intervalli, p["vuoto"])
            usati += 1
            for da, a in intervalli:
                porzione = self._sottolinea(corridoio, da, a)
                if porzione is None:
                    continue
                lunghezza += porzione.length()
                fascia = porzione.buffer(p["larghezza"] / 2.0, 12)
                if fascia and not fascia.isEmpty():
                    fasce.append((fascia, self._nome_da_chiave(chiave),
                                  porzione.length()))

        # elementi rimasti fuori: è la spia dei buchi nel retino, quindi va
        # riportata con la distanza reale invece di lasciarli sparire in silenzio
        fuori = []
        if not p["intere"]:
            for indice, g in enumerate(geometrie):
                if indice in agganciati:
                    continue
                distanze = [c.distance(g) for _, c in corridoi]
                fuori.append(min(distanze) if distanze else None)
        return fasce, lunghezza, usati, fuori

    def _costante_pal(self, *percorsi):
        """Costante di QgsPalLayerSettings cercata a runtime: fra le versioni di
        QGIS queste enumerazioni hanno cambiato più volte posizione, quindi si
        provano i percorsi noti e si rinuncia al dettaglio se nessuno esiste."""
        for percorso in percorsi:
            oggetto = QgsPalLayerSettings
            for pezzo in percorso.split("."):
                oggetto = getattr(oggetto, pezzo, None)
                if oggetto is None:
                    break
            if oggetto is not None:
                return oggetto
        return None

    def _etichetta_evidenza(self, lyr):
        """Scrive il nome della strada sull'evidenza, una volta per strada.

        Le tre impostazioni che contano sono: `labelPerPart = False`, che dà una
        sola etichetta anche quando la fascia di una strada è spezzata in più
        parti; nessuna distanza di ripetizione, che è ciò che nello stradario
        produce le sigle minute ripetute ogni pochi centimetri di carta; e il
        piazzamento libero, che ruota il testo per farlo stare dentro la fascia
        seguendone l'andamento diagonale."""
        try:
            impostazioni = QgsPalLayerSettings()
            impostazioni.fieldName = "Strada"
            impostazioni.enabled = True
            impostazioni.isExpression = False

            formato = QgsTextFormat()
            carattere = QFont("Arial")
            carattere.setBold(True)
            formato.setFont(carattere)
            formato.setSize(self.spin_ev_corpo_nome.value())
            formato.setSizeUnit(QgsUnitTypes.RenderPoints)
            formato.setColor(QColor(60, 45, 0))
            alone = QgsTextBufferSettings()
            alone.setEnabled(True)
            alone.setSize(1.0)
            alone.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            alone.setColor(QColor(255, 255, 255))
            formato.setBuffer(alone)
            impostazioni.setFormat(formato)

            # una sola etichetta per feature, anche se la fascia è in più pezzi
            impostazioni.labelPerPart = False
            for attributo in ("repeatDistance",):
                if hasattr(impostazioni, attributo):
                    setattr(impostazioni, attributo, 0.0)

            piazzamento = self._costante_pal("Free", "Placement.Free",
                                             "Horizontal", "Placement.Horizontal")
            if piazzamento is not None:
                impostazioni.placement = piazzamento
            # l'etichetta della strada non deve essere scartata per collisione
            # con le etichette dei pozzetti: in tavola serve sempre
            impostazioni.obstacle = False
            impostazioni.priority = 10

            lyr.setLabeling(QgsVectorLayerSimpleLabeling(impostazioni))
            lyr.setLabelsEnabled(True)
            lyr.triggerRepaint()
            return (f"Nome della strada scritto sull'evidenza a "
                    f"{self.spin_ev_corpo_nome.value():g} pt, una volta per strada.")
        except Exception as e:
            return f"Nome della strada non applicato: {e}"

    def _spegni_etichette_stradario(self, rif):
        """Disattiva l'etichettatura del layer stradario, che è ciò che produce
        le sigle ripetute lungo la strada. Operazione reversibile dalle proprietà
        del layer, quindi non distruttiva, ma va dichiarata nel log perché
        modifica un layer che l'utente non ha chiesto di toccare."""
        try:
            if not rif.labelsEnabled():
                return ""
            rif.setLabelsEnabled(False)
            rif.triggerRepaint()
            return (f"Etichette di '{rif.name()}' disattivate (erano quelle ripetute "
                    "lungo la strada). Per riattivarle: Proprietà layer → Etichette.")
        except Exception as e:
            return f"Etichette dello stradario non modificate: {e}"

    def _campo_nome_strada(self, lyr):
        """Indice del campo con il nome/codice della strada, se riconoscibile."""
        for nome in ("nome_strada", "denominazione", "strada", "nome", "codice",
                     "sigla", "via", "descrizione"):
            i = self._indice_campo(lyr, nome)
            if i >= 0:
                return i
        for campo in lyr.fields():
            if any(indizio in campo.name().lower()
                   for indizio in ("strad", "nome", "denom", "via", "sigla")):
                return lyr.fields().indexOf(campo.name())
        return -1

    # stili disponibili per l'evidenza
    # stile preselezionato all'apertura
    STILE_EVIDENZA_DEFAULT = "pieno"

    _STILI_EVIDENZA = (
        ("retino", "Retino diagonale (lascia leggere la strada sotto)"),
        ("retino_incrociato", "Retino incrociato"),
        ("retino_bordo", "Retino diagonale con bordo continuo"),
        ("pieno", "Tinta unita"),
    )

    @staticmethod
    def _bottone_colore(colore_iniziale):
        """Selettore di colore. Usa QgsColorButton, che è il widget nativo di
        QGIS, e se non fosse disponibile ripiega su un pulsante che apre il
        dialogo di sistema: in entrambi i casi espone .color(), così il codice
        che lo interroga non deve sapere quale dei due è."""
        try:
            from qgis.gui import QgsColorButton
            bottone = QgsColorButton()
            bottone.setColor(colore_iniziale)
            bottone.setAllowOpacity(False)
            return bottone
        except Exception:
            from qgis.PyQt.QtWidgets import QColorDialog
            bottone = QPushButton()
            bottone._colore = colore_iniziale

            def aggiorna():
                bottone.setStyleSheet(
                    f"background-color: {bottone._colore.name()};")
                bottone.setText(bottone._colore.name())

            def scegli():
                scelto = QColorDialog.getColor(bottone._colore, bottone)
                if scelto.isValid():
                    bottone._colore = scelto
                    aggiorna()

            bottone.color = lambda: bottone._colore
            bottone.clicked.connect(scegli)
            aggiorna()
            return bottone

    def _simbolo_evidenza(self, stile):
        """Simbolo di riempimento per l'evidenza.

        Il retino è preferibile al pieno perché copre la strada dichiarandola
        interessata senza nasconderne il disegno: sulla CTR o sull'ortofoto si
        continuano a leggere carreggiata, civici e accessi sotto le linee,
        mentre un campo pieno — anche trasparente — appiattisce tutto."""
        colore = self.btn_ev_colore.color()
        scuro = colore.darker(140)
        if stile == "pieno":
            return QgsFillSymbol.createSimple({
                "color": f"{colore.red()},{colore.green()},{colore.blue()}",
                "outline_color": f"{scuro.red()},{scuro.green()},{scuro.blue()}",
                "outline_width": "0.2",
                "outline_style": "solid",
            })

        from qgis.core import QgsLinePatternFillSymbolLayer, QgsSimpleLineSymbolLayer
        retino = QgsLinePatternFillSymbolLayer()
        retino.setLineAngle(float(self.spin_ev_angolo.value()))
        retino.setDistance(self.spin_ev_passo.value())
        retino.setDistanceUnit(QgsUnitTypes.RenderMillimeters)
        retino.setLineWidth(self.spin_ev_spessore.value())
        retino.setLineWidthUnit(QgsUnitTypes.RenderMillimeters)
        retino.setColor(colore)
        # Il colore va impostato anche sul sotto-simbolo, altrimenti in alcune
        # versioni il retino resta del colore di default. Va però passato un
        # CLONE: setSubSymbol() distrugge il sotto-simbolo corrente e prende
        # possesso di quello nuovo, quindi rigirargli lo stesso oggetto ottenuto
        # da subSymbol() significa fargli usare un puntatore già liberato — un
        # crash nativo, non un'eccezione.
        try:
            sotto = retino.subSymbol()
            if sotto is not None:
                nuovo = sotto.clone()
                nuovo.setColor(colore)
                nuovo.setWidth(self.spin_ev_spessore.value())
                nuovo.setWidthUnit(QgsUnitTypes.RenderMillimeters)
                retino.setSubSymbol(nuovo)
        except Exception:
            pass

        simbolo = QgsFillSymbol()
        if simbolo.symbolLayerCount() > 0:
            simbolo.changeSymbolLayer(0, retino)
        else:
            simbolo.appendSymbolLayer(retino)
        if stile == "retino_incrociato":
            incrocio = QgsLinePatternFillSymbolLayer()
            incrocio.setLineAngle((float(self.spin_ev_angolo.value()) + 90.0) % 180.0)
            incrocio.setDistance(self.spin_ev_passo.value())
            incrocio.setDistanceUnit(QgsUnitTypes.RenderMillimeters)
            incrocio.setLineWidth(self.spin_ev_spessore.value())
            incrocio.setLineWidthUnit(QgsUnitTypes.RenderMillimeters)
            incrocio.setColor(colore)
            try:
                sotto2 = incrocio.subSymbol()
                if sotto2 is not None:
                    clone2 = sotto2.clone()
                    clone2.setColor(colore)
                    clone2.setWidth(self.spin_ev_spessore.value())
                    clone2.setWidthUnit(QgsUnitTypes.RenderMillimeters)
                    incrocio.setSubSymbol(clone2)
            except Exception:
                pass
            simbolo.appendSymbolLayer(incrocio)
        if stile == "retino_bordo":
            bordo = QgsSimpleLineSymbolLayer(scuro, 0.35)
            bordo.setWidthUnit(QgsUnitTypes.RenderMillimeters)
            simbolo.appendSymbolLayer(bordo)
        return simbolo

    def _stile_evidenza(self, lyr):
        """Applica lo stile scelto al layer di evidenza."""
        stile = self._STILI_EVIDENZA[max(0, self.cb_ev_stile.currentIndex())][0]
        try:
            lyr.setRenderer(QgsSingleSymbolRenderer(self._simbolo_evidenza(stile)))
            lyr.setOpacity(self.spin_ev_opacita.value() / 100.0)
            lyr.triggerRepaint()
            return stile
        except Exception as e:
            self.log_ev.appendPlainText(f"retino non applicato ({e}): uso il riempimento pieno")
            try:
                lyr.setRenderer(QgsSingleSymbolRenderer(self._simbolo_evidenza("pieno")))
                lyr.setOpacity(self.spin_ev_opacita.value() / 100.0)
                lyr.triggerRepaint()
            except Exception:
                pass
            return "pieno"

    # ═════════════════════════════════ PERSISTENZA DELLE IMPOSTAZIONI
    # prefissi degli attributi da memorizzare fra le sessioni
    _PREFISSI_SALVATI = ("chk_", "spin_", "txt_", "cb_", "btn_ev_colore")

    def _widget_salvabili(self):
        """[(chiave, widget)] dei controlli il cui valore va conservato.

        I combo dei layer sono esclusi di proposito: puntano a layer di un
        progetto specifico e ripristinarli su un altro progetto darebbe
        riferimenti sbagliati — per quelli valgono i preset di refresh_layers().

        I widget della scheda Esportazione hanno una chiave per copia, perché la
        scheda esiste due volte (Comune e Altri Enti) e self.<nome> punta solo
        all'ultima costruita: senza la distinzione si salverebbe una copia e si
        ripristinerebbe sull'altra."""
        voci = []
        nomi_consegna = set(self._ATTR_CONSEGNA)
        for nome, oggetto in list(self.__dict__.items()):
            if nome in nomi_consegna:
                continue
            if not any(nome.startswith(pref) for pref in self._PREFISSI_SALVATI):
                continue
            if self._tipo_salvabile(oggetto) is not None:
                voci.append((nome, oggetto))
        for indice, contesto in enumerate(self._contesti_consegna):
            for nome, oggetto in contesto.items():
                if self._tipo_salvabile(oggetto) is not None:
                    voci.append((f"consegna{indice}.{nome}", oggetto))
        return voci

    @staticmethod
    def _tipo_salvabile(oggetto):
        """Come leggere e scrivere il valore del widget, o None se non è un
        widget di cui abbia senso conservare lo stato."""
        if isinstance(oggetto, QgsMapLayerComboBox):
            return None          # riferimenti a layer: vedi _widget_salvabili
        if isinstance(oggetto, QgsFieldComboBox):
            return None          # dipende dal layer corrente
        if isinstance(oggetto, QCheckBox):
            return "spunta"
        if isinstance(oggetto, (QDoubleSpinBox, QSpinBox)):
            return "numero"
        if isinstance(oggetto, QFontComboBox):
            return "carattere"
        if isinstance(oggetto, QComboBox):
            return "indice"
        if isinstance(oggetto, QLineEdit):
            return "testo"
        if hasattr(oggetto, "color") and hasattr(oggetto, "setColor"):
            return "colore"
        return None

    def _salva_impostazioni(self):
        """Memorizza i valori dei controlli. Chiamata alla chiusura, così alla
        riapertura il pannello è già come lo si è lasciato: è la forma utile di
        'default', perché segue le abitudini di chi lavora invece di imporre le
        mie."""
        try:
            self._impostazioni.beginGroup("controlli")
            for chiave, widget in self._widget_salvabili():
                tipo = self._tipo_salvabile(widget)
                try:
                    if tipo == "spunta":
                        self._impostazioni.setValue(chiave, widget.isChecked())
                    elif tipo == "numero":
                        self._impostazioni.setValue(chiave, widget.value())
                    elif tipo == "indice":
                        self._impostazioni.setValue(chiave, widget.currentIndex())
                    elif tipo == "carattere":
                        self._impostazioni.setValue(chiave, widget.currentFont().family())
                    elif tipo == "testo":
                        self._impostazioni.setValue(chiave, widget.text())
                    elif tipo == "colore":
                        self._impostazioni.setValue(chiave, widget.color().name())
                except Exception:
                    continue
            self._impostazioni.endGroup()
        except Exception:
            pass

    def _ripristina_impostazioni(self):
        """Rimette i valori memorizzati. Ogni widget è protetto a sé: un valore
        illeggibile o fuori intervallo fa perdere quel solo controllo, che resta
        al proprio default, invece di far fallire l'apertura del pannello."""
        try:
            self._impostazioni.beginGroup("controlli")
            for chiave, widget in self._widget_salvabili():
                tipo = self._tipo_salvabile(widget)
                if not self._impostazioni.contains(chiave):
                    continue
                try:
                    if tipo == "spunta":
                        widget.setChecked(
                            self._impostazioni.value(chiave, type=bool))
                    elif tipo == "numero":
                        valore = float(self._impostazioni.value(chiave))
                        if isinstance(widget, QSpinBox):
                            widget.setValue(int(round(valore)))
                        else:
                            widget.setValue(valore)
                    elif tipo == "indice":
                        indice = int(self._impostazioni.value(chiave))
                        if 0 <= indice < widget.count():
                            widget.setCurrentIndex(indice)
                    elif tipo == "carattere":
                        widget.setCurrentFont(QFont(str(self._impostazioni.value(chiave))))
                    elif tipo == "testo":
                        widget.setText(str(self._impostazioni.value(chiave)))
                    elif tipo == "colore":
                        colore = QColor(str(self._impostazioni.value(chiave)))
                        if colore.isValid():
                            widget.setColor(colore)
                except Exception:
                    continue
            self._impostazioni.endGroup()
        except Exception:
            pass

    def _azzera_impostazioni(self):
        """Riporta tutti i controlli ai valori di fabbrica."""
        if QMessageBox.question(
                self, "Ripristina i valori iniziali",
                "Vuoi riportare tutti i campi ai valori predefiniti del plugin?\\n"
                "Le impostazioni memorizzate verranno dimenticate.",
                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        try:
            self._impostazioni.beginGroup("controlli")
            self._impostazioni.remove("")
            self._impostazioni.endGroup()
        except Exception:
            pass
        QMessageBox.information(
            self, "Valori iniziali ripristinati",
            "Chiudi e riapri il pannello per vedere i valori predefiniti.")

    # ─── TAB SUOLO COMUNALE ─────────────────────────────────────────
    NOME_GRUPPO_COMUNALE = "Elementi su suolo comunale"
    CAMPO_SUOLO = "SUOLO"
    VAL_COMUNALE = "COMUNALE"
    VAL_ALTRO_ENTE = "ALTRO ENTE"

    def _tab_suolo(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("suolo"))
        v.addWidget(self._desc(
            "Individua gli elementi di progetto che NON ricadono sugli stradari di "
            "competenza dell'ente (SP, ANAS, altro) e li separa in un gruppo di livelli a "
            "sé, che si può spegnere quando si stampa la tavola per quell'ente. Prima li "
            "seleziona in mappa perché tu li possa controllare a vista, poi — solo dopo "
            "la tua conferma — li sposta. Lo spostamento non cancella nulla e non duplica "
            "geometrie: scrive un attributo che distingue i due suoli e usa quello come "
            "filtro, sul gruppo nuovo e su quelli originali. Gli stili sono conservati "
            "perché i livelli del gruppo nuovo sono cloni di quelli originali, stessa "
            "sorgente e stessa simbologia. Tutto è annullabile col terzo pulsante."
        ))

        gb1 = self._gruppo("1) Stradari dell'ente"); v1 = QVBoxLayout(gb1)
        v1.addWidget(QLabel("Seleziona uno o più stradari (Ctrl+clic per aggiungerne):"))
        self.lst_su_stradari = QListWidget()
        self.lst_su_stradari.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_su_stradari.setMaximumHeight(110)
        v1.addWidget(self.lst_su_stradari)
        v.addWidget(gb1)

        gb2 = self._gruppo("2) Livelli da analizzare"); v2 = QVBoxLayout(gb2)
        v2.addWidget(QLabel("Armadio, Pozzetto, Infrastrutture o qualunque altro livello:"))
        self.lst_su_layer = QListWidget()
        self.lst_su_layer.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_su_layer.setMaximumHeight(110)
        v2.addWidget(self.lst_su_layer)
        f2 = QFormLayout()
        self.spin_su_tolleranza = self._dspin(0, 200, 8.0, 1, " m")
        self.spin_su_tolleranza.setToolTip(
            "Oltre questa distanza dall'asse dello stradario l'elemento è considerato "
            "fuori. Gli scavi corrono a bordo strada mentre lo stradario è l'asse, quindi "
            "una tolleranza troppo stretta classificherebbe come comunale ciò che sta "
            "sulla provinciale.")
        f2.addRow("Distanza max dallo stradario:", self.spin_su_tolleranza)
        self.txt_su_gruppo = QLineEdit(self.NOME_GRUPPO_COMUNALE)
        f2.addRow("Nome del gruppo da creare:", self.txt_su_gruppo)
        v2.addLayout(f2)
        self.chk_su_solo_nuovo = QCheckBox(f"Solo gli elementi con {CAMPO_STATO} = '{VAL_NUOVO}'")
        v2.addWidget(self.chk_su_solo_nuovo)
        self.chk_su_zoom = QCheckBox("Inquadra gli elementi trovati dopo l'analisi")
        self.chk_su_zoom.setChecked(True)
        v2.addWidget(self.chk_su_zoom)
        v.addWidget(gb2)

        riga_b = QHBoxLayout()
        b1 = QPushButton("1. Evidenzia in mappa gli elementi fuori stradario")
        b1.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        b1.clicked.connect(self._trova_fuori_stradario)
        riga_b.addWidget(b1)
        b2 = QPushButton("2. Sposta nel gruppo")
        b2.setToolTip("Attivo dopo l'analisi: sposta gli elementi evidenziati nel gruppo "
                      "nuovo, filtrando gli originali.")
        b2.clicked.connect(self._sposta_su_suolo_comunale)
        riga_b.addWidget(b2)
        v.addLayout(riga_b)
        riga_b2 = QHBoxLayout()
        riga_b2.addStretch()
        b3 = QPushButton("Annulla lo spostamento")
        b3.setToolTip("Rimuove il gruppo e azzera i filtri sui livelli originali. "
                      "L'attributo scritto resta, ma non filtra più nulla.")
        b3.clicked.connect(self._annulla_suolo_comunale)
        riga_b2.addWidget(b3)
        v.addLayout(riga_b2)

        self.stato_su = self._etichetta_stato()
        v.addWidget(self.stato_su)
        self.log_su = self._log_widget(140)
        v.addWidget(self._blocco_log(self.log_su))

        v.addStretch(); return w

    # ═════════════════════════════════════════ SUOLO COMUNALE – LOGICA
    def _popola_elenchi_suolo(self):
        """Riempie i due elenchi con i livelli del progetto, conservando la
        selezione già fatta e preselezionando i tre livelli di progetto tipici la
        prima volta."""
        for elenco, tipi, preselezione in (
                (self.lst_su_stradari,
                 (QgsWkbTypes.LineGeometry, QgsWkbTypes.PolygonGeometry),
                 ("Stradario Provincia Italia", "Stradario", "Provinciali", "ANAS")),
                (self.lst_su_layer,
                 (QgsWkbTypes.PointGeometry, QgsWkbTypes.LineGeometry),
                 ("01_ARMADIO OTTICO", "02_POZZETTO", "03 INFRASTRUTTURE"))):
            gia_scelti = {e.data(Qt.UserRole) for e in elenco.selectedItems()}
            primo_giro = elenco.count() == 0
            elenco.clear()
            for lyr in self.project.mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() not in tipi:
                    continue
                if lyr.name() == self.NOME_LAYER_EVIDENZA:
                    continue
                voce = QListWidgetItem(lyr.name())
                voce.setData(Qt.UserRole, lyr.id())
                elenco.addItem(voce)
                if lyr.id() in gia_scelti or (primo_giro and lyr.name() in preselezione):
                    voce.setSelected(True)

    def _layer_scelti(self, elenco):
        scelti = []
        for voce in elenco.selectedItems():
            lyr = self.project.mapLayer(voce.data(Qt.UserRole))
            if isinstance(lyr, QgsVectorLayer):
                scelti.append(lyr)
        return scelti

    def _feature_da_classificare(self, lyr):
        feature = list(lyr.getFeatures())
        if self.chk_su_solo_nuovo.isChecked():
            i = self._indice_campo(lyr, CAMPO_STATO)
            if i >= 0:
                atteso = VAL_NUOVO.lower()
                feature = [f for f in feature
                           if self._valore_testo(f, i).lower() == atteso]
        return feature

    def _trova_fuori_stradario(self):
        """Seleziona in mappa gli elementi che distano dagli stradari più della
        tolleranza. Non modifica nulla: serve al controllo a vista prima dello
        spostamento."""
        stradari = self._layer_scelti(self.lst_su_stradari)
        bersagli = self._layer_scelti(self.lst_su_layer)
        if not stradari:
            QMessageBox.warning(self, "Stradari mancanti",
                "Seleziona almeno uno stradario nel punto 1."); return
        if not bersagli:
            QMessageBox.warning(self, "Livelli mancanti",
                "Seleziona almeno un livello da analizzare nel punto 2."); return

        tolleranza = self.spin_su_tolleranza.value()
        righe = []; self._fuori_stradario = {}
        totale_fuori = 0; totale_esaminati = 0
        estensione = QgsRectangle(); estensione.setMinimal()

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # un solo indice per tutti gli stradari messi insieme: la domanda è
            # "quanto dista dalla rete di competenza dell'ente", non da quale
            # dei suoi livelli
            indice = QgsSpatialIndex()
            geometrie_rete = {}
            contatore = 0
            for rete in stradari:
                for f in rete.getFeatures():
                    g = self._to_proj(f.geometry(), rete)
                    if not g or g.isEmpty():
                        continue
                    contatore += 1
                    geometrie_rete[contatore] = g
                    try:
                        indice.addFeature(contatore, g.boundingBox())
                    except TypeError:
                        copia = QgsFeature()
                        copia.setId(contatore)
                        copia.setGeometry(g)
                        indice.addFeature(copia)
            righe.append(f"Rete di riferimento: {contatore} tratte da "
                         + ", ".join(f"'{r.name()}'" for r in stradari))
            if not geometrie_rete:
                righe.append("Nessuna geometria negli stradari scelti: analisi interrotta.")
                self.log_su.setPlainText("\n".join(righe))
                return

            for lyr in bersagli:
                feature = self._feature_da_classificare(lyr)
                fuori = []
                for f in feature:
                    g = self._to_proj(f.geometry(), lyr)
                    if not g or g.isEmpty():
                        continue
                    totale_esaminati += 1
                    intorno = g.boundingBox()
                    intorno.grow(max(tolleranza, 0.001))
                    vicine = indice.intersects(intorno)
                    distanza = None
                    for fid in vicine:
                        d = geometrie_rete[fid].distance(g)
                        if distanza is None or d < distanza:
                            distanza = d
                        if distanza <= tolleranza:
                            break
                    if distanza is None or distanza > tolleranza:
                        fuori.append(f.id())
                        estensione.combineExtentWith(g.boundingBox())
                lyr.selectByIds(fuori)
                self._fuori_stradario[lyr.id()] = fuori
                totale_fuori += len(fuori)
                righe.append(f"  {lyr.name()}: {len(fuori)} fuori stradario su "
                             f"{len(feature)} esaminati")
        finally:
            QApplication.restoreOverrideCursor()

        if totale_fuori and self.chk_su_zoom.isChecked() and not estensione.isEmpty():
            estensione.grow(max(estensione.width(), estensione.height()) * 0.15 + 20)
            self.iface.mapCanvas().setExtent(estensione)
            self.iface.mapCanvas().refresh()

        righe.insert(0, f"{totale_fuori} elementi fuori dagli stradari dell'ente su "
                        f"{totale_esaminati} esaminati (tolleranza {tolleranza:g} m).")
        righe.append("")
        righe.append("Gli elementi trovati sono ora SELEZIONATI in mappa: controllali a "
                     "vista, poi premi '2. Sposta nel gruppo'. Se la selezione non ti "
                     "torna, ritocca la tolleranza e rilancia l'analisi — finché non "
                     "premi il secondo pulsante non viene modificato nulla.")
        self.log_su.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_su,
                           f"{totale_fuori} elementi fuori stradario, selezionati in mappa.",
                           ok=totale_fuori > 0)

    def _clona_layer(self, originale, nome, filtro):
        """Copia del livello con la stessa sorgente, lo stesso stile e un filtro.

        Si usa clone(), che porta con sé simbologia, etichette e trasparenze: il
        gruppo nuovo deve essere indistinguibile dall'originale a vedersi, e
        ricostruire lo stile a mano significherebbe perderne i dettagli. Sui
        livelli in memoria clone() non porta i dati, perché l'URI di un layer
        temporaneo non li contiene, quindi in quel caso le feature vengono
        copiate una a una."""
        try:
            copia = originale.clone()
        except Exception:
            copia = None
        if copia is None or not copia.isValid():
            return None, "clone del livello non riuscito"
        copia.setName(nome)

        if originale.dataProvider().name() == "memory":
            fids = self._fuori_stradario.get(originale.id(), [])
            copia.dataProvider().truncate()
            da_copiare = [f for f in originale.getFeatures() if f.id() in set(fids)]
            copia.dataProvider().addFeatures(da_copiare)
            copia.updateExtents()
            return copia, "livello temporaneo: feature copiate una a una"

        if not copia.setSubsetString(filtro):
            return copia, f"il filtro '{filtro}' non è stato accettato dal provider"
        return copia, ""

    def _sposta_su_suolo_comunale(self):
        if not getattr(self, "_fuori_stradario", None):
            QMessageBox.warning(self, "Analisi mancante",
                "Premi prima '1. Evidenzia in mappa gli elementi fuori stradario': lo "
                "spostamento agisce su quel risultato."); return
        totale = sum(len(v) for v in self._fuori_stradario.values())
        if not totale:
            QMessageBox.information(self, "Niente da spostare",
                "L'analisi non ha trovato elementi fuori dagli stradari."); return

        nome_gruppo = self.txt_su_gruppo.text().strip() or self.NOME_GRUPPO_COMUNALE
        if QMessageBox.question(
                self, "Conferma lo spostamento",
                f"Sposto {totale} elementi nel gruppo '{nome_gruppo}'.\n\n"
                f"Sui livelli originali verrà scritto il campo "
                f"'{self.CAMPO_SUOLO}' e applicato un filtro che nasconde gli elementi "
                f"spostati. Nessuna geometria viene cancellata e l'operazione è "
                f"annullabile.\n\nProcedo?",
                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return

        righe = []; spostati = 0
        filtro_comunale = f'"{self.CAMPO_SUOLO}" = \'{self.VAL_COMUNALE}\''
        filtro_ente = (f'"{self.CAMPO_SUOLO}" IS NULL OR "{self.CAMPO_SUOLO}" <> '
                       f"'{self.VAL_COMUNALE}'")

        self._annulla_suolo_comunale(silenzioso=True)
        radice = self.project.layerTreeRoot()
        gruppo = radice.insertGroup(0, nome_gruppo)

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            for lyr_id, fids in self._fuori_stradario.items():
                lyr = self.project.mapLayer(lyr_id)
                if lyr is None:
                    continue
                righe.append(f"── {lyr.name()} ──")
                if not fids:
                    righe.append("  nessun elemento fuori stradario: lasciato invariato.")
                    continue

                # 1) l'attributo che distingue i due suoli
                idx, nome_campo, esito = self._assicura_campo(
                    lyr, self.CAMPO_SUOLO, tipo_testo=True, lunghezza=20)
                if esito.startswith("fallito"):
                    righe.append(f"  campo '{self.CAMPO_SUOLO}': {esito[8:].strip()}. "
                                 "Livello saltato.")
                    continue
                if not self._start_edit(lyr):
                    righe.append("  impossibile avviare la modifica: livello saltato.")
                    continue
                insieme = set(fids)
                scritte = 0
                for f in self._feature_da_classificare(lyr):
                    valore = (self.VAL_COMUNALE if f.id() in insieme
                              else self.VAL_ALTRO_ENTE)
                    if lyr.changeAttributeValue(f.id(), idx, valore):
                        scritte += 1
                if not self._commit(lyr, f"Classificazione suolo su {lyr.name()}"):
                    righe.append("  SALVATAGGIO ANNULLATO: livello saltato.")
                    continue
                righe.append(f"  campo '{nome_campo}' {esito}, {scritte} valori scritti.")

                # 2) il clone filtrato nel gruppo nuovo
                copia, avviso = self._clona_layer(
                    lyr, f"{lyr.name()} — suolo comunale", filtro_comunale)
                if copia is None:
                    righe.append(f"  {avviso}: livello non aggiunto al gruppo.")
                    continue
                self.project.addMapLayer(copia, False)
                gruppo.addLayer(copia)
                if avviso:
                    righe.append(f"  {avviso}")

                # 3) il filtro complementare sull'originale
                if lyr.dataProvider().name() != "memory":
                    if lyr.setSubsetString(filtro_ente):
                        righe.append(f"  filtro applicato all'originale: nasconde i "
                                     f"{len(fids)} elementi spostati.")
                    else:
                        righe.append("  ATTENZIONE: il provider ha rifiutato il filtro "
                                     "sull'originale, quindi gli elementi restano "
                                     "visibili anche qui.")
                else:
                    righe.append("  livello temporaneo: l'originale non è stato filtrato.")
                spostati += len(fids)
        finally:
            QApplication.restoreOverrideCursor()

        gruppo.setItemVisibilityChecked(True)
        self.iface.mapCanvas().refresh()
        intestazione = (f"{spostati} elementi spostati nel gruppo '{nome_gruppo}'. "
                        "Spegni il gruppo per togliere dalla tavola gli elementi su "
                        "suolo comunale.")
        righe.insert(0, intestazione)
        righe.append("")
        righe.append("Per annullare: pulsante 'Annulla lo spostamento'. Nessuna geometria "
                     "è stata cancellata — gli elementi sono ancora tutti nei livelli "
                     "originali, semplicemente filtrati.")
        self.log_su.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_su, intestazione, ok=spostati > 0)

    def _annulla_suolo_comunale(self, silenzioso=False):
        """Toglie il gruppo e azzera i filtri, riportando i livelli come erano."""
        nome_gruppo = self.txt_su_gruppo.text().strip() or self.NOME_GRUPPO_COMUNALE
        rimossi = 0; sfiltrati = 0
        radice = self.project.layerTreeRoot()
        gruppo = radice.findGroup(nome_gruppo)
        if gruppo is not None:
            for nodo in list(gruppo.findLayers()):
                if nodo.layer() is not None:
                    self.project.removeMapLayer(nodo.layer().id())
                    rimossi += 1
            radice.removeChildNode(gruppo)

        marcatore = f'"{self.CAMPO_SUOLO}"'
        for lyr in self.project.mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            try:
                if marcatore in (lyr.subsetString() or ""):
                    lyr.setSubsetString("")
                    sfiltrati += 1
            except Exception:
                continue
        self.iface.mapCanvas().refresh()

        if silenzioso:
            return
        messaggio = (f"Gruppo rimosso ({rimossi} livelli), filtro azzerato su "
                     f"{sfiltrati} livelli originali.")
        self.log_su.setPlainText(
            messaggio + "\n\nIl campo " + self.CAMPO_SUOLO + " resta scritto negli "
            "attributi, ma non filtra più nulla: puoi rilanciare l'analisi da zero.")
        self._mostra_stato(self.stato_su, messaggio)

    # ═══════════════════════════════════════════════════════ GUIDA
    # una voce per scheda: titolo e testo in HTML. Tenuta qui e non in un file
    # esterno perché deve viaggiare col plugin senza dipendere da percorsi.
    GUIDE = {
        "pulizia": ("Seleziona elementi", """
<h3>A cosa serve</h3>
<p>Seleziona in mappa gli elementi di rete da mettere a permesso, applicando
le regole una dopo l'altra: quello che resta selezionato è ciò che finirà
nella pratica.</p>
<h3>Come si usa</h3>
<ol>
<li>Imposta i layer nei campi in cima: sono quelli su cui lavorano tutte le
regole della scheda.</li>
<li>Attiva le regole che ti servono e premi il pulsante di ciascuna. Ogni
regola lavora <b>sulla selezione corrente</b>, quindi l'ordine conta.</li>
<li>Controlla il conteggio nel log dopo ogni passo: se una regola seleziona
zero elementi, il problema è quasi sempre un layer sbagliato o una
tolleranza troppo stretta, non la regola.</li>
</ol>
<h3>Attenzione</h3>
<p>Le regole non modificano i dati, cambiano solo la selezione. Puoi rilanciarle
quante volte vuoi senza rischi.</p>
"""),
        "allinea": ("Allinea cartografia", """
<h3>A cosa serve</h3>
<p>Sposta e ruota la cartografia di appoggio per farla combaciare con la base
di riferimento, quando le due non sono sovrapposte.</p>
<h3>Come si usa</h3>
<ol>
<li>Scegli il layer da spostare e quello di riferimento.</li>
<li>Indica le coppie di punti corrispondenti con i pulsanti di raccolta dal
canvas: clicca prima sul punto della cartografia da spostare, poi su quello
corrispondente del riferimento.</li>
<li>Applica la trasformazione e verifica a vista; se non torna, aggiungi una
coppia di punti invece di correggere a mano.</li>
</ol>
"""),
        "keyplan": ("Keyplan e tavole", """
<h3>A cosa serve</h3>
<p>Genera automaticamente la copertura delle tavole di inquadramento sulla rete
selezionata, senza sovrapposizioni, e il keyplan d'insieme.</p>
<h3>Come si usa</h3>
<ol>
<li>Prepara la selezione nella scheda <i>Seleziona elementi</i>: le tavole
vengono costruite su ciò che è selezionato.</li>
<li>Imposta scala e formato: da questi due dipende quanta rete entra in una
tavola, quindi quante tavole otterrai.</li>
<li>Genera. Per rifare solo una zona, usa la rigenerazione mirata invece di
ricostruire tutto: le tavole già approvate restano come sono.</li>
</ol>
"""),
        "coni": ("Punti di ripresa", """
<h3>A cosa serve</h3>
<p>Crea i punti di ripresa fotografica davanti agli Armadi Ottici e sugli
attraversamenti, con il cono di inquadratura orientato correttamente.</p>
<h3>Come si usa</h3>
<ol>
<li>Imposta Armadio Ottico, Punto di Ripresa e Stradario, più le distanze di
ripresa.</li>
<li>Genera i coni. La camera viene arretrata lungo la strada e l'inquadratura
orientata verso il soggetto.</li>
<li>Sugli attraversamenti il soggetto è già sulla strada: in quel caso la
camera viene spostata lungo la strada stessa e l'inquadratura forzata
perpendicolare, che è la foto che serve in pratica.</li>
</ol>
"""),
        "chilometriche": ("Chilometriche", """
<h3>A cosa serve</h3>
<p>Scrive la progressiva chilometrica su pozzetti, armadi e tratte, misurandola
lungo la strada a partire dai cippi.</p>
<h3>Come si usa</h3>
<ol>
<li><b>Passo 1 — crea il campo.</b> Seleziona nel pannello Livelli gli shape su
cui ti serve e premi il pulsante. Sugli shapefile il nome viene accorciato a
10 caratteri, quindi <i>Chilometrica</i> diventa <i>Chilometri</i>: è normale
e il plugin riconosce entrambe le forme.</li>
<li><b>Passo 2 — i cippi.</b> Scegli il layer dei cippi e il campo che contiene
il valore. Il formato va dichiarato: <i>17+100</i> è km 17 più 100 metri; se
hai digitato prima i metri (<i>100+17</i>) scegli la voce INVERTITO.</li>
<li><b>Passo 3 — calcola.</b> Scegli la linea di riferimento, il layer target e
il campo di output, poi seleziona in mappa gli elementi e calcola.</li>
</ol>
<h3>Come conta</h3>
<p>Uno stradario è spezzato in centinaia di tratte: il plugin le ricuce prima in
<b>corridoi continui</b>, poi misura tutto lungo quelli. La chilometrica di un
elemento è il valore del cippo più basso più la distanza reale percorsa sulla
strada, un metro per un metro, nel verso in cui i km crescono. Gli altri cippi
non spostano il conteggio: servono da controverifica, e il log segnala se uno
di essi non sta dove la progressione lo colloca.</p>
<h3>Se non calcola</h3>
<p>Premi <b>Diagnostica</b> prima di cambiare i parametri a caso: dice quanti
cippi ha letto e quali ha scartato, quanti corridoi ha ricucito, quali elementi
non si agganciano e a che distanza stanno. Le due cause più frequenti sono la
tolleranza troppo stretta e un formato del cippo dichiarato male.</p>
"""),
        "etichette": ("Etichette", """
<h3>A cosa serve</h3>
<p>Compila un campo di testo su Armadio, Pozzetto e Infrastrutture con la
dicitura di posa da stampare in tavola, e attiva l'etichettatura in mappa.</p>
<h3>Come si usa</h3>
<ol>
<li><b>Passo 1</b> — i tre layer e il nome del campo da scrivere.</li>
<li><b>Passo 2</b> — la dicitura di ciascun layer e il campo che la completa.
Se non sai quale campo contiene la tecnica di scavo, premi <b>Ispeziona i
campi</b>: elenca ogni campo con alcuni valori di esempio.</li>
<li><b>Passo 3</b> — quali elementi elaborare.</li>
<li><b>Passo 4</b> — la resa in mappa.</li>
<li>Premi <b>Anteprima</b> prima di scrivere: mostra le etichette che
otterresti senza toccare i dati.</li>
</ol>
<h3>Leggibilità sullo sfondo</h3>
<p>Su una CTR il testo nero cade su un intreccio di linee nere e l'alone da solo
non basta, perché il tratteggio continua a leggersi dentro le lettere. Il
riquadro bianco semitrasparente è la scelta delle tavole professionali: stacca
il testo da qualunque sfondo restando discreto.</p>
<h3>Attenzione</h3>
<p>QGIS ammette una sola etichettatura per layer: assegnandone una nuova, quella
che c'era viene cancellata. Se sul layer hai già un'etichetta che vuoi tenere,
spunta <i>Conserva l'etichettatura già presente</i>: la vecchia viene convertita
in regola e la nuova si aggiunge come seconda regola.</p>
"""),
        "suolo": ("Suolo comunale", """
<h3>A cosa serve</h3>
<p>Separare gli elementi che non ricadono sugli stradari dell'ente da quelli che
vi ricadono, per poterli spegnere quando si stampa la tavola per quell'ente.</p>
<h3>Come si usa</h3>
<ol>
<li>Scegli gli stradari di competenza dell'ente (SP, ANAS, altro): possono essere
più di uno, si tengono premuti Ctrl e si clicca.</li>
<li>Scegli i livelli da analizzare e la distanza massima dall'asse oltre la quale
un elemento è considerato fuori.</li>
<li>Premi <b>1. Evidenzia</b>: gli elementi fuori vengono <b>selezionati in
mappa</b> e la vista si porta su di loro. Controllali a vista. Se la selezione
non torna, ritocca la tolleranza e rilancia: finché non premi il secondo
pulsante non viene modificato niente.</li>
<li>Premi <b>2. Sposta nel gruppo</b> per confermare.</li>
</ol>
<h3>Cosa fa lo spostamento</h3>
<p>Non cancella e non duplica geometrie. Scrive un campo <b>SUOLO</b> che
distingue i due casi, crea un gruppo di livelli filtrati sul valore
<i>COMUNALE</i> e applica il filtro complementare agli originali. I livelli del
gruppo nuovo sono cloni di quelli originali, quindi hanno la stessa sorgente e
<b>la stessa simbologia</b>: a vedersi sono identici.</p>
<p>A questo punto basta spegnere il gruppo per togliere dalla tavola gli elementi
su suolo comunale.</p>
<h3>Annullare</h3>
<p>Il terzo pulsante rimuove il gruppo e azzera i filtri. Il campo SUOLO resta
scritto negli attributi ma non filtra più nulla, quindi si può rifare l'analisi
da zero. Nessuna geometria è mai stata cancellata.</p>
<h3>Attenzione</h3>
<p>Sui livelli temporanei (in memoria) il filtro non è applicabile: in quel caso
le feature vengono copiate nel gruppo nuovo e l'originale resta intero. Il log lo
segnala.</p>
"""),
        "consegna": ("Esportazione", """
<h3>A cosa serve</h3>
<p>Tre cose distinte: generare gli shape di consegna, esportare i PDF dei layout
e unirli, ed evidenziare in tavola le strade interessate dai lavori.</p>
<h3>Shape di consegna</h3>
<p>Imposta i layer e la cartella di destinazione: i tre shape vengono generati
con i campi lunghezza aggiornati.</p>
<h3>Esportazione PDF</h3>
<p>Aggiorna l'elenco dei layout, seleziona quelli da esportare e lancia. I PDF
prodotti finiscono nell'elenco di unione, dove puoi riordinarli e fonderli in
un unico file.</p>
<h3>Evidenza delle strade</h3>
<p>Copre con un retino le tratte dello stradario su cui ricadono gli elementi di
progetto. Il layer prodotto è <b>temporaneo</b>: se ti serve nella tavola
stampata, clic destro sul layer e <i>Rendi permanente</i> prima di chiudere il
progetto.</p>
<p>Se il retino risulta interrotto, la causa quasi sempre è la
<i>Distanza max elemento → tratta</i>: gli scavi corrono a bordo strada mentre
lo stradario è l'asse, quindi su una carreggiata di 8-10 metri il bordo dista
4-5 metri dall'asse. Il log elenca gli elementi rimasti fuori e la loro
distanza reale: alza quel valore oltre il massimo indicato. In seconda battuta
agisci su <i>Colma i vuoti fino a</i>.</p>
"""),
    }

    def _mostra_guida(self, chiave):
        """Apre la guida della scheda in una finestra a sé, non modale, così
        si può continuare a lavorare con la guida aperta accanto."""
        titolo, corpo = self.GUIDE.get(chiave, ("Guida", "<p>Guida non disponibile.</p>"))
        finestra = QDialog(self)
        finestra.setWindowTitle(f"Guida — {titolo}")
        finestra.setMinimumSize(560, 520)
        v = QVBoxLayout(finestra)
        testo = QTextBrowser()
        testo.setOpenExternalLinks(True)
        testo.setHtml(f"<h2>{titolo}</h2>{corpo}")
        v.addWidget(testo)
        riga = QHBoxLayout()
        riga.addStretch()
        chiudi = QPushButton("Chiudi")
        chiudi.clicked.connect(finestra.close)
        riga.addWidget(chiudi)
        v.addLayout(riga)
        finestra.show()
        self._guide_aperte.append(finestra)  # riferimento: senza, il GC la chiude

    # ═══════════════════════════════════════════════ KEYPLAN – LOGICA
    def _messaggio_estensione_vuota(self):
        """Messaggio specifico (non generico) sul perché l'estensione
        risulta vuota, mostrato direttamente nel popup di errore invece di
        richiedere un secondo click su 'Diagnostica estensione'."""
        lyr = self.cb_kp_arlo.currentLayer()
        if not lyr:
            return ("Imposta il layer ARLO AREA (il poligono con tutte le aree\n"
                    "armadio da coprire): è l'unico layer usato per calcolare\n"
                    "l'estensione della griglia.")
        tot = lyr.featureCount()
        if tot == 0:
            return f"Il layer ARLO AREA scelto ('{lyr.name()}') non contiene nessuna feature."
        return (f"Il layer ARLO AREA scelto ('{lyr.name()}') ha {tot} feature, ma\n"
                "nessuna ha fornito una geometria valida (vuota, o non\n"
                "trasformabile nel CRS di progetto). Usa 'Diagnostica estensione'\n"
                "qui sotto per i dettagli, e controlla il CRS del layer.")

    def _diagnostica_estensione(self):
        """Mostra quante feature del layer ARLO AREA contribuiscono
        all'estensione (e quante vengono escluse per geometria nulla o per
        un errore di trasformazione CRS), oltre a quante parti separate ha
        la forma reale una volta fusa e quanto il suo bounding box la
        sovrastima — per capire subito il motivo di un'area vuota, più
        piccola del previsto, o (se il bbox è molto più grande dell'area
        reale) perché conviene la copertura 'a forma libera' invece che a
        griglia rettangolare."""
        lyr = self.cb_kp_arlo.currentLayer()
        righe = []
        if not lyr:
            righe.append("ARLO AREA: nessun layer impostato.")
        else:
            tot = lyr.featureCount()
            n_validi = 0; ext = None
            crs_prima = getattr(self, "_crs_errors", 0)
            for f in lyr.getFeatures():
                g = self._to_proj(f.geometry(), lyr)
                if not g or g.isEmpty(): continue
                n_validi += 1
                bb = g.boundingBox()
                ext = bb if ext is None else ext.combineExtentWith(bb)
            n_crs_err = getattr(self, "_crs_errors", 0) - crs_prima
            righe.append(f"ARLO AREA ('{lyr.name()}'): {n_validi} di {tot} feature usate.")
            if n_crs_err:
                righe.append(f"  → {n_crs_err} feature scartate per errore di trasformazione CRS (vedi console QGIS).")
            if tot and not n_validi:
                righe.append("  → tutte le feature hanno geometria nulla/vuota o non trasformabile:\n    controlla il CRS del layer rispetto a quello del progetto.")
            if ext:
                righe.append(f"Bounding box di tutte le feature: {ext.width():.0f} × {ext.height():.0f} m  —  {ext.toString(2)}")
                forma = self._dissolvi_arlo()
                if forma:
                    parti = self._parti_poligono(forma)
                    area_bbox = ext.width() * ext.height()
                    area_forma = forma.area()
                    righe.append(f"Forma reale fusa (quella usata per la copertura): area ≈{area_forma:.0f} m², {len(parti)} parte/i.")
                    if area_forma > 0:
                        rapporto = area_bbox / area_forma
                        righe.append(f"Il bounding box è ≈{rapporto:.1f}× più grande dell'area reale "
                                     f"({'molto sparsa/irregolare: bene usare la copertura a forma libera' if rapporto > 1.5 else 'abbastanza compatta'}).")
            else:
                righe.append("Estensione risultante: VUOTA.")
        msg = "\n".join(righe)
        self.log_kp.setPlainText(msg)
        QMessageBox.information(self, "Diagnostica estensione", msg)

    def _template_kp(self, kp_lyr):
        """Ritorna (feature, geometria in CRS di progetto) da usare come
        MODELLO di tavola dal layer Keyplan: la feature selezionata se ce n'è
        esattamente una, altrimenti la prima feature del layer. None se il
        layer non contiene nessuna geometria da cui prendere forma/dimensione."""
        if not kp_lyr: return None
        sel = list(kp_lyr.selectedFeatures())
        feats = sel if len(sel) == 1 else list(kp_lyr.getFeatures())
        if not feats: return None
        f = feats[0]
        g = self._to_proj(f.geometry(), kp_lyr)
        if not g or g.isEmpty(): return None
        return f, g

    def _dissolvi_arlo(self):
        """Fonde (unaryUnion) TUTTE le feature del layer ARLO AREA in
        un'unica geometria, anche multi-parte se le aree non sono
        adiacenti. È la vera FORMA usata per decidere dove mettere le
        tavole — non il suo bounding box: un layer con più aree armadio
        sparse produce un bbox che include anche il vuoto tra una zona e
        l'altra, mentre la forma fusa segue il contorno reale."""
        lyr = self.cb_kp_arlo.currentLayer()
        if not lyr: return None
        geoms = []
        for f in lyr.getFeatures():
            g = self._to_proj(f.geometry(), lyr)
            if g and not g.isEmpty():
                geoms.append(g)
        if not geoms: return None
        fusa = QgsGeometry.unaryUnion(geoms)
        if not fusa or fusa.isEmpty(): return None
        return fusa

    @staticmethod
    def _parti_poligono(geom):
        """Lista di QgsGeometry poligonali, una per ciascuna parte di
        `geom` (gestisce sia Polygon sia MultiPolygon); parti vuote
        scartate. Serve per lavorare parte-per-parte quando la forma da
        coprire non è un unico blocco continuo."""
        if geom is None or geom.isEmpty():
            return []
        base = QgsWkbTypes.flatType(geom.wkbType())
        if base == QgsWkbTypes.MultiPolygon:
            return [QgsGeometry.fromPolygonXY(poly) for poly in geom.asMultiPolygon() if poly]
        if base == QgsWkbTypes.Polygon:
            return [geom]
        try:
            mp = geom.asMultiPolygon()
            return [QgsGeometry.fromPolygonXY(poly) for poly in mp if poly]
        except Exception:
            return [geom]

    def _copertura_adattiva(self, dims, regione, overlap, vieta_sovrapposizione=False, soglia_residua=None):
        """Copre `regione` (una forma qualsiasi, NON un rettangolo) con
        tavole di dimensione fissa — una o due varianti in `dims`, lista di
        (nome, tw, th) — posizionate LIBERAMENTE invece che su una griglia
        globale: come mettere delle toppe sui buchi di un tessuto, invece
        di stendere un lenzuolo rigido sopra tutto (e tagliarne via i
        pezzi che avanzano fuori).
        Ad ogni passo: individua il 'buco' scoperto più grande rimasto
        (componente connessa), prende un punto al suo interno
        (pointOnSurface, sempre dentro anche per forme concave) SOLO per
        decidere DOVE guardare, poi valuta ogni posizione candidata
        contro TUTTO lo scoperto rimasto (non solo quella componente
        connessa): elementi vicini ma non tecnicamente a contatto (es. due
        Tavole di inquadramento con un piccolo spazio tra loro, o due
        gruppi di Infrastrutture/Pozzetto Nuovi non proprio adiacenti)
        sono componenti connesse SEPARATE, e valutare solo la componente
        del punto scelto le ignorerebbe anche se cadono comodamente nella
        stessa tavola — risultato: un Keyplan che non contiene per intero
        le Tavole di inquadramento vicine che dovrebbe raccogliere. Le
        posizioni candidate sono la griglia 5×5 di sempre (il punto può
        cadere su vari bordi/angoli/centro della tavola) PIÙ una posizione
        centrata sul baricentro di tutto il contenuto scoperto che
        cadrebbe in una finestra grande quanto la tavola attorno al punto:
        così la tavola risulta centrata su quello che deve inquadrare,
        non ancorata per un angolo come capitava prima.

        Se `vieta_sovrapposizione` è False (tavole di inquadramento): sottrae
        la tavola scelta (leggermente rimpicciolita dell'overlap, per
        lasciare la sovrapposizione voluta con le tavole vicine) dal 'buco'
        rimasto, e ripete — le tavole POSSONO sovrapporsi del margine
        richiesto.

        Se `vieta_sovrapposizione` è True (Keyplan): ogni candidato viene
        scartato se si sovrappone (oltre una tolleranza numerica minima) a
        una tavola già posizionata, tenendo traccia dell'unione di tutte le
        tavole piazzate finora ('occupato'). `overlap` diventa in questo
        caso un gap di sicurezza (la tavola viene rimpicciolita di
        `overlap` PRIMA di essere piazzata, così non solo non si sovrappone
        ma resta pure staccata delle tavole vicine). Dove nessuna posizione
        libera da sovrapposizioni copre il punto scelto, quel punto viene
        scartato (piccolo buco lasciato scoperto) invece di forzare una
        sovrapposizione.

        Ritorna (tessere, area_residua) dove tessere è [(geom, 'A'|'B'), …]
        e area_residua è l'area (m²) troppo piccola/frastagliata (o troppo
        stretta per stare senza sovrapporsi, in modalità Keyplan) per
        giustificare un'altra tavola intera.

        `soglia_residua`, se indicata, sostituisce la soglia di default (2%
        dell'area della tavola più piccola): quella di default va bene per
        coprire un'area PIENA (ARLO AREA), dove un ritaglio residuo pari a
        una piccola frazione di una tavola è normale da ignorare. Per
        coprire invece un target SOTTILE (es. un corridoio stretto attorno
        a un tratto di infrastruttura), quella soglia sarebbe troppo alta
        rispetto all'area totale disponibile e farebbe fermare la copertura
        dopo una o due tavole: in quel caso va passata una soglia assoluta
        piccola (es. mezzo metro quadro)."""
        if regione is None or regione.isEmpty(): return [], 0.0
        scoperto = QgsGeometry(regione)
        tile_area_min = min(tw * th for _, tw, th in dims)
        tile_dim_min = min(min(tw, th) for _, tw, th in dims)
        if soglia_residua is None:
            soglia_residua = max(1.0, 0.02 * tile_area_min)
        eps_sovrapp = max(1e-4, 1e-6 * tile_area_min)  # tolleranza per rumore numerico, non vera sovrapposizione
        max_tavole = 3000
        # Sicurezza anti-loop quando lo spazio residuo è troppo frastagliato
        # per piazzare altre tavole senza sovrapposizioni (tipico di un
        # target STRETTO come un corridoio attorno all'infrastruttura, dove
        # capita spesso). Deve essere ALTO: ogni fallimento scarta solo un
        # piccolo intorno del punto corrente e passa oltre, quindi un
        # target con molte zone strette (curve, incroci) ha bisogno di
        # MOLTI fallimenti "locali" per essere ripulito del tutto — con un
        # tetto basso l'intero ciclo si fermava subito lasciando scoperte
        # anche zone facili mai nemmeno provate, oltre a quella difficile.
        max_fallimenti = 4000
        tessere = []
        occupato = None  # unione delle tavole già piazzate, usata solo in modalità vieta_sovrapposizione
        fallimenti = 0
        while scoperto.area() > soglia_residua and len(tessere) < max_tavole and fallimenti < max_fallimenti:
            parti = self._parti_poligono(scoperto)
            if not parti: break
            parte = max(parti, key=lambda g: g.area())
            if parte.area() <= soglia_residua: break
            p = parte.pointOnSurface()
            if not p or p.isEmpty(): break
            pt = p.asPoint()
            px, py = pt.x(), pt.y()

            migliore = None  # (score, rect, nome, tw, th)
            for nome, tw, th in dims:
                # Oltre alla griglia 5×5 (angoli/bordi/centro ancorati al
                # punto interno del buco), si prova UNA posizione in più:
                # la tavola centrata sul baricentro di TUTTO lo scoperto
                # (non solo 'parte') che cadrebbe in una finestra grande
                # quanto la tavola attorno al punto — così raccoglie anche
                # elementi vicini ma non a contatto diretto col punto
                # scelto, invece di ignorarli.
                candidati_xy = [(px - fx*tw, py - fy*th) for fx in (0.0, 0.25, 0.5, 0.75, 1.0) for fy in (0.0, 0.25, 0.5, 0.75, 1.0)]
                finestra = QgsGeometry.fromRect(QgsRectangle(px - tw/2.0, py - th/2.0, px + tw/2.0, py + th/2.0))
                contenuto_locale = finestra.intersection(scoperto)
                centrato_xy = None
                if contenuto_locale and not contenuto_locale.isEmpty():
                    centro_reale = contenuto_locale.centroid()
                    if not centro_reale or centro_reale.isEmpty():
                        centro_reale = contenuto_locale.pointOnSurface()
                    if centro_reale and not centro_reale.isEmpty():
                        cp = centro_reale.asPoint()
                        centrato_xy = (cp.x() - tw/2.0, cp.y() - th/2.0)
                        candidati_xy.append(centrato_xy)
                for x0, y0 in candidati_xy:
                    rect = QgsGeometry.fromRect(QgsRectangle(x0, y0, x0 + tw, y0 + th))
                    if vieta_sovrapposizione and occupato is not None:
                        sovr = rect.intersection(occupato)
                        if sovr and not sovr.isEmpty() and sovr.area() > eps_sovrapp:
                            continue  # scartata: si sovrapporrebbe a una tavola già piazzata
                    inter = rect.intersection(scoperto)
                    score = 0.0 if not inter or inter.isEmpty() else inter.area()
                    if score <= 0: continue
                    if migliore is None or score > migliore[0]:
                        migliore = (score, rect, nome, tw, th)
            if migliore is None:
                if vieta_sovrapposizione:
                    # Nessuna posizione libera da sovrapposizioni copre questo punto
                    # (spazio residuo troppo stretto): si scarta un intorno del
                    # punto e si passa al prossimo, invece di forzare una
                    # sovrapposizione o interrompere subito la copertura. Il
                    # raggio scartato è una FRAZIONE della tavola più piccola
                    # (non della soglia_residua, che per un target stretto è
                    # volutamente minuscola): un raggio troppo piccolo lascia
                    # praticamente invariata l'area del punto più problematico,
                    # che resta il 'buco' più grande e viene riprovato subito
                    # dopo — bruciando tutto il budget di fallimenti su UN
                    # solo punto ostico invece di liberare anche il resto del
                    # target, mai nemmeno tentato.
                    raggio = max(0.15, tile_dim_min / 8.0)
                    buco = QgsGeometry.fromPointXY(pt).buffer(raggio, 8)
                    nuovo_scoperto = scoperto.difference(buco) if buco and not buco.isEmpty() else None
                    fallimenti += 1
                    if nuovo_scoperto is None or nuovo_scoperto.isEmpty():
                        break
                    scoperto = nuovo_scoperto
                    continue
                break  # sicurezza: non dovrebbe succedere dato che (px,py) è dentro 'parte'
            _, rect, nome, tw, th = migliore

            if vieta_sovrapposizione:
                gap = min(overlap, min(tw, th) / 4.0) if overlap > 0 else 0.0
                tile_piazzata = rect.buffer(-gap, 5) if gap > 0 else rect
                if not tile_piazzata or tile_piazzata.isEmpty():
                    tile_piazzata = rect
                tessere.append((tile_piazzata, nome))
                occupato = tile_piazzata if occupato is None else occupato.combine(tile_piazzata)
                tile_sottrai = rect  # tolto per intero dallo scoperto: qui non deve più finire un'altra tavola
            else:
                tessere.append((rect, nome))
                shrink = min(overlap, min(tw, th) / 4.0) if overlap > 0 else 0.0
                tile_sottrai = rect.buffer(-shrink, 5) if shrink > 0 else rect
                if not tile_sottrai or tile_sottrai.isEmpty():
                    tile_sottrai = rect

            nuovo_scoperto = scoperto.difference(tile_sottrai)
            if nuovo_scoperto is None:
                break
            scoperto = nuovo_scoperto

        return tessere, (scoperto.area() if scoperto else 0.0)

    def _pota_tavole_ridondanti(self, tessere, soglia_area=None):
        """Rimuove le tavole quasi del tutto ridondanti (già coperte dalle
        vicine per almeno tutta tranne una briciola di area) per ridurre il
        numero di tavole utili finali, SENZA mai lasciare scoperto un punto
        che prima era coperto: una tavola viene tolta solo se il suo
        contributo 'privato' (l'area che copre lei sola, non coperta da
        nessun'altra tavola) è sotto `soglia_area`. Lavora con un indice
        spaziale per restare veloce anche con centinaia di tavole. Ritorna
        una nuova lista [(geom, sorgente), …]."""
        n = len(tessere)
        if n <= 1: return tessere
        if soglia_area is None:
            aree = [g.area() for g, _ in tessere]
            soglia_area = max(1.0, 0.02 * min(aree))

        idx = QgsSpatialIndex()
        feats = []
        for i, (g, _s) in enumerate(tessere):
            f = QgsFeature(i); f.setGeometry(g)
            feats.append(f); idx.addFeature(f)

        tenute = list(range(n))  # indici delle tavole ancora presenti
        tenute_set = set(tenute)
        cambiato = True
        while cambiato and len(tenute_set) > 1:
            cambiato = False
            # dalla più piccola: le tavole piccole sono le prime candidate a essere ridondanti
            for i in sorted(tenute_set, key=lambda i: tessere[i][0].area()):
                g_i = tessere[i][0]
                vicini_bbox = idx.intersects(g_i.boundingBox())
                altre = [tessere[j][0] for j in vicini_bbox if j != i and j in tenute_set]
                if not altre:
                    continue
                unione_altre = QgsGeometry.unaryUnion(altre)
                if unione_altre is None or unione_altre.isEmpty():
                    continue
                privato = g_i.difference(unione_altre)
                area_privata = 0.0 if (not privato or privato.isEmpty()) else privato.area()
                if area_privata <= soglia_area:
                    tenute_set.discard(i)
                    cambiato = True

        return [tessere[i] for i in sorted(tenute_set)]

    def _posiziona_keyplan(self):
        """Copre la forma di ARLO AREA (fusa in un'unica geometria, non il
        suo bounding box) con tavole Keyplan — modello A e, se impostato,
        modello alternativo B — posizionate liberamente per seguire il
        contorno reale invece di riempire un rettangolo. Nessun
        collegamento a layout di stampa: agisce solo sulla geometria del
        layer generato. Se è impostato un layer di Tavole di Inquadramento
        (campo sopra), la copertura ignora ARLO AREA e copre SOLO
        l'impronta di quelle tavole."""
        tavole_lyr = self.cb_kp_tavole.currentLayer()
        if tavole_lyr:
            geoms_ti = []
            for f in tavole_lyr.getFeatures():
                g = self._to_proj(f.geometry(), tavole_lyr)
                if g and not g.isEmpty(): geoms_ti.append(g)
            if not geoms_ti:
                QMessageBox.warning(self, "Tavole vuote", f"Il layer '{tavole_lyr.name()}' impostato come Tavole di Inquadramento non ha geometrie valide."); return
            forma = QgsGeometry.unaryUnion(geoms_ti)
            if not forma or forma.isEmpty():
                QMessageBox.warning(self, "Tavole vuote", "L'unione delle Tavole di Inquadramento è risultata vuota."); return
            nome_target = f"Tavole di Inquadramento ('{tavole_lyr.name()}')"
        else:
            forma = self._dissolvi_arlo()
            if not forma:
                QMessageBox.warning(self, "Area vuota", self._messaggio_estensione_vuota()); return
            forma = forma.buffer(self.spin_margine.value(), 8)
            nome_target = "ARLO AREA"
        kp_lyr = self.cb_kp_keyplan.currentLayer()
        if not kp_lyr:
            QMessageBox.warning(self, "Layer mancante", "Seleziona almeno il layer Keyplan modello A."); return

        tmpl_a = self._template_kp(kp_lyr)
        if not tmpl_a:
            QMessageBox.warning(
                self, "Layer vuoto",
                "Il layer Keyplan modello A non contiene nessuna geometria modello.\n"
                "Aggiungi almeno una tavola (es. da Keyplan_Quadrato.gpkg o\n"
                "Keyplan_Rettangolare.gpkg) da usare come riferimento di\n"
                "forma/dimensione prima di generare la copertura."
            ); return
        f_tmpl_a, g_tmpl_a = tmpl_a
        bb_a = g_tmpl_a.boundingBox()
        if bb_a.width() <= 0 or bb_a.height() <= 0:
            QMessageBox.warning(self, "Geometria modello non valida", "La geometria modello nel layer Keyplan ha estensione nulla."); return
        dims = [('A', bb_a.width(), bb_a.height())]

        kp_lyr2 = self.cb_kp_keyplan2.currentLayer()
        tmpl_b = self._template_kp(kp_lyr2) if kp_lyr2 else None
        f_tmpl_b, g_tmpl_b = tmpl_b if tmpl_b else (None, None)
        if tmpl_b:
            bb_b = g_tmpl_b.boundingBox()
            if bb_b.width() > 0 and bb_b.height() > 0:
                dims.append(('B', bb_b.width(), bb_b.height()))

        tessere, area_residua = self._copertura_adattiva(
            dims, forma, self.spin_kp_gap.value(), vieta_sovrapposizione=True
        )
        if not tessere:
            QMessageBox.warning(self, "Copertura non riuscita", f"Nessuna tavola generata: controlla i modelli Keyplan e {nome_target}."); return

        n_prima = len(tessere)
        tessere = self._pota_tavole_ridondanti(tessere)
        n_potate = n_prima - len(tessere)

        lyr, n_a, n_b = self._scrivi_tessere(
            tessere, kp_lyr.fields(), f_tmpl_a, f_tmpl_b, "Keyplan", "keyplan", kp_lyr.wkbType(),
        )
        msg = (f"Copertura Keyplan generata: {len(tessere)} tavole (A: {n_a}"
               + (f", B: {n_b}" if tmpl_b else "") + f") nel layer '{lyr.name()}'.\n"
               f"Tavole posizionate liberamente seguendo la forma di {nome_target} (non una griglia rettangolare),\n"
               "senza nessuna sovrapposizione tra loro.\n"
               + (f"{n_potate} tavole ridondanti rimosse per ridurre il numero di tavole utili.\n" if n_potate else "")
               + (f"Area residua non coperta (troppo piccola/stretta per un'altra tavola senza sovrapporsi): ≈{area_residua:.0f} m²."
                  if area_residua > 1.0 else "Copertura completa."))
        self.log_kp.setPlainText(msg); QMessageBox.information(self, "OK", msg)

    def _scrivi_tessere(self, tessere, campi_modello, f_tmpl_a, f_tmpl_b, nome_layer, chiave, wkb_type):
        """Crea/rinfresca il layer memory `nome_layer` (chiave `chiave` in
        self._output_layers) e vi scrive le `tessere` [(geom, 'A'|'B'), …],
        copiando gli attributi dal rispettivo modello (A o B). Ritorna
        (layer, n_a, n_b).

        Se lo schema del modello contiene un campo chiamato 'fid' (capita
        spesso: è la colonna chiave primaria che GeoPackage espone anche
        come attributo quando lo si legge come layer), viene escluso dallo
        schema copiato: altrimenti TUTTE le tavole generate erediterebbero
        lo STESSO valore costante di quel campo dall'unica feature modello,
        e salvando su GeoPackage GDAL lo riconosce come chiave primaria —
        con lo stesso valore duplicato su ogni tavola, solo la prima si
        scrive e tutte le altre falliscono con 'UNIQUE constraint failed'."""
        indici_validi = [i for i, f in enumerate(campi_modello) if f.name().strip().lower() != "fid"]
        campi_filtrati = [campi_modello[i] for i in indici_validi]

        lyr = self._crea_layer_output(nome_layer, QgsWkbTypes.displayString(wkb_type), campi_filtrati, chiave)
        attrs_a_full = list(f_tmpl_a.attributes())
        attrs_b_full = list(f_tmpl_b.attributes()) if f_tmpl_b else attrs_a_full
        attrs_a = [attrs_a_full[i] for i in indici_validi]
        attrs_b = [attrs_b_full[i] for i in indici_validi]
        feats = []; n_a = n_b = 0
        for g, sorgente in tessere:
            gg = QgsGeometry(g)
            if lyr.crs() != self.project.crs():
                gg.transform(QgsCoordinateTransform(self.project.crs(), lyr.crs(), self.project))
            nf = QgsFeature(lyr.fields())
            nf.setAttributes(list(attrs_a if sorgente == 'A' else attrs_b))
            nf.setGeometry(gg)
            feats.append(nf)
            if sorgente == 'A': n_a += 1
            else: n_b += 1
        lyr.dataProvider().addFeatures(feats)
        lyr.updateExtents(); lyr.triggerRepaint()
        return lyr, n_a, n_b

    def _genera_griglia(self):
        """Genera i riquadri (tavole di inquadramento) che coprono la forma
        di ARLO AREA (fusa in un'unica geometria), posizionati liberamente
        per seguire il contorno reale, in un layer memory dedicato
        ('Poligoni Inquadramento', ricreato ad ogni generazione). Forma e
        dimensione non sono impostabili a mano: derivano dai modelli propri
        impostati sopra (Inquadramento A/B) — se non impostati, per comodità
        vengono riusati i modelli del Keyplan. Nessun collegamento a layout
        di stampa, nessuna scrittura su file."""
        forma = self._dissolvi_arlo()
        if not forma:
            QMessageBox.warning(self, "Area vuota", self._messaggio_estensione_vuota()); return
        forma = forma.buffer(self.spin_margine.value(), 8)

        lyr_a = self.cb_ti_tmpl_a.currentLayer() or self.cb_kp_keyplan.currentLayer()
        tmpl_a = self._template_kp(lyr_a)
        if not tmpl_a:
            QMessageBox.warning(
                self, "Layer modello mancante",
                "Imposta il layer Inquadramento modello A (o, in alternativa,\n"
                "il Keyplan modello A) con almeno una tavola: forma e\n"
                "dimensione dei riquadri derivano sempre da lì."
            ); return
        f_tmpl_a, g_tmpl_a = tmpl_a
        bb_a = g_tmpl_a.boundingBox()
        if bb_a.width() <= 0 or bb_a.height() <= 0:
            QMessageBox.warning(self, "Geometria modello non valida", "La geometria modello Inquadramento ha estensione nulla."); return
        dims = [('A', bb_a.width(), bb_a.height())]

        lyr_b = self.cb_ti_tmpl_b.currentLayer() or (self.cb_kp_keyplan2.currentLayer() if not self.cb_ti_tmpl_a.currentLayer() else None)
        tmpl_b = self._template_kp(lyr_b) if lyr_b else None
        f_tmpl_b, g_tmpl_b = tmpl_b if tmpl_b else (None, None)
        if tmpl_b:
            bb_b = g_tmpl_b.boundingBox()
            if bb_b.width() > 0 and bb_b.height() > 0:
                dims.append(('B', bb_b.width(), bb_b.height()))

        gap = self.spin_ti_gap.value()
        tessere, area_residua = self._copertura_adattiva(dims, forma, gap, vieta_sovrapposizione=True)
        if not tessere:
            QMessageBox.warning(self, "Copertura non riuscita", "Nessuna tavola generata: controlla i modelli Inquadramento e l'area ARLO AREA."); return

        n_prima = len(tessere)
        tessere = self._pota_tavole_ridondanti(tessere)
        n_potate = n_prima - len(tessere)

        lyr, n_a, n_b = self._scrivi_tessere(
            tessere, lyr_a.fields(), f_tmpl_a, f_tmpl_b,
            "Poligoni Inquadramento", "inquadramento", lyr_a.wkbType(),
        )
        msg = [
            f"Copertura generata: {len(tessere)} tavole (A: {n_a}" + (f", B: {n_b}" if tmpl_b else "") + f") nel layer '{lyr.name()}'.",
            "Tavole posizionate liberamente seguendo la forma di ARLO AREA (non una griglia rettangolare), senza nessuna sovrapposizione tra loro.",
        ]
        if n_potate:
            msg.append(f"{n_potate} tavole ridondanti rimosse per ridurre il numero di tavole utili.")
        msg.append(f"Area residua non coperta (troppo piccola/stretta per un'altra tavola senza sovrapporsi): ≈{area_residua:.0f} m²." if area_residua > 1.0 else "Copertura completa.")
        self.log_kp.setPlainText("\n".join(msg))
        QMessageBox.information(self, "OK", f"Copertura generata: {len(tessere)} tavole nel layer '{lyr.name()}'.")

    # ═══════════════════════════════════════════ OTTIMIZZA POSIZIONAMENTO
    def _target_ottimizza_inquadramento(self, raggio):
        """Target per la rigenerazione mirata delle Tavole di inquadramento:
        unione (bufferizzata di `raggio`) delle Infrastrutture STATO='Nuovo'
        (escluse TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL) con il Pozzetto
        STATO='Nuovo'. Confronto tollerante a maiuscole/minuscole e spazi
        (' Aerea ', 'AEREA', 'nuovo'...): un confronto esatto lasciava
        passare tratte Esistenti/Aeree/senza TIPOLOGIA ogni volta che il
        dato non era scritto esattamente 'Nuovo'/'Aerea'. Ritorna
        (geometria o None, messaggio d'errore o None)."""
        infra_lyr = self.cb_kp_infra.currentLayer()
        if not infra_lyr:
            return None, (
                "Imposta il layer Infrastrutture nella sezione 'Rigenera solo sulla "
                "rete' qui sopra (verranno usati i tratti con STATO='Nuovo', escluse "
                f"TIPOLOGIA='{VAL_AEREA}' e TIPOLOGIA vuota/NULL)."
            )
        campo_stato_ok = infra_lyr.fields().indexOf(CAMPO_STATO) >= 0
        campo_tip_ok = infra_lyr.fields().indexOf(CAMPO_TIP_INFRA) >= 0
        val_nuovo_norm = VAL_NUOVO.strip().lower()
        val_aerea_norm = VAL_AEREA.strip().lower()
        parti = []
        for f in infra_lyr.getFeatures():
            if campo_stato_ok:
                st = f[CAMPO_STATO]
                if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                    continue
            if campo_tip_ok:
                tip = f[CAMPO_TIP_INFRA]
                if tip is None or not isinstance(tip, str) or not tip.strip() or tip.strip().lower() == val_aerea_norm:
                    continue
            g = self._to_proj(f.geometry(), infra_lyr)
            if g and not g.isEmpty():
                parti.append(g.buffer(raggio, 8))

        poz_lyr = self.cb_kp_poz.currentLayer()
        if poz_lyr:
            campo_stato_poz_ok = poz_lyr.fields().indexOf(CAMPO_STATO) >= 0
            for f in poz_lyr.getFeatures():
                if campo_stato_poz_ok:
                    st = f[CAMPO_STATO]
                    if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                        continue
                g = self._to_proj(f.geometry(), poz_lyr)
                if g and not g.isEmpty():
                    parti.append(g.buffer(raggio, 8))

        if not parti:
            return None, (
                f"Nessun elemento trovato: verifica che Infrastrutture contenga tratti "
                f"STATO='Nuovo' (escluse TIPOLOGIA='{VAL_AEREA}' e TIPOLOGIA vuota/NULL) "
                "e/o che Pozzetto contenga elementi STATO='Nuovo'."
            )
        target = QgsGeometry.unaryUnion(parti)
        if not target or target.isEmpty():
            return None, "L'unione di Infrastrutture Nuove e Pozzetto Nuovo è risultata vuota."
        return target, None

    def _target_ottimizza_keyplan(self):
        """Target per la rigenerazione mirata del Keyplan: SOLO l'unione
        delle Tavole di inquadramento — che vanno quindi generate PER
        PRIME. Non è più unito all'intero poligono ARLO AREA: un'unione
        con ARLO (in genere molto più esteso della sola rete nuova) faceva
        scegliere all'algoritmo, come 'buco' scoperto più grande da
        riempire, zone di ARLO lontane dalle Tavole di inquadramento, con
        il risultato che il Keyplan finiva piazzato spostato rispetto alle
        tavole invece che sopra di esse. Così il Keyplan copre esattamente
        l'impronta delle Tavole di inquadramento. Il layer delle tavole è
        preso dal campo 'Tavole di Inquadramento' della sezione Keyplan
        qui sopra se impostato (funziona anche con tavole caricate da
        disco in una sessione precedente, non solo generate ora); solo se
        vuoto si ripiega sull'ultimo layer generato in questa sessione.
        Ritorna (geometria o None, messaggio d'errore o None)."""
        lyr_ti = self.cb_kp_tavole.currentLayer() or self._output_layers.get('inquadramento')
        if lyr_ti is None or lyr_ti.id() not in self.project.mapLayers() or lyr_ti.featureCount() == 0:
            return None, (
                "Genera prima la copertura Tavole di inquadramento sulla rete nuova "
                "(pulsante '1' qui sopra), oppure imposta un layer esistente nel campo "
                "'Tavole di Inquadramento' della sezione Keyplan più sopra: il Keyplan "
                "deve coprire quelle tavole, quindi vanno generate/impostate per prime."
            )
        geoms_ti = []
        for f in lyr_ti.getFeatures():
            g = self._to_proj(f.geometry(), lyr_ti)
            if g and not g.isEmpty():
                geoms_ti.append(g)
        if not geoms_ti:
            return None, "Le Tavole di inquadramento generate non hanno geometrie valide."
        target = QgsGeometry.unaryUnion(geoms_ti)
        if not target or target.isEmpty():
            return None, "L'unione delle Tavole di inquadramento è risultata vuota."
        return target, None

    def _ottimizza_griglia(self, chiave, nome_umano):
        """BUTTA VIA la copertura già generata e ne genera una NUOVA, nel
        minor numero di tavole possibile, con gli stessi modelli A/B già
        impostati sopra. Il target da coprire non è più l'intero poligono
        ARLO AREA:
        - Tavole di inquadramento: solo Infrastrutture STATO='Nuovo'
          (escluse TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL) unite al
          Pozzetto STATO='Nuovo' — vanno generate PER PRIME.
        - Keyplan: SOLO l'unione delle Tavole di inquadramento già
          rigenerate sulla rete nuova (richiede quindi che il punto sopra
          sia già stato fatto) — non più unito ad ARLO AREA: un target
          esteso come l'intero ARLO AREA faceva scegliere all'algoritmo
          punti da coprire lontani dalla rete, con il Keyplan che finiva
          piazzato spostato rispetto alle Tavole di inquadramento invece
          che sopra di esse.
        In entrambi i casi le tavole restano MAI sovrapposte (stessa
        regola della copertura sull'area di progetto), una accanto
        all'altra fino a toccarsi. Usa lo stesso algoritmo di copertura
        adattiva (una tavola alla volta sul 'buco' scoperto più grande)
        più la potatura delle tavole ridondanti. Le dimensioni delle
        tavole sono prese dagli STESSI layer modello già usati per la
        generazione sopra (non da quelle già generate, che potrebbero
        avere gli angoli leggermente arrotondati dal margine di sicurezza
        e dare misure imprecise)."""
        lyr = self._output_layers.get(chiave)
        if lyr is None or lyr.id() not in self.project.mapLayers():
            QMessageBox.warning(self, "Nessuna copertura", f"Genera prima la copertura {nome_umano}."); return
        n_tiles_prima = lyr.featureCount()

        raggio = self.spin_kp_raggio.value()
        if chiave == 'inquadramento':
            target, errore = self._target_ottimizza_inquadramento(raggio)
        else:
            target, errore = self._target_ottimizza_keyplan()
        if errore:
            QMessageBox.warning(self, "Target non disponibile", errore); return

        # Stessi modelli A/B già usati per la generazione (Keyplan sopra, o
        # Inquadramento se impostato, altrimenti il Keyplan come fallback):
        # dimensioni esatte, non stimate dalle tavole già generate.
        if chiave == 'keyplan':
            lyr_a = self.cb_kp_keyplan.currentLayer(); lyr_b = self.cb_kp_keyplan2.currentLayer()
        else:
            lyr_a = self.cb_ti_tmpl_a.currentLayer() or self.cb_kp_keyplan.currentLayer()
            lyr_b = self.cb_ti_tmpl_b.currentLayer() or (self.cb_kp_keyplan2.currentLayer() if not self.cb_ti_tmpl_a.currentLayer() else None)
        tmpl_a = self._template_kp(lyr_a)
        if not tmpl_a:
            QMessageBox.warning(self, "Layer modello mancante", f"Imposta almeno il modello A per {nome_umano} (sezione qui sopra)."); return
        f_tmpl_a, g_tmpl_a = tmpl_a
        bb_a = g_tmpl_a.boundingBox()
        if bb_a.width() <= 0 or bb_a.height() <= 0:
            QMessageBox.warning(self, "Geometria modello non valida", "La geometria modello ha estensione nulla."); return
        dims = [('A', bb_a.width(), bb_a.height())]
        campi = lyr_a.fields(); wkb_type = lyr_a.wkbType()

        tmpl_b = self._template_kp(lyr_b) if lyr_b else None
        f_tmpl_b, g_tmpl_b = tmpl_b if tmpl_b else (None, None)
        if tmpl_b:
            bb_b = g_tmpl_b.boundingBox()
            if bb_b.width() > 0 and bb_b.height() > 0:
                dims.append(('B', bb_b.width(), bb_b.height()))

        gap = self.spin_kp_gap.value() if chiave == 'keyplan' else self.spin_ti_gap.value()
        # Soglia residua bassa e fissa (non % dell'area di una tavola): il
        # target qui è un corridoio STRETTO, la cui area totale è normale
        # sia molto più piccola di una singola tavola. Con la soglia
        # percentuale usata per coprire ARLO AREA, la copertura si sarebbe
        # fermata dopo una tavola o due, o addirittura non partiva affatto.
        tessere, area_residua = self._copertura_adattiva(
            dims, target, gap, vieta_sovrapposizione=True, soglia_residua=0.25
        )
        if not tessere:
            QMessageBox.warning(
                self, "Rigenerazione non riuscita",
                "Nessuna tavola generata sul target: prova ad aumentare il raggio "
                "target (sezione qui sopra) o verifica il contenuto dei layer usati."
            ); return

        n_prima_potatura = len(tessere)
        tessere = self._pota_tavole_ridondanti(tessere)
        n_potate = n_prima_potatura - len(tessere)

        lyr_nuovo, n_a, n_b = self._scrivi_tessere(
            tessere, campi, f_tmpl_a, f_tmpl_b, nome_umano, chiave, wkb_type,
        )

        if chiave == 'inquadramento':
            base_msg = (
                f"{nome_umano}: rigenerate {len(tessere)} tavole (erano {n_tiles_prima}) posizionate solo "
                f"su Infrastrutture Nuove (escl. '{VAL_AEREA}'/NULL, raggio {raggio:g} m) e Pozzetto Nuovo, "
                "il più possibile a contatto tra loro, senza nessuna sovrapposizione."
            )
        else:
            base_msg = (
                f"{nome_umano}: rigenerate {len(tessere)} tavole (erano {n_tiles_prima}) posizionate sopra le "
                "Tavole di inquadramento già rigenerate, senza nessuna sovrapposizione."
            )
        msg = [base_msg]
        if n_potate:
            msg.append(f"{n_potate} tavole ridondanti rimosse in più.")
        msg.append(
            "ARLO AREA può restare scoperta dove non c'è rete nuova da documentare: è voluto."
            if area_residua <= 1.0 else
            f"Corridoio residuo non coperto (troppo stretto per un'altra tavola senza sovrapporsi): ≈{area_residua:.0f} m². "
            "ARLO AREA può comunque restare scoperta dove non c'è rete nuova: è voluto."
        )
        testo = "\n".join(msg)
        self.log_kp.setPlainText(testo)
        QMessageBox.information(self, "Rigenerazione completata", testo)

    def _numera_per_posizione(self, lyr, campo):
        """Numera le feature poligonali di `lyr` in ordine di lettura:
        raggruppa per 'righe' (i centroidi la cui Y sta entro metà
        dell'altezza media di una tavola dalla Y del primo elemento di
        quella riga finiscono nella stessa riga), poi ordina ogni riga da
        ovest a est. Il campo (intero) viene creato se manca. Ritorna
        (n_numerati, n_letti_dal_layer): se n_letti è molto più basso del
        numero di tavole/keyplan che ti aspetti, il layer impostato nel
        campo qui sopra probabilmente non è quello giusto (es. un filtro
        attivo sul layer, o il layer modello invece di quello generato)."""
        n_letti = lyr.featureCount()
        elementi = []
        for f in lyr.getFeatures():
            g = self._to_proj(f.geometry(), lyr)
            if not g or g.isEmpty(): continue
            elementi.append((f, g.centroid().asPoint(), g.boundingBox()))
        if not elementi: return 0, n_letti

        h_media = sum(bb.height() for _, _, bb in elementi) / len(elementi)
        soglia_riga = max(h_media * 0.5, 0.01)

        elementi.sort(key=lambda t: -t[1].y())  # nord -> sud
        righe = []; riga_corrente = []; y_riga = None
        for item in elementi:
            y = item[1].y()
            if y_riga is None or (y_riga - y) <= soglia_riga:
                riga_corrente.append(item)
                if y_riga is None: y_riga = y
            else:
                righe.append(riga_corrente)
                riga_corrente = [item]; y_riga = y
        if riga_corrente: righe.append(riga_corrente)
        for riga in righe:
            riga.sort(key=lambda t: t[1].x())  # ovest -> est

        era = lyr.isEditable()
        if not self._start_edit(lyr): return 0, n_letti
        idx_campo = lyr.fields().indexOf(campo)
        if idx_campo < 0:
            lyr.addAttribute(QgsField(campo, QVariant.Int))
            lyr.updateFields()
            idx_campo = lyr.fields().indexOf(campo)
        n = 0; numero = 1
        for riga in righe:
            for f, _c, _bb in riga:
                lyr.changeAttributeValue(f.id(), idx_campo, numero)
                numero += 1; n += 1
        if not era and not self._commit(lyr, f"Errore numerazione '{lyr.name()}'"):
            return 0, n_letti
        lyr.triggerRepaint()
        return n, n_letti

    def _numera_keyplan_e_tavole(self):
        lavori = []
        kp = self.cb_num_keyplan.currentLayer()
        if kp:
            campo = self.txt_num_keyplan_campo.text().strip()
            lavori.append((kp, campo, "Keyplan"))
        tv = self.cb_num_tavole.currentLayer()
        if tv:
            campo = self.txt_num_tavole_campo.text().strip()
            lavori.append((tv, campo, "Tavole di Inquadramento"))
        if not lavori:
            QMessageBox.warning(self, "Nessun layer", "Imposta almeno un layer (Keyplan e/o Tavole di Inquadramento) da numerare."); return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            righe = []
            for lyr, campo, nome in lavori:
                if not campo:
                    righe.append(f"{nome}: campo numerazione non indicato, saltato."); continue
                n, n_letti = self._numera_per_posizione(lyr, campo)
                riga = f"{nome} ('{lyr.name()}'): {n} elementi numerati su {n_letti} letti dal layer (campo '{campo}', ordine alto-sinistra → basso-destra)."
                if n_letti <= 1:
                    riga += " Solo 1 elemento nel layer: verifica che sia quello giusto (non un filtro attivo o il layer modello)."
                righe.append(riga)
        finally:
            QApplication.restoreOverrideCursor()

        testo = "\n".join(righe)
        self.log_kp.setPlainText(testo)
        QMessageBox.information(self, "Numerazione completata", testo)

    def _salva_uno(self, chiave, nome_umano, nome_stile):
        """Scrive SOLO il layer `nome_umano` (Keyplan oppure Poligoni
        Inquadramento, mai insieme) su un GeoPackage a scelta dell'utente,
        poi carica al posto della copia in RAM il layer appena scritto su
        disco con lo stile allegato al plugin già applicato. L'errore
        'UNIQUE constraint failed' capitava quando si salvava di nuovo
        sullo STESSO file: il layer caricato dal salvataggio precedente
        restava aperto nel progetto e teneva il GeoPackage 'occupato', così
        GDAL non riusciva a sovrascriverlo davvero e finiva per provare ad
        AGGIUNGERE le nuove tavole a quelle vecchie rimaste dentro, con lo
        stesso numero (fid) già usato. Ora, prima di scrivere: 1) se il
        file scelto è ESATTAMENTE quello dove il layer è già salvato, si
        blocca con un avviso invece di riscrivere su se stesso; 2) qualsiasi
        altro layer nel progetto che punta già a quel file viene rimosso
        (chiudendo la connessione) e il file preesistente viene cancellato,
        così la scrittura riparte sempre da zero."""
        lyr = self._output_layers.get(chiave)
        if lyr is None or lyr.id() not in self.project.mapLayers() or lyr.featureCount() == 0:
            QMessageBox.warning(
                self, "Niente da salvare",
                f"Genera prima la copertura {nome_umano} (deve contenere almeno una tavola)."
            ); return

        suggerito = nome_umano.replace(" ", "_") + ".gpkg"
        percorso, _ = QFileDialog.getSaveFileName(self, f"Salva {nome_umano} come GeoPackage", suggerito, "GeoPackage (*.gpkg)")
        if not percorso:
            return
        if not percorso.lower().endswith(".gpkg"):
            percorso += ".gpkg"
        percorso_norm = os.path.normcase(os.path.abspath(percorso))

        sorgente = lyr.source().split("|")[0]
        if lyr.providerType() != "memory" and sorgente and os.path.normcase(os.path.abspath(sorgente)) == percorso_norm:
            QMessageBox.warning(
                self, "Stesso file",
                f"'{nome_umano}' è già salvato in questo identico file.\n"
                "Rigenera la copertura (o scegline un altro) prima di salvarla di nuovo qui."
            ); return

        # Libera il file da eventuali lock: rimuove dal progetto ogni layer
        # (di qualunque chiave) che punta già a questo percorso, poi lo
        # cancella se esiste ancora, prima di scrivere.
        for lid, l in list(self.project.mapLayers().items()):
            try:
                src = l.source().split("|")[0]
                if src and os.path.normcase(os.path.abspath(src)) == percorso_norm:
                    self.project.removeMapLayer(lid)
            except Exception:
                pass
        if os.path.exists(percorso):
            try:
                os.remove(percorso)
            except OSError:
                pass  # se non si riesce a cancellarlo subito, ci prova comunque CreateOrOverwriteFile

        opzioni = QgsVectorFileWriter.SaveVectorOptions()
        opzioni.driverName = "GPKG"
        opzioni.layerName = nome_umano
        opzioni.fileEncoding = "UTF-8"
        opzioni.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        errore = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, percorso, self.project.transformContext(), opzioni)
        codice_errore = errore[0] if isinstance(errore, tuple) else errore
        if codice_errore != QgsVectorFileWriter.NoError:
            dettaglio = errore[1] if isinstance(errore, tuple) and len(errore) > 1 else str(errore)
            QMessageBox.critical(self, "Errore nel salvataggio", f"Impossibile salvare '{nome_umano}':\n{dettaglio}"); return

        lyr_disco = QgsVectorLayer(f"{percorso}|layername={nome_umano}", nome_umano, "ogr")
        if not lyr_disco.isValid():
            QMessageBox.warning(
                self, "Salvato ma non ricaricato",
                f"'{nome_umano}' è stato scritto in {percorso} ma non è stato possibile ricaricarlo nel progetto."
            ); return

        stile_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "styles", nome_stile)
        stile_ok = False
        if os.path.isfile(stile_path):
            ris = lyr_disco.loadNamedStyle(stile_path)
            stile_ok = bool(ris[1]) if isinstance(ris, tuple) else bool(ris)
            if stile_ok:
                lyr_disco.saveStyleToDatabase(nome_umano, f"Stile {nome_umano}", True, "")

        if lyr.id() in self.project.mapLayers():
            self.project.removeMapLayer(lyr.id())
        self.project.addMapLayer(lyr_disco)
        self._output_layers[chiave] = lyr_disco
        lyr_disco.triggerRepaint()

        msg = (f"'{nome_umano}' salvato in:\n{percorso}\n({lyr_disco.featureCount()} tavole)"
               + (" con stile applicato." if stile_ok else " — stile NON applicato (file .qml mancante nel plugin)."))
        self.log_kp.setPlainText(msg)
        QMessageBox.information(self, "Salvataggio completato", msg)
