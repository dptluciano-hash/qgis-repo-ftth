# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""FTTH Permessi Manager  v2.9.15"""
import os, math, json, re, inspect, unicodedata, urllib.request, urllib.parse, urllib.error

# logica pura (parsing, formattazione, fit di similitudine, union-find):
# vive in ftth_core, che non importa qgis/PyQt ed è coperto da tests/test_core.py
try:
    from . import ftth_core
except ImportError:          # file aperto fuori dal pacchetto (es. console)
    import ftth_core

# versione ricavata dalla docstring del modulo, che è l'unico posto in cui va
# aggiornata (e che lo script di rilascio riscrive da sé): compare nel titolo
# della finestra, così a colpo d'occhio si sa quale versione sta girando
_m_versione = re.search(r"v(\d+(?:\.\d+)*)", __doc__ or "")
VERSIONE = _m_versione.group(1) if _m_versione else "sconosciuta"

from qgis.PyQt.QtCore import (Qt, QVariant, QSettings, QSizeF,
                              QObject, QThread, pyqtSignal)
from qgis.PyQt.QtGui import QTransform, QFont, QColor
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QFormLayout, QTabWidget, QWidget,
    QLabel, QPushButton, QCheckBox, QDoubleSpinBox, QSpinBox, QPlainTextEdit,
    QGroupBox, QMessageBox, QSizePolicy, QFileDialog, QLineEdit, QComboBox,
    QScrollArea, QApplication, QListWidget, QListWidgetItem, QAbstractItemView,
    QToolButton, QGridLayout, QFontComboBox, QTextBrowser, QProgressBar,
)
from qgis.core import (QgsMapLayer, 
    QgsWkbTypes, QgsSpatialIndex, QgsFeatureRequest, QgsFeature,
    QgsPointXY, QgsRectangle, QgsGeometry, QgsCoordinateTransform,
    QgsVectorLayer, QgsField, QgsFields, QgsVectorFileWriter, QgsCoordinateReferenceSystem,
    QgsDataProvider,
    QgsExpression, QgsExpressionContext, QgsExpressionContextUtils,
    QgsLayoutExporter, QgsLayoutRenderContext,
    QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QgsTextFormat,
    QgsTextBufferSettings, QgsTextBackgroundSettings, QgsTextShadowSettings,
    QgsUnitTypes,
    QgsDistanceArea,
    QgsLineSymbol, QgsFillSymbol, QgsSingleSymbolRenderer,
)
from qgis.gui import QgsMapLayerComboBox, QgsMapTool, QgsFieldComboBox
from qgis.core import QgsMapLayerProxyModel

# scheda Istanze RFI (mixin in modulo separato)
try:
    from .ftth_rfi_ui import RFIMixin
except ImportError:
    try:
        from ftth_rfi_ui import RFIMixin
    except ImportError:
        class RFIMixin:  # fallback: plugin funziona anche senza la scheda RFI
            def _tab_rfi(self):
                return None

# scheda Fasce di rispetto (mixin in modulo separato)
try:
    from .ftth_fasce_ui import FasceMixin
except ImportError:
    try:
        from ftth_fasce_ui import FasceMixin
    except ImportError:
        class FasceMixin:  # fallback: plugin funziona anche senza la scheda Fasce
            def _tab_fasce(self):
                return None

# scheda Unisci tratte (mixin in modulo separato)
try:
    from .ftth_unisci_ui import UnisciTratteMixin
except ImportError:
    try:
        from ftth_unisci_ui import UnisciTratteMixin
    except ImportError:
        class UnisciTratteMixin:  # fallback: plugin funziona anche senza la scheda
            def _tab_unisci(self):
                return None

# ── costanti modello dati ──────────────────────────────────────────
CAMPO_TIP_INFRA   = "TIPOLOGIA"
VAL_AEREA         = "Aerea"
CAMPO_STATO       = "STATO"
VAL_NUOVO         = "Nuovo"
CAMPO_TIPO_PTE    = "TIPO"
VALORI_PTE_INT    = ["Interno Edificio", "Muro Interno"]
CAMPO_TIP_PTE     = "TIPOLOGIA"
VAL_PTE_LIGHT     = "PTE Light Diramatore"
CAMPO_ROT         = "Rotazione"
CAMPO_ID_TAVOLA   = "ID_Tavola"
CAMPO_LUNGHEZZA   = "LUNGHEZZA"
CAMPO_LUNGH_NEW   = "Lungh"
VAL_NO_DIG        = "No Dig"
CAMPO_CIVICO      = "CIVICO"
VAL_CIVICO_999    = "999"
VAL_CIVICO_SNC    = "SNC"

# --- Cono di ripresa come GEOMETRIA ------------------------------------
# Il simbolo a cono non si puo' ruotare con l'anteprima dal vivo: lo
# strumento "Ruota simboli dei punti" scrive un numero, non mostra il
# risultato mentre trascini. "Ruota elementi" lo fa, ma vuole una
# geometria vera. Da qui il cono poligonale.
#
# Convenzione, MISURATA sul simbolo attuale e non dedotta: l'inchiostro
# cade ad azimut pari a CAMPO_ROT, orario da Nord (il "+90" che compare
# nell'espressione della simbologia serve proprio a rendere il campo un
# azimut vero). Verifica su Rotazione 0/45/90/180/270: scarto medio
# -0.5 gradi, dispersione 3.7, dovuta all'asimmetria fra freccia e arco.
CONO_APERTURA_GRADI = 120.0   # come il simbolo 'third_arc'
CONO_RAGGIO_MM      = 6.0     # come la dimensione del marker
CONO_SCALA_DEFAULT  = 1000.0  # 1:1000, scala del layout 03_Inquadramento
CONO_SEGMENTI       = 18      # vertici dell'arco: arco liscio, pochi nodi
CAMPO_CONO_PUNTO    = "fid_punto"   # aggancio cono -> punto di ripresa
NOME_LAYER_CONI     = "Cono di Ripresa"


def cono_poligono(punto, azimut, raggio, apertura=CONO_APERTURA_GRADI,
                  segmenti=CONO_SEGMENTI):
    """Settore circolare con l'APICE sul punto di ripresa, bisettrice
    lungo 'azimut' (gradi orari da Nord).

    L'ordine dei vertici non e' decorativo ed e' parte del contratto con
    azimut_da_cono(): il primo vertice e' l'apice, quello centrale e' la
    meta' dell'arco. QGIS, ruotando o spostando un elemento, conserva
    l'ordine dei vertici, quindi l'azimut resta leggibile dopo che il
    collega ha trascinato il cono.
    """
    import math as _m
    cx, cy = punto.x(), punto.y()
    a0 = azimut - apertura / 2.0
    passo = apertura / float(segmenti)
    pts = [QgsPointXY(cx, cy)]
    for i in range(segmenti + 1):
        a = _m.radians(a0 + passo * i)
        pts.append(QgsPointXY(cx + raggio * _m.sin(a), cy + raggio * _m.cos(a)))
    pts.append(QgsPointXY(cx, cy))
    return QgsGeometry.fromPolygonXY([pts])


def azimut_da_cono(geom):
    """Azimut (gradi orari da Nord) letto da un cono, anche dopo che e'
    stato ruotato o spostato. Restituisce (azimut, apice) oppure None.

    Si legge dai vertici, non dal baricentro: 'Ruota elementi' puo'
    ruotare attorno a un centro qualunque, quindi l'apice si sposta e il
    baricentro non dice piu' dove guarda la camera. L'apice e' il primo
    vertice e la meta' dell'arco quello centrale: la congiungente fra i
    due e' la bisettrice, cioe' la direzione di ripresa.
    """
    import math as _m
    try:
        anelli = geom.asPolygon()
        if not anelli: return None
        ring = anelli[0]
        if len(ring) < 4: return None
        if ring[0] == ring[-1]: ring = ring[:-1]   # chiusura ripetuta
        apice = ring[0]
        meta = ring[1 + (len(ring) - 1) // 2]
        dx, dy = meta.x() - apice.x(), meta.y() - apice.y()
        if abs(dx) < 1e-9 and abs(dy) < 1e-9: return None
        return _m.degrees(_m.atan2(dx, dy)) % 360.0, apice
    except Exception:
        return None


def raggio_da_cono(geom):
    """Raggio vero del cono: distanza fra l'apice e un vertice dell'arco.

    NON si ricava dal rettangolo d'ingombro: quello dipende da come il cono
    e' orientato e sottostima il raggio fino alla meta' (a 90 gradi
    bbox.width()/2 vale esattamente la meta' del raggio). Siccome il cono
    viene poi RIDISEGNATO con quel valore, l'errore si accumula a ogni
    salvataggio e il cono si rimpicciolisce da solo: misurato 6,0 -> 0,4 m
    in cinque rotazioni consecutive.
    """
    import math as _m
    try:
        anelli = geom.asPolygon()
        if not anelli: return None
        ring = anelli[0]
        if len(ring) < 4: return None
        if ring[0] == ring[-1]: ring = ring[:-1]
        apice = ring[0]
        meta = ring[1 + (len(ring) - 1) // 2]
        r = _m.hypot(meta.x() - apice.x(), meta.y() - apice.y())
        return r if r > 1e-9 else None
    except Exception:
        return None


class _UF(ftth_core.UnionFind):
    """Alias storico: l'implementazione vive in ftth_core.UnionFind."""
    pass


def _log_avviso(contesto, errore):
    """Traccia nel pannello 'Log dei messaggi' di QGIS (scheda 'FTTH Permessi')
    le eccezioni non fatali che prima venivano ingoiate in silenzio: il
    comportamento del plugin non cambia — l'operazione prosegue comunque — ma
    un malfunzionamento lascia una riga consultabile invece di sparire."""
    try:
        from qgis.core import Qgis, QgsMessageLog
        QgsMessageLog.logMessage(f"{contesto}: {errore}",
                                 "FTTH Permessi", level=Qgis.Warning)
    except Exception:
        pass  # il logging non deve mai diventare a sua volta causa di errore


def _opzioni_accettate(funzione, candidati):
    """Tiene solo gli argomenti che `funzione` dichiara davvero.

    Lo screening e il dialogo evolvono separatamente: passare alla cieca un
    parametro nuovo (annullamento, budget di tempo) a una versione del modulo
    che non lo conosce farebbe morire lo screening con un TypeError prima
    ancora della prima interrogazione. Così il pannello funziona con entrambe
    le versioni del modulo."""
    try:
        parametri = inspect.signature(funzione).parameters
    except (TypeError, ValueError) as e:
        _log_avviso("lettura della firma di %r" % (funzione,), e)
        return {}
    if any(p.kind == p.VAR_KEYWORD for p in parametri.values()):
        return dict(candidati)
    return {k: v for k, v in candidati.items() if k in parametri}


def _sostituisci(destinazione, nuovo):
    """Riversa il report ricalcolato dentro l'oggetto che il chiamante tiene.

    Le funzioni di analisi possono restituire un dizionario nuovo oppure lo
    stesso che hanno ricevuto: svuotare alla cieca il destinatario, nel secondo
    caso, cancellerebbe proprio il risultato appena calcolato."""
    if nuovo is None or nuovo is destinazione:
        return destinazione
    destinazione.clear()
    destinazione.update(nuovo)
    return destinazione


class _ScreeningWorker(QObject):
    """Parte LENTA dello screening, da far girare in un thread a parte.

    Finché queste chiamate stavano nel thread dell'interfaccia, Windows
    marcava QGIS come 'Non risponde' per tutta la durata — nel caso peggiore
    ore, perché una sola interrogazione Overpass può arrivare a centinaia di
    secondi e i layer SITAP sono nove — la finestra sbiancava e l'unica via
    d'uscita era uccidere il processo dalla Gestione attività.

    Qui dentro NON si tocca nulla di QGIS né dell'interfaccia: arrivano solo
    geometrie shapely già preparate nel thread principale, e l'avanzamento
    esce come segnale. Scrivere direttamente sul widget di log da questo
    thread è la causa classica dei crash silenziosi di QGIS.
    """

    avanzamento = pyqtSignal(str)
    finito = pyqtSignal(object, object)   # (report, messaggio di errore)

    def __init__(self, scr, param):
        super().__init__()
        self._scr = scr
        self._p = param
        self._fermati = False

    def chiedi_annullamento(self):
        """Chiamato dal thread dell'interfaccia quando l'utente preme Annulla.
        È solo un booleano: il modulo di screening lo interroga da sé prima di
        ogni richiesta di rete, così non serve uccidere il thread (uccidere un
        thread nel mezzo di una socket lascia QGIS in uno stato incoerente)."""
        self._fermati = True

    def annullato(self):
        return self._fermati

    def _conta_strade(self, rep):
        return sum(len(v) for v in (rep.get("rete_stradale") or {}).values())

    def esegui(self):
        rep = None
        errore = None
        try:
            p = self._p
            scr = self._scr
            candidati = {
                "avanzamento": self.avanzamento.emit,
                "raccogli_geometrie": p["raccogli"],
                "annulla": self.annullato,
            }
            if p.get("budget_s") is not None:
                candidati["budget_s"] = p["budget_s"]
            rep = scr.esegui(p["comune"], p["provincia"],
                             **_opzioni_accettate(scr.esegui, candidati))

            if rep is None:
                errore = "il modulo di screening non ha restituito alcun report"
            elif not rep.get("errore") and not rep.get("annullato"):
                if self._fermati:
                    # il modulo può essere arrivato in fondo senza accorgersene
                    rep["annullato"] = True
                else:
                    self._fasi_su_dati(rep)
        except Exception as e:      # rete giù, servizio cambiato: mai crash del pannello
            _log_avviso("screening territorio (thread secondario)", e)
            errore = str(e)
        self.finito.emit(rep, errore)

    def _fasi_su_dati(self, rep):
        """Restrizione al tracciato/area e fusione dello stradario.

        Sono funzioni pure su geometrie shapely — non leggono layer di QGIS —
        quindi stanno qui e non nel thread dell'interfaccia: su un tracciato
        lungo valgono comunque minuti di calcolo, abbastanza per far sbiancare
        la finestra."""
        p = self._p
        scr = self._scr

        if p["usa_tracciato"]:
            self.avanzamento.emit("")
            self.avanzamento.emit("Analisi sul tracciato con fasce di rispetto ufficiali…")
            nuovo = scr.analizza_su_tracciato(
                rep, p["traccia"], p["buffer_m"], p["traccia_nome"])
            _sostituisci(rep, nuovo)
            attrav = sum(1 for cls in rep["rete_stradale"].values()
                         for v in cls.values() if v.get("stato") == "ATTRAVERSAMENTO")
            self.avanzamento.emit(
                "Sul tracciato: %d strade rilevanti (%d attraversamenti) · %d vincoli · "
                "ferrovie: %s · %d corsi d'acqua" % (
                    self._conta_strade(rep), attrav, len(rep["vincoli"]),
                    ", ".join(rep["ferrovie"]) or "no", len(rep["corsi_acqua"])))
        elif p["area"] is not None:
            self.avanzamento.emit("")
            self.avanzamento.emit("Restrizione all'area di progetto '%s'…" % p["nome_area"])
            nuovo = scr.restringi_ad_area(rep, p["area"], p["nome_area"])
            _sostituisci(rep, nuovo)
            self.avanzamento.emit(
                "Nell'area: %d strade classificate (%s) · %d vincoli · "
                "ferrovie: %s · ex sedimi: %s · %d corsi d'acqua" % (
                    self._conta_strade(rep),
                    ", ".join("%s×%d" % (k, len(v))
                              for k, v in sorted(rep["rete_stradale"].items())) or "nessuna",
                    len(rep["vincoli"]),
                    ", ".join(rep["ferrovie"]) or "no",
                    ", ".join(rep["ferrovie_dismesse"]) or "no",
                    len(rep["corsi_acqua"])))

        if self._fermati:
            rep["annullato"] = True
            return

        if p["strad_records"] is not None:
            self.avanzamento.emit("")
            self.avanzamento.emit(
                "Stradario di riferimento '%s': %d tratti letti%s…"
                % (p["strad_nome"], len(p["strad_records"]),
                   " nell'area" if p["area"] is not None else " nel comune"))
            rete_str = scr.rete_da_stradario(p["strad_records"])
            nuovo = scr.fondi_stradario(rep, rete_str, p["strad_nome"], p["strad_indip"])
            _sostituisci(rep, nuovo)
            n_osm_only = sum(len(v) for v in rep.get("rete_stradale_solo_osm", {}).values())
            self.avanzamento.emit(
                "Rete da stradario: %d strade (%s)%s" % (
                    self._conta_strade(rep),
                    ", ".join("%s×%d" % (k, len(v))
                              for k, v in sorted(rep["rete_stradale"].items())) or "nessuna",
                    " · %d solo in OSM (da verificare)" % n_osm_only if n_osm_only else ""))
            if not p["strad_indip"]:
                self.avanzamento.emit(
                    "  NOTA: '%s' è un estratto OSM — la controprova non è indipendente."
                    % p["strad_nome"])

        if self._fermati:
            rep["annullato"] = True



class _StrumentoClicPunto(QgsMapTool):
    """Strumento mappa temporaneo: cattura UN click sulla canvas e lo passa
    a `callback` come QgsPointXY nel CRS del progetto, poi ripristina lo
    strumento mappa precedente da solo. Usato per i punti di controllo
    manuali (es. un punto sulla rete e il corrispondente sul WMS)."""
    def __init__(self, canvas, callback):
        super().__init__(canvas)
        self._canvas = canvas
        self._callback = callback
        self._precedente = canvas.mapTool()

    def canvasReleaseEvent(self, event):
        pt = self.toMapCoordinates(event.pos())
        self._canvas.setMapTool(self._precedente)
        self._callback(QgsPointXY(pt))

    def deactivate(self):
        super().deactivate()


class ComboCheckable(QComboBox):
    """Menu a tendina a selezione multipla con caselle di spunta.

    Sostituisce le liste a selezione multipla dove serve coerenza visiva con gli
    altri combo del pannello, senza perdere la possibilità di scegliere più voci.
    Il testo mostrato riassume quante voci sono spuntate; la tendina resta aperta
    mentre si spuntano le caselle. Ogni voce porta l'id del layer in UserRole."""

    def __init__(self, parent=None, placeholder="(nessuno selezionato)"):
        super().__init__(parent)
        from qgis.PyQt.QtGui import QStandardItemModel, QStandardItem
        self._placeholder = placeholder
        self.setModel(QStandardItemModel(self))
        self.setEditable(True)
        self.lineEdit().setReadOnly(True)
        self.lineEdit().setPlaceholderText(placeholder)
        # non chiudere la tendina a ogni spunta
        self.view().pressed.connect(self._toggle_item)
        self.model().dataChanged.connect(lambda *a: self._aggiorna_testo())
        self._aggiorna_testo()

    def _toggle_item(self, index):
        from qgis.PyQt.QtGui import QStandardItem
        item = self.model().itemFromIndex(index)
        if item is None or not (item.flags() & Qt.ItemIsUserCheckable):
            return
        item.setCheckState(Qt.Unchecked if item.checkState() == Qt.Checked else Qt.Checked)

    def aggiungi(self, testo, dato, spuntato=False):
        from qgis.PyQt.QtGui import QStandardItem
        item = QStandardItem(testo)
        item.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable)
        item.setData(dato, Qt.UserRole)
        item.setCheckState(Qt.Checked if spuntato else Qt.Unchecked)
        self.model().appendRow(item)
        self._aggiorna_testo()

    def svuota(self):
        self.model().clear()
        self._aggiorna_testo()

    def dati_spuntati(self):
        out = []
        for r in range(self.model().rowCount()):
            it = self.model().item(r)
            if it.checkState() == Qt.Checked:
                out.append(it.data(Qt.UserRole))
        return out

    def testi_spuntati(self):
        out = []
        for r in range(self.model().rowCount()):
            it = self.model().item(r)
            if it.checkState() == Qt.Checked:
                out.append(it.text())
        return out

    def _aggiorna_testo(self):
        testi = self.testi_spuntati()
        if not testi:
            self.lineEdit().setText("")
        elif len(testi) == 1:
            self.lineEdit().setText(testi[0])
        else:
            self.lineEdit().setText("%d selezionati: %s" % (
                len(testi), ", ".join(testi)))



# --- riporto della rotazione dai coni ai punti di ripresa --------------
# Sta FUORI dal dialogo di proposito: l'utente riapre il progetto, ruota un
# cono e salva senza passare dal plugin, e il riporto deve funzionare lo
# stesso. Finche' viveva dentro la finestra, bastava non aprirla perche' la
# rotazione non arrivasse mai al punto di ripresa.
CONO_PROP_PUNTI   = "ftth/coni_punti_layer"
CONO_PROP_RAGGIO  = "ftth/coni_raggio"
CONO_PROP_APERT   = "ftth/coni_apertura"
CONO_PROP_MUOVE   = "ftth/coni_muove_camera"


def riporta_rotazioni(coni, punti, raggio, apert, muove, scrivi_log=None, iface=None):
    """Rilegge l'orientamento dai coni e lo riscrive sui punti.

    Si scrive via dataProvider e non con una sessione di modifica: cosi'
    non si rientra in afterCommitChanges e non si innesca un ciclo.
    """
    def _log(t):
        if scrivi_log:
            try: scrivi_log(t)
            except Exception: pass
    try:
        if punti is None or not punti.isValid(): return
        if punti.isEditable():
            # Mettere in modifica tutto il gruppo di layer e' la norma: qui il
            # riporto non puo' scrivere, e dirlo solo nel log del dialogo (che
            # nessuno guarda mentre digitalizza) equivale a tacere.
            avviso = ("Punti di Ripresa in modifica: le rotazioni NON sono "
                      "state riportate. Chiudi la modifica del layer punti "
                      "e risalva i coni.")
            _log(avviso)
            try: iface.messageBar().pushWarning("Coni di ripresa", avviso)
            except Exception: pass
            return
        i_rot_p = punti.fields().indexOf(CAMPO_ROT)
        i_rot_c = coni.fields().indexOf(CAMPO_ROT)
        if i_rot_p < 0: return

        attr_p, geom_p, attr_c, geom_c = {}, {}, {}, {}
        n_rot = n_mossi = 0
        orfani = illeggibili = 0
        rotti = senza_geom = 0
        for c in coni.getFeatures():
          # Il try sta DENTRO il ciclo di proposito: con il try attorno al
          # ciclo bastava un punto di ripresa senza geometria perche'
          # asPoint() sollevasse ValueError, l'eccezione uscisse dal for e
          # NESSUNA rotazione venisse scritta — nemmeno quelle dei coni gia'
          # letti bene, e senza una riga di log a dirlo.
          try:
            fid_p = c[CAMPO_CONO_PUNTO]
            if fid_p in (None, ""):
                orfani += 1; continue
            r = azimut_da_cono(c.geometry())
            if not r:
                # geometria non piu' riconoscibile come cono (rimodellata a
                # mano, vertici aggiunti): meglio saperlo che perderla in silenzio
                illeggibili += 1; continue
            az, apice = r
            pf = punti.getFeature(int(fid_p))
            if not pf.isValid():
                orfani += 1; continue        # il punto agganciato non c'e' piu'
            nuovo = int(round(az)) % 360
            # Rotazione assente puo' arrivare come None, QVariant nullo o
            # stringa vuota: prima float() sollevava TypeError, l'eccezione
            # usciva dal ciclo e il riporto si fermava per TUTTI i coni.
            try:
                grezzo = pf[CAMPO_ROT]
                if grezzo is None or (hasattr(grezzo, "isNull") and grezzo.isNull()) \
                   or str(grezzo).strip() == "":
                    vecchio_norm = None
                else:
                    vecchio_norm = int(round(float(grezzo))) % 360
            except (TypeError, ValueError):
                vecchio_norm = None
            if vecchio_norm is None or vecchio_norm != nuovo:
                attr_p[pf.id()] = {i_rot_p: nuovo}
                if i_rot_c >= 0: attr_c[c.id()] = {i_rot_c: nuovo}
                n_rot += 1
            gpf = pf.geometry()
            if gpf is None or gpf.isEmpty():
                # La rotazione (qui sopra) gli e' comunque stata scritta:
                # l'attributo e' valido, manca solo la posizione. Non si puo'
                # invece riancorare il cono, e va detto per quello che e'.
                senza_geom += 1; continue
            pgeo = gpf.asPoint()
            scostato = (abs(apice.x()-pgeo.x()) > 1e-6 or abs(apice.y()-pgeo.y()) > 1e-6)
            if scostato:
                if muove:
                    geom_p[pf.id()] = QgsGeometry.fromPointXY(apice)
                    n_mossi += 1
                else:
                    # ruotando attorno a un centro qualunque l'apice si sposta,
                    # e la camera non deve spostarsi per sbaglio
                    r_suo = raggio_da_cono(c.geometry()) or raggio
                    geom_c[c.id()] = cono_poligono(pgeo, az, r_suo, apert)
          except Exception as e:
            rotti += 1
            _log_avviso("cono %s non elaborato" % c.id(), e)

        if attr_p: punti.dataProvider().changeAttributeValues(attr_p)
        if geom_p: punti.dataProvider().changeGeometryValues(geom_p)
        if attr_c: coni.dataProvider().changeAttributeValues(attr_c)
        if geom_c: coni.dataProvider().changeGeometryValues(geom_c)
        if attr_p or geom_p:
            # senza ricarica una tabella attributi gia' aperta mostra ancora il
            # valore vecchio: sembra rotto anche quando il dato e' stato scritto
            try: punti.dataProvider().forceReload()
            except Exception: pass
            punti.triggerRepaint()
        if attr_c or geom_c:
            try: coni.dataProvider().forceReload()
            except Exception: pass
            coni.triggerRepaint()
        if rotti:
            _log("ATTENZIONE: %d coni non elaborati per dati malformati: gli "
                 "altri sono stati riportati regolarmente." % rotti)
        if senza_geom:
            _log("%d punti di ripresa sono senza posizione: la rotazione e' "
                 "stata scritta lo stesso, ma il cono non e' stato riancorato."
                 % senza_geom)
        if orfani or illeggibili:
            _log("ATTENZIONE: %d coni senza punto di ripresa corrispondente, "
                 "%d con geometria non riconoscibile: le loro rotazioni NON "
                 "sono state riportate. Rigenera i coni per riallinearli."
                 % (orfani, illeggibili))
        _log("Salvataggio: %d rotazioni aggiornate, %d camere spostate, "
             "%d coni riancorati." % (n_rot, n_mossi, len(geom_c)))
    except Exception as e:
        _log_avviso("riporto delle rotazioni dai coni non riuscito", e)


def aggancia_coni_progetto(project, iface=None):
    """Attacca il riporto a tutti i layer di coni presenti nel progetto.

    Va chiamata all'apertura del progetto: la connessione vive nell'oggetto
    layer di questa sessione, non nel GeoPackage, quindi riaprendo va rifatta.
    Restituisce il numero di layer agganciati (serve ai test).
    """
    n = 0
    try:
        for coni in list(project.mapLayers().values()):
            try:
                if coni.type() != QgsMapLayer.VectorLayer: continue
                # il campo da solo non basta a riconoscere un layer di coni:
                # 'fid_punto' e' un nome abbastanza comune da trovarsi altrove
                if coni.geometryType() != QgsWkbTypes.PolygonGeometry: continue
                if coni.fields().indexOf(CAMPO_CONO_PUNTO) < 0: continue
                punti = None
                pid = coni.customProperty(CONO_PROP_PUNTI)
                if pid:
                    punti = project.mapLayer(pid)
                if punti is None:
                    cand = [l for l in project.mapLayers().values()
                            if l.type() == QgsMapLayer.VectorLayer
                            and l.fields().indexOf(CAMPO_ROT) >= 0
                            and l.geometryType() == QgsWkbTypes.PointGeometry]
                    # senza indicazione esplicita si usa l'unico candidato:
                    # tirare a indovinare fra piu' layer scriverebbe rotazioni
                    # sul layer sbagliato, che e' peggio di non scrivere
                    if len(cand) == 1: punti = cand[0]
                if punti is None: continue
                raggio = float(coni.customProperty(CONO_PROP_RAGGIO) or 0) or None
                if raggio is None:
                    # layer generato prima che il raggio venisse memorizzato:
                    # lo si misura sul cono, mai dal rettangolo d'ingombro
                    g = next(coni.getFeatures(), None)
                    raggio = (raggio_da_cono(g.geometry()) if g else None) or 25.0
                apert = float(coni.customProperty(CONO_PROP_APERT) or CONO_APERTURA_GRADI)
                muove = str(coni.customProperty(CONO_PROP_MUOVE, "1")) in ("1", "True", "true")
                # Si stacca SOLO il proprio riporto, non tutto il segnale:
                # disconnect() senza argomenti buttava giu' anche gli
                # ascoltatori di chiunque altro, compreso quello agganciato
                # dalla finestra del plugin quando e' aperta.
                vecchio = coni.property("_ftth_slot_coni")
                if vecchio is not None:
                    try: coni.afterCommitChanges.disconnect(vecchio)
                    except (TypeError, RuntimeError): pass
                slot = (lambda c=coni, p=punti, r=raggio, a=apert, m=muove:
                            riporta_rotazioni(c, p, r, a, m, iface=iface))
                coni.afterCommitChanges.connect(slot)
                coni.setProperty("_ftth_slot_coni", slot)
                n += 1
            except Exception as e:
                _log_avviso("aggancio coni per il layer %s non riuscito" % coni.name(), e)
    except Exception as e:
        _log_avviso("aggancio dei coni al progetto non riuscito", e)
    return n


class FTTHPermessiDialog(QDialog, RFIMixin, FasceMixin, UnisciTratteMixin):

    def __init__(self, iface, project, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.project = project
        self.setWindowTitle(f"Gestione Permessi FTTH  —  v{VERSIONE}")
        # finestra ridimensionabile in entrambe le direzioni (allarga e
        # stringi), con dimensione iniziale contenuta e un minimo ragionevole
        # così entra anche su schermi piccoli; il contenuto di ogni scheda è
        # inoltre scorrevole (vedi _scrollable), quindi stringere la finestra
        # sotto la dimensione naturale del contenuto non taglia nulla: compare
        # una barra di scorrimento invece di clippare i controlli
        self.setWindowFlags(self.windowFlags() | Qt.WindowMinMaxButtonsHint)
        self.setSizeGripEnabled(True)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMinimumSize(420, 320)
        self.resize(700, 680)
        self._last_layers = []
        self._output_layers = {}   # 'keyplan' / 'inquadramento' -> ultimo layer memory generato
        self._punti_controllo = []  # [(sorgente: QgsPointXY, riferimento: QgsPointXY), ...]
        self._trasformazione = None  # (a: complex, b: complex) o None se non ancora calcolata
        self._tool_clic = None  # riferimento allo strumento mappa attivo, se in attesa di un click
        self._contesti_consegna = []  # una voce per ogni copia della scheda 'Esportazione'
        self._impostazioni = QSettings("TerraLab", "FTTHPermessiManager")
        self._nota_grafica = ""  # avvisi dalla costruzione del formato etichette
        self._guide_aperte = []  # finestre di guida aperte, tenute in vita
        self._gruppi = []        # tutti i riquadri comprimibili creati
        self._edifici_trovati = None   # esito dell'ultima analisi 'Edifici in carreggiata'
        self._edifici_cancellati = None  # ultima cancellazione, per l'annullamento
        self._interrompi_ed = False    # alzato dal pulsante Interrompi
        self._analisi_in_corso = False  # vedi closeEvent: blocca la chiusura durante l'analisi
        # screening del territorio: gira in un thread a parte (vedi
        # _lancia_worker_screening). Gli attributi nascono qui perché
        # closeEvent e _log_screening li interrogano anche prima del primo avvio.
        self._scr_in_corso = False
        self._scr_thread = None
        self._scr_worker = None
        self._scr_contesto = {}
        # titoli dei gruppi in grassetto e spaziatura uniforme: senza colori
        # espliciti, così resta leggibile anche con i temi scuri di QGIS
        self.setStyleSheet(
            "QGroupBox { font-weight: bold; margin-top: 8px; padding-top: 6px; }"
            "QGroupBox::title { subcontrol-origin: margin; left: 8px; padding: 0 4px; }")
        self._build_ui()
        self._ripristina_stato_finestra()
        self._migra_impostazioni()
        self._ripristina_impostazioni()

    def _migra_impostazioni(self):
        """Correzioni una tantum alle impostazioni memorizzate.

        v0.78.2: i default della scheda Edifici sono cambiati (criterio
        attraversamento + test del corridoio acceso, al posto di buffer +
        corridoio spento) perché i vecchi trovavano 2 edifici su 20.871 sui
        livelli DBSN coi bordi della carreggiata. Le impostazioni salvate
        dalle versioni precedenti conservano però i valori vecchi e li
        rimetterebbero a ogni apertura: qui vengono dimenticate UNA volta
        sola, così i nuovi default prendono effetto ma le scelte fatte
        dall'utente da qui in avanti tornano a essere ricordate."""
        try:
            if self._impostazioni.value("migrazioni/edifici_0782", type=bool):
                pass
            else:
                self._impostazioni.remove("controlli/cb_ed_criterio")
                self._impostazioni.remove("controlli/chk_ed_corridoio")
                self._impostazioni.setValue("migrazioni/edifici_0782", True)
            # v0.78.5: il default di "Su una tratta misura" è diventato il
            # testo esteso "dal km ... al km ...". Il valore salvato dalle
            # versioni precedenti (indice 0, "inizio") lo scavalcherebbe a
            # ogni apertura: si dimentica una volta sola, come sopra.
            if not self._impostazioni.value("migrazioni/km_0785", type=bool):
                self._impostazioni.remove("controlli/cb_km_misura")
                self._impostazioni.setValue("migrazioni/km_0785", True)
        except Exception as e:
            _log_avviso("migrazione impostazioni non riuscita", e)

    def _ripristina_stato_finestra(self):
        """Riapre il plugin come lo si è lasciato: dimensione della finestra e
        schede attive. Su un pannello che ha quattro schede annidate, ritrovare
        ogni volta la prima è una piccola tassa a ogni apertura."""
        try:
            geometria = self._impostazioni.value("geometria")
            if geometria:
                self.restoreGeometry(geometria)
            for nome, tabs in (("tab_principale", self._tabs_principali),
                               ("tab_comune", self._tabs_comune),
                               ("tab_altri", self._tabs_altri_enti)):
                indice = self._impostazioni.value(nome, type=int)
                if indice is not None and 0 <= indice < tabs.count():
                    tabs.setCurrentIndex(indice)
        except Exception:
            pass  # impostazioni illeggibili: si riparte dai valori di default

    def _salva_stato_finestra(self):
        try:
            self._impostazioni.setValue("geometria", self.saveGeometry())
            self._impostazioni.setValue("tab_principale", self._tabs_principali.currentIndex())
            self._impostazioni.setValue("tab_comune", self._tabs_comune.currentIndex())
            self._impostazioni.setValue("tab_altri", self._tabs_altri_enti.currentIndex())
        except Exception as e:
            _log_avviso("salvataggio stato finestra non riuscito", e)

    def closeEvent(self, evento):
        # L'analisi degli edifici chiama QApplication.processEvents() dentro il
        # ciclo per tenere viva l'interfaccia: durante quelle chiamate Qt
        # consegna anche la richiesta di chiusura, e il dialogo verrebbe
        # distrutto mentre il ciclo sta ancora scrivendo su barra di
        # avanzamento e log — oggetti C++ già liberati, quindi crash che nessun
        # try/except intercetta. Qui la chiusura viene rifiutata e tradotta in
        # una richiesta di interruzione: il ciclo se ne accorge al giro dopo.
        if self._analisi_in_corso:
            self._interrompi_ed = True
            QMessageBox.information(
                self, "Analisi in corso",
                "È in corso l'analisi degli edifici in carreggiata.\n\n"
                "Ho appena richiesto l'interruzione: attendi che si fermi, poi "
                "richiudi il pannello.")
            evento.ignore()
            return
        # Lo screening gira in un thread a parte: chiudere la finestra senza
        # fermarlo lascerebbe un thread vivo che emette segnali verso widget
        # ormai distrutti (crash a QGIS aperto, dopo la chiusura del pannello).
        if getattr(self, "_scr_in_corso", False):
            worker = getattr(self, "_scr_worker", None)
            if worker is not None:
                worker.chiedi_annullamento()
            # attesa BREVE: bloccare qui senza scadenza riprodurrebbe proprio
            # il congelamento che lo spostamento su thread ha tolto
            if self._chiudi_thread_screening(attesa_ms=3000):
                self._ripristina_interfaccia_screening()
            else:
                QMessageBox.information(
                    self, "Screening in corso",
                    "È in corso lo screening del territorio.\n\n"
                    "Ho appena richiesto l'annullamento: attendi che la "
                    "richiesta aperta si chiuda, poi richiudi il pannello.")
                evento.ignore()
                return
        self._salva_stato_finestra()
        self._salva_impostazioni()
        super().closeEvent(evento)

    @staticmethod
    def _scrollable(widget):
        """Avvolge `widget` in una QScrollArea: permette di stringere la
        finestra del plugin sotto la dimensione naturale del contenuto senza
        tagliare nulla (compare una barra di scorrimento)."""
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setFrameShape(QScrollArea.NoFrame)
        area.setWidget(widget)
        return area

    # ═══════════════════════════════════════════════════════════ UI
    def _banner_logo(self):
        """Banner beexact stretto in cima al pannello: sfondo BIANCO con il logo
        beexact ufficiale (SVG vettoriale) a sinistra. L'SVG è renderizzato alla
        densità reale dello schermo (devicePixelRatio/logicalDpi) e marcato con
        setDevicePixelRatio, così resta nitido a qualsiasi scaling di Windows.
        Ritorna un QWidget o None se l'SVG non è disponibile."""
        from qgis.PyQt.QtGui import QPixmap, QPainter
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtWidgets import QApplication
        try:
            from qgis.PyQt.QtSvg import QSvgRenderer
        except Exception:  # noqa: BLE001
            return None

        base = os.path.dirname(os.path.abspath(__file__))
        svg = os.path.join(base, "assets", "beexact_logo.svg")
        if not os.path.exists(svg):
            return None
        r = QSvgRenderer(svg)
        if not r.isValid():
            return None

        BIANCO = "#ffffff"
        ALTEZZA = 30            # altezza logica del banner
        H_LOGO = ALTEZZA - 12   # altezza logica del logo (leggermente più piccolo)

        # scala fisica dello schermo: su Windows lo scaling frazionario (125%,
        # 150%) compare in logicalDpi (120, 144) anche quando DPR resta 1.0
        scale = 1.0
        try:
            scr = self.screen() if hasattr(self, "screen") and self.screen() else QApplication.primaryScreen()
            if scr is not None:
                scale = max(float(scr.devicePixelRatio()),
                            float(scr.logicalDotsPerInch()) / 96.0)
        except Exception:  # noqa: BLE001
            scale = 1.0
        if scale < 1.0:
            scale = 1.0

        ar = r.defaultSize()
        Hf = max(1, int(round(H_LOGO * scale)))            # altezza fisica
        Wf = max(1, int(round(Hf * ar.width() / ar.height()))) if ar.height() else Hf * 6
        logo = QPixmap(QSize(Wf, Hf))
        logo.fill(Qt.transparent)
        p = QPainter(logo); p.setRenderHint(QPainter.Antialiasing, True)
        r.render(p); p.end()
        logo.setDevicePixelRatio(scale)

        cornice = QWidget()
        cornice.setStyleSheet("background:%s;" % BIANCO)
        cornice.setFixedHeight(ALTEZZA)
        lay = QHBoxLayout(cornice)
        lay.setContentsMargins(8, 4, 8, 4)   # logo ben a sinistra
        lab = QLabel()
        lab.setPixmap(logo)
        lab.setStyleSheet("background:transparent;")
        lay.addWidget(lab)
        lay.addStretch()
        return cornice

    def _build_ui(self):
        m = QVBoxLayout(self)
        m.setContentsMargins(0, 0, 0, 0)
        m.setSpacing(0)
        banner = self._banner_logo()
        if banner is not None:
            m.addWidget(banner)
        tabs_principali = QTabWidget()
        self._tabs_principali = tabs_principali
        # margini interni al contenuto, non al banner (che va a filo)
        tabs_principali.setContentsMargins(0, 0, 0, 0)
        m.addWidget(tabs_principali)

        tabs_comune = QTabWidget()
        self._tabs_comune = tabs_comune
        tabs_comune.addTab(self._scrollable(self._tab_pulizia()),  "Seleziona elementi")
        tabs_comune.addTab(self._scrollable(self._tab_keyplan()),  "Keyplan e tavole")
        tabs_comune.addTab(self._scrollable(self._tab_coni()),     "Punti di ripresa")
        tabs_comune.addTab(self._scrollable(self._tab_consegna(ramo="comune")), "Esportazione")
        tabs_principali.addTab(tabs_comune, "Comune")

        tabs_altri_enti = QTabWidget()
        self._tabs_altri_enti = tabs_altri_enti
        tabs_altri_enti.addTab(self._scrollable(self._tab_chilometriche()), "Chilometriche")
        tabs_altri_enti.addTab(self._scrollable(self._tab_etichette()), "Etichette")
        tabs_altri_enti.addTab(self._scrollable(self._tab_suolo()), "Suolo comunale")
        tabs_altri_enti.addTab(self._scrollable(self._tab_screening()), "Screening territorio")
        _tab_rfi_w = self._tab_rfi()
        if _tab_rfi_w is not None:
            tabs_altri_enti.addTab(self._scrollable(_tab_rfi_w), "Istanze RFI")
        _tab_fasce_w = self._tab_fasce()
        if _tab_fasce_w is not None:
            tabs_altri_enti.addTab(self._scrollable(_tab_fasce_w), "Fasce di rispetto")
        # stessa scheda 'Esportazione' del ramo Comune, costruita una seconda
        # volta: è una copia indipendente (widget propri, impostazioni proprie)
        # e non un alias della prima, così puoi tenere per gli Altri Enti layer
        # e layout diversi da quelli del Comune senza che una scheda sovrascriva
        # i campi dell'altra
        tabs_altri_enti.addTab(self._scrollable(self._tab_consegna(ramo="altri_enti")), "Esportazione")
        tabs_principali.addTab(tabs_altri_enti, "Altri Enti")

        # Terzo ramo: interventi sul dato di partenza (CTR, DBSN, stradari), non
        # sui dati di progetto. 'Allinea cartografia' stava nel ramo Comune ma
        # non ha niente a che vedere con la pratica comunale: è preparazione
        # della base, come la pulizia degli edifici in carreggiata. Il ramo è
        # in fondo di proposito, per non spostare l'ordine delle schede già
        # note nei due rami esistenti.
        tabs_cartografia = QTabWidget()
        self._tabs_cartografia = tabs_cartografia
        tabs_cartografia.addTab(self._scrollable(self._tab_shp2gpkg()), "Shape → GeoPackage")
        tabs_cartografia.addTab(self._scrollable(self._tab_allinea()), "Allinea")
        tabs_cartografia.addTab(self._scrollable(self._tab_edifici()), "Edifici in carreggiata")
        _tab_un = self._tab_unisci()
        if _tab_un is not None:
            tabs_cartografia.addTab(self._scrollable(_tab_un), "Unisci tratte")
        tabs_principali.addTab(tabs_cartografia, "Cartografia di base")

        riga_fondo = QHBoxLayout()
        richiudi = QPushButton("Chiudi tutte le sezioni")
        richiudi.setToolTip(
            "Riporta tutte le schede alla vista d'insieme, come all'apertura del plugin.")
        richiudi.clicked.connect(self._chiudi_tutte_le_sezioni)
        riga_fondo.addWidget(richiudi)
        azzera = QPushButton("Ripristina i valori iniziali")
        azzera.setToolTip(
            "Il pannello ricorda i valori dei campi da una sessione all'altra: questo "
            "pulsante li riporta ai predefiniti del plugin.")
        azzera.clicked.connect(self._azzera_impostazioni)
        riga_fondo.addWidget(azzera)
        riga_fondo.addStretch()
        b = QPushButton("Chiudi"); b.clicked.connect(self.close)
        riga_fondo.addWidget(b)
        m.addLayout(riga_fondo)

    # ─── TAB 1 ────────────────────────────────────────────────────
    def _tab_pulizia(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("pulizia"))

        gb = self._gruppo("Layer"); f = QFormLayout(gb)
        self.cb_infra    = self._lcombo(QgsMapLayerProxyModel.LineLayer);   f.addRow("Infrastrutture:", self.cb_infra)
        self.cb_civici   = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Civici:", self.cb_civici)
        self.cb_pte      = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("ROE PTE:", self.cb_pte)
        self.cb_pozzetto = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Pozzetto:", self.cb_pozzetto)
        self.cb_cavo     = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True); f.addRow("Cavo ottico:", self.cb_cavo)
        self.cb_cavo_raccordo = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True); f.addRow("Cavo Raccordo (bretelle tra PTE):", self.cb_cavo_raccordo)
        self.spin_tol    = self._dspin(0.001, 100, 0.05, 3, " unità CRS progetto"); f.addRow("Tolleranza:", self.spin_tol)
        v.addWidget(gb)

        btn_d = QPushButton("Diagnostica tolleranza"); btn_d.clicked.connect(self._diagnostica)
        v.addWidget(btn_d)

        # R1
        gb1 = self._gruppo("1)  Tratte nuove Civico → PTE  (+  pozzetti compresi)"); l1 = QVBoxLayout(gb1)
        l1.addWidget(self._desc(
            "Seleziona la catena di tratte STATO='Nuovo' (Aerea compresa) da un Civico "
            "a un ROE PTE, fermandosi al primo PTE incontrato (incluso PTE Light). Se "
            "quel PTE Light è a sua volta collegato via Cavo Raccordo a un ALTRO PTE, "
            "l'intera catena è esclusa (raccordo condiviso con un altro permesso)."
        ))
        self.chk_no_cavo  = QCheckBox("Escludi tratte che corrono lungo il Cavo Ottico"); self.chk_no_cavo.setChecked(True);  l1.addWidget(self.chk_no_cavo)
        self.chk_pte_light = QCheckBox("Ferma la catena a qualsiasi ROE PTE (incluso PTE Light Diramatore)"); self.chk_pte_light.setChecked(True); l1.addWidget(self.chk_pte_light)
        b1 = QPushButton("Seleziona tratte Civico ↔ PTE + pozzetti compresi"); b1.clicked.connect(self._r1); l1.addWidget(b1)
        v.addWidget(gb1)

        # R1b — tratte a contatto diretto col Civico, indipendente dalla catena
        gb1b = self._gruppo("1b)  Tratte a contatto diretto col Civico (qualsiasi tipologia/stato) + pozzetto successivo"); l1b = QVBoxLayout(gb1b)
        l1b.addWidget(self._desc(
            "Indipendente dalla Regola 1: aggiunge alla selezione ogni tratta a "
            f"contatto col Civico (qualsiasi tipo/stato) + il Pozzetto successivo, "
            f"escluso se la tratta è TIPOLOGIA='{VAL_NO_DIG}', sede di un ROE PTE o "
            "toccata dal Cavo Ottico."
        ))
        b1b = QPushButton("Aggiungi tratte a contatto col Civico + pozzetto successivo"); b1b.clicked.connect(self._r1b); l1b.addWidget(b1b)
        v.addWidget(gb1b)

        # R2
        gb2 = self._gruppo("2)  Tratte che toccano PTE interno"); l2 = QVBoxLayout(gb2)
        l2.addWidget(QLabel(f"Tratte che toccano ROE PTE con TIPO in {VALORI_PTE_INT}."))
        self.chk_r2_nuovo = QCheckBox("Solo tratte STATO='Nuovo'"); self.chk_r2_nuovo.setChecked(True); l2.addWidget(self.chk_r2_nuovo)
        b2 = QPushButton("Seleziona tratte PTE interno"); b2.clicked.connect(self._r2); l2.addWidget(b2)
        v.addWidget(gb2)

        # R3
        gb3 = self._gruppo("3)  Pozzetti toccati solo da infrastruttura esistente"); l3 = QVBoxLayout(gb3)
        l3.addWidget(self._desc(
            f"Pozzetti con almeno una tratta ma nessuna interrata STATO='Nuovo' "
            f"(TIPOLOGIA='{VAL_AEREA}' Nuovo non conta come tratta nuova ai fini di "
            "questa regola)."
        ))
        b3 = QPushButton("Seleziona pozzetti solo su esistente"); b3.clicked.connect(self._r3); l3.addWidget(b3)
        v.addWidget(gb3)

        self.log_p = self._log_widget(110)
        v.addWidget(self._blocco_log(self.log_p))
        br = QPushButton("Rimuovi elementi selezionati (ultima operazione)")
        br.setStyleSheet("font-weight:bold"); br.clicked.connect(self._rimuovi); v.addWidget(br)
        v.addStretch(); return w

    # ─── TAB SHAPE → GEOPACKAGE ───────────────────────────────────
    # cartella stili di progetto (l'utente vuole 02_POZZETTO come default)
    _CARTELLA_STILI = os.path.join(
        os.path.expanduser("~"),
        "Documents", "Lavorazioni", "Permessi Fibercop",
        "00_Base", "03_Simbologia & Layout", "Stili Qgis")
    _STILE_DEFAULT_SHP2GPKG = "02_POZZETTO.qml"

    def _tab_shp2gpkg(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("shp2gpkg"))
        v.addWidget(self._desc(
            "Crea il gemello GeoPackage di uno shapefile, nello stesso percorso "
            "e col nome 02_POZZETTO (02_POZZETTO.gpkg, layer interno 02_POZZETTO), "
            "applica uno stile .qml (predefinito 02_POZZETTO) e ricollega il layer "
            "del progetto al GeoPackage appena creato. Lo shapefile su disco non "
            "viene toccato: il .gpkg è un file nuovo affiancato.\n\n"
            "Il layer che già sta nel progetto NON viene sostituito con uno nuovo: "
            "gli si fa un «ripara sorgente dati» verso il GeoPackage, quindi "
            "conserva stile, join, moduli, posizione nell'albero e i riferimenti "
            "dei layout di stampa. Il combo parte già puntato sullo shape dei "
            "pozzetti trovato nel progetto.\n\n"
            "Con lo stile 02_POZZETTO i pozzetti Esistenti che toccano una tratta di "
            "Rete Pubblica di 03 INFRASTRUTTURE vengono marcati Rete Pubblica "
            "(campo RETE_PUBB = 'SI') e disegnati in arancione."
        ))

        g_in = self._gruppo("Shape in ingresso", compresso=False); f_in = QFormLayout(g_in)
        self.cb_s2g_layer = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True)
        f_in.addRow("Layer del progetto:", self.cb_s2g_layer)
        # avviso mostrato solo quando non c'è uno shape pozzetti da convertire
        self.lbl_s2g_avviso = QLabel("")
        self.lbl_s2g_avviso.setWordWrap(True)
        self.lbl_s2g_avviso.setVisible(False)
        self.lbl_s2g_avviso.setStyleSheet("color:#b35c00;")
        f_in.addRow("", self.lbl_s2g_avviso)
        riga_file = QHBoxLayout()
        self.txt_s2g_file = QLineEdit(); self.txt_s2g_file.setPlaceholderText(
            "…oppure scegli un file .shp dal disco (ha la precedenza sul layer)")
        self.txt_s2g_file.setClearButtonEnabled(True)
        b_sfoglia = QPushButton("Sfoglia…"); b_sfoglia.clicked.connect(self._s2g_sfoglia_shp)
        riga_file.addWidget(self.txt_s2g_file); riga_file.addWidget(b_sfoglia)
        cont_file = QWidget(); cont_file.setLayout(riga_file)
        f_in.addRow("File .shp:", cont_file)
        v.addWidget(g_in)

        g_st = self._gruppo("Stile da applicare", compresso=False); f_st = QFormLayout(g_st)
        self.cb_s2g_stile = QComboBox()
        self._s2g_popola_stili()
        f_st.addRow("Stile (.qml):", self.cb_s2g_stile)
        # lo stile si riallinea da sé appena si sceglie lo shape o il layer:
        # senza questo bisogna ricordarsi di cambiarlo a mano, e il nome
        # sbagliato nel menu non si fa notare finché il disegno non esce storto
        self._s2g_stile_a_mano_per = None
        try:
            # Se lo stile lo scegli tu comanda il tuo, ma SOLO finche' resti su
            # quello shape. Un flag valido per sempre spegneva l'automatismo
            # alla prima scelta e da li' in poi ogni shape nuovo si portava
            # dietro lo stile vecchio: convertendo ARMADIO dopo POZZETTO
            # usciva il disegno dei pozzetti.
            self.cb_s2g_stile.activated.connect(
                lambda *_: setattr(self, "_s2g_stile_a_mano_per",
                                   self._s2g_sorgente_corrente()))
            self.txt_s2g_file.textChanged.connect(self._s2g_scegli_stile_adatto)
            self.cb_s2g_layer.layerChanged.connect(self._s2g_scegli_stile_adatto)
        except Exception as e:
            _log_avviso("aggancio della scelta automatica dello stile non riuscito", e)
        riga_st = QHBoxLayout()
        self.txt_s2g_stile_file = QLineEdit(); self.txt_s2g_stile_file.setPlaceholderText(
            "…oppure un .qml qualsiasi dal disco (ha la precedenza)")
        self.txt_s2g_stile_file.setClearButtonEnabled(True)
        b_st = QPushButton("Sfoglia…"); b_st.clicked.connect(self._s2g_sfoglia_stile)
        riga_st.addWidget(self.txt_s2g_stile_file); riga_st.addWidget(b_st)
        cont_st = QWidget(); cont_st.setLayout(riga_st)
        f_st.addRow("Stile da file:", cont_st)
        v.addWidget(g_st)

        self.chk_s2g_sostituisci = QCheckBox(
            "Ricollega il layer del progetto al GeoPackage (ripara sorgente dati, "
            "conserva stile e join). Se tolto, il GeoPackage viene aggiunto ACCANTO "
            "allo shape")
        self.chk_s2g_sostituisci.setChecked(True)
        v.addWidget(self.chk_s2g_sostituisci)

        b_go = QPushButton("Crea il gemello GeoPackage")
        b_go.setStyleSheet("font-weight:bold"); b_go.clicked.connect(self._esegui_shp2gpkg)
        v.addWidget(b_go)

        self.log_s2g = self._log_widget(150)
        v.addWidget(self._blocco_log(self.log_s2g))
        v.addStretch(); return w

    def _s2g_trova_shape_pozzetto(self):
        """Cerca nel progetto lo SHAPEFILE dei pozzetti da convertire in
        GeoPackage. Serve come default della scheda Shape → GeoPackage: il
        layer giusto è quasi sempre '02_POZZETTO' (o simile) con sorgente .shp.
        Criterio, dal più forte al più debole:
          1) nome che contiene 'pozzetto' E sorgente .shp;
          2) sorgente .shp il cui NOME FILE contiene 'pozzetto';
          3) un layer puntuale .shp se il progetto ne ha uno solo.
        Restituisce il layer o None. Non tocca nulla: solo lettura.
        """
        try:
            layers = list(self.project.mapLayers().values())
        except Exception:
            return None

        def _src_shp(l):
            try:
                s = (l.source() or "").split("|")[0]
                return s if s.lower().endswith(".shp") else None
            except Exception:
                return None

        # 1) nome layer con 'pozzetto' e sorgente shapefile
        for l in layers:
            try:
                if "pozzett" in (l.name() or "").lower() and _src_shp(l):
                    return l
            except Exception:
                pass
        # 2) nome del FILE con 'pozzetto'
        for l in layers:
            s = _src_shp(l)
            if s and "pozzett" in os.path.basename(s).lower():
                return l
        # 3) unico layer puntuale su shapefile
        punt = []
        for l in layers:
            s = _src_shp(l)
            if not s:
                continue
            try:
                if l.geometryType() == QgsWkbTypes.PointGeometry:
                    punt.append(l)
            except Exception:
                pass
        if len(punt) == 1:
            return punt[0]
        return None

    def _s2g_imposta_default(self):
        """Preseleziona nel combo lo shape pozzetto trovato nel progetto.

        Se non c'è nessuno shapefile di pozzetti, il combo viene lasciato
        VUOTO invece di tenere il layer che QGIS ci mette di suo (il primo
        vettoriale del progetto, in pratica '01_ARMADIO OTTICO'). Un default
        plausibile ma sbagliato è peggio di nessun default: qui si riscrive la
        sorgente dati di un layer, e puntare l'armadio al GeoPackage dei
        pozzetti è un danno che si nota tardi.

        Il caso «non trovato» è normale, non è un errore: nei progetti già
        lavorati 02_POZZETTO è GIÀ un .gpkg e non c'è nulla da convertire.
        """
        if not hasattr(self, "cb_s2g_layer"):
            return
        try:
            lay = self._s2g_trova_shape_pozzetto()
            if lay is not None:
                self.cb_s2g_layer.setLayer(lay)
                if hasattr(self, "lbl_s2g_avviso"):
                    self.lbl_s2g_avviso.setText("")
                    self.lbl_s2g_avviso.setVisible(False)
            else:
                self.cb_s2g_layer.setLayer(None)
                if hasattr(self, "lbl_s2g_avviso"):
                    self.lbl_s2g_avviso.setText(
                        "Nessuno shapefile di pozzetti nel progetto: scegli tu il "
                        "layer da convertire.\nSe 02_POZZETTO è già un GeoPackage, "
                        "la conversione è già stata fatta.")
                    self.lbl_s2g_avviso.setVisible(True)
        except Exception as e:
            _log_avviso("preselezione shape pozzetto non riuscita", e)

    def _s2g_popola_stili(self):
        """Riempie il combo con i .qml della cartella stili di progetto.

        Si scartano i backup (…_backup_20261006_091001.qml): sono copie di
        servizio, non stili da applicare, e in una cartella senza lo stile
        giusto finivano per essere la prima voce e quindi quella scelta.
        """
        self.cb_s2g_stile.clear()
        cartella = self._CARTELLA_STILI
        trovati = []
        try:
            if os.path.isdir(cartella):
                trovati = sorted(f for f in os.listdir(cartella)
                                 if f.lower().endswith(".qml")
                                 and "_backup" not in f.lower())
        except Exception as e:
            _log_avviso("lettura cartella stili non riuscita", e)
        if not trovati:
            self.cb_s2g_stile.addItem("(nessuno stile trovato nella cartella)", "")
            return
        for nome in trovati:
            self.cb_s2g_stile.addItem(nome, os.path.join(cartella, nome))
        self._s2g_scegli_stile_adatto()

    def _s2g_sorgente_corrente(self):
        """Che cosa si sta convertendo adesso: percorso dello shape o layer.

        Serve a capire se la scelta a mano dello stile riguarda ancora questo
        dato o un altro di prima.
        """
        try:
            shp = (self.txt_s2g_file.text() or "").strip()
            if shp:
                return os.path.normcase(os.path.abspath(shp))
            lyr = self.cb_s2g_layer.currentLayer()
            return ("layer:" + lyr.id()) if lyr else ""
        except Exception:
            return ""

    def _s2g_scegli_stile_adatto(self, *args):
        """Sceglie da sé lo stile che corrisponde allo shape in ingresso.

        Prima lo stile predefinito se c'e'; altrimenti quello il cui nome
        richiama lo shapefile scelto (POZZETTO.shp → 02_POZZETTO.qml), che è
        quasi sempre la risposta giusta e risparmia una scelta a mano.
        """
        try:
            if (self._s2g_sorgente_corrente()
                    and getattr(self, "_s2g_stile_a_mano_per", None)
                    == self._s2g_sorgente_corrente()):
                return      # su QUESTO shape hai scelto tu: non si tocca
            nomi = [self.cb_s2g_stile.itemText(i)
                    for i in range(self.cb_s2g_stile.count())]
            if not nomi:
                return
            # Prima lo shape scelto, POI il predefinito: convertendo
            # ARMADIO.shp lo stile giusto e' quello dell'armadio, non quello
            # dei pozzetti solo perche' e' il predefinito della scheda.
            shp = (self.txt_s2g_file.text() or "").strip()
            base = os.path.splitext(os.path.basename(shp))[0].lower() if shp else ""
            if not base:
                lyr = self.cb_s2g_layer.currentLayer()
                base = (lyr.name() or "").lower() if lyr else ""
            chiave = "".join(ch for ch in base if ch.isalnum())
            # sotto i 4 caratteri la somiglianza non significa niente:
            # un layer chiamato 'A' corrisponderebbe a quasi tutti gli stili
            if len(chiave) >= 4:
                # si preferisce la corrispondenza piu' stretta: 'POZZETTO'
                # pesca '02_POZZETTO', non '01_ARMADIO OTTICO'
                migliore, lung = -1, None
                for i, nome in enumerate(nomi):
                    pulito = "".join(ch for ch in os.path.splitext(nome)[0].lower()
                                     if ch.isalnum())
                    if chiave in pulito or pulito.endswith(chiave):
                        if lung is None or len(pulito) < lung:
                            migliore, lung = i, len(pulito)
                if migliore >= 0:
                    self.cb_s2g_stile.setCurrentIndex(migliore); return
            atteso = self._STILE_DEFAULT_SHP2GPKG.lower()
            for i, nome in enumerate(nomi):
                if nome.lower() == atteso:
                    self.cb_s2g_stile.setCurrentIndex(i); return
            self.cb_s2g_stile.setCurrentIndex(0)
        except Exception as e:
            _log_avviso("scelta automatica dello stile non riuscita", e)

    def _s2g_sfoglia_shp(self):
        percorso, _ = QFileDialog.getOpenFileName(
            self, "Scegli lo shapefile", "", "Shapefile (*.shp)")
        if percorso:
            self.txt_s2g_file.setText(percorso)

    def _s2g_sfoglia_stile(self):
        percorso, _ = QFileDialog.getOpenFileName(
            self, "Scegli lo stile", self._CARTELLA_STILI, "Stile QGIS (*.qml)")
        if percorso:
            self.txt_s2g_stile_file.setText(percorso)

    def _esegui_shp2gpkg(self):
        # 1) sorgente: il file .shp del campo ha la precedenza, poi il layer scelto
        file_txt = self.txt_s2g_file.text().strip()
        layer_scelto = self.cb_s2g_layer.currentLayer()
        sorgente_path = None
        if file_txt:
            sorgente_path = file_txt
        elif layer_scelto is not None:
            sorgente_path = layer_scelto.source().split("|")[0]
        if not sorgente_path:
            QMessageBox.warning(self, "Nessuno shape",
                "Scegli un layer del progetto o un file .shp dal disco."); return
        sorgente_path = os.path.abspath(sorgente_path)
        if not sorgente_path.lower().endswith(".shp") or not os.path.isfile(sorgente_path):
            QMessageBox.warning(self, "Non è uno shapefile",
                "Il file scelto non è uno shapefile valido:\n%s" % sorgente_path); return

        # 2) carica la sorgente da disco (non dalla copia in progetto, così lo
        #    stile eventualmente non salvato non interferisce)
        base_nome = os.path.splitext(os.path.basename(sorgente_path))[0]
        src = QgsVectorLayer(sorgente_path, base_nome, "ogr")
        if not src.isValid():
            QMessageBox.critical(self, "Shape non leggibile",
                "Impossibile aprire lo shapefile:\n%s" % sorgente_path); return

        # nome fisso del GeoPackage e del layer interno: il gemello del pozzetto
        # deve sempre chiamarsi 02_POZZETTO (richiesta operativa), a prescindere
        # dal nome dello shape di partenza.
        nome_gpkg = "02_POZZETTO"

        # 3) percorso gemello .gpkg (stesso percorso dello shape, nome 02_POZZETTO)
        gpkg_path = os.path.join(os.path.dirname(sorgente_path), nome_gpkg + ".gpkg")
        gpkg_norm = os.path.normcase(gpkg_path)

        # 4) libera il .gpkg da eventuali lock SENZA perdere i layer che lo usano.
        #    Attenzione: qui prima si faceva removeMapLayer() sui layer che
        #    puntavano al GeoPackage da riscrivere. Ma nei progetti già lavorati
        #    è proprio '02_POZZETTO' a puntare lì: veniva buttato via con tutto
        #    il suo stile, i join e i riferimenti dei layout, e più avanti al suo
        #    posto ne nasceva uno NUOVO. Il risultato per chi lo usa è «non ripara
        #    la sorgente, me ne crea uno nuovo».
        #    Ora i layer vengono ripuntati TEMPORANEAMENTE allo shapefile di
        #    partenza: il lock sul .gpkg cade, ma l'oggetto layer resta vivo e
        #    alla fine lo si riporta sul GeoPackage riscritto.
        da_ripuntare = []
        for lid, l in list(self.project.mapLayers().items()):
            try:
                s = l.source().split("|")[0]
                if s and os.path.normcase(os.path.abspath(s)) == gpkg_norm:
                    da_ripuntare.append(lid)
                    l.setDataSource(sorgente_path, l.name(), "ogr",
                                    QgsDataProvider.ProviderOptions())
            except Exception as e:
                _log_avviso("sgancio temporaneo del layer dal gpkg non riuscito", e)
        if os.path.exists(gpkg_path):
            try:
                os.remove(gpkg_path)
            except OSError:
                pass

        # 5) scrivi il GeoPackage
        opz = QgsVectorFileWriter.SaveVectorOptions()
        opz.driverName = "GPKG"
        opz.layerName = nome_gpkg
        opz.fileEncoding = "UTF-8"
        opz.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        errore = QgsVectorFileWriter.writeAsVectorFormatV3(
            src, gpkg_path, self.project.transformContext(), opz)
        codice = errore[0] if isinstance(errore, tuple) else errore
        if codice != QgsVectorFileWriter.NoError:
            dett = errore[1] if isinstance(errore, tuple) and len(errore) > 1 else str(errore)
            QMessageBox.critical(self, "Errore nel salvataggio",
                "Impossibile scrivere il GeoPackage:\n%s" % dett); return

        # 6) ricarica il gpkg appena scritto
        gpkg_lyr = QgsVectorLayer("%s|layername=%s" % (gpkg_path, nome_gpkg), nome_gpkg, "ogr")
        if not gpkg_lyr.isValid():
            QMessageBox.warning(self, "Scritto ma non ricaricato",
                "Il GeoPackage è stato scritto in %s ma non è stato possibile "
                "ricaricarlo nel progetto." % gpkg_path); return

        # 7) stile: file .qml del campo (precedenza) o quello scelto nel combo
        stile_path = self.txt_s2g_stile_file.text().strip() or self.cb_s2g_stile.currentData()

        # 7-bis) pozzetti di RETE PUBBLICA. I pozzetti non hanno nei loro
        #    attributi l'informazione: la si deduce dalla geometria. Un pozzetto
        #    'Esistente' che tocca una tratta di Rete Pubblica di 03
        #    INFRASTRUTTURE (stessa regola dello stile delle tratte) diventa
        #    Rete Pubblica: campo RETE_PUBB = 'SI', che lo stile 02_POZZETTO
        #    colora di arancione e la macro mette nella tabella 02b. Si fa PRIMA
        #    di applicare lo stile e di ricollegare il layer, cosi' entrambi
        #    vedono gia' il campo.
        esito_rp = None
        if stile_path and "pozzett" in os.path.basename(stile_path).lower():
            infra = self._find_layer("03 INFRASTRUTTURE", "03_INFRASTRUTTURE", "INFRASTRUTTURE")
            if infra is None:
                esito_rp = {"errore": "layer '03 INFRASTRUTTURE' non trovato nel progetto: "
                                      "pozzetti di Rete Pubblica NON marcati"}
            else:
                try:
                    try:
                        from . import ftth_rete_pubblica as _rp
                    except ImportError:
                        import ftth_rete_pubblica as _rp
                    esito_rp = _rp.marca_pozzetti_rete_pubblica(gpkg_lyr, infra)
                except Exception as e:
                    _log_avviso("marcatura pozzetti Rete Pubblica non riuscita", e)
                    esito_rp = {"errore": str(e)}
        stile_ok = False
        if stile_path and os.path.isfile(stile_path):
            ris = gpkg_lyr.loadNamedStyle(stile_path)
            stile_ok = bool(ris[1]) if isinstance(ris, tuple) else bool(ris)
            if stile_ok:
                # prima di scrivere lo stile DENTRO il gpkg: gli SVG vanno
                # incorporati, altrimenti il collega che riceve il
                # GeoPackage eredita percorsi che sul suo pc non esistono
                self._rendi_stile_portatile(gpkg_lyr, stile_path)
                try:
                    gpkg_lyr.saveStyleToDatabase(nome_gpkg, "Stile %s" % nome_gpkg, True, "")
                except Exception as e:
                    _log_avviso("salvataggio stile nel gpkg non riuscito", e)

        # 8) posiziona nel progetto. IMPORTANTE: NON si sostituisce il layer del
        #    progetto con uno nuovo. Se nel progetto esiste già un layer che punta
        #    allo shape (o a un vecchio 02_POZZETTO.gpkg), gli si fa un "ripara
        #    sorgente dati" (setDataSource) verso il GeoPackage appena creato: così
        #    il layer resta LO STESSO oggetto e conserva id, stile, join, moduli,
        #    posizione nell'albero e ogni riferimento da parte di layout e regole.
        sostituisci = self.chk_s2g_sostituisci.isChecked()
        root = self.project.layerTreeRoot()
        uri_nuova = "%s|layername=%s" % (gpkg_path, nome_gpkg)

        # individua il layer del progetto da riparare. Si cerca in tre modi,
        # perché il layer da ricollegare quasi mai punta allo shape di partenza:
        #   a) uno dei layer che PRIMA puntavano al GeoPackage da riscrivere
        #      (caso normale nei progetti già lavorati: 02_POZZETTO è già .gpkg,
        #      e lo shape sta solo sul disco, non nel progetto);
        #   b) un layer che punta davvero allo shapefile di partenza
        #      (progetto appena creato, non ancora convertito);
        #   c) un layer che si chiama come il GeoPackage di destinazione.
        # Senza (a) e (c) la ricerca falliva sempre nei progetti reali e il
        # plugin finiva per aggiungere un layer nuovo invece di riparare.
        vecchio_id = None
        for lid in da_ripuntare:
            if self.project.mapLayer(lid) is not None:
                vecchio_id = lid; break
        if vecchio_id is None:
            for lid, l in list(self.project.mapLayers().items()):
                try:
                    s = l.source().split("|")[0]
                    if s and os.path.normcase(os.path.abspath(s)) == os.path.normcase(sorgente_path):
                        vecchio_id = lid; break
                except Exception:
                    pass
        if vecchio_id is None:
            for lid, l in list(self.project.mapLayers().items()):
                if (l.name() or "").strip().lower() == nome_gpkg.lower():
                    vecchio_id = lid; break

        riparato = False
        if sostituisci and vecchio_id is not None:
            lay_vecchio = self.project.mapLayer(vecchio_id)
            if lay_vecchio is not None:
                try:
                    # QGIS >= 3.20: ricollega il layer esistente alla nuova sorgente
                    lay_vecchio.setDataSource(
                        uri_nuova, nome_gpkg, "ogr",
                        QgsDataProvider.ProviderOptions())
                    riparato = lay_vecchio.isValid()
                except Exception as e:
                    _log_avviso("ripara sorgente dati non riuscito, ripiego sull'aggiunta", e)
                if riparato:
                    # lo stile scelto va applicato al layer riparato
                    if stile_path and os.path.isfile(stile_path):
                        try:
                            lay_vecchio.loadNamedStyle(stile_path)
                            self._rendi_stile_portatile(lay_vecchio, stile_path)
                        except Exception as e:
                            _log_avviso("applicazione stile al layer riparato non riuscita", e)
                    lay_vecchio.setName(nome_gpkg)
                    lay_vecchio.triggerRepaint()
                    # il layer temporaneo appena letto da disco non serve più
                    gpkg_lyr = lay_vecchio

        if not riparato:
            # nessun layer da riparare (o ripara non disponibile): aggiungi il
            # GeoPackage all'albero, nella posizione dello shape se c'era
            gruppo_padre = root
            indice = 0
            if vecchio_id is not None:
                nodo_vecchio = root.findLayer(vecchio_id)
                if nodo_vecchio is not None:
                    gruppo_padre = nodo_vecchio.parent() or root
                    try:
                        indice = gruppo_padre.children().index(nodo_vecchio)
                    except ValueError:
                        indice = 0
            self.project.addMapLayer(gpkg_lyr, False)
            gruppo_padre.insertLayer(indice, gpkg_lyr)
            if sostituisci and vecchio_id is not None:
                self.project.removeMapLayer(vecchio_id)

        # qualunque altro layer sganciato al punto 4 va riportato sul GeoPackage
        # riscritto: lasciarlo puntato allo shapefile sarebbe un effetto collaterale
        # silenzioso dell'operazione.
        for lid in da_ripuntare:
            if lid == vecchio_id and riparato:
                continue
            l = self.project.mapLayer(lid)
            if l is None:
                continue
            try:
                l.setDataSource(uri_nuova, l.name(), "ogr",
                                QgsDataProvider.ProviderOptions())
                l.triggerRepaint()
            except Exception as e:
                _log_avviso("riaggancio del layer al gpkg non riuscito", e)

        gpkg_lyr.triggerRepaint()

        if riparato:
            azione = ("è stato RICOLLEGATO al layer «%s» già nel progetto "
                      "(ripara sorgente dati: stile, join e layout conservati)"
                      % gpkg_lyr.name())
        elif vecchio_id is not None:
            azione = "è stato AGGIUNTO accanto al layer esistente"
        else:
            azione = "è stato aggiunto al progetto (nessun layer da ricollegare)"
        msg = ("GeoPackage creato:\n%s\n(%d elementi) — %s.\nStile: %s"
               % (gpkg_path, gpkg_lyr.featureCount(), azione,
                  (os.path.basename(stile_path) if stile_ok else "NON applicato")))
        if esito_rp is not None:
            if esito_rp.get("errore"):
                msg += "\n\nRete Pubblica: ATTENZIONE — %s." % esito_rp["errore"]
            else:
                msg += ("\n\nRete Pubblica: %d tratte in 03 INFRASTRUTTURE → %d pozzetti "
                        "Esistenti marcati (campo RETE_PUBB = 'SI', in arancione)."
                        % (esito_rp["n_tratte"], esito_rp["n_si"]))
        self.log_s2g.setPlainText(msg)
        QMessageBox.information(self, "Fatto", msg)

    # ─── TAB ALLINEA CARTOGRAFIA ──────────────────────────────────
    def _tab_allinea(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("allinea"))
        v.addWidget(self._desc(
            "Sposta in blocco gli elementi della rete per allinearli alla cartografia "
            "ufficiale (WMS o shapefile). Un'unica trasformazione (traslazione + "
            "rotazione + scala) viene applicata a tutti i layer scelti insieme, non "
            "elemento per elemento, per non rompere i collegamenti della rete."
        ))

        gbl = self._gruppo("Layer da spostare insieme"); fl = QFormLayout(gbl)
        self.cb_al_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True); fl.addRow("Armadio Ottico:", self.cb_al_armadio)
        self.cb_al_infra   = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  fl.addRow("Infrastrutture:", self.cb_al_infra)
        self.cb_al_poz     = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True);  fl.addRow("Pozzetto:", self.cb_al_poz)
        self.cb_al_pte     = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True);  fl.addRow("ROE PTE:", self.cb_al_pte)
        self.cb_al_cavo    = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);   fl.addRow("Cavo Ottico:", self.cb_al_cavo)
        self.cb_al_raccordo = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  fl.addRow("Cavo Raccordo:", self.cb_al_raccordo)
        self.chk_al_solo_sel = QCheckBox("Sposta SOLO gli elementi selezionati (i layer senza selezione attiva vengono saltati per intero, non spostati tutti)")
        fl.addRow(self.chk_al_solo_sel)
        v.addWidget(gbl)

        gbb = self._gruppo("Punti di controllo manuali (es. sopra un WMS)"); fb = QVBoxLayout(gbb)
        fb.addWidget(self._desc(
            "Clicca coppie di punti corrispondenti: uno sulla TUA rete, uno sulla "
            "cartografia di riferimento. Servono almeno 2 coppie; con più coppie la "
            "trasformazione calcolata è più precisa."
        ))
        self.lst_al_punti = QListWidget(); self.lst_al_punti.setMaximumHeight(100); fb.addWidget(self.lst_al_punti)
        self.lbl_al_stato = QLabel(""); fb.addWidget(self.lbl_al_stato)
        rb = QHBoxLayout()
        bb_add = QPushButton("Aggiungi coppia di punti sulla mappa"); bb_add.clicked.connect(self._avvia_cattura_coppia); rb.addWidget(bb_add)
        bb_del = QPushButton("Rimuovi ultima coppia"); bb_del.clicked.connect(self._rimuovi_ultima_coppia); rb.addWidget(bb_del)
        bb_clr = QPushButton("Svuota"); bb_clr.clicked.connect(self._svuota_coppie); rb.addWidget(bb_clr)
        fb.addLayout(rb)
        bb_calc = QPushButton("Calcola trasformazione da punti di controllo"); bb_calc.clicked.connect(self._calcola_trasf_punti)
        fb.addWidget(bb_calc)
        v.addWidget(gbb)

        self.lbl_al_preview = QLabel("Nessuna trasformazione calcolata."); self.lbl_al_preview.setWordWrap(True)
        v.addWidget(self.lbl_al_preview)
        bapply = QPushButton("Applica trasformazione ai layer selezionati sopra")
        bapply.setStyleSheet("font-weight:bold"); bapply.clicked.connect(self._applica_trasformazione)
        v.addWidget(bapply)
        self.log_al = self._log_widget(130)
        v.addWidget(self._blocco_log(self.log_al))
        v.addStretch(); return w

    # ─── TAB 2 ────────────────────────────────────────────────────
    # widget che compongono UNA copia della scheda 'Esportazione'. La scheda è
    # costruita due volte (ramo Comune e ramo Altri Enti): ogni copia registra
    # i propri widget in un contesto e, prima di eseguire l'azione di un
    # pulsante, il contesto della copia da cui è arrivato il click viene reso
    # quello "attivo" (_attiva_consegna). Così la logica di _genera_consegna /
    # _esporta_atlante / merge PDF resta scritta una volta sola su self.<attr>,
    # ma legge sempre i valori della scheda che l'utente sta effettivamente
    # usando, invece di quelli dell'ultima copia costruita.
    _ATTR_CONSEGNA = (
        "cb_c_foto", "cb_c_armadio", "cb_c_infra", "cb_c_strada", "cb_c_poz",
        "spin_c_dist", "chk_c_join_armadio", "chk_c_join_strada",
        "chk_c_armadio_su_scavi",
        "chk_c_carica", "log_c",
        "lst_atlante", "chk_atlante_vettoriale", "chk_atlante_semplifica",
        "chk_atlante_jpeg_lossy", "log_atlante",
        "lst_merge_pdf", "log_merge",
    )

    # widget del gruppo 'Evidenza strade interessate': presenti SOLO nella copia
    # Altri Enti (nel ramo Comune l'evidenza non ha senso e il gruppo è omesso)
    _ATTR_EVIDENZA = (
        "spin_ev_larghezza", "spin_ev_tolleranza", "spin_ev_opacita",
        "chk_ev_solo_selez", "chk_ev_solo_nuovo", "log_ev",
        "spin_ev_margine", "spin_ev_vuoto", "chk_ev_salda", "chk_ev_intere",
        "btn_ev_colore", "chk_ev_etichetta", "spin_ev_corpo_nome",
        "chk_ev_spegni_stradario",
        "cb_ev_stradario", "cb_ev_stile", "spin_ev_passo", "spin_ev_spessore",
        "spin_ev_angolo",
    )

    def _attiva_consegna(self, ctx):
        # guardia anti cross-talk: se un widget nuovo viene registrato su self
        # ma dimenticato in _ATTR_CONSEGNA (o viceversa), le due copie della
        # scheda condividerebbero quel widget in silenzio — meglio fallire
        # subito e in modo leggibile durante lo sviluppo
        attesi = set(self._ATTR_CONSEGNA)
        if ctx.get("ramo") == "altri_enti":
            attesi |= set(self._ATTR_EVIDENZA)
        mancanti = attesi - set(ctx)
        if mancanti:
            raise RuntimeError(
                "Contesto 'Esportazione' incompleto, widget non registrati: "
                + ", ".join(sorted(mancanti)))
        for nome, widget in ctx.items():
            setattr(self, nome, widget)

    def _collega_consegna(self, bottone, azione, ctx):
        """Collega il pulsante all'azione attivando prima il contesto (cioè il
        set di widget) della copia di scheda a cui il pulsante appartiene."""
        bottone.clicked.connect(lambda *_: (self._attiva_consegna(ctx), azione()))

    def _tab_consegna(self, ramo="comune"):
        ctx = {}  # riempito in fondo, quando tutti i widget esistono
        ctx["ramo"] = ramo
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("consegna"))
        f = QFormLayout()
        self.cb_c_foto    = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Punti di ripresa (Foto):", self.cb_c_foto)
        self.cb_c_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True); f.addRow("Armadio Ottico:", self.cb_c_armadio)
        self.cb_c_infra   = self._lcombo(QgsMapLayerProxyModel.LineLayer);   f.addRow("Infrastrutture (Scavi):", self.cb_c_infra)
        self.cb_c_strada  = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  f.addRow("Stradario:", self.cb_c_strada)
        self.cb_c_poz     = self._lcombo(QgsMapLayerProxyModel.PointLayer);  f.addRow("Pozzetto:", self.cb_c_poz)
        self.spin_c_dist  = self._dspin(0, 1e6, 0, 1, " (0=nessun limite)"); f.addRow("Distanza max join:", self.spin_c_dist)
        v.addLayout(f)

        v.addWidget(self._desc(
            "Join 'vettore più vicino' → 3 shape: ARMADI_FOTO (un Armadio + Punto di "
            "Ripresa più vicino; CIVICO='999' diventa 'SNC'), SCAVI_STRADE (Infrastrutture + "
            "Stradario, con LUNGHEZZA/Lungh calcolati su '03 INFRASTRUTTURE'), "
            "POZZETTI_STRADE (Pozzetto + Stradario). Campi duplicati "
            "diventano 'fid_2' ecc.; righe con 'n'≠1 (pareggio di distanza) rimosse."
        ))

        gbj = self._gruppo("Shape da joinare (plus: l'automatismo resta attivo di default)")
        lj = QVBoxLayout(gbj)
        lj.addWidget(self._desc(
            "Un layer impostato sopra entra automaticamente nel join; deseleziona qui "
            "solo per escluderlo senza rimuoverlo dal campo."
        ))
        self.chk_c_join_strada  = QCheckBox("Abbina lo Stradario a SCAVI_STRADE e POZZETTI_STRADE"); self.chk_c_join_strada.setChecked(True);  lj.addWidget(self.chk_c_join_strada)
        self.chk_c_join_armadio = QCheckBox("Genera ARMADI_FOTO abbinando l'Armadio Ottico ai Punti di Ripresa"); self.chk_c_join_armadio.setChecked(True); lj.addWidget(self.chk_c_join_armadio)
        self.chk_c_armadio_su_scavi = QCheckBox("Aggiungi anche l'Armadio Ottico ai join di SCAVI_STRADE e POZZETTI_STRADE"); self.chk_c_armadio_su_scavi.setChecked(False)
        self.chk_c_armadio_su_scavi.setToolTip(
            "Opzione avanzata: normalmente scavi e pozzetti si abbinano solo allo "
            "Stradario. Attiva questa spunta per aggiungere ai due shape anche i campi "
            "dell'Armadio Ottico più vicino (doppio join).")
        lj.addWidget(self.chk_c_armadio_su_scavi)
        v.addWidget(gbj)

        self.chk_c_carica = QCheckBox("Carica i 3 shape nel progetto al termine"); self.chk_c_carica.setChecked(True)
        v.addWidget(self.chk_c_carica)
        b = QPushButton("Seleziona cartella e genera i 3 shape")
        b.setStyleSheet("font-weight:bold")
        self._collega_consegna(b, self._genera_consegna, ctx); v.addWidget(b)
        self.log_c = self._log_widget(130)
        v.addWidget(self._blocco_log(self.log_c))

        gba = self._gruppo("Esporta PDF (Atlante)"); va = QVBoxLayout(gba)
        va.addWidget(self._desc(
            "Esporta in PDF, via Atlante, i layout già presenti nel progetto (layer di "
            "copertura configurato nel Compositore, non da qui). Seleziona uno o più "
            "layout, poi genera: l'Atlante viene attivato e verificato (elementi > 0) "
            "prima di ogni esportazione, un PDF per layout nella cartella scelta."
        ))
        ra = QHBoxLayout()
        self.lst_atlante = QListWidget(); self.lst_atlante.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_atlante.setMaximumHeight(110); ra.addWidget(self.lst_atlante)
        va.addLayout(ra)
        self._popola_elenco_layout()
        baggiorna = QPushButton("Aggiorna elenco layout")
        self._collega_consegna(baggiorna, self._aggiorna_elenco_layout, ctx); va.addWidget(baggiorna)
        self.chk_atlante_vettoriale = QCheckBox("PDF vettoriale (più veloce, consigliato)")
        self.chk_atlante_vettoriale.setChecked(True)
        self.chk_atlante_vettoriale.setToolTip(
            "Evita la rasterizzazione automatica di ogni pagina: esportazione più "
            "rapida e file più leggeri. Disattiva solo se nel layout usi modalità di "
            "fusione/trasparenza (blend mode) che richiedono il rendering raster."
        )
        va.addWidget(self.chk_atlante_vettoriale)
        self.chk_atlante_semplifica = QCheckBox("Semplifica geometrie in esportazione (più veloce)")
        self.chk_atlante_semplifica.setChecked(True)
        self.chk_atlante_semplifica.setToolTip(
            "Riduce i vertici delle geometrie complesse in base alla scala di stampa: "
            "accelera il rendering, differenza visiva trascurabile alla scala della tavola."
        )
        va.addWidget(self.chk_atlante_semplifica)
        self.chk_atlante_jpeg_lossy = QCheckBox("Comprimi immagini con JPEG lossy (più veloce/leggero, come nell'esportazione standard di QGIS)")
        self.chk_atlante_jpeg_lossy.setChecked(True)
        self.chk_atlante_jpeg_lossy.setToolTip(
            "Corrisponde alla casella 'Compressione immagini senza perdita' della "
            "finestra 'Esporta come PDF' di QGIS, qui lasciata DESELEZIONATA (quindi "
            "compressione JPEG con perdita): immagini raster incorporate (es. sfondi "
            "WMS/ortofoto) più leggere e rendering più rapido. Disattiva questa "
            "opzione — cioè attiva la compressione senza perdita — solo se ti serve "
            "la massima qualità delle immagini raster nel PDF finale."
        )
        va.addWidget(self.chk_atlante_jpeg_lossy)
        besporta = QPushButton("Esporta PDF dei layout selezionati"); besporta.setStyleSheet("font-weight:bold")
        self._collega_consegna(besporta, self._esporta_atlante, ctx); va.addWidget(besporta)
        self.log_atlante = self._log_widget(130)
        va.addWidget(self._blocco_log(self.log_atlante))
        v.addWidget(gba)

        gbm = self._gruppo("Unisci PDF in un ordine stabilito"); vm = QVBoxLayout(gbm)
        vm.addWidget(self._desc(
            "Unisce più PDF in un unico file, nell'ordine mostrato in elenco. Dopo "
            "un'esportazione qui sopra l'elenco si popola da solo, nello stesso ordine "
            "di esportazione; puoi anche aggiungere altri PDF a mano e riordinare o "
            "rimuovere con i pulsanti sotto. Richiede il pacchetto Python 'pypdf' (o "
            "'PyPDF2') nell'ambiente di QGIS."
        ))
        self.lst_merge_pdf = QListWidget()
        self.lst_merge_pdf.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.lst_merge_pdf.setMaximumHeight(110)
        vm.addWidget(self.lst_merge_pdf)
        rm = QHBoxLayout()
        bm_add = QPushButton("Aggiungi PDF…")
        self._collega_consegna(bm_add, self._merge_pdf_aggiungi, ctx); rm.addWidget(bm_add)
        bm_up = QPushButton("↑ Su")
        self._collega_consegna(bm_up, lambda: self._merge_pdf_sposta(-1), ctx); rm.addWidget(bm_up)
        bm_down = QPushButton("↓ Giù")
        self._collega_consegna(bm_down, lambda: self._merge_pdf_sposta(1), ctx); rm.addWidget(bm_down)
        bm_rm = QPushButton("Rimuovi")
        self._collega_consegna(bm_rm, self._merge_pdf_rimuovi, ctx); rm.addWidget(bm_rm)
        vm.addLayout(rm)
        bm_merge = QPushButton("Unisci PDF nell'ordine mostrato"); bm_merge.setStyleSheet("font-weight:bold")
        self._collega_consegna(bm_merge, self._merge_pdf_unisci, ctx); vm.addWidget(bm_merge)
        self.log_merge = self._log_widget(90)
        vm.addWidget(self._blocco_log(self.log_merge))
        v.addWidget(gbm)

        # l'evidenza delle strade interessate ha senso solo per gli Altri Enti
        # (strade classificate SS/SP/… da interpellare): nel ramo Comune non
        # serve, quindi il gruppo compare solo nella copia 'altri_enti'
        if ramo == "altri_enti":
            v.addWidget(self._gruppo_evidenza_strade(ctx))

        ctx.update({nome: getattr(self, nome) for nome in self._ATTR_CONSEGNA})
        if ramo == "altri_enti":
            ctx.update({nome: getattr(self, nome) for nome in self._ATTR_EVIDENZA})
        self._contesti_consegna.append(ctx)

        v.addStretch(); return w

    # ─── TAB 3 ────────────────────────────────────────────────────
    def _tab_coni(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("coni"))

        gbt = self._gruppo("Coni per Tavola di Inquadramento (3 a tavola, di più se servono per gli Armadi)"); vt = QVBoxLayout(gbt)
        vt.addWidget(self._desc(
            "Per ogni tavola: un cono per OGNI Armadio Ottico presente (priorità "
            "assoluta, anche oltre 3), poi fino a un totale di 3 con, in ordine di "
            "priorità, attraversamenti Provinciale, ANAS, Stradario (generici — la "
            "maggioranza dei casi), Pozzetto Nuovo e infine punto medio della tratta "
            "Infrastruttura Nuova; a parità vince il candidato più vicino al centro "
            "tavola. Infrastrutture considerate: solo STATO='Nuovo', esclusa TIPOLOGIA="
            f"'{VAL_AEREA}' o vuota. Ogni cono è la proiezione perpendicolare del "
            "soggetto sulla tratta di Stradario più vicina realmente dentro la tavola "
            "(raggio di ricerca che si allarga se serve), riportato dentro il "
            "perimetro se necessario. Se il soggetto giace già sulla strada stessa "
            "(attraversamenti), la camera resta sulla stessa linea della strada ma "
            "spostata della Distanza di ripresa, con inquadratura perpendicolare — "
            "non 'sopra' il soggetto. Due controlli anti-duplicato indipendenti "
            "evitano sia coni sullo stesso soggetto sia sulla stessa posizione-camera. "
            "Stradario, Provinciali e ANAS vengono letti solo entro ARLO AREA (dalla "
            "scheda 'Keyplan e tavole') allargata del margine sotto — utile con shape "
            "nazionali (es. Stradario Italia) per non caricarli per intero."
        ))
        ft = QFormLayout()
        self.cb_kf_tavole = self._lcombo(QgsMapLayerProxyModel.PolygonLayer); ft.addRow("Tavole di Inquadramento:", self.cb_kf_tavole)
        self.cb_kf_infra  = self._lcombo(QgsMapLayerProxyModel.LineLayer);    ft.addRow("Infrastrutture:", self.cb_kf_infra)
        self.cb_kf_pozzetto = self._lcombo(QgsMapLayerProxyModel.PointLayer); ft.addRow("Pozzetto:", self.cb_kf_pozzetto)
        self.cb_k_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer);  ft.addRow("Armadio Ottico:", self.cb_k_armadio)
        self.cb_k_foto    = self._lcombo(QgsMapLayerProxyModel.PointLayer);  ft.addRow("Punto di Ripresa (output):", self.cb_k_foto)
        self.cb_k_stradario = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        ft.addRow("Stradario o altro shape lineare di riferimento (opzionale):", self.cb_k_stradario)
        self.cb_k_sedime = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        ft.addRow("Sedime Pubblico (opzionale, evita punti non accessibili):", self.cb_k_sedime)
        self.cb_kf_prov   = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  ft.addRow("Strade Provinciali (opzionale):", self.cb_kf_prov)
        self.cb_kf_anas   = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True);  ft.addRow("Strade ANAS (opzionale):", self.cb_kf_anas)
        self.spin_k_rag   = self._dspin(1, 5000, 50.0, 1, " raggio ricerca strada"); ft.addRow("Raggio ricerca strada (iniziale):", self.spin_k_rag)
        self.spin_k_dist  = self._dspin(0.1, 500, 3.0, 1, " unità progetto"); ft.addRow("Distanza di riserva (nessuna strada trovata):", self.spin_k_dist)
        # Quando il punto di ripresa cade SOPRA l'elemento da fotografare
        # (succede spesso: i punti stanno sulle infrastrutture o sugli armadi,
        # non sulla strada) la direzione camera→soggetto è indefinita e il cono
        # finisce orientato a caso. In quel caso la camera viene arretrata di
        # questa distanza lungo la direzione di ripresa, così il cono si vede e
        # il soggetto ci cade dentro.
        self.spin_k_standoff = self._dspin(0, 100, 8.0, 1, " m")
        ft.addRow("Arretramento camera se è sopra l'elemento:", self.spin_k_standoff)
        self.spin_kf_dist = self._dspin(0.1, 500, 3.0, 1, " unità progetto"); ft.addRow("Distanza di ripresa (standoff da attraversamenti):", self.spin_kf_dist)
        self.spin_kf_margine_arlo = self._dspin(0, 200000, 500.0, 0, " margine attorno ad ARLO AREA")
        ft.addRow("Ritaglia Stradario/Provinciali/ANAS a: ARLO AREA + margine:", self.spin_kf_margine_arlo)
        vt.addLayout(ft)
        bt = QPushButton("Genera coni per Tavole di Inquadramento"); bt.setStyleSheet("font-weight:bold")
        bt.clicked.connect(self._coni_tavole); vt.addWidget(bt)
        self.log_kf = self._log_widget(130)
        vt.addWidget(self._blocco_log(self.log_kf))
        v.addWidget(gbt)

        # --- coni ruotabili a mano -------------------------------------
        gbr = self._gruppo("Coni ruotabili con anteprima (poligoni)"); vr = QVBoxLayout(gbr)
        vr.addWidget(self._desc(
            "Trasforma i Punti di Ripresa in CONI POLIGONALI, ruotabili con lo "
            "strumento «Ruota elementi» di QGIS, che mostra l'anteprima mentre "
            "trascini — cosa che «Ruota simboli dei punti» non fa, perché scrive "
            "solo un numero. Il cono ha l'apice sulla camera, apertura 120° e "
            "raggio pari ai 6 mm del simbolo riportati alla scala di stampa.\n"
            "Quando SALVI le modifiche del layer coni, il plugin rilegge "
            "l'orientamento dalla geometria e lo riscrive nel campo "
            f"'{CAMPO_ROT}' dei punti: il programma esterno delle foto continua "
            "a trovare gli stessi numeri di sempre."
        ))
        fr = QFormLayout()
        self.spin_cono_scala = self._dspin(50, 50000, CONO_SCALA_DEFAULT, 0, "  (1:scala)")
        fr.addRow("Scala di stampa della tavola:", self.spin_cono_scala)
        self.spin_cono_apert = self._dspin(5, 350, CONO_APERTURA_GRADI, 0, "°")
        fr.addRow("Apertura del cono:", self.spin_cono_apert)
        self.lbl_cono_raggio = QLabel("")
        fr.addRow("Raggio risultante:", self.lbl_cono_raggio)
        self.spin_cono_scala.valueChanged.connect(self._aggiorna_raggio_cono)
        self._aggiorna_raggio_cono()
        vr.addLayout(fr)
        self.chk_cono_muove_camera = QCheckBox(
            "Spostando il cono si sposta anche la camera (togli la spunta per "
            "tenere la camera ferma: il cono torna sull'apice e cambia solo "
            "l'orientamento)")
        self.chk_cono_muove_camera.setChecked(True)
        vr.addWidget(self.chk_cono_muove_camera)
        br = QPushButton("Genera coni ruotabili dai Punti di Ripresa")
        br.setStyleSheet("font-weight:bold")
        br.clicked.connect(self._genera_coni_ruotabili); vr.addWidget(br)
        # Il riporto della rotazione va riagganciato ogni volta che si apre il
        # progetto: la connessione al salvataggio vive nell'oggetto layer di
        # QUESTA sessione, non nel file. Senza questo, i coni generati ieri si
        # ruotano e si salvano senza che il punto di ripresa se ne accorga.
        try:
            self.cb_k_foto.layerChanged.connect(self._riaggancia_coni_esistenti)
        except Exception as e:
            _log_avviso("aggancio layerChanged dei coni non riuscito", e)
        self._riaggancia_coni_esistenti()
        self.log_cono = self._log_widget(130)
        vr.addWidget(self._blocco_log(self.log_cono))
        v.addWidget(gbr)

        gbn = self._gruppo("Numerazione automatica Foto"); vn = QVBoxLayout(gbn)
        vn.addWidget(self._desc(
            "Numera le Foto a blocchi fissi di 3 per Tavola (nell'ordine del suo "
            "numero). Se le Tavole non sono ancora numerate nel campo sotto, il "
            "plugin le numera da sé in ordine di lettura (alto→basso, "
            "sinistra→destra); se sono già numerate correttamente rispetta i "
            "valori esistenti. Il blocco resta fisso a 3 anche con meno coni: i "
            "numeri mancanti si saltano, la tavola successiva riparte comunque dal "
            "blocco pieno. Le Foto sono riconosciute tramite il campo 'ID_Tavola', "
            "non geometricamente."
        ))
        fn = QFormLayout()
        self.txt_num_tav = QLineEdit("Numero Tav"); fn.addRow("Campo numerazione Tavole (esistente):", self.txt_num_tav)
        self.txt_num_foto = QLineEdit("NumeroFoto"); fn.addRow("Campo numerazione Foto (creato se manca):", self.txt_num_foto)
        vn.addLayout(fn)
        bn = QPushButton("Numera Foto automaticamente"); bn.setStyleSheet("font-weight:bold")
        bn.clicked.connect(self._numera_foto); vn.addWidget(bn)
        self.log_n = self._log_widget(130)
        vn.addWidget(self._blocco_log(self.log_n))
        v.addWidget(gbn)

        v.addStretch(); return w

    # ─── TAB CHILOMETRICHE ──────────────────────────────────────────
    def _tab_chilometriche(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("chilometriche"))

        v.addWidget(self._desc(
            "Per le tratte che ricadono su strade ANAS/Provinciali non si usa lo "
            "stradario ma la chilometrica. Workflow: 1) crei/apri il layer Ancore, "
            "e per ogni punto di cui conosci la chilometrica reale (letta da Maps, "
            "da un cippo chilometrico o da un documento ANAS) ci clicchi sopra e "
            "scrivi il valore, es. 12+300; 2) selezioni i Pozzetto/Infrastrutture "
            "target; 3) il plugin trova la linea di riferimento più vicina a ognuno, "
            "misura la distanza reale lungo quella linea dall'ancora più vicina (o "
            "interpola fra le due ancore più vicine se ce ne sono almeno due sulla "
            "stessa linea) e scrive la chilometrica calcolata nel campo indicato."
        ))

        gb0 = self._gruppo("1) Crea il campo 'Chilometrica' sugli shape selezionati"); g0 = QVBoxLayout(gb0)
        g0.addWidget(self._desc(
            "Seleziona nel pannello Livelli (Ctrl+click) gli shape su cui ti serve "
            "il campo — tipicamente Pozzetto e/o Infrastrutture — poi genera il "
            "campo qui: se manca lo crea col tipo scelto, se esiste già lo lascia "
            "invariato. Usa lo stesso nome che poi userai come 'Campo di output' "
            "qui sotto. Attenzione: negli shapefile (DBF) i nomi campo non "
            "possono superare i 10 caratteri, quindi 'Chilometrica' viene creato "
            "come 'Chilometri' — è normale e non serve correggere nulla, il "
            "calcolo qui sotto riconosce entrambe le forme."
        ))
        riga_campo = QHBoxLayout()
        self.txt_km_nuovo_campo = QLineEdit("Chilometrica")
        riga_campo.addWidget(self.txt_km_nuovo_campo)
        self.cb_km_tipo_campo = QComboBox()
        self.cb_km_tipo_campo.addItems(["Testo (es. 12+300)", "Numerico (metri)"])
        riga_campo.addWidget(self.cb_km_tipo_campo)
        g0.addLayout(riga_campo)
        btn_crea_campo = QPushButton("Crea campo sugli shape selezionati nel pannello Livelli")
        btn_crea_campo.clicked.connect(self._crea_campo_chilometrica)
        g0.addWidget(btn_crea_campo)
        v.addWidget(gb0)

        gb1 = self._gruppo("2) Cippi di riferimento"); g1 = QVBoxLayout(gb1)
        g1.addWidget(self._desc(
            "Va bene sia il layer creato col pulsante qui sotto sia uno shape di cippi "
            "che già possiedi (es. 'Cippi Chilometrici'): in quel caso indica quale "
            "campo contiene il valore chilometrico — il plugin non presume più che si "
            "chiami 'Chilometrica'. Sono accettati i formati 12+300, 12,3 (km) e 12300 "
            "(metri)."
        ))
        riga_ancore = QHBoxLayout()
        self.cb_km_ancore = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        riga_ancore.addWidget(self.cb_km_ancore)
        btn_crea_ancore = QPushButton("Crea nuovo layer Ancore…")
        btn_crea_ancore.clicked.connect(self._crea_layer_ancore_km)
        riga_ancore.addWidget(btn_crea_ancore)
        g1.addLayout(riga_ancore)
        f1 = QFormLayout()
        self.cb_km_campo_ancora = QgsFieldComboBox()
        self.cb_km_campo_ancora.setAllowEmptyFieldName(True)
        f1.addRow("Campo con il valore chilometrico del cippo:", self.cb_km_campo_ancora)
        self.cb_km_formato = QComboBox()
        for _, etichetta in self._FORMATI_KM:
            self.cb_km_formato.addItem(etichetta)
        self.cb_km_formato.setToolTip(
            "Come leggere le due parti attorno al '+'. Il prefisso 'KM' o 'PK' viene "
            "ignorato in automatico. Scegli 'INVERTITO' se nello shape hai digitato "
            "prima i metri e poi i chilometri.")
        f1.addRow("Formato del valore scritto sul cippo:", self.cb_km_formato)
        g1.addLayout(f1)
        self.cb_km_ancore.layerChanged.connect(self._aggiorna_campi_ancore)
        self._aggiorna_campi_ancore(self.cb_km_ancore.currentLayer())
        v.addWidget(gb1)

        gb2 = self._gruppo("3) Calcolo"); g2 = QVBoxLayout(gb2)
        g2.addWidget(self._desc(
            "Uno stradario è spezzato in tantissimi segmenti: misurare la progressiva "
            "sul singolo segmento non ha senso, perciò il plugin prima ricuce i "
            "segmenti contigui in 'corridoi' continui, poi misura cippi e target lungo "
            "lo stesso corridoio. La chilometrica di ogni elemento è poi il valore del "
            "cippo di riferimento più la distanza reale percorsa lungo la strada da quel "
            "cippo, un metro per un metro: i valori crescono nel verso della strada, "
            "come i cippi veri. Non serve disegnare nulla a mano fra i cippi. Se lo "
            "stradario copre mezza provincia conviene selezionare in mappa le sole "
            "tratte della strada che ti interessa e spuntare l'opzione qui sotto: è più "
            "rapido e togli ogni ambiguità nei bivi e nelle rotatorie."
        ))
        f = QFormLayout()
        self.cb_km_riferimento = self._lcombo(QgsMapLayerProxyModel.LineLayer)
        f.addRow("Linea di riferimento (strada/tracciato):", self.cb_km_riferimento)
        self.cb_km_campo_gruppo = QgsFieldComboBox()
        self.cb_km_campo_gruppo.setAllowEmptyFieldName(True)
        f.addRow("Ricuci solo segmenti con uguale valore di (opzionale):", self.cb_km_campo_gruppo)
        self.cb_km_target = self._lcombo(
            QgsMapLayerProxyModel.PointLayer | QgsMapLayerProxyModel.LineLayer)
        f.addRow("Layer target (Pozzetto o Infrastrutture):", self.cb_km_target)
        self.txt_km_campo = QLineEdit("Chilometrica")
        f.addRow("Campo di output sul target:", self.txt_km_campo)
        self.spin_km_raggio = self._dspin(0.5, 5000, 50.0, 1, " unità progetto")
        f.addRow("Raggio ricerca target → corridoio:", self.spin_km_raggio)
        self.spin_km_tol_cippi = self._dspin(0.5, 5000, 50.0, 1, " unità progetto")
        f.addRow("Tolleranza cippo → corridoio:", self.spin_km_tol_cippi)
        self.spin_km_cucitura = self._dspin(0, 100, 1.0, 2, " unità progetto")
        self.spin_km_cucitura.setToolTip(
            "Distanza entro cui due tronchi di strada che non si toccano vengono "
            "comunque ricuciti in un unico corridoio. Negli stradari i tronchi si "
            "chiudono spesso a qualche centimetro di distanza: senza questa tolleranza "
            "la strada resta spezzata e gli elementi dei due tronchi contano da origini "
            "diverse. Alzala se la diagnostica segnala più di un corridoio.")
        f.addRow("Tolleranza di ricucitura fra tronchi:", self.spin_km_cucitura)
        self.cb_km_misura = QComboBox()
        for _, etichetta in self._MISURE_KM:
            self.cb_km_misura.addItem(etichetta)
        self.cb_km_misura.setToolTip(
            "Vale solo per i target lineari (Infrastrutture): una tratta ha due capi con "
            "chilometriche diverse. Il punto medio faceva sembrare incoerenti due scavi "
            "consecutivi, perché il primo finiva dove il secondo cominciava ma i valori "
            "scritti distavano mezza tratta.")
        f.addRow("Su una tratta misura:", self.cb_km_misura)
        # default: il testo esteso "dal km ... al km ..." — è la dicitura che
        # va nelle tavole per l'ente, ed è la ragione per cui la misura esiste
        self.cb_km_misura.setCurrentIndex(3)
        self.cb_km_pozzetti = self._lcombo(QgsMapLayerProxyModel.PointLayer,
                                           allow_empty=True)
        self.cb_km_pozzetti.setToolTip(
            "I capi delle tratte coincidono coi pozzetti: quando un capo cade su un "
            "pozzetto (entro la tolleranza qui sotto), la sua chilometrica viene "
            "misurata ESATTAMENTE nel punto del pozzetto, così il valore scritto "
            "sulla tratta e quello scritto sul pozzetto sono identici e non "
            "differiscono di qualche metro per il disegno. Dove il capo non tocca "
            "nessun pozzetto, la chilometrica si calcola normalmente sul corridoio. "
            "Vuoto = nessun aggancio.")
        f.addRow("Pozzetti (aggancia i capi delle tratte):", self.cb_km_pozzetti)
        self.spin_km_snap = self._dspin(0.05, 50, 1.0, 2, " unità progetto")
        self.spin_km_snap.setToolTip(
            "Distanza massima capo-tratta → pozzetto perché scatti l'aggancio. "
            "Nei progetti ben disegnati i capi cadono sul pozzetto al centimetro: "
            "1 unità è già larga.")
        f.addRow("Aggancio capo → pozzetto entro:", self.spin_km_snap)
        g2.addLayout(f)
        self.cb_km_riferimento.layerChanged.connect(self._aggiorna_campi_riferimento)
        self._aggiorna_campi_riferimento(self.cb_km_riferimento.currentLayer())

        riga_modo = QHBoxLayout()
        riga_modo.addWidget(QLabel("Come contare:"))
        self.cb_km_modo = QComboBox()
        for _, etichetta in self._MODI_KM:
            self.cb_km_modo.addItem(etichetta)
        self.cb_km_modo.setToolTip(
            "In progressione la chilometrica di un elemento è il valore del cippo di "
            "riferimento più la distanza reale percorsa lungo la strada, un metro per "
            "un metro: i valori crescono nel verso della strada e restano monotoni. "
            "L'interpolazione invece riscala le distanze sui valori dei cippi, quindi un "
            "cippo mal posizionato deforma tutto il tratto che lo riguarda. Solo la "
            "prima modalità garantisce valori sempre crescenti: contando dal cippo più "
            "vicino, al cambio di riferimento i valori possono fare un salto indietro se "
            "due cippi non sono coerenti fra loro.")
        riga_modo.addWidget(self.cb_km_modo, 1)
        g2.addLayout(riga_modo)
        self.chk_km_inverti = QCheckBox("Inverti il verso di progressione")
        self.chk_km_inverti.setToolTip(
            "Il verso viene ricavato dai cippi (dal valore più basso verso il più alto). "
            "Serve solo quando c'è un unico cippo utile e il verso non è deducibile: se i "
            "valori risultano decrescenti, spunta qui.")
        g2.addWidget(self.chk_km_inverti)

        self.chk_km_solo_selez_rif = QCheckBox(
            "Usa solo le tratte selezionate in mappa nella linea di riferimento")
        self.chk_km_solo_selez_rif.setToolTip(
            "Consigliato con uno stradario provinciale: seleziona in mappa le tratte "
            "della strada su cui stanno i cippi e il calcolo userà solo quelle.")
        g2.addWidget(self.chk_km_solo_selez_rif)
        self.chk_km_tutte_feature = QCheckBox(
            "Se non c'è nessuna feature selezionata nel target, elabora tutte le sue feature")
        g2.addWidget(self.chk_km_tutte_feature)
        self.chk_km_multi_target = QCheckBox(
            "Applica anche agli altri layer selezionati nel pannello Livelli "
            "(Armadio + Pozzetto + Infrastrutture in un colpo)")
        self.chk_km_multi_target.setToolTip(
            "Ogni layer vettoriale selezionato nel pannello Livelli che abbia il campo "
            "di output viene elaborato con gli stessi cippi e lo stesso riferimento. "
            "Il layer di riferimento, se selezionato lì, viene comunque escluso.")
        g2.addWidget(self.chk_km_multi_target)
        v.addWidget(gb2)

        riga_bottoni = QHBoxLayout()
        btn_diag = QPushButton("Diagnostica (perché non calcola?)")
        btn_diag.setToolTip("Controlla cippi, corridoi e distanze senza modificare nulla.")
        btn_diag.clicked.connect(self._diagnostica_chilometriche)
        riga_bottoni.addWidget(btn_diag)
        riga_bottoni.addStretch()
        btn = QPushButton("Calcola le chilometriche")
        btn.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        btn.clicked.connect(self._calcola_chilometriche)
        riga_bottoni.addWidget(btn)
        v.addLayout(riga_bottoni)

        self.stato_km = self._etichetta_stato()
        v.addWidget(self.stato_km)
        self.log_km = self._log_widget(140)
        v.addWidget(self._blocco_log(self.log_km))

        v.addStretch(); return w

    # ─── chilometriche: helper UI ───────────────────────────────────
    _INDIZI_CAMPO_KM = ("chilometr", "km", "progr", "pk", "cippo")

    def _aggiorna_campi_ancore(self, layer):
        """Popola il combo dei campi del layer cippi e preseleziona quello che
        con ogni probabilità contiene la chilometrica (nome che contiene
        'chilometr', 'km', 'progr'…), incluso il caso in cui lo shapefile
        l'abbia troncato a 'Chilometri'."""
        self.cb_km_campo_ancora.setLayer(layer)
        if layer is None:
            return
        nomi = [c.name() for c in layer.fields()]
        for indizio in self._INDIZI_CAMPO_KM:
            for nome in nomi:
                if indizio in nome.lower():
                    self.cb_km_campo_ancora.setField(nome)
                    return

    def _aggiorna_campi_riferimento(self, layer):
        self.cb_km_campo_gruppo.setLayer(layer)
        self.cb_km_campo_gruppo.setField("")

    def _campo_ancora(self, ancore_lyr):
        """Campo da leggere sul layer cippi: quello scelto nel combo, altrimenti
        ripiego sul vecchio comportamento ('Chilometrica' o la sua forma
        troncata dallo shapefile)."""
        nome = self.cb_km_campo_ancora.currentField()
        if nome:
            i = self._indice_campo(ancore_lyr, nome)
            if i >= 0:
                return i, ancore_lyr.fields().at(i).name()
        i = self._indice_campo(ancore_lyr, "Chilometrica")
        if i >= 0:
            return i, ancore_lyr.fields().at(i).name()
        return -1, ""

    def _crea_campo_chilometrica(self):
        campo = self.txt_km_nuovo_campo.text().strip()
        if not campo:
            QMessageBox.warning(self, "Nome campo mancante", "Indica il nome del campo da creare."); return
        layers = [l for l in self.iface.layerTreeView().selectedLayers()
                  if isinstance(l, QgsVectorLayer)]
        if not layers:
            QMessageBox.warning(self, "Nessuno shape selezionato",
                "Seleziona uno o più layer vettoriali nel pannello Livelli (Ctrl+click) e riprova."); return

        testo = self.cb_km_tipo_campo.currentIndex() == 0

        righe = []; creati = 0; presenti = 0; falliti = 0; troncati = []
        for lyr in layers:
            # 40 caratteri: basta per la misura più lunga ("dal km 999+999 al
            # km 999+999" sono 30) con margine; su un campo numerico la
            # lunghezza è ignorata
            i, nome_reale, esito = self._assicura_campo(lyr, campo, tipo_testo=testo,
                                                        lunghezza=40)
            if esito.startswith("fallito"):
                falliti += 1
                righe.append(f"'{lyr.name()}': {esito[8:].strip()}."); continue
            if nome_reale != campo:
                troncati.append(f"{lyr.name()} → '{nome_reale}'")
            if esito == "presente":
                presenti += 1
                righe.append(f"'{lyr.name()}': campo '{nome_reale}' già presente, nessuna modifica.")
            else:
                creati += 1
                righe.append(f"'{lyr.name()}': campo '{nome_reale}' creato "
                             f"({'testo' if testo else 'numerico'}).")

        msg = (f"{creati} campi creati, {presenti} già presenti, {falliti} falliti "
               f"su {len(layers)} shape selezionati.\n\n" + "\n".join(righe))
        if troncati:
            msg += ("\n\nNota: gli shapefile (formato DBF) ammettono nomi di campo di "
                    "massimo 10 caratteri, quindi il nome è stato adattato: "
                    + "; ".join(troncati) +
                    ". Al punto 2 puoi lasciare scritto il nome per esteso: il plugin "
                    "riconosce da solo il campo abbreviato.")
        self.log_km.setPlainText(msg)
        self._mostra_stato(self.stato_km, msg.split("\n")[0], ok=falliti == 0)

    def _crea_layer_ancore_km(self):
        crs = self.project.crs().authid()
        lyr = QgsVectorLayer(
            f"Point?crs={crs}&field=Chilometrica:string(12)&field=Strada:string(60)",
            "Ancore Chilometriche", "memory")
        self.project.addMapLayer(lyr)
        self.cb_km_ancore.setLayer(lyr)
        lyr.startEditing()
        self.iface.setActiveLayer(lyr)
        QMessageBox.information(
            self, "Layer Ancore creato",
            "Layer 'Ancore Chilometriche' creato e in modifica.\n\n"
            "Aggiungi un punto per ogni riferimento di cui conosci la chilometrica "
            "reale (da Maps, cippo o documento ANAS), scrivendo il valore nel campo "
            "Chilometrica in formato km+m, es. 12+300, e opzionalmente il nome/codice "
            "strada nel campo Strada. Poi salva le modifiche prima di calcolare."
        )

    # ─── TAB 4 ────────────────────────────────────────────────────
    def _tab_keyplan(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("keyplan"))
        f = QFormLayout()
        self.cb_kp_arlo    = self._lcombo(QgsMapLayerProxyModel.VectorLayer)
        f.addRow("ARLO AREA (poligono con TUTTE le aree armadio da coprire):", self.cb_kp_arlo)
        self.spin_margine  = self._dspin(0, 50000, 100, 0, " m")
        f.addRow("Margine estensione (buffer attorno al confine ARLO AREA):", self.spin_margine)
        v.addLayout(f)

        # --- Area da coprire: rete nuova (predefinito) oppure ARLO AREA -------
        # ARLO AREA è l'area di competenza dell'armadio e comprende strade dove
        # non si posa niente: coprirla tutta produce tavole vuote da scartare a
        # mano. Il lavoro da documentare sta dove c'è rete nuova, quindi di
        # default si copre quella.
        gb_reg = self._gruppo("Area da coprire", compresso=False)
        fr = QFormLayout(gb_reg)
        self.chk_kp_usa_rete = QCheckBox(
            "Costruisci l'area dalla RETE NUOVA (Infrastrutture nuove + Pozzetti "
            "+ Armadi) invece che da ARLO AREA")
        self.chk_kp_usa_rete.setChecked(True)
        fr.addRow(self.chk_kp_usa_rete)
        self.spin_kp_raggio_rete = self._dspin(1, 5000, 30.0, 0, " m attorno alla rete")
        fr.addRow("Raggio attorno agli elementi:", self.spin_kp_raggio_rete)
        self.chk_kp_solo_nuovi = QCheckBox(
            "Considera solo Pozzetti e Armadi con STATO = Nuovo "
            "(le Infrastrutture sono sempre filtrate a Nuovo, Aeree escluse)")
        self.chk_kp_solo_nuovi.setChecked(True)
        fr.addRow(self.chk_kp_solo_nuovi)
        fr.addRow(self._desc(
            "Il raggio è la distanza attorno a infrastrutture, pozzetti e armadi "
            "che deve finire in tavola: 30 m prende la strada e i fronti. "
            "Alzandolo le tavole diventano meno numerose ma più vuote. Se i layer "
            "non contengono rete nuova si ricade automaticamente su ARLO AREA."))
        v.addWidget(gb_reg)

        # Testo e diagnostica di ARLO AREA riguardano SOLO il caso in cui l'area
        # viene da lì. Con la rete nuova spuntata ARLO AREA non viene neppure
        # letta, e lasciarli visibili fa cercare problemi dove non ce ne sono.
        self.lbl_kp_arlo_desc = self._desc(
            "L'area da coprire è la forma reale di ARLO AREA (feature fuse, non il "
            "bounding box), allargata del margine sopra. Infrastrutture/Pozzetto/"
            "Armadio non la definiscono: servono solo se costruisci l'area dalla "
            "rete nuova."
        )
        v.addWidget(self.lbl_kp_arlo_desc)
        self.btn_kp_diag = QPushButton("Diagnostica estensione (verifica ARLO AREA)")
        self.btn_kp_diag.clicked.connect(self._diagnostica_estensione)
        v.addWidget(self.btn_kp_diag)

        def _aggiorna_visibilita_arlo(usa_rete):
            self.lbl_kp_arlo_desc.setVisible(not usa_rete)
            self.btn_kp_diag.setVisible(not usa_rete)
        self.chk_kp_usa_rete.toggled.connect(_aggiorna_visibilita_arlo)
        _aggiorna_visibilita_arlo(self.chk_kp_usa_rete.isChecked())

        v.addWidget(self._desc(
            "Con l'area costruita dalla rete nuova le tavole seguono un RETICOLO "
            "allineato al modello: celle adiacenti, mai sovrapposte, e si tengono "
            "solo quelle che contengono rete — le altre non vengono create. "
            "Nessun pozzetto o tratta può restare fuori: ogni punto sta in una "
            "cella, e la cella con rete dentro viene tenuta. Partendo invece da "
            "ARLO AREA le tavole si dispongono liberamente, una 'toppa' alla volta "
            "sul buco più grande. I layer modello non vengono mai modificati. Ogni "
            "generazione crea un layer temporaneo 'memory' (RAM): usa 'Salva su disco' "
            "più sotto per renderlo permanente."
        ))

        gbk = self._gruppo("Keyplan – copertura automatica (segue la forma, MAI sovrapposta)"); fk = QFormLayout(gbk)
        self.cb_kp_keyplan = self._lcombo(QgsMapLayerProxyModel.VectorLayer); fk.addRow("Layer Keyplan modello A (shape / GeoPackage):", self.cb_kp_keyplan)
        self.cb_kp_keyplan2 = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True)
        # Modello B è OPZIONALE: deve partire VUOTO. Lasciando fare a QGIS ci
        # finiva il primo vettoriale del progetto (01_ARMADIO OTTICO), che non è
        # affatto un modello di tavola: la copertura ne avrebbe ricavato una
        # seconda forma inventata dall'estensione dell'armadio.
        self.cb_kp_keyplan2.setLayer(None)
        fk.addRow("Layer Keyplan modello B (opzionale, es. l'altra forma):", self.cb_kp_keyplan2)
        self.spin_kp_gap = self._dspin(0, 500, 0, 2, " m gap minimo tra tavole", step=0.01); fk.addRow("Margine di sicurezza (gap):", self.spin_kp_gap)
        self.cb_kp_tavole = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        # Deve partire VUOTO: valorizzato manda la copertura sull'impronta delle
        # tavole invece che sull'area di progetto, e non è una scelta da fare al
        # posto tuo. Niente preset, e a ogni refresh si riazzera — tranne quando
        # l'hai scelto tu: 'activated' scatta solo sull'interazione umana, non
        # quando è QGIS a ripopolare il combo.
        self.cb_kp_tavole.setLayer(None)
        self._kp_tavole_scelto = False
        self.cb_kp_tavole.activated.connect(
            lambda *_: setattr(self, "_kp_tavole_scelto", True))
        fk.addRow("Tavole di Inquadramento (se impostato, il Keyplan copre SOLO queste — non ARLO AREA):", self.cb_kp_tavole)
        fk.addRow(self._desc(
            "La feature selezionata (o la prima) di ciascun layer modello è presa come "
            "MODELLO di tavola. Solo A → copertura di sole copie di A; anche B → ad "
            "ogni tavola si sceglie la forma che copre più area utile. Il campo sopra "
            "è un margine di sicurezza aggiuntivo oltre al non-sovrapporsi. Se imposti "
            "un layer di Tavole di Inquadramento, il Keyplan copre ESATTAMENTE la loro "
            "impronta (ARLO AREA ignorata); altrimenti copre l'intero ARLO AREA."
        ))
        bkp = QPushButton("Genera copertura Keyplan sull'area di progetto")
        bkp.setStyleSheet("font-weight:bold"); bkp.clicked.connect(self._posiziona_keyplan)
        fk.addRow(bkp)
        self.chk_kp_sovrascrivi = QCheckBox(
            "Sostituisci le tavole già presenti nel layer di destinazione "
            "(la feature modello viene conservata)")
        self.chk_kp_sovrascrivi.setChecked(True)
        fk.addRow(self.chk_kp_sovrascrivi)
        bkpc = QPushButton("Copia le tavole generate nel layer modello A (Quadrato/Rettangolare)")
        bkpc.clicked.connect(lambda: self._copia_nel_modello(
            "keyplan", self.cb_kp_keyplan, "Keyplan", self.chk_kp_sovrascrivi))
        fk.addRow(bkpc)
        fk.addRow(self._desc(
            "La generazione scrive in un layer temporaneo, che vive solo in questa "
            "sessione: serve a guardare il risultato prima di accettarlo. Il pulsante "
            "qui sopra copia quelle tavole nel layer modello scelto in «modello A» — "
            "quadrato o rettangolare a seconda di cosa hai impostato — che è quello "
            "a cui puntano i layout. Le tavole vengono aggiunte, nulla viene rimosso."
        ))
        v.addWidget(gbk)

        gbt = self._gruppo("Tavole di inquadramento – copertura automatica (modelli propri)"); ft = QFormLayout(gbt)
        self.cb_ti_tmpl_a = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True); ft.addRow("Layer Inquadramento modello A (es. Tavole_Inquadramento.gpkg):", self.cb_ti_tmpl_a)
        self.cb_ti_tmpl_b = self._lcombo(QgsMapLayerProxyModel.VectorLayer, allow_empty=True)
        # opzionale, deve partire VUOTO: lasciandolo a QGIS ci finiva
        # 01_ARMADIO OTTICO, un layer di punti preso per modello di tavola.
        self.cb_ti_tmpl_b.setLayer(None)
        ft.addRow("Layer Inquadramento modello B (opzionale):", self.cb_ti_tmpl_b)
        self.spin_ti_gap = self._dspin(0, 500, 0, 2, " m gap minimo tra tavole", step=0.01); ft.addRow("Margine di sicurezza (gap):", self.spin_ti_gap)
        ft.addRow(self._desc(
            "Copertura indipendente dal Keyplan (scala diversa), stesso automatismo A/B "
            "(riusa i modelli del Keyplan se non ne imposti qui). Mai sovrapposte; le "
            "tavole quasi del tutto ridondanti vengono rimosse in automatico."
        ))
        btv = QPushButton("Genera copertura tavole di inquadramento"); btv.setStyleSheet("font-weight:bold"); btv.clicked.connect(self._genera_griglia)
        ft.addRow(btv)
        self.chk_ti_sovrascrivi = QCheckBox(
            "Sostituisci le tavole già presenti nel layer di destinazione "
            "(la feature modello viene conservata)")
        self.chk_ti_sovrascrivi.setChecked(True)
        ft.addRow(self.chk_ti_sovrascrivi)
        btvc = QPushButton("Copia le tavole generate nel layer modello A (Poligoni di Inquadramento)")
        btvc.clicked.connect(lambda: self._copia_nel_modello(
            "inquadramento", self.cb_ti_tmpl_a, "Poligoni Inquadramento", self.chk_ti_sovrascrivi))
        ft.addRow(btvc)
        v.addWidget(gbt)

        # I due pulsanti «rigenera solo sulla rete» non ci sono più: facevano in
        # due passaggi (prima inquadramento, poi keyplan) quello che adesso la
        # generazione fa da sola, perché la copertura a reticolo tiene solo le
        # celle con rete dentro. Restano i layer, che servono a costruire l'area.
        # Resta il solo layer Infrastrutture, che è l'unico davvero letto per
        # costruire l'area. Il combo «Pozzetto» e il «Raggio target» sono stati
        # tolti: alimentavano esclusivamente i due pulsanti «rigenera solo sulla
        # rete», e una volta rimossi quelli nessuno li leggeva più — restavano
        # campi che sembravano configurare qualcosa senza toccare il risultato.
        # Pozzetti e armadi per l'area si prendono dai combo della scheda
        # «Seleziona elementi» (cb_kf_pozzetto / cb_k_armadio), e il raggio è
        # quello di «Area da coprire» qui sopra.
        gbo = self._gruppo("Layer della rete nuova (da cui si costruisce l'area da coprire)"); fo = QFormLayout(gbo)
        self.cb_kp_infra = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        fo.addRow("Infrastrutture (STATO='Nuovo'):", self.cb_kp_infra)
        fo.addRow(self._desc(
            "È il layer da cui si ricava la rete nuova: Infrastrutture STATO='Nuovo' "
            f"(escluse TIPOLOGIA='{VAL_AEREA}' o vuota). Pozzetti e armadi vengono "
            "presi dai layer scelti nella scheda «Seleziona elementi»; il raggio è "
            "quello impostato sopra in «Area da coprire». Le tavole si creano SOLO "
            "dove c'è rete: le zone senza rete nuova restano scoperte, ed è voluto."
        ))
        v.addWidget(gbo)

        gbn = self._gruppo("Numerazione Keyplan e Tavole di Inquadramento"); fn = QFormLayout(gbn)
        fn.addRow(self._desc(
            "Numera le tavole in ordine di lettura (righe nord→sud, ovest→est), "
            "indipendentemente per Keyplan e Tavole. Campo creato se manca; vuoto = "
            "quel layer non viene numerato."
        ))
        self.cb_num_keyplan = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        fn.addRow("Layer Keyplan:", self.cb_num_keyplan)
        self.txt_num_keyplan_campo = QLineEdit("Numero Tav")
        fn.addRow("Campo numerazione Keyplan:", self.txt_num_keyplan_campo)
        self.cb_num_tavole = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        fn.addRow("Layer Tavole di Inquadramento:", self.cb_num_tavole)
        self.txt_num_tavole_campo = QLineEdit("Numero Tav")
        fn.addRow("Campo numerazione Tavole:", self.txt_num_tavole_campo)
        bnum = QPushButton("Numera Keyplan e Tavole"); bnum.setStyleSheet("font-weight:bold")
        bnum.clicked.connect(self._numera_keyplan_e_tavole); fn.addRow(bnum)
        v.addWidget(gbn)

        gbs = self._gruppo("Salva su disco"); fs = QFormLayout(gbs)
        fs.addRow(self._desc(
            "I layer generati sopra sono temporanei (memory). Questi pulsanti salvano "
            "UN layer alla volta nel GeoPackage scelto, con lo stile del plugin."
        ))
        bsalva_kp = QPushButton("Salva Keyplan su GeoPackage…")
        bsalva_kp.setStyleSheet("font-weight:bold")
        bsalva_kp.clicked.connect(lambda: self._salva_uno('keyplan', 'Keyplan', 'keyplan.qml'))
        fs.addRow(bsalva_kp)
        bsalva_ti = QPushButton("Salva Poligoni Inquadramento su GeoPackage…")
        bsalva_ti.setStyleSheet("font-weight:bold")
        bsalva_ti.clicked.connect(lambda: self._salva_uno('inquadramento', 'Poligoni Inquadramento', 'poligoni_inquadramento.qml'))
        fs.addRow(bsalva_ti)
        v.addWidget(gbs)

        self.log_kp = self._log_widget(130)
        v.addWidget(self._blocco_log(self.log_kp))
        v.addStretch(); return w

    # ═══════════════════════════════════════════════════ HELPERS UI
    def _lcombo(self, filtro, allow_empty=False):
        c = QgsMapLayerComboBox(); c.setFilters(filtro)
        if allow_empty: c.setAllowEmptyLayer(True)
        self._rendi_ricercabile(c)
        return c

    @staticmethod
    def _rendi_ricercabile(combo):
        """Aggiunge una barra di ricerca al combo dei layer: lo rende editabile
        e collega un completer 'contains' (cerca la sottostringa ovunque nel
        nome, non solo all'inizio, senza distinzione maiuscole/minuscole).

        QgsMapLayerComboBox non è ricercabile di suo: con tanti layer nel
        progetto scorrere la lista è scomodo. Qui basta iniziare a digitare
        una parte del nome per filtrare. Il testo digitato NON crea layer
        fantasma: currentLayer() continua a leggere la selezione reale, e a
        fine editing il testo viene risincronizzato col layer corrente così
        non resta testo libero che non corrisponde a nulla."""
        from qgis.PyQt.QtWidgets import QCompleter
        from qgis.PyQt.QtCore import Qt
        combo.setEditable(True)
        # l'edit line è solo per cercare: non deve inserire voci nuove
        combo.setInsertPolicy(QComboBox.NoInsert)
        le = combo.lineEdit()
        if le is not None:
            le.setPlaceholderText("digita per cercare un layer…")
            le.setClearButtonEnabled(True)
        comp = combo.completer()
        if comp is not None:
            comp.setCompletionMode(QCompleter.PopupCompletion)
            comp.setFilterMode(Qt.MatchContains)
            comp.setCaseSensitivity(Qt.CaseInsensitive)

        # risincronizza il testo al layer realmente selezionato quando l'utente
        # smette di digitare. Se l'edit line contiene testo che NON corrisponde
        # a un layer (ricerca abbandonata senza scegliere dal popup), ripristina
        # l'ultimo layer valido invece di lasciare il combo in uno stato sporco.
        def _ricorda(lyr):
            if lyr is not None:
                combo.setProperty("_ultimo_layer_id", lyr.id())
        combo.layerChanged.connect(_ricorda)
        _ricorda(combo.currentLayer())

        def _risincronizza():
            if le is None:
                return
            testo = le.text().strip()
            lyr = combo.currentLayer()
            # se il combo ammette il layer vuoto e l'utente ha svuotato il campo,
            # RISPETTA la scelta 'nessun layer' invece di riproporre l'ultimo
            if not testo and combo.allowEmptyLayer():
                combo.setLayer(None)
                le.setText("")
                return
            # il testo digitato corrisponde davvero al layer selezionato?
            if lyr is not None and testo == lyr.name():
                return
            # testo non corrispondente: prova a risolverlo su un nome di layer
            corrisp = None
            if testo:
                for i in range(combo.count()):
                    nome = combo.itemText(i)
                    if nome and nome.lower() == testo.lower():
                        corrisp = i
                        break
            if corrisp is not None:
                combo.setCurrentIndex(corrisp)
                return
            # testo vuoto ma il combo NON ammette il vuoto, oppure testo non
            # risolvibile: ripristina l'ultimo layer valido
            ultimo = combo.property("_ultimo_layer_id")
            if ultimo:
                for i in range(combo.count()):
                    l_i = combo.layer(i) if hasattr(combo, "layer") else None
                    if l_i is not None and l_i.id() == ultimo:
                        combo.setCurrentIndex(i); break
            lyr2 = combo.currentLayer()
            le.setText(lyr2.name() if lyr2 is not None else "")
        combo.layerChanged.connect(lambda *_: (le.setText(combo.currentLayer().name()
                                                          if combo.currentLayer() is not None else "")
                                               if le is not None else None))
        if le is not None:
            le.editingFinished.connect(_risincronizza)
        return combo

    def _dspin(self, lo, hi, val, dec, suf="", step=None):
        s = QDoubleSpinBox(); s.setRange(lo, hi); s.setDecimals(dec)
        s.setValue(val); s.setSuffix(suf)
        if step is not None: s.setSingleStep(step)
        return s

    def _ispin(self, lo, hi, val):
        s = QSpinBox(); s.setRange(lo, hi); s.setValue(val); return s

    @staticmethod
    def _desc(testo, soglia=170):
        """Blocco di aiuto: la prima frase resta sempre visibile, il resto si
        apre su richiesta con '▸ dettagli'.

        Prima ogni scheda si apriva con un paragrafo giustificato di otto o dieci
        righe che spingeva i controlli sotto la piega e costringeva a leggere
        tutto per trovare il pulsante: chi conosce già la funzione vuole solo il
        promemoria di una riga, chi non la conosce apre i dettagli. I testi
        restano quelli, cambia solo quanto ne vedi subito."""
        testo = " ".join(str(testo).split())
        if len(testo) <= soglia:
            etichetta = QLabel(testo)
            etichetta.setWordWrap(True)
            etichetta.setAlignment(Qt.AlignJustify)
            return etichetta

        # taglio alla fine della prima frase "vera": il punto deve essere
        # seguito da spazio e maiuscola, così non si spezza su 'es. 12+300'
        taglio = -1
        for m in re.finditer(r"(?<=[a-z0-9àèéìòù\)\]])\.\s+(?=[A-Z0-9])", testo):
            if m.start() >= 50:
                taglio = m.start() + 1
                break
        if taglio < 0 or taglio > soglia * 1.6:
            taglio = testo.rfind(" ", 0, soglia)
            if taglio < 50:
                taglio = soglia
        sommario, resto = testo[:taglio].strip(), testo[taglio:].strip()

        contenitore = QWidget()
        v = QVBoxLayout(contenitore)
        v.setContentsMargins(0, 0, 0, 4); v.setSpacing(2)

        capo = QLabel(sommario)
        capo.setWordWrap(True); capo.setAlignment(Qt.AlignJustify)
        v.addWidget(capo)

        dettagli = QLabel(resto)
        dettagli.setWordWrap(True); dettagli.setAlignment(Qt.AlignJustify)
        dettagli.setVisible(False)

        interruttore = QToolButton()
        interruttore.setText("dettagli")
        interruttore.setCheckable(True)
        interruttore.setAutoRaise(True)
        interruttore.setArrowType(Qt.RightArrow)
        interruttore.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        interruttore.setCursor(Qt.PointingHandCursor)
        interruttore.setStyleSheet("QToolButton { border: none; padding: 0px; }")

        def _apri(aperto):
            dettagli.setVisible(aperto)
            interruttore.setArrowType(Qt.DownArrow if aperto else Qt.RightArrow)
            interruttore.setText("nascondi" if aperto else "dettagli")
        interruttore.toggled.connect(_apri)

        riga = QHBoxLayout(); riga.setContentsMargins(0, 0, 0, 0)
        riga.addWidget(interruttore); riga.addStretch()
        v.addLayout(riga)
        v.addWidget(dettagli)
        return contenitore

    def _gruppo(self, titolo, compresso=True):
        """Riquadro comprimibile, chiuso all'apertura del plugin.

        Ogni scheda si presenta come un elenco di titoli: si apre quello che
        serve e il resto resta fuori dai piedi.

        Il salvataggio automatico dello stato va disattivato di proposito.
        QgsCollapsibleGroupBox memorizza in QgsSettings se il riquadro era aperto
        e lo ripristina quando il widget viene mostrato, sovrascrivendo il
        setCollapsed() fatto qui: senza disattivarlo, i riquadri lasciati aperti
        nella sessione precedente si riaprirebbero da soli e la richiesta di
        trovarli tutti chiusi non sarebbe rispettata."""
        try:
            from qgis.gui import QgsCollapsibleGroupBox
            gb = QgsCollapsibleGroupBox(titolo)
            gb.setObjectName("ftth_" + re.sub(r"[^0-9A-Za-z]+", "_", titolo).strip("_").lower())
            if hasattr(gb, "setSaveCollapsedState"):
                gb.setSaveCollapsedState(False)
            gb.setCollapsed(compresso)
            self._gruppi.append(gb)
            return gb
        except Exception:
            return QGroupBox(titolo)

    def _chiudi_tutte_le_sezioni(self):
        """Richiude ogni riquadro, per tornare alla vista d'insieme senza
        chiudere e riaprire il pannello."""
        chiusi = 0
        for gb in self._gruppi:
            try:
                if not gb.isCollapsed():
                    gb.setCollapsed(True)
                    chiusi += 1
            except Exception:
                continue
        return chiusi

    def _barra_guida(self, chiave):
        """Riga con il pulsante Guida, da mettere in cima a ogni scheda."""
        riga = QHBoxLayout()
        riga.addStretch()
        b = QPushButton("  ?  Guida")
        b.setToolTip("Come si usa questa scheda, passo per passo.")
        b.clicked.connect(lambda: self._mostra_guida(chiave))
        riga.addWidget(b)
        contenitore = QWidget()
        contenitore.setLayout(riga)
        return contenitore

    @staticmethod
    def _intestazione(testo):
        """Intestazione di sezione dentro un riquadro: serve a spezzare gli
        elenchi lunghi di controlli, che altrimenti si leggono come una fila
        indistinta in cui non si trova più niente."""
        etichetta = QLabel(testo.upper())
        etichetta.setStyleSheet(
            "font-weight: bold; color: palette(mid); margin-top: 6px;")
        return etichetta

    def _scrivi_log(self, widget, testo):
        """Aggiunge una riga a un riquadro di log.

        Esiste perche' nel plugin i log si scrivono direttamente sul widget
        (setPlainText/appendPlainText) e non c'era un metodo comune: averlo
        inventato senza verificarlo ha prodotto un AttributeError a runtime
        che i test non hanno intercettato, perche' la classe finta ne
        definiva uno suo e mascherava l'assenza.
        """
        try:
            widget.appendPlainText(str(testo))
        except Exception as e:
            _log_avviso("scrittura nel riquadro di log non riuscita", e)

    @staticmethod
    def _log_widget(altezza=150):
        """Riquadro di log a larghezza fissa di carattere: le colonne degli
        elenchi (campi, valori di esempio) restano allineate, e l'altezza
        massima evita che il log si mangi la scheda."""
        log = QPlainTextEdit()
        log.setReadOnly(True)
        log.setMaximumHeight(altezza)
        carattere = QFont("Monospace")
        carattere.setStyleHint(QFont.TypeWriter)
        carattere.setPointSize(max(7, QFont().pointSize() - 1))
        log.setFont(carattere)
        return log

    def _blocco_log(self, log, titolo="Registro dell'operazione"):
        """Avvolge un riquadro di log in un blocco richiudibile, chiuso all'avvio.

        I log occupavano spazio verticale anche quando erano vuoti — nelle schede
        più cariche erano tre o quattro rettangoli bianchi che allontanavano i
        controlli fra loro. Ora restano chiusi e si aprono da sé quando c'è
        qualcosa da leggere, così lo spazio è occupato solo se serve."""
        contenitore = QWidget()
        v = QVBoxLayout(contenitore)
        v.setContentsMargins(0, 0, 0, 0); v.setSpacing(2)

        interruttore = QToolButton()
        interruttore.setText(titolo)
        interruttore.setCheckable(True)
        interruttore.setAutoRaise(True)
        interruttore.setArrowType(Qt.RightArrow)
        interruttore.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        interruttore.setCursor(Qt.PointingHandCursor)
        interruttore.setStyleSheet("QToolButton { border: none; padding: 0px; }")
        log.setVisible(False)

        def _apri(aperto):
            log.setVisible(aperto)
            interruttore.setArrowType(Qt.DownArrow if aperto else Qt.RightArrow)
        interruttore.toggled.connect(_apri)

        def _contenuto_cambiato():
            if log.toPlainText().strip() and not interruttore.isChecked():
                interruttore.setChecked(True)
        log.textChanged.connect(_contenuto_cambiato)

        riga = QHBoxLayout(); riga.setContentsMargins(0, 0, 0, 0)
        riga.addWidget(interruttore); riga.addStretch()
        v.addLayout(riga)
        v.addWidget(log)
        return contenitore

    @staticmethod
    def _etichetta_stato():
        """Riga di esito accanto ai pulsanti: sostituisce il popup di conferma
        per le operazioni andate a buon fine, che obbligava a un click in più
        per leggere poi la stessa cosa nel log."""
        stato = QLabel("")
        stato.setWordWrap(True)
        stato.setTextInteractionFlags(Qt.TextSelectableByMouse)
        return stato

    def _mostra_stato(self, etichetta, testo, ok=True):
        etichetta.setText(("✔ " if ok else "⚠ ") + testo)
        etichetta.setStyleSheet("font-weight: bold;" if ok else
                                "font-weight: bold; color: #b35c00;")
        self.repaint()

    # ═══════════════════════════════════════════════ HELPERS SPAZIALI
    def _to_proj(self, geom, lyr):
        """Trasforma geom (nel CRS di lyr) nel CRS di progetto. Ritorna None
        se la geometria è vuota/assente o se la trasformazione fallisce
        (CRS non validi/non compatibili), invece di interrompere il plugin
        con un'eccezione non gestita."""
        if geom is None or geom.isEmpty(): return None
        src = lyr.crs(); dst = self.project.crs()
        if src == dst: return QgsGeometry(geom)
        g = QgsGeometry(geom)
        try:
            g.transform(QgsCoordinateTransform(src, dst, self.project))
        except Exception as e:
            self._crs_errors = getattr(self, "_crs_errors", 0) + 1
            print(f"[FTTH Permessi] Errore trasformazione CRS ({lyr.name()}): {e}")
            return None
        return g

    @staticmethod
    def _valida(geom):
        """Ritorna una geometria valida (make-valid) se GEOS la considera
        non valida, altrimenti la geometria originale. Evita che una feature
        corrotta faccia fallire intersection()/combine()/distance()."""
        if geom is None or geom.isEmpty(): return geom
        if not geom.isGeosValid():
            fixed = geom.makeValid()
            if fixed and not fixed.isEmpty(): return fixed
        return geom

    def _req_area(self, lyr, area_geom):
        """QgsFeatureRequest con bbox limitato ad area_geom (già nel CRS
        di progetto), trasformato nel CRS di lyr se serve. Ritorna None
        se area_geom o lyr mancano (nessun filtro, layer letto per
        intero)."""
        if area_geom is None or lyr is None:
            return None
        bb = area_geom.boundingBox()
        req = QgsFeatureRequest()
        if lyr.crs() != self.project.crs():
            trasf = QgsCoordinateTransform(self.project.crs(), lyr.crs(), self.project)
            req.setFilterRect(trasf.transformBoundingBox(bb))
        else:
            req.setFilterRect(bb)
        return req

    def _build_idx(self, lyr, req=None):
        idx = QgsSpatialIndex(); by_id = {}
        it = lyr.getFeatures(req) if req else lyr.getFeatures()
        for f in it:
            g = self._to_proj(f.geometry(), lyr)
            if not g or g.isEmpty(): continue
            ff = QgsFeature(f.id()); ff.setGeometry(g)
            idx.addFeature(ff); by_id[f.id()] = (g, f)
        return idx, by_id

    @staticmethod
    def _endpoints(geom):
        """Estremi (primo/ultimo vertice) delle parti lineari di geom.
        Tipi non lineari (punti, poligoni, o geometrie/collection miste
        senza parti lineari) vengono ignorati invece di produrre risultati
        imprevedibili da asPolyline()."""
        eps = []
        if not geom or geom.isEmpty(): return eps
        if geom.type() != QgsWkbTypes.LineGeometry: return eps
        if geom.isMultipart():
            for p in geom.asGeometryCollection(): eps.extend(FTTHPermessiDialog._endpoints(p))
        else:
            pl = geom.asPolyline()
            if len(pl) >= 2: eps.append((QgsPointXY(pl[0]), QgsPointXY(pl[-1])))
        return eps

    @staticmethod
    def _trova_vicino(pt, idx, by_id, tol):
        bb = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
        for cid in idx.intersects(bb):
            e = by_id.get(cid)
            if e and pt.distance(e[0].asPoint()) <= tol: return e[1]
        return None

    @staticmethod
    def _pte_al_nodo(pa, pb, idx_pte, pte_by, tol):
        """Come _trova_vicino, ma verifica che il ROE PTE trovato sia
        realmente il NODO condiviso fra le due tratte: deve essere entro
        tolleranza sia da pa sia da pb, non solo dal primo estremo. Con
        tolleranze elevate, cercare solo vicino a pa può far scambiare per
        barriera un PTE che in realtà non è il punto di giunzione reale
        fra le due tratte."""
        bb = QgsRectangle(pa.x()-tol, pa.y()-tol, pa.x()+tol, pa.y()+tol)
        for cid in idx_pte.intersects(bb):
            e = pte_by.get(cid)
            if not e: continue
            p_pte = e[0].asPoint()
            if pa.distance(p_pte) <= tol and pb.distance(p_pte) <= tol:
                return e[1]
        return None

    def _unione_layer(self, lyr):
        """Unione di tutte le geometrie del layer in un'unica geometria,
        usata per i test di intersezione/distanza (es. dorsale Cavo Ottico).
        unaryUnion() calcola l'unione in un solo passaggio, molto più
        veloce del combine() ripetuto in loop su layer con molte feature."""
        gs = []
        for f in lyr.getFeatures():
            g = self._to_proj(f.geometry(), lyr)
            if g and not g.isEmpty(): gs.append(self._valida(g))
        if not gs: return None
        return QgsGeometry.unaryUnion(gs)

    # ═════════════════════════════════ CAMPI – COMPATIBILITÀ PROVIDER
    @staticmethod
    def _limite_nome_campo(layer):
        """Lunghezza massima ammessa per un nome di campo su questo layer, o
        None se il provider non ha un limite stretto.

        Serve perché il formato Shapefile/DBF tronca i nomi a 10 caratteri:
        se si chiede di creare 'Chilometrica' (12 caratteri) OGR crea davvero
        'Chilometri' e QGIS, che al commit confronta il campo atteso con quello
        riletto dal provider, fallisce con 'il campo con indice N non è
        uguale!' e fa rollback. Troncando il nome PRIMA di aggiungerlo,
        atteso e riletto coincidono e il salvataggio va a buon fine."""
        try:
            tipo = (layer.dataProvider().storageType() or "").lower()
        except Exception:
            return None
        if "shapefile" in tipo or "dbf" in tipo or "mapinfo" in tipo:
            return 10
        return None

    @staticmethod
    def _nome_campo_compatibile(layer, nome):
        """Nome di campo effettivamente creabile su `layer`: accenti rimossi,
        caratteri non alfanumerici sostituiti con '_', e troncatura al limite
        del provider (10 caratteri su Shapefile). Su GeoPackage/PostGIS/memory
        il nome resta invariato."""
        pulito = unicodedata.normalize("NFKD", str(nome).strip())
        pulito = "".join(c for c in pulito if not unicodedata.combining(c))
        pulito = re.sub(r"[^0-9A-Za-z_]", "_", pulito).strip("_")
        if not pulito:
            return ""
        if pulito[0].isdigit():
            pulito = "f" + pulito
        limite = FTTHPermessiDialog._limite_nome_campo(layer)
        if limite:
            pulito = pulito[:limite]
        return pulito

    def _indice_campo(self, layer, nome):
        """Indice del campo `nome` sul layer, tollerante alle differenze che i
        provider introducono da soli: confronto senza distinzione di
        maiuscole (lookupField) e ripiego sul nome troncato/normalizzato, così
        un campo scritto su Shapefile come 'Chilometri' viene trovato anche
        cercando 'Chilometrica'."""
        campi = layer.fields()
        for candidato in (nome, self._nome_campo_compatibile(layer, nome)):
            if not candidato:
                continue
            i = campi.indexOf(candidato)
            if i >= 0:
                return i
            i = campi.lookupField(candidato)
            if i >= 0:
                return i
        return -1

    def _assicura_campo(self, lyr, nome, tipo_testo=True, lunghezza=20, precisione=2):
        """Garantisce che `lyr` abbia il campo `nome`, creandolo se manca.

        Ritorna (indice, nome_reale, esito) dove esito è 'presente', 'creato'
        oppure un testo che inizia con 'fallito'. Il nome viene adattato al
        provider prima dell'aggiunta (vedi _nome_campo_compatibile): sugli
        shapefile 'Chilometrica' diventa 'Chilometri', altrimenti il commit
        fallirebbe perché QGIS confronta il campo atteso con quello riletto dal
        file. Usato sia dal punto 0 delle chilometriche sia dalla scheda
        Etichette, così la regola sta scritta in un solo posto."""
        i = self._indice_campo(lyr, nome)
        if i >= 0:
            return i, lyr.fields().at(i).name(), "presente"

        nome_eff = self._nome_campo_compatibile(lyr, nome)
        if not nome_eff:
            return -1, "", f"fallito: '{nome}' non è un nome di campo valido"
        if not self._start_edit(lyr):
            return -1, nome_eff, "fallito: impossibile avviare la modifica"

        campo = (QgsField(nome_eff, QVariant.String, "string", lunghezza) if tipo_testo
                 else QgsField(nome_eff, QVariant.Double, "double", 15, precisione))
        if not lyr.addAttribute(campo):
            lyr.rollBack()
            return -1, nome_eff, "fallito: il provider ha rifiutato l'aggiunta del campo"
        lyr.updateFields()
        if not self._commit(lyr, f"Creazione campo su {lyr.name()}"):
            return -1, nome_eff, "fallito: commit rifiutato (vedi popup)"
        lyr.updateFields()
        i = self._indice_campo(lyr, nome_eff)
        if i < 0:
            return -1, nome_eff, "fallito: commit riuscito ma il campo non risulta presente"
        return i, lyr.fields().at(i).name(), "creato"

    def _start_edit(self, layer):
        """Avvia l'editing se non già attivo. Ritorna True se il layer è
        (o è diventato) editabile."""
        return layer.isEditable() or layer.startEditing()

    def _commit(self, layer, titolo="Errore salvataggio"):
        """commitChanges() con dettaglio degli errori: se il commit fallisce
        mostra layer.commitErrors() (spesso indica subito la causa reale,
        es. vincoli del provider) invece del solo esito booleano, e fa
        rollback per non lasciare il layer in uno stato inconsistente."""
        if layer.commitChanges():
            return True
        dettagli = layer.commitErrors()
        msg = "\n".join(dettagli) if dettagli else "Errore sconosciuto durante il salvataggio."
        QMessageBox.critical(self, titolo, f"Impossibile salvare le modifiche su '{layer.name()}':\n{msg}")
        layer.rollBack()
        return False

    def _crea_layer_output(self, nome, wkb_type_str, attr_fields, chiave):
        """Crea da zero un layer 'memory' (RAM, nessun file coinvolto) con
        questo nome e questi campi, lo aggiunge al progetto, e rimuove
        l'eventuale layer generato in precedenza dalla stessa chiave
        ('keyplan' / 'inquadramento'). Un layer 'memory' fresco ad ogni
        generazione non ha NESSUNO dei problemi di fid/cache che affliggono
        i provider su file (GeoPackage/Shapefile): niente viene mai scritto
        dentro un GeoPackage, quindi il problema del fid non può più
        presentarsi. Per salvare il risultato in modo permanente, l'utente
        userà la funzione nativa di QGIS 'Esporta → Salva le entità con
        nome…' sul layer generato, quando è soddisfatto del risultato."""
        vecchio = self._output_layers.get(chiave)
        if vecchio is not None:
            try:
                if vecchio.id() in self.project.mapLayers():
                    self.project.removeMapLayer(vecchio.id())
            except Exception as e:
                _log_avviso("rimozione del layer di output precedente non riuscita", e)
        crs = self.project.crs().authid()
        lyr = QgsVectorLayer(f"{wkb_type_str}?crs={crs}", nome, "memory")
        pr = lyr.dataProvider()
        pr.addAttributes(list(attr_fields))
        lyr.updateFields()
        self.project.addMapLayer(lyr)
        self._output_layers[chiave] = lyr
        return lyr

    def _su_cavo(self, geom_tratta, cavo_union, tol):
        """True se la tratta corre LUNGO il cavo ottico (intersezione lineare,
        non solo incrocio puntuale). Un incrocio a 90° dà lunghezza ~0."""
        if not cavo_union or cavo_union.isEmpty(): return False
        try:
            inter = self._valida(geom_tratta).intersection(cavo_union)
        except Exception:
            return False
        if not inter or inter.isEmpty(): return False
        return inter.length() > tol

    def _find_layer(self, *nomi):
        """Primo layer che corrisponde a uno dei nomi dati, in ordine di
        preferenza. Match esatto prima su tutti i nomi, poi case-insensitive.
        Accetta più nomi alternativi (es. 'Poligoni di Inquadramento' nei
        progetti reali vs 'Poligoni Inquadramento' generato dal plugin)."""
        cand = []
        for n in nomi:
            if isinstance(n, (list, tuple)):
                cand.extend(n)
            else:
                cand.append(n)
        for nome in cand:
            for l in self.project.mapLayers().values():
                if l.name() == nome:
                    return l
        for nome in cand:
            for l in self.project.mapLayers().values():
                if l.name().strip().lower() == nome.strip().lower():
                    return l
        return None

    def refresh_layers(self):
        """Assegna ad ogni combo il layer con il nome atteso (convenzione di
        progetto), se esiste. NON si limita più al caso 'combo vuoto'
        (currentLayer() is None): un QgsMapLayerComboBox con
        allow_empty=False seleziona da solo un layer qualsiasi (il primo
        disponibile) appena creato o quando cambia l'elenco dei layer nel
        progetto, quindi currentLayer() può risultare 'valorizzato' con il
        layer SBAGLIATO senza che questo venga mai corretto — causa concreta
        di un'estensione calcolata sul layer sbagliato (es. su un modello
        Keyplan invece che su ARLO AREA). Ora il nome atteso ha sempre la
        precedenza quando il layer esiste nel progetto."""
        preset = {
            self.cb_infra:    "03 INFRASTRUTTURE",
            self.cb_civici:   "CIVICI",
            self.cb_pte:      "ROE PTE",
            self.cb_pozzetto: "02_POZZETTO",
            self.cb_cavo:     "CAVO OTTICO",
            self.cb_cavo_raccordo: "RACCORDI",
            self.cb_k_armadio: "01_ARMADIO OTTICO",
            self.cb_k_foto:    "Punto di Ripresa Fotografico",
            self.cb_kp_infra:  "03 INFRASTRUTTURE",
            self.cb_kp_arlo:   "ARLO AREA",
            # combo MODELLO della scheda Keyplan e tavole: puntano ai layer
            # modello presenti nei progetti reali (nomi verificati). Il Keyplan
            # modello A è 'Keyplan Quadrato'; il modello A delle Tavole di
            # inquadramento è 'Poligoni di Inquadramento' (col 'di', diverso dal
            # layer 'Poligoni Inquadramento' che il plugin GENERA).
            self.cb_kp_keyplan:  "Keyplan Quadrato",
            self.cb_ti_tmpl_a:   "Poligoni di Inquadramento",
            self.cb_kf_tavole:   ("Poligoni di Inquadramento", "Poligoni Inquadramento"),
            self.cb_num_keyplan: "Keyplan",
            self.cb_num_tavole:  ("Poligoni di Inquadramento", "Poligoni Inquadramento"),
            self.cb_kf_infra:    "03 INFRASTRUTTURE",
            self.cb_kf_pozzetto: "02_POZZETTO",
            self.cb_al_armadio:  "01_ARMADIO OTTICO",
            self.cb_al_infra:    "03 INFRASTRUTTURE",
            self.cb_al_poz:      "02_POZZETTO",
            self.cb_al_pte:      "ROE PTE",
            self.cb_al_cavo:     "CAVO OTTICO",
            self.cb_al_raccordo: "RACCORDI",
            self.cb_et_armadio:  "01_ARMADIO OTTICO",
            self.cb_et_poz:      "02_POZZETTO",
            self.cb_et_infra:    "03 INFRASTRUTTURE",
            # scheda Chilometriche (v0.78.5): all'apertura i layer del flusso
            # tipico sono già impostati — cippi, target Infrastrutture e
            # pozzetti per l'aggancio dei capi; per lo stradario di
            # riferimento vale l'elenco di candidati qui sotto
            self.cb_km_ancore:   "Cippi_Chilometrici",
            self.cb_km_target:   "03 INFRASTRUTTURE",
            self.cb_km_pozzetti: "02_POZZETTO",
        }
        # Scheda 'Unisci tratte': i combo esistono solo se il mixin si è
        # caricato, quindi si aggiungono qui e non nel dizionario letterale
        # (un AttributeError lì dentro farebbe saltare TUTTI i preset).
        # Senza questo il combo puntuale pescava il primo layer di punti del
        # progetto — in pratica '01_ARMADIO OTTICO' invece di '02_POZZETTO',
        # cioè l'opposto della regola: sono i POZZETTI che interrompono la
        # fusione, mentre un armadio non spezza affatto una tratta.
        if hasattr(self, "cb_un_infra"):
            preset[self.cb_un_infra] = "03 INFRASTRUTTURE"
        if hasattr(self, "cb_un_poz"):
            preset[self.cb_un_poz] = "02_POZZETTO"
        # linea di riferimento delle Chilometriche: primo candidato presente
        for nome_rif_km in ("Stradario Provincia Italia", "ANAS_Italia",
                            "Stradario", "Rete stradale"):
            if self._find_layer(nome_rif_km) is not None:
                preset[self.cb_km_riferimento] = nome_rif_km
                break
        # area di progetto dello Screening territorio: i progetti la chiamano
        # in modi leggermente diversi ("ARLO AREA", "Arlo Area"); il combo non
        # deve mai ripiegare su un poligono qualsiasi, quindi senza candidati
        # resta vuoto e ci pensa l'utente
        for nome_arlo in ("ARLO AREA", "Arlo Area", "ARLO_AREA", "ARLO"):
            if self._find_layer(nome_arlo) is not None:
                preset[self.cb_scr_arlo] = nome_arlo
                break
        # i combo della scheda 'Esportazione' esistono in più copie (Comune e
        # Altri Enti): il preset va applicato ad ognuna, non solo all'ultima
        # costruita, altrimenti la prima scheda resta con il layer sbagliato
        for ctx in self._contesti_consegna:
            # lo stradario dell'evidenza non deve mai partire da un layer
            # qualsiasi: se nessuno di questi nomi esiste il combo resta come sta
            # e l'utente lo scegli a mano. Il combo evidenza esiste SOLO nella
            # copia Altri Enti (da v0.93): salta la copia Comune che non ce l'ha
            if "cb_ev_stradario" in ctx:
                for nome_stradario in ("Stradario Provincia Italia", "Stradario",
                                       "Rete stradale", "Grafo stradale"):
                    strada = self._find_layer(nome_stradario)
                    if strada is not None:
                        preset[ctx["cb_ev_stradario"]] = nome_stradario
                        break
            preset[ctx["cb_c_foto"]]    = "Punto di Ripresa Fotografico"
            preset[ctx["cb_c_infra"]]   = "03 INFRASTRUTTURE"
            preset[ctx["cb_c_poz"]]     = "02_POZZETTO"
            preset[ctx["cb_c_armadio"]] = "01_ARMADIO OTTICO"
            # Stradario dell'Esportazione: default 'Stradario_Italia_Join'
            # (copia dello stradario nazionale con i soli tratti nominati, name
            # sempre valorizzato — ottimizzata per il join). Vale per entrambi i
            # rami. È un combo con opzione vuoto: se il layer non c'è resta vuoto
            # e lo sceglie l'utente.
            preset[ctx["cb_c_strada"]] = "Stradario_Italia_Join"

        try:
            self._popola_elenchi_suolo()
        except Exception as e:
            _log_avviso("preset della scheda Suolo comunale non applicato", e)

        # Scheda Shape → GeoPackage: il combo deve partire già puntato sullo
        # SHAPEFILE dei pozzetti da convertire (non su un layer qualsiasi né su
        # un .gpkg già convertito). La ricerca è per caratteristiche, non per
        # nome esatto, perché i progetti chiamano il layer in modi diversi.
        try:
            self._s2g_imposta_default()
        except Exception as e:
            _log_avviso("preselezione shape pozzetto (Shape → GeoPackage) non applicata", e)

        # Keyplan modello B: campo OPZIONALE, deve restare vuoto finché non lo
        # scegli tu. Il combo si ripopola a ogni refresh e QGIS gli rimette
        # dentro il primo vettoriale del progetto (01_ARMADIO OTTICO): preso per
        # modello di tavola darebbe una seconda forma ricavata dall'armadio.
        # Si azzera solo se punta a un layer che non è un modello keyplan.
        try:
            lb = self.cb_kp_keyplan2.currentLayer()
            if lb is not None and "keyplan" not in (lb.name() or "").lower():
                self.cb_kp_keyplan2.setLayer(None)
        except Exception as e:
            _log_avviso("azzeramento Keyplan modello B non riuscito", e)

        # Inquadramento modello B: stessa storia, stesso rimedio.
        try:
            lb = self.cb_ti_tmpl_b.currentLayer()
            if lb is not None and not any(
                    k in (lb.name() or "").lower() for k in ("inquadr", "tavol", "keyplan")):
                self.cb_ti_tmpl_b.setLayer(None)
        except Exception as e:
            _log_avviso("azzeramento Inquadramento modello B non riuscito", e)

        # Campi OPZIONALI dei Punti di ripresa: devono restare VUOTI finché non
        # li scegli tu. Senza preset QGIS ci infila il primo layer compatibile,
        # e il risultato osservato era «Strade ANAS = 03 INFRASTRUTTURE» e
        # «Sedime Pubblico = Aree d'acqua»: non un difetto estetico, perché i
        # coni verrebbero generati trattando le infrastrutture come strade ANAS
        # e il sedime come specchi d'acqua. Si azzerano quando il layer dentro
        # non c'entra niente con il ruolo del campo.
        opzionali_ripresa = (
            ("cb_k_stradario", ("stradario", "strada", "strade", "rete stradale",
                                "grafo", "viabilit")),
            ("cb_k_sedime",    ("sedime", "suolo", "demani", "pubblic", "proprieta")),
            ("cb_kf_prov",     ("provinc", "sp ", "_sp", "sp_")),
            ("cb_kf_anas",     ("anas", "statal", "ss ", "_ss", "ss_")),
        )
        for attr, chiavi in opzionali_ripresa:
            try:
                cb = getattr(self, attr, None)
                if cb is None: continue
                lb = cb.currentLayer()
                if lb is not None and not any(k in (lb.name() or "").lower() for k in chiavi):
                    cb.setLayer(None)
            except Exception as e:
                _log_avviso(f"azzeramento del campo opzionale {attr} non riuscito", e)

        # Tavole di Inquadramento della scheda Keyplan: resta vuoto finché non lo
        # scegli tu. Valorizzato, la copertura va sull'impronta delle tavole e
        # non sull'area di progetto — con un preset era attivo senza che nessuno
        # l'avesse chiesto.
        try:
            if not getattr(self, "_kp_tavole_scelto", False):
                self.cb_kp_tavole.setLayer(None)
        except Exception as e:
            _log_avviso("azzeramento Tavole di Inquadramento (Keyplan) non riuscito", e)

        # Livello strade della scheda Edifici (v0.78.2): NESSUN preset. Il
        # preset per nome ("Strade DBSN", introdotto in 0.77) scavalcava il
        # livello giusto riconosciuto dentro il gruppo regione — 'DBSN Strade
        # (carreggiata reale)' — e faceva girare l'analisi su un layer
        # sbagliato: risultato, una manciata di edifici trovati su migliaia.
        # Il combo resta vuoto di default, che significa "usa il livello del
        # gruppo della regione selezionata": è la scelta giusta nel flusso
        # DBSN, e chi ha le strade fuori dai gruppi lo imposta a mano.

        # Livello strade della scheda Edifici: default Stradario_Italia (v2.3+).
        # Da quando lo stradario nazionale unico ha sostituito i DBSN regionali,
        # le strade non stanno più nei gruppi regione (che portano solo edifici):
        # si usa Stradario_Italia come fonte strade per ogni regione. Il combo ha
        # precedenza sul riconoscimento per gruppo (vedi _strade_da_usare) e la
        # ricerca regioni ora accetta i gruppi coi soli edifici quando questo
        # combo è impostato (vedi _gruppi_lavorabili). Se il layer non c'è il
        # combo resta vuoto e vale il vecchio flusso "strade dentro il gruppo".
        try:
            _strad_ed = self._find_layer("Stradario_Italia")
            if _strad_ed is not None and self.cb_ed_strade.currentLayer() is None:
                self.cb_ed_strade.setLayer(_strad_ed)
        except Exception as e:
            _log_avviso("preset stradario scheda Edifici non applicato", e)

        for cb, nome in preset.items():
            l = self._find_layer(nome)
            if l and cb.currentLayer() != l:
                cb.setLayer(l)

        # Screening territorio: preseleziona lo stradario di riferimento
        # migliore disponibile (DBSN > regionale > estratto OSM), solo se
        # l'utente non ne ha già scelto uno a mano. Vedi _scegli_stradario_auto.
        if self.cb_scr_stradario.currentLayer() is None:
            lyr, campo = self._scegli_stradario_auto(self.cb_scr_arlo.currentLayer())
            if lyr is not None and campo:
                self.cb_scr_stradario.setLayer(lyr)   # popola il combo dei campi (slot connesso)
                self.cb_scr_campo.setField(campo)
                self.chk_scr_stradario.setChecked(True)

    # campo che porta la sigla stradale, in ordine di preferenza; il primo
    # presente vince. tr_str_nom = DBSN (IGM); trim_str_c = Stradario FVG;
    # ref = estratti OSM (ANAS_Italia, Stradario Provincia Italia)
    _CAMPI_SIGLA_STRADARIO = ("tr_str_nom", "trim_str_c", "ref")

    def _campo_sigla_stradario(self, layer):
        nomi = {f.name().lower(): f.name() for f in layer.fields()}
        for pref in self._CAMPI_SIGLA_STRADARIO:
            if pref in nomi:
                return nomi[pref]
        return None

    def _scegli_stradario_auto(self, arlo_layer=None):
        """Sceglie il miglior layer stradario del progetto da usare come fonte
        primaria delle strade. Ritorna (layer, campo_sigla) o (None, None).

        Priorità: 1) DBSN Strade (IGM, indipendente da OSM); 2) stradario
        regionale (indipendente); 3) estratto OSM (ANAS_Italia, Stradario
        Provincia Italia). A parità, preferisce i layer la cui ESTENSIONE
        interseca l'area di progetto: così nei progetti con più DBSN regionali
        viene scelto quello che copre davvero l'ARLO, non il primo in elenco."""
        from qgis.core import QgsVectorLayer, QgsWkbTypes
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")

        arlo_bbox = None
        if arlo_layer is not None:
            try:
                tr = QgsCoordinateTransform(arlo_layer.crs(), wgs, self.project)
                arlo_bbox = tr.transformBoundingBox(arlo_layer.extent())
            except Exception as e:
                _log_avviso("estensione ARLO per auto-stradario", e)

        candidati = []
        for l in self.project.mapLayers().values():
            if not isinstance(l, QgsVectorLayer):
                continue
            if QgsWkbTypes.geometryType(l.wkbType()) != QgsWkbTypes.LineGeometry:
                continue
            campo = self._campo_sigla_stradario(l)
            if not campo:
                continue
            nomi_campi = {f.name().lower() for f in l.fields()}
            is_osm = "osm_id" in nomi_campi
            nome = l.name().lower()
            if "dbsn" in nome and "strade" in nome and campo == "tr_str_nom":
                prio = 1
            elif not is_osm:
                prio = 2           # stradario regionale/altro non-OSM
            else:
                prio = 3           # estratto OSM
            # l'estensione interseca l'ARLO? (0 = sì/ignoto, 10 = no → in coda)
            fuori = 0
            if arlo_bbox is not None:
                try:
                    trl = QgsCoordinateTransform(l.crs(), wgs, self.project)
                    if not trl.transformBoundingBox(l.extent()).intersects(arlo_bbox):
                        fuori = 10
                except Exception:
                    fuori = 0
            candidati.append((fuori, prio, l.name(), l, campo))

        if not candidati:
            return None, None
        candidati.sort(key=lambda x: (x[0], x[1], x[2]))
        best = candidati[0]
        return best[3], best[4]

    # ═══════════════════════════════════════════════ PULIZIA – LOGICA
    def _diagnostica(self):
        infra = self.cb_infra.currentLayer()
        if not infra: QMessageBox.warning(self, "Attenzione", "Seleziona Infrastrutture."); return
        tol = self.spin_tol.value(); righe = [f"CRS progetto: {self.project.crs().authid()}  |  Tolleranza: {tol}"]
        eps = []
        for f in infra.getFeatures():
            g = self._to_proj(f.geometry(), infra)
            for p1, p2 in self._endpoints(g): eps.extend([p1, p2])
        for nome, lyr in (("Civici", self.cb_civici.currentLayer()), ("ROE PTE", self.cb_pte.currentLayer())):
            if not lyr: continue
            md = None
            for f in lyr.getFeatures():
                g = self._to_proj(f.geometry(), lyr)
                if not g: continue
                p = QgsPointXY(g.asPoint())
                for ep in eps:
                    d = p.distance(ep)
                    if md is None or d < md: md = d
            righe.append(f"Dist. min estremi Infra → {nome}: {md:.5f}" if md is not None else f"{nome}: nessun dato")
        self.log_p.setPlainText("\n".join(righe))

    @staticmethod
    def _pte_light_collegato(pt_light, idx_pte, pte_by, racc_eps, tol, trova_vicino):
        """True se pt_light (posizione di un ROE PTE 'PTE Light Diramatore') è
        collegato, tramite una tratta dello shape Cavo Raccordo, a un ALTRO
        ROE PTE (di qualsiasi tipologia) diverso da se stesso."""
        for pa, pb in racc_eps:
            for estremo, altro in ((pa, pb), (pb, pa)):
                if pt_light.distance(estremo) > tol: continue
                if pt_light.distance(altro) <= tol: continue
                if trova_vicino(altro, idx_pte, pte_by, tol):
                    return True
        return False

    def _trova_tratte(self, infra, civici, pte, tol, cavo, ferma_a_pte, cavo_racc=None):
        expr = f'"{CAMPO_STATO}" = \'{VAL_NUOVO}\''
        dati = {}
        for feat in infra.getFeatures(QgsFeatureRequest().setFilterExpression(expr)):
            g = self._to_proj(feat.geometry(), infra)
            eps = self._endpoints(g)
            if not eps: continue
            p1, p2 = eps[0]
            dati[feat.id()] = {"g": g, "p1": p1, "p2": p2}
        if not dati: return {}, 0, 0, 0

        # indici civici e PTE
        idx_civ, civ_by = self._build_idx(civici)
        idx_pte, pte_by = self._build_idx(pte)
        campo_tip_pte_ok = pte.fields().indexOf(CAMPO_TIP_PTE) >= 0

        # estremi delle tratte dello shape Cavo Raccordo (bretelle tra PTE),
        # usate per individuare un PTE Light Diramatore condiviso con un
        # altro PTE
        racc_eps = []
        if cavo_racc:
            for f in cavo_racc.getFeatures():
                g = self._to_proj(f.geometry(), cavo_racc)
                racc_eps.extend(self._endpoints(g))

        # tratte che toccano civico direttamente (SEMPRE selezionate)
        su_civico = set()
        for fid, d in dati.items():
            for pt in (d["p1"], d["p2"]):
                if self._trova_vicino(pt, idx_civ, civ_by, tol):
                    su_civico.add(fid); break

        # unione cavo ottico per check intersezione lineare
        cavo_u = self._unione_layer(cavo) if cavo else None

        # tratte che corrono lungo il cavo (escluse dalla catena, ma NON se su_civico)
        su_cavo = set()
        if cavo_u:
            for fid, d in dati.items():
                if fid not in su_civico and self._su_cavo(d["g"], cavo_u, tol):
                    su_cavo.add(fid)

        # union-find sulla connettività degli estremi: un ROE PTE di QUALSIASI
        # tipologia (compreso "PTE Light Diramatore") funge da BARRIERA — la
        # catena non viene unita oltre un punto in cui è presente un PTE,
        # perché da lì la tratta può proseguire condivisa verso un altro PTE.
        uf = _UF(list(dati.keys()))
        ep_idx = QgsSpatialIndex(); ep_own = {}; eid = 0
        for fid, d in dati.items():
            for pt in (d["p1"], d["p2"]):
                ef = QgsFeature(eid); ef.setGeometry(QgsGeometry.fromPointXY(pt))
                ep_idx.addFeature(ef); ep_own[eid] = (fid, pt); eid += 1
        n_barriera = 0
        for ea, (ta, pa) in ep_own.items():
            bb = QgsRectangle(pa.x()-tol, pa.y()-tol, pa.x()+tol, pa.y()+tol)
            for eb in ep_idx.intersects(bb):
                if eb == ea: continue
                tb, pb = ep_own[eb]
                if tb == ta or pa.distance(pb) > tol: continue
                if ferma_a_pte and self._pte_al_nodo(pa, pb, idx_pte, pte_by, tol):
                    n_barriera += 1; continue
                uf.union(ta, tb)

        result = {}; n_cat = 0; n_escl_light = 0
        for _, membri in uf.groups().items():
            ha_civico = any(m in su_civico for m in membri)
            if not ha_civico: continue
            # il gruppo è una catena valida solo se tocca un PTE da qualche
            # parte; teniamo traccia di TUTTI i PTE toccati (non solo il
            # primo) per poter verificare l'eventuale PTE Light condiviso
            pte_tocchi = {}
            for m in membri:
                for pt in (dati[m]["p1"], dati[m]["p2"]):
                    fp = self._trova_vicino(pt, idx_pte, pte_by, tol)
                    if fp: pte_tocchi[fp.id()] = (fp, pt)
            pte_ok = bool(pte_tocchi)
            n_cat += 1

            # se la catena arriva a un PTE Light Diramatore che è a sua volta
            # collegato, tramite il Cavo Raccordo, a un ALTRO ROE PTE, si
            # tratta di un raccordo condiviso con un altro permesso: l'intera
            # catena (tratte + pozzetti) va esclusa dalla selezione
            escludi_light = False
            if pte_ok and racc_eps and campo_tip_pte_ok:
                for fp, pt_pte in pte_tocchi.values():
                    if fp[CAMPO_TIP_PTE] == VAL_PTE_LIGHT and self._pte_light_collegato(
                        pt_pte, idx_pte, pte_by, racc_eps, tol, self._trova_vicino
                    ):
                        escludi_light = True; break
            if escludi_light:
                n_escl_light += 1
                continue

            for m in membri:
                # la tratta che tocca direttamente il Civico è SEMPRE
                # selezionata. Le altre tratte della stessa catena vengono
                # selezionate anche se la catena non raggiunge ancora un PTE
                # (non è più richiesto pte_ok): l'unico motivo di esclusione,
                # a parte il raccordo condiviso già gestito sopra, è correre
                # lungo il Cavo Ottico (dorsale condivisa con altri permessi).
                if m in su_civico or m not in su_cavo:
                    result[m] = dati[m]["g"]
        return result, n_cat, n_barriera // 2, len(su_cavo), n_escl_light

    def _trova_pozzetti(self, poz_lyr, tratte, tol, pte=None, cavo=None):
        if not tratte: return [], 0, 0
        idx = QgsSpatialIndex()
        for fid, g in tratte.items():
            f = QgsFeature(fid); f.setGeometry(g); idx.addFeature(f)
        idx_pte, pte_by = self._build_idx(pte) if pte else (None, None)
        cavo_u = self._unione_layer(cavo) if cavo else None
        ids = []; n_pte = 0; n_cavo = 0
        for fp in poz_lyr.getFeatures():
            gp = self._to_proj(fp.geometry(), poz_lyr)
            if not gp or gp.isEmpty(): continue
            pt = QgsPointXY(gp.asPoint())
            g_pt = QgsGeometry.fromPointXY(pt)  # costruita una sola volta per pozzetto
            bb = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
            hit = any(
                g_pt.distance(tratte[cid]) <= tol
                for cid in idx.intersects(bb) if cid in tratte
            )
            if not hit: continue
            # escludi il pozzetto sede di un PTE
            if idx_pte and self._trova_vicino(pt, idx_pte, pte_by, tol):
                n_pte += 1; continue
            # escludi il pozzetto toccato dal Cavo Ottico (dorsale condivisa)
            if cavo_u and not cavo_u.isEmpty() and g_pt.distance(cavo_u) <= tol:
                n_cavo += 1; continue
            ids.append(fp.id())
        return ids, n_pte, n_cavo

    def _r1(self):
        infra = self.cb_infra.currentLayer(); civici = self.cb_civici.currentLayer()
        pte   = self.cb_pte.currentLayer();   poz    = self.cb_pozzetto.currentLayer()
        cavo  = self.cb_cavo.currentLayer()
        cavo_racc = self.cb_cavo_raccordo.currentLayer()
        if not infra or not civici or not pte:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture, Civici e ROE PTE."); return
        tol = self.spin_tol.value()
        tratte, n_cat, n_barriera, n_cavo, n_escl_light = self._trova_tratte(
            infra, civici, pte, tol,
            cavo if self.chk_no_cavo.isChecked() else None,
            self.chk_pte_light.isChecked(),
            cavo_racc,
        )
        infra.removeSelection(); infra.selectByIds(list(tratte.keys()))
        layers = [infra]; msg = [
            f"Tratte selezionate: {len(tratte)}  (catene: {n_cat})",
            f"Punti di barriera a un PTE (catena fermata): {n_barriera}",
            f"Tratte escluse perché corrono lungo il CAVO OTTICO: {n_cavo}",
            f"Catene escluse: PTE Light collegato via Cavo Raccordo ad altro PTE: {n_escl_light}",
        ]
        if poz:
            ids_p, n_pte, n_cavo_poz = self._trova_pozzetti(
                poz, tratte, tol, pte,
                cavo if self.chk_no_cavo.isChecked() else None,
            )
            poz.removeSelection(); poz.selectByIds(ids_p)
            layers.append(poz)
            msg.append(
                f"Pozzetti compresi: {len(ids_p)}  "
                f"(esclusi sede-PTE: {n_pte}, esclusi su CAVO OTTICO: {n_cavo_poz})"
            )
        if tratte: self.iface.mapCanvas().zoomToSelected(infra)
        self._last_layers = layers; self.log_p.setPlainText("\n".join(msg))

    def _r1b(self):
        """Regola indipendente dalla Regola 1: seleziona OGNI tratta
        Infrastrutture (qualsiasi TIPOLOGIA e STATO, nessun filtro) che
        tocca/interseca direttamente un Civico su almeno un estremo, più il
        Pozzetto vicino all'estremo OPPOSTO della stessa tratta (il pozzetto
        "subito dopo" il Civico). A differenza della Regola 1, non segue la
        catena oltre la prima tratta e non si ferma a un PTE: serve proprio
        a coprire i casi che la Regola 1 (STATO='Nuovo' + logica di
        catena/PTE) lascia fuori. Si AGGIUNGE alla selezione corrente invece
        di sostituirla, così può essere usata insieme alla Regola 1.
        Il pozzetto candidato viene escluso se è vera ALMENO UNA di tre
        condizioni indipendenti (basta una sola, non serve che siano tutte
        vere): la tratta di provenienza ha TIPOLOGIA='No Dig', il pozzetto
        è sede di un ROE PTE (di qualsiasi tipologia), oppure il pozzetto è
        toccato dal layer Cavo Ottico (dorsale condivisa)."""
        infra = self.cb_infra.currentLayer(); civici = self.cb_civici.currentLayer()
        poz = self.cb_pozzetto.currentLayer(); pte = self.cb_pte.currentLayer()
        cavo = self.cb_cavo.currentLayer()
        if not infra or not civici:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e Civici."); return
        tol = self.spin_tol.value()
        idx_civ, civ_by = self._build_idx(civici)
        idx_pte, pte_by = self._build_idx(pte) if pte else (None, None)
        cavo_u = self._unione_layer(cavo) if cavo else None
        campo_tip_infra_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0

        ids_infra = []
        estremi_opposti = []  # (punto, TIPOLOGIA tratta) da cui cercare il Pozzetto "subito dopo"
        for feat in infra.getFeatures():  # nessun filtro TIPOLOGIA/STATO
            g = self._to_proj(feat.geometry(), infra)
            eps = self._endpoints(g)
            if not eps: continue
            p1, p2 = eps[0]
            tocca1 = self._trova_vicino(p1, idx_civ, civ_by, tol) is not None
            tocca2 = self._trova_vicino(p2, idx_civ, civ_by, tol) is not None
            if not (tocca1 or tocca2): continue
            ids_infra.append(feat.id())
            tip = feat[CAMPO_TIP_INFRA] if campo_tip_infra_ok else None
            if tocca1 and not tocca2: estremi_opposti.append((p2, tip))
            elif tocca2 and not tocca1: estremi_opposti.append((p1, tip))
            else: estremi_opposti.extend([(p1, tip), (p2, tip)])  # tratta tra due Civici

        ids_infra_prima = set(infra.selectedFeatureIds())
        ids_infra_finali = sorted(ids_infra_prima | set(ids_infra))
        infra.selectByIds(ids_infra_finali)
        layers = [infra]
        msg = [
            f"Tratte a contatto diretto col Civico (qualsiasi tipologia/stato): {len(ids_infra)} "
            f"(selezione Infrastrutture totale: {len(ids_infra_finali)})"
        ]

        if poz and estremi_opposti:
            idx_poz, poz_by = self._build_idx(poz)
            ids_poz = set(); ids_no_dig = set(); ids_sede_pte = set(); ids_cavo = set()
            for pt, tip in estremi_opposti:
                fp = self._trova_vicino(pt, idx_poz, poz_by, tol)
                if not fp: continue
                escludi = False
                if tip == VAL_NO_DIG:
                    ids_no_dig.add(fp.id()); escludi = True
                g_poz = poz_by[fp.id()][0]
                p_poz = QgsPointXY(g_poz.asPoint())
                if idx_pte and self._trova_vicino(p_poz, idx_pte, pte_by, tol) is not None:
                    ids_sede_pte.add(fp.id()); escludi = True
                if cavo_u and not cavo_u.isEmpty() and QgsGeometry.fromPointXY(p_poz).distance(cavo_u) <= tol:
                    ids_cavo.add(fp.id()); escludi = True
                if escludi: continue  # esclusione indipendente: basta UNA delle tre condizioni
                ids_poz.add(fp.id())
            ids_poz_prima = set(poz.selectedFeatureIds())
            ids_poz_finali = sorted(ids_poz_prima | ids_poz)
            poz.selectByIds(ids_poz_finali)
            layers.append(poz)
            dettaglio_escl = []
            if ids_no_dig: dettaglio_escl.append(f"tratta '{VAL_NO_DIG}': {len(ids_no_dig)}")
            if ids_sede_pte: dettaglio_escl.append(f"sede-PTE: {len(ids_sede_pte)}")
            if ids_cavo: dettaglio_escl.append(f"su CAVO OTTICO: {len(ids_cavo)}")
            msg.append(
                f"Pozzetti subito dopo la tratta: {len(ids_poz)} "
                f"(selezione Pozzetto totale: {len(ids_poz_finali)}"
                + (f", esclusi — {', '.join(dettaglio_escl)}" if dettaglio_escl else "")
                + ")"
            )

        if ids_infra: self.iface.mapCanvas().zoomToSelected(infra)
        # si aggiunge (non sostituisce) ai layer dell'ultima operazione, così
        # "Rimuovi elementi selezionati" tiene conto anche di questa regola
        # se usata insieme alla Regola 1 nella stessa sessione
        self._last_layers = list(dict.fromkeys(self._last_layers + layers))
        self.log_p.setPlainText("\n".join(msg))

    def _r2(self):
        infra = self.cb_infra.currentLayer(); pte = self.cb_pte.currentLayer()
        if not infra or not pte:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e ROE PTE."); return
        if pte.fields().indexOf(CAMPO_TIPO_PTE) < 0:
            QMessageBox.critical(self, "Campo mancante", f"ROE PTE non ha il campo '{CAMPO_TIPO_PTE}'."); return
        tol = self.spin_tol.value()
        idx_pte, pte_by = self._build_idx(pte)
        pte_int = {f.id() for f in pte.getFeatures() if f[CAMPO_TIPO_PTE] in VALORI_PTE_INT}
        req = QgsFeatureRequest().setFilterExpression(f'"{CAMPO_STATO}" = \'{VAL_NUOVO}\'') if self.chk_r2_nuovo.isChecked() else None
        ids = []
        for feat in (infra.getFeatures(req) if req else infra.getFeatures()):
            g = self._to_proj(feat.geometry(), infra)
            for p1, p2 in self._endpoints(g):
                for pt in (p1, p2):
                    fp = self._trova_vicino(pt, idx_pte, pte_by, tol)
                    if fp and fp.id() in pte_int: ids.append(feat.id()); break
                else: continue; break
        infra.removeSelection(); infra.selectByIds(ids)
        if ids: self.iface.mapCanvas().zoomToSelected(infra)
        self._last_layers = [infra]; self.log_p.setPlainText(f"Tratte che toccano PTE interno: {len(ids)}")

    def _r3(self):
        infra = self.cb_infra.currentLayer(); poz = self.cb_pozzetto.currentLayer()
        if not infra or not poz:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Infrastrutture e Pozzetto."); return
        tol = self.spin_tol.value()
        idx_i, i_by = self._build_idx(infra)
        campo_tip_infra_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0
        ids = []
        for fp in poz.getFeatures():
            gp = self._to_proj(fp.geometry(), poz)
            if not gp or gp.isEmpty(): continue
            pt = QgsPointXY(gp.asPoint())
            bb = QgsRectangle(pt.x()-tol, pt.y()-tol, pt.x()+tol, pt.y()+tol)
            tocca = tocca_n = False
            for cid in idx_i.intersects(bb):
                e = i_by.get(cid)
                if not e: continue
                g_i, f_i = e
                for pp1, pp2 in self._endpoints(g_i):
                    if pt.distance(pp1) <= tol or pt.distance(pp2) <= tol:
                        tocca = True
                        # una tratta Aerea 'Nuovo' NON conta come "nuova
                        # interrata": non deve escludere il pozzetto
                        is_aerea = campo_tip_infra_ok and f_i[CAMPO_TIP_INFRA] == VAL_AEREA
                        if f_i[CAMPO_STATO] == VAL_NUOVO and not is_aerea:
                            tocca_n = True
                        break
            if tocca and not tocca_n: ids.append(fp.id())
        poz.removeSelection(); poz.selectByIds(ids)
        if ids: self.iface.mapCanvas().zoomToSelected(poz)
        self._last_layers = [poz]; self.log_p.setPlainText(f"Pozzetti solo su esistente: {len(ids)}")

    # ═══════════════════════════════════════ ALLINEA CARTOGRAFIA
    @staticmethod
    def _fit_similarity(coppie):
        """Miglior trasformazione di similitudine ai minimi quadrati.
        Implementazione e documentazione in ftth_core.fit_similarity
        (testata in tests/test_core.py)."""
        return ftth_core.fit_similarity(coppie)

    def _mostra_anteprima_trasformazione(self, ris, n_punti, fonte):
        if ris is None:
            self._trasformazione = None
            self.lbl_al_preview.setText("Trasformazione non calcolabile con questi dati (punti insufficienti o tutti coincidenti).")
            return
        a, b, rms = ris
        self._trasformazione = (a, b)
        scala = abs(a); rot = math.degrees(math.atan2(a.imag, a.real))
        self.lbl_al_preview.setText(
            f"Trasformazione calcolata da {fonte} ({n_punti} punti): rotazione {rot:.2f}°, "
            f"scala {scala:.5f}, traslazione ({b.real:.2f}, {b.imag:.2f}) m, "
            f"errore residuo RMS {rms:.2f} m. Verifica che sia plausibile prima di applicarla."
        )

    def _avvia_cattura_coppia(self):
        canvas = self.iface.mapCanvas()
        self.lbl_al_stato.setText("Clicca sulla mappa il punto sulla TUA rete…")
        def su_primo_punto(pt_sorgente):
            self.lbl_al_stato.setText("Ora clicca il punto corrispondente sul riferimento (es. WMS)…")
            def su_secondo_punto(pt_riferimento):
                self._punti_controllo.append((pt_sorgente, pt_riferimento))
                d = pt_sorgente.distance(pt_riferimento)
                self.lst_al_punti.addItem(
                    f"{len(self._punti_controllo)}) rete ({pt_sorgente.x():.2f}, {pt_sorgente.y():.2f}) → "
                    f"riferimento ({pt_riferimento.x():.2f}, {pt_riferimento.y():.2f})  [{d:.2f} m]"
                )
                self.lbl_al_stato.setText(f"Coppia {len(self._punti_controllo)} aggiunta. Puoi aggiungerne un'altra.")
                self._tool_clic = None
            self._tool_clic = _StrumentoClicPunto(canvas, su_secondo_punto)
            canvas.setMapTool(self._tool_clic)
        self._tool_clic = _StrumentoClicPunto(canvas, su_primo_punto)
        canvas.setMapTool(self._tool_clic)

    def _rimuovi_ultima_coppia(self):
        if not self._punti_controllo: return
        self._punti_controllo.pop()
        self.lst_al_punti.takeItem(self.lst_al_punti.count() - 1)
        self.lbl_al_stato.setText(f"{len(self._punti_controllo)} coppie rimaste.")

    def _svuota_coppie(self):
        self._punti_controllo = []
        self.lst_al_punti.clear()
        self.lbl_al_stato.setText("")

    def _calcola_trasf_punti(self):
        if len(self._punti_controllo) < 2:
            QMessageBox.warning(self, "Punti insufficienti", "Servono almeno 2 coppie di punti di controllo."); return
        ris = self._fit_similarity(self._punti_controllo)
        self._mostra_anteprima_trasformazione(ris, len(self._punti_controllo), "punti di controllo")

    def _applica_trasformazione(self):
        if self._trasformazione is None:
            QMessageBox.warning(self, "Nessuna trasformazione", "Calcola prima la trasformazione (sezione A o B sopra)."); return
        a, b = self._trasformazione
        qt = QTransform(a.real, a.imag, -a.imag, a.real, b.real, b.imag)

        layers = [l for l in (
            self.cb_al_armadio.currentLayer(), self.cb_al_infra.currentLayer(),
            self.cb_al_poz.currentLayer(), self.cb_al_pte.currentLayer(),
            self.cb_al_cavo.currentLayer(), self.cb_al_raccordo.currentLayer(),
        ) if l is not None]
        if not layers:
            QMessageBox.warning(self, "Nessun layer", "Imposta almeno un layer da spostare nella sezione 'Layer da spostare insieme'."); return

        risposta = QMessageBox.question(
            self, "Conferma spostamento",
            f"Stai per spostare {len(layers)} layer applicando la trasformazione calcolata "
            "(traslazione + rotazione + scala). L'operazione modifica le geometrie sul posto "
            "e non è annullabile da questo plugin (solo con Annulla di QGIS, se il layer è "
            "ancora in editing). Procedere?",
            QMessageBox.Yes | QMessageBox.No, QMessageBox.No
        )
        if risposta != QMessageBox.Yes: return

        solo_sel = self.chk_al_solo_sel.isChecked()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        totali = {}
        try:
            for lyr in layers:
                if solo_sel and lyr.selectedFeatureCount() == 0:
                    totali[lyr.name()] = "saltato: nessun elemento selezionato"
                    continue
                era = lyr.isEditable()
                if not self._start_edit(lyr):
                    totali[lyr.name()] = "ERRORE avvio editing"; continue
                ids = lyr.selectedFeatureIds() if solo_sel else [f.id() for f in lyr.getFeatures()]
                n = 0
                for fid in ids:
                    feat = lyr.getFeature(fid)
                    g = QgsGeometry(feat.geometry())
                    if lyr.crs() != self.project.crs():
                        g.transform(QgsCoordinateTransform(lyr.crs(), self.project.crs(), self.project))
                    g.transform(qt)
                    if lyr.crs() != self.project.crs():
                        g.transform(QgsCoordinateTransform(self.project.crs(), lyr.crs(), self.project))
                    lyr.changeGeometry(fid, g)
                    n += 1
                if not era and not self._commit(lyr, f"Errore salvataggio su '{lyr.name()}'"):
                    totali[lyr.name()] = "ERRORE commit"; continue
                lyr.triggerRepaint()
                totali[lyr.name()] = f"{n} elementi spostati"
        finally:
            QApplication.restoreOverrideCursor()

        testo = "\n".join(f"{nome}: {esito}" for nome, esito in totali.items())
        self.log_al.setPlainText(testo)
        QMessageBox.information(self, "Allineamento applicato", testo)

    def _rimuovi(self):
        if not self._last_layers:
            QMessageBox.information(self, "Nessuna operazione", "Esegui prima una delle regole."); return
        det = []; tot = 0; ls = []
        for l in self._last_layers:
            n = l.selectedFeatureCount()
            if n > 0: det.append(f"- {l.name()}: {n}"); tot += n; ls.append(l)
        if not tot:
            QMessageBox.information(self, "Nessuna selezione", "Nessun elemento selezionato."); return
        if QMessageBox.question(self, "Conferma", "Eliminare definitivamente:\n"+"\n".join(det),
                QMessageBox.Yes|QMessageBox.No, QMessageBox.No) != QMessageBox.Yes: return
        err = []
        for l in ls:
            era = l.isEditable()
            if not self._start_edit(l): err.append(f"{l.name()}: impossibile avviare l'editing"); continue
            if not l.deleteSelectedFeatures(): err.append(f"{l.name()}: eliminazione fallita"); continue
            if not era and not self._commit(l, "Errore eliminazione"): err.append(f"{l.name()}: commit fallito (dettagli nel popup)"); continue
            l.triggerRepaint()
        if err: QMessageBox.critical(self, "Errori", "\n".join(err))
        else:   QMessageBox.information(self, "OK", f"{tot} elementi rimossi.")

    # ═══════════════════════════════════════════════ CONSEGNA – LOGICA
    # oltre questa soglia di feature, il layer di join viene prima ritagliato
    # all'estensione dell'input: con lo stradario nazionale (milioni di tratti)
    # il join-by-nearest scandaglierebbe tutta Italia per abbinare poche
    # centinaia di elementi locali (misurato: 164 s per un solo join).
    _SOGLIA_RITAGLIO_JOIN = 50000

    def _ritaglia_per_join(self, inp, join, max_d):
        """Se 'join' è molto grande (es. Stradario_Italia nazionale), ne
        restituisce una copia in memoria ritagliata all'estensione di 'inp'
        allargata di un margine (la Distanza max join + 200 m di sicurezza),
        riproiettata nel CRS di 'inp'. Così il join-by-nearest lavora su poche
        centinaia di tratti locali invece che su milioni. Sotto soglia (o se
        qualcosa va storto) restituisce il layer 'join' originale invariato."""
        try:
            if join is None or join.featureCount() <= self._SOGLIA_RITAGLIO_JOIN:
                return join
            crs_inp = inp.crs()
            margine = (max_d if max_d and max_d > 0 else 0) + 200.0
            # Il margine è in METRI: va applicato nel CRS del layer di join
            # (di norma metrico, es. 25832), NON sull'estensione dell'input se
            # questa è in gradi (CRS84) — lì 200 varrebbe 200 gradi e il bbox
            # coprirebbe mezzo pianeta, annullando il filtro. Quindi: porta
            # prima l'estensione dell'input nel CRS del join, poi allarga.
            est_inp = inp.extent()
            if join.crs() != crs_inp:
                bbox_join = QgsCoordinateTransform(
                    crs_inp, join.crs(), self.project).transformBoundingBox(est_inp)
                tr_lettura = QgsCoordinateTransform(join.crs(), crs_inp, self.project)
            else:
                bbox_join = QgsRectangle(est_inp)
                tr_lettura = None
            bbox_join = QgsRectangle(
                bbox_join.xMinimum() - margine, bbox_join.yMinimum() - margine,
                bbox_join.xMaximum() + margine, bbox_join.yMaximum() + margine)
            # layer in memoria nel CRS dell'input, stessi campi del join
            tipo = {QgsWkbTypes.PointGeometry: "Point",
                    QgsWkbTypes.LineGeometry: "LineString",
                    QgsWkbTypes.PolygonGeometry: "Polygon"}.get(
                        join.geometryType(), "LineString")
            mem = QgsVectorLayer(
                "%s?crs=%s" % (tipo, crs_inp.authid()), "join_ritagliato", "memory")
            dp = mem.dataProvider()
            dp.addAttributes(join.fields()); mem.updateFields()
            req = QgsFeatureRequest().setFilterRect(bbox_join)
            nuove = []
            for f in join.getFeatures(req):
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                if tr_lettura is not None:
                    g = QgsGeometry(g)
                    if g.transform(tr_lettura) != 0:
                        continue
                nf = QgsFeature(mem.fields())
                nf.setGeometry(g); nf.setAttributes(f.attributes())
                nuove.append(nf)
            if not nuove:
                return join  # nessun tratto nell'area: meglio il layer intero che un join vuoto
            dp.addFeatures(nuove); mem.updateExtents()
            return mem
        except Exception as e:
            _log_avviso("ritaglio stradario per il join non riuscito, uso il layer intero", e)
            return join

    def _join_nn(self, inp, join, out, prefix, max_d, scarta_non_corrispondenti=False):
        """Esegue il join by nearest e scrive il risultato in 'out' come
        Shapefile in modo esplicito. Non ci si fida del parametro OUTPUT
        passato direttamente all'algoritmo di processing: a seconda dei
        casi (es. ARMADI_FOTO) l'algoritmo può restituire un output con un
        formato/provider diverso da quello atteso dall'estensione .shp e il
        file risultante non viene poi caricato correttamente nel progetto.
        Si esegue quindi il join su un output in memoria e si scrive il
        layer risultante su disco con QgsVectorFileWriter, stesso approccio
        già usato per il salvataggio su GeoPackage.
        Se `scarta_non_corrispondenti` è True, gli elementi di 'inp' senza
        un elemento di 'join' entro la Distanza max vengono ESCLUSI
        dall'output invece di comparire con i campi uniti vuoti.
        Se il layer di join è enorme (stradario nazionale) viene prima
        ritagliato all'area dell'input, altrimenti il join impiegherebbe
        minuti."""
        import processing
        join = self._ritaglia_per_join(inp, join, max_d)
        risultato = processing.run("native:joinbynearest", {
            'INPUT': inp, 'INPUT_2': join, 'FIELDS_TO_COPY': [],
            'DISCARD_NONMATCHING': scarta_non_corrispondenti, 'PREFIX': prefix, 'NEIGHBORS': 1,
            'MAX_DISTANCE': max_d if max_d > 0 else None, 'OUTPUT': 'memory:',
        })
        lyr = risultato.get('OUTPUT')
        if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            raise RuntimeError(f"Join fallito: impossibile ottenere un risultato valido per '{os.path.basename(out)}'.")
        opzioni = QgsVectorFileWriter.SaveVectorOptions()
        opzioni.driverName = "ESRI Shapefile"
        opzioni.fileEncoding = "UTF-8"
        opzioni.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        errore = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, out, self.project.transformContext(), opzioni)
        codice_errore = errore[0] if isinstance(errore, tuple) else errore
        if codice_errore != QgsVectorFileWriter.NoError:
            dettaglio = errore[1] if isinstance(errore, tuple) and len(errore) > 1 else str(errore)
            raise RuntimeError(f"Scrittura shapefile fallita per '{os.path.basename(out)}':\n{dettaglio}")

    @staticmethod
    def _rm_shp(path):
        base = os.path.splitext(path)[0]
        for ext in (".shp",".shx",".dbf",".prj",".cpg",".qix"):
            p = base+ext
            if os.path.exists(p):
                try: os.remove(p)
                except OSError: pass

    def _doppio_join(self, inp, j1, pref1, j2, pref2, out, max_d):
        import tempfile, uuid
        tmp = os.path.join(tempfile.gettempdir(), f"ftth_{uuid.uuid4().hex}.shp")
        self._join_nn(inp, j1, tmp, pref1, max_d)
        lyr = QgsVectorLayer(tmp, "tmp", "ogr")
        if not lyr.isValid(): raise RuntimeError(f"Join intermedio fallito: {tmp}")
        self._join_nn(lyr, j2, out, pref2, max_d)
        del lyr; self._rm_shp(tmp)

    def _aggiorna_lunghezza_infra(self, infra_lyr):
        """Aggiorna i valori di LUNGHEZZA e Lungh nel layer Infrastrutture,
        usando la stessa espressione '$Length' del calcolatore di campi di
        QGIS (non un semplice geometry().length()): il valore scritto
        coincide con quello del calcolatore di campi (compresa l'eventuale
        misura ellissoidica di progetto). Se uno dei due campi esiste già
        nello shape, viene SOLO aggiornato; se manca, viene creato ora."""
        era = infra_lyr.isEditable()
        if not self._start_edit(infra_lyr):
            raise RuntimeError(f"Impossibile avviare la modifica su '{infra_lyr.name()}'.")
        fields = infra_lyr.fields()
        if fields.indexOf(CAMPO_LUNGHEZZA) < 0:
            infra_lyr.addAttribute(QgsField(CAMPO_LUNGHEZZA, QVariant.Double, "double", 15, 2))
            infra_lyr.updateFields(); fields = infra_lyr.fields()
        if fields.indexOf(CAMPO_LUNGH_NEW) < 0:
            infra_lyr.addAttribute(QgsField(CAMPO_LUNGH_NEW, QVariant.Double, "double", 15, 2))
            infra_lyr.updateFields(); fields = infra_lyr.fields()
        idx_lungh    = fields.indexOf(CAMPO_LUNGHEZZA)
        idx_lungh_new = fields.indexOf(CAMPO_LUNGH_NEW)
        espressione = QgsExpression("$Length")
        contesto = QgsExpressionContext()
        contesto.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(infra_lyr))
        if espressione.hasParserError():
            raise RuntimeError(f"Espressione '$Length' non valida: {espressione.parserErrorString()}")
        for feat in infra_lyr.getFeatures():
            contesto.setFeature(feat)
            valore = espressione.evaluate(contesto)
            if espressione.hasEvalError():
                # ripiego robusto: calcolo diretto dalla geometria
                valore = feat.geometry().length() if feat.geometry() else 0.0
            try:
                valore = round(float(valore), 2)
            except (TypeError, ValueError):
                valore = 0.0
            if idx_lungh >= 0:     infra_lyr.changeAttributeValue(feat.id(), idx_lungh,     valore)
            if idx_lungh_new >= 0: infra_lyr.changeAttributeValue(feat.id(), idx_lungh_new, valore)
        if not era and not self._commit(infra_lyr, "Errore aggiornamento LUNGHEZZA"):
            raise RuntimeError(f"Commit fallito su '{infra_lyr.name()}' (vedi dettagli nel popup).")

    @staticmethod
    def _conta_feature(path):
        """Numero di feature nello shapefile scritto su disco in `path`,
        o None se non è possibile riaprirlo."""
        l = QgsVectorLayer(path, "conta", "ogr")
        return l.featureCount() if l.isValid() else None

    def _civico_999_a_snc(self, path):
        """Nello shape ARMADI_FOTO, sostituisce i valori '999' del campo
        CIVICO con 'SNC'. Se il campo è numerico viene convertito in campo
        testo (serve per poter scrivere 'SNC'), preservando gli altri
        valori. Ritorna il numero di valori sostituiti (0 se il campo
        CIVICO non esiste o non contiene nessun '999')."""
        l = QgsVectorLayer(path, "ARMADI_FOTO", "ogr")
        if not l.isValid():
            raise RuntimeError("Impossibile riaprire 'ARMADI_FOTO' per la sostituzione del CIVICO.")
        idx = l.fields().indexOf(CAMPO_CIVICO)
        if idx < 0:
            return 0
        campo_testo = l.fields().at(idx).type() == QVariant.String
        if not self._start_edit(l):
            raise RuntimeError("Impossibile avviare la modifica su 'ARMADI_FOTO' (campo CIVICO).")
        n = 0
        if campo_testo:
            for f in l.getFeatures():
                v = f[CAMPO_CIVICO]
                if v is not None and str(v).strip() == VAL_CIVICO_999:
                    l.changeAttributeValue(f.id(), idx, VAL_CIVICO_SNC); n += 1
        else:
            # campo numerico: serve un campo testo per poter scrivere 'SNC'
            tmp = "CIVICO_T"
            l.addAttribute(QgsField(tmp, QVariant.String, "string", 20))
            l.updateFields()
            idx_tmp = l.fields().indexOf(tmp)
            for f in l.getFeatures():
                v = f[CAMPO_CIVICO]
                if v is None:
                    testo = None
                elif float(v) == float(VAL_CIVICO_999):
                    testo = VAL_CIVICO_SNC; n += 1
                else:
                    testo = str(int(v)) if float(v).is_integer() else str(v)
                l.changeAttributeValue(f.id(), idx_tmp, testo)
            l.deleteAttribute(idx)
            l.updateFields()
            idx_tmp = l.fields().indexOf(tmp)
            if l.dataProvider().capabilities() & l.dataProvider().RenameAttributes:
                l.renameAttribute(idx_tmp, CAMPO_CIVICO)
        if not self._commit(l, "Errore sostituzione CIVICO in ARMADI_FOTO"):
            raise RuntimeError("Commit fallito sostituendo CIVICO in 'ARMADI_FOTO'.")
        del l
        return n


    def _pulisci_campo_n(self, path, nome_layer):
        """Dopo il join, elimina dallo shape le feature con l'attributo 'n'
        diverso da 1 (incluso mancante/NULL): con NEIGHBORS=1 dovrebbe
        essere sempre 1, ma se più elementi si trovano esattamente alla
        STESSA distanza minima il join può restituire più righe per lo
        stesso elemento di partenza — se ne tiene solo una. Se il campo
        'n' non esiste (nessun join effettuato per questo shape) non fa
        nulla. Ritorna il numero di feature eliminate."""
        l = QgsVectorLayer(path, nome_layer, "ogr")
        if not l.isValid():
            raise RuntimeError(f"Impossibile riaprire '{nome_layer}' per il controllo del campo 'n'.")
        if l.fields().indexOf("n") < 0:
            return 0
        req = QgsFeatureRequest().setFilterExpression('"n" IS NULL OR "n" <> 1').setSubsetOfAttributes([])
        ids = [f.id() for f in l.getFeatures(req)]
        if not ids:
            return 0
        if not self._start_edit(l):
            raise RuntimeError(f"Impossibile avviare la modifica su '{nome_layer}' per pulire il campo 'n'.")
        if not l.deleteFeatures(ids):
            raise RuntimeError(f"Eliminazione fallita ripulendo '{nome_layer}' (campo 'n').")
        if not self._commit(l, f"Errore pulizia campo 'n' su {nome_layer}"):
            raise RuntimeError(f"Commit fallito ripulendo '{nome_layer}' (vedi dettagli nel popup).")
        del l
        return len(ids)

    def _genera_consegna(self):
        foto    = self.cb_c_foto.currentLayer()
        armadio = self.cb_c_armadio.currentLayer() if self.chk_c_join_armadio.isChecked() else None
        # Base SEMPRE il layer '03 INFRASTRUTTURE' del progetto (per nome,
        # non quello che capita di avere selezionato la combo in questo
        # momento): sia l'aggiornamento di LUNGHEZZA/Lungh sia il join
        # partono da questo stesso layer, così i due passaggi lavorano
        # sempre sullo stesso oggetto.
        infra = self._find_layer("03 INFRASTRUTTURE")
        if infra:
            if self.cb_c_infra.currentLayer() != infra: self.cb_c_infra.setLayer(infra)
        else:
            infra = self.cb_c_infra.currentLayer()  # ripiego se il progetto non ha un layer con quel nome esatto
        strada  = self.cb_c_strada.currentLayer() if self.chk_c_join_strada.isChecked() else None
        poz     = self.cb_c_poz.currentLayer()
        mancanti = [n for n, l in (("Foto", foto), ("Infrastrutture", infra), ("Pozzetto", poz)) if not l]
        if mancanti:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona:\n- "+"\n- ".join(mancanti)); return
        cartella = QFileDialog.getExistingDirectory(self, "Cartella di destinazione")
        if not cartella: return
        max_d = self.spin_c_dist.value()
        p1 = os.path.join(cartella, "ARMADI_FOTO.shp")
        p2 = os.path.join(cartella, "SCAVI_STRADE.shp")
        p3 = os.path.join(cartella, "POZZETTI_STRADE.shp")
        self.log_c.setPlainText("Aggiorno LUNGHEZZA/Lungh in Infrastrutture (03 INFRASTRUTTURE)…"); self.repaint()
        try:
            # aggiorna campi lunghezza nel layer sorgente '03 INFRASTRUTTURE'
            self._aggiorna_lunghezza_infra(infra)
            # 1) ARMADI_FOTO = Armadio Ottico + Foto (nearest), UN SOLO
            # elemento per Armadio Ottico: la base del join deve essere
            # l'Armadio (non il Punto di Ripresa), altrimenti si ottiene
            # una riga per OGNI punto di ripresa (compresi quelli generati
            # per attraversamenti/tavole, non legati a un armadio) invece
            # che una per ogni armadio. Confermato dallo schema di
            # riferimento: i campi dell'Armadio Ottico vengono per primi,
            # seguiti da quelli del Punto di Ripresa più vicino.
            n_armadi = armadio.featureCount() if armadio else None
            if armadio:
                self._join_nn(armadio, foto, p1, "", max_d)
            else:
                QgsVectorFileWriter.writeAsVectorFormat(foto, p1, "UTF-8")
            n_civico = self._civico_999_a_snc(p1)
            # armadio da usare per l'opzione "aggiungi anche l'armadio a
            # scavi/pozzetti": è il layer del combo, indipendente dalla spunta
            # che genera ARMADI_FOTO.
            armadio_scavi = (self.cb_c_armadio.currentLayer()
                             if self.chk_c_armadio_su_scavi.isChecked() else None)
            # 2) SCAVI_STRADE = Infrastrutture + Stradario (+ Armadio se richiesto).
            if strada and armadio_scavi:
                self._doppio_join(infra, strada, "", armadio_scavi, "", p2, max_d)
            elif strada:
                self._join_nn(infra, strada, p2, "", max_d)
            elif armadio_scavi:
                self._join_nn(infra, armadio_scavi, p2, "", max_d)
            else:
                QgsVectorFileWriter.writeAsVectorFormat(infra, p2, "UTF-8")
            # 3) POZZETTI_STRADE = Pozzetto + Stradario (+ Armadio se richiesto).
            if strada and armadio_scavi:
                self._doppio_join(poz, strada, "", armadio_scavi, "", p3, max_d)
            elif strada:
                self._join_nn(poz, strada, p3, "", max_d)
            elif armadio_scavi:
                self._join_nn(poz, armadio_scavi, p3, "", max_d)
            else:
                QgsVectorFileWriter.writeAsVectorFormat(poz, p3, "UTF-8")
            # prima di considerarli pronti: ripulisce da SCAVI_STRADE e
            # POZZETTI_STRADE le eventuali righe doppie prodotte da un pareggio
            # di distanza nel join (campo 'n' diverso da 1)
            self.log_c.setPlainText("Controllo campo 'n' su SCAVI_STRADE e POZZETTI_STRADE…"); self.repaint()
            n_rim_2 = self._pulisci_campo_n(p2, "SCAVI_STRADE")
            n_rim_3 = self._pulisci_campo_n(p3, "POZZETTI_STRADE")
        except Exception as e:
            QMessageBox.critical(self, "Errore", str(e)); return
        righe = [f"Generati:\n- {p1}\n- {p2}\n- {p3}"]
        if armadio:
            n_dopo = self._conta_feature(p1)
            righe.append(
                f"ARMADI_FOTO: {n_dopo if n_dopo is not None else n_armadi} elementi — uno per ogni Armadio Ottico "
                f"({n_armadi} nel layer), ciascuno con gli attributi del Punto di Ripresa più vicino entro la Distanza max join."
            )
        else:
            righe.append("ARMADI_FOTO: nessun layer Armadio Ottico impostato, contiene tutti i punti di ripresa senza filtro.")
        if n_civico: righe.append(f"ARMADI_FOTO: {n_civico} valori '{VAL_CIVICO_999}' del campo '{CAMPO_CIVICO}' sostituiti con '{VAL_CIVICO_SNC}'.")
        if n_rim_2: righe.append(f"SCAVI_STRADE: {n_rim_2} righe con 'n' diverso da 1 rimosse.")
        if n_rim_3: righe.append(f"POZZETTI_STRADE: {n_rim_3} righe con 'n' diverso da 1 rimosse.")
        self.log_c.setPlainText("\n".join(righe))
        if self.chk_c_carica.isChecked():
            for nome, path in (("ARMADI_FOTO",p1),("SCAVI_STRADE",p2),("POZZETTI_STRADE",p3)):
                l = QgsVectorLayer(path, nome, "ogr")
                if l.isValid(): self.project.addMapLayer(l)
        QMessageBox.information(self, "OK", "\n".join(righe))

    # ═══════════════════════════════════════════════ ATLANTE – LOGICA
    def _popola_elenco_layout(self):
        self.lst_atlante.clear()
        for layout in self.project.layoutManager().printLayouts():
            self.lst_atlante.addItem(layout.name())

    def _aggiorna_elenco_layout(self):
        self._popola_elenco_layout()

    def _esporta_atlante(self):
        items = self.lst_atlante.selectedItems()
        if not items:
            QMessageBox.warning(self, "Nessun layout selezionato", "Seleziona almeno un layout dall'elenco (Ctrl/Maiusc per più di uno)."); return
        cartella = QFileDialog.getExistingDirectory(self, "Cartella di destinazione PDF")
        if not cartella: return

        vettoriale = self.chk_atlante_vettoriale.isChecked()
        semplifica = self.chk_atlante_semplifica.isChecked()
        jpeg_lossy = self.chk_atlante_jpeg_lossy.isChecked()

        self.log_atlante.clear()
        risultati = []
        pdf_esportati = []
        gestore = self.project.layoutManager()
        for item in items:
            nome = item.text()
            # Log incrementale + processEvents PRIMA di ogni passo lento:
            # se l'esportazione si blocca davvero (non solo "lenta"), qui
            # si vede subito su quale layout e a quale fase (attivazione
            # Atlante / aggiornamento feature / rendering PDF), invece di
            # avere solo il cursore di attesa fermo senza indicazioni.
            self.log_atlante.appendPlainText(f"{nome}: avvio…")
            QApplication.processEvents()
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                layout = gestore.layoutByName(nome)
                if layout is None:
                    risultati.append(f"{nome}: layout non trovato (elenco non aggiornato?)."); continue
                atlas = layout.atlas()
                if atlas is None or atlas.coverageLayer() is None:
                    risultati.append(f"{nome}: nessun layer di copertura Atlante configurato in questo layout — configuralo nel Compositore (scheda Atlante) prima di usare questa funzione."); continue

                era_abilitato = atlas.enabled()
                if not era_abilitato:
                    atlas.setEnabled(True)
                try:
                    # setEnabled(True) non garantisce da solo che l'elenco
                    # feature dell'Atlante sia aggiornato (es. layer di
                    # copertura filtrato/modificato dopo l'ultima apertura
                    # del layout): updateFeatures() forza il refresh, così
                    # verifichiamo per davvero che l'Atlante sia attivo E
                    # popolato PRIMA di esportare, invece di scoprirlo solo
                    # dal risultato dell'export.
                    self.log_atlante.appendPlainText(f"{nome}: aggiornamento elenco elementi Atlante…")
                    QApplication.processEvents()
                    atlas.updateFeatures()
                    if atlas.count() == 0:
                        risultati.append(f"{nome}: Atlante attivato ma 0 elementi da coprire — controlla il layer/filtro di copertura nel Compositore (scheda Atlante).")
                        continue

                    percorso = os.path.join(cartella, f"{nome}.pdf")
                    settings = QgsLayoutExporter.PdfExportSettings()
                    # Vettoriale invece di rasterizzare ogni pagina: molto
                    # più veloce e file più leggeri, salvo layout con
                    # modalità di fusione/trasparenza che impongono comunque
                    # il rendering raster internamente.
                    settings.forceVectorOutput = vettoriale
                    # Semplifica le geometrie in base alla scala di stampa:
                    # riduce il lavoro di rendering su layer con geometrie
                    # complesse (es. infrastrutture molto dettagliate).
                    settings.simplifyGeometries = semplifica
                    # Stessa opzione della finestra "Esporta come PDF" di
                    # QGIS ("Compressione immagini senza perdita"): qui di
                    # default la lasciamo DISATTIVATA (quindi JPEG con
                    # perdita) per immagini raster incorporate più leggere
                    # e rendering più rapido. I due flag di base replicano
                    # i default del costruttore di PdfExportSettings.
                    flag = QgsLayoutRenderContext.FlagAntialiasing | QgsLayoutRenderContext.FlagUseAdvancedEffects
                    if not jpeg_lossy:
                        flag |= QgsLayoutRenderContext.FlagLosslessImageRendering
                    settings.flags = flag

                    self.log_atlante.appendPlainText(f"{nome}: rendering ed esportazione di {atlas.count()} pagine…")
                    QApplication.processEvents()
                    # Questo overload statico (con un Atlante, non un
                    # semplice layout) ritorna una TUPLA (risultato,
                    # messaggio d'errore), non il solo codice come le
                    # esportazioni non-Atlante: confrontare la tupla
                    # intera con Success falliva sempre, segnalando un
                    # errore anche quando il PDF veniva scritto bene.
                    esito, errore_msg = QgsLayoutExporter.exportToPdf(atlas, percorso, settings)
                finally:
                    if not era_abilitato:
                        atlas.setEnabled(False)  # ripristina lo stato originale del layout

                if esito == QgsLayoutExporter.Success:
                    risultati.append(f"{nome}: esportato in '{percorso}' ({atlas.count()} pagine/elementi).")
                    pdf_esportati.append(percorso)
                else:
                    risultati.append(f"{nome}: errore nell'esportazione (codice {esito}{': '+errore_msg if errore_msg else ''}) — verifica che l'Atlante abbia elementi da coprire.")
            except Exception as e:
                # Prima un'eccezione qui risaliva silenziosamente fino allo
                # slot Qt: il cursore di attesa restava impostato e non
                # comparivano né il PDF né alcun messaggio d'errore visibile
                # ("resta in caricamento"). Ora l'errore reale viene
                # mostrato nel log invece di sparire.
                risultati.append(f"{nome}: ERRORE IMPREVISTO — {type(e).__name__}: {e}")
            finally:
                QApplication.restoreOverrideCursor()
            self.log_atlante.appendPlainText(risultati[-1] if risultati else f"{nome}: nessun risultato registrato.")
            QApplication.processEvents()

        testo = "\n".join(risultati)
        self.log_atlante.setPlainText(testo)
        QMessageBox.information(self, "Esportazione completata", testo)

        # I PDF appena esportati con successo popolano subito l'elenco
        # da unire qui sotto, nello stesso ordine di esportazione —
        # l'utente può comunque aggiungerne altri o riordinare a mano.
        if pdf_esportati:
            self.lst_merge_pdf.clear()
            for p in pdf_esportati:
                self.lst_merge_pdf.addItem(p)

    def _merge_pdf_aggiungi(self):
        percorsi, _ = QFileDialog.getOpenFileNames(self, "Aggiungi PDF", "", "PDF (*.pdf)")
        for p in percorsi:
            self.lst_merge_pdf.addItem(p)

    def _merge_pdf_sposta(self, delta):
        riga = self.lst_merge_pdf.currentRow()
        if riga < 0: return
        nuova = riga + delta
        if nuova < 0 or nuova >= self.lst_merge_pdf.count(): return
        item = self.lst_merge_pdf.takeItem(riga)
        self.lst_merge_pdf.insertItem(nuova, item)
        self.lst_merge_pdf.setCurrentRow(nuova)

    def _merge_pdf_rimuovi(self):
        for item in self.lst_merge_pdf.selectedItems():
            self.lst_merge_pdf.takeItem(self.lst_merge_pdf.row(item))

    def _merge_pdf_unisci(self):
        n = self.lst_merge_pdf.count()
        if n < 2:
            QMessageBox.warning(self, "Elenco insufficiente", "Aggiungi almeno due PDF da unire, nell'ordine desiderato (usa ↑/↓ per riordinare)."); return
        try:
            from pypdf import PdfWriter
        except ImportError:
            try:
                from PyPDF2 import PdfWriter
            except ImportError:
                QMessageBox.critical(self, "Libreria mancante",
                    "Serve il pacchetto Python 'pypdf' (o 'PyPDF2') nell'ambiente "
                    "Python di QGIS. Installalo ad es. dalla OSGeo4W Shell con "
                    "'pip install pypdf' e riprova."); return

        percorso_out, _ = QFileDialog.getSaveFileName(self, "Salva PDF unito", "unito.pdf", "PDF (*.pdf)")
        if not percorso_out: return
        if not percorso_out.lower().endswith(".pdf"):
            percorso_out += ".pdf"

        percorsi = [self.lst_merge_pdf.item(i).text() for i in range(n)]
        writer = PdfWriter()
        saltati = []
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            for p in percorsi:
                if not os.path.isfile(p):
                    saltati.append(p); continue
                writer.append(p)
            with open(percorso_out, "wb") as fh:
                writer.write(fh)
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Errore unione", f"Errore durante l'unione dei PDF: {e}"); return
        finally:
            QApplication.restoreOverrideCursor()

        msg = f"PDF unito creato: '{percorso_out}' ({n - len(saltati)} di {n} file, nell'ordine mostrato)."
        if saltati:
            msg += "\nSaltati (file non trovato): " + "; ".join(saltati)
        self.log_merge.setPlainText(msg)
        QMessageBox.information(self, "Unione completata", msg)

    # ═══════════════════════════════════════════════ CONI – LOGICA
    # distanza minima camera-soggetto sotto la quale la direzione non è
    # affidabile: due punti a 20 cm danno un azimut che dipende dal rumore
    # delle coordinate, non dalla geometria reale.
    DIST_MIN_DIREZIONE = 1.0
    # di quanto arretrare la camera quando si trova addosso al soggetto
    STANDOFF_DEFAULT = 8.0

    def _direzione_cono(self, pt_ripresa, pt_verso, linee_idx=None, linee_geoms=None,
                        soggetti_vicini=None):
        """Azimut (gradi, 0=Nord) da `pt_ripresa` verso `pt_verso`, con i casi
        degeneri gestiti invece che lasciati produrre un angolo casuale.

        Il problema reale: i punti di ripresa cadono spesso SOPRA l'elemento che
        devono inquadrare (un armadio, una tratta), non sulla strada. Quando
        camera e soggetto quasi coincidono, dx e dy valgono ~0 e
        math.atan2(0, 0) restituisce 0: il cono finisce puntato a Nord a caso,
        che è esattamente il sintomo visto in tavola.

        Strategia, in ordine:
          1. se camera e soggetto distano abbastanza, si usa quella direzione;
          2. altrimenti si guarda la linea (strada/infrastruttura) più vicina e
             si prende la sua PERPENDICOLARE: un elemento di rete sta sempre
             lungo un asse stradale, e lo si fotografa di traverso. Fra le due
             perpendicolari possibili si sceglie quella che punta verso la massa
             degli elementi vicini, cioè verso ciò che va documentato;
          3. se non c'è nemmeno una linea, si punta al baricentro degli elementi
             vicini;
          4. in ultima istanza si tiene la direzione grezza.

        Restituisce (azimut_gradi, motivo) — `motivo` serve per la diagnostica.
        """
        dx = pt_verso.x() - pt_ripresa.x()
        dy = pt_verso.y() - pt_ripresa.y()
        dist = math.hypot(dx, dy)

        if dist >= self.DIST_MIN_DIREZIONE:
            return math.degrees(math.atan2(dx, dy)) % 360, "camera→soggetto"

        # --- caso degenere: camera addosso al soggetto -----------------------
        # 2) perpendicolare alla linea più vicina
        asse = None
        if linee_idx is not None and linee_geoms:
            try:
                vicini = linee_idx.nearestNeighbor(pt_ripresa, 1)
                if vicini:
                    asse = linee_geoms.get(vicini[0])
            except Exception:
                asse = None
        if asse is not None and not asse.isEmpty():
            try:
                # direzione locale dell'asse: segmento più vicino al punto
                _d, pt_vicino, idx_dopo, _lato = asse.closestSegmentWithContext(pt_ripresa)
                linea = asse.asPolyline() if not asse.isMultipart() else None
                if linea is None:
                    parti = asse.asMultiPolyline()
                    linea = parti[0] if parti else None
                if linea and 1 <= idx_dopo < len(linea):
                    p1 = linea[idx_dopo - 1]; p2 = linea[idx_dopo]
                    ax = p2.x() - p1.x(); ay = p2.y() - p1.y()
                    norma = math.hypot(ax, ay)
                    if norma > 0:
                        # due perpendicolari possibili: (ay,-ax) e (-ay,ax)
                        cand = [(ay / norma, -ax / norma), (-ay / norma, ax / norma)]
                        scelta = cand[0]
                        # si punta dalla parte dove stanno gli elementi da
                        # documentare, non verso il campo aperto
                        rif = None
                        if soggetti_vicini:
                            sx = sum(p.x() for p in soggetti_vicini) / len(soggetti_vicini)
                            sy = sum(p.y() for p in soggetti_vicini) / len(soggetti_vicini)
                            rif = (sx - pt_ripresa.x(), sy - pt_ripresa.y())
                        elif dist > 0:
                            rif = (dx, dy)
                        if rif is not None and (rif[0] or rif[1]):
                            scelta = max(cand, key=lambda c: c[0] * rif[0] + c[1] * rif[1])
                        return (math.degrees(math.atan2(scelta[0], scelta[1])) % 360,
                                "perpendicolare all'asse stradale")
            except Exception as e:
                _log_avviso("perpendicolare asse per direzione cono", e)

        # 3) baricentro degli elementi vicini
        if soggetti_vicini:
            sx = sum(p.x() for p in soggetti_vicini) / len(soggetti_vicini)
            sy = sum(p.y() for p in soggetti_vicini) / len(soggetti_vicini)
            bx = sx - pt_ripresa.x(); by = sy - pt_ripresa.y()
            if math.hypot(bx, by) >= 0.01:
                return math.degrees(math.atan2(bx, by)) % 360, "baricentro elementi vicini"

        # 4) ripiego
        return math.degrees(math.atan2(dx, dy)) % 360, "ripiego (direzione incerta)"

    def _arretra_camera(self, pt_ripresa, azimut_gradi, distanza=None):
        """Sposta la camera all'indietro lungo la direzione di ripresa.

        Serve quando il punto di ripresa cade sopra l'elemento: una foto scattata
        a zero metri non esiste, e in tavola il cono parte dentro il simbolo e non
        si legge. Arretrando di qualche metro il cono si vede e il soggetto ci
        finisce dentro.
        """
        if distanza is None:
            try:
                distanza = float(self.spin_k_standoff.value())
            except Exception:
                distanza = self.STANDOFF_DEFAULT
        if distanza <= 0:
            return pt_ripresa
        rad = math.radians(azimut_gradi)
        # azimut 0 = Nord, cresce in senso orario: dx = sin, dy = cos
        return QgsPointXY(pt_ripresa.x() - math.sin(rad) * distanza,
                          pt_ripresa.y() - math.cos(rad) * distanza)

    def _aggiungi_cono(self, foto_lyr, pt_ripresa, pt_verso, extra=None, rot_forzata=None,
                       linee_idx=None, linee_geoms=None, soggetti_vicini=None,
                       arretra=False):
        if rot_forzata is not None:
            rot = rot_forzata % 360
        else:
            rot, _motivo = self._direzione_cono(
                pt_ripresa, pt_verso,
                linee_idx=linee_idx, linee_geoms=linee_geoms,
                soggetti_vicini=soggetti_vicini)
            # se la camera è praticamente sul soggetto, arretrala lungo la
            # direzione appena calcolata: il cono diventa leggibile e il
            # soggetto ci cade dentro invece di stare sul vertice
            if arretra:
                try:
                    d = math.hypot(pt_verso.x() - pt_ripresa.x(),
                                   pt_verso.y() - pt_ripresa.y())
                    if d < self.DIST_MIN_DIREZIONE:
                        pt_ripresa = self._arretra_camera(pt_ripresa, rot)
                except Exception as e:
                    _log_avviso("arretramento camera non riuscito", e)
        g_out = QgsGeometry.fromPointXY(pt_ripresa)
        if foto_lyr.crs() != self.project.crs():
            g_out.transform(QgsCoordinateTransform(self.project.crs(), foto_lyr.crs(), self.project))
        nf = QgsFeature(foto_lyr.fields()); nf.setGeometry(g_out)
        nf[CAMPO_ROT] = round(rot, 1)
        if extra:
            for campo, valore in extra.items():
                idx = foto_lyr.fields().indexOf(campo)
                if idx >= 0: nf.setAttribute(idx, valore)
        foto_lyr.addFeature(nf)

    @staticmethod
    def _piede_perpendicolare_segmento(pt, p1, p2):
        """Scompone pt rispetto al segmento p1->p2 nella componente
        PARALLELA (t: posizione lungo il segmento, 0=p1, 1=p2 — la
        direzione della strada) e PERPENDICOLARE (lo scarto laterale) —
        coerente col fatto che lo Stradario è uno shape lineare. Ritorna
        (piede, distanza_quadra, t_non_clampato): t fuori da [0,1] segnala
        che pt non ha un vero piede perpendicolare dentro QUESTO segmento
        (cade oltre uno dei due estremi) — il chiamante preferisce un
        segmento con un vero piede perpendicolare (anche se un filo più
        lontano) a un punto d'estremo clampato, che non sarebbe una vera
        perpendicolare alla strada ma solo il punto più vicino in senso
        stretto."""
        dx = p2.x()-p1.x(); dy = p2.y()-p1.y()
        L2 = dx*dx + dy*dy
        if L2 == 0:
            piede = QgsPointXY(p1.x(), p1.y())
            return piede, (pt.x()-p1.x())**2+(pt.y()-p1.y())**2, 0.0
        t = ((pt.x()-p1.x())*dx + (pt.y()-p1.y())*dy) / L2
        t_clamp = max(0.0, min(1.0, t))
        piede = QgsPointXY(p1.x()+t_clamp*dx, p1.y()+t_clamp*dy)
        d2 = (pt.x()-piede.x())**2 + (pt.y()-piede.y())**2
        return piede, d2, t

    def _cerca_piede_stradario(self, pt_target, strad_idx, strad_geoms, raggio, g_tile=None, n_vicini=20):
        """Cerca il piede perpendicolare più vicino a pt_target usando un
        indice spaziale già costruito su Stradario (strad_idx/strad_geoms,
        vedi `_coni_tavole`) invece di re-interrogare il layer con un
        raggio che raddoppia ogni volta: con un indice in memoria basta
        chiedere le `n_vicini` feature più vicine, molto più veloce su
        Stradario grandi (es. uno Stradario Italia). Se `g_tile` è
        passato, un segmento che intersaca la tavola ha SEMPRE priorità
        su uno che non la intersaca, anche se quest'ultimo è più vicino:
        senza questa priorità il piede più vicino in assoluto poteva
        stare su una strada fuori tavola, e il punto — poi riportato
        dentro il perimetro per non uscirne — finiva agganciato a un
        lato qualunque del bordo, senza nessun legame con una strada
        reale di quella tavola. Ritorna (piede, tangente_unitaria) del
        segmento scelto, o (None, None) se nulla è entro il raggio: la
        tangente (versore lungo la strada in quel punto) serve al
        chiamante per tenere la camera sulla stessa linea della strada
        quando il soggetto vi giace già sopra (attraversamenti)."""
        pulito_in = None; pulito_in_d2 = None; pulito_in_tg = None
        pulito_out = None; pulito_out_d2 = None; pulito_out_tg = None
        scorta_in = None; scorta_in_d2 = None; scorta_in_tg = None
        scorta_out = None; scorta_out_d2 = None; scorta_out_tg = None
        for cid in strad_idx.nearestNeighbor(pt_target, n_vicini):
            g = strad_geoms.get(cid)
            if not g: continue
            in_tavola = bool(g_tile) and g.intersects(g_tile)
            linee = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for linea in linee:
                for i in range(len(linea) - 1):
                    p1 = QgsPointXY(linea[i]); p2 = QgsPointXY(linea[i + 1])
                    piede, d2, t = self._piede_perpendicolare_segmento(pt_target, p1, p2)
                    dx = p2.x() - p1.x(); dy = p2.y() - p1.y()
                    L = math.hypot(dx, dy)
                    tg = (dx / L, dy / L) if L > 0 else (1.0, 0.0)
                    if 0.0 <= t <= 1.0:
                        if in_tavola:
                            if pulito_in_d2 is None or d2 < pulito_in_d2:
                                pulito_in_d2 = d2; pulito_in = piede; pulito_in_tg = tg
                        else:
                            if pulito_out_d2 is None or d2 < pulito_out_d2:
                                pulito_out_d2 = d2; pulito_out = piede; pulito_out_tg = tg
                    else:
                        if in_tavola:
                            if scorta_in_d2 is None or d2 < scorta_in_d2:
                                scorta_in_d2 = d2; scorta_in = piede; scorta_in_tg = tg
                        else:
                            if scorta_out_d2 is None or d2 < scorta_out_d2:
                                scorta_out_d2 = d2; scorta_out = piede; scorta_out_tg = tg
        # Priorità: vero piede in tavola > vero piede fuori tavola >
        # punto d'estremo in tavola > punto d'estremo fuori tavola.
        for scelto, scelto_d2, scelto_tg in (
            (pulito_in, pulito_in_d2, pulito_in_tg), (pulito_out, pulito_out_d2, pulito_out_tg),
            (scorta_in, scorta_in_d2, scorta_in_tg), (scorta_out, scorta_out_d2, scorta_out_tg),
        ):
            if scelto is not None and scelto_d2 <= raggio * raggio:
                return scelto, scelto_tg
        return None, None

    def _pt_cono_stradario(self, pt_target, strad_idx, strad_geoms, raggio, dist_riserva, sedime_lyr=None, g_tile=None):
        """Punto di ripresa per un soggetto, proiettato perpendicolarmente
        sul segmento Stradario più vicino tramite l'indice spaziale già
        costruito (strad_idx/strad_geoms), preferendo un segmento
        realmente dentro la tavola (vedi `_cerca_piede_stradario`). La
        ricerca allarga sia il raggio sia il numero di vicini interrogati
        se non trova nulla, fino a un tetto, per non ricadere troppo
        spesso sul ripiego 'a Nord'.
        Se il soggetto giace già (quasi) sulla strada stessa — il caso
        degli attraversamenti, che per costruzione sono intersezioni
        Infrastruttura×Strada — la proiezione perpendicolare ricadrebbe
        sul soggetto stesso: distanza zero, camera 'sopra' l'oggetto,
        rotazione indefinita. In quel caso la camera viene invece
        spostata di `dist_riserva` LUNGO la strada (resta sulla sua
        stessa linea, non se ne allontana) e la ripresa è forzata
        PERPENDICOLARE alla strada (verso il lato che guarda più al
        centro della tavola) — una vera foto di attraversamento, non un
        cono piazzato sul soggetto.
        Se lo Stradario non trova nulla e `sedime_lyr` è impostato, il
        ripiego 'a Nord' viene spostato al punto più vicino dentro il
        Sedime Pubblico. Ritorna (pt_ripresa, senza_strada: bool,
        rotazione_forzata: gradi o None — se None il chiamante calcola
        la rotazione normalmente, guardando verso il soggetto)."""
        scelto = None; tangente = None
        if strad_idx is not None:
            r = raggio; n_vic = 20
            for _tentativo in range(7):
                scelto, tangente = self._cerca_piede_stradario(pt_target, strad_idx, strad_geoms, r, g_tile=g_tile, n_vicini=n_vic)
                if scelto is not None: break
                r *= 2; n_vic = min(n_vic * 3, 800)

        if scelto is not None:
            distanza_min = max(1.5, dist_riserva * 0.5)
            if scelto.distance(pt_target) < distanza_min:
                dx, dy = tangente
                spostato = QgsPointXY(scelto.x() + dx * dist_riserva, scelto.y() + dy * dist_riserva)
                perp1 = (-dy, dx); perp2 = (dy, -dx)
                if g_tile:
                    centro = g_tile.centroid().asPoint()
                    v = (centro.x() - spostato.x(), centro.y() - spostato.y())
                    perp = perp1 if (perp1[0]*v[0] + perp1[1]*v[1]) >= (perp2[0]*v[0] + perp2[1]*v[1]) else perp2
                else:
                    perp = perp1
                rot = math.degrees(math.atan2(perp[0], perp[1])) % 360
                return spostato, False, rot
            return scelto, False, None

        scelto = QgsPointXY(pt_target.x(), pt_target.y()+dist_riserva)
        if sedime_lyr:
            g_pt = QgsGeometry.fromPointXY(scelto)
            dentro = False
            bb = QgsRectangle(scelto.x()-0.01, scelto.y()-0.01, scelto.x()+0.01, scelto.y()+0.01)
            for f in sedime_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb)):
                g_s = self._to_proj(f.geometry(), sedime_lyr)
                if g_s and g_s.intersects(g_pt):
                    dentro = True; break
            if not dentro:
                migliore = None; migliore_d = None
                bb_ampio = QgsRectangle(scelto.x()-raggio, scelto.y()-raggio, scelto.x()+raggio, scelto.y()+raggio)
                for f in sedime_lyr.getFeatures(QgsFeatureRequest().setFilterRect(bb_ampio)):
                    g_s = self._to_proj(f.geometry(), sedime_lyr)
                    if not g_s or g_s.isEmpty(): continue
                    d = g_s.distance(g_pt)
                    if migliore_d is None or d < migliore_d:
                        migliore_d = d; migliore = g_s.nearestPoint(g_pt)
                if migliore is not None and not migliore.isEmpty():
                    scelto = QgsPointXY(migliore.asPoint())
        return scelto, True, None

    # m: sotto questa distanza due posizioni-camera sono considerate lo
    # stesso punto. Era 0.10 (praticamente solo coincidenze esatte):
    # troppo stretto per accorgersi di coni ravvicinati ma non identici
    # (es. due proiezioni sullo stesso tratto di strada a 30-40 cm
    # l'una dall'altra) — alzata a 1.0 m, un valore inferiore alla
    # spaziatura minima ragionevole tra due riprese diverse.
    _SOGLIA_DUPLICATO = 1.0

    def _indice_punti_foto(self, foto_lyr):
        """Indice spaziale sui Punti di Ripresa già presenti nel layer,
        usato per evitare di piazzare più coni esattamente sullo stesso
        punto — capita eseguendo sia 'Coni Armadi' sia 'Coni per Tavola di
        Inquadramento' sullo stesso Armadio (o rieseguendo la stessa
        funzione due volte): entrambe calcolano la STESSA posizione dalla
        STESSA proiezione sullo Stradario, quindi senza questo controllo
        risultano due Foto diverse impilate sul punto identico. Ritorna
        (idx, prossimo_id): prossimo_id è il primo id libero per
        registrare via via, con `_registra_punto_foto`, i nuovi punti
        aggiunti in questa esecuzione (l'indice non si aggiorna da solo)."""
        idx = QgsSpatialIndex(); n = 0
        for f in foto_lyr.getFeatures():
            g = self._to_proj(f.geometry(), foto_lyr)
            if not g or g.isEmpty(): continue
            nf = QgsFeature(); nf.setId(n); nf.setGeometry(g)
            idx.addFeature(nf); n += 1
        return idx, n

    @classmethod
    def _punto_occupato(cls, pt, idx):
        s = cls._SOGLIA_DUPLICATO
        bb = QgsRectangle(pt.x()-s, pt.y()-s, pt.x()+s, pt.y()+s)
        return len(idx.intersects(bb)) > 0

    @staticmethod
    def _registra_punto_foto(pt, idx, prossimo_id):
        nf = QgsFeature(); nf.setId(prossimo_id); nf.setGeometry(QgsGeometry.fromPointXY(pt))
        idx.addFeature(nf)
        return prossimo_id + 1

    @staticmethod
    def _clip_in_poligono(pt, g_poly):
        """Se pt è già dentro g_poly lo ritorna invariato; altrimenti lo
        sposta al punto più vicino sul perimetro di g_poly — così un
        punto di ripresa calcolato sullo Stradario (che può cadere oltre
        il bordo di una tavola stretta) resta sempre dentro la tavola,
        invece di finire fuori dal suo perimetro. Non usa
        QgsGeometry.boundary() (non disponibile in tutte le versioni di
        QGIS/PyQGIS): il punto più vicino di un poligono a un punto
        esterno cade comunque sul suo bordo."""
        g_pt = QgsGeometry.fromPointXY(pt)
        if g_poly.contains(g_pt):
            return pt
        vicino = g_poly.nearestPoint(g_pt)
        if vicino and not vicino.isEmpty():
            return QgsPointXY(vicino.asPoint())
        return pt

    # ---------- coni ruotabili come geometria ----------
    def _raggio_cono(self):
        """Raggio in metri: i 6 mm del simbolo riportati alla scala."""
        try:
            scala = float(self.spin_cono_scala.value())
        except Exception:
            scala = CONO_SCALA_DEFAULT
        return CONO_RAGGIO_MM * scala / 1000.0

    def _aggiorna_raggio_cono(self):
        try:
            self.lbl_cono_raggio.setText(
                "%.2f m  (%.0f mm sulla carta)" % (self._raggio_cono(), CONO_RAGGIO_MM))
        except Exception as e:
            _log_avviso("aggiornamento etichetta raggio cono non riuscito", e)

    def _genera_coni_ruotabili(self):
        """Crea il layer poligonale dei coni a partire dai Punti di Ripresa.

        Il layer nasce come GeoPackage accanto al progetto, non in memoria:
        deve sopravvivere alla chiusura di QGIS e soprattutto deve poter
        essere messo in modifica e SALVATO, perche' e' il salvataggio a far
        scattare il riporto della rotazione sui punti.
        """
        punti = self.cb_k_foto.currentLayer()
        if not punti:
            QMessageBox.warning(self, "Layer mancante",
                                "Seleziona il layer Punto di Ripresa."); return
        if punti.fields().indexOf(CAMPO_ROT) < 0:
            QMessageBox.critical(self, "Campo mancante",
                                 f"Il layer '{punti.name()}' non ha il campo '{CAMPO_ROT}'."); return
        if punti.featureCount() == 0:
            QMessageBox.warning(self, "Nessun punto",
                                f"'{punti.name()}' non contiene punti di ripresa."); return

        raggio = self._raggio_cono()
        apert = float(self.spin_cono_apert.value())
        self.log_cono.clear()
        self._scrivi_log(self.log_cono, "Raggio %.2f m (6 mm a 1:%.0f), apertura %.0f°."
                  % (raggio, self.spin_cono_scala.value(), apert))

        campi = QgsFields()
        campi.append(QgsField(CAMPO_CONO_PUNTO, QVariant.LongLong))
        for f in punti.fields():
            if f.name() != CAMPO_CONO_PUNTO:
                campi.append(QgsField(f.name(), f.type()))

        feats, senza_rot = [], 0
        for p in punti.getFeatures():
            g = p.geometry()
            if not g or g.isEmpty(): continue
            pt = g.asPoint()
            rot = p[CAMPO_ROT]
            if rot in (None, "") or (isinstance(rot, QVariant) and rot.isNull()):
                rot = 0.0; senza_rot += 1
            nf = QgsFeature(campi)
            nf.setGeometry(cono_poligono(pt, float(rot), raggio, apert))
            nf[CAMPO_CONO_PUNTO] = p.id()
            for f in punti.fields():
                if f.name() != CAMPO_CONO_PUNTO:
                    nf[f.name()] = p[f.name()]
            feats.append(nf)

        if not feats:
            QMessageBox.warning(self, "Nessun cono",
                                "Nessun punto con geometria valida."); return
        if senza_rot:
            self._scrivi_log(self.log_cono, "%d punti senza rotazione: coni orientati a Nord." % senza_rot)

        base = os.path.dirname(self.project.fileName() or "") or os.path.expanduser("~")
        gpkg = os.path.join(base, "Coni di Ripresa.gpkg")
        nome = NOME_LAYER_CONI
        tmp = QgsVectorLayer("Polygon?crs=" + punti.crs().authid(), nome, "memory")
        tmp.dataProvider().addAttributes(campi); tmp.updateFields()
        tmp.dataProvider().addFeatures(feats); tmp.updateExtents()

        opz = QgsVectorFileWriter.SaveVectorOptions()
        opz.driverName = "GPKG"; opz.layerName = nome; opz.fileEncoding = "UTF-8"
        opz.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        err = QgsVectorFileWriter.writeAsVectorFormatV3(
            tmp, gpkg, self.project.transformContext(), opz)
        codice = err[0] if isinstance(err, tuple) else err
        if codice != QgsVectorFileWriter.NoError:
            dett = err[1] if isinstance(err, tuple) and len(err) > 1 else str(err)
            QMessageBox.critical(self, "Scrittura non riuscita",
                                 "GeoPackage non scritto:\n%s" % dett); return

        for l in list(self.project.mapLayers().values()):
            if l.name() == nome:
                self.project.removeMapLayer(l.id())
        lyr = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
        if not lyr.isValid():
            QMessageBox.warning(self, "Scritto ma non caricato",
                                "Il file è in %s ma non si è caricato." % gpkg); return
        self.project.addMapLayer(lyr)
        # Questi quattro valori restano nel progetto: servono a riagganciare il
        # riporto quando il progetto viene riaperto, senza che nessuno apra il
        # plugin e senza tirare a indovinare quale sia il layer dei punti.
        lyr.setCustomProperty(CONO_PROP_PUNTI, punti.id())
        lyr.setCustomProperty(CONO_PROP_RAGGIO, float(raggio))
        lyr.setCustomProperty(CONO_PROP_APERT, float(apert))
        lyr.setCustomProperty(CONO_PROP_MUOVE,
                              "1" if self.chk_cono_muove_camera.isChecked() else "0")
        self._collega_sync_coni(lyr, punti)
        self._scrivi_log(self.log_cono, "%d coni scritti in %s." % (len(feats), gpkg))
        QMessageBox.information(
            self, "Coni generati",
            "%d coni creati nel layer «%s».\n\n"
            "Per ruotarli: layer in modifica, strumento «Ruota elementi» "
            "(barra Digitalizzazione avanzata), trascina e vedi l'anteprima.\n"
            "Al SALVATAGGIO delle modifiche la rotazione viene riscritta nel "
            "campo '%s' dei punti di ripresa." % (len(feats), nome, CAMPO_ROT))

    def _riaggancia_coni_esistenti(self, *args):
        """Riattacca il riporto della rotazione ai coni gia' presenti.

        La connessione a afterCommitChanges sta nell'oggetto layer vivo, non
        nel GeoPackage: riaprendo il progetto va rifatta, altrimenti ruotare e
        salvare non scrive piu' niente sui punti di ripresa e sembra che il
        plugin ignori le modifiche.
        """
        try:
            punti = self.cb_k_foto.currentLayer()
            if punti is None or not punti.isValid():
                return
            for lyr in list(self.project.mapLayers().values()):
                if lyr.name() != NOME_LAYER_CONI:
                    continue
                if lyr.fields().indexOf(CAMPO_CONO_PUNTO) < 0:
                    continue
                self._collega_sync_coni(lyr, punti)
        except Exception as e:
            _log_avviso("riaggancio dei coni esistenti non riuscito", e)

    def _collega_sync_coni(self, coni, punti):
        """Aggancia il riporto della rotazione al salvataggio del layer coni."""
        try:
            # Si stacca prima quello che c'era: riagganciando a ogni cambio di
            # layer, senza questo, la stessa rotazione verrebbe riportata due
            # o tre volte per salvataggio.
            try:
                coni.afterCommitChanges.disconnect()
            except (TypeError, RuntimeError):
                pass
            coni.afterCommitChanges.connect(
                lambda lyr=coni, pt=punti: self._sync_coni_su_punti(lyr, pt))
        except Exception as e:
            _log_avviso("aggancio del salvataggio coni non riuscito", e)

    def _sync_coni_su_punti(self, coni, punti):
        """Riporta le rotazioni usando i valori impostati nel dialogo."""
        riporta_rotazioni(coni, punti, self._raggio_cono(),
                          float(self.spin_cono_apert.value()),
                          self.chk_cono_muove_camera.isChecked(),
                          scrivi_log=lambda t: self._scrivi_log(self.log_cono, t),
                          iface=getattr(self, "iface", None))

    def _coni_tavole(self):
        """Genera fino a 3 coni per ogni Tavola di Inquadramento (di più se
        servono per gli Armadi, vedi sotto): un cono per OGNI Armadio
        Ottico che ricade nella tavola — priorità assoluta, mai saltato,
        anche se sono più di 3 nella stessa tavola — poi, con il budget
        rimasto fino a un totale di 3, agli attraversamenti
        Infrastrutture×Provinciale, Infrastrutture×ANAS,
        Infrastrutture×Stradario (attraversamenti generici, non solo
        Provinciale/ANAS: coprono la maggioranza dei casi reali) e, in
        mancanza, ai Pozzetti Nuovi che toccano un'Infrastruttura Nuova e
        infine, in ultima istanza, un punto lungo le tratte Infrastrutture
        Nuove stesse (un attraversamento da un Pozzetto a un ROE PTE, o
        tra due Pozzetti) che ricadono nella tavola, in quest'ordine di
        priorità; a parità di tipo vince il candidato più vicino al centro
        della tavola. Non punta più al PTE dentro un Pozzetto come
        ripiego. TUTTI i coni (Armadio compreso) sono ancorati allo stesso
        modo: la proiezione perpendicolare del soggetto sulla tratta di
        Stradario (o altro shape lineare a scelta) più vicina, RIPORTATA
        dentro il perimetro della tavola se cadesse fuori (proiezione sul
        bordo più vicino) — così ogni cono resta sempre dentro la tavola
        che deve documentare. Ogni cono creato viene inoltre collegato
        alla sua tavola tramite il campo interno 'ID_Tavola' (creato se
        manca): un aggancio esplicito, non geometrico, così la
        numerazione automatica (pulsante più sotto) trova sempre il cono.
        Due controlli anti-duplicato indipendenti: un candidato il cui
        SOGGETTO (non solo la posizione della camera) coincide con uno già
        inquadrato in questa esecuzione viene scartato prima ancora di
        calcolarne la posizione; una posizione-camera calcolata che
        coincide (entro pochi cm) con un cono già esistente non viene
        comunque duplicata — per un Armadio conta come 'coperto', per gli
        altri tipi si scarta e si prova il candidato successivo senza
        consumare budget."""
        tavole = self.cb_kf_tavole.currentLayer()
        infra  = self.cb_kf_infra.currentLayer()
        poz    = self.cb_kf_pozzetto.currentLayer()
        arm_lyr  = self.cb_k_armadio.currentLayer()
        foto_lyr = self.cb_k_foto.currentLayer()
        strad_lyr = self.cb_k_stradario.currentLayer()
        sedime_lyr = self.cb_k_sedime.currentLayer()
        prov   = self.cb_kf_prov.currentLayer()
        anas   = self.cb_kf_anas.currentLayer()
        if not tavole or not infra or not arm_lyr or not foto_lyr:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Tavole di Inquadramento, Infrastrutture, Armadio Ottico e Punto di Ripresa."); return
        if foto_lyr.fields().indexOf(CAMPO_ROT) < 0:
            QMessageBox.critical(self, "Campo mancante", f"Punto di Ripresa non ha '{CAMPO_ROT}'."); return

        dist_riserva = self.spin_k_dist.value(); rag = self.spin_k_rag.value()
        dist_kf = self.spin_kf_dist.value()

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            idx_arm, arm_by = self._build_idx(arm_lyr)

            # Ritaglio su ARLO AREA (+ margine): Stradario, Provinciali e
            # ANAS sono spesso shape a scala nazionale (es. Stradario
            # Italia) letti per intero anche se il permesso copre
            # un'area minuscola — qui li limitiamo, con un semplice
            # filtro bbox lato provider, all'intorno di ARLO AREA.
            area_arlo = self._dissolvi_arlo()
            margine_arlo = self.spin_kf_margine_arlo.value()
            area_filtro = area_arlo.buffer(margine_arlo, 8) if area_arlo else None

            # Indice spaziale su Stradario costruito UNA volta sola,
            # prima del ciclo sulle tavole: prima veniva re-interrogato
            # il layer via bbox con raggio raddoppiato fino a 9 volte
            # PER OGNI candidato di OGNI tavola, il vero collo di
            # bottiglia su uno Stradario grande. Con l'indice in RAM
            # (già ritagliato ad ARLO AREA sopra) ogni ricerca costa una
            # nearestNeighbor(), non una nuova scansione del layer.
            strad_idx = None; strad_geoms = {}
            if strad_lyr:
                strad_idx = QgsSpatialIndex()
                req_strad = self._req_area(strad_lyr, area_filtro)
                it_strad = strad_lyr.getFeatures(req_strad) if req_strad is not None else strad_lyr.getFeatures()
                for i, f in enumerate(it_strad):
                    g = self._to_proj(f.geometry(), strad_lyr)
                    if not g or g.isEmpty(): continue
                    nf_idx = QgsFeature(); nf_idx.setId(i); nf_idx.setGeometry(g)
                    strad_idx.addFeature(nf_idx); strad_geoms[i] = g

            # Infrastrutture di interesse per i punti di ripresa: sempre
            # solo STATO='Nuovo', escluse TIPOLOGIA='Aerea' e TIPOLOGIA
            # vuota/NULL (non più un filtro opzionale). Confronto tollerante
            # a maiuscole/minuscole e spazi (' Aerea ', 'AEREA', 'nuovo'...):
            # un confronto esatto lasciava passare l'infrastruttura aerea
            # ogni volta che il dato non era scritto esattamente 'Aerea'.
            campo_stato_ok = infra.fields().indexOf(CAMPO_STATO) >= 0
            campo_tip_ok = infra.fields().indexOf(CAMPO_TIP_INFRA) >= 0
            val_nuovo_norm = VAL_NUOVO.strip().lower()
            val_aerea_norm = VAL_AEREA.strip().lower()
            feat_infra = []
            for f in infra.getFeatures():
                if campo_stato_ok:
                    st = f[CAMPO_STATO]
                    if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                        continue
                if campo_tip_ok:
                    tip = f[CAMPO_TIP_INFRA]
                    if tip is None or not isinstance(tip, str) or not tip.strip() or tip.strip().lower() == val_aerea_norm:
                        continue
                feat_infra.append(f)

            def punti_attraversamento(lyr_strada):
                """Punti di intersezione (proiettati) fra Infrastrutture e
                lyr_strada, con indice spaziale su lyr_strada (letto solo
                entro ARLO AREA + margine, vedi sopra) per non fare un
                confronto O(n×m) su layer grandi."""
                pts = []
                if not lyr_strada: return pts
                req_s = self._req_area(lyr_strada, area_filtro)
                idx_s, s_by = self._build_idx(lyr_strada, req=req_s)
                for f in feat_infra:
                    g = self._to_proj(f.geometry(), infra)
                    if not g or g.isEmpty(): continue
                    for cid in idx_s.intersects(g.boundingBox()):
                        g2, _f2 = s_by[cid]
                        try:
                            inter = self._valida(g).intersection(self._valida(g2))
                        except Exception:
                            continue
                        if not inter or inter.isEmpty(): continue
                        if inter.type() == QgsWkbTypes.PointGeometry:
                            if inter.isMultipart():
                                pts.extend(QgsPointXY(p) for p in inter.asMultiPoint())
                            else:
                                pts.append(QgsPointXY(inter.asPoint()))
                return pts

            pool_prov = punti_attraversamento(prov)
            pool_anas = punti_attraversamento(anas)
            # Attraversamenti perpendicolari allo Stradario stesso (non
            # solo Provinciale/ANAS): la maggior parte delle tratte nuove
            # attraversa strade comunali "generiche", mai classificate
            # come Provinciale/ANAS — senza questo tier quegli
            # attraversamenti (probabilmente i più numerosi) non
            # venivano mai individuati.
            pool_stradario = punti_attraversamento(strad_lyr) if strad_lyr else []

            # Ripiego intermedio: Pozzetti Nuovi che toccano un'Infrastruttura
            # Nuova (priorità più bassa degli attraversamenti Provinciale/
            # ANAS, ma più alta della tratta generica sotto — un pozzetto è
            # un punto fisico riconoscibile, più utile da fotografare di un
            # punto arbitrario a metà di una tratta).
            pool_pozzetti_nuovi = []
            if poz:
                idx_fi = QgsSpatialIndex(); fi_geoms = {}
                for i, f in enumerate(feat_infra):
                    g = self._to_proj(f.geometry(), infra)
                    if not g or g.isEmpty(): continue
                    nf_idx = QgsFeature(); nf_idx.setId(i); nf_idx.setGeometry(g)
                    idx_fi.addFeature(nf_idx); fi_geoms[i] = g
                campo_stato_poz_ok = poz.fields().indexOf(CAMPO_STATO) >= 0
                for f in poz.getFeatures():
                    if campo_stato_poz_ok:
                        st = f[CAMPO_STATO]
                        if not (isinstance(st, str) and st.strip().lower() == val_nuovo_norm):
                            continue
                    g = self._to_proj(f.geometry(), poz)
                    if not g or g.isEmpty(): continue
                    p = QgsPointXY(g.asPoint())
                    bb = QgsRectangle(p.x()-0.5, p.y()-0.5, p.x()+0.5, p.y()+0.5)
                    tocca = any(fi_geoms[cid].distance(g) <= 0.5 for cid in idx_fi.intersects(bb))
                    if tocca:
                        pool_pozzetti_nuovi.append(p)

            # Ripiego finale: un punto a metà lunghezza di ciascuna tratta
            # Infrastruttura Nuova (l'attraversamento realizzato dalla
            # tratta stessa, da un Pozzetto a un ROE PTE o tra due
            # Pozzetti), non più il PTE dentro un Pozzetto.
            pool_tratte = []
            for f in feat_infra:
                g = self._to_proj(f.geometry(), infra)
                if not g or g.isEmpty(): continue
                lung = g.length()
                if lung <= 0: continue
                pm = g.interpolate(lung / 2.0)
                if pm and not pm.isEmpty():
                    pool_tratte.append(QgsPointXY(pm.asPoint()))

            era = foto_lyr.isEditable()
            if not self._start_edit(foto_lyr):
                QMessageBox.critical(self, "Errore", "Impossibile avviare la modifica su Punto di Ripresa."); return
            if foto_lyr.fields().indexOf(CAMPO_ID_TAVOLA) < 0:
                foto_lyr.addAttribute(QgsField(CAMPO_ID_TAVOLA, QVariant.LongLong))
                foto_lyr.updateFields()
            idx_usati, prossimo_id = self._indice_punti_foto(foto_lyr)
            # Oggetti già inquadrati in questa esecuzione (non solo
            # posizioni-camera già occupate, ma i SOGGETTI stessi): un
            # incrocio Stradario molto vicino a un Pozzetto Nuovo, o due
            # tavole adiacenti che vedono lo stesso incrocio, potevano
            # produrre due coni diversi puntati allo stesso oggetto.
            bersagli_usati = []
            # Era 0.5 m: bastava che due incroci calcolati da pool diversi
            # (es. stesso incrocio fisico digitalizzato leggermente
            # diverso su Provinciale e su Stradario) fossero a 1-2 m
            # l'uno dall'altro per sfuggire al controllo e produrre due
            # coni puntati, di fatto, allo stesso oggetto. Alzata a 3 m
            # (poco meno della metà larghezza sedime stradale di default).
            SOGLIA_BERSAGLIO = 3.0

            def bersaglio_libero(pt):
                return not any(pt.distance(b) <= SOGLIA_BERSAGLIO for b in bersagli_usati)

            n_tavole = 0; n_arm = 0; n_prov = 0; n_anas = 0; n_strada = 0; n_poz = 0; n_tratta = 0
            n_incomplete = 0; n_vuote = 0; n_tavole_extra_armadi = 0; n_duplicati = 0
            for ft in tavole.getFeatures():
                g_tile = self._to_proj(ft.geometry(), tavole)
                if not g_tile or g_tile.isEmpty(): continue
                n_tavole += 1
                centro = g_tile.centroid().asPoint()
                extra = {CAMPO_ID_TAVOLA: ft.id()}

                def dentro(pt):
                    return g_tile.intersects(QgsGeometry.fromPointXY(pt))

                # 1) Armadio: un cono per OGNI Armadio nella tavola, sempre
                # — priorità assoluta, anche oltre il tetto di 3 se ce ne
                # sono di più. Se un cono esiste già esattamente sullo
                # stesso punto (es. da un'esecuzione precedente), l'Armadio
                # conta comunque come 'coperto' ma non si crea un duplicato.
                bb_tile = g_tile.boundingBox()
                armadi_in_tile = []
                for cid in idx_arm.intersects(bb_tile):
                    g_a, _fa = arm_by[cid]
                    pa = QgsPointXY(g_a.asPoint())
                    if dentro(pa):
                        armadi_in_tile.append(pa)
                coni_tile = 0
                for pa in armadi_in_tile:
                    pt_rip, _, rot_forzata = self._pt_cono_stradario(pa, strad_idx, strad_geoms, rag, dist_riserva, sedime_lyr=sedime_lyr, g_tile=g_tile)
                    pt_rip = self._clip_in_poligono(pt_rip, g_tile)
                    if self._punto_occupato(pt_rip, idx_usati):
                        n_duplicati += 1
                    else:
                        self._aggiungi_cono(foto_lyr, pt_rip, pa, extra=extra, rot_forzata=rot_forzata,
                                            linee_idx=strad_idx, linee_geoms=strad_geoms,
                                            soggetti_vicini=armadi_in_tile, arretra=True)
                        prossimo_id = self._registra_punto_foto(pt_rip, idx_usati, prossimo_id)
                        bersagli_usati.append(pa)
                        n_arm += 1
                    coni_tile += 1
                if len(armadi_in_tile) > 3: n_tavole_extra_armadi += 1
                budget = max(0, 3 - coni_tile)

                # 2) Pool attraversamenti/pozzetti/tratte nella tavola, in
                # ordine di priorità — stesso ancoraggio via Stradario
                # dell'Armadio, sempre tenuto DENTRO la tavola. Un
                # candidato che finirebbe duplicato (stessa posizione-
                # camera, o stesso oggetto già inquadrato) viene scartato
                # senza consumare budget: si passa al successivo.
                for pool, tag in ((pool_prov, 'prov'), (pool_anas, 'anas'), (pool_stradario, 'strada'), (pool_pozzetti_nuovi, 'poz'), (pool_tratte, 'tratta')):
                    if budget <= 0: break
                    candidati = sorted(
                        (p for p in pool if dentro(p) and bersaglio_libero(p)),
                        key=lambda p: p.distance(centro),
                    )
                    for p in candidati:
                        if budget <= 0: break
                        if not bersaglio_libero(p): continue  # potrebbe essere stato preso da un candidato precedente in questo stesso ciclo
                        pt_rip, _, rot_forzata = self._pt_cono_stradario(p, strad_idx, strad_geoms, rag, dist_kf, sedime_lyr=sedime_lyr, g_tile=g_tile)
                        pt_rip = self._clip_in_poligono(pt_rip, g_tile)
                        if self._punto_occupato(pt_rip, idx_usati):
                            n_duplicati += 1; continue
                        self._aggiungi_cono(foto_lyr, pt_rip, p, extra=extra, rot_forzata=rot_forzata,
                                            linee_idx=strad_idx, linee_geoms=strad_geoms,
                                            soggetti_vicini=[p], arretra=True)
                        prossimo_id = self._registra_punto_foto(pt_rip, idx_usati, prossimo_id)
                        bersagli_usati.append(p)
                        budget -= 1; coni_tile += 1
                        if tag == 'prov': n_prov += 1
                        elif tag == 'anas': n_anas += 1
                        elif tag == 'strada': n_strada += 1
                        elif tag == 'poz': n_poz += 1
                        else: n_tratta += 1

                if coni_tile == 0: n_vuote += 1
                elif coni_tile < 3: n_incomplete += 1

            if not era and not self._commit(foto_lyr, "Errore salvataggio Punti di Ripresa"):
                return
            foto_lyr.triggerRepaint()
        finally:
            QApplication.restoreOverrideCursor()

        tot = n_arm + n_prov + n_anas + n_strada + n_poz + n_tratta
        msg = [
            f"Tavole esaminate: {n_tavole}. Coni creati: {tot} "
            f"(Armadio: {n_arm}, Provinciale: {n_prov}, ANAS: {n_anas}, Stradario: {n_strada}, Pozzetto Nuovo: {n_poz}, Tratta Infrastruttura Nuova: {n_tratta}).",
        ]
        if n_duplicati: msg.append(f"{n_duplicati} coni scartati: punto già occupato da un cono esistente.")
        if n_tavole_extra_armadi: msg.append(f"{n_tavole_extra_armadi} tavole con più di 3 Armadi: tutti fotografati, oltre il tetto di 3 coni.")
        if n_incomplete: msg.append(f"{n_incomplete} tavole con meno di 3 coni (candidati insufficienti).")
        if n_vuote: msg.append(f"{n_vuote} tavole senza nessun candidato.")
        if area_filtro is None:
            msg.append("ARLO AREA non impostata (scheda 'Keyplan e tavole'): Stradario/Provinciali/ANAS letti per intero, senza ritaglio — su shape nazionali può essere lento.")
        testo = "\n".join(msg)
        self.log_kf.setPlainText(testo)
        QMessageBox.information(self, "Coni Tavole generati", testo)

    def _assicura_numero_tav(self, tavole, campo_tav):
        """Garantisce che il layer Tavole abbia il campo campo_tav popolato in
        modo valido e univoco. Se il campo manca, o non è valorizzato ovunque,
        o contiene duplicati/valori non interi, RINUMERA automaticamente tutte
        le tavole in ordine di lettura (dall'alto in basso per righe, da
        sinistra a destra dentro ogni riga) — il criterio con cui si numerano
        le tavole di una planimetria. Se invece la numerazione esistente è già
        completa, intera e univoca, la RISPETTA e non tocca nulla (non
        sovrascrive il lavoro manuale fatto altrove).
        Ritorna (ok, rinumerate) dove rinumerate=True se ha riscritto i numeri.
        """
        idx = tavole.fields().indexOf(campo_tav)
        # valuta se la numerazione attuale è già buona
        valida = idx >= 0
        if valida:
            visti = set()
            n_feat = 0
            for f in tavole.getFeatures():
                n_feat += 1
                v = f[campo_tav]
                if v is None or (isinstance(v, str) and not v.strip()):
                    valida = False; break
                try:
                    n = int(round(float(v)))
                except (TypeError, ValueError):
                    valida = False; break
                if n in visti:
                    valida = False; break
                visti.add(n)
            if n_feat == 0:
                valida = False
        if valida:
            return True, False   # numerazione esistente buona: non toccare

        # --- rinumerazione automatica in ordine di lettura ---
        # ordino le tavole per posizione: righe dall'alto (y decrescente),
        # colonne da sinistra (x crescente). Uso il centroide in CRS di
        # progetto. Le righe si raggruppano con una tolleranza pari a metà
        # dell'altezza media delle tavole, così tavole della stessa fascia
        # orizzontale finiscono nella stessa riga anche se non perfettamente
        # allineate.
        centri = []
        altezze = []
        for f in tavole.getFeatures():
            g = self._to_proj(f.geometry(), tavole)
            if not g or g.isEmpty():
                continue
            c = g.centroid().asPoint()
            bb = g.boundingBox()
            centri.append((f.id(), c.x(), c.y()))
            altezze.append(bb.height())
        if not centri:
            return False, False
        tol = (sum(altezze) / len(altezze)) * 0.5 if altezze else 0.0

        # raggruppo in righe per y decrescente
        centri.sort(key=lambda t: -t[2])
        righe = []
        for fid, x, y in centri:
            for r in righe:
                if abs(r["y"] - y) <= tol:
                    r["items"].append((fid, x, y))
                    r["y"] = sum(i[2] for i in r["items"]) / len(r["items"])
                    break
            else:
                righe.append({"y": y, "items": [(fid, x, y)]})
        # ordino le righe dall'alto e, dentro ognuna, da sinistra
        righe.sort(key=lambda r: -r["y"])
        ordine = []
        for r in righe:
            for fid, x, y in sorted(r["items"], key=lambda i: i[1]):
                ordine.append(fid)

        if not self._start_edit(tavole):
            QMessageBox.critical(self, "Errore",
                "Impossibile avviare la modifica sulle Tavole di Inquadramento "
                "per numerarle automaticamente."); return False, False
        if idx < 0:
            tavole.addAttribute(QgsField(campo_tav, QVariant.Int))
            tavole.updateFields()
            idx = tavole.fields().indexOf(campo_tav)
        for n, fid in enumerate(ordine, start=1):
            tavole.changeAttributeValue(fid, idx, n)
        if not self._commit(tavole, "Errore salvataggio numerazione Tavole"):
            return False, False
        tavole.triggerRepaint()
        return True, True

    def _trova_layer_tavole(self, campo_tav, foto_lyr=None):
        """Trova il layer 'Tavole di Inquadramento' nel progetto in modo robusto,
        indipendente dal nome esatto (che nei progetti varia:
        'Poligoni di Inquadramento', 'Poligoni_di_Inquadramento_1-500_A1', ecc.).
        Criterio: layer POLIGONALE che (a) ha già il campo campo_tav, oppure
        (b) ha nel nome sia 'poligon' sia 'inquadr'. Scarta i layer enormi
        (edifici/particelle). Se è dato foto_lyr, fra i candidati sceglie quello
        che CONTIENE GEOMETRICAMENTE PIÙ FOTO — criterio infallibile quando nel
        progetto convivono più layer tavole (es. una versione con poche feature e
        quella vera con tutte le tavole). Ritorna il layer o None."""
        from qgis.core import QgsWkbTypes, QgsSpatialIndex, QgsFeature
        candidati_campo = []
        candidati_nome = []
        for l in self.project.mapLayers().values():
            try:
                if l.type() != l.VectorLayer:
                    continue
                if QgsWkbTypes.geometryType(l.wkbType()) != QgsWkbTypes.PolygonGeometry:
                    continue
            except Exception:
                continue
            nome_l = l.name().lower()
            ha_campo = l.fields().indexOf(campo_tav) >= 0
            try:
                n = l.featureCount()
            except Exception:
                n = -1
            piccolo = (n < 0) or (n <= 2000)
            if ha_campo and piccolo:
                candidati_campo.append(l)
            elif ("poligon" in nome_l and "inquadr" in nome_l) and piccolo:
                candidati_nome.append(l)

        # se ho il layer foto, costruisco un indice dei punti e conto quante foto
        # cadono dentro ogni candidato: vince chi ne contiene di più.
        idx_foto = None
        punti = {}
        if foto_lyr is not None:
            try:
                idx_foto = QgsSpatialIndex()
                for i, f in enumerate(foto_lyr.getFeatures()):
                    g = self._to_proj(f.geometry(), foto_lyr)
                    if not g or g.isEmpty():
                        continue
                    nf = QgsFeature(); nf.setId(i); nf.setGeometry(g)
                    idx_foto.addFeature(nf); punti[i] = g
            except Exception:
                idx_foto = None

        def foto_contenute(layer):
            if idx_foto is None:
                return -1
            tot = 0
            try:
                for ft in layer.getFeatures():
                    gt = self._to_proj(ft.geometry(), layer)
                    if not gt or gt.isEmpty():
                        continue
                    for cid in idx_foto.intersects(gt.boundingBox()):
                        if gt.intersects(punti[cid]):
                            tot += 1
            except Exception:
                return -1
            return tot

        for gruppo in (candidati_campo, candidati_nome):
            if not gruppo:
                continue
            if idx_foto is not None and len(gruppo) > 1:
                # scegli quello che contiene più foto; a parità, più feature
                gruppo.sort(key=lambda l: (foto_contenute(l),
                                           l.featureCount() if l.featureCount() >= 0 else 0),
                            reverse=True)
            else:
                # nessun layer foto o candidato unico: preferisci più feature
                # (il layer tavole vero ha tutte le tavole, non un sottoinsieme)
                gruppo.sort(key=lambda l: l.featureCount() if l.featureCount() >= 0 else 0,
                            reverse=True)
            return gruppo[0]
        return None

    def _numera_foto(self):
        """Numera le Foto da 1 a N a blocchi FISSI di 3 per Tavola di
        Inquadramento (base = (numero_tav-1)*3 + 1), nell'ordine del
        rispettivo numero tavola. Richiede che le Tavole di Inquadramento
        siano già numerate nel campo indicato (non generato da questo
        plugin, va numerato altrove, es. nel software di impaginazione):
        se il campo manca, o non è valorizzato ovunque, o contiene
        duplicati, non numera nulla e spiega il motivo. Se una tavola ha
        meno di 3 coni, il/i numero/i mancante/i del suo blocco vengono
        semplicemente saltati — non riassegnati né riutilizzati dalla
        tavola successiva, che parte comunque dal proprio blocco pieno.
        Le Foto generate da 'Coni per Tavola di Inquadramento' sono
        associate alla loro tavola tramite il campo 'ID_Tavola' (aggancio
        esplicito): serve perché il punto di ripresa può finire fuori dal
        perimetro della tavola una volta spostato sullo Stradario più
        vicino, e un semplice test geometrico "dentro la tavola" non le
        troverebbe più. Le Foto senza questo campo valorizzato (es. dal
        pulsante Coni Armadi, non legato a nessuna tavola) usano ancora
        il ripiego geometrico."""
        tavole = self.cb_kf_tavole.currentLayer()
        foto_lyr = self.cb_k_foto.currentLayer()
        campo_tav = self.txt_num_tav.text().strip()
        campo_foto = self.txt_num_foto.text().strip()
        if not campo_foto:
            campo_foto = "NumeroFoto"
        if not campo_tav:
            campo_tav = "Numero Tav"
        # Rete di sicurezza sul layer Tavole. Il combo può puntare al layer
        # sbagliato: un layer poligonale enorme (edifici/particelle → "13800
        # tavole"), oppure una versione delle tavole che NON contiene le foto
        # (es. un 'Poligoni_di_Inquadramento_..._fit' con poche feature mentre le
        # foto stanno sopra un altro layer tavole). Il criterio decisivo è: il
        # layer tavole giusto è quello che CONTIENE le foto. Se il layer
        # selezionato non contiene nessuna foto, cerco quello che ne contiene di
        # più.
        from qgis.core import QgsSpatialIndex as _QSI, QgsFeature as _QF
        def _foto_dentro(layer_tav):
            if layer_tav is None or foto_lyr is None:
                return -1
            try:
                idxf = _QSI(); pts = {}
                for i, f in enumerate(foto_lyr.getFeatures()):
                    g = self._to_proj(f.geometry(), foto_lyr)
                    if not g or g.isEmpty():
                        continue
                    nf = _QF(); nf.setId(i); nf.setGeometry(g)
                    idxf.addFeature(nf); pts[i] = g
                tot = 0
                for ft in layer_tav.getFeatures():
                    gt = self._to_proj(ft.geometry(), layer_tav)
                    if not gt or gt.isEmpty():
                        continue
                    for cid in idxf.intersects(gt.boundingBox()):
                        if gt.intersects(pts[cid]):
                            tot += 1
                return tot
            except Exception:
                return -1
        def _troppo_grande(l):
            try:
                n = l.featureCount()
            except Exception:
                n = -1
            return n > 2000
        # decido se il layer corrente va bene o va cercato quello giusto
        serve_ricerca = (tavole is None) or _troppo_grande(tavole)
        if not serve_ricerca and foto_lyr is not None:
            if _foto_dentro(tavole) == 0:
                serve_ricerca = True   # tavole valide ma non contengono foto
        if serve_ricerca:
            trovato = self._trova_layer_tavole(campo_tav, foto_lyr)
            if trovato is not None:
                tavole = trovato
                try:
                    self.cb_kf_tavole.setLayer(trovato)  # allinea anche il combo
                except Exception:
                    pass
        if not tavole or not foto_lyr:
            QMessageBox.warning(self, "Layer mancanti", "Seleziona Tavole di Inquadramento e Punto di Ripresa."); return

        # numerazione automatica delle Tavole se il campo manca / è incompleto /
        # ha duplicati: se invece è già valido lo rispetta e non tocca nulla.
        ok_tav, rinumerate = self._assicura_numero_tav(tavole, campo_tav)
        if not ok_tav:
            return
        idx_campo_tav = tavole.fields().indexOf(campo_tav)

        tavole_num = []; mancanti = 0
        for f in tavole.getFeatures():
            v = f[campo_tav]
            if v is None or (isinstance(v, str) and not v.strip()):
                mancanti += 1; continue
            try:
                n = int(round(float(v)))
            except (TypeError, ValueError):
                mancanti += 1; continue
            tavole_num.append((n, f))
        if not tavole_num:
            QMessageBox.warning(self, "Tavole non numerate", f"Nessuna tavola ha un valore valido nel campo '{campo_tav}': numera prima le tavole, poi riprova."); return
        if mancanti:
            QMessageBox.warning(
                self, "Numerazione incompleta",
                f"{mancanti} tavole non hanno un valore valido nel campo '{campo_tav}'. "
                "Completa la numerazione di TUTTE le tavole prima di procedere."
            ); return
        numeri = [n for n, _ in tavole_num]
        if len(numeri) != len(set(numeri)):
            QMessageBox.warning(self, "Numeri duplicati", f"Il campo '{campo_tav}' contiene valori duplicati tra le tavole: correggi prima di procedere."); return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # Aggancio foto→tavola robusto all'OVERLAP fra tavole. Le foto
            # generate da "Coni per Tavola" hanno lo stesso ID_Tavola quando
            # appartengono alla stessa tavola: quell'ID è spesso "orfano"
            # rispetto agli fid reali (id temporanei di un layer memory poi
            # salvato), ma resta un RAGGRUPPAMENTO valido. Quindi:
            #  1) raggruppo le foto per ID_Tavola (le foto di una stessa tavola
            #     restano insieme anche se cadono nella zona di sovrapposizione
            #     con la tavola accanto);
            #  2) assegno ogni GRUPPO in blocco alla tavola che ne contiene
            #     geometricamente più punti — così l'overlap non spezza i gruppi
            #     e nessuna foto viene contata due volte;
            #  3) le foto senza ID_Tavola valido vanno per pura geometria.
            idx_campo_id_tav_foto = foto_lyr.fields().indexOf(CAMPO_ID_TAVOLA)
            gruppi_id = {}          # id_tavola -> [foto]
            foto_non_collegate = [] # foto senza id: ripiego geometrico puro
            for f in foto_lyr.getFeatures():
                v = f[CAMPO_ID_TAVOLA] if idx_campo_id_tav_foto >= 0 else None
                messa = False
                if v is not None:
                    try:
                        if not (hasattr(v, "isNull") and v.isNull()):
                            gruppi_id.setdefault(int(v), []).append(f)
                            messa = True
                    except (TypeError, ValueError):
                        pass
                if not messa:
                    foto_non_collegate.append(f)

            # geometrie tavole in CRS di progetto (una volta sola)
            tav_geom = {}
            for n_tav, ft in tavole_num:
                g = self._to_proj(ft.geometry(), tavole)
                tav_geom[n_tav] = g

            # per ogni gruppo: la tavola che contiene più punti del gruppo
            per_tavola = {}  # n_tav -> [foto]
            for gid, fs in gruppi_id.items():
                conteggio = {}
                for f in fs:
                    gp = self._to_proj(f.geometry(), foto_lyr)
                    if not gp or gp.isEmpty():
                        continue
                    for n_tav, g in tav_geom.items():
                        if g and not g.isEmpty() and g.intersects(gp):
                            conteggio[n_tav] = conteggio.get(n_tav, 0) + 1
                if conteggio:
                    n_best = max(conteggio.items(), key=lambda kv: kv[1])[0]
                    per_tavola.setdefault(n_best, []).extend(fs)
                else:
                    # gruppo interamente fuori da ogni tavola: ripiego geometrico
                    foto_non_collegate.extend(fs)

            idx_foto_libere = QgsSpatialIndex(); foto_libere_by = {}
            for i, f in enumerate(foto_non_collegate):
                g = self._to_proj(f.geometry(), foto_lyr)
                if not g or g.isEmpty(): continue
                nf_idx = QgsFeature(); nf_idx.setId(i); nf_idx.setGeometry(g)
                idx_foto_libere.addFeature(nf_idx); foto_libere_by[i] = (g, f)

            era = foto_lyr.isEditable()
            if not self._start_edit(foto_lyr):
                QMessageBox.critical(self, "Errore", "Impossibile avviare la modifica su Punto di Ripresa."); return
            idx_campo_foto = foto_lyr.fields().indexOf(campo_foto)
            if idx_campo_foto < 0:
                foto_lyr.addAttribute(QgsField(campo_foto, QVariant.Int))
                foto_lyr.updateFields()
                idx_campo_foto = foto_lyr.fields().indexOf(campo_foto)

            assegnati = 0; tavole_incomplete = 0
            usate_geom = set()   # id foto già prese dal pool geometrico
            for n_tav, ft in sorted(tavole_num, key=lambda x: x[0]):
                candidati = list(per_tavola.get(n_tav, []))
                if len(candidati) < 3:
                    g_tile = tav_geom.get(n_tav)
                    if g_tile and not g_tile.isEmpty():
                        bb = g_tile.boundingBox()
                        for cid in idx_foto_libere.intersects(bb):
                            if cid in usate_geom:
                                continue
                            g_f, f_f = foto_libere_by[cid]
                            if g_tile.intersects(g_f):
                                candidati.append(f_f); usate_geom.add(cid)
                candidati.sort(key=lambda f: f.id())
                candidati = candidati[:3]
                if len(candidati) < 3: tavole_incomplete += 1
                base = (n_tav - 1) * 3 + 1
                for i, f in enumerate(candidati):
                    foto_lyr.changeAttributeValue(f.id(), idx_campo_foto, base + i)
                    assegnati += 1

            if not era and not self._commit(foto_lyr, "Errore salvataggio numerazione Foto"):
                return
            foto_lyr.triggerRepaint()
        finally:
            QApplication.restoreOverrideCursor()

        msg = f"Numerate {assegnati} foto su {len(tavole_num)} tavole (campo '{campo_foto}')."
        if rinumerate:
            msg = ("Tavole di Inquadramento numerate automaticamente (campo "
                   f"'{campo_tav}', ordine di lettura alto→basso, sinistra→destra).\n") + msg
        if tavole_incomplete:
            msg += f"\n{tavole_incomplete} tavole con meno di 3 coni: i numeri mancanti del loro blocco sono stati saltati."
        self.log_n.setPlainText(msg)
        QMessageBox.information(self, "Numerazione completata", msg)

    # ═══════════════════════════════════════════════ CHILOMETRICHE – LOGICA
    # formati ammessi per il valore scritto sul cippo: chiave interna e
    # etichetta mostrata nel combo del punto 1
    _FORMATI_KM = (
        ("km_m",       "km+metri, es. 17+100 (standard)"),
        ("invertito",  "metri+km INVERTITO, es. 100+17 = km 17+100"),
        ("metri",      "solo metri, es. 17100"),
        ("km_dec",     "km decimali, es. 17,1"),
    )
    _PREFISSI_KM = ftth_core.PREFISSI_KM  # definito in ftth_core

    @staticmethod
    def _parse_chilometrica(testo, formato="km_m"):
        """Valore del cippo → metri (None se non interpretabile).
        Implementazione e documentazione in ftth_core.parse_chilometrica
        (testata in tests/test_core.py)."""
        return ftth_core.parse_chilometrica(testo, formato)

    @staticmethod
    def _format_chilometrica(metri):
        return ftth_core.format_chilometrica(metri)

    # ═════════════════════════════════════════ CHILOMETRICHE – LOGICA
    @staticmethod
    def _punto_riferimento(geom):
        """Punto rappresentativo con cui cercare il corridoio: il punto stesso
        se la geometria è puntuale, il punto medio misurato lungo la linea se
        è lineare (il centroide di una linea curva può cadere fuori dalla
        strada)."""
        if geom is None or geom.isEmpty():
            return None
        if geom.type() == QgsWkbTypes.PointGeometry:
            return geom.asPoint()
        lunghezza = geom.length()
        if lunghezza <= 0:
            centro = geom.centroid()
            return centro.asPoint() if centro and not centro.isEmpty() else None
        medio = geom.interpolate(lunghezza / 2.0)
        if medio is None or medio.isEmpty():
            centro = geom.centroid()
            return centro.asPoint() if centro and not centro.isEmpty() else None
        return medio.asPoint()

    def _costruisci_corridoi(self, rif_lyr, solo_selezionate, campo_gruppo,
                             area_interesse, cucitura=1.0):
        """Ricuce le tratte della linea di riferimento in 'corridoi' continui e
        ritorna [(etichetta, geometria_linea_continua), …].

        È il cuore della correzione: uno stradario (es. 'Stradario Provincia
        Italia') non è UNA linea ma centinaia di segmenti, uno per tronco o
        per civico. Sul singolo segmento lineLocatePoint() misura una
        progressiva relativa a quel pezzetto, e un cippo e un pozzetto distanti
        50 m ricadono quasi sempre su due segmenti DIVERSI: la vecchia versione
        pretendeva invece che ricadessero sulla stessa feature, quindi
        scartava praticamente tutto con 'nessuna ancora sulla stessa linea di
        riferimento'. Qui i segmenti che si toccano vengono fusi (mergeLines)
        in polilinee continue, così la progressiva è misurata lungo l'intera
        strada e cippi e target stanno sullo stesso sistema di riferimento.

        `solo_selezionate` limita alle tratte selezionate in mappa (consigliato
        con stradari estesi), `campo_gruppo` ricuce solo tratte che condividono
        lo stesso valore (es. codice o nome strada), `area_interesse` limita la
        lettura all'intorno di cippi e target per non caricare l'intera
        provincia."""
        if rif_lyr is None:
            return []
        if solo_selezionate:
            iteratore = rif_lyr.getSelectedFeatures()
        else:
            richiesta = self._req_area(rif_lyr, area_interesse)
            iteratore = rif_lyr.getFeatures(richiesta) if richiesta else rif_lyr.getFeatures()

        idx_gruppo = self._indice_campo(rif_lyr, campo_gruppo) if campo_gruppo else -1
        gruppi = {}
        n_anelli = 0
        for f in iteratore:
            g = self._to_proj(f.geometry(), rif_lyr)
            if not g or g.isEmpty():
                continue
            chiave = str(f[idx_gruppo]) if idx_gruppo >= 0 else "tutte le tratte"
            # molti stradari sono di tipo MultiLineString: le parti vanno
            # esplose prima di raccoglierle, altrimenti collectGeometry()
            # produce una geometria annidata su cui mergeLines() non ricuce
            for parte in (g.asGeometryCollection() if g.isMultipart() else [g]):
                if parte is None or parte.isEmpty():
                    continue
                # ROTONDE: una tratta chiusa su se stessa (l'anello della
                # rotonda) non è percorso utile della strada. Se finisce nel
                # corridoio, mergeLines la cuce dentro e la progressiva si
                # gonfia di mezza circonferenza: su una rotonda da 15 m di
                # raggio sono ~64 m di errore su ogni elemento oltre la
                # rotonda (misurato). Va scartata: i due monconi di strada
                # vengono poi ricuciti dritti da _ricuci_con_tolleranza.
                if self._e_anello_chiuso(parte):
                    n_anelli += 1
                    continue
                gruppi.setdefault(chiave, []).append(parte)
        if n_anelli:
            _log_avviso("corridoi chilometriche: scartati %d anelli chiusi "
                        "(rotonde) che falsavano le progressive" % n_anelli, None)

        corridoi = []
        for chiave, geometrie in gruppi.items():
            unite = QgsGeometry.collectGeometry(geometrie)
            if unite is None or unite.isEmpty():
                continue
            try:
                # mergeLines() fonde le linee che condividono un estremo: da N
                # segmenti contigui ottiene una sola polilinea continua
                fuse = unite.mergeLines()
                if fuse is None or fuse.isEmpty():
                    fuse = unite
            except Exception:
                fuse = unite
            parti = fuse.asGeometryCollection() if fuse.isMultipart() else [fuse]
            parti = self._ricuci_con_tolleranza(parti, cucitura)
            multi = len(parti) > 1
            for n, parte in enumerate(parti, start=1):
                if parte is None or parte.isEmpty() or parte.length() <= 0:
                    continue
                etichetta = f"{chiave} – tronco {n}" if multi else str(chiave)
                corridoi.append((etichetta, parte))
        return corridoi

    def _e_anello_chiuso(self, geom, tol=2.0):
        """True se la linea si chiude su se stessa: è l'anello di una rotonda
        (o una piazza/cul-de-sac circolare).

        Serve alle Chilometriche: l'anello non è percorso utile della strada,
        ma mergeLines() lo cuce dentro il corridoio e la progressiva di ogni
        elemento OLTRE la rotonda si gonfia di mezza circonferenza. Misurato su
        una rotonda di raggio 15 m: +64 m di errore, azzerato scartando l'anello.

        Criterio: primo e ultimo vertice coincidono entro `tol` metri, con
        almeno 4 vertici (sotto non è un anello ma un segmento degenere) e una
        lunghezza compatibile con una rotonda reale (non un intero cappio
        stradale di chilometri, che invece va tenuto).
        """
        try:
            if geom is None or geom.isEmpty() or geom.isMultipart():
                return False
            pts = geom.asPolyline()
        except Exception:
            return False
        if len(pts) < 4:
            return False
        try:
            dx = pts[0].x() - pts[-1].x()
            dy = pts[0].y() - pts[-1].y()
            if (dx * dx + dy * dy) ** 0.5 > tol:
                return False
            # un anello chiuso lunghissimo non è una rotonda: è un circuito
            # stradale vero e va lasciato nel corridoio
            return geom.length() <= 400.0
        except Exception:
            return False

    def _ricuci_con_tolleranza(self, parti, tolleranza):
        """Concatena le polilinee i cui estremi distano meno di `tolleranza`,
        restituendo il minor numero possibile di tracciati continui.

        mergeLines() unisce solo le linee che condividono un vertice ESATTO,
        mentre negli stradari reali i tronchi si chiudono spesso a pochi
        centimetri l'uno dall'altro: il risultato è una strada spezzata in più
        corridoi. Ogni corridoio ha un proprio sistema di progressive e un
        proprio cippo di riferimento, quindi due elementi vicini ma su corridoi
        diversi ricevono chilometriche non confrontabili — è la seconda causa
        degli errori di conteggio. L'ordine di partenza è deterministico
        (coordinate del primo vertice) perché a parità di dati il risultato
        deve essere identico a ogni lancio."""
        linee = []
        for g in parti:
            try:
                punti = list(g.asPolyline())
            except Exception:
                punti = []
            if len(punti) >= 2:
                linee.append(punti)
        if tolleranza <= 0 or len(linee) < 2:
            return [QgsGeometry.fromPolylineXY(l) for l in linee]

        linee.sort(key=lambda l: (round(l[0].x(), 3), round(l[0].y(), 3)))
        usate = [False] * len(linee)
        risultato = []

        def direzione(a, b):
            return math.atan2(b.y() - a.y(), b.x() - a.x())

        def scarto_angolare(entrante, uscente):
            """Differenza fra due direzioni, riportata in 0..pi."""
            delta = abs(entrante - uscente) % (2 * math.pi)
            return min(delta, 2 * math.pi - delta)

        # oltre questo scarto la candidata non è la prosecuzione della strada ma
        # una laterale: agli incroci mergeLines() consegna tre tronconi che si
        # toccano nello stesso punto, e agganciare quello sbagliato produrrebbe
        # progressive che a un certo punto svoltano in un'altra via
        MAX_SCARTO = math.radians(75)

        for i in range(len(linee)):
            if usate[i]:
                continue
            catena = list(linee[i]); usate[i] = True
            while True:
                migliore = None  # (indice, rovesciata, in_coda, scarto, distanza)
                coda, testa = catena[-1], catena[0]
                dir_coda = direzione(catena[-2], catena[-1])
                dir_testa = direzione(catena[1], catena[0])
                for j, altra in enumerate(linee):
                    if usate[j]:
                        continue
                    for rovesciata in (False, True):
                        a = altra[::-1] if rovesciata else altra
                        d = math.hypot(coda.x() - a[0].x(), coda.y() - a[0].y())
                        if d <= tolleranza:
                            scarto = scarto_angolare(dir_coda, direzione(a[0], a[1]))
                            if scarto <= MAX_SCARTO and (migliore is None or
                                                         (scarto, d) < migliore[3:5]):
                                migliore = (j, rovesciata, True, scarto, d)
                        d = math.hypot(testa.x() - a[-1].x(), testa.y() - a[-1].y())
                        if d <= tolleranza:
                            scarto = scarto_angolare(dir_testa, direzione(a[-1], a[-2]))
                            if scarto <= MAX_SCARTO and (migliore is None or
                                                         (scarto, d) < migliore[3:5]):
                                migliore = (j, rovesciata, False, scarto, d)
                if migliore is None:
                    break
                j, rovesciata, in_coda, _, distanza = migliore
                a = linee[j][::-1] if rovesciata else list(linee[j])
                usate[j] = True
                coincidente = distanza <= 1e-6
                if in_coda:
                    catena.extend(a[1:] if coincidente else a)
                else:
                    catena = (a[:-1] if coincidente else a) + catena
            risultato.append(QgsGeometry.fromPolylineXY(catena))
        return risultato

    def _leggi_cippi(self, ancore_lyr, idx_campo_ancora, formato="km_m"):
        """[(geometria_punto, valore_metri, etichetta), …] per i cippi
        leggibili, più l'elenco dei motivi di scarto."""
        cippi = []; scartati = []
        for a in ancore_lyr.getFeatures():
            g = self._to_proj(a.geometry(), ancore_lyr)
            if not g or g.isEmpty():
                scartati.append(f"id {a.id()}: geometria mancante o non trasformabile.")
                continue
            grezzo = a[idx_campo_ancora]
            valore = self._parse_chilometrica(grezzo, formato)
            if valore is None:
                scartati.append(f"id {a.id()}: valore '{grezzo}' non interpretabile come chilometrica.")
                continue
            cippi.append((g, valore, str(grezzo)))
        return cippi, scartati

    @staticmethod
    def _cippi_sul_corridoio(corridoio, cippi, tolleranza):
        """Cippi entro `tolleranza` dal corridoio, proiettati su di esso e
        ordinati per progressiva: [(progressiva, valore, etichetta, distanza)].

        Un cippo può servire più corridoi (vicino a un bivio è normale che sia
        prossimo a due strade): non viene assegnato in esclusiva a quello più
        vicino, altrimenti in prossimità di rotatorie e incroci si perderebbe
        proprio il riferimento che serve."""
        intorno = corridoio.boundingBox()
        intorno.grow(tolleranza)
        trovati = []
        for g, valore, etichetta in cippi:
            punto = g.asPoint()
            if not intorno.contains(punto):
                continue
            d = corridoio.distance(g)
            if d > tolleranza:
                continue
            trovati.append((corridoio.lineLocatePoint(g), valore, etichetta, d))
        trovati.sort(key=lambda t: t[0])
        return trovati

    # modalità di calcolo: chiave interna ed etichetta nel combo
    _MODI_KM = (
        ("basso", "Progressione dal cippo più basso (1 m di strada = 1 m di chilometrica)"),
        ("vicino", "Progressione dal cippo più vicino all'elemento"),
        ("interpolazione", "Interpolazione fra i cippi (adatta la scala ai loro valori)"),
    )

    @staticmethod
    def _verso_progressione(cippi_corridoio):
        """+1 se le chilometriche crescono nel senso in cui il corridoio è stato
        ricucito, -1 se calano, 0 se i cippi non permettono di stabilirlo.

        Il verso in cui mergeLines() concatena i segmenti è arbitrario e non ha
        nulla a che vedere con il verso di crescita delle chilometriche: lo si
        ricava confrontando la posizione del cippo con il valore più basso con
        quella del cippo con il valore più alto."""
        if len(cippi_corridoio) < 2:
            return 0
        piu_basso = min(cippi_corridoio, key=lambda c: c[1])
        piu_alto = max(cippi_corridoio, key=lambda c: c[1])
        if piu_alto[1] == piu_basso[1] or piu_alto[0] == piu_basso[0]:
            return 0
        return 1 if piu_alto[0] > piu_basso[0] else -1

    def _chilometrica_da_cippi(self, prog_target, cippi_corridoio,
                               modo="basso", inverti=False):
        """(valore_metri, nota) per un elemento che sta a `prog_target` metri
        lungo il corridoio.

        Nelle due modalità di progressione la chilometrica è il valore del cippo
        di riferimento più la distanza REALE percorsa lungo la strada, un metro
        di strada per un metro di chilometrica: una strada ha un verso e i
        chilometri crescono in quel verso, quindi i valori risultano monotoni e
        confrontabili fra loro. L'interpolazione invece riscala le distanze sui
        valori dichiarati dai cippi: è più fedele quando i cippi sono precisi,
        ma se un cippo è posizionato male o trascritto male comprime o dilata
        tutto il tratto che lo riguarda, e la progressione si perde."""
        if not cippi_corridoio:
            return None, "nessun cippo sul corridoio"

        verso = self._verso_progressione(cippi_corridoio)
        avviso_verso = ""
        if verso == 0:
            verso = 1
            avviso_verso = (" — VERSO NON DETERMINABILE con un solo cippo utile: "
                            "se i valori crescono al contrario spunta 'Inverti il verso'")
        if inverti:
            verso = -verso

        if modo == "interpolazione" and len(cippi_corridoio) >= 2:
            valore, nota = self._interpola_fra_cippi(prog_target, cippi_corridoio)
            return valore, nota

        if modo == "vicino":
            base = min(cippi_corridoio, key=lambda c: abs(c[0] - prog_target))
        else:
            base = min(cippi_corridoio, key=lambda c: c[1])

        scostamento = verso * (prog_target - base[0])
        return (base[1] + scostamento,
                f"progressione da '{base[2]}' {scostamento:+.0f} m lungo la strada"
                + avviso_verso)

    @staticmethod
    def _interpola_fra_cippi(prog_target, cippi_corridoio):
        """Vecchia modalità: interpolazione lineare fra i due cippi che
        racchiudono il punto, estrapolazione con la pendenza della coppia più
        esterna quando il punto cade fuori dal tratto coperto."""
        prima = [c for c in cippi_corridoio if c[0] <= prog_target]
        dopo = [c for c in cippi_corridoio if c[0] > prog_target]
        if prima and dopo:
            prog_p, val_p, nome_p, _ = prima[-1]
            prog_d, val_d, nome_d = dopo[0][0], dopo[0][1], dopo[0][2]
            campata = prog_d - prog_p
            t = (prog_target - prog_p) / campata if campata else 0.0
            return val_p + t * (val_d - val_p), f"interpolato fra '{nome_p}' e '{nome_d}'"

        if dopo:
            a, b = cippi_corridoio[0], cippi_corridoio[1]
        else:
            a, b = cippi_corridoio[-2], cippi_corridoio[-1]
        campata = b[0] - a[0]
        pendenza = ((b[1] - a[1]) / campata) if campata else 1.0
        base = cippi_corridoio[0] if dopo else cippi_corridoio[-1]
        return (base[1] + pendenza * (prog_target - base[0]),
                f"estrapolato oltre '{base[2]}' con la pendenza fra '{a[2]}' e '{b[2]}'")

    def _verifica_coerenza_cippi(self, cippi_corridoio, modo="basso"):
        """Avvisi sui cippi di un corridoio che non stanno dove la loro
        chilometrica dice.

        In progressione il riferimento è il cippo più basso e la strada si
        misura 1:1, quindi ogni altro cippo dovrebbe trovarsi esattamente alla
        distanza pari alla differenza fra le due chilometriche. Lo scarto fra
        posizione dichiarata e posizione reale è l'errore che gli elementi di
        quel tratto si porteranno dietro, quindi conviene vederlo prima."""
        avvisi = []
        if len(cippi_corridoio) < 2:
            return avvisi

        # scarto di unità: nessuna coppia con una pendenza plausibile
        for a, b in zip(cippi_corridoio, cippi_corridoio[1:]):
            campata = b[0] - a[0]
            if campata <= 0.5:
                avvisi.append(f"i cippi '{a[2]}' e '{b[2]}' cadono nello stesso punto "
                              f"della strada ({campata:.1f} unità): impossibile "
                              "stabilire il verso di progressione.")
                continue
            pendenza = abs(b[1] - a[1]) / campata
            if not 0.2 <= pendenza <= 5:
                avvisi.append(
                    f"fra '{a[2]}' e '{b[2]}' ci sono {campata:.0f} unità di strada ma "
                    f"{abs(b[1] - a[1]):.0f} m di chilometrica ({pendenza:.2f} m per "
                    "metro): il valore dei cippi non è nell'unità che il plugin sta "
                    "leggendo. Controlla il 'Formato del valore scritto sul cippo' — se "
                    "hai digitato prima i metri e poi i km (100+17 per km 17+100) scegli "
                    "la voce INVERTITO.")
                return avvisi  # inutile controllare gli scarti con l'unità sbagliata

        verso = self._verso_progressione(cippi_corridoio) or 1
        base = min(cippi_corridoio, key=lambda c: c[1])
        for prog, valore, nome, _ in cippi_corridoio:
            if nome == base[2]:
                continue
            previsto = base[1] + verso * (prog - base[0])
            scarto = valore - previsto
            tolleranza = max(15.0, abs(valore - base[1]) * 0.1)
            if abs(scarto) > tolleranza:
                avvisi.append(
                    f"il cippo '{nome}' sta dove la progressione da '{base[2]}' dà "
                    f"{self._format_chilometrica(previsto)}: scarto {scarto:+.0f} m. "
                    + ("In progressione il cippo non viene usato come riferimento, "
                       "quindi il risultato non ne è influenzato, ma uno dei due cippi "
                       "è mal posizionato o trascritto male."
                       if modo != "interpolazione" else
                       "In interpolazione questo scarto viene distribuito sugli elementi "
                       "del tratto: passa alla progressione o correggi il cippo."))
        return avvisi

    # punto in cui misurare la chilometrica di una TRATTA (per i punti non serve)
    _MISURE_KM = (
        ("inizio", "Inizio della tratta (il capo con la chilometrica minore)"),
        ("medio", "Punto medio della tratta"),
        ("intervallo", "Intervallo: da inizio a fine (es. 17+100 / 17+145)"),
        ("estremi", "Testo esteso: dal km 17+100 al km 17+145"),
    )

    @staticmethod
    def _estremi_linea(geom):
        """Primo e ultimo vertice della geometria lineare, o None."""
        try:
            if geom.isMultipart():
                parti = geom.asMultiPolyline()
                punti = [p for parte in parti for p in parte]
            else:
                punti = list(geom.asPolyline())
        except Exception:
            return None
        if len(punti) < 2:
            return None
        return punti[0], punti[-1]

    def _indice_pozzetti_km(self, p):
        """Indice spaziale dei pozzetti nel CRS di progetto, per l'aggancio dei
        capi delle tratte. Ritorna (QgsSpatialIndex, {fid: QgsPointXY}) o
        (None, {}) se il layer non è impostato."""
        lyr = p.get("pozzetti_lyr")
        if lyr is None or not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
            return None, {}
        indice = QgsSpatialIndex(); punti = {}
        for f in lyr.getFeatures(QgsFeatureRequest().setNoAttributes()):
            g = self._to_proj(f.geometry(), lyr)
            if g is None or g.isEmpty():
                continue
            pt = g.asPoint()
            punti[f.id()] = QgsPointXY(pt)
            copia = QgsFeature(); copia.setId(f.id())
            copia.setGeometry(QgsGeometry.fromPointXY(pt))
            indice.addFeature(copia)
        return (indice if punti else None), punti

    @staticmethod
    def _aggancia_a_pozzetto(punto, indice, punti, tolleranza):
        """Il QgsPointXY del pozzetto più vicino entro tolleranza, o None."""
        if indice is None:
            return None
        vicini = indice.nearestNeighbor(punto, 1, tolleranza)
        if not vicini:
            return None
        candidato = punti.get(vicini[0])
        if candidato is None:
            return None
        if math.hypot(candidato.x() - punto.x(),
                      candidato.y() - punto.y()) <= tolleranza:
            return candidato
        return None

    # Scostamento massimo (m) tra i due capi di una tratta, misurato lungo
    # l'asse strada, sotto il quale la tratta è considerata un ATTRAVERSAMENTO
    # ortogonale e la chilometrica è scritta come punto singolo invece che
    # "dal km X al km Y" (i due estremi proiettano quasi sullo stesso punto).
    _SOGLIA_KM_PUNTUALE = 2.0

    def _valore_su_corridoio(self, geom, corridoio, cippi_corridoio, p,
                             idx_pozzetti=None, punti_pozzetti=None):
        """(valore_numerico, testo, nota) per un elemento sul corridoio.

        Su una tratta la chilometrica dei due capi è diversa, e misurare il
        punto medio faceva sembrare incoerenti tratte adiacenti: due scavi
        consecutivi di 40 m ricevevano valori distanti 40 m mentre il primo
        finiva dove il secondo cominciava. Ora l'impostazione predefinita è il
        capo con la chilometrica minore, cioè il punto in cui la tratta inizia
        nel verso di crescita della strada, e c'è la possibilità di scrivere
        l'intervallo completo.

        Aggancio ai pozzetti (v0.78.5): i capi delle tratte coincidono coi
        pozzetti della rete. Se un capo cade su un pozzetto entro la tolleranza
        di aggancio, la misura usa ESATTAMENTE il punto del pozzetto: così la
        chilometrica scritta sulla tratta e quella scritta sul pozzetto sono
        identiche, invece di differire di qualche decimetro di disegno. Dove il
        capo non tocca pozzetti, si misura il capo così com'è."""
        def km(punto):
            prog = corridoio.lineLocatePoint(QgsGeometry.fromPointXY(punto))
            return self._chilometrica_da_cippi(prog, cippi_corridoio,
                                               p["modo"], p["inverti"])

        if geom.type() == QgsWkbTypes.PointGeometry:
            valore, nota = km(geom.asPoint())
            return valore, (self._format_chilometrica(valore) if valore is not None else ""), nota

        estremi = self._estremi_linea(geom)
        if estremi is None or p["misura"] == "medio":
            punto = self._punto_riferimento(geom)
            if punto is None:
                return None, "", "geometria non misurabile"
            valore, nota = km(punto)
            return valore, (self._format_chilometrica(valore) if valore is not None else ""), nota

        # aggancio dei capi ai pozzetti, dove ci sono
        capo_a, capo_b = estremi
        agganciati = 0
        pa = self._aggancia_a_pozzetto(capo_a, idx_pozzetti,
                                       punti_pozzetti or {}, p.get("snap", 0))
        pb = self._aggancia_a_pozzetto(capo_b, idx_pozzetti,
                                       punti_pozzetti or {}, p.get("snap", 0))
        if pa is not None:
            capo_a = pa; agganciati += 1
        if pb is not None:
            capo_b = pb; agganciati += 1

        valore_a, nota = km(capo_a)
        valore_b, _ = km(capo_b)
        if valore_a is None or valore_b is None:
            return None, "", nota
        if agganciati:
            nota += f" — {agganciati} cap{'o' if agganciati == 1 else 'i'} su pozzetto"
        minore, maggiore = sorted((valore_a, valore_b))
        # Tratta ortogonale alla strada (attraversamento): i due capi proiettati
        # sull'asse cadono quasi nello stesso punto. "dal km X al km X+1" è
        # inutilmente verboso quando lo scostamento è minimo → un solo km.
        if (maggiore - minore) <= self._SOGLIA_KM_PUNTUALE:
            return minore, self._format_chilometrica(minore), nota + " — attraversamento (km puntuale)"
        if p["misura"] == "intervallo":
            testo = (f"{self._format_chilometrica(minore)} / "
                     f"{self._format_chilometrica(maggiore)}")
            return minore, testo, nota + f" — tratta lunga {maggiore - minore:.0f} m"
        if p["misura"] == "estremi":
            # la dicitura per le tavole e le relazioni: "dal km X al km Y",
            # sempre nel verso di crescita della strada (inizio = km minore),
            # a prescindere dal verso di disegno della polilinea
            testo = (f"dal km {self._format_chilometrica(minore)} "
                     f"al km {self._format_chilometrica(maggiore)}")
            return minore, testo, nota + f" — tratta lunga {maggiore - minore:.0f} m"
        return minore, self._format_chilometrica(minore), nota

    def _target_chilometriche(self):
        """Layer su cui scrivere: il layer del combo e, se richiesto, gli altri
        layer vettoriali selezionati nel pannello Livelli (esclusi il layer di
        riferimento e quello dei cippi)."""
        principale = self.cb_km_target.currentLayer()
        target = [principale] if principale else []
        if self.chk_km_multi_target.isChecked():
            esclusi = {l.id() for l in (self.cb_km_riferimento.currentLayer(),
                                        self.cb_km_ancore.currentLayer()) if l}
            for l in self.iface.layerTreeView().selectedLayers():
                if not isinstance(l, QgsVectorLayer):
                    continue
                if l.id() in esclusi or any(t.id() == l.id() for t in target):
                    continue
                if l.geometryType() not in (QgsWkbTypes.PointGeometry, QgsWkbTypes.LineGeometry):
                    continue
                target.append(l)
        return target

    def _estensione_proj(self, lyr):
        """Estensione del layer nel CRS di progetto, letta dai metadati senza
        scorrere le feature."""
        try:
            bb = lyr.extent()
            if lyr.crs() != self.project.crs():
                trasf = QgsCoordinateTransform(lyr.crs(), self.project.crs(), self.project)
                bb = trasf.transformBoundingBox(bb)
            return bb
        except Exception:
            return None

    def _area_interesse_km(self, cippi, target_lyrs, margine):
        """Bounding box entro cui leggere la linea di riferimento: cippi più
        ESTENSIONE COMPLETA dei layer target, allargata di `margine`.

        Deve essere indipendente dalla selezione, ed è il motivo per cui usa
        l'estensione dei layer e non le feature scelte: prima l'area cambiava a
        ogni lancio, quindi cambiava anche l'insieme di tratte lette dallo
        stradario e con esso il corridoio ricucito. La progressiva è misurata
        lungo il corridoio, quindi lo stesso pozzetto elaborato con la selezione
        della Tavola 1 e poi con quella della Tavola 2 otteneva due
        chilometriche diverse. Così invece il sistema di riferimento è sempre lo
        stesso e i valori sono confrontabili fra tratte, pozzetti e lanci
        successivi."""
        bb = QgsRectangle(); bb.setMinimal()
        for g, _, _ in cippi:
            bb.combineExtentWith(g.boundingBox())
        for lyr in target_lyrs:
            estensione = self._estensione_proj(lyr)
            if estensione is not None and not estensione.isEmpty():
                bb.combineExtentWith(estensione)
        if bb.isNull() or bb.isEmpty():
            return None
        bb.grow(max(margine, bb.width() * 0.25, bb.height() * 0.25))
        return QgsGeometry.fromRect(bb)

    def _feature_da_elaborare(self, lyr):
        """Feature selezionate del layer; tutte se non c'è selezione e l'utente
        ha spuntato l'opzione."""
        selezionate = list(lyr.getSelectedFeatures())
        if selezionate:
            return selezionate
        if self.chk_km_tutte_feature.isChecked():
            return list(lyr.getFeatures())
        return []

    def _parametri_chilometriche(self):
        """Controlli comuni a calcolo e diagnostica: ritorna un dizionario con
        i parametri già validati, oppure None dopo aver mostrato l'errore."""
        ancore_lyr = self.cb_km_ancore.currentLayer()
        rif_lyr = self.cb_km_riferimento.currentLayer()
        if not ancore_lyr or not rif_lyr:
            QMessageBox.warning(self, "Layer mancanti",
                "Imposta il layer dei cippi e la linea di riferimento."); return None

        idx_ancora, nome_ancora = self._campo_ancora(ancore_lyr)
        if idx_ancora < 0:
            nomi = ", ".join(c.name() for c in ancore_lyr.fields()) or "(nessun campo)"
            QMessageBox.critical(self, "Campo del cippo non indicato",
                f"Su '{ancore_lyr.name()}' non trovo il campo con il valore "
                f"chilometrico.\n\nScegli il campo giusto nel punto 1: i campi "
                f"disponibili sono:\n{nomi}"); return None

        target_lyrs = self._target_chilometriche()
        if not target_lyrs:
            QMessageBox.warning(self, "Target mancante", "Imposta il layer target."); return None

        formato = self._FORMATI_KM[max(0, self.cb_km_formato.currentIndex())][0]
        cippi, scartati = self._leggi_cippi(ancore_lyr, idx_ancora, formato)
        return {
            "ancore_lyr": ancore_lyr, "rif_lyr": rif_lyr, "target_lyrs": target_lyrs,
            "idx_ancora": idx_ancora, "nome_ancora": nome_ancora, "formato": formato,
            "cippi": cippi, "scartati": scartati,
            "raggio": self.spin_km_raggio.value(),
            "tolleranza": self.spin_km_tol_cippi.value(),
            "solo_selez_rif": self.chk_km_solo_selez_rif.isChecked(),
            "campo_gruppo": self.cb_km_campo_gruppo.currentField(),
            "campo_out": self.txt_km_campo.text().strip(),
            "modo": self._MODI_KM[max(0, self.cb_km_modo.currentIndex())][0],
            "inverti": self.chk_km_inverti.isChecked(),
            "cucitura": self.spin_km_cucitura.value(),
            "misura": self._MISURE_KM[max(0, self.cb_km_misura.currentIndex())][0],
            "pozzetti_lyr": self.cb_km_pozzetti.currentLayer(),
            "snap": self.spin_km_snap.value(),
        }

    def _corridoio_piu_vicino(self, punto, corridoi_con_cippi, raggio):
        """(indice, distanza) del corridoio più vicino al punto entro raggio."""
        geom_punto = QgsGeometry.fromPointXY(punto)
        migliore = -1; dist_migliore = None
        for i, (_, corridoio, _) in enumerate(corridoi_con_cippi):
            d = corridoio.distance(geom_punto)
            if d > raggio:
                continue
            if dist_migliore is None or d < dist_migliore:
                migliore = i; dist_migliore = d
        return migliore, dist_migliore

    def _corridoio_per_feature(self, geom, punto_rif, corridoi_con_cippi, raggio):
        """(indice, distanza) del corridoio più vicino alla feature.

        Per le tratte lineari non basta il punto di riferimento (il medio): una
        tratta ORTOGONALE alla strada (attraversamento) ha il punto medio a metà
        carreggiata, che può cadere oltre il raggio dal corridoio con i cippi,
        mentre uno dei suoi CAPI tocca la strada. Si prova quindi il punto medio
        e, per le linee, anche i due estremi, tenendo il corridoio più vicino fra
        tutti i punti candidati: così l'attraversamento aggancia comunque la
        strada che lo riguarda."""
        candidati = [punto_rif]
        if geom is not None and geom.type() == QgsWkbTypes.LineGeometry:
            estremi = self._estremi_linea(geom)
            if estremi is not None:
                candidati.extend(estremi)
        migliore = -1; dist_migliore = None
        for punto in candidati:
            if punto is None:
                continue
            i, d = self._corridoio_piu_vicino(punto, corridoi_con_cippi, raggio)
            if i < 0:
                continue
            if dist_migliore is None or d < dist_migliore:
                migliore = i; dist_migliore = d
        return migliore, dist_migliore

    def _diagnostica_chilometriche(self):
        """Spiega, numeri alla mano, perché il calcolo non produce risultati:
        CRS, cippi letti e scartati, corridoi ricuciti, distanze reali fra
        cippi/target e corridoi. Sostituisce il vecchio 'nessuna ancora sulla
        stessa linea di riferimento', che non diceva quale delle cinque cause
        possibili fosse quella vera."""
        p = self._parametri_chilometriche()
        if p is None:
            return

        r = []
        crs_prog = self.project.crs()
        r.append(f"CRS di progetto: {crs_prog.authid()} "
                 f"({'gradi — le distanze in metri NON funzionano, riproietta il progetto in UTM' if crs_prog.isGeographic() else 'unità lineari, ok'})")
        r.append(f"Cippi: '{p['ancore_lyr'].name()}' [{p['ancore_lyr'].crs().authid()}], "
                 f"campo letto: '{p['nome_ancora']}'")
        r.append(f"Riferimento: '{p['rif_lyr'].name()}' [{p['rif_lyr'].crs().authid()}], "
                 f"{p['rif_lyr'].featureCount()} tratte totali, "
                 f"{p['rif_lyr'].selectedFeatureCount()} selezionate in mappa")
        r.append("")

        r.append(f"Cippi con valore leggibile: {len(p['cippi'])} "
                 f"(formato: {dict(self._FORMATI_KM)[p['formato']]})")
        alternativo = "invertito" if p["formato"] == "km_m" else "km_m"
        for g, valore, etichetta in p["cippi"][:15]:
            riga = f"  • '{etichetta}' → {self._format_chilometrica(valore)} ({valore:.0f} m)"
            alt = self._parse_chilometrica(etichetta, alternativo)
            if alt is not None and abs(alt - valore) > 0.5:
                riga += f"   [leggendolo al contrario sarebbe {self._format_chilometrica(alt)}]"
            r.append(riga)
        if len(p["cippi"]) > 15:
            r.append(f"  … e altri {len(p['cippi']) - 15}")
        for s in p["scartati"][:10]:
            r.append(f"  ✗ {s}")
        if not p["cippi"]:
            r.append("  → senza cippi leggibili il calcolo non può partire: controlla il "
                     "campo scelto al punto 1 e il formato dei valori (12+300 / 12,3 / 12300).")
            self.log_km.setPlainText("\n".join(r)); return
        r.append("")

        area = self._area_interesse_km(p["cippi"], p["target_lyrs"], p["raggio"] * 10)
        corridoi = self._costruisci_corridoi(p["rif_lyr"], p["solo_selez_rif"],
                                             p["campo_gruppo"], area, p["cucitura"])
        origine = min(p["cippi"], key=lambda c: c[1])
        r.append(f"PUNTO 0 (cippo più basso fra tutti): '{origine[2]}' = "
                 f"{self._format_chilometrica(origine[1])}")
        r.append(f"Corridoi continui ricuciti dallo stradario: {len(corridoi)} "
                 f"(tolleranza di ricucitura {p['cucitura']:g})")
        if not corridoi:
            r.append("  → nessuna tratta di riferimento letta. Se hai spuntato 'usa solo le "
                     "tratte selezionate' devi prima selezionarle in mappa; altrimenti "
                     "controlla che lo stradario copra la zona dei cippi.")
            self.log_km.setPlainText("\n".join(r)); return

        utili = []
        for etichetta, corridoio in corridoi:
            sopra = self._cippi_sul_corridoio(corridoio, p["cippi"], p["tolleranza"])
            if sopra:
                utili.append((etichetta, corridoio, sopra))
        r.append(f"Corridoi che hanno almeno un cippo entro {p['tolleranza']:g}: {len(utili)}")
        r.append(f"Modalità: {dict(self._MODI_KM)[p['modo']]}"
                 + ("  [verso invertito a mano]" if p["inverti"] else ""))
        for etichetta, corridoio, sopra in utili[:10]:
            verso = self._verso_progressione(sopra)
            base = min(sopra, key=lambda c: c[1])
            descrizione_verso = {1: "concorde al tracciato ricucito",
                                 -1: "opposto al tracciato ricucito",
                                 0: "NON DETERMINABILE (serve un secondo cippo)"}[verso]
            r.append(f"  • {etichetta}: lunghezza {corridoio.length():.0f}, "
                     f"{len(sopra)} cippi ({', '.join(c[2] for c in sopra[:6])})")
            r.append(f"    conta da '{base[2]}', verso di crescita {descrizione_verso}")
            for a in self._verifica_coerenza_cippi(sopra, p["modo"]):
                r.append(f"    ⚠ {a}")
        if not utili:
            distanze = []
            for _, corridoio in corridoi:
                for g, _, etichetta in p["cippi"]:
                    distanze.append((corridoio.distance(g), etichetta))
            distanze.sort()
            if distanze:
                r.append(f"  → il cippo più vicino a un corridoio dista "
                         f"{distanze[0][0]:.1f} unità ('{distanze[0][1]}'): alza la "
                         f"'Tolleranza cippo → corridoio' oltre questo valore.")
            self.log_km.setPlainText("\n".join(r)); return
        r.append("")

        for lyr in p["target_lyrs"]:
            feature = self._feature_da_elaborare(lyr)
            i_out = self._indice_campo(lyr, p["campo_out"])
            r.append(f"Target '{lyr.name()}': {len(feature)} feature da elaborare, "
                     f"campo '{p['campo_out']}' "
                     f"{'presente come ' + lyr.fields().at(i_out).name() if i_out >= 0 else 'ASSENTE (crealo al punto 0)'}")
            if not feature:
                r.append("  → nessuna feature selezionata in mappa: selezionale, oppure "
                         "spunta 'elabora tutte le sue feature'.")
                continue
            agganciate = 0; fuori = []
            for f in feature:
                g = self._to_proj(f.geometry(), lyr)
                punto = self._punto_riferimento(g)
                if punto is None:
                    continue
                i, d = self._corridoio_piu_vicino(punto, utili, p["raggio"])
                if i >= 0:
                    agganciate += 1
                else:
                    tutte = [c[1].distance(QgsGeometry.fromPointXY(punto)) for c in utili]
                    if tutte:
                        fuori.append(min(tutte))
            r.append(f"  agganciate a un corridoio con cippi: {agganciate}/{len(feature)}")
            if fuori:
                r.append(f"  → le altre distano da {min(fuori):.1f} a {max(fuori):.1f} unità dal "
                         f"corridoio più vicino: alza 'Raggio ricerca target → corridoio' "
                         f"(ora {p['raggio']:g}).")

        self.log_km.setPlainText("\n".join(r))
        self._mostra_stato(self.stato_km, "Diagnostica eseguita: nessun dato modificato.")

    def _calcola_chilometriche(self):
        p = self._parametri_chilometriche()
        if p is None:
            return
        if not p["campo_out"]:
            QMessageBox.warning(self, "Campo di output mancante",
                "Indica il nome del campo su cui scrivere la chilometrica."); return
        if not p["cippi"]:
            QMessageBox.critical(self, "Nessun cippo leggibile",
                f"Nessuna feature di '{p['ancore_lyr'].name()}' ha un valore "
                f"chilometrico interpretabile nel campo '{p['nome_ancora']}'.\n\n"
                "Usa 'Diagnostica' per l'elenco degli scarti."); return

        area = self._area_interesse_km(p["cippi"], p["target_lyrs"], p["raggio"] * 10)
        corridoi = self._costruisci_corridoi(p["rif_lyr"], p["solo_selez_rif"],
                                             p["campo_gruppo"], area, p["cucitura"])
        utili = []
        for etichetta, corridoio in corridoi:
            sopra = self._cippi_sul_corridoio(corridoio, p["cippi"], p["tolleranza"])
            if sopra:
                utili.append((etichetta, corridoio, sopra))
        if not utili:
            QMessageBox.critical(self, "Nessun corridoio utilizzabile",
                f"Ho ricucito {len(corridoi)} corridoi dalla linea di riferimento, ma "
                f"nessuno ha un cippo entro {p['tolleranza']:g} unità.\n\n"
                "Premi 'Diagnostica' per vedere le distanze reali e capire quale "
                "tolleranza serve."); return

        righe = []; totale_aggiornati = 0; totale_feature = 0
        idx_pozzetti, punti_pozzetti = self._indice_pozzetti_km(p)
        if idx_pozzetti is not None:
            righe.append(f"AGGANCIO POZZETTI attivo: '{p['pozzetti_lyr'].name()}' "
                         f"({len(punti_pozzetti)} pozzetti, tolleranza "
                         f"{p['snap']:g}). I capi delle tratte che cadono su un "
                         f"pozzetto vengono misurati nel punto esatto del pozzetto.")
            righe.append("")

        # punto 0: il cippo con la chilometrica più bassa fra tutti quelli letti.
        # È il riferimento da cui si conta, e va dichiarato in testa al log perché
        # è l'unico modo di accorgersi se fra due lanci è cambiato.
        origine = min(p["cippi"], key=lambda c: c[1])
        righe.append(f"PUNTO 0: cippo '{origine[2]}' = "
                     f"{self._format_chilometrica(origine[1])}. Da qui si conta la "
                     f"distanza reale lungo la strada, 1 m per 1 m.")
        if len(utili) > 1:
            righe.append(f"ATTENZIONE: la linea di riferimento risulta spezzata in "
                         f"{len(utili)} corridoi separati, ognuno con la propria origine: "
                         f"gli elementi che stanno su corridoi diversi NON sono "
                         f"confrontabili fra loro. Alza la 'Tolleranza di ricucitura' "
                         f"oppure seleziona in mappa le sole tratte della strada.")
        righe.append("")

        avvisi = []
        for etichetta, _, cippi_corr in utili:
            for a in self._verifica_coerenza_cippi(cippi_corr, p["modo"]):
                avvisi.append(f"⚠ {etichetta}: {a}")
        if avvisi:
            righe.append("CONTROVERIFICA SUI CIPPI (gli altri cippi non spostano il "
                         "conteggio, servono a confermarlo):")
            righe.extend("  " + a for a in avvisi)
            righe.append("")

        for lyr in p["target_lyrs"]:
            feature = self._feature_da_elaborare(lyr)
            righe.append(f"── {lyr.name()} ──")
            if not feature:
                righe.append("  nessuna feature selezionata (e opzione 'tutte' non attiva): saltato.")
                continue
            idx_out = self._indice_campo(lyr, p["campo_out"])
            if idx_out < 0:
                righe.append(f"  campo '{p['campo_out']}' assente: crealo al punto 0. Saltato.")
                continue
            nome_out = lyr.fields().at(idx_out).name()
            campo_e_testo = lyr.fields().at(idx_out).type() == QVariant.String
            # con le misure testuali lunghe (intervallo, "dal km ... al km ...")
            # un campo creato corto dalle versioni precedenti tronca in silenzio:
            # meglio dirlo subito, con la lunghezza che serve
            lunghezza_campo = lyr.fields().at(idx_out).length()
            if (campo_e_testo and p["misura"] in ("intervallo", "estremi")
                    and 0 < lunghezza_campo < 30):
                righe.append(f"  ATTENZIONE: il campo '{nome_out}' è lungo "
                             f"{lunghezza_campo} caratteri e la misura scelta può "
                             f"produrre testi fino a ~30: i valori più lunghi "
                             f"verrebbero troncati. Ricrea il campo al punto 0 "
                             f"(ora viene creato a 40) o rinominalo e rilancia.")
            if not self._start_edit(lyr):
                righe.append("  impossibile avviare la modifica: saltato.")
                continue

            aggiornati = 0; origini_usate = {}
            for f in feature:
                totale_feature += 1
                g = self._to_proj(f.geometry(), lyr)
                punto = self._punto_riferimento(g)
                if punto is None:
                    righe.append(f"  id {f.id()}: geometria mancante, saltata."); continue
                i_corr, dist = self._corridoio_per_feature(g, punto, utili, p["raggio"])
                if i_corr < 0:
                    righe.append(f"  id {f.id()}: nessun corridoio con cippi entro "
                                 f"{p['raggio']:g} unità."); continue
                etichetta_corr, corridoio, cippi_corr = utili[i_corr]
                valore, testo_km, nota = self._valore_su_corridoio(
                    g, corridoio, cippi_corr, p, idx_pozzetti, punti_pozzetti)
                if valore is None:
                    righe.append(f"  id {f.id()}: {nota}."); continue
                da_scrivere = (self._testo_scrivibile(lyr, testo_km) if campo_e_testo
                               else round(valore, 2))
                origini_usate[etichetta_corr] = origini_usate.get(etichetta_corr, 0) + 1
                if lyr.changeAttributeValue(f.id(), idx_out, da_scrivere):
                    aggiornati += 1
                    righe.append(f"  id {f.id()}: {testo_km} — {nota} "
                                 f"[corridoio: {etichetta_corr}, scostamento {dist:.1f}]")
                else:
                    righe.append(f"  id {f.id()}: scrittura rifiutata dal provider.")

            if self._commit(lyr, f"Salvataggio chilometriche su {lyr.name()}"):
                totale_aggiornati += aggiornati
                righe.append(f"  → {aggiornati} feature scritte nel campo '{nome_out}'.")
                if len(origini_usate) > 1:
                    righe.append("     ATTENZIONE: le feature di questo layer sono state "
                                 "misurate su corridoi diversi — "
                                 + ", ".join(f"{quante} su '{corr}'"
                                             for corr, quante in origini_usate.items()))
            else:
                righe.append("  → SALVATAGGIO ANNULLATO (rollback): nessun valore scritto.")

        intestazione = (f"{totale_aggiornati} feature valorizzate su {totale_feature} "
                        f"elaborate, usando {len(p['cippi'])} cippi su "
                        f"{len(utili)} corridoi.\n")
        self.log_km.setPlainText(intestazione + "\n" + "\n".join(righe))
        self._mostra_stato(self.stato_km, intestazione.strip(),
                           ok=totale_aggiornati > 0)

    # ─── TAB ETICHETTE ──────────────────────────────────────────────
    # ruolo -> (etichetta nel pannello, filtro layer)
    _SEPARATORI_ET = (("trattino ( - )", " - "), ("spazio", " "), ("a capo", "\n"))

    # caratteri tipografici che i DBF in codepage ANSI/Latin-1 non sanno scrivere
    # (li sostituisce con '?') e loro equivalenti ASCII
    _SOSTITUZIONI_ASCII = {
        "\u2013": "-", "\u2014": "-", "\u2212": "-",   # en dash, em dash, meno
        "\u00f7": "-",                                  # segno di divisione
        "\u00d7": "x", "\u2019": "'", "\u2018": "'",
        "\u201c": '"', "\u201d": '"', "\u2026": "...",
        "\u00a0": " ", "\u2022": "-",
    }

    def _testo_scrivibile(self, lyr, testo):
        """Adatta il testo alla codifica con cui il layer verrà scritto.

        Uno shapefile senza file .cpg dichiara una codepage ANSI e QGIS scrive
        con quella: ogni carattere fuori tabella diventa un punto interrogativo
        nell'attributo, ed è il motivo per cui nelle etichette compariva un '?'
        al posto del trattino tipografico. Qui i caratteri tipografici più
        comuni vengono ricondotti all'equivalente ASCII e, se resta qualcosa di
        non codificabile, gli accenti vengono rimossi anziché lasciare che il
        provider li rovini."""
        for originale, sostituto in self._SOSTITUZIONI_ASCII.items():
            testo = testo.replace(originale, sostituto)
        try:
            codifica = lyr.dataProvider().encoding() or "UTF-8"
        except Exception:
            codifica = "UTF-8"
        try:
            testo.encode(codifica)
            return testo
        except (UnicodeEncodeError, LookupError):
            pass
        senza_accenti = unicodedata.normalize("NFKD", testo)
        senza_accenti = "".join(c for c in senza_accenti if not unicodedata.combining(c))
        try:
            senza_accenti.encode(codifica)
            return senza_accenti
        except (UnicodeEncodeError, LookupError):
            return senza_accenti.encode("ascii", "replace").decode("ascii")

    def _tab_etichette(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("etichette"))

        v.addWidget(self._desc(
            "Compila un campo di testo (per default 'Etichette') su Armadio, Pozzetto e "
            "Infrastrutture, componendolo dalla chilometrica dell'elemento più la "
            "dicitura di posa. Il campo viene creato se manca. Le diciture e i campi di "
            "origine sono modificabili qui sotto, così se il modello dati cambia non "
            "serve rimettere mano al codice. Richiede la chilometrica già calcolata "
            "nella scheda Chilometriche."
        ))

        gb1 = self._gruppo("1) Layer da etichettare"); f1 = QFormLayout(gb1)
        self.cb_et_armadio = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        f1.addRow("Armadio Ottico:", self.cb_et_armadio)
        self.cb_et_poz = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        f1.addRow("Pozzetto:", self.cb_et_poz)
        self.cb_et_infra = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        f1.addRow("Infrastrutture:", self.cb_et_infra)
        riga_campi = QHBoxLayout()
        self.txt_et_campo = QLineEdit("Etichette")
        riga_campi.addWidget(QLabel("campo da scrivere:")); riga_campi.addWidget(self.txt_et_campo)
        self.txt_et_km = QLineEdit("Chilometrica")
        riga_campi.addWidget(QLabel("chilometrica da:")); riga_campi.addWidget(self.txt_et_km)
        f1.addRow(riga_campi)
        v.addWidget(gb1)

        gb2 = self._gruppo("2) Testo dell'etichetta"); v2 = QVBoxLayout(gb2)
        riga_forma = QHBoxLayout()
        riga_forma.addWidget(QLabel("prima della chilometrica:"))
        self.txt_et_prefisso = QLineEdit("KM ")
        self.txt_et_prefisso.setMaximumWidth(70)
        self.txt_et_prefisso.setToolTip(
            "Se il valore nel campo di origine già inizia con questo prefisso non viene "
            "ripetuto.")
        riga_forma.addWidget(self.txt_et_prefisso)
        riga_forma.addWidget(QLabel("   separatore:"))
        self.cb_et_sep = QComboBox()
        for etichetta, _ in self._SEPARATORI_ET:
            self.cb_et_sep.addItem(etichetta)
        riga_forma.addWidget(self.cb_et_sep)
        riga_forma.addStretch()
        v2.addLayout(riga_forma)

        griglia = QGridLayout()
        griglia.setHorizontalSpacing(8)
        for colonna, titolo in enumerate(("", "dicitura", "campo che la completa",
                                          "chilometrica")):
            capo = QLabel(titolo)
            capo.setStyleSheet("color: palette(mid);")
            griglia.addWidget(capo, 0, colonna)

        griglia.addWidget(QLabel("Armadio:"), 1, 0)
        self.txt_et_dic_armadio = QLineEdit("POSA ARMADIO F.O.")
        griglia.addWidget(self.txt_et_dic_armadio, 1, 1)
        nessuno = QLabel("—"); nessuno.setStyleSheet("color: palette(mid);")
        griglia.addWidget(nessuno, 1, 2)
        self.chk_et_km_armadio = QCheckBox(); self.chk_et_km_armadio.setChecked(True)
        self.chk_et_km_armadio.setToolTip("Includi la chilometrica nell'etichetta dell'armadio.")
        griglia.addWidget(self.chk_et_km_armadio, 1, 3)

        griglia.addWidget(QLabel("Pozzetto:"), 2, 0)
        self.txt_et_dic_poz = QLineEdit("POSA POZZETTO")
        griglia.addWidget(self.txt_et_dic_poz, 2, 1)
        self.cb_et_campo_tipo_poz = QgsFieldComboBox()
        self.cb_et_campo_tipo_poz.setAllowEmptyFieldName(True)
        self.cb_et_campo_tipo_poz.setToolTip("Campo con il tipo/misura del pozzetto.")
        griglia.addWidget(self.cb_et_campo_tipo_poz, 2, 2)
        self.chk_et_km_poz = QCheckBox(); self.chk_et_km_poz.setChecked(True)
        self.chk_et_km_poz.setToolTip("Includi la chilometrica nell'etichetta del pozzetto.")
        griglia.addWidget(self.chk_et_km_poz, 2, 3)

        griglia.addWidget(QLabel("Infrastrutture:"), 3, 0)
        self.txt_et_dic_infra = QLineEdit("SCAVO")
        self.txt_et_dic_infra.setToolTip(
            "Seguita dal valore della tecnica: 'SCAVO' dà 'SCAVO TRADIZIONALE' e "
            "'SCAVO MINI TRINCEA'.")
        griglia.addWidget(self.txt_et_dic_infra, 3, 1)
        self.cb_et_campo_scavo = QgsFieldComboBox()
        self.cb_et_campo_scavo.setAllowEmptyFieldName(True)
        self.cb_et_campo_scavo.setToolTip(
            "Il campo con la TECNICA di scavo (tradizionale, mini trincea, no dig…). "
            "Il plugin lo indovina guardando i valori contenuti, non il nome del campo; "
            "con 'Ispeziona i campi' vedi cosa contiene ciascun campo.")
        griglia.addWidget(self.cb_et_campo_scavo, 3, 2)
        self.chk_et_km_infra = QCheckBox()
        self.chk_et_km_infra.setToolTip(
            "Spenta: sulle tratte l'etichetta riporta solo la lavorazione. La "
            "chilometrica resta comunque scritta nel suo campo dalla scheda "
            "Chilometriche, semplicemente non compare in etichetta.")
        griglia.addWidget(self.chk_et_km_infra, 3, 3)

        griglia.addWidget(QLabel("…se Aerea:"), 4, 0)
        self.txt_et_dic_aerea = QLineEdit("POSA AEREA")
        self.txt_et_dic_aerea.setToolTip(
            f"Usata al posto di 'SCAVO' quando la tecnica vale '{VAL_AEREA}': una tratta "
            "aerea non è uno scavo. Svuota il campo per trattarle come le altre.")
        griglia.addWidget(self.txt_et_dic_aerea, 4, 1)
        v2.addLayout(griglia)

        riga_lungh = QHBoxLayout()
        riga_lungh.addWidget(QLabel("Lunghezza da:"))
        self.cb_et_campo_lungh = QgsFieldComboBox()
        self.cb_et_campo_lungh.setAllowEmptyFieldName(True)
        self.cb_et_campo_lungh.setToolTip(
            f"Se lasciato vuoto, o se il valore manca, ripiega su '{CAMPO_LUNGH_NEW}' e "
            "poi sulla lunghezza geometrica reale della tratta.")
        riga_lungh.addWidget(self.cb_et_campo_lungh)
        riga_lungh.addWidget(QLabel("decimali:"))
        self.spin_et_decimali = self._ispin(0, 3, 0)
        self.spin_et_decimali.setToolTip(
            "0 = metri interi, arrotondati (es. 100 m). Sulle tavole di permesso i "
            "centimetri non servono.")
        riga_lungh.addWidget(self.spin_et_decimali)
        riga_lungh.addWidget(QLabel("unità:"))
        self.txt_et_unita = QLineEdit("m")
        self.txt_et_unita.setMaximumWidth(50)
        riga_lungh.addWidget(self.txt_et_unita)
        riga_lungh.addStretch()
        v2.addLayout(riga_lungh)
        v.addWidget(gb2)

        self.cb_et_poz.layerChanged.connect(self._aggiorna_campi_poz_et)
        self.cb_et_infra.layerChanged.connect(self._aggiorna_campi_infra_et)
        self._aggiorna_campi_poz_et(self.cb_et_poz.currentLayer())
        self._aggiorna_campi_infra_et(self.cb_et_infra.currentLayer())

        gb3 = self._gruppo("3) Quali elementi"); v3 = QVBoxLayout(gb3)
        self.chk_et_solo_selez = QCheckBox(
            "Solo le feature selezionate (se non c'è selezione elabora tutte)")
        self.chk_et_solo_selez.setChecked(True)
        v3.addWidget(self.chk_et_solo_selez)
        self.chk_et_solo_nuovo = QCheckBox(f"Solo gli elementi con {CAMPO_STATO} = '{VAL_NUOVO}'")
        self.chk_et_solo_nuovo.setToolTip(
            "Nei layer di progetto convivono le tratte in progetto e quelle esistenti: "
            "senza questo filtro anche l'esistente riceverebbe un'etichetta di posa.")
        v3.addWidget(self.chk_et_solo_nuovo)
        self.chk_et_sovrascrivi = QCheckBox("Sovrascrivi le etichette già compilate")
        self.chk_et_sovrascrivi.setChecked(True)
        v3.addWidget(self.chk_et_sovrascrivi)
        self.chk_et_senza_km = QCheckBox("Scrivi l'etichetta anche senza chilometrica")
        self.chk_et_senza_km.setToolTip(
            "Per default le feature senza chilometrica vengono saltate e contate nel "
            "log, invece di produrre etichette mutile senza che te ne accorga.")
        v3.addWidget(self.chk_et_senza_km)
        self.chk_et_km_in_fondo = QCheckBox("Chilometrica in fondo all'etichetta")
        self.chk_et_km_in_fondo.setToolTip(
            "Come nelle tavole: prima la lavorazione, per ultima la chilometrica.")
        v3.addWidget(self.chk_et_km_in_fondo)
        self.chk_et_maiuscolo = QCheckBox("Valori degli attributi in MAIUSCOLO")
        self.chk_et_maiuscolo.setToolTip(
            "Riguarda solo i valori letti dai campi (tipo pozzetto, tecnica di scavo), "
            "non le diciture che scrivi tu.")
        v3.addWidget(self.chk_et_maiuscolo)
        v.addWidget(gb3)

        gb4 = self._gruppo("4) Grafica delle etichette in mappa"); v4 = QVBoxLayout(gb4)
        v4.addWidget(self._desc(
            "La leggibilità dipende da cosa c'è sotto: su una CTR il testo nero cade su "
            "un intreccio di linee nere e diventa illeggibile, su ortofoto si perde "
            "sull'asfalto. Il riquadro bianco semitrasparente è la soluzione delle tavole "
            "professionali perché stacca il testo da qualunque sfondo restando discreto, "
            "e l'ombra sottile lo solleva dal disegno senza appesantirlo. L'alone è più "
            "leggero e lascia vedere la mappa, ma su sfondi molto disegnati non basta."
        ))
        self.chk_et_attiva_label = QCheckBox("Mostra le etichette in mappa")
        self.chk_et_attiva_label.setChecked(True)
        v4.addWidget(self.chk_et_attiva_label)
        f4 = QFormLayout()
        riga_f = QHBoxLayout()
        self.cb_et_font = QFontComboBox()
        self.cb_et_font.setCurrentFont(QFont("Arial"))
        riga_f.addWidget(self.cb_et_font, 1)
        self.spin_et_font = self._dspin(4, 40, 9.0, 1, " pt")
        riga_f.addWidget(self.spin_et_font)
        self.chk_et_grassetto = QCheckBox("grassetto")
        riga_f.addWidget(self.chk_et_grassetto)
        f4.addRow("Carattere:", riga_f)
        self.cb_et_leggibilita = QComboBox()
        for _, etichetta in self._SFONDI_ET:
            self.cb_et_leggibilita.addItem(etichetta)
        self.cb_et_leggibilita.setCurrentIndex(3)
        f4.addRow("Leggibilità sullo sfondo:", self.cb_et_leggibilita)
        riga_o = QHBoxLayout()
        self.spin_et_opacita_sfondo = self._ispin(10, 100, 85)
        self.spin_et_opacita_sfondo.setToolTip(
            "Opacità del riquadro bianco: sotto il 70% la CTR traspare e disturba la "
            "lettura, al 100% il riquadro copre del tutto la mappa.")
        riga_o.addWidget(QLabel("opacità riquadro (%):")); riga_o.addWidget(self.spin_et_opacita_sfondo)
        riga_o.addWidget(QLabel("   distanza dall'elemento:"))
        self.spin_et_scostamento = self._dspin(0, 50, 8.0, 1, " mm")
        riga_o.addWidget(self.spin_et_scostamento)
        riga_o.addStretch()
        f4.addRow(riga_o)
        v4.addLayout(f4)
        self.chk_et_richiamo = QCheckBox("Linea di richiamo verso l'elemento")
        self.chk_et_richiamo.setChecked(True)
        v4.addWidget(self.chk_et_richiamo)
        self.chk_et_conserva_label = QCheckBox(
            "Conserva l'etichettatura già presente sul layer (aggiunge una regola)")
        self.chk_et_conserva_label.setToolTip(
            "QGIS ammette una sola etichettatura per layer: assegnandone una nuova, "
            "quella che c'era viene cancellata. Con questa spunta l'etichettatura "
            "esistente viene convertita in regola e conservata, e la nuova si aggiunge "
            "come seconda regola. Le regole si gestiscono poi da Proprietà layer → "
            "Etichette.")
        v4.addWidget(self.chk_et_conserva_label)
        v.addWidget(gb4)

        riga_b = QHBoxLayout()
        bisp = QPushButton("Ispeziona i campi")
        bisp.setToolTip("Elenca i campi dei layer con alcuni valori di esempio: serve a "
                        "capire quale campo contiene davvero la tecnica di scavo.")
        bisp.clicked.connect(self._ispeziona_campi_etichette)
        riga_b.addWidget(bisp)
        bant = QPushButton("Anteprima")
        bant.setToolTip("Mostra le etichette che verrebbero scritte, senza modificare nulla.")
        bant.clicked.connect(self._anteprima_etichette)
        riga_b.addWidget(bant)
        riga_b.addStretch()
        bgen = QPushButton("Crea il campo e scrivi le etichette")
        bgen.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        bgen.clicked.connect(self._genera_etichette)
        riga_b.addWidget(bgen)
        v.addLayout(riga_b)

        self.stato_et = self._etichetta_stato()
        v.addWidget(self.stato_et)
        self.log_et = self._log_widget(140)
        v.addWidget(self._blocco_log(self.log_et))

        v.addStretch(); return w


    # ═══════════════════════════════════════════════ ETICHETTE – LOGICA
    # indizi per riconoscere da solo il campo giusto. Quelli sui VALORI contano
    # più di quelli sul nome: in questo modello dati 'TIPOLOGIA' esiste ma
    # contiene Aerea/Interrata, non la tecnica di scavo, quindi cercare per nome
    # porta sul campo sbagliato — è proprio l'errore da evitare.
    _NOMI_SCAVO = ("scav", "tecnic", "tecnolog", "posa", "modal", "sistem", "metod")
    _VALORI_SCAVO = ("tradizional", "trincea", "no dig", "nodig", "no-dig", "fresat",
                     "spingitub", "perforaz", "trivell", "aratro", "microtrincea",
                     "minitrincea", "mini-trincea", "sottopass", "staffagg", "aereo")
    _NOMI_TIPO_POZZ = ("tipo", "pozz", "dimens", "misur", "modell", "formato")
    _VALORI_TIPO_POZZ = ("x", "cm", "125", "80", "40", "prefabbric", "botola", "chiusin")
    _NOMI_LUNGHEZZA = ("lungh", "length", "metri", "misura", "sviluppo")

    def _campioni_valori(self, lyr, limite=300):
        """{nome_campo: [valori distinti come testo]} su un campione di feature.
        Una sola lettura del layer, riusata sia dall'auto-riconoscimento sia dal
        pulsante 'Ispeziona i campi'."""
        campioni = {c.name(): [] for c in lyr.fields()}
        if not campioni:
            return campioni
        nomi = list(campioni)
        try:
            richiesta = QgsFeatureRequest().setLimit(limite)
        except Exception:
            richiesta = QgsFeatureRequest()
        letti = 0
        for f in lyr.getFeatures(richiesta):
            for i, nome in enumerate(nomi):
                valore = self._valore_testo(f, i)
                if valore and valore not in campioni[nome] and len(campioni[nome]) < 12:
                    campioni[nome].append(valore)
            letti += 1
            if letti >= limite:
                break
        return campioni

    def _campo_piu_probabile(self, lyr, indizi_nome, indizi_valore=(), solo_numerici=False):
        """Nome del campo che più probabilmente contiene il dato cercato, o ''.

        Il punteggio premia soprattutto le corrispondenze sui valori reali
        (3 punti) rispetto a quelle sul nome (1 punto), perché il nome può
        ingannare: 'TIPOLOGIA' sembra il campo della tecnica di scavo ma qui
        contiene Aerea/Interrata."""
        if lyr is None:
            return ""
        campioni = self._campioni_valori(lyr)
        migliore = ""; punteggio_migliore = 0
        for campo in lyr.fields():
            nome = campo.name()
            if solo_numerici and campo.type() not in (QVariant.Double, QVariant.Int,
                                                     QVariant.LongLong):
                continue
            punteggio = 0
            minuscolo = nome.lower()
            if any(indizio in minuscolo for indizio in indizi_nome):
                punteggio += 1
            for valore in campioni.get(nome, []):
                v = valore.lower()
                if any(indizio in v for indizio in indizi_valore):
                    punteggio += 3
                    break
            if punteggio > punteggio_migliore:
                punteggio_migliore = punteggio; migliore = nome
        return migliore

    def _aggiorna_campi_poz_et(self, layer):
        self.cb_et_campo_tipo_poz.setLayer(layer)
        if layer is None:
            return
        scelto = self._campo_piu_probabile(layer, self._NOMI_TIPO_POZZ,
                                           self._VALORI_TIPO_POZZ)
        self.cb_et_campo_tipo_poz.setField(scelto or "")

    def _aggiorna_campi_infra_et(self, layer):
        self.cb_et_campo_scavo.setLayer(layer)
        self.cb_et_campo_lungh.setLayer(layer)
        if layer is None:
            return
        self.cb_et_campo_scavo.setField(
            self._campo_piu_probabile(layer, self._NOMI_SCAVO, self._VALORI_SCAVO) or "")
        lungh = self._campo_piu_probabile(layer, self._NOMI_LUNGHEZZA, solo_numerici=True)
        if not lungh:
            lungh = self._campo_piu_probabile(layer, self._NOMI_LUNGHEZZA)
        self.cb_et_campo_lungh.setField(lungh or "")

    def _ispeziona_campi_etichette(self):
        """Elenca i campi dei layer impostati con qualche valore di esempio.
        Serve esattamente a rispondere alla domanda 'quale campo contiene
        tradizionale / mini trincea?' senza aprire la tabella attributi."""
        ruoli = [("Armadio", self.cb_et_armadio.currentLayer()),
                 ("Pozzetto", self.cb_et_poz.currentLayer()),
                 ("Infrastrutture", self.cb_et_infra.currentLayer())]
        ruoli = [(r, l) for r, l in ruoli if l is not None]
        if not ruoli:
            QMessageBox.warning(self, "Nessun layer", "Imposta almeno un layer."); return
        righe = []
        for ruolo, lyr in ruoli:
            righe.append(f"── {ruolo}: {lyr.name()} ({lyr.featureCount()} feature) ──")
            campioni = self._campioni_valori(lyr)
            for campo in lyr.fields():
                valori = campioni.get(campo.name(), [])
                esempi = ", ".join(valori[:6]) if valori else "(sempre vuoto nel campione)"
                righe.append(f"  {campo.name():<14} [{campo.typeName()}]  {esempi}")
            righe.append("")
        self.log_et.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_et,
                           "Campi elencati con i valori di esempio: scegli sopra quello giusto.")

    def _cfg_etichette(self):
        """Parametri della scheda Etichette, con i tre layer nei rispettivi
        ruoli. Ritorna None (dopo il messaggio) se non c'è nulla da fare."""
        ruoli = [("armadio", self.cb_et_armadio.currentLayer()),
                 ("pozzetto", self.cb_et_poz.currentLayer()),
                 ("infrastrutture", self.cb_et_infra.currentLayer())]
        ruoli = [(r, l) for r, l in ruoli if l is not None]
        if not ruoli:
            QMessageBox.warning(self, "Nessun layer",
                "Imposta almeno uno dei tre layer (Armadio, Pozzetto, Infrastrutture)."); return None
        campo = self.txt_et_campo.text().strip()
        if not campo:
            QMessageBox.warning(self, "Campo mancante",
                "Indica il nome del campo da creare/compilare."); return None
        return {
            "ruoli": ruoli,
            "campo": campo,
            "campo_km": self.txt_et_km.text().strip() or "Chilometrica",
            "prefisso": self.txt_et_prefisso.text(),
            "sep": self._SEPARATORI_ET[max(0, self.cb_et_sep.currentIndex())][1],
            "dic_armadio": self.txt_et_dic_armadio.text().strip(),
            "dic_poz": self.txt_et_dic_poz.text().strip(),
            "campo_tipo_poz": self.cb_et_campo_tipo_poz.currentField(),
            "dic_infra": self.txt_et_dic_infra.text().strip(),
            "dic_aerea": self.txt_et_dic_aerea.text().strip(),
            "campo_tipologia": self.cb_et_campo_scavo.currentField(),
            "campo_lungh": self.cb_et_campo_lungh.currentField(),
            "decimali": self.spin_et_decimali.value(),
            "unita": self.txt_et_unita.text().strip(),
            "maiuscolo": self.chk_et_maiuscolo.isChecked(),
            "km_in_fondo": self.chk_et_km_in_fondo.isChecked(),
            "km_per_ruolo": {"armadio": self.chk_et_km_armadio.isChecked(),
                             "pozzetto": self.chk_et_km_poz.isChecked(),
                             "infrastrutture": self.chk_et_km_infra.isChecked()},
            "conserva_label": self.chk_et_conserva_label.isChecked(),
            "font_dim": self.spin_et_font.value(),
            "font_nome": self.cb_et_font.currentFont().family(),
            "grassetto": self.chk_et_grassetto.isChecked(),
            "scostamento": self.spin_et_scostamento.value(),
            "sfondo": self._SFONDI_ET[max(0, self.cb_et_leggibilita.currentIndex())][0],
            "opacita_sfondo": self.spin_et_opacita_sfondo.value() / 100.0,
            "richiamo": self.chk_et_richiamo.isChecked(),
            "senza_km": self.chk_et_senza_km.isChecked(),
            "sovrascrivi": self.chk_et_sovrascrivi.isChecked(),
        }

    @staticmethod
    def _valore_testo(feat, indice):
        """Attributo come testo pulito, o '' se assente/NULL. Serve perché un
        campo vuoto in uno shapefile può arrivare come None, come QVariant
        nullo o come stringa di soli spazi, e nessuno dei tre va finire
        nell'etichetta."""
        if indice is None or indice < 0:
            return ""
        valore = feat[indice]
        if valore is None:
            return ""
        try:
            if hasattr(valore, "isNull") and valore.isNull():
                return ""
        except Exception:
            pass
        testo = str(valore).strip()
        return "" if testo.upper() in ("NULL", "NONE") else testo

    def _testo_chilometrica(self, feat, lyr, indice, prefisso):
        """Chilometrica formattata per l'etichetta. Un campo numerico (metri)
        viene reso in km+m; un campo di testo è già nella forma '17+100' e si
        usa così com'è. Il prefisso non viene duplicato se il valore lo ha già
        (es. i cippi scritti come 'KM 17+100')."""
        if indice is None or indice < 0:
            return ""
        grezzo = feat[indice]
        if grezzo is None or str(grezzo).strip() == "" or str(grezzo).upper() == "NULL":
            return ""
        if lyr.fields().at(indice).type() in (QVariant.Double, QVariant.Int, QVariant.LongLong):
            try:
                testo = self._format_chilometrica(float(grezzo))
            except (TypeError, ValueError):
                return ""
        else:
            testo = str(grezzo).strip()
        # Non anteporre il prefisso (es. "KM") se il valore lo contiene già al
        # suo interno: la misura "estremi" produce "dal km X al km Y", e un
        # "KM dal km ..." sarebbe ridondante. Il controllo startswith copre solo
        # il prefisso in testa; qui si esclude anche il caso in cui "km" compare
        # dentro il testo (tipico delle chilometriche a intervallo/estremi).
        if prefisso:
            gia_presente = (testo.upper().startswith(prefisso.strip().upper())
                            or "KM" in testo.upper())
            if not gia_presente:
                testo = prefisso + testo
        return testo

    def _lunghezza_vera(self, geom, lyr):
        """Metri veri della geometria, in qualunque CRS stia il layer.

        Due strade, scelte apposta:

        - CRS proiettato (i progetti di permesso: 25832, 32632, 25833): si
          misura sul piano, come fanno il campo LUNGHEZZA, il motore di
          fusione, il CAD e il computo. Misurare qui sull'ellissoide darebbe
          99,7 m su una tratta di 100,0 (fattore di scala UTM): piu' corretto
          in geodesia, ma in disaccordo con ogni altro numero della pratica.

        - CRS geografico (gli export LLD arrivano in WGS84): sul piano
          sarebbero GRADI, quindi li' serve per forza l'ellissoide. Senza
          questo, un'etichetta da 82 m scriveva "0,0 m".
        """
        if geom is None or geom.isEmpty():
            return 0.0
        try:
            crs = lyr.crs()
            if not crs.isGeographic():
                fattore = QgsUnitTypes.fromUnitToUnitFactor(
                    crs.mapUnits(), QgsUnitTypes.DistanceMeters)
                return geom.length() * fattore
            da = QgsDistanceArea()
            da.setSourceCrs(crs, self.project.transformContext())
            # Se il progetto ha le misure ellissoidiche disattivate (ellissoide
            # "NONE", che è il default di molti progetti) setEllipsoid non
            # attiva niente e measureLength torna UNITA' DI CRS: il risultato
            # veniva poi convertito con un fattore piatto, dando 111,3 m dove
            # la distanza vera era 82,3 (misurato). Qui si pretende
            # l'ellissoide e si verifica che sia davvero attivo.
            ell = (self.project.ellipsoid() or "").strip()
            if not ell or ell.upper().startswith("NONE"):
                ell = "WGS84"
            da.setEllipsoid(ell)
            if not da.willUseEllipsoid():
                da.setEllipsoid("WGS84")
            return da.convertLengthMeasurement(da.measureLength(geom),
                                               QgsUnitTypes.DistanceMeters)
        except Exception as e:
            _log_avviso("misura della lunghezza non riuscita", e)
            return 0.0

    def _testo_lunghezza(self, feat, lyr, indici, cfg):
        """Lunghezza della tratta come testo.

        Si usa il campo del modello dati, che è il valore ufficiale, MA solo
        se corrisponde ancora alla linea disegnata: chi sposta un vertice,
        ritaglia o spezza una tratta in QGIS non ricalcola il campo, e
        l'etichetta finiva in istanza con il metraggio di prima. Misurati
        9 casi su 30.844 tratte (fino a 7 m di scarto su una da 24,6).
        Quando i due valori litigano vince la geometria, che è quella che
        l'ente vede disegnata, e lo scarto viene contato per il riepilogo.
        """
        vera = self._lunghezza_vera(feat.geometry(), lyr)
        for chiave in ("lungh", "lungh_alt"):
            i = indici.get(chiave, -1)
            if i is None or i < 0:
                continue
            grezzo = self._valore_testo(feat, i)
            if not grezzo:
                continue
            try:
                valore = float(grezzo.replace(",", "."))
            except ValueError:
                continue
            if valore > 0:
                if vera > 0.5 and abs(valore - vera) > max(0.5, vera * 0.02):
                    self._etic_ricalcolate = getattr(self, "_etic_ricalcolate", [])
                    self._etic_ricalcolate.append((lyr.name(), feat.id(),
                                                   valore, vera))
                    return self._formatta_numero(vera, cfg["decimali"])
                return self._formatta_numero(valore, cfg["decimali"])
        if vera > 0:
            return self._formatta_numero(vera, cfg["decimali"])
        return ""

    @staticmethod
    def _formatta_numero(valore, decimali):
        """Numero con virgola italiana, mezzi arrotondati per eccesso.
        Implementazione e documentazione in ftth_core.formatta_numero
        (testata in tests/test_core.py)."""
        return ftth_core.formatta_numero(valore, decimali)

    def _indici_etichette(self, ruolo, lyr, cfg):
        """Indici dei campi di origine per questo ruolo, risolti in modo
        tollerante (maiuscole e nomi troncati dallo shapefile)."""
        indici = {"km": self._indice_campo(lyr, cfg["campo_km"])}
        if ruolo == "pozzetto":
            indici["tipo"] = self._indice_campo(lyr, cfg["campo_tipo_poz"])
        elif ruolo == "infrastrutture":
            indici["tipologia"] = self._indice_campo(lyr, cfg["campo_tipologia"])
            indici["lungh"] = self._indice_campo(lyr, cfg["campo_lungh"])
            indici["lungh_alt"] = self._indice_campo(lyr, CAMPO_LUNGH_NEW)
        return indici

    def _componi_etichetta(self, ruolo, feat, lyr, cfg, indici):
        """(testo_etichetta, motivo_scarto). Il motivo è valorizzato solo
        quando la feature va saltata."""
        usa_km = cfg.get("km_per_ruolo", {}).get(ruolo, True)
        km = (self._testo_chilometrica(feat, lyr, indici.get("km", -1), cfg["prefisso"])
              if usa_km else "")
        if usa_km and not km and not cfg["senza_km"]:
            return "", "chilometrica assente"

        if ruolo == "armadio":
            coda = cfg["dic_armadio"]
        elif ruolo == "pozzetto":
            tipo = self._valore_testo(feat, indici.get("tipo", -1))
            if cfg.get("maiuscolo"):
                tipo = tipo.upper()
            coda = " ".join(p for p in (cfg["dic_poz"], tipo) if p)
        else:
            tecnica = self._valore_testo(feat, indici.get("tipologia", -1))
            lunghezza = self._testo_lunghezza(feat, lyr, indici, cfg)
            misura = f"{lunghezza} {cfg['unita']}".strip() if lunghezza else ""
            if cfg.get("dic_aerea") and VAL_AEREA.lower() in tecnica.lower():
                # una tratta aerea non è uno scavo: 'SCAVO AEREA' non vuol dire nulla
                coda = " ".join(p for p in (cfg["dic_aerea"], misura) if p)
            else:
                if cfg.get("maiuscolo"):
                    tecnica = tecnica.upper()
                coda = " ".join(p for p in (cfg["dic_infra"], tecnica, misura) if p)

        ordine = (coda, km) if cfg.get("km_in_fondo") else (km, coda)
        parti = [p for p in ordine if p]
        if not parti:
            return "", "nessun dato disponibile per comporre l'etichetta"
        # A-capo LOGICO fra le due parti (KM/posizione su una riga, descrizione
        # sull'altra) invece di un wrap meccanico che spezza dentro le parole
        # ("... trincea 13" / "m"). Se l'utente ha scelto il separatore "a capo"
        # si rispetta; con gli altri separatori le due parti restano comunque su
        # righe distinte, così l'etichetta è compatta e nessun "m" resta orfano.
        sep = cfg["sep"]
        if len(parti) >= 2 and sep != "\n":
            testo = parti[0] + "\n" + sep.join(parti[1:])
        else:
            testo = sep.join(parti)
        return testo, ""

    def _anteprima_etichette(self):
        """Mostra l'etichetta che verrebbe scritta sulla prima feature utile di
        ogni layer, senza modificare nulla: conviene guardarla prima di
        scrivere su tre shape."""
        cfg = self._cfg_etichette()
        if cfg is None:
            return
        righe = []
        for ruolo, lyr in cfg["ruoli"]:
            indici = self._indici_etichette(ruolo, lyr, cfg)
            righe.append(f"── {lyr.name()} ({ruolo}) ──")
            mancanti = ([f"'{cfg['campo_km']}'"]
                        if indici.get("km", -1) < 0
                        and cfg.get("km_per_ruolo", {}).get(ruolo, True) else [])
            if ruolo == "pozzetto" and indici.get("tipo", -1) < 0:
                mancanti.append(f"'{cfg['campo_tipo_poz']}'" if cfg["campo_tipo_poz"]
                                else "tipo di pozzetto non indicato")
            if ruolo == "infrastrutture":
                if indici.get("tipologia", -1) < 0:
                    mancanti.append(f"'{cfg['campo_tipologia']}'" if cfg["campo_tipologia"]
                                    else "tecnica di scavo non indicata")
                if indici.get("lungh", -1) < 0 and indici.get("lungh_alt", -1) < 0:
                    mancanti.append("lunghezza: userò quella geometrica")
            if mancanti:
                righe.append("  campi non usati: " + ", ".join(mancanti))
            feature = self._feature_etichette(lyr)
            if not feature:
                righe.append("  nessuna feature da elaborare."); continue
            mostrate = 0
            for f in feature:
                testo, scarto = self._componi_etichetta(ruolo, f, lyr, cfg, indici)
                righe.append(f"  id {f.id()}: " +
                             (repr(testo) if testo else f"SALTATA ({scarto})"))
                mostrate += 1
                if mostrate >= 3:
                    break
            if len(feature) > mostrate:
                righe.append(f"  … altre {len(feature) - mostrate} feature")
        self.log_et.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_et, "Anteprima: nessun dato è stato modificato.")

    def _feature_etichette(self, lyr):
        selezionate = list(lyr.getSelectedFeatures())
        if selezionate and self.chk_et_solo_selez.isChecked():
            feature = selezionate
        else:
            feature = list(lyr.getFeatures())
        if self.chk_et_solo_nuovo.isChecked():
            i = self._indice_campo(lyr, CAMPO_STATO)
            if i >= 0:
                atteso = VAL_NUOVO.lower()
                feature = [f for f in feature
                           if self._valore_testo(f, i).lower() == atteso]
        return feature

    # descrizione con cui la regola di etichettatura del plugin si riconosce
    # fra le altre: serve a sostituire la propria a ogni lancio senza toccare
    # le regole che l'utente ha configurato a mano
    NOME_REGOLA_ET = "FTTH Etichette permessi"

    # varianti di leggibilità del testo sullo sfondo della tavola
    _SFONDI_ET = (
        ("nessuno", "Solo testo (sfondi chiari e puliti)"),
        ("alone", "Alone bianco (leggero, lascia vedere la mappa)"),
        ("riquadro", "Riquadro bianco semitrasparente (consigliato su CTR)"),
        ("riquadro_ombra", "Riquadro bianco con ombra sottile (tavole professionali)"),
    )

    def _formato_testo_etichette(self, cfg):
        """QgsTextFormat con la resa richiesta.

        Su una CTR il testo nero cade su un intreccio di linee nere: l'alone
        bianco da solo non basta perché il tratteggio continua a leggersi dentro
        le lettere, mentre il riquadro semitrasparente stacca il testo da
        qualunque sfondo restando discreto. L'ombra è tenuta volutamente breve e
        poco opaca: serve a sollevare il riquadro dal disegno, non a fare
        effetto."""
        formato = QgsTextFormat()
        carattere = QFont(cfg.get("font_nome") or "Arial")
        carattere.setBold(bool(cfg.get("grassetto")))
        formato.setFont(carattere)
        formato.setSize(cfg.get("font_dim", 9.0))
        formato.setSizeUnit(QgsUnitTypes.RenderPoints)
        formato.setColor(QColor(0, 0, 0))

        sfondo = cfg.get("sfondo", "riquadro_ombra")
        opacita = cfg.get("opacita_sfondo", 0.85)

        if sfondo == "alone":
            alone = QgsTextBufferSettings()
            alone.setEnabled(True)
            alone.setSize(1.0)
            alone.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            alone.setColor(QColor(255, 255, 255))
            alone.setOpacity(1.0)
            formato.setBuffer(alone)

        try:
            self._aggiungi_riquadro(formato, sfondo, opacita)
        except Exception as e:
            # se una costante è cambiata in questa versione di QGIS si rinuncia
            # al riquadro, ma testo e alone restano validi
            self._nota_grafica = f"riquadro non applicato ({e})"
        return formato

    def _aggiungi_riquadro(self, formato, sfondo, opacita):
        """Riquadro e ombra, isolati dal resto: sono le parti che usano le
        costanti più soggette a cambiare fra le versioni di QGIS."""
        if sfondo in ("riquadro", "riquadro_ombra"):
            # un filo d'alone sotto al riquadro compensa l'antialiasing dei
            # caratteri sul bordo, altrimenti il testo appare sporco in stampa
            alone = QgsTextBufferSettings()
            alone.setEnabled(True)
            alone.setSize(0.4)
            alone.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            alone.setColor(QColor(255, 255, 255))
            formato.setBuffer(alone)

            riquadro = QgsTextBackgroundSettings()
            riquadro.setEnabled(True)
            riquadro.setType(QgsTextBackgroundSettings.ShapeRectangle)
            riquadro.setFillColor(QColor(255, 255, 255))
            riquadro.setStrokeColor(QColor(90, 90, 90))
            riquadro.setStrokeWidth(0.15)
            riquadro.setStrokeWidthUnit(QgsUnitTypes.RenderMillimeters)
            riquadro.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
            riquadro.setSize(QSizeF(1.0, 0.6))
            riquadro.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            riquadro.setRadii(QSizeF(0.4, 0.4))
            riquadro.setRadiiUnit(QgsUnitTypes.RenderMillimeters)
            riquadro.setOpacity(opacita)
            formato.setBackground(riquadro)

        if sfondo == "riquadro_ombra":
            ombra = QgsTextShadowSettings()
            ombra.setEnabled(True)
            # ShadowLowest: l'ombra va sotto la componente più bassa disegnata,
            # cioè sotto il riquadro e non dietro le singole lettere
            ombra.setShadowPlacement(QgsTextShadowSettings.ShadowLowest)
            ombra.setOffsetAngle(135)
            ombra.setOffsetDistance(0.7)
            ombra.setOffsetUnit(QgsUnitTypes.RenderMillimeters)
            ombra.setBlurRadius(0.6)
            ombra.setBlurRadiusUnit(QgsUnitTypes.RenderMillimeters)
            ombra.setColor(QColor(70, 70, 70))
            ombra.setOpacity(0.45)
            formato.setShadow(ombra)

    def _applica_etichettatura(self, lyr, impostazioni, conserva):
        """Applica le impostazioni di etichettatura al layer.

        Con `conserva` l'etichettatura viene aggiunta come REGOLA a quella
        esistente invece di sostituirla: QGIS ammette una sola etichettatura per
        layer, e assegnarne una nuova con setLabeling() cancella quella che c'era
        — è il motivo per cui l'etichetta già attiva su Infrastrutture spariva.
        L'unico modo di averne due contemporaneamente è l'etichettatura basata su
        regole, quindi quella semplice preesistente viene prima convertita in
        regola e conservata. Ritorna il testo da mettere nel log."""
        if not conserva:
            lyr.setLabeling(QgsVectorLayerSimpleLabeling(impostazioni))
            lyr.setLabelsEnabled(True)
            lyr.triggerRepaint()
            return "etichettatura impostata (quella precedente è stata sostituita)"

        from qgis.core import QgsRuleBasedLabeling
        esistente = lyr.labeling()
        conservate = 0
        if isinstance(esistente, QgsRuleBasedLabeling):
            radice = esistente.rootRule().clone()
            conservate = len(radice.children())
        elif esistente is not None:
            radice = None
            try:
                convertita = QgsRuleBasedLabeling.convertFromSimpleLabeling(esistente)
                if convertita is not None:
                    radice = convertita.rootRule().clone()
                    conservate = len(radice.children())
            except Exception:
                radice = None
            if radice is None:
                # ripiego: ricostruisco a mano la regola dall'etichettatura semplice
                radice = QgsRuleBasedLabeling.Rule(None)
                try:
                    precedenti = QgsPalLayerSettings(esistente.settings())
                    regola_vecchia = QgsRuleBasedLabeling.Rule(precedenti)
                    regola_vecchia.setDescription("etichettatura preesistente")
                    radice.appendChild(regola_vecchia)
                    conservate = 1
                except Exception:
                    conservate = 0
        else:
            radice = QgsRuleBasedLabeling.Rule(None)

        # via la nostra regola del lancio precedente, per non accumularne una
        # a ogni compilazione
        figli = list(radice.children())
        for indice in range(len(figli) - 1, -1, -1):
            if figli[indice].description() == self.NOME_REGOLA_ET:
                radice.removeChildAt(indice)
                conservate -= 1
        regola = QgsRuleBasedLabeling.Rule(impostazioni)
        regola.setDescription(self.NOME_REGOLA_ET)
        radice.appendChild(regola)

        lyr.setLabeling(QgsRuleBasedLabeling(radice))
        lyr.setLabelsEnabled(True)
        lyr.triggerRepaint()
        if conservate > 0:
            return (f"etichettatura aggiunta come regola '{self.NOME_REGOLA_ET}', "
                    f"conservate le {conservate} regole già presenti")
        return f"etichettatura aggiunta come regola '{self.NOME_REGOLA_ET}'"

    def _attiva_etichettatura(self, lyr, campo, cfg):
        """Imposta l'etichettatura QGIS del layer sul campo compilato, con la
        grafica delle tavole: testo nero multiriga allineato a sinistra,
        scostato dall'elemento e collegato da una linea di richiamo.

        Le costanti di posizionamento e allineamento sono state spostate di
        modulo fra le versioni di QGIS, quindi vengono cercate a runtime con
        dei ripieghi: se una non esiste si rinuncia a quel dettaglio invece di
        far fallire tutta l'operazione."""
        def costante(*percorsi):
            for percorso in percorsi:
                oggetto = QgsPalLayerSettings
                for pezzo in percorso.split("."):
                    oggetto = getattr(oggetto, pezzo, None)
                    if oggetto is None:
                        break
                if oggetto is not None:
                    return oggetto
            return None

        try:
            impostazioni = QgsPalLayerSettings()
            impostazioni.fieldName = campo
            impostazioni.enabled = True
            impostazioni.isExpression = False

            impostazioni.setFormat(self._formato_testo_etichette(cfg))

            allineamento = costante("MultiLineLeft", "MultiLineAlign.MultiLineLeft")
            if allineamento is not None:
                impostazioni.multilineAlign = allineamento

            # NIENTE wrap meccanico (autoWrapLength): spezzava dentro le parole
            # lasciando "m" orfano su una riga. L'a-capo è già gestito in modo
            # logico da _componi_etichetta (riga 1 = KM/posizione, riga 2 =
            # descrizione), quindi qui si disattiva il wrap automatico.
            try:
                impostazioni.autoWrapLength = 0
            except Exception:
                pass

            # Orientamento delle etichette:
            #  - PUNTI: attorno al punto (come sempre).
            #  - LINEE: NON più parallelo (che ruota il testo come la tratta e,
            #    sulle tratte ortogonali corte, esce verticale e illeggibile).
            #    Si usa il posizionamento ORIZZONTALE attorno al centro della
            #    tratta, che cerca la posizione libera migliore (sopra/sotto/
            #    lato) e collega con la linea di richiamo: le etichette escono
            #    diritte e già distanziate, senza doverle raddrizzare a mano.
            if lyr.geometryType() == QgsWkbTypes.PointGeometry:
                piazzamento = costante("AroundPoint", "Placement.AroundPoint")
                scostamento_default = 8.0
            else:
                piazzamento = costante(
                    "OrderedPositionsAroundPoint",
                    "Placement.OrderedPositionsAroundPoint",
                    "AroundPoint", "Placement.AroundPoint")
                scostamento_default = 12.0
            if piazzamento is not None:
                impostazioni.placement = piazzamento
            # ordine di preferenza delle posizioni: prima sopra, poi ai lati,
            # poi sotto — così restano vicine alla tratta ma non sopra di essa
            try:
                impostazioni.predefinedPositionOrder = [
                    QgsPalLayerSettings.TopMiddle, QgsPalLayerSettings.TopRight,
                    QgsPalLayerSettings.TopLeft, QgsPalLayerSettings.MiddleRight,
                    QgsPalLayerSettings.MiddleLeft, QgsPalLayerSettings.BottomMiddle,
                    QgsPalLayerSettings.BottomRight, QgsPalLayerSettings.BottomLeft]
            except Exception:
                pass
            impostazioni.dist = cfg.get("scostamento", scostamento_default)
            impostazioni.distUnits = QgsUnitTypes.RenderMillimeters
            # le etichette dei permessi devono uscire tutte, anche se si
            # sovrappongono: meglio spostarle a mano che non vederle
            impostazioni.obstacle = False
            impostazioni.priority = 10

            # Consenti il posizionamento anche quando l'etichetta è più lunga
            # dell'elemento: una tratta di scavo ORTOGONALE (attraversamento) è
            # corta pochi metri e col placement parallelo QGIS non trova spazio
            # per il testo → nessun candidato → etichetta invisibile. Con
            # allowDegradedPlacement l'etichetta viene comunque disegnata.
            # L'API è cambiata fra le versioni: prima si prova quella nuova
            # (placementSettings), poi il flag diretto, senza far fallire tutto.
            try:
                ps = impostazioni.placementSettings()
                ps.setAllowDegradedPlacement(True)
                if hasattr(ps, "setOverlapHandling"):
                    from qgis.core import Qgis
                    modo = getattr(Qgis.LabelOverlapHandling, "AllowOverlapIfRequired", None)
                    if modo is not None:
                        ps.setOverlapHandling(modo)
                impostazioni.setPlacementSettings(ps)
            except Exception:
                try:
                    impostazioni.allowDegradedPlacement = True
                except Exception:
                    pass

            if cfg.get("richiamo", True):
                try:
                    from qgis.core import QgsSimpleLineCallout
                    richiamo = QgsSimpleLineCallout()
                    richiamo.setEnabled(True)
                    linea = QgsLineSymbol.createSimple(
                        {"color": "60,60,60,255", "width": "0.2"})
                    richiamo.setLineSymbol(linea)
                    if hasattr(richiamo, "setMinimumLength"):
                        richiamo.setMinimumLength(2.0)
                        richiamo.setMinimumLengthUnit(QgsUnitTypes.RenderMillimeters)
                    impostazioni.setCallout(richiamo)
                except Exception as e:
                    self.log_et.appendPlainText(
                        f"    linea di richiamo non disponibile in questa versione di QGIS ({e})")

            # Rende le etichette SPOSTABILI a mano in QGIS: senza le proprietà
            # data-defined di posizione (X/Y), lo strumento "Sposta etichetta"
            # non aggancia le feature e alcune etichette risultano bloccate.
            # Qui si assicurano due colonne sul layer e si collegano a
            # PositionX/PositionY, così ogni etichetta è trascinabile.
            self._abilita_spostamento_etichette(lyr, impostazioni)

            esito = self._applica_etichettatura(lyr, impostazioni,
                                                cfg.get("conserva_label", False))
            if self._nota_grafica:
                esito += f" — {self._nota_grafica}"
                self._nota_grafica = ""
            return esito
        except Exception as e:
            self.log_et.appendPlainText(f"  etichettatura non attivata: {e}")
            return ""

    def _abilita_spostamento_etichette(self, lyr, impostazioni):
        """Collega le proprietà data-defined di posizione (X/Y) a due colonne
        del layer, così in QGIS lo strumento 'Sposta etichetta' può trascinare
        OGNI etichetta e salvare la posizione scelta.

        Senza queste proprietà QGIS lascia il posizionamento all'automatismo e
        le etichette non sono spostabili a mano — il motivo per cui 'alcune non
        si spostano'. Le colonne (LBLX/LBLY, Double) vengono create se mancano;
        il loro contenuto resta vuoto finché non si sposta un'etichetta, quindi
        non altera il posizionamento automatico di partenza."""
        try:
            from qgis.core import QgsPalLayerSettings, QgsProperty
        except Exception:
            return
        # nomi corti (<=10 char) per non essere troncati dallo shapefile
        campi = {"LBLX": None, "LBLY": None, "LBLR": None}
        dp = lyr.dataProvider()
        from qgis.core import QgsField
        from qgis.PyQt.QtCore import QVariant
        da_creare = []
        for nome in campi:
            if self._indice_campo(lyr, nome) < 0:
                da_creare.append(QgsField(nome, QVariant.Double, len=20, prec=6))
        if da_creare:
            try:
                dp.addAttributes(da_creare)
                lyr.updateFields()
            except Exception as e:
                self.log_et.appendPlainText(
                    f"    posizione manuale non attivabile (campi non creati: {e})")
                return
        # risolve i nomi reali (lo shapefile può adattarli) e collega le property
        nx = lyr.fields().at(self._indice_campo(lyr, "LBLX")).name() if self._indice_campo(lyr, "LBLX") >= 0 else None
        ny = lyr.fields().at(self._indice_campo(lyr, "LBLY")).name() if self._indice_campo(lyr, "LBLY") >= 0 else None
        nr = lyr.fields().at(self._indice_campo(lyr, "LBLR")).name() if self._indice_campo(lyr, "LBLR") >= 0 else None
        if not (nx and ny):
            return
        try:
            dd = impostazioni.dataDefinedProperties()
            P = QgsPalLayerSettings.Property
            dd.setProperty(P.PositionX, QgsProperty.fromField(nx))
            dd.setProperty(P.PositionY, QgsProperty.fromField(ny))
            if nr:
                dd.setProperty(P.LabelRotation, QgsProperty.fromField(nr))
            impostazioni.setDataDefinedProperties(dd)
        except Exception as e:
            self.log_et.appendPlainText(
                f"    posizione manuale non collegata ({e})")

    def _genera_etichette(self):
        cfg = self._cfg_etichette()
        if cfg is None:
            return

        righe = []; totale_scritte = 0; totale_saltate = 0
        for ruolo, lyr in cfg["ruoli"]:
            righe.append(f"── {lyr.name()} ({ruolo}) ──")
            idx_out, nome_out, esito = self._assicura_campo(
                lyr, cfg["campo"], tipo_testo=True, lunghezza=254)
            if esito.startswith("fallito"):
                righe.append(f"  campo '{cfg['campo']}': {esito[8:].strip()}. Layer saltato.")
                continue
            righe.append(f"  campo '{nome_out}': {esito}"
                         + (" (nome adattato dal formato del file)"
                            if nome_out != cfg["campo"] else ""))

            indici = self._indici_etichette(ruolo, lyr, cfg)
            if indici.get("km", -1) < 0 and cfg.get("km_per_ruolo", {}).get(ruolo, True):
                righe.append(f"  ATTENZIONE: campo chilometrica '{cfg['campo_km']}' non "
                             f"trovato su questo layer: calcolalo nella scheda "
                             f"Chilometriche, oppure togli la spunta 'chilometrica' per "
                             f"questo layer. Layer saltato.")
                continue

            feature = self._feature_etichette(lyr)
            if not feature:
                righe.append("  nessuna feature da elaborare."); continue
            if not self._start_edit(lyr):
                righe.append("  impossibile avviare la modifica: layer saltato."); continue

            scritte = 0; saltate = 0; motivi = {}
            for f in feature:
                if not cfg["sovrascrivi"] and self._valore_testo(f, idx_out):
                    saltate += 1
                    motivi["etichetta già presente"] = motivi.get("etichetta già presente", 0) + 1
                    continue
                testo, scarto = self._componi_etichetta(ruolo, f, lyr, cfg, indici)
                if not testo:
                    saltate += 1
                    motivi[scarto] = motivi.get(scarto, 0) + 1
                    continue
                testo = self._testo_scrivibile(lyr, testo)
                if lyr.changeAttributeValue(f.id(), idx_out, testo):
                    scritte += 1
                else:
                    saltate += 1
                    motivi["scrittura rifiutata dal provider"] = \
                        motivi.get("scrittura rifiutata dal provider", 0) + 1

            if self._commit(lyr, f"Salvataggio etichette su {lyr.name()}"):
                totale_scritte += scritte; totale_saltate += saltate
                righe.append(f"  {scritte} etichette scritte, {saltate} saltate "
                             f"su {len(feature)} feature.")
                for motivo, quante in motivi.items():
                    righe.append(f"    – {quante} × {motivo}")
                esempio = next((f for f in feature), None)
                if esempio is not None and scritte:
                    testo, _ = self._componi_etichetta(ruolo, esempio, lyr, cfg, indici)
                    if testo:
                        righe.append(f"    esempio: {testo!r}")
                if self.chk_et_attiva_label.isChecked():
                    esito_label = self._attiva_etichettatura(lyr, nome_out, cfg)
                    if esito_label:
                        righe.append(f"    {esito_label}, campo '{nome_out}'.")
                    # Salva lo stile (con l'etichettatura appena applicata) in
                    # 01_File shp/Stili/<nome layer>.qml e lo collega come
                    # predefinito, così alla riapertura il layer è già stilizzato.
                    esito_stile = self._salva_e_collega_stile(lyr, lyr.name())
                    if esito_stile:
                        righe.append(f"    {esito_stile}.")
            else:
                righe.append("  SALVATAGGIO ANNULLATO (rollback): nessuna etichetta scritta.")

        intestazione = (f"{totale_scritte} etichette scritte, {totale_saltate} saltate "
                        f"su {len(cfg['ruoli'])} layer.")

        # Le tratte il cui campo LUNGHEZZA non corrispondeva piu' alla linea
        # disegnata: l'etichetta riporta la misura vera, ma il dato nel campo
        # resta sbagliato e finira' negli altri documenti (computi, export).
        # Va detto adesso, non scoperto dall'ente.
        ricalcolate = getattr(self, "_etic_ricalcolate", [])
        if ricalcolate:
            righe.append("")
            righe.append("ATTENZIONE: %d tratte hanno il campo lunghezza diverso "
                         "dalla geometria. L'etichetta riporta la misura vera "
                         "della linea; il campo nei dati resta da correggere:"
                         % len(ricalcolate))
            for nome_lyr, fid, campo, vera in sorted(
                    ricalcolate, key=lambda x: -abs(x[2] - x[3]))[:15]:
                righe.append("    %s fid %s: campo %s m -> misurati %s m "
                             "(scarto %s m)"
                             % (nome_lyr, fid,
                                self._formatta_numero(campo, 2),
                                self._formatta_numero(vera, 2),
                                self._formatta_numero(abs(campo - vera), 2)))
            if len(ricalcolate) > 15:
                righe.append("    … e altre %d." % (len(ricalcolate) - 15))
            intestazione += (" ATTENZIONE: %d lunghezze non corrispondono al "
                             "disegno (dettaglio sotto)." % len(ricalcolate))
        self._etic_ricalcolate = []

        self.log_et.setPlainText(intestazione + "\n\n" + "\n".join(righe))
        self._mostra_stato(self.stato_et, intestazione, ok=totale_scritte > 0)

    # ═════════════════════════════════ EVIDENZA STRADE INTERESSATE
    NOME_LAYER_EVIDENZA = "Strade interessate (evidenza)"

    def _gruppo_evidenza_strade(self, ctx):
        """Gruppo di controlli per l'evidenza delle strade toccate dal progetto.

        Diviso in due sezioni perché era diventato un elenco di tredici controlli
        in fila, in fondo alla quarta sezione di una scheda lunga: le opzioni che
        riguardano la resa in stampa — colore, retino, nome della strada — stanno
        ora insieme, dove chi le cerca va a guardare.

        Riceve `ctx` perché la scheda Esportazione esiste in due copie (Comune e
        Altri Enti) e ogni copia deve avere i propri widget."""
        gb = self._gruppo("Evidenza delle strade interessate")
        v = QVBoxLayout(gb)
        v.addWidget(self._desc(
            "Copre con un retino le sole tratte dello stradario (ANAS, provinciale, "
            "comunale) su cui ricadono Infrastrutture, Pozzetto o Armadio Ottico, così "
            "in stampa si vede subito di quale strada si sta chiedendo il permesso. Il "
            "retino va sulla STRADA, non sugli elementi di progetto: quelli servono solo "
            "a stabilire quali tratte sono interessate, e sono i tre layer impostati in "
            "cima alla scheda. Il layer prodotto si chiama sempre allo stesso modo e "
            "viene rigenerato a ogni lancio, quindi non se ne accumulano copie, e viene "
            "messo in fondo all'elenco dei livelli per non coprire il progetto."
        ))

        # ── quali strade ──
        v.addWidget(self._intestazione("Quali strade"))
        f1 = QFormLayout()
        self.cb_ev_stradario = self._lcombo(
            QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer)
        self.cb_ev_stradario.setToolTip(
            "Il layer delle STRADE da coprire con il retino: stradario ANAS, provinciale "
            "o comunale. Non è un layer di progetto — se qui metti Infrastrutture il "
            "retino finisce sugli scavi invece che sulla strada, e il plugin te lo "
            "impedisce.")
        f1.addRow("Stradario da evidenziare:", self.cb_ev_stradario)
        self.spin_ev_tolleranza = self._dspin(0, 100, 8.0, 1, " m")
        self.spin_ev_tolleranza.setToolTip(
            "Quanto può distare un elemento dall'asse dello stradario perché quel punto "
            "sia considerato interessato. È il parametro che più spesso causa buchi nel "
            "retino: gli scavi corrono a bordo strada mentre lo stradario è l'asse, "
            "quindi su una carreggiata di 8-10 m il bordo dista 4-5 m dall'asse e con "
            "una tolleranza di 2 m quei tratti verrebbero scartati. Il log elenca gli "
            "elementi rimasti fuori e la loro distanza reale.")
        f1.addRow("Distanza max elemento → tratta:", self.spin_ev_tolleranza)
        riga_v = QHBoxLayout()
        riga_v.addWidget(QLabel("colma i vuoti fino a:"))
        self.spin_ev_vuoto = self._dspin(0, 5000, 60.0, 0, " m")
        self.spin_ev_vuoto.setToolTip(
            "Due tratti evidenziati separati da meno di questa distanza vengono uniti in "
            "uno solo. È il parametro che dà continuità al retino: senza, ogni scavo "
            "produce la sua fascetta e fra due scavi consecutivi resta un buco. Alzalo "
            "se il retino risulta ancora interrotto; abbassalo se collega tratti di "
            "strada che con i lavori non hanno nulla a che vedere.")
        riga_v.addWidget(self.spin_ev_vuoto)
        riga_v.addWidget(QLabel("   estendi oltre i lavori:"))
        self.spin_ev_margine = self._dspin(0, 200, 10.0, 1, " m")
        riga_v.addWidget(self.spin_ev_margine)
        riga_v.addStretch()
        f1.addRow("Continuità:", riga_v)
        v.addLayout(f1)

        self.chk_ev_solo_selez = QCheckBox(
            "Considera solo le feature selezionate dei layer di progetto")
        v.addWidget(self.chk_ev_solo_selez)
        self.chk_ev_solo_nuovo = QCheckBox(f"Solo gli elementi con {CAMPO_STATO} = '{VAL_NUOVO}'")
        v.addWidget(self.chk_ev_solo_nuovo)
        self.chk_ev_salda = QCheckBox(
            "Salda le fasce che si sfiorano (chiude i vuoti agli incroci)")
        self.chk_ev_salda.setChecked(True)
        self.chk_ev_salda.setToolTip(
            "Agli incroci due strade sono due corridoi distinti e fra le rispettive "
            "fasce resta una fessura. Questa opzione la chiude dilatando e ricontraendo "
            "il retino, con un raggio limitato a metà larghezza per non fondere strade "
            "parallele vicine.")
        v.addWidget(self.chk_ev_salda)
        self.chk_ev_intere = QCheckBox(
            "Copri le tratte intere dello stradario, non solo il tratto dei lavori")
        self.chk_ev_intere.setChecked(True)
        self.chk_ev_intere.setToolTip(
            "Con questa spunta ogni tratta toccata viene evidenziata per tutta la sua "
            "lunghezza, anche se gli scavi ne interessano pochi metri.")
        v.addWidget(self.chk_ev_intere)

        # ── aspetto in stampa ──
        v.addWidget(self._intestazione("Aspetto in stampa"))
        f2 = QFormLayout()
        riga_c = QHBoxLayout()
        self.btn_ev_colore = self._bottone_colore(QColor(255, 200, 0))
        riga_c.addWidget(self.btn_ev_colore)
        self.cb_ev_stile = QComboBox()
        for _, etichetta in self._STILI_EVIDENZA:
            self.cb_ev_stile.addItem(etichetta)
        chiavi_stile = [c for c, _ in self._STILI_EVIDENZA]
        self.cb_ev_stile.setCurrentIndex(chiavi_stile.index(self.STILE_EVIDENZA_DEFAULT))
        riga_c.addWidget(self.cb_ev_stile, 1)
        f2.addRow("Colore e stile:", riga_c)
        riga_l = QHBoxLayout()
        self.spin_ev_larghezza = self._dspin(0.5, 200, 8.0, 1, " m")
        self.spin_ev_larghezza.setToolTip(
            "Larghezza totale della fascia, in metri reali: si adatta alla scala della "
            "tavola perché è misurata a terra, non sul foglio.")
        riga_l.addWidget(self.spin_ev_larghezza)
        riga_l.addWidget(QLabel("   opacità:"))
        self.spin_ev_opacita = self._ispin(5, 100, 80)
        riga_l.addWidget(self.spin_ev_opacita)
        riga_l.addWidget(QLabel("%"))
        riga_l.addStretch()
        f2.addRow("Larghezza della fascia:", riga_l)
        riga_ret = QHBoxLayout()
        riga_ret.addWidget(QLabel("passo:"))
        self.spin_ev_passo = self._dspin(0.3, 20, 2.5, 1, " mm")
        self.spin_ev_passo.setToolTip(
            "Distanza fra le linee del retino, misurata sul foglio: resta uguale in "
            "stampa a qualunque scala.")
        riga_ret.addWidget(self.spin_ev_passo)
        riga_ret.addWidget(QLabel("spessore:"))
        self.spin_ev_spessore = self._dspin(0.05, 3, 0.4, 2, " mm")
        riga_ret.addWidget(self.spin_ev_spessore)
        riga_ret.addWidget(QLabel("angolo:"))
        self.spin_ev_angolo = self._ispin(0, 179, 45)
        riga_ret.addWidget(self.spin_ev_angolo)
        riga_ret.addStretch()
        f2.addRow("Retino:", riga_ret)
        riga_n = QHBoxLayout()
        self.chk_ev_etichetta = QCheckBox("Scrivi il nome della strada")
        self.chk_ev_etichetta.setChecked(True)
        self.chk_ev_etichetta.setToolTip(
            "Una sola scritta per strada, in grassetto con alone bianco, ruotata per "
            "seguire la fascia. Il nome è preso dal campo dello stradario riconosciuto "
            "come denominazione.")
        riga_n.addWidget(self.chk_ev_etichetta)
        riga_n.addWidget(QLabel("corpo:"))
        self.spin_ev_corpo_nome = self._dspin(4, 60, 16.0, 1, " pt")
        riga_n.addWidget(self.spin_ev_corpo_nome)
        riga_n.addStretch()
        f2.addRow("Nome della strada:", riga_n)
        v.addLayout(f2)
        self.chk_ev_spegni_stradario = QCheckBox(
            "Spegni le etichette dello stradario (le sigle minute ripetute)")
        self.chk_ev_spegni_stradario.setToolTip(
            "Le sigle ripetute lungo la strada vengono dall'etichettatura del layer "
            "stradario, non dall'evidenza. Questa spunta le disattiva; si riattivano "
            "da Proprietà layer → Etichette.")
        v.addWidget(self.chk_ev_spegni_stradario)

        btn = QPushButton("Evidenzia le strade interessate")
        btn.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        self._collega_consegna(btn, self._evidenzia_strade, ctx)
        v.addWidget(btn)
        self.log_ev = self._log_widget(110)
        v.addWidget(self._blocco_log(self.log_ev))
        return gb

    def _geometrie_progetto_evidenza(self):
        """Geometrie (nel CRS di progetto) dei layer di progetto da cui ricavare
        le strade interessate, con il conteggio per layer."""
        geometrie = []; conteggio = {}
        for combo in (self.cb_c_infra, self.cb_c_poz, self.cb_c_armadio):
            lyr = combo.currentLayer()
            if lyr is None:
                continue
            selezionate = list(lyr.getSelectedFeatures())
            if selezionate and self.chk_ev_solo_selez.isChecked():
                feature = selezionate
            else:
                feature = list(lyr.getFeatures())
            if self.chk_ev_solo_nuovo.isChecked():
                i = self._indice_campo(lyr, CAMPO_STATO)
                if i >= 0:
                    atteso = VAL_NUOVO.lower()
                    feature = [f for f in feature
                               if self._valore_testo(f, i).lower() == atteso]
            quante = 0
            for f in feature:
                g = self._to_proj(f.geometry(), lyr)
                if g and not g.isEmpty():
                    geometrie.append(g); quante += 1
            conteggio[lyr.name()] = quante
        return geometrie, conteggio

    def _cartella_stili_progetto(self):
        """Cartella '01_File shp/Stili' accanto al progetto, dove salvare i .qml
        di Strade Evidenziate e INFRASTRUTTURE. Ritorna None se il progetto non
        è ancora salvato (senza cartella non c'è dove scrivere)."""
        import os
        prog_path = self.project.fileName()
        if not prog_path:
            return None
        cartella = os.path.join(os.path.dirname(prog_path), "01_File shp", "Stili")
        try:
            os.makedirs(cartella, exist_ok=True)
        except Exception:
            return None
        return cartella

    def _rendi_stile_portatile(self, lyr, stile_path=None):
        """Incorpora gli SVG dello stile dentro lo stile stesso.

        Senza questo passaggio lo stile dei pozzetti cita gli SVG con il
        percorso della cartella di chi l'ha creato: sul PC di un collega
        quel percorso non esiste e il simbolo sparisce (misurato: 100 pixel
        disegnati invece di 212). Incorporandoli, lo stile si porta dietro
        il disegno e si vede su qualunque macchina, anche dentro il
        GeoPackage che gli passi.

        Non e' una opzione da spuntare: e' sempre attivo, perche' uno stile
        che si vede solo sul PC di chi l'ha fatto e' uno stile rotto.
        """
        try:
            from . import ftth_stili
        except (ImportError, ValueError):
            import ftth_stili
        cartelle = []
        try:
            if stile_path:
                cartelle.append(os.path.dirname(os.path.abspath(stile_path)))
            pf = self.project.fileName()
            if pf:
                cartelle.append(os.path.dirname(pf))
        except Exception:
            pass
        # Catalogo dei simboli vicini allo stile. Serve al caso piu' comune:
        # il collega ha la cartella dei simboli sul proprio PC, ma il .qml e'
        # una copia e cita i percorsi della macchina d'origine. I disegni
        # sono a due passi dal .qml e si ritrovano per nome. Un nome viene
        # accettato solo se tutte le copie hanno contenuto identico.
        catalogo = None
        try:
            catalogo, _scartati = ftth_stili.catalogo_per_stile(cartelle)
        except Exception as e:
            _log_avviso("catalogo dei simboli non costruito", e)
        try:
            esito = ftth_stili.rendi_layer_portatile(lyr, cartelle, catalogo)
        except Exception as e:
            _log_avviso("incorporamento SVG nello stile non riuscito", e)
            return None
        if esito.get("incorporati"):
            try:
                from qgis.core import Qgis, QgsMessageLog
                QgsMessageLog.logMessage(
                    "stile di '%s': incorporati %d simboli SVG (%s)"
                    % (lyr.name(), len(esito["incorporati"]),
                       ", ".join(sorted(set(esito["incorporati"]))[:4])),
                    "FTTH Permessi", level=Qgis.Info)
            except Exception:
                pass
        if esito.get("mancanti"):
            # va detto: questi simboli sono gia' invisibili su questa macchina
            _log_avviso("stile di '%s': %d simboli SVG non trovati, restano "
                        "collegati e potrebbero non vedersi: %s"
                        % (lyr.name(), len(esito["mancanti"]),
                           ", ".join(os.path.basename(m) for m in esito["mancanti"][:3])),
                        None)
        return esito

    def _salva_e_collega_stile(self, lyr, nome_stile):
        """Esporta lo stile del layer come .qml in '01_File shp/Stili/' col nome
        indicato E lo imposta come stile predefinito del layer.

        - Il .qml è un backup leggibile/riusabile dello stile applicato.
        - Il collegamento come predefinito: per uno shapefile scrive il .qml
          gemello del file dati (QGIS lo ricarica in automatico all'apertura);
          per un GeoPackage salva lo stile DENTRO il .gpkg (tabella
          layer_styles). Così alla riapertura il layer si ripresenta già
          stilizzato senza dover rilanciare il plugin.
        Ritorna un breve testo per il log; non solleva se qualcosa non è
        disponibile (versioni QGIS diverse)."""
        import os
        cartella = self._cartella_stili_progetto()
        if cartella is None:
            return "stile non esportato (progetto non salvato)"
        qml = os.path.join(cartella, nome_stile + ".qml")
        esiti = []
        # 1) esporta il .qml nella cartella Stili
        try:
            msg, ok = lyr.saveNamedStyle(qml)
            if os.path.exists(qml):
                esiti.append(f"stile esportato in Stili/{nome_stile}.qml")
            else:
                esiti.append(f"esportazione .qml non riuscita ({msg})")
        except Exception as e:
            esiti.append(f"esportazione .qml non riuscita ({e})")
        # 2) collega come stile predefinito del layer
        try:
            src = lyr.dataProvider().dataSourceUri() if lyr.dataProvider() else ""
            if "|layername=" in src or src.lower().endswith(".gpkg"):
                # GeoPackage: salva lo stile nel file (default alla riapertura)
                self._rendi_stile_portatile(lyr)
                lyr.saveStyleToDatabase(lyr.name(), "Stile FTTH", True, "")
                esiti.append("impostato come stile predefinito nel GeoPackage")
            else:
                # shapefile/altro: .qml gemello del file dati = default all'apertura
                percorso_dati = src.split("|")[0]
                if percorso_dati:
                    gemello = os.path.splitext(percorso_dati)[0] + ".qml"
                    lyr.saveNamedStyle(gemello)
                    esiti.append("impostato come stile predefinito (.qml gemello)")
        except Exception as e:
            esiti.append(f"stile predefinito non collegato ({e})")
        return "; ".join(esiti)

    def _percorso_gpkg_evidenza(self):
        """Percorso fisso del GeoPackage dell'evidenza: sottocartella
        '01_File shp' accanto al progetto .qgz aperto. Ritorna None se il
        progetto non è ancora stato salvato (senza cartella non c'è dove
        scrivere un file persistente)."""
        import os
        prog_path = self.project.fileName()
        if not prog_path:
            return None
        cartella = os.path.join(os.path.dirname(prog_path), "01_File shp")
        try:
            os.makedirs(cartella, exist_ok=True)
        except Exception:
            cartella = os.path.dirname(prog_path)
        return os.path.join(cartella, "Strade Evidenziate.gpkg")

    def _layer_evidenza_persistente(self, campi, crs_obj, feature):
        """Scrive le feature dell'evidenza in un GeoPackage a percorso fisso e
        restituisce il layer, riusando quello già presente nel progetto quando
        esiste (così il layout con i livelli bloccati continua a vederlo).

        - Se il progetto non è salvato, ripiega su un layer in memoria (com'era
          prima): senza cartella non c'è un file persistente possibile.
        - Se il layer 'Strade interessate (evidenza)' è già nel progetto e punta
          al GeoPackage giusto, ne svuota le feature e riscrive le nuove: stessa
          identità di layer, il layout non perde il riferimento.
        - Altrimenti (ri)crea il GeoPackage e aggiunge il layer una volta."""
        from qgis.core import (QgsVectorFileWriter, QgsCoordinateTransformContext,
                               QgsVectorLayer)
        gpkg = self._percorso_gpkg_evidenza()

        # ripiego: progetto non salvato → memory come prima
        if gpkg is None:
            crs = crs_obj.authid() or crs_obj.toWkt()
            lyr = QgsVectorLayer(
                f"Polygon?crs={crs}&field=Strada:string(120)&field=Lunghezza:double(12,1)",
                self.NOME_LAYER_EVIDENZA, "memory")
            lyr.dataProvider().addFeatures(feature)
            lyr.updateExtents()
            self.project.addMapLayer(lyr, False)
            self.project.layerTreeRoot().addLayer(lyr)
            return lyr

        # 1) layer già nel progetto che punta a questo GeoPackage → riscrivo dentro
        esistente = None
        for l in self.project.mapLayers().values():
            if l.name() != self.NOME_LAYER_EVIDENZA:
                continue
            try:
                if l.dataProvider() and l.dataProvider().dataSourceUri().split("|")[0] == gpkg:
                    esistente = l
                    break
            except Exception:
                pass

        # 2) scrivo/riscrivo il GeoPackage su disco (sovrascrive il layer omonimo)
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = "GPKG"
        opts.layerName = "Strade Evidenziate"
        opts.fileEncoding = "UTF-8"
        import os
        if os.path.exists(gpkg):
            opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteLayer
        else:
            opts.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        writer = QgsVectorFileWriter.create(
            gpkg, campi, QgsWkbTypes.Polygon, crs_obj,
            QgsCoordinateTransformContext(), opts)
        if writer.hasError() != QgsVectorFileWriter.NoError:
            return None
        for f in feature:
            writer.addFeature(f)
        del writer  # chiude e scarica su disco

        uri = f"{gpkg}|layername=Strade Evidenziate"
        if esistente is not None:
            # stesso oggetto-layer: ricarico la sorgente aggiornata mantenendo id
            esistente.setDataSource(uri, self.NOME_LAYER_EVIDENZA, "ogr")
            esistente.updateExtents()
            esistente.triggerRepaint()
            return esistente

        # 3) prima volta: aggiungo il layer al progetto, in fondo (sotto gli
        # elementi di progetto). NON usare insertLayer(-1) (crash nativo).
        lyr = QgsVectorLayer(uri, self.NOME_LAYER_EVIDENZA, "ogr")
        if not lyr.isValid():
            return None
        self.project.addMapLayer(lyr, False)
        self.project.layerTreeRoot().addLayer(lyr)
        return lyr

    def _rimuovi_layer_evidenza(self):
        """Elimina l'eventuale evidenza generata in precedenza, così i lanci
        successivi non lasciano copie sovrapposte che scuriscono il giallo."""
        for lyr in list(self.project.mapLayers().values()):
            if lyr.name() == self.NOME_LAYER_EVIDENZA:
                self.project.removeMapLayer(lyr.id())

    def _evidenzia_strade(self):
        rif = self.cb_ev_stradario.currentLayer() or self.cb_c_strada.currentLayer()
        if rif is None:
            QMessageBox.warning(self, "Stradario mancante",
                "Scegli il layer dello stradario da evidenziare (ANAS, provinciale, "
                "comunale): è quello da cui viene ricavato il retino."); return

        # il retino deve coprire la STRADA, non il progetto: se qui finisce uno
        # dei layer di progetto si otterrebbe un retino sopra gli scavi, che è
        # esattamente l'errore da evitare
        layer_progetto = {l.id(): l.name() for l in
                          (self.cb_c_infra.currentLayer(), self.cb_c_poz.currentLayer(),
                           self.cb_c_armadio.currentLayer()) if l is not None}
        if rif.id() in layer_progetto:
            QMessageBox.critical(self, "Layer sbagliato",
                f"'{rif.name()}' è uno dei layer di progetto, non lo stradario: il "
                "retino coprirebbe gli scavi invece della strada.\n\nIn 'Stradario da "
                "evidenziare' scegli il layer delle strade (es. Stradario Provincia, "
                "Rete stradale, grafo ANAS)."); return

        geometrie, conteggio = self._geometrie_progetto_evidenza()
        if not geometrie:
            QMessageBox.warning(self, "Nessun elemento",
                "Nessuna geometria nei layer Infrastrutture, Pozzetto e Armadio Ottico. "
                "Controlla i layer impostati e i filtri qui sotto."); return

        tolleranza = self.spin_ev_tolleranza.value()
        larghezza = self.spin_ev_larghezza.value()

        # Area di lettura: l'intorno degli elementi di progetto. Senza questo
        # filtro veniva scorso lo stradario INTERO, che su un grafo provinciale
        # significa centinaia di migliaia di geometrie tenute in memoria — e se
        # il layer è servito via WFS anche altrettante righe scaricate dalla rete.
        intorno = QgsRectangle(); intorno.setMinimal()
        for g in geometrie:
            intorno.combineExtentWith(g.boundingBox())
        if intorno.isNull() or intorno.isEmpty():
            QMessageBox.warning(self, "Estensione non calcolabile",
                "Non riesco a determinare l'area degli elementi di progetto."); return
        intorno.grow(max(tolleranza * 2, larghezza, 10.0))
        richiesta = self._req_area(rif, QgsGeometry.fromRect(intorno))

        try:
            provider = (rif.dataProvider().name() or "").lower()
        except Exception:
            provider = ""
        avviso_provider = ""
        if provider in ("wfs", "arcgisfeatureserver", "oapif"):
            avviso_provider = (f"Lo stradario è un layer remoto ({provider}): la lettura "
                               "passa dalla rete e può essere lenta. Se lo usi spesso, "
                               "salvane una copia locale in GeoPackage.")

        # indice spaziale sulle tratte lette, poi per ogni elemento di progetto
        # si interrogano solo quelle del suo intorno: senza indice il confronto
        # sarebbe elementi × tratte
        indice = QgsSpatialIndex()
        tratte = {}
        LIMITE_TRATTE = 100000
        for f in (rif.getFeatures(richiesta) if richiesta else rif.getFeatures()):
            g = self._to_proj(f.geometry(), rif)
            if not g or g.isEmpty():
                continue
            tratte[f.id()] = (g, f)
            try:
                indice.addFeature(f.id(), g.boundingBox())
            except TypeError:
                # versioni in cui esiste solo la firma con la feature intera
                copia = QgsFeature(f)
                copia.setGeometry(g)
                indice.addFeature(copia)
            if len(tratte) > LIMITE_TRATTE:
                QMessageBox.critical(self, "Troppe tratte",
                    f"Nell'area di lavoro ci sono più di {LIMITE_TRATTE} tratte di "
                    "stradario: probabilmente gli elementi di progetto selezionati "
                    "coprono un'area enorme, o il layer di riferimento non è uno "
                    "stradario. Restringi la selezione."); return
        if not tratte:
            QMessageBox.information(self, "Nessuna tratta nell'area",
                f"Lo stradario '{rif.name()}' non ha tratte nell'intorno degli elementi "
                "di progetto. Controlla di aver scelto il layer giusto e che i due "
                "layer siano nella stessa zona."); return

        toccate = set()
        for g in geometrie:
            area = g.boundingBox()
            area.grow(max(tolleranza, 0.001))
            for fid in indice.intersects(area):
                if fid in toccate:
                    continue
                g_tratta = tratte.get(fid, (None, None))[0]
                if g_tratta is None:
                    continue
                if g_tratta.distance(g) <= tolleranza:
                    toccate.add(fid)

        if not toccate:
            QMessageBox.information(self, "Nessuna tratta interessata",
                f"Nessuna tratta dello stradario risulta entro {tolleranza:g} m dagli "
                "elementi di progetto. Se gli scavi corrono a bordo strada prova ad "
                "alzare la distanza massima."); return

        # nomi delle strade e tratte toccate, che servono agli attributi e alla
        # modalità "tratte intere"
        nomi = {}; tratte_toccate = []
        campo_nome = self._campo_nome_strada(rif)
        for fid in toccate:
            g, f = tratte[fid]
            tratte_toccate.append((g, f))
            if campo_nome >= 0:
                nome = self._valore_testo(f, campo_nome)
                if nome:
                    nomi[nome] = nomi.get(nome, 0) + 1

        parametri = {
            "area": QgsGeometry.fromRect(intorno),
            "tolleranza": tolleranza,
            "larghezza": larghezza,
            "margine": self.spin_ev_margine.value(),
            "vuoto": self.spin_ev_vuoto.value(),
            "intere": self.chk_ev_intere.isChecked(),
            "campo_nome_strada": (rif.fields().at(campo_nome).name()
                                  if campo_nome >= 0 else ""),
        }

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            if rif.geometryType() == QgsWkbTypes.PolygonGeometry:
                # stradario già poligonale: la sede stradale è disegnata, non
                # serve ricucire nulla né bufferizzare
                fasce = [(g, self._valore_testo(f, campo_nome) if campo_nome >= 0 else "",
                          0.0)
                         for g, f in tratte_toccate if g and not g.isEmpty()]
                lunghezza_totale = 0.0
                corridoi_usati = len(fasce)
                fuori = []
            else:
                fasce, lunghezza_totale, corridoi_usati, fuori = self._fasce_da_corridoi(
                    rif, richiesta, geometrie, tratte_toccate, parametri)
        finally:
            QApplication.restoreOverrideCursor()

        if not fasce:
            QMessageBox.critical(self, "Evidenza non creata",
                "Le tratte interessate non hanno prodotto alcuna fascia utilizzabile."); return
        # Una feature per strada, non una sola geometria dissolta: è ciò che
        # permette di scrivere il nome UNA volta per strada. Con un'unica feature
        # l'etichetta sarebbe una sola per tutta l'evidenza, e con le fasce
        # separate si ripeterebbe su ogni frammento.
        per_strada = {}; metri_strada = {}
        for fascia, nome, metri in fasce:
            per_strada.setdefault(nome, []).append(fascia)
            metri_strada[nome] = metri_strada.get(nome, 0.0) + metri

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            geometrie_finali = {}
            raggio = min(larghezza / 2.0, 5.0)
            for nome, elenco in per_strada.items():
                unita = QgsGeometry.unaryUnion(elenco) if len(elenco) > 1 else elenco[0]
                if self.chk_ev_salda.isChecked() and unita and not unita.isEmpty():
                    # chiusura morfologica: dilata e ricontrae. Salda le fasce che
                    # si sfiorano — tipicamente agli incroci — con raggio limitato
                    # a metà larghezza per non fondere strade parallele vicine.
                    saldata = unita.buffer(raggio, 8).buffer(-raggio, 8)
                    if saldata and not saldata.isEmpty():
                        unita = saldata
                if unita and not unita.isEmpty():
                    geometrie_finali[nome] = unita
        finally:
            QApplication.restoreOverrideCursor()
        if not geometrie_finali:
            QMessageBox.critical(self, "Evidenza non creata",
                "L'unione delle fasce non ha prodotto una geometria valida."); return

        # Layer PERSISTENTE su GeoPackage, a percorso fisso derivato dal
        # progetto: 01_File shp/Strade Evidenziate.gpkg accanto al .qgz. Un layer
        # in memoria sparisce alla chiusura e cambia identità a ogni lancio,
        # quindi il layout di stampa con i livelli BLOCCATI non lo vede mai. Con
        # un GeoPackage a nome fisso, invece, il layer resta lo stesso oggetto:
        # se esiste già nel progetto ne SVUOTO e RISCRIVO le feature (identità
        # preservata → il layout continua a disegnarlo senza ri-bloccare i
        # livelli); se non esiste lo creo una volta e lo aggiungo.
        crs_obj = self.project.crs()
        campi_evid = QgsFields()
        campi_evid.append(QgsField("Strada", QVariant.String, len=120))
        campi_evid.append(QgsField("Lunghezza", QVariant.Double, len=12, prec=1))
        nuove = []
        for nome, geometria in sorted(geometrie_finali.items()):
            feat = QgsFeature(campi_evid)
            feat.setGeometry(geometria)
            feat.setAttributes([
                (nome or "")[:120],
                round(metri_strada.get(nome, 0.0), 1)])
            nuove.append(feat)

        lyr = self._layer_evidenza_persistente(campi_evid, crs_obj, nuove)
        if lyr is None:
            QMessageBox.critical(self, "Evidenza non creata",
                "Non è stato possibile creare o aggiornare il GeoPackage "
                "dell'evidenza. Controlla che la cartella del progetto sia "
                "scrivibile."); return

        stile_usato = self._stile_evidenza(lyr)
        esito_nome = ""
        if self.chk_ev_etichetta.isChecked():
            esito_nome = self._etichetta_evidenza(lyr)
        lyr.triggerRepaint()

        # Salva lo stile in 01_File shp/Stili/Strade Evidenziate.qml e lo collega
        # come predefinito (nel GeoPackage), così l'evidenza si ripresenta già
        # stilizzata alla riapertura senza rilanciare il plugin.
        esito_stile = self._salva_e_collega_stile(lyr, "Strade Evidenziate")

        righe = [f"Stradario usato: '{rif.name()}'.",
                 f"{len(toccate)} tratte dello stradario interessate, "
                 f"{lunghezza_totale:.0f} m evidenziati su {corridoi_usati} "
                 f"corridoi continui"
                 + (" (tratte intere)." if parametri["intere"]
                    else f", vuoti fino a {parametri['vuoto']:g} m colmati."),
                 f"Fascia larga {larghezza:g} m, stile '{stile_usato}', "
                 f"opacità {self.spin_ev_opacita.value()}%.",
                 "Elementi di progetto considerati: "
                 + ", ".join(f"{nome}: {quante}" for nome, quante in conteggio.items())]
        if fuori:
            valide = [d for d in fuori if d is not None]
            dettaglio = (f" Il più vicino dista {min(valide):.1f} m, il più lontano "
                         f"{max(valide):.1f} m." if valide else "")
            righe.append(f"ATTENZIONE: {len(fuori)} elementi di progetto non ricadono su "
                         f"nessun corridoio entro {tolleranza:g} m e non hanno prodotto "
                         f"retino — è la causa tipica delle interruzioni.{dettaglio} "
                         f"Alza 'Distanza max elemento → tratta' oltre quel valore.")
        if esito_nome:
            righe.append(esito_nome)
        if esito_stile:
            righe.append(esito_stile)
        if self.chk_ev_spegni_stradario.isChecked():
            esito_spegni = self._spegni_etichette_stradario(rif)
            if esito_spegni:
                righe.append(esito_spegni)
        if avviso_provider:
            righe.append(avviso_provider)
        if nomi:
            righe.append("Strade: " + ", ".join(f"{n} ({q} tratte)"
                                                for n, q in sorted(nomi.items())))
        righe.append(f"Layer '{self.NOME_LAYER_EVIDENZA}' aggiunto in fondo all'elenco "
                     "dei livelli: se ti serve nella tavola, ricordati che è un layer "
                     "temporaneo e va reso permanente (clic destro → Rendi permanente) "
                     "prima di chiudere il progetto.")
        self.log_ev.setPlainText("\n".join(righe))

    # ── geometria dell'evidenza: continuità lungo il corridoio ──────
    @staticmethod
    def _vertici_geometria(geom):
        """Vertici della geometria come QgsPointXY, qualunque sia il tipo."""
        punti = []
        try:
            for v in geom.vertices():
                punti.append(QgsPointXY(v.x(), v.y()))
            if punti:
                return punti
        except Exception:
            pass
        try:
            if geom.type() == QgsWkbTypes.PointGeometry:
                return [geom.asPoint()]
            if geom.isMultipart():
                for parte in geom.asMultiPolyline():
                    punti.extend(parte)
            else:
                punti.extend(geom.asPolyline())
        except Exception:
            return punti
        return punti

    @staticmethod
    def _sottolinea(geom, da, a):
        """Porzione di polilinea compresa fra due progressive, con i vertici
        intermedi conservati e i due estremi interpolati.

        Serve perché l'evidenza deve seguire la strada per il tratto richiesto:
        prendere solo i due punti agli estremi taglierebbe le curve in linea
        retta e la fascia uscirebbe dalla carreggiata."""
        try:
            punti = list(geom.asPolyline())
        except Exception:
            return None
        if len(punti) < 2:
            return None
        lunghezza = geom.length()
        da = max(0.0, min(da, lunghezza))
        a = max(0.0, min(a, lunghezza))
        if a - da <= 1e-9:
            return None

        risultato = []
        percorso = 0.0
        for i in range(len(punti) - 1):
            p, q = punti[i], punti[i + 1]
            segmento = math.hypot(q.x() - p.x(), q.y() - p.y())
            if segmento <= 0:
                continue
            inizio, fine = percorso, percorso + segmento
            percorso = fine
            if fine < da or inizio > a:
                continue
            if inizio < da:
                t = (da - inizio) / segmento
                risultato.append(QgsPointXY(p.x() + (q.x() - p.x()) * t,
                                            p.y() + (q.y() - p.y()) * t))
            elif not risultato:
                risultato.append(QgsPointXY(p.x(), p.y()))
            if fine <= a:
                risultato.append(QgsPointXY(q.x(), q.y()))
            else:
                t = (a - inizio) / segmento
                risultato.append(QgsPointXY(p.x() + (q.x() - p.x()) * t,
                                            p.y() + (q.y() - p.y()) * t))
                break
        if len(risultato) < 2:
            return None
        return QgsGeometry.fromPolylineXY(risultato)

    def _intervalli_toccati(self, corridoio, geometrie, tolleranza):
        """Intervalli di progressiva del corridoio interessati dagli elementi:
        [(da, a), …]. Di ogni elemento si proiettano TUTTI i vertici, non solo
        gli estremi, perché uno scavo curvo può allontanarsi dall'asse nel
        mezzo e verrebbe misurato più corto di quello che è."""
        intervalli = []
        for g in geometrie:
            if corridoio.distance(g) > tolleranza:
                continue
            progressive = [corridoio.lineLocatePoint(QgsGeometry.fromPointXY(p))
                           for p in self._vertici_geometria(g)]
            if progressive:
                intervalli.append((min(progressive), max(progressive)))
        return intervalli

    @staticmethod
    def _unisci_intervalli(intervalli, vuoto_max):
        """Fonde gli intervalli separati da meno di `vuoto_max`.
        Implementazione e documentazione in ftth_core.unisci_intervalli
        (testata in tests/test_core.py)."""
        return ftth_core.unisci_intervalli(intervalli, vuoto_max)

    @staticmethod
    def _nome_da_chiave(chiave):
        """Il nome della strada dalla chiave del corridoio (ftth_core)."""
        return ftth_core.nome_da_chiave(chiave)

    def _fasce_da_corridoi(self, rif, richiesta, geometrie, tratte_toccate, p):
        """Fasce continue lungo i corridoi dello stradario.

        Ritorna (fasce, lunghezza_evidenziata, numero_corridoi_usati). Lo
        stradario viene prima ricucito in corridoi continui, poi su ciascuno si
        calcolano gli intervalli interessati e si colmano i vuoti: l'evidenza
        risulta un tratto unico invece di una collana di frammenti."""
        # raggruppando per nome strada, ogni corridoio appartiene a una sola
        # strada: serve sia a non ricucire due strade diverse fra loro, sia a
        # poter scrivere il nome corretto su ciascuna fascia
        campo_gruppo = p.get("campo_nome_strada", "")
        corridoi = self._costruisci_corridoi(
            rif, False, campo_gruppo, p["area"] if richiesta is not None else None, 1.0)

        fasce = []; lunghezza = 0.0; usati = 0
        agganciati = set()  # indici delle geometrie di progetto effettivamente usate
        for chiave, corridoio in corridoi:
            if p["intere"]:
                # copertura per tratte intere: si proietta sul corridoio
                # l'estensione completa di ogni tratta toccata
                intervalli = []
                for g, _ in tratte_toccate:
                    if corridoio.distance(g) > 0.5:
                        continue
                    progressive = [corridoio.lineLocatePoint(QgsGeometry.fromPointXY(pt))
                                   for pt in self._vertici_geometria(g)]
                    if progressive:
                        intervalli.append((min(progressive), max(progressive)))
            else:
                intervalli = []
                for indice, g in enumerate(geometrie):
                    if corridoio.distance(g) > p["tolleranza"]:
                        continue
                    progressive = [corridoio.lineLocatePoint(QgsGeometry.fromPointXY(pt))
                                   for pt in self._vertici_geometria(g)]
                    if progressive:
                        intervalli.append((min(progressive), max(progressive)))
                        agganciati.add(indice)
            if not intervalli:
                continue

            margine = p["margine"]
            intervalli = [(da - margine, a + margine) for da, a in intervalli]
            intervalli = self._unisci_intervalli(intervalli, p["vuoto"])
            usati += 1
            for da, a in intervalli:
                porzione = self._sottolinea(corridoio, da, a)
                if porzione is None:
                    continue
                lunghezza += porzione.length()
                fascia = porzione.buffer(p["larghezza"] / 2.0, 12)
                if fascia and not fascia.isEmpty():
                    fasce.append((fascia, self._nome_da_chiave(chiave),
                                  porzione.length()))

        # elementi rimasti fuori: è la spia dei buchi nel retino, quindi va
        # riportata con la distanza reale invece di lasciarli sparire in silenzio
        fuori = []
        if not p["intere"]:
            for indice, g in enumerate(geometrie):
                if indice in agganciati:
                    continue
                distanze = [c.distance(g) for _, c in corridoi]
                fuori.append(min(distanze) if distanze else None)
        return fasce, lunghezza, usati, fuori

    def _costante_pal(self, *percorsi):
        """Costante di QgsPalLayerSettings cercata a runtime: fra le versioni di
        QGIS queste enumerazioni hanno cambiato più volte posizione, quindi si
        provano i percorsi noti e si rinuncia al dettaglio se nessuno esiste."""
        for percorso in percorsi:
            oggetto = QgsPalLayerSettings
            for pezzo in percorso.split("."):
                oggetto = getattr(oggetto, pezzo, None)
                if oggetto is None:
                    break
            if oggetto is not None:
                return oggetto
        return None

    def _etichetta_evidenza(self, lyr):
        """Scrive il nome della strada sull'evidenza, una volta per strada.

        Le tre impostazioni che contano sono: `labelPerPart = False`, che dà una
        sola etichetta anche quando la fascia di una strada è spezzata in più
        parti; nessuna distanza di ripetizione, che è ciò che nello stradario
        produce le sigle minute ripetute ogni pochi centimetri di carta; e il
        piazzamento libero, che ruota il testo per farlo stare dentro la fascia
        seguendone l'andamento diagonale."""
        try:
            impostazioni = QgsPalLayerSettings()
            impostazioni.fieldName = "Strada"
            impostazioni.enabled = True
            impostazioni.isExpression = False

            formato = QgsTextFormat()
            carattere = QFont("Arial")
            carattere.setBold(True)
            formato.setFont(carattere)
            formato.setSize(self.spin_ev_corpo_nome.value())
            formato.setSizeUnit(QgsUnitTypes.RenderPoints)
            formato.setColor(QColor(60, 45, 0))
            alone = QgsTextBufferSettings()
            alone.setEnabled(True)
            alone.setSize(1.0)
            alone.setSizeUnit(QgsUnitTypes.RenderMillimeters)
            alone.setColor(QColor(255, 255, 255))
            formato.setBuffer(alone)
            impostazioni.setFormat(formato)

            # una sola etichetta per feature, anche se la fascia è in più pezzi
            impostazioni.labelPerPart = False
            for attributo in ("repeatDistance",):
                if hasattr(impostazioni, attributo):
                    setattr(impostazioni, attributo, 0.0)

            piazzamento = self._costante_pal("Free", "Placement.Free",
                                             "Horizontal", "Placement.Horizontal")
            if piazzamento is not None:
                impostazioni.placement = piazzamento
            # l'etichetta della strada non deve essere scartata per collisione
            # con le etichette dei pozzetti: in tavola serve sempre
            impostazioni.obstacle = False
            impostazioni.priority = 10

            lyr.setLabeling(QgsVectorLayerSimpleLabeling(impostazioni))
            lyr.setLabelsEnabled(True)
            lyr.triggerRepaint()
            return (f"Nome della strada scritto sull'evidenza a "
                    f"{self.spin_ev_corpo_nome.value():g} pt, una volta per strada.")
        except Exception as e:
            return f"Nome della strada non applicato: {e}"

    def _spegni_etichette_stradario(self, rif):
        """Disattiva l'etichettatura del layer stradario, che è ciò che produce
        le sigle ripetute lungo la strada. Operazione reversibile dalle proprietà
        del layer, quindi non distruttiva, ma va dichiarata nel log perché
        modifica un layer che l'utente non ha chiesto di toccare."""
        try:
            if not rif.labelsEnabled():
                return ""
            rif.setLabelsEnabled(False)
            rif.triggerRepaint()
            return (f"Etichette di '{rif.name()}' disattivate (erano quelle ripetute "
                    "lungo la strada). Per riattivarle: Proprietà layer → Etichette.")
        except Exception as e:
            return f"Etichette dello stradario non modificate: {e}"

    def _campo_nome_strada(self, lyr):
        """Indice del campo con il nome/codice della strada, se riconoscibile."""
        for nome in ("nome_strada", "denominazione", "strada", "nome", "codice",
                     "sigla", "via", "descrizione"):
            i = self._indice_campo(lyr, nome)
            if i >= 0:
                return i
        for campo in lyr.fields():
            if any(indizio in campo.name().lower()
                   for indizio in ("strad", "nome", "denom", "via", "sigla")):
                return lyr.fields().indexOf(campo.name())
        return -1

    # stili disponibili per l'evidenza
    # stile preselezionato all'apertura
    STILE_EVIDENZA_DEFAULT = "pieno"

    _STILI_EVIDENZA = (
        ("retino", "Retino diagonale (lascia leggere la strada sotto)"),
        ("retino_incrociato", "Retino incrociato"),
        ("retino_bordo", "Retino diagonale con bordo continuo"),
        ("pieno", "Tinta unita"),
    )

    @staticmethod
    def _bottone_colore(colore_iniziale):
        """Selettore di colore. Usa QgsColorButton, che è il widget nativo di
        QGIS, e se non fosse disponibile ripiega su un pulsante che apre il
        dialogo di sistema: in entrambi i casi espone .color(), così il codice
        che lo interroga non deve sapere quale dei due è."""
        try:
            from qgis.gui import QgsColorButton
            bottone = QgsColorButton()
            bottone.setColor(colore_iniziale)
            bottone.setAllowOpacity(False)
            return bottone
        except Exception:
            from qgis.PyQt.QtWidgets import QColorDialog
            bottone = QPushButton()
            bottone._colore = colore_iniziale

            def aggiorna():
                bottone.setStyleSheet(
                    f"background-color: {bottone._colore.name()};")
                bottone.setText(bottone._colore.name())

            def scegli():
                scelto = QColorDialog.getColor(bottone._colore, bottone)
                if scelto.isValid():
                    bottone._colore = scelto
                    aggiorna()

            bottone.color = lambda: bottone._colore
            bottone.clicked.connect(scegli)
            aggiorna()
            return bottone

    def _simbolo_evidenza(self, stile):
        """Simbolo di riempimento per l'evidenza.

        Il retino è preferibile al pieno perché copre la strada dichiarandola
        interessata senza nasconderne il disegno: sulla CTR o sull'ortofoto si
        continuano a leggere carreggiata, civici e accessi sotto le linee,
        mentre un campo pieno — anche trasparente — appiattisce tutto."""
        colore = self.btn_ev_colore.color()
        scuro = colore.darker(140)
        if stile == "pieno":
            return QgsFillSymbol.createSimple({
                "color": f"{colore.red()},{colore.green()},{colore.blue()}",
                "outline_color": f"{scuro.red()},{scuro.green()},{scuro.blue()}",
                "outline_width": "0.2",
                "outline_style": "solid",
            })

        from qgis.core import QgsLinePatternFillSymbolLayer, QgsSimpleLineSymbolLayer
        retino = QgsLinePatternFillSymbolLayer()
        retino.setLineAngle(float(self.spin_ev_angolo.value()))
        retino.setDistance(self.spin_ev_passo.value())
        retino.setDistanceUnit(QgsUnitTypes.RenderMillimeters)
        retino.setLineWidth(self.spin_ev_spessore.value())
        retino.setLineWidthUnit(QgsUnitTypes.RenderMillimeters)
        retino.setColor(colore)
        # Il colore va impostato anche sul sotto-simbolo, altrimenti in alcune
        # versioni il retino resta del colore di default. Va però passato un
        # CLONE: setSubSymbol() distrugge il sotto-simbolo corrente e prende
        # possesso di quello nuovo, quindi rigirargli lo stesso oggetto ottenuto
        # da subSymbol() significa fargli usare un puntatore già liberato — un
        # crash nativo, non un'eccezione.
        try:
            sotto = retino.subSymbol()
            if sotto is not None:
                nuovo = sotto.clone()
                nuovo.setColor(colore)
                nuovo.setWidth(self.spin_ev_spessore.value())
                nuovo.setWidthUnit(QgsUnitTypes.RenderMillimeters)
                retino.setSubSymbol(nuovo)
        except Exception:
            pass

        simbolo = QgsFillSymbol()
        if simbolo.symbolLayerCount() > 0:
            simbolo.changeSymbolLayer(0, retino)
        else:
            simbolo.appendSymbolLayer(retino)
        if stile == "retino_incrociato":
            incrocio = QgsLinePatternFillSymbolLayer()
            incrocio.setLineAngle((float(self.spin_ev_angolo.value()) + 90.0) % 180.0)
            incrocio.setDistance(self.spin_ev_passo.value())
            incrocio.setDistanceUnit(QgsUnitTypes.RenderMillimeters)
            incrocio.setLineWidth(self.spin_ev_spessore.value())
            incrocio.setLineWidthUnit(QgsUnitTypes.RenderMillimeters)
            incrocio.setColor(colore)
            try:
                sotto2 = incrocio.subSymbol()
                if sotto2 is not None:
                    clone2 = sotto2.clone()
                    clone2.setColor(colore)
                    clone2.setWidth(self.spin_ev_spessore.value())
                    clone2.setWidthUnit(QgsUnitTypes.RenderMillimeters)
                    incrocio.setSubSymbol(clone2)
            except Exception as e:
                _log_avviso("personalizzazione del retino incrociato non applicata", e)
            simbolo.appendSymbolLayer(incrocio)
        if stile == "retino_bordo":
            bordo = QgsSimpleLineSymbolLayer(scuro, 0.35)
            bordo.setWidthUnit(QgsUnitTypes.RenderMillimeters)
            simbolo.appendSymbolLayer(bordo)
        return simbolo

    def _stile_evidenza(self, lyr):
        """Applica lo stile scelto al layer di evidenza."""
        stile = self._STILI_EVIDENZA[max(0, self.cb_ev_stile.currentIndex())][0]
        try:
            lyr.setRenderer(QgsSingleSymbolRenderer(self._simbolo_evidenza(stile)))
            lyr.setOpacity(self.spin_ev_opacita.value() / 100.0)
            lyr.triggerRepaint()
            return stile
        except Exception as e:
            self.log_ev.appendPlainText(f"retino non applicato ({e}): uso il riempimento pieno")
            try:
                lyr.setRenderer(QgsSingleSymbolRenderer(self._simbolo_evidenza("pieno")))
                lyr.setOpacity(self.spin_ev_opacita.value() / 100.0)
                lyr.triggerRepaint()
            except Exception:
                pass
            return "pieno"

    # ═════════════════════════════════ PERSISTENZA DELLE IMPOSTAZIONI
    # prefissi degli attributi da memorizzare fra le sessioni
    _PREFISSI_SALVATI = ("chk_", "spin_", "txt_", "cb_", "btn_ev_colore")

    def _widget_salvabili(self):
        """[(chiave, widget)] dei controlli il cui valore va conservato.

        I combo dei layer sono esclusi di proposito: puntano a layer di un
        progetto specifico e ripristinarli su un altro progetto darebbe
        riferimenti sbagliati — per quelli valgono i preset di refresh_layers().

        I widget della scheda Esportazione hanno una chiave per copia, perché la
        scheda esiste due volte (Comune e Altri Enti) e self.<nome> punta solo
        all'ultima costruita: senza la distinzione si salverebbe una copia e si
        ripristinerebbe sull'altra."""
        voci = []
        nomi_consegna = set(self._ATTR_CONSEGNA)
        for nome, oggetto in list(self.__dict__.items()):
            if nome in nomi_consegna:
                continue
            if not any(nome.startswith(pref) for pref in self._PREFISSI_SALVATI):
                continue
            if self._tipo_salvabile(oggetto) is not None:
                voci.append((nome, oggetto))
        for indice, contesto in enumerate(self._contesti_consegna):
            for nome, oggetto in contesto.items():
                if self._tipo_salvabile(oggetto) is not None:
                    voci.append((f"consegna{indice}.{nome}", oggetto))
        return voci

    @staticmethod
    def _tipo_salvabile(oggetto):
        """Come leggere e scrivere il valore del widget, o None se non è un
        widget di cui abbia senso conservare lo stato."""
        if isinstance(oggetto, QgsMapLayerComboBox):
            return None          # riferimenti a layer: vedi _widget_salvabili
        if isinstance(oggetto, QgsFieldComboBox):
            return None          # dipende dal layer corrente
        if isinstance(oggetto, QCheckBox):
            return "spunta"
        if isinstance(oggetto, (QDoubleSpinBox, QSpinBox)):
            return "numero"
        if isinstance(oggetto, QFontComboBox):
            return "carattere"
        if isinstance(oggetto, QComboBox):
            return "indice"
        if isinstance(oggetto, QLineEdit):
            return "testo"
        if hasattr(oggetto, "color") and hasattr(oggetto, "setColor"):
            return "colore"
        return None

    def _salva_impostazioni(self):
        """Memorizza i valori dei controlli. Chiamata alla chiusura, così alla
        riapertura il pannello è già come lo si è lasciato: è la forma utile di
        'default', perché segue le abitudini di chi lavora invece di imporre le
        mie."""
        try:
            self._impostazioni.beginGroup("controlli")
            for chiave, widget in self._widget_salvabili():
                tipo = self._tipo_salvabile(widget)
                try:
                    if tipo == "spunta":
                        self._impostazioni.setValue(chiave, widget.isChecked())
                    elif tipo == "numero":
                        self._impostazioni.setValue(chiave, widget.value())
                    elif tipo == "indice":
                        # Si salva ANCHE il testo della voce: i menu riempiti
                        # leggendo una cartella cambiano lunghezza quando i file
                        # cambiano, e la sola posizione finisce per puntare a
                        # un'altra voce. E' bastato aggiungere qualche file di
                        # backup nella cartella degli stili perche' la scelta
                        # memorizzata scivolasse sullo stile sbagliato.
                        self._impostazioni.setValue(chiave, widget.currentIndex())
                        self._impostazioni.setValue(chiave + "__testo",
                                                    widget.currentText())
                    elif tipo == "carattere":
                        self._impostazioni.setValue(chiave, widget.currentFont().family())
                    elif tipo == "testo":
                        self._impostazioni.setValue(chiave, widget.text())
                    elif tipo == "colore":
                        self._impostazioni.setValue(chiave, widget.color().name())
                except Exception:
                    continue
            self._impostazioni.endGroup()
        except Exception as e:
            _log_avviso("lettura/scrittura impostazioni non riuscita", e)

    def _ripristina_impostazioni(self):
        """Rimette i valori memorizzati. Ogni widget è protetto a sé: un valore
        illeggibile o fuori intervallo fa perdere quel solo controllo, che resta
        al proprio default, invece di far fallire l'apertura del pannello."""
        try:
            self._impostazioni.beginGroup("controlli")
            for chiave, widget in self._widget_salvabili():
                tipo = self._tipo_salvabile(widget)
                if not self._impostazioni.contains(chiave):
                    continue
                try:
                    if tipo == "spunta":
                        widget.setChecked(
                            self._impostazioni.value(chiave, type=bool))
                    elif tipo == "numero":
                        valore = float(self._impostazioni.value(chiave))
                        if isinstance(widget, QSpinBox):
                            widget.setValue(int(round(valore)))
                        else:
                            widget.setValue(valore)
                    elif tipo == "indice":
                        # prima si cerca la voce per NOME: se c'e' ancora, e'
                        # quella che l'utente aveva scelto, in qualunque
                        # posizione sia finita
                        testo = self._impostazioni.value(chiave + "__testo")
                        pos = widget.findText(str(testo)) if testo else -1
                        if pos >= 0:
                            widget.setCurrentIndex(pos)
                        else:
                            indice = int(self._impostazioni.value(chiave))
                            if 0 <= indice < widget.count():
                                widget.setCurrentIndex(indice)
                    elif tipo == "carattere":
                        widget.setCurrentFont(QFont(str(self._impostazioni.value(chiave))))
                    elif tipo == "testo":
                        widget.setText(str(self._impostazioni.value(chiave)))
                    elif tipo == "colore":
                        colore = QColor(str(self._impostazioni.value(chiave)))
                        if colore.isValid():
                            widget.setColor(colore)
                except Exception:
                    continue
            self._impostazioni.endGroup()
        except Exception as e:
            _log_avviso("lettura/scrittura impostazioni non riuscita", e)

    def _azzera_impostazioni(self):
        """Riporta tutti i controlli ai valori di fabbrica."""
        if QMessageBox.question(
                self, "Ripristina i valori iniziali",
                "Vuoi riportare tutti i campi ai valori predefiniti del plugin?\\n"
                "Le impostazioni memorizzate verranno dimenticate.",
                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return
        try:
            self._impostazioni.beginGroup("controlli")
            self._impostazioni.remove("")
            self._impostazioni.endGroup()
        except Exception as e:
            _log_avviso("lettura/scrittura impostazioni non riuscita", e)
        QMessageBox.information(
            self, "Valori iniziali ripristinati",
            "Chiudi e riapri il pannello per vedere i valori predefiniti.")

    # ─── TAB SUOLO COMUNALE ─────────────────────────────────────────
    NOME_GRUPPO_COMUNALE = "Elementi su suolo comunale"
    CAMPO_SUOLO = "SUOLO"
    VAL_COMUNALE = "COMUNALE"
    VAL_ALTRO_ENTE = "ALTRO ENTE"

    def _tab_suolo(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("suolo"))
        v.addWidget(self._desc(
            "Individua gli elementi di progetto che NON ricadono sugli stradari di "
            "competenza dell'ente (SP, ANAS, altro) e li separa in un gruppo di livelli a "
            "sé, che si può spegnere quando si stampa la tavola per quell'ente. Prima li "
            "seleziona in mappa perché tu li possa controllare a vista, poi — solo dopo "
            "la tua conferma — li sposta. Lo spostamento non cancella nulla e non duplica "
            "geometrie: scrive un attributo che distingue i due suoli e usa quello come "
            "filtro, sul gruppo nuovo e su quelli originali. Gli stili sono conservati "
            "perché i livelli del gruppo nuovo sono cloni di quelli originali, stessa "
            "sorgente e stessa simbologia. Tutto è annullabile col terzo pulsante."
        ))

        gb1 = self._gruppo("1) Stradari dell'ente"); v1 = QVBoxLayout(gb1)
        v1.addWidget(QLabel("Spunta uno o più stradari di competenza dell'ente:"))
        self.lst_su_stradari = ComboCheckable(placeholder="scegli gli stradari…")
        v1.addWidget(self.lst_su_stradari)
        v.addWidget(gb1)

        gb2 = self._gruppo("2) Livelli da analizzare"); v2 = QVBoxLayout(gb2)
        v2.addWidget(QLabel("Spunta i livelli da analizzare (Armadio, Pozzetto, Infrastrutture, …):"))
        self.lst_su_layer = ComboCheckable(placeholder="scegli i livelli…")
        v2.addWidget(self.lst_su_layer)
        f2 = QFormLayout()
        self.spin_su_tolleranza = self._dspin(0, 200, 8.0, 1, " m")
        self.spin_su_tolleranza.setToolTip(
            "Oltre questa distanza dall'asse dello stradario l'elemento è considerato "
            "fuori. Gli scavi corrono a bordo strada mentre lo stradario è l'asse, quindi "
            "una tolleranza troppo stretta classificherebbe come comunale ciò che sta "
            "sulla provinciale.")
        f2.addRow("Distanza max dallo stradario:", self.spin_su_tolleranza)
        self.txt_su_gruppo = QLineEdit(self.NOME_GRUPPO_COMUNALE)
        f2.addRow("Nome del gruppo da creare:", self.txt_su_gruppo)
        v2.addLayout(f2)
        self.chk_su_solo_nuovo = QCheckBox(f"Solo gli elementi con {CAMPO_STATO} = '{VAL_NUOVO}'")
        v2.addWidget(self.chk_su_solo_nuovo)
        self.chk_su_zoom = QCheckBox("Inquadra gli elementi trovati dopo l'analisi")
        self.chk_su_zoom.setChecked(True)
        v2.addWidget(self.chk_su_zoom)
        v.addWidget(gb2)

        riga_b = QHBoxLayout()
        b1 = QPushButton("1. Evidenzia in mappa gli elementi fuori stradario")
        b1.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        b1.clicked.connect(self._trova_fuori_stradario)
        riga_b.addWidget(b1)
        b2 = QPushButton("2. Sposta nel gruppo")
        b2.setToolTip("Attivo dopo l'analisi: sposta gli elementi evidenziati nel gruppo "
                      "nuovo, filtrando gli originali.")
        b2.clicked.connect(self._sposta_su_suolo_comunale)
        riga_b.addWidget(b2)
        v.addLayout(riga_b)
        riga_b2 = QHBoxLayout()
        riga_b2.addStretch()
        b3 = QPushButton("Annulla lo spostamento")
        b3.setToolTip("Rimuove il gruppo e azzera i filtri sui livelli originali. "
                      "L'attributo scritto resta, ma non filtra più nulla.")
        b3.clicked.connect(self._annulla_suolo_comunale)
        riga_b2.addWidget(b3)
        v.addLayout(riga_b2)

        self.stato_su = self._etichetta_stato()
        v.addWidget(self.stato_su)
        self.log_su = self._log_widget(140)
        v.addWidget(self._blocco_log(self.log_su))

        v.addStretch(); return w

    # ═════════════════════════════════════════ SUOLO COMUNALE – LOGICA
    def _popola_elenchi_suolo(self):
        """Riempie i due menu a tendina con i livelli del progetto, conservando
        le spunte già fatte e preselezionando i livelli tipici la prima volta."""
        for combo, tipi, preselezione in (
                (self.lst_su_stradari,
                 (QgsWkbTypes.LineGeometry, QgsWkbTypes.PolygonGeometry),
                 ("Stradario_Italia_Join", "Stradario_Italia", "Stradario Provincia Italia",
                  "Stradario", "Provinciali", "ANAS")),
                (self.lst_su_layer,
                 (QgsWkbTypes.PointGeometry, QgsWkbTypes.LineGeometry),
                 ("01_ARMADIO OTTICO", "02_POZZETTO", "03 INFRASTRUTTURE"))):
            gia_scelti = set(combo.dati_spuntati())
            primo_giro = combo.model().rowCount() == 0
            combo.svuota()
            for lyr in self.project.mapLayers().values():
                if not isinstance(lyr, QgsVectorLayer):
                    continue
                if lyr.geometryType() not in tipi:
                    continue
                if lyr.name() == self.NOME_LAYER_EVIDENZA:
                    continue
                spuntato = (lyr.id() in gia_scelti
                            or (primo_giro and lyr.name() in preselezione))
                combo.aggiungi(lyr.name(), lyr.id(), spuntato)

    def _layer_scelti(self, combo):
        scelti = []
        for lid in combo.dati_spuntati():
            lyr = self.project.mapLayer(lid)
            if isinstance(lyr, QgsVectorLayer):
                scelti.append(lyr)
        return scelti

    def _feature_da_classificare(self, lyr):
        feature = list(lyr.getFeatures())
        if self.chk_su_solo_nuovo.isChecked():
            i = self._indice_campo(lyr, CAMPO_STATO)
            if i >= 0:
                atteso = VAL_NUOVO.lower()
                feature = [f for f in feature
                           if self._valore_testo(f, i).lower() == atteso]
        return feature

    def _trova_fuori_stradario(self):
        """Seleziona in mappa gli elementi che distano dagli stradari più della
        tolleranza. Non modifica nulla: serve al controllo a vista prima dello
        spostamento."""
        stradari = self._layer_scelti(self.lst_su_stradari)
        bersagli = self._layer_scelti(self.lst_su_layer)
        if not stradari:
            QMessageBox.warning(self, "Stradari mancanti",
                "Seleziona almeno uno stradario nel punto 1."); return
        if not bersagli:
            QMessageBox.warning(self, "Livelli mancanti",
                "Seleziona almeno un livello da analizzare nel punto 2."); return

        tolleranza = self.spin_su_tolleranza.value()
        righe = []; self._fuori_stradario = {}
        totale_fuori = 0; totale_esaminati = 0
        estensione = QgsRectangle(); estensione.setMinimal()

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # un solo indice per tutti gli stradari messi insieme: la domanda è
            # "quanto dista dalla rete di competenza dell'ente", non da quale
            # dei suoi livelli
            indice = QgsSpatialIndex()
            geometrie_rete = {}
            contatore = 0
            for rete in stradari:
                for f in rete.getFeatures():
                    g = self._to_proj(f.geometry(), rete)
                    if not g or g.isEmpty():
                        continue
                    contatore += 1
                    geometrie_rete[contatore] = g
                    try:
                        indice.addFeature(contatore, g.boundingBox())
                    except TypeError:
                        copia = QgsFeature()
                        copia.setId(contatore)
                        copia.setGeometry(g)
                        indice.addFeature(copia)
            righe.append(f"Rete di riferimento: {contatore} tratte da "
                         + ", ".join(f"'{r.name()}'" for r in stradari))
            if not geometrie_rete:
                righe.append("Nessuna geometria negli stradari scelti: analisi interrotta.")
                self.log_su.setPlainText("\n".join(righe))
                return

            for lyr in bersagli:
                feature = self._feature_da_classificare(lyr)
                fuori = []
                for f in feature:
                    g = self._to_proj(f.geometry(), lyr)
                    if not g or g.isEmpty():
                        continue
                    totale_esaminati += 1
                    intorno = g.boundingBox()
                    intorno.grow(max(tolleranza, 0.001))
                    vicine = indice.intersects(intorno)
                    distanza = None
                    for fid in vicine:
                        d = geometrie_rete[fid].distance(g)
                        if distanza is None or d < distanza:
                            distanza = d
                        if distanza <= tolleranza:
                            break
                    if distanza is None or distanza > tolleranza:
                        fuori.append(f.id())
                        estensione.combineExtentWith(g.boundingBox())
                lyr.selectByIds(fuori)
                self._fuori_stradario[lyr.id()] = fuori
                totale_fuori += len(fuori)
                righe.append(f"  {lyr.name()}: {len(fuori)} fuori stradario su "
                             f"{len(feature)} esaminati")
        finally:
            QApplication.restoreOverrideCursor()

        if totale_fuori and self.chk_su_zoom.isChecked() and not estensione.isEmpty():
            estensione.grow(max(estensione.width(), estensione.height()) * 0.15 + 20)
            self.iface.mapCanvas().setExtent(estensione)
            self.iface.mapCanvas().refresh()

        righe.insert(0, f"{totale_fuori} elementi fuori dagli stradari dell'ente su "
                        f"{totale_esaminati} esaminati (tolleranza {tolleranza:g} m).")
        righe.append("")
        righe.append("Gli elementi trovati sono ora SELEZIONATI in mappa: controllali a "
                     "vista, poi premi '2. Sposta nel gruppo'. Se la selezione non ti "
                     "torna, ritocca la tolleranza e rilancia l'analisi — finché non "
                     "premi il secondo pulsante non viene modificato nulla.")
        self.log_su.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_su,
                           f"{totale_fuori} elementi fuori stradario, selezionati in mappa.",
                           ok=totale_fuori > 0)

    def _clona_layer(self, originale, nome, filtro):
        """Copia del livello con la stessa sorgente, lo stesso stile e un filtro.

        Si usa clone(), che porta con sé simbologia, etichette e trasparenze: il
        gruppo nuovo deve essere indistinguibile dall'originale a vedersi, e
        ricostruire lo stile a mano significherebbe perderne i dettagli. Sui
        livelli in memoria clone() non porta i dati, perché l'URI di un layer
        temporaneo non li contiene, quindi in quel caso le feature vengono
        copiate una a una."""
        try:
            copia = originale.clone()
        except Exception:
            copia = None
        if copia is None or not copia.isValid():
            return None, "clone del livello non riuscito"
        copia.setName(nome)

        if originale.dataProvider().name() == "memory":
            fids = self._fuori_stradario.get(originale.id(), [])
            copia.dataProvider().truncate()
            da_copiare = [f for f in originale.getFeatures() if f.id() in set(fids)]
            copia.dataProvider().addFeatures(da_copiare)
            copia.updateExtents()
            return copia, "livello temporaneo: feature copiate una a una"

        if not copia.setSubsetString(filtro):
            return copia, f"il filtro '{filtro}' non è stato accettato dal provider"
        return copia, ""

    def _sposta_su_suolo_comunale(self):
        if not getattr(self, "_fuori_stradario", None):
            QMessageBox.warning(self, "Analisi mancante",
                "Premi prima '1. Evidenzia in mappa gli elementi fuori stradario': lo "
                "spostamento agisce su quel risultato."); return
        totale = sum(len(v) for v in self._fuori_stradario.values())
        if not totale:
            QMessageBox.information(self, "Niente da spostare",
                "L'analisi non ha trovato elementi fuori dagli stradari."); return

        nome_gruppo = self.txt_su_gruppo.text().strip() or self.NOME_GRUPPO_COMUNALE
        if QMessageBox.question(
                self, "Conferma lo spostamento",
                f"Sposto {totale} elementi nel gruppo '{nome_gruppo}'.\n\n"
                f"Sui livelli originali verrà scritto il campo "
                f"'{self.CAMPO_SUOLO}' e applicato un filtro che nasconde gli elementi "
                f"spostati. Nessuna geometria viene cancellata e l'operazione è "
                f"annullabile.\n\nProcedo?",
                QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
            return

        righe = []; spostati = 0
        filtro_comunale = f'"{self.CAMPO_SUOLO}" = \'{self.VAL_COMUNALE}\''
        filtro_ente = (f'"{self.CAMPO_SUOLO}" IS NULL OR "{self.CAMPO_SUOLO}" <> '
                       f"'{self.VAL_COMUNALE}'")

        self._annulla_suolo_comunale(silenzioso=True)
        radice = self.project.layerTreeRoot()
        gruppo = radice.insertGroup(0, nome_gruppo)

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            for lyr_id, fids in self._fuori_stradario.items():
                lyr = self.project.mapLayer(lyr_id)
                if lyr is None:
                    continue
                righe.append(f"── {lyr.name()} ──")
                if not fids:
                    righe.append("  nessun elemento fuori stradario: lasciato invariato.")
                    continue

                # 1) l'attributo che distingue i due suoli
                idx, nome_campo, esito = self._assicura_campo(
                    lyr, self.CAMPO_SUOLO, tipo_testo=True, lunghezza=20)
                if esito.startswith("fallito"):
                    righe.append(f"  campo '{self.CAMPO_SUOLO}': {esito[8:].strip()}. "
                                 "Livello saltato.")
                    continue
                if not self._start_edit(lyr):
                    righe.append("  impossibile avviare la modifica: livello saltato.")
                    continue
                insieme = set(fids)
                scritte = 0
                for f in self._feature_da_classificare(lyr):
                    valore = (self.VAL_COMUNALE if f.id() in insieme
                              else self.VAL_ALTRO_ENTE)
                    if lyr.changeAttributeValue(f.id(), idx, valore):
                        scritte += 1
                if not self._commit(lyr, f"Classificazione suolo su {lyr.name()}"):
                    righe.append("  SALVATAGGIO ANNULLATO: livello saltato.")
                    continue
                righe.append(f"  campo '{nome_campo}' {esito}, {scritte} valori scritti.")

                # 2) il clone filtrato nel gruppo nuovo
                copia, avviso = self._clona_layer(
                    lyr, f"{lyr.name()} — suolo comunale", filtro_comunale)
                if copia is None:
                    righe.append(f"  {avviso}: livello non aggiunto al gruppo.")
                    continue
                self.project.addMapLayer(copia, False)
                gruppo.addLayer(copia)
                if avviso:
                    righe.append(f"  {avviso}")

                # 3) il filtro complementare sull'originale
                if lyr.dataProvider().name() != "memory":
                    if lyr.setSubsetString(filtro_ente):
                        righe.append(f"  filtro applicato all'originale: nasconde i "
                                     f"{len(fids)} elementi spostati.")
                    else:
                        righe.append("  ATTENZIONE: il provider ha rifiutato il filtro "
                                     "sull'originale, quindi gli elementi restano "
                                     "visibili anche qui.")
                else:
                    righe.append("  livello temporaneo: l'originale non è stato filtrato.")
                spostati += len(fids)
        finally:
            QApplication.restoreOverrideCursor()

        gruppo.setItemVisibilityChecked(True)
        self.iface.mapCanvas().refresh()
        intestazione = (f"{spostati} elementi spostati nel gruppo '{nome_gruppo}'. "
                        "Spegni il gruppo per togliere dalla tavola gli elementi su "
                        "suolo comunale.")
        righe.insert(0, intestazione)
        righe.append("")
        righe.append("Per annullare: pulsante 'Annulla lo spostamento'. Nessuna geometria "
                     "è stata cancellata — gli elementi sono ancora tutti nei livelli "
                     "originali, semplicemente filtrati.")
        self.log_su.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_su, intestazione, ok=spostati > 0)

    def _annulla_suolo_comunale(self, silenzioso=False):
        """Toglie il gruppo e azzera i filtri, riportando i livelli come erano."""
        nome_gruppo = self.txt_su_gruppo.text().strip() or self.NOME_GRUPPO_COMUNALE
        rimossi = 0; sfiltrati = 0
        radice = self.project.layerTreeRoot()
        gruppo = radice.findGroup(nome_gruppo)
        if gruppo is not None:
            for nodo in list(gruppo.findLayers()):
                if nodo.layer() is not None:
                    self.project.removeMapLayer(nodo.layer().id())
                    rimossi += 1
            radice.removeChildNode(gruppo)

        marcatore = f'"{self.CAMPO_SUOLO}"'
        for lyr in self.project.mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            try:
                if marcatore in (lyr.subsetString() or ""):
                    lyr.setSubsetString("")
                    sfiltrati += 1
            except Exception:
                continue
        self.iface.mapCanvas().refresh()

        if silenzioso:
            return
        messaggio = (f"Gruppo rimosso ({rimossi} livelli), filtro azzerato su "
                     f"{sfiltrati} livelli originali.")
        self.log_su.setPlainText(
            messaggio + "\n\nIl campo " + self.CAMPO_SUOLO + " resta scritto negli "
            "attributi, ma non filtra più nulla: puoi rilanciare l'analisi da zero.")
        self._mostra_stato(self.stato_su, messaggio)

    # ══════════════════════════════════ EDIFICI IN CARREGGIATA – UI
    # Nei dati DBSN capita che geometrie di 'Edifici minori' cadano dentro il
    # poligono della carreggiata: sono errori del dato di base, non edifici. La
    # scheda li trova regione per regione, li mette da parte in un file e poi li
    # cancella. Il lavoro è per gruppo di livelli e non sull'intero progetto:
    # una regione alla volta, con esito verificabile prima di passare oltre.
    CHIAVE_ED_STRADE = "strade"
    CHIAVE_ED_EDIFICI = "edifici minori"
    NOME_FILE_SCARTI = "edifici_in_carreggiata.gpkg"

    # ─── TAB SCREENING TERRITORIO ─────────────────────────────────
    def _tab_screening(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("screening"))
        v.addWidget(self._desc(
            "Scrivi il nome del comune e lo screening interroga le fonti nazionali: "
            "rete stradale classificata (SS ANAS, SP, SR, autostrade) con l'ente "
            "gestore, Soprintendenza ABAP competente con la PEC, vincoli paesaggistici "
            "SITAP (art. 136, art. 142, parchi, UNESCO), ferrovie e corsi d'acqua. Il "
            "risultato è l'elenco degli enti da interpellare per lo scavo su suolo "
            "pubblico, con titolo richiesto, norme e documentazione tipica, più un "
            "report Markdown di pre-istruttoria. È una ricognizione, non una "
            "certificazione: ogni stadio dichiara la fonte e la confidenza del dato, e "
            "i vincoli ex art. 142 operano anche dove non sono cartografati. Servono "
            "la connessione a internet e qualche minuto: le fonti sono servizi "
            "pubblici (OSM, SITAP del Ministero della Cultura), non archivi locali."
        ))

        gb1 = self._gruppo("1) Comune da analizzare"); f1 = QFormLayout(gb1)
        self.txt_scr_comune = QLineEdit()
        self.txt_scr_comune.setPlaceholderText("es. Manziana")
        f1.addRow("Comune:", self.txt_scr_comune)
        self.txt_scr_provincia = QLineEdit()
        self.txt_scr_provincia.setPlaceholderText("facoltativa — serve per le omonimie (es. Roma)")
        f1.addRow("Provincia:", self.txt_scr_provincia)
        v.addWidget(gb1)

        gb2 = self._gruppo("2) Cosa produce"); v2 = QVBoxLayout(gb2)

        # modalità di analisi: sul tracciato (dettaglio, con fasce di rispetto)
        # oppure sull'area di progetto ARLO (prudente, tutto ciò che la tocca)
        from qgis.PyQt.QtWidgets import QRadioButton, QButtonGroup
        v2.addWidget(self._intestazione("Ambito dell'analisi"))
        self.rb_scr_tracciato = QRadioButton(
            "Sul TRACCIATO di progetto (03 INFRASTRUTTURE + pozzetti + armadi) con fasce di rispetto ufficiali")
        self.rb_scr_arlo_area = QRadioButton(
            "Sull'AREA di progetto (ARLO): tutto ciò che la interseca")
        self.rb_scr_tracciato.setChecked(True)   # dettaglio come default
        self._grp_scr_ambito = QButtonGroup(self)
        self._grp_scr_ambito.addButton(self.rb_scr_tracciato)
        self._grp_scr_ambito.addButton(self.rb_scr_arlo_area)
        v2.addWidget(self.rb_scr_tracciato)
        v2.addWidget(self.rb_scr_arlo_area)

        ft = QFormLayout()
        self.spin_scr_buffer = self._dspin(0, 500, 20, 0, " m")
        self.spin_scr_buffer.setToolTip(
            "Margine attorno al tracciato entro cui cercare le interferenze, in aggiunta "
            "alle fasce di rispetto di legge. 0 = solo la distanza reale.")
        ft.addRow("Margine attorno al tracciato:", self.spin_scr_buffer)
        v2.addLayout(ft)

        # backward-compat: alcuni metodi leggono chk_scr_arlo; lo teniamo come
        # alias logico dello stato "usa ARLO", nascosto
        self.chk_scr_arlo = QCheckBox()
        self.chk_scr_arlo.setVisible(False)
        f2 = QFormLayout()
        self.cb_scr_arlo = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        f2.addRow("Area di progetto (ARLO):", self.cb_scr_arlo)
        v2.addLayout(f2)

        self.chk_scr_stradario = QCheckBox(
            "Usa uno stradario del progetto come fonte primaria delle strade (OSM resta controprova)")
        v2.addWidget(self.chk_scr_stradario)
        f3 = QFormLayout()
        self.cb_scr_stradario = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        # parte vuoto: l'auto-selezione in refresh_layers sceglie il migliore.
        # Senza questo, QgsMapLayerComboBox si auto-riempie col primo layer
        # linea del progetto (di solito '03 INFRASTRUTTURE') e l'auto-scelta
        # non scatterebbe mai.
        self.cb_scr_stradario.setLayer(None)
        f3.addRow("Stradario di riferimento:", self.cb_scr_stradario)
        self.cb_scr_campo = QgsFieldComboBox()
        self.cb_scr_stradario.layerChanged.connect(self.cb_scr_campo.setLayer)
        f3.addRow("Campo con la sigla (SP/SS…):", self.cb_scr_campo)
        v2.addLayout(f3)
        self.chk_scr_layer = QCheckBox(
            "Carica in mappa i layer dello screening (confine, strade classificate, vincoli, ferrovie e acque)")
        self.chk_scr_layer.setChecked(True)
        v2.addWidget(self.chk_scr_layer)
        self.chk_scr_report = QCheckBox("Salva il report Markdown accanto al progetto")
        self.chk_scr_report.setChecked(True)
        v2.addWidget(self.chk_scr_report)
        self.chk_scr_xlsx = QCheckBox("Salva il report Excel (.xlsx) degli enti accanto al progetto")
        self.chk_scr_xlsx.setChecked(True)
        v2.addWidget(self.chk_scr_xlsx)
        self.chk_scr_shp = QCheckBox(
            "Genera shape + GeoPackage con stili QGIS per le tavole (confine, strade, vincoli, Natura 2000, ferrovie, acque, boschi)")
        self.chk_scr_shp.setChecked(False)
        v2.addWidget(self.chk_scr_shp)
        v.addWidget(gb2)

        riga = QHBoxLayout()
        self.btn_scr_avvia = QPushButton("Avvia screening")
        self.btn_scr_avvia.clicked.connect(self._avvia_screening)
        riga.addWidget(self.btn_scr_avvia)
        # L'utente non aveva alcun modo di fermare uno screening partito per
        # sbaglio o su un comune sbagliato: restava a guardare la finestra
        # bloccata finché non uccideva QGIS. Abilitato solo mentre gira.
        self.btn_scr_annulla = QPushButton("Annulla")
        self.btn_scr_annulla.setToolTip(
            "Ferma lo screening in corso appena la richiesta aperta si chiude. "
            "Non vengono creati layer né salvati report.")
        self.btn_scr_annulla.setEnabled(False)
        self.btn_scr_annulla.clicked.connect(self._annulla_screening)
        riga.addWidget(self.btn_scr_annulla)
        btn_apri = QPushButton("Apri l'ultimo report")
        btn_apri.setToolTip("Apre il report Markdown dell'ultimo screening con il programma predefinito.")
        btn_apri.clicked.connect(self._apri_report_screening)
        riga.addWidget(btn_apri)
        riga.addStretch()
        v.addLayout(riga)

        self.log_scr = self._log_widget(220)
        v.addWidget(self._blocco_log(self.log_scr, "Esito dello screening"))
        v.addStretch(); return w

    def _log_screening(self, msg):
        self.log_scr.appendPlainText(str(msg))
        sb = self.log_scr.verticalScrollBar()
        sb.setValue(sb.maximum())
        # Mentre lo screening gira in un thread a parte il ciclo degli eventi
        # è già libero, quindi processEvents non serve e anzi è pericoloso:
        # rientrerebbe nel ciclo durante la consegna di un segnale e potrebbe
        # consegnare la chiusura della finestra mentre il log sta scrivendo.
        # Resta per gli altri chiamanti (caricamento dei layer in mappa, export
        # delle tavole), che girano nel thread dell'interfaccia dentro cicli
        # lunghi e senza di esso lascerebbero la finestra ferma.
        if not getattr(self, "_scr_in_corso", False):
            QApplication.processEvents()

    def _percorso_report_screening(self, nome_comune):
        """Cartella dedicata 'Screening Territorio/<Comune>/' dentro il progetto
        (o nella home se il progetto non è salvato). Tutti gli export dello
        screening (md, xlsx, shp, gpkg) derivano da qui, così restano ordinati."""
        radice = os.path.dirname(self.project.fileName() or "") or os.path.expanduser("~")
        sicuro = re.sub(r"[^0-9A-Za-zÀ-ÿ _-]+", "", nome_comune).strip() or "comune"
        base = os.path.join(radice, "Screening Territorio", sicuro)
        try:
            os.makedirs(base, exist_ok=True)
        except Exception as e:
            _log_avviso("creazione cartella Screening Territorio non riuscita", e)
            base = radice
        return os.path.join(base, "screening_%s.md" % sicuro.replace(" ", "_"))

    def _apri_report_screening(self):
        percorso = getattr(self, "_ultimo_report_screening", None)
        if not percorso or not os.path.exists(percorso):
            QMessageBox.information(self, "Nessun report",
                                    "Non c'è ancora un report: avvia prima uno screening.")
            return
        try:
            os.startfile(percorso)          # Windows
        except Exception as e:
            _log_avviso("apertura report screening non riuscita", e)
            QMessageBox.information(self, "Report", "Il report è in:\n%s" % percorso)

    def _avvia_screening(self):
        # Due screening insieme si contenderebbero log, report ed export sugli
        # stessi percorsi: con l'interfaccia ora reattiva il doppio clic
        # diventa possibile, quindi va rifiutato esplicitamente.
        if getattr(self, "_scr_in_corso", False):
            QMessageBox.information(
                self, "Screening in corso",
                "Uno screening sta già girando: attendi la fine oppure premi Annulla.")
            return
        comune = self.txt_scr_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante",
                                "Scrivi il nome del comune da analizzare.")
            return
        provincia = self.txt_scr_provincia.text().strip() or None
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
        except ImportError as e:
            QMessageBox.critical(
                self, "Dipendenze mancanti",
                "Lo screening richiede i moduli Python 'requests', 'yaml' e "
                "'shapely', normalmente inclusi in QGIS.\n\nDettaglio: %s" % e)
            return

        self.log_scr.clear()
        self.btn_scr_avvia.setEnabled(False)

        # ambito dell'analisi: TRACCIATO (dettaglio, con fasce) o ARLO (area).
        usa_tracciato = self.rb_scr_tracciato.isChecked()
        traccia_shapely = None
        traccia_nome = None
        buffer_m = self.spin_scr_buffer.value()
        if usa_tracciato:
            try:
                traccia_shapely, traccia_nome, n_parti = self._costruisci_tracciato()
            except Exception as e:
                _log_avviso("costruzione tracciato screening", e)
                QMessageBox.warning(self, "Tracciato non utilizzabile",
                                    "Non riesco a costruire il tracciato di progetto:\n%s" % e)
                self.btn_scr_avvia.setEnabled(True)
                return
            if traccia_shapely is None:
                QMessageBox.warning(
                    self, "Tracciato mancante",
                    "Per l'analisi sul tracciato servono i layer '03 INFRASTRUTTURE', "
                    "'02_POZZETTO' o '01_ARMADIO OTTICO' nel progetto. In alternativa "
                    "scegli l'analisi sull'area di progetto (ARLO).")
                self.btn_scr_avvia.setEnabled(True)
                return
            self._log_screening("Tracciato di progetto: %s (%d elementi, margine %.0f m)"
                                % (traccia_nome, n_parti, buffer_m))

        # geometria dell'area di progetto (ARLO): unione dei poligoni in WGS84,
        # calcolata PRIMA della rete così un errore ferma subito senza sprecare
        # i minuti delle interrogazioni. Serve sempre allo stradario (filtro
        # spaziale); in modalità tracciato usiamo il tracciato per gli enti ma
        # l'ARLO, se presente, per leggere lo stradario.
        area_shapely = None
        nome_area = None
        usa_arlo = self.rb_scr_arlo_area.isChecked()
        arlo = self.cb_scr_arlo.currentLayer()
        if usa_arlo or (usa_tracciato and arlo is not None):
            if arlo is None:
                QMessageBox.warning(
                    self, "Area di progetto mancante",
                    "Hai chiesto l'analisi sull'area di progetto ma il combo "
                    "è vuoto: scegli il layer (es. 'Arlo Area') o usa il tracciato.")
                self.btn_scr_avvia.setEnabled(True)
                return
            try:
                from shapely import wkt as _shp_wkt
                geoms = [f.geometry() for f in arlo.getFeatures() if f.hasGeometry()]
                if not geoms:
                    raise ValueError("il layer '%s' non ha geometrie" % arlo.name())
                g_unione = QgsGeometry.unaryUnion(geoms)
                tr = QgsCoordinateTransform(
                    arlo.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), self.project)
                g_unione.transform(tr)
                area_shapely = _shp_wkt.loads(g_unione.asWkt(8))
                nome_area = arlo.name()
            except Exception as e:
                _log_avviso("preparazione area di progetto screening", e)
                if usa_arlo:
                    QMessageBox.warning(self, "Area di progetto non utilizzabile",
                                        "Non riesco a usare '%s' come area di progetto:\n%s"
                                        % (arlo.name(), e))
                    self.btn_scr_avvia.setEnabled(True)
                    return
                area_shapely = None   # in modalità tracciato l'ARLO è opzionale
            if area_shapely is not None and usa_arlo:
                self._log_screening("Area di progetto: '%s' (%d poligoni)"
                                    % (nome_area, arlo.featureCount()))

        # zone ARLO per etichetta: [(label, shapely_wgs84)] — servono ad
        # attribuire ogni vincolo/strada all'ARLO AREA che tocca (colonna nel
        # report). Raccolte solo se c'è il layer ARLO (in una delle due modalità).
        arlo_zone = None
        if arlo is not None:
            try:
                arlo_zone = self._zone_arlo(arlo)
                if arlo_zone:
                    scart = getattr(self, "_arlo_zone_scartate", 0)
                    self._log_screening("Zone ARLO riconosciute: %d (%s)%s" % (
                        len(arlo_zone),
                        ", ".join(z[0] for z in arlo_zone[:6]) + (" …" if len(arlo_zone) > 6 else ""),
                        " · %d poligono/i senza etichetta scartato/i" % scart if scart else ""))
            except Exception as e:
                _log_avviso("lettura zone ARLO per etichetta", e)
                arlo_zone = None

        # stradario di riferimento (fonte primaria delle strade), letto sui
        # tratti che intersecano l'area di progetto (o il bbox del comune se
        # non c'è ARLO). Preparato PRIMA delle interrogazioni di rete.
        strad_records = None
        strad_nome = None
        strad_indip = True
        if self.chk_scr_stradario.isChecked():
            strad = self.cb_scr_stradario.currentLayer()
            campo = self.cb_scr_campo.currentField()
            if strad is None or not campo:
                QMessageBox.warning(
                    self, "Stradario incompleto",
                    "Hai chiesto di usare uno stradario di riferimento ma manca il "
                    "layer o il campo con la sigla. Scegli entrambi o togli la spunta.")
                self.btn_scr_avvia.setEnabled(True)
                return
            try:
                # in modalità tracciato lo stradario va letto sul tracciato
                # (bufferizzato) per coerenza d'ambito; in modalità ARLO sull'area
                if usa_tracciato:
                    area_lettura = traccia_shapely.buffer(max(buffer_m, 40) / 111320.0)
                    strad_records, strad_indip = self._leggi_stradario(
                        strad, campo, area_lettura, tracciato_wgs=traccia_shapely)
                else:
                    area_lettura = area_shapely
                    strad_records, strad_indip = self._leggi_stradario(strad, campo, area_lettura)
            except Exception as e:
                _log_avviso("lettura stradario di riferimento", e)
                QMessageBox.warning(self, "Stradario non utilizzabile",
                                    "Non riesco a leggere '%s':\n%s" % (strad.name(), e))
                self.btn_scr_avvia.setEnabled(True)
                return
            strad_nome = strad.name()
            self._log_screening(
                "Stradario di riferimento: '%s' campo '%s' (%s)"
                % (strad_nome, campo,
                   "fonte indipendente" if strad_indip else "estratto OSM — controprova non indipendente"))

        raccogli = self.chk_scr_layer.isChecked() or area_shapely is not None
        self._log_screening("Screening di '%s'%s — interrogazione delle fonti nazionali…"
                            % (comune, " (%s)" % provincia if provincia else ""))

        # Da qui in poi il lavoro è LENTO (decine di interrogazioni remote, più
        # i calcoli shapely) e va FUORI dal thread dell'interfaccia. Tutto ciò
        # che legge i layer di QGIS — tracciato, area ARLO, zone ARLO,
        # stradario — è già stato fatto sopra, nel thread principale, perché
        # gli oggetti di QGIS non sono utilizzabili da un altro thread: al
        # worker arrivano solo geometrie shapely e liste Python.
        self._scr_contesto = {
            "scr": scr,
            "usa_tracciato": usa_tracciato,
            "traccia_nome": traccia_nome,
            "nome_area": nome_area,
            "area": area_shapely,
            "arlo_zone": arlo_zone,
        }
        self._lancia_worker_screening(scr, {
            "comune": comune,
            "provincia": provincia,
            "raccogli": raccogli,
            "usa_tracciato": usa_tracciato,
            "traccia": traccia_shapely,
            "traccia_nome": traccia_nome,
            "buffer_m": buffer_m,
            "area": area_shapely,
            "nome_area": nome_area,
            "strad_records": strad_records,
            "strad_nome": strad_nome,
            "strad_indip": strad_indip,
            "budget_s": None,       # None = budget predefinito del modulo
        })

    def _lancia_worker_screening(self, scr, param):
        """Mette in moto il thread secondario e restituisce subito il controllo
        al ciclo degli eventi: è questo che impedisce a Windows di marcare QGIS
        come 'Non risponde' per tutta la durata dello screening."""
        self._scr_thread = QThread()
        self._scr_worker = _ScreeningWorker(scr, param)
        self._scr_worker.moveToThread(self._scr_thread)
        self._scr_thread.started.connect(self._scr_worker.esegui)
        # L'avanzamento passa di qui e non da una chiamata diretta al widget:
        # scrivere su un QPlainTextEdit dal thread secondario fa morire QGIS
        # senza alcun messaggio.
        self._scr_worker.avanzamento.connect(self._log_screening)
        self._scr_worker.finito.connect(self._screening_finito)
        self._scr_in_corso = True
        self.btn_scr_avvia.setEnabled(False)
        self.btn_scr_annulla.setEnabled(True)
        QApplication.setOverrideCursor(Qt.BusyCursor)
        self._scr_thread.start()

    def _annulla_screening(self):
        """Chiede al worker di fermarsi al primo punto utile.

        Il thread non viene ucciso: interrompere una socket a metà lascerebbe
        QGIS in uno stato incoerente. Si alza un flag che il modulo di
        screening legge prima di ogni richiesta di rete."""
        worker = getattr(self, "_scr_worker", None)
        if worker is None:
            return
        self.btn_scr_annulla.setEnabled(False)
        worker.chiedi_annullamento()
        self._log_screening("")
        self._log_screening("Annullamento richiesto: mi fermo appena la "
                            "richiesta già aperta si chiude.")

    def _chiudi_thread_screening(self, attesa_ms=5000):
        """Spegne il thread secondario e ne rilascia gli oggetti.

        L'attesa è limitata: un `wait()` senza scadenza nel thread
        dell'interfaccia riprodurrebbe esattamente il blocco che si vuole
        togliere. Ritorna True solo se il thread è davvero terminato."""
        th = getattr(self, "_scr_thread", None)
        if th is None:
            return True
        th.quit()
        terminato = th.wait(attesa_ms)
        if terminato:
            try:
                if self._scr_worker is not None:
                    self._scr_worker.deleteLater()
                th.deleteLater()
            except RuntimeError as e:
                _log_avviso("rilascio del thread di screening", e)
            self._scr_thread = None
            self._scr_worker = None
        return terminato

    def _ripristina_interfaccia_screening(self):
        """Riporta il pannello allo stato di riposo per OGNI via d'uscita
        (fine, errore, annullamento): senza questo il pulsante Avvia resterebbe
        spento e il cursore d'attesa acceso finché non si chiude QGIS."""
        self._scr_in_corso = False
        try:
            QApplication.restoreOverrideCursor()
        except Exception as e:
            _log_avviso("ripristino del cursore dopo lo screening", e)
        try:
            self.btn_scr_annulla.setEnabled(False)
            self.btn_scr_avvia.setEnabled(True)
        except RuntimeError as e:       # finestra già distrutta
            _log_avviso("riabilitazione dei pulsanti dello screening", e)

    def _screening_finito(self, rep, errore):
        """Completamento nel thread dell'interfaccia.

        Da qui in avanti si creano layer, si scrivono file e si mostrano
        messaggi: tutte cose che toccano QGIS e i widget, quindi devono stare
        nel thread principale."""
        ctx = getattr(self, "_scr_contesto", {}) or {}
        scr = ctx.get("scr")
        usa_tracciato = ctx.get("usa_tracciato", False)
        traccia_nome = ctx.get("traccia_nome")
        nome_area = ctx.get("nome_area")
        area_shapely = ctx.get("area")
        arlo_zone = ctx.get("arlo_zone")
        # il lavoro lento è finito: il log può tornare a usare processEvents
        # per i cicli lunghi che seguono (caricamento dei layer in mappa)
        self._scr_in_corso = False
        self._chiudi_thread_screening()

        if errore:
            self._log_screening("ERRORE: %s" % errore)
            self._ripristina_interfaccia_screening()
            return
        if rep is None:
            self._log_screening("ERRORE: nessun report prodotto.")
            self._ripristina_interfaccia_screening()
            return
        if rep.get("annullato"):
            # Risultati parziali: niente layer, niente report, niente Excel.
            # Un report incompleto che sembra completo è il falso negativo
            # peggiore, perché finisce davanti a un ente.
            self._log_screening("")
            self._log_screening(
                "Screening ANNULLATO dall'utente: i risultati sono parziali, "
                "quindi non carico layer e non salvo né report né Excel.")
            self._ripristina_interfaccia_screening()
            return

        try:
            if rep.get("errore"):
                self._log_screening("ERRORE: %s" % rep["errore"])
                QMessageBox.warning(self, "Screening non riuscito", rep["errore"])
                return


            # attribuzione ARLO AREA: assegna a ogni strada/vincolo/interferenza
            # la/le zona/e ARLO che tocca (colonna nel report ed Excel)
            if arlo_zone:
                try:
                    scr.attribuisci_arlo(rep, arlo_zone)
                    rep["_arlo_infra"] = self._infra_per_arlo(arlo_zone)
                    self._log_screening("")
                    self._log_screening("Attribuzione ARLO AREA completata (%d zone)." % len(arlo_zone))
                except Exception as e:
                    _log_avviso("attribuzione ARLO ai vincoli", e)

            if rep.get("warning"):
                self._log_screening("")
                self._log_screening("Warning (%d):" % len(rep["warning"]))
                for wmsg in rep["warning"]:
                    self._log_screening("  ⚠ %s" % wmsg)

            # -- Armadi ottici (manufatti fuori terra) vs vincoli paesaggistici --
            # Legge i punti dal layer '01_ARMADIO OTTICO' del progetto e verifica
            # per ciascuno la sovrapposizione con 136/142 (Soprintendenza) e con
            # gli UCP regionali (Città consolidata PPTR → Regione/Comune).
            try:
                armadi = self._raccogli_armadi(area_shapely if area_shapely is not None else None)
                if armadi:
                    res_arm = scr.analizza_armadi(
                        armadi, rep.get("_geometrie_vincoli"),
                        ucp_puglia=rep.get("_ucp_puglia_geoms"))
                    rep["armadi_analisi"] = res_arm
                    n_vinc = sum(1 for a in res_arm if a["vincolato"])
                    self._log_screening("")
                    self._log_screening(
                        "── Armadi ottici: %d totali, %d in area tutelata ──"
                        % (len(res_arm), n_vinc))
                    for a in res_arm:
                        if a["vincolato"]:
                            self._log_screening(
                                "  %s [%s]: %s" % (a["id"], a["tipo"], a["competenza"]))
                else:
                    self._log_screening("")
                    self._log_screening(
                        "Armadi ottici: layer '01_ARMADIO OTTICO' assente o vuoto "
                        "(analisi armadi saltata).")
            except Exception as e:  # noqa: BLE001
                _log_avviso("analisi armadi ottici", e)
                self._log_screening("Analisi armadi non riuscita: %s" % e)

            self._log_screening("")
            self._log_screening("── Enti da interpellare ──")
            for i, ente in enumerate(rep["enti"], 1):
                self._log_screening("%d. %s — %s" % (i, ente["ente"], ente["ruolo"]))
                if ente.get("trigger") and ente["trigger"] != "sempre":
                    self._log_screening("   perché: %s" % ente["trigger"])
                pec = (ente.get("contatti") or {}).get("pec")
                if pec:
                    self._log_screening("   PEC: %s" % pec)

            if self.chk_scr_report.isChecked():
                percorso = self._percorso_report_screening(rep["comune"]["nome"])
                with open(percorso, "w", encoding="utf-8") as fh:
                    fh.write(scr.to_markdown(rep))
                self._ultimo_report_screening = percorso
                self._log_screening("")
                self._log_screening("Report salvato: %s" % percorso)

            if self.chk_scr_xlsx.isChecked():
                try:
                    percorso_x = os.path.splitext(
                        self._percorso_report_screening(rep["comune"]["nome"]))[0] + ".xlsx"
                    scr.esporta_xlsx(rep, percorso_x, nome_area=(traccia_nome if usa_tracciato else nome_area))
                    self._ultimo_xlsx_screening = percorso_x
                    self._log_screening("Report Excel salvato: %s" % percorso_x)
                except Exception as e:
                    _log_avviso("export xlsx screening", e)
                    self._log_screening("Export Excel non riuscito: %s" % e)

                # shapefile permanente dei vincoli SITAP intercettati (art.136,
                # art.142, boschi, fasce fluviali, ...): accanto all'Excel, per la
                # verifica in mappa senza dipendere dal servizio SITAP online.
                try:
                    percorso_shp = self._salva_shp_vincoli(scr, rep)
                    if percorso_shp:
                        self._log_screening("Shapefile vincoli SITAP salvato: %s" % percorso_shp)
                    else:
                        self._log_screening("Shapefile vincoli: nessun vincolo SITAP intercettato, non generato.")
                except Exception as e:
                    _log_avviso("export shapefile vincoli", e)
                    self._log_screening("Export shapefile vincoli non riuscito: %s" % e)

            if self.chk_scr_layer.isChecked():
                self._carica_layer_screening(scr, rep)

            if self.chk_scr_shp.isChecked():
                try:
                    self._esporta_shape_tavole(scr, rep)
                except Exception as e:
                    _log_avviso("export shape+stili tavole", e)
                    self._log_screening("Export shape per le tavole non riuscito: %s" % e)
        except Exception as e:
            _log_avviso("composizione esito screening", e)
            self._log_screening("ERRORE nella composizione dell'esito: %s" % e)
        finally:
            self._ripristina_interfaccia_screening()

    def _raccogli_armadi(self, area_shapely=None):
        """Legge i punti dal layer '01_ARMADIO OTTICO' del progetto e ritorna una
        lista di dict {id, tipo, indirizzo, civico, lon, lat} in WGS84.
        Se area_shapely è dato (modalità ARLO), tiene solo gli armadi nell'area.
        Ritorna [] se il layer manca o è vuoto (progetti di altri service senza
        armadi funzionano lo stesso: l'analisi armadi viene semplicemente saltata).
        """
        from qgis.core import (QgsCoordinateReferenceSystem,
                                QgsCoordinateTransform, QgsProject)
        lyr = self._find_layer("01_ARMADIO OTTICO") or self._find_layer("ARMADIO OTTICO")
        if lyr is None or not lyr.isValid() or lyr.featureCount() == 0:
            return []
        crs_dst = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(lyr.crs(), crs_dst, QgsProject.instance())
        campi = [f.name() for f in lyr.fields()]
        def _get(f, *nomi):
            for n in nomi:
                if n in campi and f[n] not in (None, ""):
                    return f[n]
            return ""
        armadi = []
        for i, f in enumerate(lyr.getFeatures()):
            g = f.geometry()
            if g is None or g.isEmpty():
                continue
            pt = g.asPoint() if g.type() == 0 else g.centroid().asPoint()
            try:
                p = tr.transform(pt)
            except Exception:  # noqa: BLE001
                continue
            from shapely.geometry import Point as _P
            if area_shapely is not None and not area_shapely.contains(_P(p.x(), p.y())):
                continue
            idv = _get(f, "ID_ARMADIO", "ID_ARMAD", "OBJECTID")
            ind_raw = _get(f, "INDIRIZZO", "VIA")
            civ_raw = _get(f, "CIVICO", "CIV")
            ind, civ = self._pulisci_indirizzo_armadio(ind_raw, civ_raw)
            armadi.append({
                "id": ("AO-%s" % idv) if idv else ("AO-%d" % i),
                "tipo": _get(f, "TIPO_ARMAD", "TIPO", "TIPO_ARMADIO"),
                "indirizzo": ind,
                "civico": civ,
                "lon": p.x(), "lat": p.y(),
            })
        return armadi

    @staticmethod
    def _pulisci_indirizzo_armadio(indirizzo, civico):
        """Normalizza gli indirizzi degli armadi, spesso sporchi nel LLD:
        - 'VIAROMA' -> 'VIA ROMA' (spazio dopo la DUG attaccata)
        - 'VIAPALAZZOLO29VIAPALAZZOLO' -> 'VIA PALAZZOLO' (dedup del testo ripetuto)
        - civico '9999'/'999'/'0' placeholder -> 'SNC'
        Ritorna (indirizzo_pulito, civico_pulito). Non inventa dati: si limita a
        formattare ciò che c'è.
        """
        import re as _re
        ind = str(indirizzo or "").strip()
        civ = str(civico or "").strip()
        # civico placeholder -> SNC
        if civ in ("9999", "999", "0", "00", ""):
            civ = "SNC" if civ in ("9999", "999") else civ
        # dedup: 'VIAPALAZZOLO29VIAPALAZZOLO' -> tieni la prima occorrenza della DUG
        low = ind.upper()
        for dug in ("VIALE", "VIA", "PIAZZALE", "PIAZZA", "LARGO", "CORSO",
                    "VICOLO", "LOCALITA'", "LOCALITA", "STRADA", "CONTRADA"):
            pos = low.find(dug, 1)
            if pos > 0 and low[:pos].replace(" ", "").startswith(dug.replace(" ", "")[:3]):
                ind = ind[:pos].strip()
                low = ind.upper()
                break
        # rimuovi un eventuale civico incollato in coda all'indirizzo (es. '...29')
        if civ and civ != "SNC":
            ind = _re.sub(r"\s*%s\s*$" % _re.escape(civ), "", ind).strip()
        # togli cifre residue attaccate in coda alla via (es. 'PALAZZOLO29' -> 'PALAZZOLO')
        ind = _re.sub(r"(?<=[A-Za-zÀ-ù])\d{1,4}$", "", ind).strip()
        # inserisci lo spazio dopo la DUG attaccata: 'VIAROMA' -> 'VIA ROMA'
        for dug in ("VIALE", "PIAZZALE", "LOCALITA'", "CONTRADA", "VICOLO",
                    "LARGO", "CORSO", "STRADA", "PIAZZA", "VIA"):
            m = _re.match(r"^(%s)([A-ZÀ-Ù].*)$" % dug, ind, _re.IGNORECASE)
            if m and not ind[len(dug):len(dug) + 1].isspace():
                ind = "%s %s" % (m.group(1), m.group(2))
                break
        # normalizza spazi multipli
        ind = _re.sub(r"\s+", " ", ind).strip()
        return ind, civ

    def _salva_shp_vincoli(self, scr, rep):
        """Salva i vincoli SITAP intercettati come shapefile PERMANENTE accanto
        all'Excel dello screening. Ritorna il percorso .shp, o None se non ci
        sono vincoli. Le geometrie sono in EPSG:4326 (come SITAP).

        Le geometrie SITAP possono essere GeometryCollection (non supportate dal
        formato shapefile): estraiamo solo le componenti poligonali e le
        normalizziamo a MultiPolygon, così lo shapefile è scrivibile e apribile
        in qualsiasi GIS."""
        collezione = scr.geojson_vincoli(rep.get("_geometrie_vincoli"))
        if not collezione.get("features"):
            return None
        # normalizza ogni geometria a (Multi)Polygon: scarta punti/linee spuri e
        # scompone le GeometryCollection tenendo solo i poligoni
        from shapely.geometry import shape as _shape, mapping as _mapping
        from shapely.geometry import MultiPolygon, Polygon
        from shapely.ops import unary_union as _uu
        feats_poly = []
        for feat in collezione["features"]:
            try:
                g = _shape(feat["geometry"])
            except Exception:  # noqa: BLE001
                continue
            polys = []
            if g.geom_type == "Polygon":
                polys = [g]
            elif g.geom_type == "MultiPolygon":
                polys = list(g.geoms)
            elif g.geom_type == "GeometryCollection":
                polys = [p for p in g.geoms if p.geom_type in ("Polygon", "MultiPolygon")]
            if not polys:
                continue
            mp = _uu(polys)
            if mp.is_empty:
                continue
            if mp.geom_type == "Polygon":
                mp = MultiPolygon([mp])
            feats_poly.append({"type": "Feature",
                               "properties": feat.get("properties", {}),
                               "geometry": _mapping(mp)})
        if not feats_poly:
            return None
        coll_poly = {"type": "FeatureCollection", "features": feats_poly}
        import tempfile
        cartella = tempfile.mkdtemp(prefix="ftth_vincoli_")
        gj = os.path.join(cartella, "vincoli.geojson")
        with open(gj, "w", encoding="utf-8") as fh:
            json.dump(coll_poly, fh)
        sorgente = QgsVectorLayer(gj, "vincoli_tmp", "ogr")
        if not sorgente.isValid():
            raise RuntimeError("GeoJSON dei vincoli non caricabile")
        base = os.path.splitext(
            self._percorso_report_screening(rep["comune"]["nome"]))[0]
        percorso = base + "_vincoli_SITAP.shp"
        opzioni = QgsVectorFileWriter.SaveVectorOptions()
        opzioni.driverName = "ESRI Shapefile"
        opzioni.fileEncoding = "UTF-8"
        opzioni.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        errore = QgsVectorFileWriter.writeAsVectorFormatV3(
            sorgente, percorso, self.project.transformContext(), opzioni)
        codice = errore[0] if isinstance(errore, tuple) else errore
        if codice != QgsVectorFileWriter.NoError:
            dettaglio = (errore[1] if isinstance(errore, tuple) and len(errore) > 1
                         else str(errore))
            raise RuntimeError("Scrittura shapefile fallita: %s" % dettaglio)
        controllo = QgsVectorLayer(percorso, "controllo_vincoli", "ogr")
        if not controllo.isValid() or controllo.featureCount() == 0:
            raise RuntimeError("Shapefile dei vincoli non rileggibile o vuoto")
        return percorso

    def _carica_layer_screening(self, scr, rep):
        """Carica i risultati come layer in un gruppo 'Screening <comune>'.

        I layer nascono da GeoJSON scritti in file temporanei e caricati con il
        provider ogr: un layer 'memory' costruito feature per feature sarebbe
        più elegante ma il giro dal GeoJSON riusa la serializzazione già
        testata fuori da QGIS e mantiene questo metodo un semplice adattatore."""
        import tempfile
        nome_comune = rep["comune"]["nome"]
        nome_gruppo = "Screening %s" % nome_comune
        radice = self.project.layerTreeRoot()
        esistente = radice.findGroup(nome_gruppo)
        if esistente is not None:
            radice.removeChildNode(esistente)
        gruppo = radice.insertGroup(0, nome_gruppo)

        # Il report elenca le strade usando i soli nomi; i layer hanno bisogno
        # delle geometrie, che vengono scaricate solo se lo screening e' stato
        # lanciato chiedendole. Se mancano, prima il layer spariva in silenzio
        # (finiva una riga nel log) e sul report restavano SP e SS senza nessun
        # disegno a cui corrispondere: su una pratica di permesso e' un
        # fraintendimento che costa caro.
        # Overpass irraggiungibile: nessuna strada arriva, quindi nemmeno il
        # report ne elenca. Senza questo avviso il risultato è identico a
        # "in questo comune non ci sono strade classificate" — che è falso, e
        # su una pratica di permesso porta a dire all'ente la cosa sbagliata.
        # Misurato su Fabrica di Roma: un giro a vuoto, quello dopo 73 elementi.
        err_strade = next((f.get("errore") for f in (rep.get("fonti") or [])
                           if f.get("stadio") == "rete stradale" and f.get("errore")), None)
        if err_strade:
            self._log_screening("ATTENZIONE: rete stradale NON letta (%s)" % err_strade)
            QMessageBox.warning(
                self, "Rete stradale non letta",
                "Non è stato possibile leggere la rete stradale da "
                "OpenStreetMap: i server pubblici non hanno risposto.\n\n"
                "Questo NON significa che il comune non abbia strade "
                "classificate: significa che non si è potuto verificarlo. Il "
                "layer «Strade classificate» resta vuoto e il report non le "
                "elenca.\n\nRilancia lo screening fra qualche minuto.\n\n"
                "Dettaglio: %s" % err_strade)
        elif rep.get("rete_stradale") and not rep.get("_elementi_strade"):
            elencate = sorted(r for refs in rep["rete_stradale"].values() for r in refs)
            self._log_screening("ATTENZIONE: strade nel report (%s) ma nessuna "
                                "geometria scaricata: layer non creato."
                                % ", ".join(elencate))
            QMessageBox.warning(
                self, "Strade senza geometrie",
                "Il report elenca %d strade classificate (%s), ma le geometrie "
                "non sono state scaricate: il layer «Strade classificate» non "
                "verrà creato.\n\nRilancia lo screening con la creazione dei "
                "layer attiva per ottenere anche i tracciati."
                % (len(elencate), ", ".join(elencate[:6])
                   + ("…" if len(elencate) > 6 else "")))

        cartella = tempfile.mkdtemp(prefix="ftth_screening_")
        blocchi = [
            ("Confine comunale",       scr.geojson_comune(rep)),
            ("Strade classificate",    scr.geojson_strade(rep.get("_elementi_strade"), rep)),
            ("Vincoli SITAP",          scr.geojson_vincoli(rep.get("_geometrie_vincoli"))),
            ("Ferrovie e corsi acqua", scr.geojson_lineari(rep.get("_elementi_lineari"))),
        ]
        caricati = 0
        for nome, collezione in blocchi:
            if not collezione["features"]:
                self._log_screening("layer '%s': nessuna geometria, saltato" % nome)
                continue
            percorso = os.path.join(
                cartella, re.sub(r"[^0-9A-Za-z]+", "_", nome).lower() + ".geojson")
            with open(percorso, "w", encoding="utf-8") as fh:
                json.dump(collezione, fh)
            layer = QgsVectorLayer(percorso, "%s — %s" % (nome, nome_comune), "ogr")
            if not layer.isValid():
                self._log_screening("layer '%s': caricamento non riuscito" % nome)
                continue
            self.project.addMapLayer(layer, False)
            gruppo.addLayer(layer)
            caricati += 1
            self._log_screening("layer '%s': %d elementi" % (nome, layer.featureCount()))
        self._log_screening("Gruppo '%s': %d layer caricati." % (nome_gruppo, caricati))

        # zoom sul comune (le geometrie sono in EPSG:4326: serve trasformarle
        # nel CRS del progetto, altrimenti l'estensione finisce nel posto sbagliato)
        try:
            bbox = rep["comune"]["bbox"]  # [S, N, W, E]
            rett = QgsRectangle(bbox[2], bbox[0], bbox[3], bbox[1])
            tr = QgsCoordinateTransform(
                QgsCoordinateReferenceSystem("EPSG:4326"),
                self.project.crs(), self.project)
            self.iface.mapCanvas().setExtent(tr.transformBoundingBox(rett))
            self.iface.mapCanvas().refresh()
        except Exception as e:
            _log_avviso("zoom sul comune dello screening", e)

    def _esporta_shape_tavole(self, scr, rep):
        """Genera shape permanenti + un GeoPackage con TUTTI i dati analizzati e
        applica stili QGIS categorizzati (per stato/tipo), pronti per le tavole.

        Output accanto all'Excel: cartella '<comune>_Screening_SHP/' con uno .shp
        per tipo + '<comune>_screening.gpkg' con tutti i layer. Gli stili sono
        salvati come .qml accanto a ogni shape e applicati ai layer caricati in
        mappa nel gruppo 'Screening <comune>'."""
        from qgis.core import (QgsVectorLayer, QgsVectorFileWriter, QgsField,
                               QgsCoordinateReferenceSystem, QgsSymbol,
                               QgsRendererCategory, QgsCategorizedSymbolRenderer,
                               QgsSimpleFillSymbolLayer, QgsSimpleLineSymbolLayer,
                               QgsPalLayerSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)
        from qgis.PyQt.QtGui import QColor, QFont
        import tempfile

        base_dir = os.path.dirname(
            self._percorso_report_screening(rep["comune"]["nome"]))
        nome_comune = rep["comune"]["nome"]
        safe = re.sub(r"[^0-9A-Za-z]+", "_", nome_comune).strip("_")
        shp_dir = os.path.join(base_dir, "%s_Screening_SHP" % safe)
        os.makedirs(shp_dir, exist_ok=True)
        gpkg = os.path.join(base_dir, "%s_screening.gpkg" % safe)
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tmp = tempfile.mkdtemp(prefix="ftth_shp_")

        # blocchi: (nome_layer, collezione_geojson, funzione_stile)
        geoms_v = rep.get("_geometrie_vincoli")
        blocchi = [
            ("Confine comunale", scr.geojson_comune(rep), self._stile_confine),
            ("Strade classificate", scr.geojson_strade(rep.get("_elementi_strade"), rep), self._stile_strade),
            ("Vincoli SITAP", scr.geojson_vincoli_sitap(geoms_v), self._stile_vincoli),
            ("Rete Natura 2000", scr.geojson_natura2000(geoms_v), self._stile_natura2000),
            ("Aree protette (parchi)", scr.geojson_parchi(geoms_v), self._stile_parchi),
            ("Aree boscate art.142g", scr.geojson_boschi(geoms_v), self._stile_boschi),
            ("Fasce art.142 costa-fiumi", scr.geojson_fasce142(geoms_v), self._stile_fasce142),
            ("Ferrovie e corsi acqua", scr.geojson_lineari(rep.get("_elementi_lineari")), self._stile_lineari),
            ("Armadi ottici", scr.geojson_armadi(rep.get("armadi_analisi")), self._stile_armadi),
        ]

        radice = self.project.layerTreeRoot()
        nome_gruppo = "Screening %s (tavole)" % nome_comune
        esistente = radice.findGroup(nome_gruppo)
        if esistente is not None:
            radice.removeChildNode(esistente)
        gruppo = radice.insertGroup(0, nome_gruppo)

        prodotti = []
        primo_gpkg = True
        for nome, collezione, fn_stile in blocchi:
            if not collezione.get("features"):
                continue
            gj = os.path.join(tmp, re.sub(r"[^0-9A-Za-z]+", "_", nome).lower() + ".geojson")
            with open(gj, "w", encoding="utf-8") as fh:
                json.dump(collezione, fh)
            src = QgsVectorLayer(gj, nome, "ogr")
            if not src.isValid() or src.featureCount() == 0:
                continue
            # 1) shapefile singolo
            shp_path = os.path.join(shp_dir, "%s_%s.shp" % (safe, re.sub(r"[^0-9A-Za-z]+", "_", nome).lower()))
            opt = QgsVectorFileWriter.SaveVectorOptions()
            opt.driverName = "ESRI Shapefile"
            opt.fileEncoding = "UTF-8"
            opt.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            QgsVectorFileWriter.writeAsVectorFormatV3(src, shp_path, self.project.transformContext(), opt)
            # 2) layer nel GeoPackage (stesso file, un layer per blocco)
            opt_g = QgsVectorFileWriter.SaveVectorOptions()
            opt_g.driverName = "GPKG"
            opt_g.layerName = re.sub(r"[^0-9A-Za-z]+", "_", nome).lower()
            opt_g.fileEncoding = "UTF-8"
            opt_g.actionOnExistingFile = (
                QgsVectorFileWriter.CreateOrOverwriteFile if primo_gpkg
                else QgsVectorFileWriter.CreateOrOverwriteLayer)
            QgsVectorFileWriter.writeAsVectorFormatV3(src, gpkg, self.project.transformContext(), opt_g)
            primo_gpkg = False
            # 3) carica lo shape permanente in mappa e applica lo stile
            lyr = QgsVectorLayer(shp_path, "%s — %s" % (nome, nome_comune), "ogr")
            if lyr.isValid():
                try:
                    fn_stile(lyr)
                except Exception as e:  # noqa: BLE001
                    _log_avviso("stile layer %s" % nome, e)
                # salva lo stile come .qml accanto allo shape (riusabile)
                try:
                    lyr.saveNamedStyle(os.path.splitext(shp_path)[0] + ".qml")
                except Exception:  # noqa: BLE001
                    pass
                self.project.addMapLayer(lyr, False)
                gruppo.addLayer(lyr)
            prodotti.append(nome)

        self._log_screening("")
        self._log_screening("Shape+GeoPackage per le tavole: %d layer in %s" % (len(prodotti), shp_dir))
        self._log_screening("GeoPackage: %s" % gpkg)
        return shp_dir

    # ---- stili QGIS per i layer dello screening (tavole) ----
    def _stile_confine(self, layer):
        from qgis.core import QgsSimpleLineSymbolLayer, QgsFillSymbol
        from qgis.PyQt.QtGui import QColor
        from qgis.PyQt.QtCore import Qt
        sym = QgsFillSymbol.createSimple({"style": "no", "outline_color": "0,0,0,255",
                                          "outline_width": "0.6", "outline_style": "dash"})
        layer.renderer().setSymbol(sym)
        layer.triggerRepaint()

    def _stile_strade(self, layer):
        """Categorizzato per 'stato': attraversamento=rosso, entro fascia=arancione,
        fuori fascia=grigio, n.d.=blu. Con etichetta ref (SP88…)."""
        from qgis.core import (QgsLineSymbol, QgsRendererCategory,
                               QgsCategorizedSymbolRenderer)
        mapping = [
            ("attraversamento", "#d7191c", 1.1, "Attraversamento"),
            ("entro fascia",    "#fdae61", 0.9, "Entro fascia di rispetto"),
            ("fuori fascia",    "#999999", 0.5, "Fuori fascia"),
            ("n.d.",            "#2c7fb8", 0.5, "Non determinato"),
        ]
        cats = []
        for val, col, w, lab in mapping:
            s = QgsLineSymbol.createSimple({"line_color": col, "line_width": str(w)})
            cats.append(QgsRendererCategory(val, s, lab))
        layer.setRenderer(QgsCategorizedSymbolRenderer("stato", cats))
        self._applica_etichetta(layer, "ref", dim=8, bold=True, colore="#000000")
        layer.triggerRepaint()

    def _stile_vincoli(self, layer):
        """Categorizzato per tipo di vincolo (etichetta 'vincolo'), semi-trasparente."""
        from qgis.core import (QgsFillSymbol, QgsRendererCategory,
                               QgsCategorizedSymbolRenderer)
        # colori per parola chiave nell'etichetta
        regole = [
            ("136", "#8856a7"),   # decretato art.136 viola
            ("142", "#e6550d"),   # ex lege art.142 arancio
            ("UNESCO", "#dd1c77"),
            ("bosc", "#31a354"),
            ("zone umide", "#2b8cbe"),
        ]
        vals = sorted({f["vincolo"] for f in layer.getFeatures()})
        cats = []
        for v in vals:
            col = "#756bb1"
            for chiave, c in regole:
                if chiave.lower() in str(v).lower():
                    col = c; break
            s = QgsFillSymbol.createSimple({"color": col, "style": "solid",
                                            "outline_color": col, "outline_width": "0.3"})
            s.setOpacity(0.45)
            cats.append(QgsRendererCategory(v, s, str(v)[:40]))
        if cats:
            layer.setRenderer(QgsCategorizedSymbolRenderer("vincolo", cats))
        layer.triggerRepaint()

    def _stile_natura2000(self, layer):
        """SIC/ZSC verde, ZPS verde-azzurro, tratteggio, etichetta codice."""
        from qgis.core import (QgsFillSymbol, QgsRendererCategory,
                               QgsCategorizedSymbolRenderer, QgsPalLayerSettings,
                               QgsTextFormat, QgsVectorLayerSimpleLabeling,
                               QgsTextBufferSettings)
        from qgis.PyQt.QtGui import QColor, QFont
        campo = "vincolo"
        nomi = [f.name() for f in layer.fields()]
        if "vincolo" not in nomi and "codice" in nomi:
            campo = "codice"
        vals = sorted({(f[campo] if f[campo] is not None else "") for f in layer.getFeatures()})
        cats = []
        for v in vals:
            col = "#1a9850" if "Habitat" in str(v) or "SIC" in str(v) or "ZSC" in str(v) else "#66c2a5"
            s = QgsFillSymbol.createSimple({"color": col, "style": "b_diagonal",
                                            "outline_color": col, "outline_width": "0.4"})
            s.setOpacity(0.5)
            cats.append(QgsRendererCategory(v, s, str(v)[:40]))
        if cats:
            layer.setRenderer(QgsCategorizedSymbolRenderer(campo, cats))
        # etichetta codice se presente
        if "codice" in nomi:
            self._applica_etichetta(layer, "codice", dim=7, bold=True,
                                    colore="#1a6b30", linea=False)
        layer.triggerRepaint()

    def _stile_parchi(self, layer):
        """Aree protette (parchi): verde bosco semi-trasparente, bordo marcato,
        etichetta col nome del parco."""
        from qgis.core import QgsFillSymbol
        from qgis.PyQt.QtGui import QColor
        sym = QgsFillSymbol.createSimple({"color": "#238b45", "style": "diagonal_x",
                                          "outline_color": "#00441b",
                                          "outline_width": "0.6"})
        sym.setOpacity(0.45)
        layer.renderer().setSymbol(sym)
        nomi = [f.name() for f in layer.fields()]
        campo = "nome" if "nome" in nomi else ("vincolo" if "vincolo" in nomi else None)
        if campo:
            self._applica_etichetta(layer, campo, dim=8, bold=True,
                                    colore="#00441b", linea=False)
        layer.triggerRepaint()

    def _stile_boschi(self, layer):
        """Aree boscate (art.142 lett.g): verde oliva punteggiato, semi-trasparente."""
        from qgis.core import QgsFillSymbol
        sym = QgsFillSymbol.createSimple({"color": "#74c476", "style": "dense4",
                                          "outline_color": "#006d2c",
                                          "outline_width": "0.5"})
        sym.setOpacity(0.5)
        layer.renderer().setSymbol(sym)
        nomi = [f.name() for f in layer.fields()]
        if "nome" in nomi:
            self._applica_etichetta(layer, "nome", dim=7, bold=False,
                                    colore="#006d2c", linea=False)
        layer.triggerRepaint()

    def _stile_fasce142(self, layer):
        """Fasce art.142 costa (300 m) e fiumi (150 m): categorizzato per tipo, blu
        per la costa, azzurro per i fiumi, semi-trasparente con etichetta."""
        from qgis.core import (QgsFillSymbol, QgsRendererCategory,
                               QgsCategorizedSymbolRenderer)
        vals = sorted({(f["vincolo"] if f["vincolo"] is not None else "") for f in layer.getFeatures()})
        cats = []
        for v in vals:
            col = "#2166ac" if "costier" in str(v).lower() or "costa" in str(v).lower() else "#4393c3"
            s = QgsFillSymbol.createSimple({"color": col, "style": "solid",
                                            "outline_color": col, "outline_width": "0.4"})
            s.setOpacity(0.4)
            cats.append(QgsRendererCategory(v, s, str(v)[:45]))
        if cats:
            layer.setRenderer(QgsCategorizedSymbolRenderer("vincolo", cats))
        layer.triggerRepaint()

    def _stile_armadi(self, layer):
        """Armadi ottici: marker quadrato categorizzato per stato paesaggistico.
        Rosso = Soprintendenza (136/142), ambra = Regione/Comune (UCP),
        verde = nessun vincolo. Etichetta con l'id armadio."""
        from qgis.core import (QgsMarkerSymbol, QgsRendererCategory,
                               QgsCategorizedSymbolRenderer)
        colori = {
            "Soprintendenza (art.136/142)": "#d7191c",
            "Regione/Comune (UCP)": "#fdae61",
            "nessun vincolo": "#1a9641",
        }
        cats = []
        for stato, col in colori.items():
            s = QgsMarkerSymbol.createSimple({
                "name": "square", "color": col, "size": "3.2",
                "outline_color": "#000000", "outline_width": "0.4"})
            cats.append(QgsRendererCategory(stato, s, stato))
        layer.setRenderer(QgsCategorizedSymbolRenderer("stato", cats))
        self._applica_etichetta(layer, "id", dim=8, bold=True,
                                colore="#000000", linea=False)
        layer.triggerRepaint()

    def _applica_etichetta(self, layer, campo, dim=8, bold=False, colore="#000000", linea=True):
        """Attiva un'etichetta semplice sul campo dato, con alone bianco per
        leggibilità sopra l'ortofoto. Usata da strade, ferrovie/acque, Natura 2000.
        linea=True fa seguire l'andamento della linea; False = posizione libera
        (per i poligoni: al centro/attorno)."""
        from qgis.core import (QgsPalLayerSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling, QgsTextBufferSettings)
        from qgis.PyQt.QtGui import QColor, QFont
        try:
            pal = QgsPalLayerSettings()
            pal.fieldName = campo
            pal.enabled = True
            try:
                pal.placement = (QgsPalLayerSettings.Line if linea
                                 else QgsPalLayerSettings.AroundPoint)
            except Exception:  # noqa: BLE001
                pass
            tf = QgsTextFormat()
            f = QFont("Segoe UI"); f.setPointSize(dim); f.setBold(bold)
            tf.setFont(f); tf.setColor(QColor(colore))
            buf = QgsTextBufferSettings(); buf.setEnabled(True); buf.setSize(0.9)
            buf.setColor(QColor("white")); tf.setBuffer(buf)
            pal.setFormat(tf)
            layer.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            layer.setLabelsEnabled(True)
        except Exception as e:  # noqa: BLE001
            _log_avviso("etichetta layer %s" % campo, e)

    def _stile_lineari(self, layer):
        """Ferrovie nero tratto-punto, corsi d'acqua azzurro, ex sedime grigio.
        Con etichetta del nome (o del tipo se il nome manca)."""
        from qgis.core import (QgsLineSymbol, QgsRendererCategory,
                               QgsCategorizedSymbolRenderer)
        mapping = [
            ("ferrovia", "#000000", 0.8),
            ("ex sedime ferroviario", "#888888", 0.6),
            ("corso d'acqua", "#2b8cbe", 0.7),
        ]
        cats = []
        for val, col, w in mapping:
            s = QgsLineSymbol.createSimple({"line_color": col, "line_width": str(w)})
            cats.append(QgsRendererCategory(val, s, val))
        layer.setRenderer(QgsCategorizedSymbolRenderer("tipo", cats))
        # etichetta: nome della ferrovia/corso d'acqua (blu scuro per l'acqua? uniforme nero)
        self._applica_etichetta(layer, "etichetta", dim=8, bold=False, colore="#204060")
        layer.triggerRepaint()

    def _zone_arlo(self, layer):
        """Ritorna [(label, geometria_shapely_wgs84)] una per poligono ARLO,
        usando il campo etichetta (Label/Nome/…). I poligoni SENZA etichetta
        (Label vuoto/NULL) vengono SCARTATI dal conteggio ARLO: nel progetto
        dell'utente sono in genere artefatti che si sovrappongono a un'area
        etichettata, e falserebbero il numero di ARLO. Il numero di poligoni
        scartati è riportato in self._arlo_zone_scartate."""
        from shapely import wkt as _shp_wkt
        # individua il campo etichetta con tolleranza sui nomi comuni
        campo_lab = None
        nomi = [f.name() for f in layer.fields()]
        for cand in ("Label", "label", "LABEL", "Nome", "nome", "NOME",
                     "Area", "AREA", "id", "ID", "name"):
            if cand in nomi:
                campo_lab = cand
                break
        tr = QgsCoordinateTransform(
            layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), self.project)
        zone = []
        scartate = 0
        for i, feat in enumerate(layer.getFeatures(), 1):
            g = feat.geometry()
            if g is None or g.isEmpty():
                continue
            g = QgsGeometry(g)
            g.transform(tr)
            try:
                shp = _shp_wkt.loads(g.asWkt(8))
                if not shp.is_valid:
                    shp = shp.buffer(0)
            except Exception:  # noqa: BLE001
                continue
            lab = None
            if campo_lab:
                v = feat[campo_lab]
                lab = str(v).strip() if v not in (None, "") else None
            if not lab:
                scartate += 1   # poligono ARLO senza etichetta: non conta
                continue
            zone.append((lab, shp))
        self._arlo_zone_scartate = scartate
        return zone

    def _infra_per_arlo(self, arlo_zone):
        """Per ogni zona ARLO conta le infrastrutture di progetto che vi ricadono:
        tratte (03 INFRASTRUTTURE) con lunghezza totale e label, armadi
        (01_ARMADIO OTTICO), pozzetti (02_POZZETTO). Ritorna
        {label: {tratte_n, tratte_m, tratte_label[], armadi[], pozzetti_n}}."""
        from shapely import wkt as _shp_wkt
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")

        def _trova(nomi):
            for n in nomi:
                for ly in self.project.mapLayers().values():
                    if ly.name() == n and hasattr(ly, "getFeatures"):
                        return ly
            return None

        lyr_tratte = _trova(["03 INFRASTRUTTURE"])
        lyr_arm = _trova(["01_ARMADIO OTTICO", "01 ARMADIO OTTICO"])
        lyr_poz = _trova(["02_POZZETTO", "02 POZZETTO"])
        out = {lab: {"tratte_n": 0, "tratte_m": 0.0, "tratte_label": [],
                     "armadi": [], "pozzetti_n": 0} for lab, _ in arlo_zone}

        def _campo(layer, cands):
            nomi = [f.name() for f in layer.fields()]
            for c in cands:
                if c in nomi:
                    return c
            return None

        def _proc(layer, tipo):
            if layer is None or layer.featureCount() == 0:
                return
            tr = QgsCoordinateTransform(layer.crs(), wgs, self.project)
            c_lab = _campo(layer, ["LABEL", "Label", "ID_ARMADIO", "Etichette"])
            c_len = _campo(layer, ["LUNGHEZZA", "Lungh", "Chilometri"])
            for feat in layer.getFeatures():
                g = feat.geometry()
                if g is None or g.isEmpty():
                    continue
                g = QgsGeometry(g)
                g.transform(tr)
                try:
                    shp = _shp_wkt.loads(g.asWkt(7))
                except Exception:  # noqa: BLE001
                    continue
                for lab, z in arlo_zone:
                    try:
                        if not shp.intersects(z):
                            continue
                    except Exception:  # noqa: BLE001
                        continue
                    rec = out[lab]
                    if tipo == "tratta":
                        rec["tratte_n"] += 1
                        if c_len:
                            try:
                                rec["tratte_m"] += float(str(feat[c_len]).replace(",", "."))
                            except (ValueError, TypeError):
                                pass
                        if c_lab and feat[c_lab] not in (None, ""):
                            rec["tratte_label"].append(str(feat[c_lab]))
                    elif tipo == "armadio":
                        if c_lab and feat[c_lab] not in (None, ""):
                            rec["armadi"].append(str(feat[c_lab]))
                        else:
                            rec["armadi"].append("armadio")
                    elif tipo == "pozzetto":
                        rec["pozzetti_n"] += 1

        _proc(lyr_tratte, "tratta")
        _proc(lyr_arm, "armadio")
        _proc(lyr_poz, "pozzetto")
        return out

    def _costruisci_tracciato(self):
        """Unione geometrica di 03 INFRASTRUTTURE + 02_POZZETTO + 01_ARMADIO
        OTTICO in EPSG:4326, come tracciato di progetto per l'analisi puntuale.
        Ritorna (geometria_shapely, nome, n_elementi) o (None, None, 0) se non
        c'è alcun layer di rete nel progetto.

        Per 03 INFRASTRUTTURE si prendono SOLO le tratte con STATO='Nuovo': le
        infrastrutture Esistenti sono rete gia' posata, non oggetto del permesso,
        e includerle inquinerebbe l'analisi (attraversamenti/affiancamenti su reti
        vecchie). Pozzetti e armadi non hanno il campo STATO: restano tutti."""
        from shapely import wkt as _shp_wkt
        nomi = ["03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO"]
        parti = []
        usati = []
        n_tot = 0
        n_esistenti_scartate = 0
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        for nome in nomi:
            lyr = self._find_layer(nome)
            if lyr is None:
                continue
            # layer con sorgente/subset rotto (es. subset che referenzia un campo
            # inesistente come "SUOLO"): il layer nasce invalido e getFeatures()
            # non itera -> il tracciato resterebbe vuoto senza spiegazione. In quel
            # caso RICARICO il layer dalla sorgente pulita (senza il subset e senza
            # eventuali parametri che lo invalidano), così lo screening parte.
            def _sorgente_pulita(src):
                # toglie "|subset=..." e altri modificatori dopo il path del file
                return src.split("|")[0]
            if not lyr.isValid() or next(lyr.getFeatures(), None) is None:
                src0 = _sorgente_pulita(lyr.source())
                lyr2 = QgsVectorLayer(src0, nome, "ogr")
                if lyr2.isValid() and next(lyr2.getFeatures(), None) is not None:
                    self._log_screening(
                        "%s: il layer nel progetto ha un filtro/sorgente non valido "
                        "— ricaricato dalla sorgente (%s)." % (nome, os.path.basename(src0)))
                    lyr = lyr2
                else:
                    self._log_screening(
                        "%s: layer non leggibile (sorgente non valida) — saltato." % nome)
                    continue
            # filtro STATO=Nuovo solo su 03 INFRASTRUTTURE (se il campo esiste)
            filtra_stato = False
            campo_stato = None
            if nome == "03 INFRASTRUTTURE":
                nomi_campi = [f.name() for f in lyr.fields()]
                for cand in ("STATO", "Stato", "stato"):
                    if cand in nomi_campi:
                        campo_stato = cand
                        filtra_stato = True
                        break
            # PRIMO passaggio: se filtro STATO attivo, conta quante tratte sono
            # 'Nuovo'. Se il campo esiste ma è vuoto/valorizzato diversamente su
            # TUTTE le feature (progetti che non compilano STATO), filtrare
            # svuoterebbe il tracciato e lo screening non partirebbe: in quel caso
            # NON filtrare (meglio analizzare tutto che non analizzare niente).
            if filtra_stato:
                n_nuovo = sum(1 for f in lyr.getFeatures()
                              if f.hasGeometry() and f[campo_stato] is not None
                              and str(f[campo_stato]).strip().lower() == "nuovo")
                if n_nuovo == 0:
                    filtra_stato = False
                    self._log_screening(
                        "03 INFRASTRUTTURE: campo STATO senza tratte 'Nuovo' "
                        "(vuoto o non compilato) — analizzo tutte le tratte.")
            geoms = []
            for f in lyr.getFeatures():
                if not f.hasGeometry():
                    continue
                if filtra_stato:
                    val = f[campo_stato]
                    if val is None or str(val).strip().lower() != "nuovo":
                        n_esistenti_scartate += 1
                        continue
                geoms.append(f.geometry())
            if not geoms:
                continue
            g = QgsGeometry.unaryUnion(geoms)
            if lyr.crs() != wgs:
                tr = QgsCoordinateTransform(lyr.crs(), wgs, self.project)
                g.transform(tr)
            parti.append(g)
            usati.append(nome)
            n_tot += len(geoms)
        if not parti:
            return None, None, 0
        if n_esistenti_scartate:
            self._log_screening(
                "03 INFRASTRUTTURE: %d tratte Esistenti escluse (analisi su sole tratte Nuovo)."
                % n_esistenti_scartate)
        unito = QgsGeometry.unaryUnion(parti) if len(parti) > 1 else parti[0]
        shp = _shp_wkt.loads(unito.asWkt(8))
        return shp, " + ".join(usati), n_tot

    def _leggi_stradario(self, layer, campo, area_shapely, tracciato_wgs=None):
        """Estrae dallo stradario locale i record {ref, name, operator} dei
        tratti che intersecano l'area di progetto (se data) o tutto il layer.
        Ritorna (records, indipendente). indipendente=False se il layer è un
        estratto OSM (campo 'osm_id' presente): la controprova non varrebbe.

        Il filtro spaziale usa un QgsSpatialIndex sull'area riproiettata nel
        CRS del layer, così non si trasforma feature per feature."""
        from shapely import wkt as _shp_wkt
        nomi_campi = {f.name().lower() for f in layer.fields()}
        indipendente = "osm_id" not in nomi_campi

        # trova il campo denominazione e operatore se presenti (facoltativi)
        campo_nome = next((f.name() for f in layer.fields()
                           if f.name().lower() in {"name", "nome"} and f.name() != campo), None)
        campo_op = next((f.name() for f in layer.fields()
                         if f.name().lower() in {"operator", "ente_gesto", "gestore", "cod_ente"}), None)

        area_layer_crs = None
        if area_shapely is not None:
            # riproietta l'area (WGS84) nel CRS del layer
            g = QgsGeometry.fromWkt(area_shapely.wkt)
            tr = QgsCoordinateTransform(
                QgsCoordinateReferenceSystem("EPSG:4326"), layer.crs(), self.project)
            g.transform(tr)
            area_layer_crs = _shp_wkt.loads(g.asWkt(8))
            bbox = g.boundingBox()
            richiesta = QgsFeatureRequest().setFilterRect(bbox)
        else:
            richiesta = QgsFeatureRequest()

        # per la distanza dal tracciato: proietto tracciato e feature in metri
        tracc_m = None
        proj_m = None
        if tracciato_wgs is not None:
            try:
                import ftth_screening as _scr
            except ImportError:
                from . import ftth_screening as _scr
            tracc_m, info = _scr._metrico(tracciato_wgs)
            proj_m = _scr._proiettore_metrico(info)

        records = []
        for feat in layer.getFeatures(richiesta):
            sigla = feat[campo]
            if sigla in (None, ""):
                continue
            g = feat.geometry()
            if area_layer_crs is not None:
                if g is None or g.isEmpty():
                    continue
                try:
                    if not _shp_wkt.loads(g.asWkt(6)).intersects(area_layer_crs):
                        continue
                except Exception:
                    continue
            dist = None
            if tracc_m is not None and g is not None and not g.isEmpty():
                try:
                    from shapely.ops import transform as _t
                    # geometria feature in WGS84, poi in metri
                    gw = g
                    if layer.crs() != QgsCoordinateReferenceSystem("EPSG:4326"):
                        gw = QgsGeometry(g)
                        gw.transform(QgsCoordinateTransform(
                            layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"), self.project))
                    gm = _t(proj_m, _shp_wkt.loads(gw.asWkt(7)))
                    dist = tracc_m.distance(gm)
                except Exception:
                    dist = None
            records.append({
                "ref": sigla,
                "name": feat[campo_nome] if campo_nome else None,
                "operator": feat[campo_op] if campo_op else None,
                "distanza_m": dist,
            })
        return records, indipendente

    # ─── TAB EDIFICI ──────────────────────────────────────────────
    def _tab_edifici(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._barra_guida("edifici"))
        v.addWidget(self._desc(
            "Trova gli edifici minori che ricadono interamente dentro la carreggiata e "
            "li elimina, una regione alla volta. L'analisi non modifica niente: trova, "
            "seleziona in mappa e ti lascia controllare. Solo il secondo pulsante scrive, "
            "e prima di cancellare salva gli elementi in un GeoPackage a parte, così la "
            "cancellazione resta annullabile. Il test è di contenimento: un edificio che "
            "sporge anche di poco dalla carreggiata NON viene toccato. Sui livelli "
            "poligonali la carreggiata è il poligono; su quelli lineari, che è il caso "
            "normale, viene ricostruita allargando la linea della larghezza impostata nel "
            "punto 2 — e lì si può anche passare al criterio dell'attraversamento. "
            "L'analisi non legge l'intero territorio nazionale ma solo i livelli del "
            "gruppo scelto, ristretti alla loro estensione, quindi il tempo dipende dalla "
            "regione e non dalla dimensione del progetto."
        ))

        gb1 = self._gruppo("1) Regioni presenti nel progetto"); v1 = QVBoxLayout(gb1)
        v1.addWidget(self._desc(
            "Il plugin percorre l'albero dei livelli e cerca i gruppi che contengono sia "
            "un livello di strade sia uno di edifici minori: sono le regioni lavorabili. "
            "Il riconoscimento è per porzione di nome, senza distinzione fra maiuscole e "
            "minuscole, così funziona con 'DBSN Strade (carreggiata reale)' come con "
            "qualunque altra dicitura che contenga la parola indicata."
        ))
        f1 = QFormLayout()
        self.txt_ed_chiave_strade = QLineEdit(self.CHIAVE_ED_STRADE)
        self.txt_ed_chiave_strade.setToolTip(
            "Porzione di nome che identifica il livello delle strade dentro il gruppo "
            "regione. Se nel gruppo ci sono più livelli che la contengono viene preso il "
            "primo poligonale, perché il contenimento richiede un'area.")
        f1.addRow("Il livello strade contiene:", self.txt_ed_chiave_strade)
        self.txt_ed_chiave_edifici = QLineEdit(self.CHIAVE_ED_EDIFICI)
        self.txt_ed_chiave_edifici.setToolTip(
            "Porzione di nome che identifica il livello degli edifici da ripulire.")
        f1.addRow("Il livello edifici contiene:", self.txt_ed_chiave_edifici)
        v1.addLayout(f1)
        btn_cerca = QPushButton("Cerca le regioni nel progetto")
        btn_cerca.clicked.connect(self._cerca_regioni_edifici)
        v1.addWidget(btn_cerca)
        self.lst_ed_regioni = QListWidget()
        self.lst_ed_regioni.setSelectionMode(QAbstractItemView.SingleSelection)
        self.lst_ed_regioni.setMaximumHeight(150)
        self.lst_ed_regioni.setToolTip(
            "Una riga per gruppo lavorabile. Si elabora una regione per volta: "
            "selezionane una e premi il primo pulsante.")
        v1.addWidget(self.lst_ed_regioni)
        f1b = QFormLayout()
        self.cb_ed_strade = self._lcombo(
            QgsMapLayerProxyModel.PolygonLayer | QgsMapLayerProxyModel.LineLayer,
            allow_empty=True)
        self.cb_ed_strade.setToolTip(
            "Lasciandolo vuoto vale il livello strade riconosciuto dentro il gruppo "
            "della regione. Impostandolo, quel livello viene usato per TUTTE le "
            "regioni: serve quando le strade stanno in un livello unico fuori dai "
            "gruppi regione, o quando nel gruppo ne esiste più di uno e il "
            "riconoscimento per nome pesca quello sbagliato.\n\n"
            "Preferisci sempre un livello POLIGONALE quando c'è: su un livello lineare "
            "il contenimento non esiste e va ricostruito col buffer, con i limiti "
            "spiegati nel punto 2.")
        f1b.addRow("Usa invece questo livello strade:", self.cb_ed_strade)
        # parte VUOTO (v0.78.2): QgsMapLayerComboBox seleziona da sé il primo
        # layer del progetto anche con allowEmptyLayer, e un layer qualunque
        # qui scavalca il livello del gruppo regione — vuoto è il default
        # giusto e significa "usa il livello riconosciuto nel gruppo".
        self.cb_ed_strade.setLayer(None)
        v1.addLayout(f1b)
        v.addWidget(gb1)

        gb2 = self._gruppo("2) Criterio di riconoscimento"); v2 = QVBoxLayout(gb2)
        v2.addWidget(self._desc(
            "Un edificio è 'in carreggiata' quando è contenuto per intero nel poligono "
            "della strada. La carreggiata però è spezzata in tronchi: un edificio a "
            "cavallo di due tronchi adiacenti non è contenuto in nessuno dei due presi "
            "singolarmente, e senza l'unione dei tronchi vicini sfuggirebbe all'analisi. "
            "È lo stesso motivo per cui le chilometriche misurano sui corridoi ricuciti "
            "e non sulle singole tratte."
        ))
        self.chk_ed_unisci = QCheckBox(
            "Unisci i tronchi di strada adiacenti prima del test (consigliato)")
        self.chk_ed_unisci.setChecked(True)
        self.chk_ed_unisci.setToolTip(
            "L'unione viene calcolata solo per gli edifici che nessun tronco singolo "
            "contiene, quindi non pesa sull'analisi complessiva.")
        v2.addWidget(self.chk_ed_unisci)
        f2 = QFormLayout()
        self.cb_ed_criterio = QComboBox()
        for etichetta in ("L'asse stradale attraversa l'edificio (consigliato)",
                          "Contenuto nella carreggiata ricostruita col buffer"):
            self.cb_ed_criterio.addItem(etichetta)
        self.cb_ed_criterio.setToolTip(
            "Vale solo per i livelli strade LINEARI; su un livello poligonale il test è "
            "sempre il contenimento nel poligono.\n\n"
            "ATTRAVERSAMENTO: se l'asse della strada passa dentro un edificio, "
            "quell'edificio è in mezzo alla strada. Non serve nessuna larghezza — e la "
            "larghezza è proprio il punto debole dell'altro criterio, perché sulla stessa "
            "regione convivono strade da quattro metri e da dodici, mentre il buffer ne "
            "usa una sola. Su un banco di prova con sei casi tipici il buffer sbaglia due "
            "volte con qualunque valore, l'attraversamento una sola.\n\n"
            "Soprattutto: l'attraversamento sbaglia solo per difetto. Può lasciare lì un "
            "edificio che sta in carreggiata di lato, ma non dichiara mai dentro qualcosa "
            "che sta fuori. Trattandosi di una cancellazione, è l'errore preferibile: ciò "
            "che sfugge si prende al giro dopo, ciò che viene cancellato per sbaglio va "
            "ripescato dal file.")
        # predefinito l'ATTRAVERSAMENTO (v0.78.2): il caso d'uso principale è il
        # DBSN, dove il livello strade contiene i BORDI della carreggiata — e lì
        # il buffer trova quasi zero edifici (2 su 20.871 nel collaudo in Valle
        # d'Aosta, contro i 417 di attraversamento + corridoio). Il buffer resta
        # disponibile per chi lavora su assi con larghezza nota.
        self.cb_ed_criterio.setCurrentIndex(0)
        f2.addRow("Se le strade sono linee, considera dentro:", self.cb_ed_criterio)
        self.spin_ed_attraversamento = self._dspin(0, 50, 0.0, 2, " m")
        self.spin_ed_attraversamento.setToolTip(
            "Lunghezza minima del tratto di asse che cade dentro l'edificio. Serve a non "
            "far scattare il criterio quando l'asse sfiora appena un angolo: con zero "
            "basterebbe un contatto puntuale.")
        f2.addRow("Attraversamento minimo:", self.spin_ed_attraversamento)
        self.spin_ed_corridoio = self._dspin(1, 60, 14.0, 1, " m")
        self.spin_ed_corridoio.setToolTip(
            "Larghezza oltre la quale due bordi non delimitano più una carreggiata ma "
            "due strade diverse. Serve al test del corridoio qui sotto: alzarla troppo "
            "farebbe considerare 'in strada' anche un edificio che sta in mezzo a due "
            "strade parallele lontane.")
        f2.addRow("Larghezza massima di carreggiata:", self.spin_ed_corridoio)
        self.spin_ed_quota = self._ispin(0, 100, 50)
        self.spin_ed_quota.setSuffix(" %")
        self.spin_ed_quota.setToolTip(
            "Quota minima dell'AREA dell'edificio che deve stare dentro la carreggiata "
            "perché venga selezionato. Filtra gli edifici a filo strada che il bordo "
            "taglia appena: senza questo filtro basta che il bordo attraversi l'edificio "
            "per un qualunque tratto, anche se il 90% dell'edificio sta fuori.\n\n"
            "La quota è stimata campionando una griglia di punti dentro l'edificio e "
            "verificando per ciascuno se sta fra due bordi. Con 0 il filtro è spento.\n\n"
            "Vale solo quando il test del corridoio è attivo (cioè con i livelli che "
            "contengono i LIMITI della carreggiata): con gli assi la carreggiata fra "
            "i bordi non esiste e la quota non è stimabile.")
        f2.addRow("Quota minima dell'area in carreggiata:", self.spin_ed_quota)
        v2.addLayout(f2)
        self.chk_ed_corridoio = QCheckBox(
            "Considera dentro anche gli edifici racchiusi fra due bordi "
            "(solo se le linee sono i LIMITI della carreggiata)")
        # acceso di default (v0.78.2): il flusso di lavoro tipico è il DBSN, le
        # cui linee sono i limiti della carreggiata — il caso per cui questo
        # test esiste. Chi lavora su un livello di ASSI deve spegnerlo (il
        # tooltip e il log lo ricordano: con gli assi il test dichiara in
        # carreggiata gli edifici fra due strade parallele vicine).
        self.chk_ed_corridoio.setChecked(True)
        self.chk_ed_corridoio.setToolTip(
            "Quando il livello strade contiene i LIMITI della carreggiata e non gli assi, "
            "fra i due bordi c'è la strada ma nessuna geometria la rappresenta: un "
            "edificio minore piccolo può starci tutto dentro senza toccare né l'uno né "
            "l'altro bordo, e il solo attraversamento lo lascerebbe lì.\n\n"
            "Il test guarda il bordo più vicino al centro dell'edificio e cerca un altro "
            "bordo dalla parte opposta entro la larghezza massima qui sopra. Un edificio "
            "appena fuori strada ha un bordo da un lato e niente dall'altro, quindi non "
            "scatta.\n\n"
            "PRIMA DI ATTIVARLO verifica che le linee siano davvero i limiti e non gli "
            "assi: una simbologia a doppio tratto (una linea scura spessa sotto e una "
            "chiara più sottile sopra) fa sembrare due bordi quella che è una geometria "
            "sola. Con gli assi questo test trova la strada parallela vicina e dichiara "
            "'in carreggiata' gli edifici che stanno fra due strade.\n\n"
            "Vale solo col criterio dell'attraversamento.")
        v2.addWidget(self.chk_ed_corridoio)
        self.spin_ed_larghezza = self._dspin(0, 60, 3.0, 1, " m")
        self.spin_ed_larghezza.setToolTip(
            "Serve SOLO se il livello strade è lineare invece che poligonale: in quel "
            "caso non esiste un poligono in cui essere contenuti, e la carreggiata viene "
            "ricostruita allargando l'asse di metà di questo valore per lato. È una "
            "carreggiata stimata: il log lo dichiara quando succede. Se il livello è già "
            "poligonale il valore viene ignorato.\n\n"
            "ATTENZIONE: il buffer allarga la linea in ENTRAMBE le direzioni. Va bene se "
            "le linee sono gli ASSI stradali; se invece sono i LIMITI della carreggiata "
            "(due linee parallele per ogni strada) l'area prodotta cade metà dentro e "
            "metà fuori dalla strada, e gli edifici a filo strada risultano 'in "
            "carreggiata' pur stando fuori. In quel caso serve un livello poligonale.")
        f2b = QFormLayout()
        f2b.addRow("Larghezza carreggiata (solo col criterio del buffer):",
                   self.spin_ed_larghezza)
        v2.addLayout(f2b)
        self.chk_ed_zoom = QCheckBox("Inquadra gli edifici trovati a fine analisi")
        self.chk_ed_zoom.setChecked(True)
        v2.addWidget(self.chk_ed_zoom)
        v.addWidget(gb2)

        gb3 = self._gruppo("3) Dove finiscono gli edifici eliminati"); v3 = QVBoxLayout(gb3)
        v3.addWidget(self._desc(
            "Prima di cancellare, gli edifici vengono scritti in un GeoPackage con un "
            "livello per regione. Il GeoPackage è preferito allo Shapefile perché "
            "conserva i nomi di campo per intero: gli attributi DBSN superano i dieci "
            "caratteri e su DBF verrebbero troncati, rendendo il ripristino impreciso. "
            "Se il file non c'è viene creato; se c'è già, il livello della regione viene "
            "riscritto e gli altri restano."
        ))
        riga3 = QHBoxLayout()
        self.txt_ed_file = QLineEdit("")
        self.txt_ed_file.setPlaceholderText(
            "percorso del GeoPackage degli scarti (obbligatorio prima di cancellare)")
        riga3.addWidget(self.txt_ed_file)
        btn_sfoglia = QPushButton("Sfoglia…")
        btn_sfoglia.clicked.connect(self._scegli_file_scarti)
        riga3.addWidget(btn_sfoglia)
        v3.addLayout(riga3)
        self.chk_ed_carica = QCheckBox(
            "Carica nel progetto il livello degli scarti dopo la cancellazione")
        self.chk_ed_carica.setToolTip(
            "Utile per controllare a posteriori che sia stato messo da parte ciò che "
            "ti aspettavi.")
        v3.addWidget(self.chk_ed_carica)
        v.addWidget(gb3)

        riga_b = QHBoxLayout()
        b1 = QPushButton("1. Analizza la regione selezionata")
        b1.setStyleSheet("font-weight:bold; padding: 5px 10px;")
        b1.setToolTip("Trova e seleziona in mappa. Non modifica nulla.")
        b1.clicked.connect(self._analizza_edifici)
        riga_b.addWidget(b1)
        b2 = QPushButton("2. Metti da parte ed elimina")
        b2.setToolTip("Attivo dopo l'analisi: salva gli edifici trovati nel GeoPackage "
                      "e solo se il salvataggio è verificato li cancella dal livello.")
        b2.clicked.connect(self._elimina_edifici)
        riga_b.addWidget(b2)
        v.addLayout(riga_b)

        riga_d = QHBoxLayout()
        bd = QPushButton("Perché questo edificio? (diagnostica sull'elemento selezionato)")
        bd.setToolTip(
            "Seleziona in mappa UN edificio e premi qui: il plugin rifà il ragionamento "
            "solo su quello e dice quali tronchi di strada ha considerato, quanto lo "
            "sovrappongono e perché è stato incluso o escluso. È lo strumento da usare "
            "quando il risultato non torna, prima di cambiare i parametri a tentativi.")
        bd.clicked.connect(self._diagnostica_edificio)
        riga_d.addWidget(bd)
        v.addLayout(riga_d)

        riga_p = QHBoxLayout()
        self.prog_ed = QProgressBar()
        self.prog_ed.setVisible(False)
        riga_p.addWidget(self.prog_ed)
        self.btn_ed_stop = QPushButton("Interrompi")
        self.btn_ed_stop.setVisible(False)
        self.btn_ed_stop.clicked.connect(self._ferma_analisi_edifici)
        riga_p.addWidget(self.btn_ed_stop)
        v.addLayout(riga_p)

        riga_b2 = QHBoxLayout()
        riga_b2.addStretch()
        b3 = QPushButton("Annulla l'ultima cancellazione")
        b3.setToolTip("Rimette nel livello gli edifici dell'ultima cancellazione, "
                      "rileggendoli dal GeoPackage.")
        b3.clicked.connect(self._annulla_cancellazione_edifici)
        riga_b2.addWidget(b3)
        v.addLayout(riga_b2)

        self.stato_ed = self._etichetta_stato()
        v.addWidget(self.stato_ed)
        self.log_ed = self._log_widget(170)
        v.addWidget(self._blocco_log(self.log_ed))

        v.addStretch(); return w

    # ═════════════════════════════ EDIFICI IN CARREGGIATA – LOGICA
    def _scegli_file_scarti(self):
        iniziale = self.txt_ed_file.text().strip() or self.NOME_FILE_SCARTI
        percorso, _ = QFileDialog.getSaveFileName(
            self, "GeoPackage degli edifici eliminati", iniziale,
            "GeoPackage (*.gpkg)")
        if not percorso:
            return
        if not percorso.lower().endswith(".gpkg"):
            percorso += ".gpkg"
        self.txt_ed_file.setText(percorso)

    def _ferma_analisi_edifici(self):
        self._interrompi_ed = True
        self._mostra_stato(self.stato_ed, "Interruzione richiesta: mi fermo al prossimo "
                                          "blocco di elementi.", ok=False)

    @staticmethod
    def _nome_layer_scarti(nome_gruppo):
        """Nome del livello dentro il GeoPackage, ricavato dal nome del gruppo.

        I nomi dei gruppi regione contengono punti e trattini ('Veneto_dbsn_2025-07-28')
        che in un identificatore SQL vanno protetti: si normalizzano qui una volta
        per tutte, invece di scoprire al momento della scrittura che il livello
        non è stato creato."""
        pulito = re.sub(r"[^0-9A-Za-z_]+", "_", str(nome_gruppo)).strip("_")
        return pulito or "scarti"

    def _gruppi_lavorabili(self, chiave_strade, chiave_edifici):
        """[(gruppo, layer_strade, layer_edifici)] per ogni gruppo dell'albero
        che contiene entrambi i livelli fra i propri figli DIRETTI.

        Si guarda ai figli diretti e non a tutta la discendenza perché i gruppi
        regione sono annidati dentro un gruppo padre ('CTR Italia DBSN'): con
        una ricerca ricorsiva il padre risulterebbe lavorabile a sua volta e si
        finirebbe per confrontare gli edifici di una regione con le strade di
        un'altra.

        Per le strade si preferisce un livello poligonale quando c'è: il test è
        di contenimento e un'area è la sorgente giusta. Se nel gruppo ci sono
        solo livelli lineari si prende quello, e l'analisi ricostruirà la
        carreggiata col buffer, dichiarandolo."""
        from qgis.core import QgsLayerTreeGroup, QgsLayerTreeLayer
        trovati = []

        # se l'utente ha scelto uno stradario esterno nel punto 1 (es.
        # Stradario_Italia nazionale), le strade NON devono più stare dentro il
        # gruppo regione: basta che il gruppo abbia gli edifici. Lo stradario
        # scelto a mano viene poi usato da _strade_da_usare per ogni regione.
        strade_esterne = None
        try:
            scelto = self.cb_ed_strade.currentLayer()
            if isinstance(scelto, QgsVectorLayer) and scelto.isValid():
                strade_esterne = scelto
        except Exception:
            strade_esterne = None

        def esamina(nodo):
            strade_poligono = None; strade_linea = None; edifici = None
            for figlio in nodo.children():
                if isinstance(figlio, QgsLayerTreeGroup):
                    esamina(figlio)
                    continue
                if not isinstance(figlio, QgsLayerTreeLayer):
                    continue
                lyr = figlio.layer()
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid():
                    continue
                nome = lyr.name().lower()
                if chiave_edifici and chiave_edifici in nome and edifici is None:
                    if lyr.geometryType() == QgsWkbTypes.PolygonGeometry:
                        edifici = lyr
                    continue
                if chiave_strade and chiave_strade in nome:
                    if lyr.geometryType() == QgsWkbTypes.PolygonGeometry:
                        if strade_poligono is None:
                            strade_poligono = lyr
                    elif lyr.geometryType() == QgsWkbTypes.LineGeometry:
                        if strade_linea is None:
                            strade_linea = lyr
            # strade del gruppo, oppure lo stradario esterno scelto a mano
            strade = strade_poligono or strade_linea or strade_esterne
            if strade is not None and edifici is not None:
                trovati.append((nodo, strade, edifici))

        esamina(self.project.layerTreeRoot())
        return trovati

    def _cerca_regioni_edifici(self):
        chiave_s = self.txt_ed_chiave_strade.text().strip().lower()
        chiave_e = self.txt_ed_chiave_edifici.text().strip().lower()
        # se c'è uno stradario esterno nel punto 1 (es. Stradario_Italia), la
        # chiave strade non serve: le strade non stanno più nei gruppi regione.
        strad_esterno = self.cb_ed_strade.currentLayer()
        ha_strad_esterno = isinstance(strad_esterno, QgsVectorLayer) and strad_esterno.isValid()
        if not chiave_e or (not chiave_s and not ha_strad_esterno):
            QMessageBox.warning(self, "Chiavi mancanti",
                "Indica la porzione di nome del livello edifici. Per le strade: "
                "scrivi la chiave del livello strade OPPURE scegli uno stradario "
                "nel punto 1 (es. Stradario_Italia)."); return

        self.lst_ed_regioni.clear()
        gruppi = self._gruppi_lavorabili(chiave_s, chiave_e)
        righe = []
        for gruppo, strade, edifici in gruppi:
            tipo = ("poligonale" if strade.geometryType() == QgsWkbTypes.PolygonGeometry
                    else "LINEARE")
            n = edifici.featureCount()
            voce = QListWidgetItem(f"{gruppo.name()}  —  {n if n >= 0 else '?'} edifici minori")
            voce.setData(Qt.UserRole, (gruppo.name(), strade.id(), edifici.id()))
            self.lst_ed_regioni.addItem(voce)
            righe.append(f"  {gruppo.name()}")
            righe.append(f"      strade  : '{strade.name()}' ({tipo})")
            righe.append(f"      edifici : '{edifici.name()}' ({n if n >= 0 else '?'} elementi)")

        if not gruppi:
            self.log_ed.setPlainText(
                "Nessun gruppo contiene entrambi i livelli.\n\n"
                f"Cercavo un livello col nome contenente '{chiave_s}' e uno contenente "
                f"'{chiave_e}', fra i figli diretti dello stesso gruppo. Se i tuoi "
                "livelli si chiamano diversamente, correggi le due chiavi qui sopra; "
                "se strade ed edifici stanno in gruppi diversi, l'abbinamento per "
                "gruppo non può funzionare e va scelto un altro criterio.")
            self._mostra_stato(self.stato_ed, "Nessuna regione lavorabile trovata.", ok=False)
            return

        lineari = [g.name() for g, s, e in gruppi
                   if s.geometryType() != QgsWkbTypes.PolygonGeometry]
        if lineari:
            righe.append("")
            righe.append("Attenzione: in questi gruppi il livello strade è LINEARE, quindi "
                         "non esiste un poligono di carreggiata e verrà ricostruito col "
                         "valore di larghezza del punto 2 — il risultato è una stima: "
                         + ", ".join(lineari))
        righe.insert(0, f"{len(gruppi)} regioni lavorabili:")
        self.log_ed.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_ed,
                           f"{len(gruppi)} regioni trovate: selezionane una e analizza.")

    def _regione_selezionata(self):
        """(nome_gruppo, layer_strade, layer_edifici) per la riga scelta, o None
        con un avviso già mostrato."""
        voce = self.lst_ed_regioni.currentItem()
        if voce is None:
            QMessageBox.warning(self, "Nessuna regione selezionata",
                "Premi 'Cerca le regioni nel progetto' e seleziona una riga "
                "nell'elenco."); return None
        nome_gruppo, id_strade, id_edifici = voce.data(Qt.UserRole)
        strade = self.project.mapLayer(id_strade)
        edifici = self.project.mapLayer(id_edifici)
        if not isinstance(strade, QgsVectorLayer) or not isinstance(edifici, QgsVectorLayer):
            QMessageBox.warning(self, "Livelli non più disponibili",
                "I livelli di quel gruppo non sono più nel progetto: rilancia la "
                "ricerca delle regioni."); return None
        return nome_gruppo, strade, edifici

    @staticmethod
    def _punto_piu_vicino(geom_linea, punto_xy):
        """Punto di `geom_linea` più vicino a `punto_xy`.

        nearestPoint() è la via diretta, ma non è presente con la stessa firma
        in tutte le versioni di QGIS che il plugin dichiara di supportare;
        closestSegmentWithContext c'è da sempre e restituisce lo stesso punto,
        quindi fa da ripiego invece di far fallire l'intera analisi."""
        if hasattr(geom_linea, "nearestPoint"):
            try:
                p = geom_linea.nearestPoint(QgsGeometry.fromPointXY(punto_xy))
                if p is not None and not p.isEmpty():
                    return p.asPoint()
            except Exception:
                pass
        try:
            esito = geom_linea.closestSegmentWithContext(punto_xy)
        except Exception:
            return None
        return esito[1] if esito and len(esito) > 1 else None

    @staticmethod
    def _dentro_corridoio(g, indice, geometrie, larghezza_max):
        """True se l'edificio sta FRA due bordi stradali.

        Quando il livello strade contiene i limiti della carreggiata e non gli
        assi, fra i due bordi c'è la strada ma nessuna geometria la rappresenta:
        un edificio minore piccolo può starci tutto dentro senza toccare nessuno
        dei due, e il criterio dell'attraversamento lo lascerebbe lì.

        Si guarda il bordo più vicino al centro dell'edificio e si cerca un
        altro bordo dalla parte opposta, lungo la perpendicolare, entro la
        larghezza massima. Un edificio appena fuori strada ha un bordo da un
        lato e niente dall'altro, quindi non scatta; uno in mezzo a due strade
        parallele lontane non scatta perché il raggio non ci arriva."""
        centro = g.centroid()
        if centro is None or centro.isEmpty():
            return False
        c = centro.asPoint()
        intorno = g.boundingBox()
        intorno.grow(larghezza_max)
        vicini = indice.intersects(intorno)
        if not vicini:
            return False

        piu_vicino = None; distanza_min = None
        for fid in vicini:
            d = geometrie[fid].distance(centro)
            if distanza_min is None or d < distanza_min:
                distanza_min = d; piu_vicino = fid
        if piu_vicino is None or distanza_min > larghezza_max / 2.0:
            return False

        p = FTTHPermessiDialog._punto_piu_vicino(geometrie[piu_vicino], c)
        if p is None:
            return False
        dx = c.x() - p.x(); dy = c.y() - p.y()
        norma = math.hypot(dx, dy)
        if norma == 0:
            return True   # il centro cade sul bordo: è già in carreggiata
        dx /= norma; dy /= norma
        raggio = QgsGeometry.fromPolylineXY([
            QgsPointXY(c.x(), c.y()),
            QgsPointXY(c.x() + dx * larghezza_max, c.y() + dy * larghezza_max)])
        # Il bordo opposto viene cercato ANCHE nella stessa feature del bordo
        # vicino: le due parallele di una strada possono stare in una sola
        # polilinea, e il raggio parte dal centro e va dalla parte OPPOSTA al
        # punto più vicino, quindi un'intersezione con la stessa feature è per
        # forza un altro tratto di linea. Escluderla (com'era fino alla v0.78)
        # faceva sfuggire proprio quegli edifici.
        for fid in vicini:
            if geometrie[fid].intersects(raggio):
                return True
        return False

    @staticmethod
    def _livello_bordi(nome):
        """True se il nome del livello dice che le linee sono i BORDI della
        carreggiata e non gli assi (es. 'DBSN Strade (carreggiata reale)').
        Su questi livelli il buffer produce una carreggiata mezza fuori strada
        e il contenimento trova quasi zero edifici: il criterio giusto è
        l'attraversamento più il test del corridoio."""
        return bool(re.search(r"carreggiat|bordi|limiti", str(nome), re.I))

    @staticmethod
    def _punto_fra_bordi(pt, indice, geometrie, larghezza_max):
        """True se il PUNTO sta fra due bordi stradali (versione puntuale del
        test del corridoio). Si guarda il bordo più vicino e si lancia un
        raggio dalla parte opposta: se incontra un bordo, il punto ha strada
        da entrambi i lati, cioè sta nella carreggiata."""
        g_pt = QgsGeometry.fromPointXY(pt)
        intorno = g_pt.boundingBox()
        intorno.grow(larghezza_max)
        vicini = indice.intersects(intorno)
        if not vicini:
            return False
        piu_vicino = None; distanza_min = None
        for fid in vicini:
            d = geometrie[fid].distance(g_pt)
            if distanza_min is None or d < distanza_min:
                distanza_min = d; piu_vicino = fid
        if piu_vicino is None or distanza_min > larghezza_max / 2.0:
            return False
        q = FTTHPermessiDialog._punto_piu_vicino(geometrie[piu_vicino], pt)
        if q is None:
            return False
        dx = pt.x() - q.x(); dy = pt.y() - q.y()
        norma = math.hypot(dx, dy)
        if norma == 0:
            return True   # il punto cade sul bordo
        dx /= norma; dy /= norma
        raggio = QgsGeometry.fromPolylineXY([
            QgsPointXY(pt.x(), pt.y()),
            QgsPointXY(pt.x() + dx * larghezza_max, pt.y() + dy * larghezza_max)])
        for fid in vicini:
            if geometrie[fid].intersects(raggio):
                return True
        return False

    @staticmethod
    def _quota_in_carreggiata(g, indice, geometrie, larghezza_max, lato_griglia=7):
        """Frazione approssimata (0..1) dell'AREA dell'edificio che sta dentro
        la carreggiata, o None se non stimabile.

        Coi bordi della carreggiata non esiste un poligono strada con cui
        intersecare, quindi la quota si stima campionando: una griglia di
        punti dentro l'edificio, e per ciascuno il test puntuale 'sta fra due
        bordi?'. Con la griglia 7×7 l'errore di stima è di qualche punto
        percentuale, che per una soglia al 50-60%% è più che sufficiente."""
        rett = g.boundingBox()
        if rett.isEmpty() or rett.width() <= 0 or rett.height() <= 0:
            return None
        x0, y0 = rett.xMinimum(), rett.yMinimum()
        passo_x = rett.width() / (lato_griglia + 1)
        passo_y = rett.height() / (lato_griglia + 1)
        dentro_ed = []
        for i in range(1, lato_griglia + 1):
            for j in range(1, lato_griglia + 1):
                pt = QgsPointXY(x0 + i * passo_x, y0 + j * passo_y)
                if g.contains(QgsGeometry.fromPointXY(pt)):
                    dentro_ed.append(pt)
        if len(dentro_ed) < 4:
            # edificio più piccolo del passo della griglia: si ripiega sul
            # centroide, che per un poligono minuscolo rappresenta bene tutto
            centro = g.centroid()
            if centro is None or centro.isEmpty():
                return None
            dentro_ed = [centro.asPoint()]
        in_strada = sum(
            1 for pt in dentro_ed
            if FTTHPermessiDialog._punto_fra_bordi(pt, indice, geometrie, larghezza_max))
        return in_strada / len(dentro_ed)

    @staticmethod
    def _verdetto_edificio(g, indice, geometrie, attraversamento, minimo_attrav,
                           usa_corridoio, larghezza_corridoio, unisci,
                           quota_minima=0.0):
        """Il verdetto per UN edificio: (in_carreggiata, via).

        `via` dice quale test l'ha riconosciuto: 'diretto' (attraversamento o
        contenimento), 'unione' (contenuto solo unendo tronchi adiacenti),
        'corridoio' (racchiuso fra due bordi), 'quota' (SCARTATO perché meno
        della quota minima della sua area sta in carreggiata), '' se è fuori.

        `quota_minima` (0..1, v0.78.3) è il filtro sull'area: un edificio
        preso dall'attraversamento o dal corridoio viene tenuto solo se almeno
        quella frazione della sua area sta fra i bordi. Filtra gli edifici a
        filo strada che il bordo taglia appena. Vale solo nel flusso coi bordi
        (usa_corridoio attivo), dove la carreggiata fra i bordi esiste davvero.

        È un metodo statico separato dal ciclo dell'analisi per essere
        eseguibile e testabile anche fuori da QGIS (vedi tests/). Fix v0.78.1:
        col criterio dell'attraversamento il test del corridoio gira anche
        quando il bounding box dell'edificio non tocca nessun bordo — prima un
        `continue` lo saltava e un edificio in mezzo alla carreggiata ma
        lontano da entrambi i bordi sfuggiva."""
        candidati = indice.intersects(g.boundingBox())
        if attraversamento:
            via = ""
            for fid in candidati:
                try:
                    tratto = geometrie[fid].intersection(g)
                except Exception:
                    continue
                if tratto is None or tratto.isEmpty():
                    continue
                if tratto.length() >= minimo_attrav:
                    via = "diretto"
                    break
            if not via and usa_corridoio and FTTHPermessiDialog._dentro_corridoio(
                    g, indice, geometrie, larghezza_corridoio):
                via = "corridoio"
            if not via:
                return False, ""
            if quota_minima > 0 and usa_corridoio:
                quota = FTTHPermessiDialog._quota_in_carreggiata(
                    g, indice, geometrie, larghezza_corridoio)
                if quota is not None and quota < quota_minima:
                    return False, "quota"
            return True, via
        if not candidati:
            return False, ""
        for fid in candidati:
            if geometrie[fid].contains(g):
                return True, "diretto"
        if unisci and len(candidati) > 1:
            # Solo per i dubbi: la carreggiata è spezzata in tronchi e un
            # edificio a cavallo di due non è contenuto in nessuno dei due
            # preso da solo. L'unione si calcola qui e non a monte perché
            # unire l'intera rete regionale costerebbe moltissimo e
            # servirebbe a pochi casi.
            unione = QgsGeometry.unaryUnion([geometrie[fid] for fid in candidati])
            if unione is not None and not unione.isEmpty() and unione.contains(g):
                return True, "unione"
        return False, ""

    def _strade_da_usare(self, strade_del_gruppo):
        """Livello strade effettivo e da dove viene.

        Il combo del punto 1 ha la precedenza sul riconoscimento per nome: nel
        DBSN le strade possono stare in un livello unico fuori dai gruppi
        regione, e in quel caso il riconoscimento per gruppo non le trova; e
        quando nel gruppo ci sono più livelli il cui nome contiene la chiave, il
        primo che il riconoscimento incontra non è per forza quello giusto — il
        selettore è l'unico modo per dirlo con certezza."""
        scelto = self.cb_ed_strade.currentLayer()
        if isinstance(scelto, QgsVectorLayer) and scelto.isValid():
            return scelto, "scelto a mano nel punto 1"
        return strade_del_gruppo, "riconosciuto nel gruppo della regione"

    @staticmethod
    def _avviso_linee_strada(strade, serve_buffer):
        """Testo dell'avviso sui limiti del buffer, o stringa vuota.

        Va ripetuto in ogni esito perché è la causa più probabile di un falso
        positivo: allargare una linea produce area sui due lati, e se le linee
        sono i limiti della carreggiata (due parallele per strada) metà di
        quell'area cade FUORI dalla strada."""
        if not serve_buffer:
            return ""
        return (f"Il livello '{strade.name()}' è LINEARE: la carreggiata è ricostruita "
                f"allargando le linee. Se quelle linee sono i limiti della carreggiata e "
                f"non gli assi, l'area prodotta cade metà fuori strada e gli edifici a "
                f"filo risultano dentro pur non essendolo. Con un livello poligonale il "
                f"problema non si pone.")

    def _crs_di_lavoro(self, edifici, serve_buffer):
        """CRS in cui fare i confronti geometrici, e il motivo della scelta.

        Si preferisce il CRS del livello edifici: è il più popoloso e lasciarlo
        dov'è evita di trasformare centinaia di migliaia di geometrie. Il DBSN
        è però distribuito in coordinate geografiche, dove una larghezza di
        carreggiata in metri non ha senso: in quel caso, e solo se il buffer
        serve davvero, si passa al CRS di progetto, che è metrico."""
        crs = edifici.crs()
        if not serve_buffer or not crs.isGeographic():
            return crs, ""
        crs_progetto = self.project.crs()
        if crs_progetto.isGeographic():
            return crs, ("il livello edifici e il progetto sono entrambi in coordinate "
                         "geografiche: la larghezza in metri non è applicabile")
        return crs_progetto, (
            f"livello edifici in coordinate geografiche ({crs.authid()}): i confronti "
            f"girano nel CRS di progetto {crs_progetto.authid()}, che è metrico, "
            "altrimenti la larghezza della carreggiata sarebbe interpretata in gradi")

    def _analizza_edifici(self):
        """Trova gli edifici contenuti nella carreggiata e li seleziona in mappa.
        Non scrive nulla: serve al controllo a vista prima della cancellazione."""
        scelta = self._regione_selezionata()
        if scelta is None:
            return
        nome_gruppo, strade_gruppo, edifici = scelta
        strade, provenienza = self._strade_da_usare(strade_gruppo)

        strade_poligonali = strade.geometryType() == QgsWkbTypes.PolygonGeometry
        larghezza = self.spin_ed_larghezza.value()

        # Auto-riconoscimento dei livelli coi BORDI della carreggiata (v0.78.1):
        # su 'DBSN Strade (carreggiata reale)' le linee sono i limiti, due
        # parallele per strada. Col criterio del buffer il contenimento trova
        # quasi zero edifici (l'area del buffer di un bordo cade metà fuori
        # strada e la fascia CENTRALE della carreggiata resta scoperta), quindi
        # qui si propone di passare ad attraversamento + corridoio, che è la
        # combinazione pensata apposta per questi livelli.
        if (not strade_poligonali and self._livello_bordi(strade.name())
                and (self.cb_ed_criterio.currentIndex() != 0
                     or not self.chk_ed_corridoio.isChecked())):
            scelta_utente = QMessageBox.question(
                self, "Livello coi bordi della carreggiata",
                f"Il nome del livello '{strade.name()}' indica che le linee sono i "
                "LIMITI della carreggiata (due parallele per strada), non gli assi.\n\n"
                "Con le impostazioni attuali gli edifici in mezzo alla strada "
                "sfuggirebbero quasi tutti: il criterio adatto è \"l'asse attraversa "
                "l'edificio\" CON il test del corridoio (edificio racchiuso fra due "
                "bordi).\n\nImposto questa combinazione e proseguo?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if scelta_utente == QMessageBox.Yes:
                self.cb_ed_criterio.setCurrentIndex(0)
                self.chk_ed_corridoio.setChecked(True)

        # su un livello poligonale il criterio è sempre il contenimento; la
        # scelta del punto 2 riguarda solo i livelli lineari
        attraversamento = (not strade_poligonali
                           and self.cb_ed_criterio.currentIndex() == 0)
        minimo_attrav = self.spin_ed_attraversamento.value()
        serve_buffer = not strade_poligonali and not attraversamento
        usa_corridoio = attraversamento and self.chk_ed_corridoio.isChecked()
        larghezza_corridoio = self.spin_ed_corridoio.value()
        quota_minima = (self.spin_ed_quota.value() / 100.0) if usa_corridoio else 0.0
        if serve_buffer and larghezza <= 0:
            QMessageBox.warning(self, "Larghezza mancante",
                f"Il livello '{strade.name()}' è lineare: senza una larghezza di "
                "carreggiata non esiste un poligono in cui un edificio possa essere "
                "contenuto, e il risultato sarebbe sempre zero.\n\nImposta la larghezza "
                "nel punto 2."); return

        crs_lavoro, nota_crs = self._crs_di_lavoro(edifici, serve_buffer)
        if serve_buffer and crs_lavoro.isGeographic():
            QMessageBox.warning(self, "Coordinate geografiche",
                "Le strade sono lineari e andrebbero allargate di una misura in metri, "
                "ma sia il livello che il progetto sono in coordinate geografiche: il "
                "valore verrebbe letto come gradi.\n\nImposta un CRS di progetto metrico "
                "(es. ETRS89 / UTM) e rilancia."); return

        righe_avviso_corridoio = ""
        if strade_poligonali:
            descrizione_criterio = "contenimento totale nel poligono della carreggiata"
        elif attraversamento:
            descrizione_criterio = (f"un bordo attraversa l'edificio per almeno "
                                    f"{minimo_attrav:g} m")
            if usa_corridoio:
                descrizione_criterio += (f", oppure l'edificio sta fra due bordi "
                                         f"distanti al più {larghezza_corridoio:g} m")
                if quota_minima > 0:
                    descrizione_criterio += (
                        f"; in ogni caso almeno il {quota_minima:.0%} della sua "
                        f"area deve stare in carreggiata")
                righe_avviso_corridoio = (
                    "Il test del corridoio è ATTIVO: ha senso solo se le linee sono i "
                    "limiti della carreggiata. Se sono gli assi, gli edifici fra due "
                    f"strade parallele entro {larghezza_corridoio:g} m vengono dichiarati "
                    "in carreggiata pur non essendolo — controlla il conteggio "
                    "'racchiusi fra due bordi' prima di eliminare.")
            else:
                righe_avviso_corridoio = ""
        else:
            descrizione_criterio = (f"contenimento nella carreggiata ricostruita "
                                    f"allargando le linee di {larghezza:g} m complessivi")
        righe = [f"── {nome_gruppo} ──",
                 f"strade  : '{strade.name()}' "
                 f"({'poligoni' if strade_poligonali else 'linee'}) — {provenienza}",
                 f"edifici : '{edifici.name()}'",
                 f"criterio: {descrizione_criterio}",
                 f"CRS di lavoro: {crs_lavoro.authid()}"]
        if nota_crs:
            righe.append(f"  ({nota_crs})")
        avviso_linee = self._avviso_linee_strada(strade, serve_buffer)
        if avviso_linee:
            righe.append("")
            righe.append(avviso_linee)
            righe.append("")
        if attraversamento and righe_avviso_corridoio:
            righe.append("")
            righe.append(righe_avviso_corridoio)
            righe.append("")

        tr_strade = (QgsCoordinateTransform(strade.crs(), crs_lavoro, self.project)
                     if strade.crs() != crs_lavoro else None)
        tr_edifici = (QgsCoordinateTransform(edifici.crs(), crs_lavoro, self.project)
                      if edifici.crs() != crs_lavoro else None)

        self._analisi_in_corso = True
        self._interrompi_ed = False
        self.prog_ed.setVisible(True); self.btn_ed_stop.setVisible(True)
        self.prog_ed.setFormat("preparo l'indice delle strade… %p%")
        self.prog_ed.setRange(0, 0)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        QApplication.processEvents()
        interrotta = False
        dentro = []; esaminati = 0; per_unione = 0; senza_geometria = 0
        per_corridoio = 0; scartati_quota = 0
        estensione = QgsRectangle(); estensione.setMinimal()
        try:
            # Le strade si leggono ristrette all'estensione degli edifici della
            # regione: se qualcuno indica un livello strade nazionale invece di
            # quello regionale, senza questo filtro si leggerebbe l'Italia
            # intera per confrontarla con una regione sola.
            area = edifici.extent()
            if tr_edifici is not None:
                area = tr_edifici.transformBoundingBox(area)
            area_strade = area
            if tr_strade is not None:
                area_strade = QgsCoordinateTransform(
                    crs_lavoro, strade.crs(), self.project).transformBoundingBox(area)
            richiesta_strade = QgsFeatureRequest().setFilterRect(area_strade)
            richiesta_strade.setNoAttributes()

            indice = QgsSpatialIndex()
            geometrie = {}
            contatore = 0
            mezza = larghezza / 2.0
            for f in strade.getFeatures(richiesta_strade):
                g = f.geometry()
                if g is None or g.isEmpty():
                    continue
                if tr_strade is not None:
                    g = QgsGeometry(g)
                    if g.transform(tr_strade) != 0:
                        continue
                if serve_buffer:
                    g = g.buffer(mezza, 8)
                    if g is None or g.isEmpty():
                        continue
                contatore += 1
                geometrie[contatore] = g
                copia = QgsFeature(); copia.setId(contatore); copia.setGeometry(g)
                indice.addFeature(copia)
            righe.append(f"tronchi di strada indicizzati: {contatore}")
            if not contatore:
                righe.append("Nessuna geometria di strada nell'estensione degli edifici: "
                             "analisi interrotta.")
                self.log_ed.setPlainText("\n".join(righe))
                self._mostra_stato(self.stato_ed, "Nessuna strada da confrontare.", ok=False)
                return

            totale = edifici.featureCount()
            self.prog_ed.setRange(0, max(totale, 1))
            self.prog_ed.setFormat(f"{nome_gruppo}: %v / %m edifici")
            unisci = self.chk_ed_unisci.isChecked()
            # Gli attributi non servono al confronto e sono la parte pesante
            # della lettura: si chiede al provider di non leggerli affatto.
            for f in edifici.getFeatures(QgsFeatureRequest().setNoAttributes()):
                esaminati += 1
                if esaminati % 500 == 0:
                    self.prog_ed.setValue(esaminati)
                    QApplication.processEvents()
                    if self._interrompi_ed:
                        interrotta = True
                        break
                g = f.geometry()
                if g is None or g.isEmpty():
                    senza_geometria += 1
                    continue
                if tr_edifici is not None:
                    g = QgsGeometry(g)
                    if g.transform(tr_edifici) != 0:
                        senza_geometria += 1
                        continue
                contenuto, via = self._verdetto_edificio(
                    g, indice, geometrie, attraversamento, minimo_attrav,
                    usa_corridoio, larghezza_corridoio, unisci, quota_minima)
                if via == "unione":
                    per_unione += 1
                elif via == "corridoio":
                    per_corridoio += 1
                elif via == "quota":
                    scartati_quota += 1
                if contenuto:
                    dentro.append(f.id())
                    estensione.combineExtentWith(g.boundingBox())
            self.prog_ed.setValue(esaminati)
        finally:
            QApplication.restoreOverrideCursor()
            self._analisi_in_corso = False
            self.prog_ed.setVisible(False)
            self.btn_ed_stop.setVisible(False)

        edifici.selectByIds(dentro)
        self._edifici_trovati = {
            "gruppo": nome_gruppo,
            "layer": edifici.id(),
            "fids": dentro,
            "parziale": interrotta,
        }

        if dentro and self.chk_ed_zoom.isChecked() and not estensione.isEmpty():
            da_mostrare = estensione
            if crs_lavoro != self.project.crs():
                da_mostrare = QgsCoordinateTransform(
                    crs_lavoro, self.project.crs(), self.project).transformBoundingBox(estensione)
            da_mostrare.grow(max(da_mostrare.width(), da_mostrare.height()) * 0.15 + 20)
            self.iface.mapCanvas().setExtent(da_mostrare)
            self.iface.mapCanvas().refresh()

        righe.append("")
        righe.append(f"esaminati      : {esaminati}")
        righe.append(f"in carreggiata : {len(dentro)}")
        if per_unione:
            righe.append(f"  di cui {per_unione} riconosciuti solo unendo tronchi "
                         f"adiacenti (senza l'unione sarebbero sfuggiti)")
        if per_corridoio:
            righe.append(f"  di cui {per_corridoio} racchiusi fra due bordi senza "
                         f"toccarne nessuno (senza il test del corridoio sarebbero "
                         f"sfuggiti)")
        if scartati_quota:
            righe.append(f"scartati dal filtro area: {scartati_quota} attraversati da "
                         f"un bordo ma con meno del {quota_minima:.0%} dell'area in "
                         f"carreggiata (edifici a filo strada)")
        if senza_geometria:
            righe.append(f"scartati       : {senza_geometria} senza geometria valida")
        righe.append("")
        if interrotta:
            righe.append("ANALISI INTERROTTA: il conteggio riguarda solo la parte "
                         "esaminata. Il pulsante di eliminazione resta attivo ma "
                         "lavorerebbe su un risultato parziale — meglio rilanciare.")
        else:
            righe.append("Gli edifici trovati sono ora SELEZIONATI in mappa: controllali "
                         "a vista prima di premere il secondo pulsante. Finché non lo "
                         "premi non viene modificato niente.")
        self.log_ed.setPlainText("\n".join(righe))
        self._mostra_stato(
            self.stato_ed,
            f"{nome_gruppo}: {len(dentro)} edifici in carreggiata su {esaminati}"
            + (" (analisi parziale)" if interrotta else ""),
            ok=not interrotta)

    def _diagnostica_edificio(self):
        """Rifà il ragionamento dell'analisi su UN edificio selezionato in mappa
        e ne riporta i passaggi.

        Serve quando il verdetto non torna: un elenco di percentuali di
        sovrapposizione dice in un colpo d'occhio se il problema è il criterio,
        il livello strade sbagliato o il buffer che allarga dalla parte
        sbagliata. Senza, l'unica via sarebbe cambiare i parametri a tentativi.
        Stesso ruolo del pulsante Diagnostica delle chilometriche."""
        scelta = self._regione_selezionata()
        if scelta is None:
            return
        nome_gruppo, strade_gruppo, edifici = scelta
        strade, provenienza = self._strade_da_usare(strade_gruppo)

        selezionati = edifici.selectedFeatureIds()
        if not selezionati:
            QMessageBox.warning(self, "Nessun edificio selezionato",
                f"Seleziona in mappa un elemento di '{edifici.name()}' e ripremi.\n\n"
                "Se hai appena lanciato l'analisi la selezione contiene tutti gli "
                "edifici trovati: qui viene esaminato il primo."); return

        strade_poligonali = strade.geometryType() == QgsWkbTypes.PolygonGeometry
        attraversamento = (not strade_poligonali
                           and self.cb_ed_criterio.currentIndex() == 0)
        minimo_attrav = self.spin_ed_attraversamento.value()
        serve_buffer = not strade_poligonali and not attraversamento
        usa_corridoio = attraversamento and self.chk_ed_corridoio.isChecked()
        larghezza_corridoio = self.spin_ed_corridoio.value()
        larghezza = self.spin_ed_larghezza.value()
        crs_lavoro, nota_crs = self._crs_di_lavoro(edifici, serve_buffer)

        f = next(edifici.getFeatures(
            QgsFeatureRequest().setFilterFid(selezionati[0])), None)
        if f is None or f.geometry() is None or f.geometry().isEmpty():
            QMessageBox.warning(self, "Geometria assente",
                "L'elemento selezionato non ha una geometria leggibile."); return

        g = QgsGeometry(f.geometry())
        if edifici.crs() != crs_lavoro:
            if g.transform(QgsCoordinateTransform(
                    edifici.crs(), crs_lavoro, self.project)) != 0:
                QMessageBox.warning(self, "Trasformazione fallita",
                    "Non riesco a portare la geometria nel CRS di lavoro."); return

        righe = ["── diagnostica su un solo edificio ──",
                 f"regione : {nome_gruppo}",
                 f"edificio: id {selezionati[0]} del livello '{edifici.name()}'"
                 + (f"  (selezionati {len(selezionati)}, esamino il primo)"
                    if len(selezionati) > 1 else ""),
                 f"strade  : '{strade.name()}' "
                 f"({'poligoni' if strade_poligonali else 'linee'}) — {provenienza}",
                 "criterio: " + ("contenimento nel poligono" if strade_poligonali
                                  else f"l'asse attraversa per almeno {minimo_attrav:g} m"
                                  if attraversamento
                                  else f"contenimento nel buffer di {larghezza:g} m"),
                 f"CRS di lavoro: {crs_lavoro.authid()}"]
        if nota_crs:
            righe.append(f"  ({nota_crs})")
        righe.append(f"area dell'edificio: {g.area():.2f} unità²")
        righe.append("")

        # niente indice spaziale: per un solo elemento basta chiedere al provider
        # le strade del suo intorno
        intorno = g.boundingBox()
        intorno.grow(max(larghezza, larghezza_corridoio, 1.0) * 2)
        if strade.crs() != crs_lavoro:
            intorno = QgsCoordinateTransform(
                crs_lavoro, strade.crs(), self.project).transformBoundingBox(intorno)
        tr_strade = (QgsCoordinateTransform(strade.crs(), crs_lavoro, self.project)
                     if strade.crs() != crs_lavoro else None)

        # due elenchi: i bordi dell'intorno servono al test del corridoio, quelli
        # che toccano il rettangolo dell'edificio alla tabella dei tronchi
        candidati = []
        indice_vicini = QgsSpatialIndex()
        geometrie_vicine = {}
        for t in strade.getFeatures(QgsFeatureRequest().setFilterRect(intorno)):
            gt = t.geometry()
            if gt is None or gt.isEmpty():
                continue
            gt = QgsGeometry(gt)
            if tr_strade is not None and gt.transform(tr_strade) != 0:
                continue
            if serve_buffer:
                gt = gt.buffer(larghezza / 2.0, 8)
                if gt is None or gt.isEmpty():
                    continue
            geometrie_vicine[t.id()] = gt
            copia = QgsFeature(); copia.setId(t.id()); copia.setGeometry(gt)
            indice_vicini.addFeature(copia)
            if not gt.boundingBox().intersects(g.boundingBox()):
                continue
            candidati.append((t.id(), gt))

        if not candidati:
            righe.append("Nessun bordo di strada tocca il rettangolo dell'edificio.")
            if usa_corridoio and self._dentro_corridoio(
                    g, indice_vicini, geometrie_vicine, larghezza_corridoio):
                righe.append("")
                righe.append(f"Però l'edificio è RACCHIUSO fra due bordi entro "
                             f"{larghezza_corridoio:g} m: sta dentro la carreggiata senza "
                             f"toccarne i limiti.")
                righe.append("VERDETTO: da eliminare — test del corridoio.")
                self.log_ed.setPlainText("\n".join(righe))
                self._mostra_stato(self.stato_ed,
                                   "Diagnostica: l'edificio risulta IN carreggiata "
                                   "(racchiuso fra due bordi).")
                return
            righe.append("L'analisi lo lascerebbe dov'è.")
            righe.append("")
            righe.append("Se ti aspettavi il contrario, il livello strade è quello "
                         "sbagliato oppure è troppo lontano: controlla la riga 'strade' "
                         "qui sopra.")
            self.log_ed.setPlainText("\n".join(righe))
            self._mostra_stato(self.stato_ed, "Edificio non in carreggiata: nessun "
                                              "bordo lo tocca.")
            return

        righe.append(f"tronchi considerati: {len(candidati)}")
        contenuto_da = None
        if attraversamento:
            righe.append(f"{'id tronco':>12}  {'attraversa':>11}  "
                         f"{'tratto interno':>14}  distanza")
            for fid, gt in candidati:
                try:
                    tratto = gt.intersection(g)
                    dentro_m = tratto.length() if tratto is not None and not tratto.isEmpty() else 0.0
                except Exception:
                    dentro_m = 0.0
                passa = dentro_m >= minimo_attrav
                righe.append(f"{fid:>12}  {'SI' if passa else 'no':>11}  "
                             f"{dentro_m:>13.2f}m  {gt.distance(g):.2f}")
                if passa and contenuto_da is None:
                    contenuto_da = fid
        else:
            righe.append(f"{'id tronco':>12}  {'contiene':>9}  {'sovrapp.':>9}  distanza")
            for fid, gt in candidati:
                contiene = gt.contains(g)
                try:
                    inter = g.intersection(gt)
                    perc = (inter.area() / g.area() * 100.0) if g.area() > 0 else 0.0
                except Exception:
                    perc = float("nan")
                righe.append(f"{fid:>12}  {'SI' if contiene else 'no':>9}  "
                             f"{perc:>8.1f}%  {gt.distance(g):.2f}")
                if contiene and contenuto_da is None:
                    contenuto_da = fid

        per_corridoio = False
        if contenuto_da is None and usa_corridoio:
            per_corridoio = self._dentro_corridoio(
                g, indice_vicini, geometrie_vicine, larghezza_corridoio)
            righe.append("")
            righe.append(f"test del corridoio (larghezza max {larghezza_corridoio:g} m): "
                         + ("l'edificio è RACCHIUSO fra due bordi"
                            if per_corridoio else
                            "nessun bordo dalla parte opposta, non scatta"))

        per_unione = False
        # con l'attraversamento l'unione non serve: un bordo che passa dentro
        # l'edificio lo attraversa a prescindere da come i tronchi sono spezzati
        if (contenuto_da is None and not attraversamento and len(candidati) > 1
                and self.chk_ed_unisci.isChecked()):
            unione = QgsGeometry.unaryUnion([gt for _, gt in candidati])
            if unione is not None and not unione.isEmpty() and unione.contains(g):
                per_unione = True
            try:
                perc_u = (g.intersection(unione).area() / g.area() * 100.0
                          if unione is not None and g.area() > 0 else 0.0)
            except Exception:
                perc_u = float("nan")
            righe.append("")
            righe.append(f"unione dei {len(candidati)} tronchi: "
                         f"{'CONTIENE' if per_unione else 'non contiene'} l'edificio "
                         f"(sovrapposizione {perc_u:.1f}%)")

        dentro = contenuto_da is not None or per_unione or per_corridoio

        # filtro sull'area (v0.78.3): stessa regola dell'analisi, riportata
        # qui con il valore stimato così il verdetto è spiegato per intero
        quota_minima_diag = (self.spin_ed_quota.value() / 100.0) if usa_corridoio else 0.0
        if dentro and quota_minima_diag > 0 and usa_corridoio:
            quota_ed = self._quota_in_carreggiata(
                g, indice_vicini, geometrie_vicine, larghezza_corridoio)
            if quota_ed is not None:
                righe.append("")
                righe.append(f"quota dell'area in carreggiata: {quota_ed:.0%} "
                             f"(minimo richiesto {quota_minima_diag:.0%})")
                if quota_ed < quota_minima_diag:
                    dentro = False
                    righe.append("")
                    righe.append("VERDETTO: da tenere — un bordo lo attraversa, ma "
                                 "la parte in carreggiata è sotto la quota minima "
                                 "(edificio a filo strada).")
                    self.log_ed.setPlainText("\n".join(righe))
                    self._mostra_stato(self.stato_ed,
                                       "Diagnostica: tenuto dal filtro area.")
                    return
        righe.append("")
        if dentro:
            if contenuto_da is None and per_corridoio:
                motivo = "racchiuso fra due bordi (test del corridoio)"
            elif contenuto_da is None:
                motivo = "contenuto nell'unione di tronchi adiacenti"
            elif attraversamento:
                motivo = f"attraversato dal bordo {contenuto_da}"
            else:
                motivo = f"contenuto per intero nel tronco {contenuto_da}"
            righe.append(f"VERDETTO: da eliminare — {motivo}.")
        else:
            # quanto ci è andato vicino: se sfiora il 100% il problema è il
            # criterio (contenimento totale), se è basso è davvero fuori
            massima = 0.0
            for _, gt in candidati:
                try:
                    if g.area() > 0:
                        massima = max(massima, g.intersection(gt).area() / g.area() * 100.0)
                except Exception:
                    continue
            if attraversamento:
                righe.append("VERDETTO: da tenere — nessun bordo lo attraversa per la "
                             "lunghezza minima richiesta"
                             + (", e non risulta racchiuso fra due bordi."
                                if usa_corridoio else "."))
                if not usa_corridoio:
                    righe.append("Se secondo te sta dentro la carreggiata senza toccarne "
                                 "i limiti, attiva 'Considera dentro anche gli edifici "
                                 "racchiusi fra due bordi' nel punto 2.")
            else:
                righe.append("VERDETTO: da tenere — nessun tronco, né la loro unione, lo "
                             f"contiene per intero (sovrapposizione massima {massima:.1f}%).")
            if not attraversamento and massima >= 90.0:
                righe.append("Sta quasi tutto dentro: se casi come questo li consideri "
                             "errori del dato, il criterio del contenimento totale è "
                             "troppo severo e va cambiato in una soglia percentuale.")

        avviso = self._avviso_linee_strada(strade, serve_buffer)
        if avviso:
            righe.append("")
            righe.append(avviso)
            if dentro:
                righe.append("È esattamente il caso in cui un edificio a bordo strada "
                             "viene dichiarato dentro pur non essendolo: verifica se "
                             "quelle linee sono assi o limiti di carreggiata prima di "
                             "eliminare qualcosa.")
        self.log_ed.setPlainText("\n".join(righe))
        self._mostra_stato(
            self.stato_ed,
            "Diagnostica: l'edificio risulta " + ("IN carreggiata." if dentro
                                                  else "fuori carreggiata."),
            ok=True)

    def _elimina_edifici(self):
        """Salva gli edifici trovati nel GeoPackage e solo dopo averlo verificato
        li cancella dal livello."""
        esito = self._edifici_trovati
        if not esito:
            QMessageBox.warning(self, "Analisi mancante",
                "Premi prima '1. Analizza la regione selezionata': l'eliminazione "
                "agisce su quel risultato."); return
        edifici = self.project.mapLayer(esito["layer"])
        if not isinstance(edifici, QgsVectorLayer):
            QMessageBox.warning(self, "Livello non disponibile",
                "Il livello analizzato non è più nel progetto."); return
        fids = list(esito["fids"])
        if not fids:
            QMessageBox.information(self, "Niente da eliminare",
                "L'analisi non ha trovato edifici in carreggiata."); return

        percorso = self.txt_ed_file.text().strip()
        if not percorso:
            self._scegli_file_scarti()
            percorso = self.txt_ed_file.text().strip()
            if not percorso:
                return
        nome_scarto = self._nome_layer_scarti(esito["gruppo"])

        avviso = ""
        if esito.get("parziale"):
            avviso = ("\n\nATTENZIONE: l'analisi era stata interrotta, quindi questo è "
                      "un risultato parziale.")
        if QMessageBox.question(
                self, "Conferma l'eliminazione",
                f"Elimino {len(fids)} edifici da '{edifici.name()}' "
                f"({esito['gruppo']}).\n\nPrima vengono scritti in:\n{percorso}\n"
                f"livello '{nome_scarto}'\n\nLa cancellazione avviene solo se il "
                f"salvataggio risulta completo, ed è annullabile dal terzo "
                f"pulsante.{avviso}\n\nProcedo?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return

        righe = [f"── {esito['gruppo']} ──"]
        selezione_precedente = edifici.selectedFeatureIds()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            edifici.selectByIds(fids)
            opzioni = QgsVectorFileWriter.SaveVectorOptions()
            opzioni.driverName = "GPKG"
            opzioni.layerName = nome_scarto
            opzioni.fileEncoding = "UTF-8"
            opzioni.onlySelectedFeatures = True
            # Il file raccoglie una regione per livello: se esiste già va
            # riscritto SOLO il livello di questa regione, altrimenti la prima
            # cancellazione della seconda regione cancellerebbe gli scarti della
            # prima insieme al file.
            opzioni.actionOnExistingFile = (
                QgsVectorFileWriter.CreateOrOverwriteLayer if os.path.exists(percorso)
                else QgsVectorFileWriter.CreateOrOverwriteFile)
            errore = QgsVectorFileWriter.writeAsVectorFormatV3(
                edifici, percorso, self.project.transformContext(), opzioni)
            codice = errore[0] if isinstance(errore, tuple) else errore
            if codice != QgsVectorFileWriter.NoError:
                dettaglio = (errore[1] if isinstance(errore, tuple) and len(errore) > 1
                             else str(errore))
                raise RuntimeError(f"Salvataggio degli scarti fallito:\n{dettaglio}")

            # verifica prima di cancellare: se il file non si riapre o contiene un
            # numero diverso di elementi, la cancellazione non parte
            controllo = QgsVectorLayer(f"{percorso}|layername={nome_scarto}",
                                       "controllo_scarti", "ogr")
            if not controllo.isValid():
                raise RuntimeError(
                    f"Il livello '{nome_scarto}' non è rileggibile da {percorso}: "
                    "non cancello niente.")
            n_salvati = controllo.featureCount()
            del controllo
            if n_salvati != len(fids):
                raise RuntimeError(
                    f"Salvati {n_salvati} elementi su {len(fids)} attesi: non cancello "
                    "niente. Controlla lo spazio su disco e che il GeoPackage non sia "
                    "aperto altrove.")
            righe.append(f"messi da parte : {n_salvati} in '{nome_scarto}' ({percorso})")

            era = edifici.isEditable()
            if not self._start_edit(edifici):
                raise RuntimeError(f"Impossibile avviare la modifica su '{edifici.name()}'.")
            # una sola chiamata per tutti gli id e un solo commit: cancellare una
            # feature per volta su un livello con centinaia di migliaia di
            # elementi significa altrettante scritture sul provider
            if not edifici.deleteFeatures(fids):
                edifici.rollBack()
                raise RuntimeError("Il provider ha rifiutato la cancellazione.")
            if not era and not self._commit(edifici, "Errore eliminazione edifici"):
                raise RuntimeError("Commit rifiutato: vedi il dettaglio nel popup.")
            edifici.triggerRepaint()
            righe.append(f"eliminati      : {len(fids)} da '{edifici.name()}'")
        except Exception as e:
            edifici.selectByIds(selezione_precedente)
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Errore", str(e))
            righe.append(f"ERRORE: {e}")
            self.log_ed.setPlainText("\n".join(righe))
            self._mostra_stato(self.stato_ed, "Eliminazione non eseguita.", ok=False)
            return
        finally:
            if QApplication.overrideCursor() is not None:
                QApplication.restoreOverrideCursor()

        self._edifici_cancellati = {
            "gruppo": esito["gruppo"],
            "layer": edifici.id(),
            "file": percorso,
            "livello": nome_scarto,
            "quanti": len(fids),
        }
        self._edifici_trovati = None

        if self.chk_ed_carica.isChecked():
            scarti = QgsVectorLayer(f"{percorso}|layername={nome_scarto}",
                                    f"Scartati — {esito['gruppo']}", "ogr")
            if scarti.isValid():
                self.project.addMapLayer(scarti)
                righe.append(f"livello degli scarti caricato nel progetto: "
                             f"'Scartati — {esito['gruppo']}' — lo trovi IN CIMA "
                             f"al pannello Layer, fuori dai gruppi regione")
            else:
                righe.append(f"ATTENZIONE: il livello '{nome_scarto}' non si è potuto "
                             f"ricaricare da {percorso} — il file è stato scritto, ma "
                             f"va aggiunto a mano (Layer → Aggiungi layer vettoriale)")

        righe.append("")
        righe.append("Se il risultato non ti convince, il terzo pulsante rimette dentro "
                     "gli elementi rileggendoli dal GeoPackage. Nota: i nuovi elementi "
                     "riceveranno identificativi diversi da quelli di prima, perché il "
                     "provider li assegna alla scrittura.")
        self.log_ed.setPlainText("\n".join(righe))
        self._mostra_stato(self.stato_ed,
                           f"{esito['gruppo']}: {len(fids)} edifici eliminati e messi da parte.")

    def _annulla_cancellazione_edifici(self):
        ultima = self._edifici_cancellati
        if not ultima:
            QMessageBox.information(self, "Niente da annullare",
                "In questa sessione non risulta nessuna cancellazione."); return
        edifici = self.project.mapLayer(ultima["layer"])
        if not isinstance(edifici, QgsVectorLayer):
            QMessageBox.warning(self, "Livello non disponibile",
                "Il livello da cui erano stati eliminati non è più nel progetto."); return

        sorgente = QgsVectorLayer(f"{ultima['file']}|layername={ultima['livello']}",
                                  "scarti_da_ripristinare", "ogr")
        if not sorgente.isValid():
            QMessageBox.critical(self, "File non leggibile",
                f"Non riesco a rileggere '{ultima['livello']}' da:\n{ultima['file']}"); return

        if QMessageBox.question(
                self, "Conferma il ripristino",
                f"Rimetto {sorgente.featureCount()} edifici in '{edifici.name()}' "
                f"({ultima['gruppo']}).\n\nProcedo?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
            return

        campi_dest = edifici.fields()
        era = edifici.isEditable()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            if not self._start_edit(edifici):
                raise RuntimeError(f"Impossibile avviare la modifica su '{edifici.name()}'.")
            nuove = []
            for f in sorgente.getFeatures():
                nuova = QgsFeature(campi_dest)
                nuova.setGeometry(f.geometry())
                for campo in f.fields():
                    nome = campo.name()
                    # 'fid' è la chiave primaria che il GeoPackage aggiunge da sé:
                    # riproporla in scrittura significa chiedere al provider di
                    # destinazione un identificativo che potrebbe essere già in uso.
                    if nome.lower() == "fid":
                        continue
                    i = campi_dest.indexOf(nome)
                    if i >= 0:
                        nuova.setAttribute(i, f[nome])
                nuove.append(nuova)
            if not edifici.addFeatures(nuove):
                edifici.rollBack()
                raise RuntimeError("Il provider ha rifiutato l'inserimento.")
            if not era and not self._commit(edifici, "Errore ripristino edifici"):
                raise RuntimeError("Commit rifiutato: vedi il dettaglio nel popup.")
            edifici.triggerRepaint()
        except Exception as e:
            QApplication.restoreOverrideCursor()
            QMessageBox.critical(self, "Errore", str(e))
            self._mostra_stato(self.stato_ed, "Ripristino non riuscito.", ok=False)
            return
        finally:
            if QApplication.overrideCursor() is not None:
                QApplication.restoreOverrideCursor()

        quanti = len(nuove)
        self._edifici_cancellati = None
        self.log_ed.setPlainText(
            f"Ripristinati {quanti} edifici in '{edifici.name()}' dal livello "
            f"'{ultima['livello']}' di {ultima['file']}.\n\n"
            "Gli identificativi sono nuovi: il contenuto è identico, ma non sono gli "
            "stessi numeri di prima. Il livello nel GeoPackage resta dov'è, così puoi "
            "ancora consultarlo.")
        self._mostra_stato(self.stato_ed, f"{quanti} edifici rimessi nel livello.")

    # ═══════════════════════════════════════════════════════ GUIDA
    # una voce per scheda: titolo e testo in HTML. Tenuta qui e non in un file
    # esterno perché deve viaggiare col plugin senza dipendere da percorsi.
    GUIDE = {
        "screening": ("Screening territorio", """
<h3>A cosa serve</h3>
<p>Dato il nome di un comune, produce la <b>pre-istruttoria</b> per le
richieste di scavo su suolo pubblico: quali e quante strade classificate ci
sono (statali ANAS, provinciali, regionali, autostrade) e chi le gestisce,
quale Soprintendenza ABAP è competente (con la PEC), quali vincoli
paesaggistici nazionali insistono sul territorio (art. 136, art. 142, parchi,
UNESCO) e quali interferenze lineari esistono (ferrovie con la fascia di 30 m,
corsi d'acqua). Chiude con l'elenco degli enti da interpellare: titolo
richiesto, riferimenti normativi, documentazione tipica e criticità note.</p>
<h3>Come si usa</h3>
<ol>
<li>Scrivi il nome del comune; la provincia serve solo se il nome è ambiguo
(es. Peschiera, Samone).</li>
<li>Scegli l'<b>ambito</b>: <b>sul tracciato</b> (default — misura la distanza
reale tra 03 INFRASTRUTTURE + pozzetti + armadi e ogni ente, e la confronta con
la fascia di rispetto ufficiale: attraversamento o entro fascia), oppure
<b>sull'area di progetto</b> (ARLO: tutto ciò che la interseca, più prudente).
Il margine attorno al tracciato è regolabile. Lo <b>stradario di riferimento</b>
viene <b>preselezionato in automatico</b> sul miglior layer presente nel progetto
(prima il DBSN dell'IGM, poi un grafo regionale, e solo come ultima scelta un
estratto OSM) usato come fonte primaria delle strade, con OSM come controprova e
le discordanze segnalate; puoi cambiarlo o togliere la spunta. Poi i layer in
mappa (gruppo
"Screening &lt;comune&gt;"), il report Markdown e il <b>report Excel</b> con
gli enti riga per riga, salvati accanto al file di progetto.</li>
<li>Premi <b>Avvia screening</b> e segui il registro: ogni stadio dichiara la
fonte interrogata e cosa ha trovato. Servono 1–3 minuti.</li>
</ol>
<h3>Attenzione</h3>
<p>È una <b>ricognizione, non una certificazione</b>. OSM non è autoritativo:
la classificazione delle strade e l'ente gestore vanno confermati presso gli
enti. SITAP è ricognitivo e la copertura varia da regione a regione; i vincoli
ex art. 142 (fasce fluviali di 150 m, boschi…) operano <b>anche se non
cartografati</b>. Il report chiude con la tabella di provenienza e confidenza
dei dati: leggila. Non copre: vincolo idrogeologico, PAI, usi civici, PUGSS,
sottoservizi esistenti (SINFI), servitù militari.</p>
"""),
        "pulizia": ("Seleziona elementi", """
<h3>A cosa serve</h3>
<p>Seleziona in mappa gli elementi di rete da mettere a permesso, applicando
le regole una dopo l'altra: quello che resta selezionato è ciò che finirà
nella pratica.</p>
<h3>Come si usa</h3>
<ol>
<li>Imposta i layer nei campi in cima: sono quelli su cui lavorano tutte le
regole della scheda.</li>
<li>Attiva le regole che ti servono e premi il pulsante di ciascuna. Ogni
regola lavora <b>sulla selezione corrente</b>, quindi l'ordine conta.</li>
<li>Controlla il conteggio nel log dopo ogni passo: se una regola seleziona
zero elementi, il problema è quasi sempre un layer sbagliato o una
tolleranza troppo stretta, non la regola.</li>
</ol>
<h3>Attenzione</h3>
<p>Le regole non modificano i dati, cambiano solo la selezione. Puoi rilanciarle
quante volte vuoi senza rischi.</p>
"""),
        "shp2gpkg": ("Shape → GeoPackage", """
<h3>A cosa serve</h3>
<p>Crea il <b>gemello GeoPackage</b> di uno shapefile: stesso percorso, stesso
nome (<code>.gpkg</code> accanto al <code>.shp</code>), con uno stile già
applicato. Comodo per passare dai vecchi shapefile al formato GeoPackage senza
perdere la simbologia.</p>
<h3>Come si usa</h3>
<ol>
<li>Scegli lo shape: un layer del progetto dal menu, <b>oppure</b> un file
<code>.shp</code> dal disco con <b>Sfoglia</b> (il file ha la precedenza).</li>
<li>Scegli lo stile <code>.qml</code> (predefinito <b>02_POZZETTO</b>); puoi
anche indicarne uno qualsiasi dal disco.</li>
<li>Decidi se il GeoPackage deve <b>sostituire</b> lo shape nel progetto o
essere aggiunto <b>accanto</b> (spunta).</li>
<li>Premi <b>Crea il gemello GeoPackage</b>.</li>
</ol>
<h3>Attenzione</h3>
<p>Lo shapefile su disco <b>non viene toccato</b>: il <code>.gpkg</code> è un
file nuovo. Se un <code>.gpkg</code> con lo stesso nome esiste già, viene
riscritto da zero.</p>
"""),
        "allinea": ("Allinea cartografia", """
<h3>A cosa serve</h3>
<p>Sposta e ruota la cartografia di appoggio per farla combaciare con la base
di riferimento, quando le due non sono sovrapposte.</p>
<h3>Come si usa</h3>
<ol>
<li>Scegli il layer da spostare e quello di riferimento.</li>
<li>Indica le coppie di punti corrispondenti con i pulsanti di raccolta dal
canvas: clicca prima sul punto della cartografia da spostare, poi su quello
corrispondente del riferimento.</li>
<li>Applica la trasformazione e verifica a vista; se non torna, aggiungi una
coppia di punti invece di correggere a mano.</li>
</ol>
"""),
        "edifici": ("Edifici in carreggiata", """
<h3>A cosa serve</h3>
<p>Nei dati cartografici di base capita che geometrie di <b>edifici minori</b>
cadano dentro il poligono della carreggiata: non sono edifici, sono errori del
dato. Questa scheda li trova e li elimina, <b>una regione alla volta</b>.</p>
<h3>Come si usa</h3>
<ol>
<li>Premi <b>Cerca le regioni nel progetto</b>: il plugin percorre l'albero dei
livelli e mostra i gruppi che contengono sia le strade sia gli edifici minori.
Se il tuo progetto usa nomi diversi, correggi le due chiavi di ricerca.</li>
<li>Seleziona <b>una</b> regione e premi <b>Analizza</b>. Nessun dato viene
modificato: gli edifici trovati vengono soltanto selezionati in mappa perché tu
li possa controllare.</li>
<li>Indica il GeoPackage degli scarti, poi premi <b>Metti da parte ed elimina</b>.
Gli elementi vengono prima scritti nel file, poi cancellati — e solo se il
salvataggio risulta completo.</li>
<li>Passa alla regione successiva.</li>
</ol>
<h3>Il criterio</h3>
<p>Un edificio viene eliminato solo se è <b>contenuto per intero</b> nella
carreggiata. Uno che sporge anche di poco resta dov'è: è la scelta prudente,
perché a bordo strada gli edifici veri toccano quasi sempre il poligono.</p>
<p>La carreggiata è spezzata in tronchi, e un edificio a cavallo di due tronchi
adiacenti non è contenuto in nessuno dei due preso da solo. Per questo l'opzione
<b>unisci i tronchi adiacenti</b> va tenuta attiva: il log dice quanti edifici
sono stati riconosciuti soltanto grazie a lei.</p>
<h3>Se il livello strade è lineare</h3>
<p>Nel DBSN il livello delle strade contiene i <b>limiti della carreggiata</b>:
due linee parallele per ogni strada, con in mezzo la sede stradale, che però non
esiste come geometria. Senza un poligono il contenimento non è applicabile, e il
criterio predefinito diventa un altro.</p>
<p><b>Un bordo attraversa l'edificio.</b> Se la linea di limite passa dentro un
edificio, quell'edificio è in mezzo alla strada. Non serve sapere quanto è larga
la carreggiata — ed è il punto debole dell'alternativa, perché sulla stessa
regione convivono strade da quattro metri e da dodici mentre un buffer ne usa una
sola.</p>
<p><b>Il test del corridoio</b> copre il caso che l'attraversamento perderebbe:
un edificio minore piccolo, tutto dentro la carreggiata, che non arriva a toccare
né l'uno né l'altro limite. Il plugin guarda il bordo più vicino al centro
dell'edificio e cerca un altro bordo dalla parte opposta entro la larghezza
massima impostata. Un edificio appena fuori strada ha un bordo da un lato e
niente dall'altro, quindi non scatta.</p>
<p>Il criterio del <b>buffer</b> resta disponibile, ma allarga la linea in
entrambe le direzioni: applicato a un limite di carreggiata produce area anche
sul lato esterno della strada, e prende edifici che stanno fuori.</p>
<h3>Attenzione</h3>
<p>L'eliminazione è annullabile solo finché il pannello resta aperto: il terzo
pulsante rilegge dal GeoPackage. Il file però resta sul disco anche dopo, quindi
un ripristino tardivo si può sempre fare a mano con «Aggiungi livello».</p>
<p>Se premi <b>Interrompi</b> il conteggio riguarda solo la parte esaminata: in
quel caso conviene rilanciare l'analisi invece di eliminare un risultato
parziale.</p>
"""),
        "keyplan": ("Keyplan e tavole", """
<h3>A cosa serve</h3>
<p>Genera automaticamente la copertura delle tavole di inquadramento sulla rete
selezionata, senza sovrapposizioni, e il keyplan d'insieme.</p>
<h3>Come si usa</h3>
<ol>
<li>Prepara la selezione nella scheda <i>Seleziona elementi</i>: le tavole
vengono costruite su ciò che è selezionato.</li>
<li>Imposta scala e formato: da questi due dipende quanta rete entra in una
tavola, quindi quante tavole otterrai.</li>
<li>Genera. Per rifare solo una zona, usa la rigenerazione mirata invece di
ricostruire tutto: le tavole già approvate restano come sono.</li>
</ol>
"""),
        "coni": ("Punti di ripresa", """
<h3>A cosa serve</h3>
<p>Crea i punti di ripresa fotografica davanti agli Armadi Ottici e sugli
attraversamenti, con il cono di inquadratura orientato correttamente.</p>
<h3>Come si usa</h3>
<ol>
<li>Imposta Armadio Ottico, Punto di Ripresa e Stradario, più le distanze di
ripresa.</li>
<li>Genera i coni. La camera viene arretrata lungo la strada e l'inquadratura
orientata verso il soggetto.</li>
<li>Sugli attraversamenti il soggetto è già sulla strada: in quel caso la
camera viene spostata lungo la strada stessa e l'inquadratura forzata
perpendicolare, che è la foto che serve in pratica.</li>
</ol>
"""),
        "chilometriche": ("Chilometriche", """
<h3>A cosa serve</h3>
<p>Scrive la progressiva chilometrica su pozzetti, armadi e tratte, misurandola
lungo la strada a partire dai cippi.</p>
<h3>Come si usa</h3>
<ol>
<li><b>Passo 1 — crea il campo.</b> Seleziona nel pannello Livelli gli shape su
cui ti serve e premi il pulsante. Sugli shapefile il nome viene accorciato a
10 caratteri, quindi <i>Chilometrica</i> diventa <i>Chilometri</i>: è normale
e il plugin riconosce entrambe le forme.</li>
<li><b>Passo 2 — i cippi.</b> Scegli il layer dei cippi e il campo che contiene
il valore. Il formato va dichiarato: <i>17+100</i> è km 17 più 100 metri; se
hai digitato prima i metri (<i>100+17</i>) scegli la voce INVERTITO.</li>
<li><b>Passo 3 — calcola.</b> Scegli la linea di riferimento, il layer target e
il campo di output, poi seleziona in mappa gli elementi e calcola.</li>
</ol>
<h3>Come conta</h3>
<p>Uno stradario è spezzato in centinaia di tratte: il plugin le ricuce prima in
<b>corridoi continui</b>, poi misura tutto lungo quelli. La chilometrica di un
elemento è il valore del cippo più basso più la distanza reale percorsa sulla
strada, un metro per un metro, nel verso in cui i km crescono. Gli altri cippi
non spostano il conteggio: servono da controverifica, e il log segnala se uno
di essi non sta dove la progressione lo colloca.</p>
<h3>Se non calcola</h3>
<p>Premi <b>Diagnostica</b> prima di cambiare i parametri a caso: dice quanti
cippi ha letto e quali ha scartato, quanti corridoi ha ricucito, quali elementi
non si agganciano e a che distanza stanno. Le due cause più frequenti sono la
tolleranza troppo stretta e un formato del cippo dichiarato male.</p>
"""),
        "etichette": ("Etichette", """
<h3>A cosa serve</h3>
<p>Compila un campo di testo su Armadio, Pozzetto e Infrastrutture con la
dicitura di posa da stampare in tavola, e attiva l'etichettatura in mappa.</p>
<h3>Come si usa</h3>
<ol>
<li><b>Passo 1</b> — i tre layer e il nome del campo da scrivere.</li>
<li><b>Passo 2</b> — la dicitura di ciascun layer e il campo che la completa.
Se non sai quale campo contiene la tecnica di scavo, premi <b>Ispeziona i
campi</b>: elenca ogni campo con alcuni valori di esempio.</li>
<li><b>Passo 3</b> — quali elementi elaborare.</li>
<li><b>Passo 4</b> — la resa in mappa.</li>
<li>Premi <b>Anteprima</b> prima di scrivere: mostra le etichette che
otterresti senza toccare i dati.</li>
</ol>
<h3>Leggibilità sullo sfondo</h3>
<p>Su una CTR il testo nero cade su un intreccio di linee nere e l'alone da solo
non basta, perché il tratteggio continua a leggersi dentro le lettere. Il
riquadro bianco semitrasparente è la scelta delle tavole professionali: stacca
il testo da qualunque sfondo restando discreto.</p>
<h3>Attenzione</h3>
<p>QGIS ammette una sola etichettatura per layer: assegnandone una nuova, quella
che c'era viene cancellata. Se sul layer hai già un'etichetta che vuoi tenere,
spunta <i>Conserva l'etichettatura già presente</i>: la vecchia viene convertita
in regola e la nuova si aggiunge come seconda regola.</p>
"""),
        "suolo": ("Suolo comunale", """
<h3>A cosa serve</h3>
<p>Separare gli elementi che non ricadono sugli stradari dell'ente da quelli che
vi ricadono, per poterli spegnere quando si stampa la tavola per quell'ente.</p>
<h3>Come si usa</h3>
<ol>
<li>Scegli gli stradari di competenza dell'ente (SP, ANAS, altro): possono essere
più di uno, si tengono premuti Ctrl e si clicca.</li>
<li>Scegli i livelli da analizzare e la distanza massima dall'asse oltre la quale
un elemento è considerato fuori.</li>
<li>Premi <b>1. Evidenzia</b>: gli elementi fuori vengono <b>selezionati in
mappa</b> e la vista si porta su di loro. Controllali a vista. Se la selezione
non torna, ritocca la tolleranza e rilancia: finché non premi il secondo
pulsante non viene modificato niente.</li>
<li>Premi <b>2. Sposta nel gruppo</b> per confermare.</li>
</ol>
<h3>Cosa fa lo spostamento</h3>
<p>Non cancella e non duplica geometrie. Scrive un campo <b>SUOLO</b> che
distingue i due casi, crea un gruppo di livelli filtrati sul valore
<i>COMUNALE</i> e applica il filtro complementare agli originali. I livelli del
gruppo nuovo sono cloni di quelli originali, quindi hanno la stessa sorgente e
<b>la stessa simbologia</b>: a vedersi sono identici.</p>
<p>A questo punto basta spegnere il gruppo per togliere dalla tavola gli elementi
su suolo comunale.</p>
<h3>Annullare</h3>
<p>Il terzo pulsante rimuove il gruppo e azzera i filtri. Il campo SUOLO resta
scritto negli attributi ma non filtra più nulla, quindi si può rifare l'analisi
da zero. Nessuna geometria è mai stata cancellata.</p>
<h3>Attenzione</h3>
<p>Sui livelli temporanei (in memoria) il filtro non è applicabile: in quel caso
le feature vengono copiate nel gruppo nuovo e l'originale resta intero. Il log lo
segnala.</p>
"""),
        "consegna": ("Esportazione", """
<h3>A cosa serve</h3>
<p>Tre cose distinte: generare gli shape di consegna, esportare i PDF dei layout
e unirli, ed evidenziare in tavola le strade interessate dai lavori.</p>
<h3>Shape di consegna</h3>
<p>Imposta i layer e la cartella di destinazione: i tre shape vengono generati
con i campi lunghezza aggiornati.</p>
<h3>Esportazione PDF</h3>
<p>Aggiorna l'elenco dei layout, seleziona quelli da esportare e lancia. I PDF
prodotti finiscono nell'elenco di unione, dove puoi riordinarli e fonderli in
un unico file.</p>
<h3>Evidenza delle strade</h3>
<p>Copre con un retino le tratte dello stradario su cui ricadono gli elementi di
progetto. Il layer prodotto è <b>temporaneo</b>: se ti serve nella tavola
stampata, clic destro sul layer e <i>Rendi permanente</i> prima di chiudere il
progetto.</p>
<p>Se il retino risulta interrotto, la causa quasi sempre è la
<i>Distanza max elemento → tratta</i>: gli scavi corrono a bordo strada mentre
lo stradario è l'asse, quindi su una carreggiata di 8-10 metri il bordo dista
4-5 metri dall'asse. Il log elenca gli elementi rimasti fuori e la loro
distanza reale: alza quel valore oltre il massimo indicato. In seconda battuta
agisci su <i>Colma i vuoti fino a</i>.</p>
"""),
    }

    def _mostra_guida(self, chiave):
        """Apre la guida della scheda in una finestra a sé, non modale, così
        si può continuare a lavorare con la guida aperta accanto."""
        titolo, corpo = self.GUIDE.get(chiave, ("Guida", "<p>Guida non disponibile.</p>"))
        finestra = QDialog(self)
        finestra.setWindowTitle(f"Guida — {titolo}")
        finestra.setMinimumSize(560, 520)
        v = QVBoxLayout(finestra)
        testo = QTextBrowser()
        testo.setOpenExternalLinks(True)
        testo.setHtml(f"<h2>{titolo}</h2>{corpo}")
        v.addWidget(testo)
        riga = QHBoxLayout()
        riga.addStretch()
        chiudi = QPushButton("Chiudi")
        chiudi.clicked.connect(finestra.close)
        riga.addWidget(chiudi)
        v.addLayout(riga)
        finestra.show()
        self._guide_aperte.append(finestra)  # riferimento: senza, il GC la chiude

    # ═══════════════════════════════════════════════ KEYPLAN – LOGICA
    def _messaggio_estensione_vuota(self):
        """Messaggio specifico (non generico) sul perché l'estensione
        risulta vuota, mostrato direttamente nel popup di errore invece di
        richiedere un secondo click su 'Diagnostica estensione'."""
        lyr = self.cb_kp_arlo.currentLayer()
        if not lyr:
            return ("Imposta il layer ARLO AREA (il poligono con tutte le aree\n"
                    "armadio da coprire): è l'unico layer usato per calcolare\n"
                    "l'estensione della griglia.")
        tot = lyr.featureCount()
        if tot == 0:
            return f"Il layer ARLO AREA scelto ('{lyr.name()}') non contiene nessuna feature."
        return (f"Il layer ARLO AREA scelto ('{lyr.name()}') ha {tot} feature, ma\n"
                "nessuna ha fornito una geometria valida (vuota, o non\n"
                "trasformabile nel CRS di progetto). Usa 'Diagnostica estensione'\n"
                "qui sotto per i dettagli, e controlla il CRS del layer.")

    def _diagnostica_estensione(self):
        """Mostra quante feature del layer ARLO AREA contribuiscono
        all'estensione (e quante vengono escluse per geometria nulla o per
        un errore di trasformazione CRS), oltre a quante parti separate ha
        la forma reale una volta fusa e quanto il suo bounding box la
        sovrastima — per capire subito il motivo di un'area vuota, più
        piccola del previsto, o (se il bbox è molto più grande dell'area
        reale) perché conviene la copertura 'a forma libera' invece che a
        griglia rettangolare."""
        lyr = self.cb_kp_arlo.currentLayer()
        righe = []
        if not lyr:
            righe.append("ARLO AREA: nessun layer impostato.")
        else:
            tot = lyr.featureCount()
            n_validi = 0; ext = None
            crs_prima = getattr(self, "_crs_errors", 0)
            for f in lyr.getFeatures():
                g = self._to_proj(f.geometry(), lyr)
                if not g or g.isEmpty(): continue
                n_validi += 1
                bb = g.boundingBox()
                ext = bb if ext is None else ext.combineExtentWith(bb)
            n_crs_err = getattr(self, "_crs_errors", 0) - crs_prima
            righe.append(f"ARLO AREA ('{lyr.name()}'): {n_validi} di {tot} feature usate.")
            if n_crs_err:
                righe.append(f"  → {n_crs_err} feature scartate per errore di trasformazione CRS (vedi console QGIS).")
            if tot and not n_validi:
                righe.append("  → tutte le feature hanno geometria nulla/vuota o non trasformabile:\n    controlla il CRS del layer rispetto a quello del progetto.")
            if ext:
                righe.append(f"Bounding box di tutte le feature: {ext.width():.0f} × {ext.height():.0f} m  —  {ext.toString(2)}")
                forma = self._dissolvi_arlo()
                if forma:
                    parti = self._parti_poligono(forma)
                    area_bbox = ext.width() * ext.height()
                    area_forma = forma.area()
                    righe.append(f"Forma reale fusa (quella usata per la copertura): area ≈{area_forma:.0f} m², {len(parti)} parte/i.")
                    if area_forma > 0:
                        rapporto = area_bbox / area_forma
                        righe.append(f"Il bounding box è ≈{rapporto:.1f}× più grande dell'area reale "
                                     f"({'molto sparsa/irregolare: bene usare la copertura a forma libera' if rapporto > 1.5 else 'abbastanza compatta'}).")
            else:
                righe.append("Estensione risultante: VUOTA.")
        msg = "\n".join(righe)
        self.log_kp.setPlainText(msg)
        QMessageBox.information(self, "Diagnostica estensione", msg)

    def _template_kp(self, kp_lyr):
        """Ritorna (feature, geometria in CRS di progetto) da usare come
        MODELLO di tavola dal layer Keyplan: la feature selezionata se ce n'è
        esattamente una, altrimenti la prima feature del layer. None se il
        layer non contiene nessuna geometria da cui prendere forma/dimensione."""
        if not kp_lyr: return None
        sel = list(kp_lyr.selectedFeatures())
        feats = sel if len(sel) == 1 else list(kp_lyr.getFeatures())
        if not feats: return None
        f = feats[0]
        g = self._to_proj(f.geometry(), kp_lyr)
        if not g or g.isEmpty(): return None
        return f, g

    def _forma_da_coprire(self):
        """Area da coprire per Keyplan e Tavole: rete nuova o ARLO AREA.

        Se la spunta «Costruisci l'area dalla RETE NUOVA» è attiva (predefinito)
        si copre l'intorno di Infrastrutture nuove, Pozzetti e Armadi; se quei
        layer non danno nulla si ricade su ARLO AREA, così il comando non si
        pianta mai per una scelta di default.

        Restituisce (forma, nome_target) con forma già bufferizzata, oppure
        (None, nome) se non c'è niente da coprire.
        """
        usa_rete = False
        try:
            usa_rete = self.chk_kp_usa_rete.isChecked()
        except Exception:
            pass

        if usa_rete:
            regione, diag = self._regione_rete_nuova()
            if regione is not None and not regione.isEmpty():
                nome = ("rete nuova (%d infrastrutture, %d pozzetti, %d armadi)"
                        % (diag["infra"], diag["pozzetti"], diag["armadi"]))
                return regione, nome
            _log_avviso("rete nuova non disponibile per la copertura: "
                        "si ripiega su ARLO AREA", None)

        forma = self._dissolvi_arlo()
        if not forma:
            return None, "ARLO AREA"
        try:
            forma = forma.buffer(self.spin_margine.value(), 8)
        except Exception:
            pass
        return forma, "ARLO AREA"

    def _regione_rete_nuova(self, raggio=None):
        """Area da coprire costruita sulla RETE NUOVA invece che su ARLO AREA.

        ARLO AREA è l'area di competenza dell'armadio: comprende strade dove non
        si posa nulla, quindi genera tavole vuote. Quello che va documentato è
        dove si lavora davvero: Infrastrutture NUOVE (escluse le Aeree), Pozzetti
        e Armadi Ottici. Qui si prendono quelle geometrie, si bufferizzano del
        raggio indicato e si fondono: il risultato è un "nastro" che segue la
        rete e che la copertura adattiva riempie di tavole.

        Restituisce (geometria, diagnostica) con geometria None se non c'è nulla
        da coprire, così il chiamante può ripiegare su ARLO AREA.
        """
        if raggio is None:
            try:
                raggio = float(self.spin_kp_raggio_rete.value())
            except Exception:
                raggio = 30.0

        diag = {"infra": 0, "pozzetti": 0, "armadi": 0, "scartate_aeree": 0}
        geoms = []

        # --- Infrastrutture: solo STATO='Nuovo', escluse le Aeree (come nei coni)
        infra = None
        for cb in ("cb_kf_infra", "cb_k_infra", "cb_kp_infra"):
            if hasattr(self, cb):
                try:
                    infra = getattr(self, cb).currentLayer()
                except Exception:
                    infra = None
                if infra is not None:
                    break
        if infra is not None:
            i_stato = infra.fields().indexOf(CAMPO_STATO)
            i_tip = infra.fields().indexOf(CAMPO_TIP_INFRA)
            for f in infra.getFeatures():
                try:
                    if i_stato >= 0:
                        v = f[i_stato]
                        if v is None or str(v).strip().lower() != VAL_NUOVO.strip().lower():
                            continue
                    if i_tip >= 0:
                        t = f[i_tip]
                        if t is not None and str(t).strip().lower() == VAL_AEREA.strip().lower():
                            diag["scartate_aeree"] += 1
                            continue
                    g = self._to_proj(f.geometry(), infra)
                    if g and not g.isEmpty():
                        geoms.append(g); diag["infra"] += 1
                except Exception:
                    continue

        # --- Pozzetti e Armadi: tutti quelli presenti (sono gli elementi da posare)
        for attr, chiave in (("cb_kf_pozzetto", "pozzetti"), ("cb_k_armadio", "armadi")):
            lyr = None
            if hasattr(self, attr):
                try:
                    lyr = getattr(self, attr).currentLayer()
                except Exception:
                    lyr = None
            if lyr is None:
                continue
            i_stato = lyr.fields().indexOf(CAMPO_STATO)
            solo_nuovi = False
            try:
                solo_nuovi = self.chk_kp_solo_nuovi.isChecked()
            except Exception:
                pass
            for f in lyr.getFeatures():
                try:
                    if solo_nuovi and i_stato >= 0:
                        v = f[i_stato]
                        if v is None or str(v).strip().lower() != VAL_NUOVO.strip().lower():
                            continue
                    g = self._to_proj(f.geometry(), lyr)
                    if g and not g.isEmpty():
                        geoms.append(g); diag[chiave] += 1
                except Exception:
                    continue

        if not geoms:
            self._elementi_rete = []
            return None, diag

        # gli elementi grezzi servono alla verifica di copertura: la regione
        # bufferizzata dice DOVE lavorare, ma solo gli elementi dicono se una
        # tavola è davvero necessaria o se qualcuno è rimasto fuori.
        self._elementi_rete = list(geoms)

        try:
            unione = QgsGeometry.unaryUnion(geoms)
            if unione is None or unione.isEmpty():
                return None, diag
            regione = unione.buffer(float(raggio), 8)
            if regione is None or regione.isEmpty():
                return None, diag
            return regione, diag
        except Exception as e:
            _log_avviso("costruzione regione rete nuova non riuscita", e)
            return None, diag

    def _elementi_scoperti(self, tessere, elementi=None):
        """Elementi della rete che NON stanno dentro nessuna tavola.

        La copertura adattiva ragiona per AREA: riempie la regione finché resta
        spazio per un'altra tavola senza sovrapposizioni. Ma la regione della
        rete nuova è fatta di corridoi stretti lungo le strade, e in quella
        forma restano inevitabilmente ritagli troppo stretti per un'altra
        tavola: l'«area residua» segnalata a fine corsa. Se in quei ritagli
        cade un pozzetto, il pozzetto resta fuori da ogni tavola.

        Qui si controlla la cosa che conta davvero — gli ELEMENTI, non l'area.
        Una linea è considerata coperta solo se sta TUTTA dentro l'unione delle
        tavole: una tratta a cavallo di due tavole che non si toccano verrebbe
        altrimenti data per buona pur avendo un pezzo scoperto.
        """
        if elementi is None:
            elementi = getattr(self, "_elementi_rete", []) or []
        if not elementi or not tessere:
            return list(elementi)

        idx = QgsSpatialIndex()
        geoms_t = {}
        for i, (g, _s) in enumerate(tessere):
            f = QgsFeature(i); f.setGeometry(g)
            idx.addFeature(f); geoms_t[i] = g

        scoperti = []
        for g in elementi:
            try:
                vicine = [geoms_t[i] for i in idx.intersects(g.boundingBox())]
                if not vicine:
                    scoperti.append(g); continue
                unione = QgsGeometry.unaryUnion(vicine)
                if unione is None or unione.isEmpty():
                    scoperti.append(g); continue
                if not unione.contains(g):
                    scoperti.append(g)
            except Exception:
                scoperti.append(g)
        return scoperti

    def _copertura_a_reticolo(self, dims, elementi, forma=None):
        """Copertura a RETICOLO allineato al modello: celle W×H adiacenti, di cui
        si tengono solo quelle che contengono rete.

        Perché un reticolo e non la disposizione libera: le tavole piazzate
        liberamente lungo i corridoi stretti della rete nuova lasciavano ritagli
        scoperti, e le tavole-toppa che li chiudevano finivano sovrapposte alle
        vicine. Un reticolo risolve le tre cose insieme, per costruzione e non
        per tentativi:

          - MAI sovrapposte: le celle sono una partizione del piano, due celle
            distinte non hanno punti in comune;
          - rete tutta coperta: ogni punto del piano sta in esattamente una
            cella; la cella che contiene un pezzo di rete interseca quella rete,
            quindi viene tenuta. Nessun elemento può cadere fuori;
          - solo dove serve: le celle senza rete dentro non vengono create,
            che è quello che prima richiedeva il secondo passaggio
            «rigenera solo sulla rete».

        Il `gap` non si applica: le celle sono adiacenti per non lasciare
        strisce scoperte fra una tavola e l'altra.

        Ritorna [(geom, etichetta), …].
        """
        if not dims or not elementi:
            return []
        etichetta, larg, alt = dims[0]
        if larg <= 0 or alt <= 0:
            return []

        bb = None
        for g in elementi:
            b = g.boundingBox()
            bb = QgsRectangle(b) if bb is None else bb
            bb.combineExtentWith(b)
        if bb is None or bb.isEmpty():
            return []

        # origine scelta per centrare la rete nel reticolo: senza questo la
        # griglia parte dallo spigolo della rete e l'ultima fila di tavole
        # resta quasi vuota.
        n_x = max(1, int(math.ceil(bb.width() / larg)))
        n_y = max(1, int(math.ceil(bb.height() / alt)))
        ox = bb.xMinimum() - (n_x * larg - bb.width()) / 2.0
        oy = bb.yMinimum() - (n_y * alt - bb.height()) / 2.0

        # indice degli elementi, per non confrontare ogni cella con tutta la rete
        idx = QgsSpatialIndex()
        per_id = {}
        for i, g in enumerate(elementi):
            f = QgsFeature(i); f.setGeometry(g)
            idx.addFeature(f); per_id[i] = g

        # si visitano solo le celle toccate dai bounding box degli elementi:
        # scorrere tutto il rettangolo della rete sarebbe sprecato quando la
        # rete è un insieme di corridoi sottili.
        celle = set()
        for g in elementi:
            b = g.boundingBox()
            i0 = int(math.floor((b.xMinimum() - ox) / larg))
            i1 = int(math.floor((b.xMaximum() - ox) / larg))
            j0 = int(math.floor((b.yMinimum() - oy) / alt))
            j1 = int(math.floor((b.yMaximum() - oy) / alt))
            for i in range(i0, i1 + 1):
                for j in range(j0, j1 + 1):
                    celle.add((i, j))

        tessere = []
        for (i, j) in sorted(celle):
            rett = QgsRectangle(ox + i * larg, oy + j * alt,
                                ox + (i + 1) * larg, oy + (j + 1) * alt)
            cella = QgsGeometry.fromRect(rett)
            tiene = False
            for cid in idx.intersects(rett):
                g = per_id.get(cid)
                if g is not None and g.intersects(cella):
                    tiene = True; break
            if tiene:
                tessere.append((cella, etichetta))
        return tessere

    def _verifica_tessere(self, tessere, elementi=None):
        """Controlla il risultato invece di darlo per buono.

        Ritorna (n_sovrapposte, n_scoperti): coppie di tavole che si
        sovrappongono e elementi che non stanno dentro nessuna tavola. Con il
        reticolo devono essere entrambi 0; se non lo sono è un errore da
        mostrare, non da nascondere.
        """
        n_sov = 0
        idx = QgsSpatialIndex()
        geoms = {}
        for i, (g, _s) in enumerate(tessere):
            f = QgsFeature(i); f.setGeometry(g)
            idx.addFeature(f); geoms[i] = g
        for i, g in geoms.items():
            for j in idx.intersects(g.boundingBox()):
                if j <= i:
                    continue
                try:
                    inter = g.intersection(geoms[j])
                    # i bordi in comune non sono sovrapposizione: conta l'area
                    if inter and not inter.isEmpty() and inter.area() > 1e-6:
                        n_sov += 1
                except Exception:
                    pass
        return n_sov, len(self._elementi_scoperti(tessere, elementi))

    def _numera_appena_generate(self, lyr, widget_campo):
        """Numera subito le tavole appena generate, sul layer temporaneo.

        Numerare a fine generazione evita che le tavole restino senza numero
        fino a quando non ci si ricorda di premere il pulsante: senza numero i
        layout non sanno cosa stampare. Se fallisce non si blocca la
        generazione — le tavole ci sono comunque e il pulsante manuale resta.

        Ritorna una riga di resoconto, o stringa vuota se non ha fatto nulla.
        """
        try:
            campo = (widget_campo.text() or "").strip()
            if not campo or lyr is None:
                return ""
            n, n_letti = self._numera_per_posizione(lyr, campo)
            return (f"Numerate automaticamente {n} tavole su {n_letti} "
                    f"(campo '{campo}', ordine nord→sud, ovest→est).\n")
        except Exception as e:
            _log_avviso("numerazione automatica a fine generazione non riuscita", e)
            return "Numerazione automatica non riuscita: usa il pulsante «Numera Keyplan e Tavole».\n"

    def _copia_nel_modello(self, chiave, combo, etichetta, chk_sovrascrivi=None):
        """Copia le tavole generate dal layer temporaneo al layer MODELLO scelto.

        Il generatore scrive in un layer memory ('Keyplan', 'Poligoni
        Inquadramento') che vive solo nella sessione: comodo per guardare il
        risultato prima di accettarlo, inutile per i layout, che puntano al
        layer vero (Keyplan Quadrato, Keyplan Rettangolare, Poligoni di
        Inquadramento). Questo porta le tavole dove servono, scegliendo la
        destinazione in base al modello selezionato — quadrato o rettangolare,
        secondo quello che hai impostato tu.

        Le tavole vengono AGGIUNTE, oppure SOSTITUISCONO quelle già presenti se
        la casella «Sostituisci» è spuntata. In sostituzione la feature-modello
        NON viene toccata: è quella da cui si ricavano forma e dimensione delle
        tavole, e cancellandola la generazione successiva non avrebbe più un
        modello da cui partire.
        """
        temp = (getattr(self, "_output_layers", {}) or {}).get(chiave)
        if temp is None or not temp.isValid():
            QMessageBox.warning(
                self, "Nessuna tavola da copiare",
                f"Non c'è un layer temporaneo «{etichetta}» in questa sessione.\n"
                "Genera prima la copertura."); return

        dest = combo.currentLayer()
        if dest is None:
            QMessageBox.warning(
                self, "Layer di destinazione mancante",
                "Scegli il layer modello di destinazione (es. Keyplan Quadrato\n"
                "o Keyplan Rettangolare)."); return
        if dest.id() == temp.id():
            QMessageBox.warning(self, "Destinazione uguale all'origine",
                                "Il layer di destinazione è il layer temporaneo stesso."); return

        feats = list(temp.getFeatures())
        if not feats:
            QMessageBox.warning(self, "Nessuna tavola", "Il layer temporaneo è vuoto."); return

        n_dest = dest.featureCount()
        sovrascrivi = bool(chk_sovrascrivi is not None and chk_sovrascrivi.isChecked())

        # in sostituzione si risparmia la feature-modello: è la stessa che la
        # generazione usa come stampo (selezionata, o la prima se non c'è
        # selezione), quindi la si individua allo stesso modo.
        id_modello = None
        da_togliere = []
        if sovrascrivi:
            try:
                t = self._template_kp(dest)
                if t:
                    id_modello = t[0].id()
            except Exception as e:
                _log_avviso("individuazione della feature modello non riuscita", e)
            if id_modello is None:
                # senza modello identificato NON si svuota il layer: cancellare
                # tutto lascerebbe la generazione successiva senza stampo, e il
                # danno sarebbe silenzioso. Meglio fermarsi e dirlo.
                QMessageBox.warning(
                    self, "Modello non identificato",
                    f"Non riesco a riconoscere la feature modello in «{dest.name()}», "
                    "quindi non sostituisco niente: svuotare il layer lascerebbe la "
                    "prossima generazione senza una tavola da cui ricavare forma e "
                    "dimensione.\n\n"
                    "Togli la spunta «Sostituisci» per aggiungere le tavole senza "
                    "cancellare, oppure seleziona nel layer la feature da tenere "
                    "come modello e riprova."); return
            da_togliere = [f.id() for f in dest.getFeatures() if f.id() != id_modello]

        if sovrascrivi:
            testo = (f"Sostituisco il contenuto di «{dest.name()}»:\n\n"
                     f"  • {len(da_togliere)} tavole esistenti verranno ELIMINATE\n"
                     "  • 1 feature modello verrà conservata\n"
                     f"  • {len(feats)} tavole nuove verranno inserite\n\n"
                     "L'operazione non è annullabile una volta salvata. Procedo?")
        else:
            testo = (f"Copio {len(feats)} tavole da «{temp.name()}»\n"
                     f"nel layer «{dest.name()}» (che ora ne ha {n_dest}).\n\n"
                     "Le tavole vengono aggiunte a quelle esistenti.\n"
                     "Procedo?")
        if QMessageBox.question(self, "Copiare le tavole nel modello?", testo,
                                QMessageBox.Yes | QMessageBox.No,
                                QMessageBox.No) != QMessageBox.Yes:
            return

        # i campi si allineano per NOME, non per posizione: i due layer hanno
        # quasi sempre schemi simili ma non identici, e copiare per indice
        # sposterebbe i valori di colonna senza che nessuno se ne accorga.
        campi_d = dest.fields()
        nomi_d = [f.name() for f in campi_d]
        nuove = []
        for f in feats:
            nf = QgsFeature(campi_d)
            nf.setGeometry(f.geometry())
            for c in f.fields():
                nome = c.name()
                if nome in nomi_d and nome.lower() != "fid":
                    nf.setAttribute(nome, f[nome])
            nuove.append(nf)

        era_in_modifica = dest.isEditable()
        if not era_in_modifica and not dest.startEditing():
            QMessageBox.critical(self, "Layer non modificabile",
                                 f"Non riesco ad aprire «{dest.name()}» in modifica."); return
        if da_togliere and not dest.deleteFeatures(da_togliere):
            dest.rollBack()
            QMessageBox.critical(self, "Sostituzione non riuscita",
                                 "Non sono riuscito a eliminare le tavole esistenti;\n"
                                 "nulla è stato modificato."); return
        if not dest.addFeatures(nuove):
            dest.rollBack()
            QMessageBox.critical(self, "Copia non riuscita",
                                 "L'inserimento delle tavole è fallito; nulla è stato scritto."); return

        # la feature modello resta SENZA numero: numerata si confonderebbe con
        # le tavole vere e finirebbe stampata; vuota si riconosce a colpo
        # d'occhio e si cancella quando non serve più.
        modello_azzerato = False
        if sovrascrivi and id_modello is not None:
            try:
                w = (self.txt_num_keyplan_campo if chiave == "keyplan"
                     else self.txt_num_tavole_campo)
                campo_num = (w.text() or "").strip()
                i_num = dest.fields().indexOf(campo_num) if campo_num else -1
                if i_num >= 0:
                    modello_azzerato = dest.changeAttributeValue(id_modello, i_num, None)
            except Exception as e:
                _log_avviso("azzeramento del numero sulla feature modello non riuscito", e)

        if not era_in_modifica and not dest.commitChanges():
            err = "; ".join(dest.commitErrors()[:3])
            dest.rollBack()
            QMessageBox.critical(self, "Salvataggio non riuscito",
                                 f"Le tavole non sono state salvate.\n{err}"); return

        dest.updateExtents(); dest.triggerRepaint()
        QMessageBox.information(
            self, "Tavole copiate",
            (f"{len(da_togliere)} tavole eliminate e " if sovrascrivi else "")
            + f"{len(nuove)} tavole scritte in «{dest.name()}».\n"
            + ("Feature modello conservata e lasciata SENZA numero,\n"
               "così la riconosci e puoi cancellarla.\n" if modello_azzerato
               else ("Feature modello conservata.\n" if sovrascrivi and id_modello is not None else ""))
            + f"Ora il layer ne contiene {dest.featureCount()} (prima {n_dest}).")

    def _completa_copertura(self, tessere, dims, max_giri=40):
        """Aggiunge tavole finché ogni elemento della rete non è coperto.

        Le tavole aggiunte qui POSSONO sovrapporsi a quelle esistenti. È una
        scelta deliberata: su un keyplan la sovrapposizione è innocua, un
        pozzetto che non compare su nessuna tavola no. Il vincolo di non
        sovrapposizione serve a non sprecare tavole, non a lasciare scoperta
        la rete.

        Ritorna (tessere, n_aggiunte, n_ancora_scoperti).
        """
        if not dims:
            return tessere, 0, 0
        etichetta, larg, alt = dims[0]
        tessere = list(tessere)
        aggiunte = 0

        for _giro in range(max_giri):
            scoperti = self._elementi_scoperti(tessere)
            if not scoperti:
                return tessere, aggiunte, 0
            # si parte dall'elemento più lontano da qualsiasi tavola: una tavola
            # piazzata lì copre con ogni probabilità anche i suoi vicini, quindi
            # servono meno tavole-toppa di quante siano le lacune.
            g = max(scoperti, key=lambda x: x.boundingBox().width() * x.boundingBox().height())
            bb = g.boundingBox()
            cx = bb.center().x(); cy = bb.center().y()
            nuova = QgsGeometry.fromRect(QgsRectangle(
                cx - larg / 2.0, cy - alt / 2.0, cx + larg / 2.0, cy + alt / 2.0))
            tessere.append((nuova, etichetta))
            aggiunte += 1

        return tessere, aggiunte, len(self._elementi_scoperti(tessere))

    def _dissolvi_arlo(self):
        """Fonde (unaryUnion) TUTTE le feature del layer ARLO AREA in
        un'unica geometria, anche multi-parte se le aree non sono
        adiacenti. È la vera FORMA usata per decidere dove mettere le
        tavole — non il suo bounding box: un layer con più aree armadio
        sparse produce un bbox che include anche il vuoto tra una zona e
        l'altra, mentre la forma fusa segue il contorno reale."""
        lyr = self.cb_kp_arlo.currentLayer()
        if not lyr: return None
        geoms = []
        for f in lyr.getFeatures():
            g = self._to_proj(f.geometry(), lyr)
            if g and not g.isEmpty():
                geoms.append(g)
        if not geoms: return None
        fusa = QgsGeometry.unaryUnion(geoms)
        if not fusa or fusa.isEmpty(): return None
        return fusa

    @staticmethod
    def _parti_poligono(geom):
        """Lista di QgsGeometry poligonali, una per ciascuna parte di
        `geom` (gestisce sia Polygon sia MultiPolygon); parti vuote
        scartate. Serve per lavorare parte-per-parte quando la forma da
        coprire non è un unico blocco continuo."""
        if geom is None or geom.isEmpty():
            return []
        base = QgsWkbTypes.flatType(geom.wkbType())
        if base == QgsWkbTypes.MultiPolygon:
            return [QgsGeometry.fromPolygonXY(poly) for poly in geom.asMultiPolygon() if poly]
        if base == QgsWkbTypes.Polygon:
            return [geom]
        try:
            mp = geom.asMultiPolygon()
            return [QgsGeometry.fromPolygonXY(poly) for poly in mp if poly]
        except Exception:
            return [geom]

    def _copertura_adattiva(self, dims, regione, overlap, vieta_sovrapposizione=False, soglia_residua=None):
        """Copre `regione` (una forma qualsiasi, NON un rettangolo) con
        tavole di dimensione fissa — una o due varianti in `dims`, lista di
        (nome, tw, th) — posizionate LIBERAMENTE invece che su una griglia
        globale: come mettere delle toppe sui buchi di un tessuto, invece
        di stendere un lenzuolo rigido sopra tutto (e tagliarne via i
        pezzi che avanzano fuori).
        Ad ogni passo: individua il 'buco' scoperto più grande rimasto
        (componente connessa), prende un punto al suo interno
        (pointOnSurface, sempre dentro anche per forme concave) SOLO per
        decidere DOVE guardare, poi valuta ogni posizione candidata
        contro TUTTO lo scoperto rimasto (non solo quella componente
        connessa): elementi vicini ma non tecnicamente a contatto (es. due
        Tavole di inquadramento con un piccolo spazio tra loro, o due
        gruppi di Infrastrutture/Pozzetto Nuovi non proprio adiacenti)
        sono componenti connesse SEPARATE, e valutare solo la componente
        del punto scelto le ignorerebbe anche se cadono comodamente nella
        stessa tavola — risultato: un Keyplan che non contiene per intero
        le Tavole di inquadramento vicine che dovrebbe raccogliere. Le
        posizioni candidate sono la griglia 5×5 di sempre (il punto può
        cadere su vari bordi/angoli/centro della tavola) PIÙ una posizione
        centrata sul baricentro di tutto il contenuto scoperto che
        cadrebbe in una finestra grande quanto la tavola attorno al punto:
        così la tavola risulta centrata su quello che deve inquadrare,
        non ancorata per un angolo come capitava prima.

        Se `vieta_sovrapposizione` è False (tavole di inquadramento): sottrae
        la tavola scelta (leggermente rimpicciolita dell'overlap, per
        lasciare la sovrapposizione voluta con le tavole vicine) dal 'buco'
        rimasto, e ripete — le tavole POSSONO sovrapporsi del margine
        richiesto.

        Se `vieta_sovrapposizione` è True (Keyplan): ogni candidato viene
        scartato se si sovrappone (oltre una tolleranza numerica minima) a
        una tavola già posizionata, tenendo traccia dell'unione di tutte le
        tavole piazzate finora ('occupato'). `overlap` diventa in questo
        caso un gap di sicurezza (la tavola viene rimpicciolita di
        `overlap` PRIMA di essere piazzata, così non solo non si sovrappone
        ma resta pure staccata delle tavole vicine). Dove nessuna posizione
        libera da sovrapposizioni copre il punto scelto, quel punto viene
        scartato (piccolo buco lasciato scoperto) invece di forzare una
        sovrapposizione.

        Ritorna (tessere, area_residua) dove tessere è [(geom, 'A'|'B'), …]
        e area_residua è l'area (m²) troppo piccola/frastagliata (o troppo
        stretta per stare senza sovrapporsi, in modalità Keyplan) per
        giustificare un'altra tavola intera.

        `soglia_residua`, se indicata, sostituisce la soglia di default (2%
        dell'area della tavola più piccola): quella di default va bene per
        coprire un'area PIENA (ARLO AREA), dove un ritaglio residuo pari a
        una piccola frazione di una tavola è normale da ignorare. Per
        coprire invece un target SOTTILE (es. un corridoio stretto attorno
        a un tratto di infrastruttura), quella soglia sarebbe troppo alta
        rispetto all'area totale disponibile e farebbe fermare la copertura
        dopo una o due tavole: in quel caso va passata una soglia assoluta
        piccola (es. mezzo metro quadro)."""
        if regione is None or regione.isEmpty(): return [], 0.0
        scoperto = QgsGeometry(regione)
        tile_area_min = min(tw * th for _, tw, th in dims)
        tile_dim_min = min(min(tw, th) for _, tw, th in dims)
        if soglia_residua is None:
            soglia_residua = max(1.0, 0.02 * tile_area_min)
        eps_sovrapp = max(1e-4, 1e-6 * tile_area_min)  # tolleranza per rumore numerico, non vera sovrapposizione
        max_tavole = 3000
        # Sicurezza anti-loop quando lo spazio residuo è troppo frastagliato
        # per piazzare altre tavole senza sovrapposizioni (tipico di un
        # target STRETTO come un corridoio attorno all'infrastruttura, dove
        # capita spesso). Deve essere ALTO: ogni fallimento scarta solo un
        # piccolo intorno del punto corrente e passa oltre, quindi un
        # target con molte zone strette (curve, incroci) ha bisogno di
        # MOLTI fallimenti "locali" per essere ripulito del tutto — con un
        # tetto basso l'intero ciclo si fermava subito lasciando scoperte
        # anche zone facili mai nemmeno provate, oltre a quella difficile.
        max_fallimenti = 4000
        tessere = []
        occupato = None  # unione delle tavole già piazzate, usata solo in modalità vieta_sovrapposizione
        fallimenti = 0
        while scoperto.area() > soglia_residua and len(tessere) < max_tavole and fallimenti < max_fallimenti:
            parti = self._parti_poligono(scoperto)
            if not parti: break
            parte = max(parti, key=lambda g: g.area())
            if parte.area() <= soglia_residua: break
            p = parte.pointOnSurface()
            if not p or p.isEmpty(): break
            pt = p.asPoint()
            px, py = pt.x(), pt.y()

            migliore = None  # (score, rect, nome, tw, th)
            for nome, tw, th in dims:
                # Oltre alla griglia 5×5 (angoli/bordi/centro ancorati al
                # punto interno del buco), si prova UNA posizione in più:
                # la tavola centrata sul baricentro di TUTTO lo scoperto
                # (non solo 'parte') che cadrebbe in una finestra grande
                # quanto la tavola attorno al punto — così raccoglie anche
                # elementi vicini ma non a contatto diretto col punto
                # scelto, invece di ignorarli.
                candidati_xy = [(px - fx*tw, py - fy*th) for fx in (0.0, 0.25, 0.5, 0.75, 1.0) for fy in (0.0, 0.25, 0.5, 0.75, 1.0)]
                finestra = QgsGeometry.fromRect(QgsRectangle(px - tw/2.0, py - th/2.0, px + tw/2.0, py + th/2.0))
                contenuto_locale = finestra.intersection(scoperto)
                centrato_xy = None
                if contenuto_locale and not contenuto_locale.isEmpty():
                    centro_reale = contenuto_locale.centroid()
                    if not centro_reale or centro_reale.isEmpty():
                        centro_reale = contenuto_locale.pointOnSurface()
                    if centro_reale and not centro_reale.isEmpty():
                        cp = centro_reale.asPoint()
                        centrato_xy = (cp.x() - tw/2.0, cp.y() - th/2.0)
                        candidati_xy.append(centrato_xy)
                for x0, y0 in candidati_xy:
                    rect = QgsGeometry.fromRect(QgsRectangle(x0, y0, x0 + tw, y0 + th))
                    if vieta_sovrapposizione and occupato is not None:
                        sovr = rect.intersection(occupato)
                        if sovr and not sovr.isEmpty() and sovr.area() > eps_sovrapp:
                            continue  # scartata: si sovrapporrebbe a una tavola già piazzata
                    inter = rect.intersection(scoperto)
                    score = 0.0 if not inter or inter.isEmpty() else inter.area()
                    if score <= 0: continue
                    if migliore is None or score > migliore[0]:
                        migliore = (score, rect, nome, tw, th)
            if migliore is None:
                if vieta_sovrapposizione:
                    # Nessuna posizione libera da sovrapposizioni copre questo punto
                    # (spazio residuo troppo stretto): si scarta un intorno del
                    # punto e si passa al prossimo, invece di forzare una
                    # sovrapposizione o interrompere subito la copertura. Il
                    # raggio scartato è una FRAZIONE della tavola più piccola
                    # (non della soglia_residua, che per un target stretto è
                    # volutamente minuscola): un raggio troppo piccolo lascia
                    # praticamente invariata l'area del punto più problematico,
                    # che resta il 'buco' più grande e viene riprovato subito
                    # dopo — bruciando tutto il budget di fallimenti su UN
                    # solo punto ostico invece di liberare anche il resto del
                    # target, mai nemmeno tentato.
                    raggio = max(0.15, tile_dim_min / 8.0)
                    buco = QgsGeometry.fromPointXY(pt).buffer(raggio, 8)
                    nuovo_scoperto = scoperto.difference(buco) if buco and not buco.isEmpty() else None
                    fallimenti += 1
                    if nuovo_scoperto is None or nuovo_scoperto.isEmpty():
                        break
                    scoperto = nuovo_scoperto
                    continue
                break  # sicurezza: non dovrebbe succedere dato che (px,py) è dentro 'parte'
            _, rect, nome, tw, th = migliore

            if vieta_sovrapposizione:
                gap = min(overlap, min(tw, th) / 4.0) if overlap > 0 else 0.0
                tile_piazzata = rect.buffer(-gap, 5) if gap > 0 else rect
                if not tile_piazzata or tile_piazzata.isEmpty():
                    tile_piazzata = rect
                tessere.append((tile_piazzata, nome))
                occupato = tile_piazzata if occupato is None else occupato.combine(tile_piazzata)
                tile_sottrai = rect  # tolto per intero dallo scoperto: qui non deve più finire un'altra tavola
            else:
                tessere.append((rect, nome))
                shrink = min(overlap, min(tw, th) / 4.0) if overlap > 0 else 0.0
                tile_sottrai = rect.buffer(-shrink, 5) if shrink > 0 else rect
                if not tile_sottrai or tile_sottrai.isEmpty():
                    tile_sottrai = rect

            nuovo_scoperto = scoperto.difference(tile_sottrai)
            if nuovo_scoperto is None:
                break
            scoperto = nuovo_scoperto

        return tessere, (scoperto.area() if scoperto else 0.0)

    def _pota_tavole_ridondanti(self, tessere, soglia_area=None):
        """Rimuove le tavole quasi del tutto ridondanti (già coperte dalle
        vicine per almeno tutta tranne una briciola di area) per ridurre il
        numero di tavole utili finali, SENZA mai lasciare scoperto un punto
        che prima era coperto: una tavola viene tolta solo se il suo
        contributo 'privato' (l'area che copre lei sola, non coperta da
        nessun'altra tavola) è sotto `soglia_area`. Lavora con un indice
        spaziale per restare veloce anche con centinaia di tavole. Ritorna
        una nuova lista [(geom, sorgente), …]."""
        n = len(tessere)
        if n <= 1: return tessere
        if soglia_area is None:
            aree = [g.area() for g, _ in tessere]
            soglia_area = max(1.0, 0.02 * min(aree))

        idx = QgsSpatialIndex()
        feats = []
        for i, (g, _s) in enumerate(tessere):
            f = QgsFeature(i); f.setGeometry(g)
            feats.append(f); idx.addFeature(f)

        tenute = list(range(n))  # indici delle tavole ancora presenti
        tenute_set = set(tenute)
        cambiato = True
        while cambiato and len(tenute_set) > 1:
            cambiato = False
            # dalla più piccola: le tavole piccole sono le prime candidate a essere ridondanti
            for i in sorted(tenute_set, key=lambda i: tessere[i][0].area()):
                g_i = tessere[i][0]
                vicini_bbox = idx.intersects(g_i.boundingBox())
                altre = [tessere[j][0] for j in vicini_bbox if j != i and j in tenute_set]
                if not altre:
                    continue
                unione_altre = QgsGeometry.unaryUnion(altre)
                if unione_altre is None or unione_altre.isEmpty():
                    continue
                privato = g_i.difference(unione_altre)
                area_privata = 0.0 if (not privato or privato.isEmpty()) else privato.area()
                if area_privata <= soglia_area:
                    tenute_set.discard(i)
                    cambiato = True

        return [tessere[i] for i in sorted(tenute_set)]

    def _posiziona_keyplan(self):
        """Copre la forma di ARLO AREA (fusa in un'unica geometria, non il
        suo bounding box) con tavole Keyplan — modello A e, se impostato,
        modello alternativo B — posizionate liberamente per seguire il
        contorno reale invece di riempire un rettangolo. Nessun
        collegamento a layout di stampa: agisce solo sulla geometria del
        layer generato. Se è impostato un layer di Tavole di Inquadramento
        (campo sopra), la copertura ignora ARLO AREA e copre SOLO
        l'impronta di quelle tavole."""
        tavole_lyr = self.cb_kp_tavole.currentLayer()
        if tavole_lyr:
            geoms_ti = []
            for f in tavole_lyr.getFeatures():
                g = self._to_proj(f.geometry(), tavole_lyr)
                if g and not g.isEmpty(): geoms_ti.append(g)
            if not geoms_ti:
                QMessageBox.warning(self, "Tavole vuote", f"Il layer '{tavole_lyr.name()}' impostato come Tavole di Inquadramento non ha geometrie valide."); return
            forma = QgsGeometry.unaryUnion(geoms_ti)
            if not forma or forma.isEmpty():
                QMessageBox.warning(self, "Tavole vuote", "L'unione delle Tavole di Inquadramento è risultata vuota."); return
            nome_target = f"Tavole di Inquadramento ('{tavole_lyr.name()}')"
            # Gli oggetti da coprire sono le tavole stesse, così anche questo
            # ramo passa dal RETICOLO. Senza questa riga _forma_da_coprire() non
            # veniva mai chiamata, _elementi_rete restava vuoto e la generazione
            # ricadeva sulla copertura libera — cioè proprio il caso che produce
            # tavole sovrapposte, con un campo che per giunta il preset riempie
            # da solo.
            self._elementi_rete = geoms_ti
        else:
            forma, nome_target = self._forma_da_coprire()
            if not forma:
                QMessageBox.warning(self, "Area vuota", self._messaggio_estensione_vuota()); return
        kp_lyr = self.cb_kp_keyplan.currentLayer()
        if not kp_lyr:
            QMessageBox.warning(self, "Layer mancante", "Seleziona almeno il layer Keyplan modello A."); return

        tmpl_a = self._template_kp(kp_lyr)
        if not tmpl_a:
            QMessageBox.warning(
                self, "Layer vuoto",
                "Il layer Keyplan modello A non contiene nessuna geometria modello.\n"
                "Aggiungi almeno una tavola (es. da Keyplan_Quadrato.gpkg o\n"
                "Keyplan_Rettangolare.gpkg) da usare come riferimento di\n"
                "forma/dimensione prima di generare la copertura."
            ); return
        f_tmpl_a, g_tmpl_a = tmpl_a
        bb_a = g_tmpl_a.boundingBox()
        if bb_a.width() <= 0 or bb_a.height() <= 0:
            QMessageBox.warning(self, "Geometria modello non valida", "La geometria modello nel layer Keyplan ha estensione nulla."); return
        dims = [('A', bb_a.width(), bb_a.height())]

        kp_lyr2 = self.cb_kp_keyplan2.currentLayer()
        tmpl_b = self._template_kp(kp_lyr2) if kp_lyr2 else None
        f_tmpl_b, g_tmpl_b = tmpl_b if tmpl_b else (None, None)
        if tmpl_b:
            bb_b = g_tmpl_b.boundingBox()
            if bb_b.width() > 0 and bb_b.height() > 0:
                dims.append(('B', bb_b.width(), bb_b.height()))

        tessere, area_residua = self._copertura_adattiva(
            dims, forma, self.spin_kp_gap.value(), vieta_sovrapposizione=True
        )
        if not tessere:
            QMessageBox.warning(self, "Copertura non riuscita", f"Nessuna tavola generata: controlla i modelli Keyplan e {nome_target}."); return

        n_prima = len(tessere)
        tessere = self._pota_tavole_ridondanti(tessere)
        n_potate = n_prima - len(tessere)

        # Quando l'area viene dalla RETE NUOVA si usa il reticolo: celle
        # adiacenti allineate al modello, tenute solo dove c'è rete. Risolve per
        # costruzione sovrapposizioni e lacune, e rende inutile il secondo
        # passaggio «rigenera solo sulla rete».
        elementi = getattr(self, "_elementi_rete", None)
        if elementi:
            tessere = self._copertura_a_reticolo(dims, elementi)
            n_potate = 0
        n_toppe = 0
        n_sov, n_scoperti = self._verifica_tessere(tessere, elementi)

        lyr, n_a, n_b = self._scrivi_tessere(
            tessere, kp_lyr.fields(), f_tmpl_a, f_tmpl_b, "Keyplan", "keyplan", kp_lyr.wkbType(),
        )
        msg = (f"Copertura Keyplan generata: {len(tessere)} tavole (A: {n_a}"
               + (f", B: {n_b}" if tmpl_b else "") + f") nel layer '{lyr.name()}'.\n"
               + (f"Tavole disposte a RETICOLO allineato al modello, solo dove serve ({nome_target}):\n"
                  "adiacenti, mai sovrapposte, nessun elemento fuori.\n" if elementi else
                  f"Tavole posizionate liberamente seguendo la forma di {nome_target} (non una griglia rettangolare),\n"
                  "senza nessuna sovrapposizione tra loro.\n")
               + (f"{n_potate} tavole ridondanti rimosse per ridurre il numero di tavole utili.\n" if n_potate else "")
               + (f"{n_toppe} tavole aggiunte per coprire elementi rimasti fuori (pozzetti/tratte nei ritagli stretti).\n" if n_toppe else "")
               + ("Tavole sovrapposte: NESSUNA.\n" if not n_sov
                  else f"ATTENZIONE: {n_sov} coppie di tavole si sovrappongono.\n")
               + ("Elementi della rete fuori copertura: NESSUNO.\n" if not n_scoperti
                  else f"ATTENZIONE: {n_scoperti} elementi restano fuori da ogni tavola.\n")
               + self._numera_appena_generate(lyr, self.txt_num_keyplan_campo)
               + ("" if elementi else
                  (f"Area residua non coperta (troppo piccola/stretta per un'altra tavola senza sovrapporsi): ≈{area_residua:.0f} m²."
                   if area_residua > 1.0 else "Copertura completa.")))
        self.log_kp.setPlainText(msg); QMessageBox.information(self, "OK", msg)

    def _scrivi_tessere(self, tessere, campi_modello, f_tmpl_a, f_tmpl_b, nome_layer, chiave, wkb_type):
        """Crea/rinfresca il layer memory `nome_layer` (chiave `chiave` in
        self._output_layers) e vi scrive le `tessere` [(geom, 'A'|'B'), …],
        copiando gli attributi dal rispettivo modello (A o B). Ritorna
        (layer, n_a, n_b).

        Se lo schema del modello contiene un campo chiamato 'fid' (capita
        spesso: è la colonna chiave primaria che GeoPackage espone anche
        come attributo quando lo si legge come layer), viene escluso dallo
        schema copiato: altrimenti TUTTE le tavole generate erediterebbero
        lo STESSO valore costante di quel campo dall'unica feature modello,
        e salvando su GeoPackage GDAL lo riconosce come chiave primaria —
        con lo stesso valore duplicato su ogni tavola, solo la prima si
        scrive e tutte le altre falliscono con 'UNIQUE constraint failed'."""
        indici_validi = [i for i, f in enumerate(campi_modello) if f.name().strip().lower() != "fid"]
        campi_filtrati = [campi_modello[i] for i in indici_validi]

        lyr = self._crea_layer_output(nome_layer, QgsWkbTypes.displayString(wkb_type), campi_filtrati, chiave)
        attrs_a_full = list(f_tmpl_a.attributes())
        attrs_b_full = list(f_tmpl_b.attributes()) if f_tmpl_b else attrs_a_full
        attrs_a = [attrs_a_full[i] for i in indici_validi]
        attrs_b = [attrs_b_full[i] for i in indici_validi]
        feats = []; n_a = n_b = 0
        for g, sorgente in tessere:
            gg = QgsGeometry(g)
            if lyr.crs() != self.project.crs():
                gg.transform(QgsCoordinateTransform(self.project.crs(), lyr.crs(), self.project))
            nf = QgsFeature(lyr.fields())
            nf.setAttributes(list(attrs_a if sorgente == 'A' else attrs_b))
            nf.setGeometry(gg)
            feats.append(nf)
            if sorgente == 'A': n_a += 1
            else: n_b += 1
        lyr.dataProvider().addFeatures(feats)
        lyr.updateExtents(); lyr.triggerRepaint()
        return lyr, n_a, n_b

    def _genera_griglia(self):
        """Genera i riquadri (tavole di inquadramento) che coprono la forma
        di ARLO AREA (fusa in un'unica geometria), posizionati liberamente
        per seguire il contorno reale, in un layer memory dedicato
        ('Poligoni Inquadramento', ricreato ad ogni generazione). Forma e
        dimensione non sono impostabili a mano: derivano dai modelli propri
        impostati sopra (Inquadramento A/B) — se non impostati, per comodità
        vengono riusati i modelli del Keyplan. Nessun collegamento a layout
        di stampa, nessuna scrittura su file."""
        forma, _nome_target = self._forma_da_coprire()
        if not forma:
            QMessageBox.warning(self, "Area vuota", self._messaggio_estensione_vuota()); return

        lyr_a = self.cb_ti_tmpl_a.currentLayer() or self.cb_kp_keyplan.currentLayer()
        tmpl_a = self._template_kp(lyr_a)
        if not tmpl_a:
            QMessageBox.warning(
                self, "Layer modello mancante",
                "Imposta il layer Inquadramento modello A (o, in alternativa,\n"
                "il Keyplan modello A) con almeno una tavola: forma e\n"
                "dimensione dei riquadri derivano sempre da lì."
            ); return
        f_tmpl_a, g_tmpl_a = tmpl_a
        bb_a = g_tmpl_a.boundingBox()
        if bb_a.width() <= 0 or bb_a.height() <= 0:
            QMessageBox.warning(self, "Geometria modello non valida", "La geometria modello Inquadramento ha estensione nulla."); return
        dims = [('A', bb_a.width(), bb_a.height())]

        lyr_b = self.cb_ti_tmpl_b.currentLayer() or (self.cb_kp_keyplan2.currentLayer() if not self.cb_ti_tmpl_a.currentLayer() else None)
        tmpl_b = self._template_kp(lyr_b) if lyr_b else None
        f_tmpl_b, g_tmpl_b = tmpl_b if tmpl_b else (None, None)
        if tmpl_b:
            bb_b = g_tmpl_b.boundingBox()
            if bb_b.width() > 0 and bb_b.height() > 0:
                dims.append(('B', bb_b.width(), bb_b.height()))

        gap = self.spin_ti_gap.value()
        tessere, area_residua = self._copertura_adattiva(dims, forma, gap, vieta_sovrapposizione=True)
        if not tessere:
            QMessageBox.warning(self, "Copertura non riuscita", "Nessuna tavola generata: controlla i modelli Inquadramento e l'area ARLO AREA."); return

        n_prima = len(tessere)
        tessere = self._pota_tavole_ridondanti(tessere)
        n_potate = n_prima - len(tessere)

        # come per il Keyplan: con l'area costruita dalla rete nuova si passa al
        # reticolo, che non lascia sovrapposizioni né elementi scoperti.
        elementi = getattr(self, "_elementi_rete", None)
        if elementi:
            tessere = self._copertura_a_reticolo(dims, elementi)
            n_potate = 0
        n_sov, n_scoperti = self._verifica_tessere(tessere, elementi)

        lyr, n_a, n_b = self._scrivi_tessere(
            tessere, lyr_a.fields(), f_tmpl_a, f_tmpl_b,
            "Poligoni Inquadramento", "inquadramento", lyr_a.wkbType(),
        )
        msg = [
            f"Copertura generata: {len(tessere)} tavole (A: {n_a}" + (f", B: {n_b}" if tmpl_b else "") + f") nel layer '{lyr.name()}'.",
            ("Tavole disposte a RETICOLO allineato al modello, solo dove c'è rete nuova: adiacenti, mai sovrapposte, nessun elemento fuori."
             if elementi else
             "Tavole posizionate liberamente seguendo la forma di ARLO AREA (non una griglia rettangolare), senza nessuna sovrapposizione tra loro."),
        ]
        if n_potate:
            msg.append(f"{n_potate} tavole ridondanti rimosse per ridurre il numero di tavole utili.")
        msg.append("Tavole sovrapposte: NESSUNA." if not n_sov
                   else f"ATTENZIONE: {n_sov} coppie di tavole si sovrappongono.")
        msg.append("Elementi della rete fuori copertura: NESSUNO." if not n_scoperti
                   else f"ATTENZIONE: {n_scoperti} elementi restano fuori da ogni tavola.")
        riga_num = self._numera_appena_generate(lyr, self.txt_num_tavole_campo)
        if riga_num:
            msg.append(riga_num.rstrip("\n"))
        if not elementi:
            msg.append(f"Area residua non coperta (troppo piccola/stretta per un'altra tavola senza sovrapporsi): ≈{area_residua:.0f} m²." if area_residua > 1.0 else "Copertura completa.")
        self.log_kp.setPlainText("\n".join(msg))
        QMessageBox.information(self, "OK", "\n".join(msg))

    def _numera_per_posizione(self, lyr, campo):
        """Numera le feature poligonali di `lyr` in ordine di lettura:
        raggruppa per 'righe' (i centroidi la cui Y sta entro metà
        dell'altezza media di una tavola dalla Y del primo elemento di
        quella riga finiscono nella stessa riga), poi ordina ogni riga da
        ovest a est. Il campo (intero) viene creato se manca. Ritorna
        (n_numerati, n_letti_dal_layer): se n_letti è molto più basso del
        numero di tavole/keyplan che ti aspetti, il layer impostato nel
        campo qui sopra probabilmente non è quello giusto (es. un filtro
        attivo sul layer, o il layer modello invece di quello generato)."""
        n_letti = lyr.featureCount()
        elementi = []
        for f in lyr.getFeatures():
            g = self._to_proj(f.geometry(), lyr)
            if not g or g.isEmpty(): continue
            elementi.append((f, g.centroid().asPoint(), g.boundingBox()))
        if not elementi: return 0, n_letti

        h_media = sum(bb.height() for _, _, bb in elementi) / len(elementi)
        soglia_riga = max(h_media * 0.5, 0.01)

        elementi.sort(key=lambda t: -t[1].y())  # nord -> sud
        righe = []; riga_corrente = []; y_riga = None
        for item in elementi:
            y = item[1].y()
            if y_riga is None or (y_riga - y) <= soglia_riga:
                riga_corrente.append(item)
                if y_riga is None: y_riga = y
            else:
                righe.append(riga_corrente)
                riga_corrente = [item]; y_riga = y
        if riga_corrente: righe.append(riga_corrente)
        for riga in righe:
            riga.sort(key=lambda t: t[1].x())  # ovest -> est

        era = lyr.isEditable()
        if not self._start_edit(lyr): return 0, n_letti
        idx_campo = lyr.fields().indexOf(campo)
        if idx_campo < 0:
            lyr.addAttribute(QgsField(campo, QVariant.Int))
            lyr.updateFields()
            idx_campo = lyr.fields().indexOf(campo)
        n = 0; numero = 1
        for riga in righe:
            for f, _c, _bb in riga:
                lyr.changeAttributeValue(f.id(), idx_campo, numero)
                numero += 1; n += 1
        if not era and not self._commit(lyr, f"Errore numerazione '{lyr.name()}'"):
            return 0, n_letti
        lyr.triggerRepaint()
        return n, n_letti

    def _numera_keyplan_e_tavole(self):
        lavori = []
        kp = self.cb_num_keyplan.currentLayer()
        if kp:
            campo = self.txt_num_keyplan_campo.text().strip()
            lavori.append((kp, campo, "Keyplan"))
        tv = self.cb_num_tavole.currentLayer()
        if tv:
            campo = self.txt_num_tavole_campo.text().strip()
            lavori.append((tv, campo, "Tavole di Inquadramento"))
        if not lavori:
            QMessageBox.warning(self, "Nessun layer", "Imposta almeno un layer (Keyplan e/o Tavole di Inquadramento) da numerare."); return

        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            righe = []
            for lyr, campo, nome in lavori:
                if not campo:
                    righe.append(f"{nome}: campo numerazione non indicato, saltato."); continue
                n, n_letti = self._numera_per_posizione(lyr, campo)
                riga = f"{nome} ('{lyr.name()}'): {n} elementi numerati su {n_letti} letti dal layer (campo '{campo}', ordine alto-sinistra → basso-destra)."
                if n_letti <= 1:
                    riga += " Solo 1 elemento nel layer: verifica che sia quello giusto (non un filtro attivo o il layer modello)."
                righe.append(riga)
        finally:
            QApplication.restoreOverrideCursor()

        testo = "\n".join(righe)
        self.log_kp.setPlainText(testo)
        QMessageBox.information(self, "Numerazione completata", testo)

    def _salva_uno(self, chiave, nome_umano, nome_stile):
        """Scrive SOLO il layer `nome_umano` (Keyplan oppure Poligoni
        Inquadramento, mai insieme) su un GeoPackage a scelta dell'utente,
        poi carica al posto della copia in RAM il layer appena scritto su
        disco con lo stile allegato al plugin già applicato. L'errore
        'UNIQUE constraint failed' capitava quando si salvava di nuovo
        sullo STESSO file: il layer caricato dal salvataggio precedente
        restava aperto nel progetto e teneva il GeoPackage 'occupato', così
        GDAL non riusciva a sovrascriverlo davvero e finiva per provare ad
        AGGIUNGERE le nuove tavole a quelle vecchie rimaste dentro, con lo
        stesso numero (fid) già usato. Ora, prima di scrivere: 1) se il
        file scelto è ESATTAMENTE quello dove il layer è già salvato, si
        blocca con un avviso invece di riscrivere su se stesso; 2) qualsiasi
        altro layer nel progetto che punta già a quel file viene rimosso
        (chiudendo la connessione) e il file preesistente viene cancellato,
        così la scrittura riparte sempre da zero."""
        lyr = self._output_layers.get(chiave)
        if lyr is None or lyr.id() not in self.project.mapLayers() or lyr.featureCount() == 0:
            QMessageBox.warning(
                self, "Niente da salvare",
                f"Genera prima la copertura {nome_umano} (deve contenere almeno una tavola)."
            ); return

        suggerito = nome_umano.replace(" ", "_") + ".gpkg"
        percorso, _ = QFileDialog.getSaveFileName(self, f"Salva {nome_umano} come GeoPackage", suggerito, "GeoPackage (*.gpkg)")
        if not percorso:
            return
        if not percorso.lower().endswith(".gpkg"):
            percorso += ".gpkg"
        percorso_norm = os.path.normcase(os.path.abspath(percorso))

        sorgente = lyr.source().split("|")[0]
        if lyr.providerType() != "memory" and sorgente and os.path.normcase(os.path.abspath(sorgente)) == percorso_norm:
            QMessageBox.warning(
                self, "Stesso file",
                f"'{nome_umano}' è già salvato in questo identico file.\n"
                "Rigenera la copertura (o scegline un altro) prima di salvarla di nuovo qui."
            ); return

        # Libera il file da eventuali lock: rimuove dal progetto ogni layer
        # (di qualunque chiave) che punta già a questo percorso, poi lo
        # cancella se esiste ancora, prima di scrivere.
        for lid, l in list(self.project.mapLayers().items()):
            try:
                src = l.source().split("|")[0]
                if src and os.path.normcase(os.path.abspath(src)) == percorso_norm:
                    self.project.removeMapLayer(lid)
            except Exception as e:
                _log_avviso("rimozione del layer che punta al file da riscrivere non riuscita", e)
        if os.path.exists(percorso):
            try:
                os.remove(percorso)
            except OSError:
                pass  # se non si riesce a cancellarlo subito, ci prova comunque CreateOrOverwriteFile

        opzioni = QgsVectorFileWriter.SaveVectorOptions()
        opzioni.driverName = "GPKG"
        opzioni.layerName = nome_umano
        opzioni.fileEncoding = "UTF-8"
        opzioni.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        errore = QgsVectorFileWriter.writeAsVectorFormatV3(lyr, percorso, self.project.transformContext(), opzioni)
        codice_errore = errore[0] if isinstance(errore, tuple) else errore
        if codice_errore != QgsVectorFileWriter.NoError:
            dettaglio = errore[1] if isinstance(errore, tuple) and len(errore) > 1 else str(errore)
            QMessageBox.critical(self, "Errore nel salvataggio", f"Impossibile salvare '{nome_umano}':\n{dettaglio}"); return

        lyr_disco = QgsVectorLayer(f"{percorso}|layername={nome_umano}", nome_umano, "ogr")
        if not lyr_disco.isValid():
            QMessageBox.warning(
                self, "Salvato ma non ricaricato",
                f"'{nome_umano}' è stato scritto in {percorso} ma non è stato possibile ricaricarlo nel progetto."
            ); return

        stile_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "styles", nome_stile)
        stile_ok = False
        if os.path.isfile(stile_path):
            ris = lyr_disco.loadNamedStyle(stile_path)
            stile_ok = bool(ris[1]) if isinstance(ris, tuple) else bool(ris)
            if stile_ok:
                self._rendi_stile_portatile(lyr_disco, stile_path)
                lyr_disco.saveStyleToDatabase(nome_umano, f"Stile {nome_umano}", True, "")

        if lyr.id() in self.project.mapLayers():
            self.project.removeMapLayer(lyr.id())
        self.project.addMapLayer(lyr_disco)
        self._output_layers[chiave] = lyr_disco
        lyr_disco.triggerRepaint()

        msg = (f"'{nome_umano}' salvato in:\n{percorso}\n({lyr_disco.featureCount()} tavole)"
               + (" con stile applicato." if stile_ok else " — stile NON applicato (file .qml mancante nel plugin)."))
        self.log_kp.setPlainText(msg)
        QMessageBox.information(self, "Salvataggio completato", msg)
