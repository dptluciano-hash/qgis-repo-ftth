# -*- coding: utf-8 -*-
"""
ftth_rfi_ui.py — Scheda "Istanze RFI" del plugin FTTH Permessi Manager.

Mixin (RFIMixin) agganciato a FTTHPermessiDialog. Tiene qui tutta la UI e la
logica QGIS del filone RFI, per non gonfiare ftth_permessi_dialog.py.

Flusso scheda:
  1) scelta tipologia (A/B/C/D) + dati comune/linea/DOIT/procuratore
  2) "Scarica ferrovia + cippi (OSM)"  -> crea layer linea e cippi km, e il
     layer 'Fascia di rispetto RFI' (buffer parametrico, default 30 m)
  3) "Leggi tratte dal progetto" -> filtra 03 INFRASTRUTTURE/02_POZZETTO dentro
     la fascia, stima km_da/km_a dai cippi, calcola cronoprogramma
  4) "Genera istanze" -> compila i 4 template .docx via ftth_rfi + Excel dati

La logica pura (compilazione docx, cronoprogramma, stima km) sta in ftth_rfi.py
ed e' gia' testata headless. Qui c'e' solo il collante QGIS. (c) Beexact S.r.l.
"""
import os
import json
import urllib.request
import urllib.parse

from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QFormLayout, QLineEdit, QComboBox,
    QPushButton, QMessageBox, QPlainTextEdit, QLabel, QCheckBox,
)
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
    QgsVectorLayer, QgsFeature, QgsField, QgsProject, QgsPointXY,
    QgsFields,
    QgsFillSymbol, QgsLineSymbol, QgsMarkerSymbol, QgsSingleSymbolRenderer,
    QgsSimpleLineSymbolLayer, QgsMarkerLineSymbolLayer,
    QgsPalLayerSettings, QgsVectorLayerSimpleLabeling, QgsTextFormat,
    QgsTextBufferSettings, QgsUnitTypes,
)
from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QColor, QFont

OVERPASS_MIRRORS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]

TIPOLOGIE = {
    "D": "Tipo D — Parallelismo (nuova infrastruttura interrata, fascia 6-30m)",
    "C": "Tipo C — Attraversamento ferrovia",
    "B": "Tipo B — (da definire)",
    "A": "Tipo A — (da definire)",
}


class RFIMixin:
    """Metodi della scheda Istanze RFI. Mescolato in FTTHPermessiDialog."""

    # ------------------------------------------------------------------ UI
    def _tab_rfi(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Genera le istanze di autorizzazione RFI (permessi ferroviari) a "
            "partire dai layer di progetto. Scarica la linea ferroviaria e i "
            "cippi chilometrici da OpenStreetMap, crea la fascia di rispetto, "
            "individua le tratte di scavo interferenti, stima le progressive "
            "chilometriche e compila i modelli Word (istanza art.49, relazione "
            "tecnica, bollo, modello B) con le tabelle scavi/pozzetti/"
            "cronoprogramma. I km stimati dai cippi OSM vanno sempre verificati: "
            "dove i dati non bastano il campo riporta 'km da verificare'."
        ))

        # 1) tipologia + dati generali
        gb1 = self._gruppo("1) Tipologia di interferenza e dati generali")
        f1 = QFormLayout(gb1)
        self.cb_rfi_tipologia = QComboBox()
        for k in ("D", "C", "B", "A"):
            self.cb_rfi_tipologia.addItem(TIPOLOGIE[k], k)
        f1.addRow("Tipologia:", self.cb_rfi_tipologia)
        self.txt_rfi_comune = QLineEdit(); self.txt_rfi_comune.setPlaceholderText("es. CHIAVENNA")
        f1.addRow("Comune:", self.txt_rfi_comune)
        self.txt_rfi_prov = QLineEdit(); self.txt_rfi_prov.setPlaceholderText("sigla, es. SO")
        f1.addRow("Provincia (sigla):", self.txt_rfi_prov)
        self.txt_rfi_cap = QLineEdit()
        f1.addRow("CAP:", self.txt_rfi_cap)
        self.txt_rfi_indirizzo = QLineEdit(); self.txt_rfi_indirizzo.setPlaceholderText("indirizzo del Comune")
        f1.addRow("Indirizzo Comune:", self.txt_rfi_indirizzo)
        self.txt_rfi_comune_pec = QLineEdit()
        f1.addRow("PEC Comune:", self.txt_rfi_comune_pec)
        self.txt_rfi_linea = QLineEdit(); self.txt_rfi_linea.setPlaceholderText("es. COLICO-CHIAVENNA")
        f1.addRow("Linea ferroviaria:", self.txt_rfi_linea)
        self.txt_rfi_doit_citta = QLineEdit(); self.txt_rfi_doit_citta.setPlaceholderText("es. MILANO")
        f1.addRow("RFI DOIT (città):", self.txt_rfi_doit_citta)
        self.txt_rfi_doit_ind = QLineEdit()
        f1.addRow("DOIT indirizzo:", self.txt_rfi_doit_ind)
        self.txt_rfi_doit_pec = QLineEdit()
        f1.addRow("DOIT PEC:", self.txt_rfi_doit_pec)
        # pulsante precompilazione automatica dallo screening territorio
        riga_pre = QHBoxLayout()
        self.btn_rfi_precompila = QPushButton("Precompila dallo screening territorio")
        self.btn_rfi_precompila.setToolTip(
            "Esegue lo screening del comune (o riusa l'ultimo) e riempie comune, "
            "provincia, CAP, regione, linea ferroviaria e DOIT RFI competente con la PEC.")
        self.btn_rfi_precompila.clicked.connect(self._rfi_precompila_da_screening)
        riga_pre.addWidget(self.btn_rfi_precompila)
        f1.addRow(riga_pre)
        v.addWidget(gb1)

        # 2) ferrovia + fascia
        gb2 = self._gruppo("2) Ferrovia e fascia di rispetto")
        v2 = QVBoxLayout(gb2)
        f2 = QFormLayout()
        self.spin_rfi_fascia = self._dspin(1, 200, 30, 0, " m")
        self.spin_rfi_fascia.setToolTip("Larghezza fascia di rispetto attorno alla linea (tipo D: 6-30 m).")
        f2.addRow("Fascia di rispetto:", self.spin_rfi_fascia)
        v2.addLayout(f2)
        riga2 = QHBoxLayout()
        self.btn_rfi_osm = QPushButton("Scarica ferrovia + cippi (OSM)")
        self.btn_rfi_osm.clicked.connect(self._rfi_scarica_osm)
        riga2.addWidget(self.btn_rfi_osm)
        v2.addLayout(riga2)
        v.addWidget(gb2)

        # 3) tratte
        gb3 = self._gruppo("3) Tratte di scavo interferenti")
        v3 = QVBoxLayout(gb3)
        self.btn_rfi_tratte = QPushButton("Leggi tratte dal progetto (dentro la fascia)")
        self.btn_rfi_tratte.clicked.connect(self._rfi_leggi_tratte)
        v3.addWidget(self.btn_rfi_tratte)
        v.addWidget(gb3)

        # 4) procuratore
        gb4 = self._gruppo("4) Firmatario / procuratore (variabile)")
        f4 = QFormLayout(gb4)
        self.txt_rfi_proc_cognome = QLineEdit()
        f4.addRow("Cognome:", self.txt_rfi_proc_cognome)
        self.txt_rfi_proc_nome = QLineEdit()
        f4.addRow("Nome:", self.txt_rfi_proc_nome)
        self.txt_rfi_proc_cf = QLineEdit()
        f4.addRow("Codice Fiscale:", self.txt_rfi_proc_cf)
        self.txt_rfi_proc_nato = QLineEdit(); self.txt_rfi_proc_nato.setPlaceholderText("luogo")
        f4.addRow("Nato a:", self.txt_rfi_proc_nato)
        self.txt_rfi_proc_natoprov = QLineEdit(); self.txt_rfi_proc_natoprov.setPlaceholderText("prov")
        f4.addRow("Prov. nascita:", self.txt_rfi_proc_natoprov)
        self.txt_rfi_proc_natoil = QLineEdit(); self.txt_rfi_proc_natoil.setPlaceholderText("gg/mm/aaaa")
        f4.addRow("Nato il:", self.txt_rfi_proc_natoil)
        self.txt_rfi_proc_res = QLineEdit()
        f4.addRow("Residente a:", self.txt_rfi_proc_res)
        self.txt_rfi_proc_via = QLineEdit()
        f4.addRow("In via:", self.txt_rfi_proc_via)
        self.txt_rfi_proc_doc = QLineEdit()
        f4.addRow("Documento n°:", self.txt_rfi_proc_doc)
        v.addWidget(gb4)

        # 5) genera
        gb5 = self._gruppo("5) Genera")
        v5 = QVBoxLayout(gb5)
        riga5 = QHBoxLayout()
        self.btn_rfi_genera = QPushButton("Genera istanze RFI (Word + Excel)")
        self.btn_rfi_genera.clicked.connect(self._rfi_genera)
        riga5.addWidget(self.btn_rfi_genera)
        self.btn_rfi_tavole = QPushButton("Genera tavole (Corografia + PL)")
        self.btn_rfi_tavole.clicked.connect(self._rfi_genera_tavole)
        riga5.addWidget(self.btn_rfi_tavole)
        v5.addLayout(riga5)
        v.addWidget(gb5)

        # log
        self.log_rfi = QPlainTextEdit(); self.log_rfi.setReadOnly(True)
        self.log_rfi.setMinimumHeight(120)
        v.addWidget(self.log_rfi)

        v.addStretch()
        return w

    def _log_rfi(self, msg):
        self.log_rfi.appendPlainText(str(msg))
        self.log_rfi.repaint()

    # ---------------------------------------------- precompila da screening
    def _rfi_precompila_da_screening(self):
        """Esegue lo screening del comune e riempie i campi testata dai dati
        trovati: comune/provincia/CAP/regione, linea ferroviaria, DOIT RFI+PEC.
        Non tocca i campi gia' compilati a mano se lo screening non ha il dato."""
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
        except ImportError as e:
            QMessageBox.critical(self, "Screening non disponibile",
                                 "Modulo ftth_screening non importabile:\n%s" % e)
            return
        # comune: dal campo RFI, oppure da quello dello screening se gia' usato
        comune = self.txt_rfi_comune.text().strip()
        if not comune and hasattr(self, "txt_scr_comune"):
            comune = self.txt_scr_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante",
                                "Scrivi il comune (o compilalo nella scheda "
                                "'Screening territorio') e riprova.")
            return
        provincia = self.txt_rfi_prov.text().strip() or None

        self.log_rfi.clear()
        self._log_rfi("Screening RFI di %s (comune + ferrovie + DOIT, veloce)..." % comune)
        self.btn_rfi_precompila.setEnabled(False)
        try:
            from qgis.PyQt.QtWidgets import QApplication
            QApplication.processEvents()
            # screening RISTRETTO alla RFI (comune + ferrovie + DOIT), non completo
            rep = scr.esegui_rfi(comune, provincia,
                                 avanzamento=lambda m: self._log_rfi("  " + str(m)))
        except Exception as e:
            QMessageBox.critical(self, "Screening fallito", str(e))
            self.btn_rfi_precompila.setEnabled(True)
            return
        finally:
            self.btn_rfi_precompila.setEnabled(True)

        if rep.get("errore"):
            QMessageBox.warning(self, "Comune non risolto",
                                "Screening non riuscito: %s" % rep["errore"])
            return

        c = rep.get("comune") or {}
        def _set_se_vuoto(widget, valore):
            if valore and not widget.text().strip():
                widget.setText(str(valore))
        # comune / provincia / CAP: lo screening da' nome, provincia (nome esteso), cap
        if c.get("nome") and not self.txt_rfi_comune.text().strip():
            self.txt_rfi_comune.setText(c["nome"].upper())
        _set_se_vuoto(self.txt_rfi_cap, c.get("cap"))
        # provincia: lo screening da' il nome esteso; la sigla la lascio all'utente
        # ma se il campo e' vuoto ci metto il nome esteso come promemoria
        _set_se_vuoto(self.txt_rfi_prov, c.get("provincia"))

        # linea ferroviaria: prima delle ferrovie trovate, MA se OSM ha dato solo
        # l'operatore (es. "Rete Ferroviaria Italiana") non e' un nome-linea:
        # lascio il campo vuoto con un avviso, cosi' non sembra un dato valido.
        ferrovie = rep.get("ferrovie") or []
        _OPERATORI = ("rete ferroviaria italiana", "rfi", "trenitalia",
                      "ferrovie dello stato", "linea ferroviaria")
        linee_vere = [f for f in ferrovie if f.strip().lower() not in _OPERATORI]
        if linee_vere:
            _set_se_vuoto(self.txt_rfi_linea, linee_vere[0].upper())
            if len(linee_vere) > 1:
                self._log_rfi("Ferrovie trovate: %s (uso la prima; correggi se serve)"
                              % ", ".join(linee_vere))
        elif ferrovie:
            self._log_rfi("OSM ha rilevato una ferrovia ma senza nome-linea "
                          "(solo operatore: %s). Inserisci il nome-linea a mano "
                          "(es. COLICO-CHIAVENNA)." % ", ".join(ferrovie))

        # DOIT RFI competente per regione (gia' calcolata da esegui_rfi in rep['rfi'])
        regione = c.get("regione")
        rfi_c = rep.get("rfi")
        if rfi_c is None:
            try:
                rfi_c = scr.rfi_struttura(regione)
            except Exception:
                rfi_c = None
        if rfi_c:
            _set_se_vuoto(self.txt_rfi_doit_citta, (rfi_c.get("citta") or "").upper())
            contatti = rfi_c.get("contatti") or []
            if contatti:
                # se piu' DOIT, prendo la prima ma le elenco nel log
                c0 = contatti[0]
                _set_se_vuoto(self.txt_rfi_doit_pec, c0.get("pec"))
                doits = ", ".join("%s (%s)" % (x.get("doit","?"), x.get("pec","")) for x in contatti)
                self._log_rfi("DOIT RFI per %s: %s" % (regione, doits))
                if len(contatti) > 1:
                    self._log_rfi("Piu' DOIT possibili: verifica quella competente "
                                  "per la linea e correggi PEC/città se serve.")
        else:
            self._log_rfi("Nessuna struttura RFI mappata per la regione '%s': "
                          "compila DOIT a mano." % (regione or "?"))

        # PEC del Comune: lo screening non la fornisce in modo affidabile
        # (l'ente 'Comune' usa una scheda generica senza PEC specifica) -> manuale.
        # Se un domani rep porta la PEC comunale, la si aggancia qui.

        self._log_rfi("Precompilazione completata. Controlla i campi e completa "
                      "quelli mancanti (indirizzo Comune, indirizzo DOIT, procuratore).")
        QMessageBox.information(
            self, "Precompilato",
            "Ho riempito i campi disponibili dallo screening.\n\n"
            "Verifica sempre la DOIT competente per la linea e completa i campi "
            "mancanti (indirizzi, procuratore).")

    # -------------------------------------------------- stato interno RFI
    def _rfi_state(self):
        if not hasattr(self, "_rfi_dati_cache"):
            self._rfi_dati_cache = {"cippi": [], "linea_wgs": None, "tratte": None}
        return self._rfi_dati_cache

    # ------------------------------------------------------- OSM download
    def _overpass(self, query):
        import time
        data = urllib.parse.urlencode({"data": query}).encode()
        last = None
        for m in OVERPASS_MIRRORS:
            for _ in range(2):
                try:
                    req = urllib.request.Request(
                        m, data=data, headers={"User-Agent": "ftth-permessi/1.0"})
                    with urllib.request.urlopen(req, timeout=90) as r:
                        return json.load(r)
                except Exception as e:
                    last = e
                    time.sleep(2)
        raise last

    def _rfi_bbox_progetto(self):
        """bbox (latmin,lonmin,latmax,lonmax) in WGS84 dal tracciato/ARLO."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        rect = None
        for nome in ("03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO", "Arlo Area"):
            lyr = self._find_layer(nome)
            if lyr is None:
                continue
            tr = QgsCoordinateTransform(lyr.crs(), wgs, self.project)
            ext = lyr.extent()
            g = QgsGeometry.fromRect(ext)
            g.transform(tr)
            b = g.boundingBox()
            if rect is None:
                rect = b
            else:
                rect.combineExtentWith(b)
        if rect is None:
            return None
        # margine ~500 m in gradi (~0.005°)
        m = 0.006
        return (rect.yMinimum() - m, rect.xMinimum() - m,
                rect.yMaximum() + m, rect.xMaximum() + m)

    def _rfi_scarica_osm(self):
        self.log_rfi.clear()
        bbox = self._rfi_bbox_progetto()
        if bbox is None:
            QMessageBox.warning(self, "Progetto senza layer",
                                "Servono i layer di progetto (03 INFRASTRUTTURE / "
                                "02_POZZETTO / Arlo Area) per delimitare l'area.")
            return
        latmin, lonmin, latmax, lonmax = bbox
        self._log_rfi("Scarico ferrovia e cippi da OSM (bbox %.4f,%.4f,%.4f,%.4f)..."
                      % (latmin, lonmin, latmax, lonmax))
        b = "%f,%f,%f,%f" % (latmin, lonmin, latmax, lonmax)
        query = ("[out:json][timeout:90];("
                 'way["railway"="rail"](%s);'
                 'node["railway"="milestone"](%s);'
                 ");out body geom;") % (b, b)
        try:
            res = self._overpass(query)
        except Exception as e:
            QMessageBox.critical(self, "OSM non raggiungibile",
                                 "Impossibile scaricare i dati OSM:\n%s" % e)
            return
        els = res.get("elements", [])
        ways = [e for e in els if e["type"] == "way" and e.get("geometry")]
        cippi_raw = [e for e in els if e["type"] == "node"
                     and e.get("tags", {}).get("railway:position")]
        # cippi -> lista dict {km,lat,lon}
        cippi = []
        for c in cippi_raw:
            try:
                km = float(str(c["tags"]["railway:position"]).replace(",", "."))
            except ValueError:
                continue
            cippi.append({"km": km, "lat": c["lat"], "lon": c["lon"]})
        self._rfi_state()["cippi"] = cippi
        self._log_rfi("Trovati %d segmenti di linea e %d cippi km."
                      % (len(ways), len(cippi)))

        # crea layer linea ferroviaria
        lay_linea = self._rfi_layer_linea(ways)
        # crea layer cippi
        lay_cippi = self._rfi_layer_cippi(cippi)
        # crea fascia di rispetto (buffer sulla linea, in metri, CRS metrico)
        fascia_m = self.spin_rfi_fascia.value()
        self._rfi_layer_fascia(lay_linea, fascia_m)
        # z-order finale: Cippi (sopra) > Ferrovia > Fascia (sotto)
        self._rfi_ordina_layer()
        self._log_rfi("Creati layer 'Ferrovia RFI', 'Cippi km RFI' e "
                      "'Fascia di rispetto RFI' (%.0f m)." % fascia_m)
        if not cippi:
            self._log_rfi("ATTENZIONE: nessun cippo km in OSM per questa zona — "
                          "le progressive saranno 'da verificare'.")

    def _rfi_layer_linea(self, ways):
        vl = QgsVectorLayer("LineString?crs=EPSG:4326", "Ferrovia RFI", "memory")
        pr = vl.dataProvider()
        feats = []
        for wy in ways:
            pts = [QgsPointXY(p["lon"], p["lat"]) for p in wy["geometry"]]
            if len(pts) < 2:
                continue
            f = QgsFeature()
            f.setGeometry(QgsGeometry.fromPolylineXY(pts))
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        self._rfi_stile_ferrovia(vl)
        self._rfi_sostituisci_layer("Ferrovia RFI", vl)
        self._rfi_state()["linea_wgs"] = vl
        return vl

    def _rfi_layer_cippi(self, cippi):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Cippi km RFI", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("km", QVariant.Double)])
        vl.updateFields()
        feats = []
        for c in cippi:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(c["lon"], c["lat"])))
            f["km"] = c["km"]
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        self._rfi_stile_cippi(vl)
        self._rfi_sostituisci_layer("Cippi km RFI", vl)
        return vl

    def _rfi_layer_fascia(self, lay_linea, fascia_m):
        """Buffer della linea in metri: trasforma in CRS metrico locale, bufferizza,
        ritorna il layer fascia in WGS84."""
        # scelgo un CRS metrico: UTM32N (EPSG:32632) per l'Italia nord/centro,
        # UTM33N (32633) per l'est. Uso 32632 di default (va bene per stima fascia).
        crs_metrico = QgsCoordinateReferenceSystem("EPSG:32632")
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr_in = QgsCoordinateTransform(wgs, crs_metrico, self.project)
        tr_out = QgsCoordinateTransform(crs_metrico, wgs, self.project)
        geoms_m = []
        for f in lay_linea.getFeatures():
            g = QgsGeometry(f.geometry())
            g.transform(tr_in)
            geoms_m.append(g)
        if not geoms_m:
            return None
        unione = QgsGeometry.unaryUnion(geoms_m)
        buff = unione.buffer(fascia_m, 8)
        buff.transform(tr_out)
        vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "Fascia di rispetto RFI", "memory")
        pr = vl.dataProvider()
        f = QgsFeature()
        f.setGeometry(buff)
        pr.addFeatures([f])
        vl.updateExtents()
        self._rfi_stile_fascia(vl)
        self._rfi_sostituisci_layer("Fascia di rispetto RFI", vl, in_cima=False)
        self._rfi_state()["fascia_wgs"] = vl
        return vl

    # ------------------------------------------------------------ stili
    def _rfi_stile_fascia(self, vl):
        """Fascia di rispetto: riempimento leggerissimo + bordo TRATTEGGIATO."""
        sym = QgsFillSymbol.createSimple({
            "color": "255,80,80,30",          # rosso molto trasparente (alpha 30)
            "outline_color": "200,30,30,255",  # bordo rosso
            "outline_width": "0.6",
            "outline_style": "dash",           # linee tratteggiate agli estremi
        })
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        vl.setOpacity(1.0)
        vl.triggerRepaint()

    def _rfi_stile_ferrovia(self, vl):
        """Ferrovia: simbolo ferroviario classico (linea nera + traversine bianche)."""
        sym = QgsLineSymbol()
        sym.deleteSymbolLayer(0)
        base = QgsSimpleLineSymbolLayer(QColor(0, 0, 0))
        base.setWidth(1.0)
        sym.appendSymbolLayer(base)
        # traversine bianche tratteggiate sopra (effetto binario)
        trav = QgsSimpleLineSymbolLayer(QColor(255, 255, 255))
        trav.setWidth(0.8)
        trav.setPenStyle(Qt.CustomDashLine)
        trav.setCustomDashVector([3, 3])
        trav.setUseCustomDashPattern(True)
        sym.appendSymbolLayer(trav)
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        vl.triggerRepaint()

    def _rfi_stile_cippi(self, vl):
        """Cippi km: pallino ben visibile + etichetta con la progressiva km."""
        sym = QgsMarkerSymbol.createSimple({
            "name": "circle",
            "color": "255,215,0,255",         # giallo cippo
            "outline_color": "0,0,0,255",
            "outline_width": "0.4",
            "size": "2.6",
        })
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        # etichetta km
        pal = QgsPalLayerSettings()
        pal.fieldName = "km"
        pal.isExpression = False
        try:
            pal.placement = QgsPalLayerSettings.OverPoint
        except Exception:
            pass
        tf = QgsTextFormat()
        fnt = QFont("Arial", 8)
        fnt.setBold(True)
        tf.setFont(fnt)
        tf.setSize(8)
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(1.0)
        buf.setColor(QColor(255, 255, 255))
        tf.setBuffer(buf)
        pal.setFormat(tf)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
        vl.triggerRepaint()

    def _rfi_ordina_layer(self):
        """Z-order corretto in cima all'albero: Cippi > Ferrovia > Fascia."""
        root = self.project.layerTreeRoot()
        for nome in ("Fascia di rispetto RFI", "Ferrovia RFI", "Cippi km RFI"):
            nodo = root.findLayer(self._rfi_layer_id(nome))
            if nodo is None:
                continue
            clone = nodo.clone()
            parent = nodo.parent()
            parent.insertChildNode(0, clone)   # sposta in cima
            parent.removeChildNode(nodo)

    def _rfi_layer_id(self, nome):
        for l in self.project.mapLayers().values():
            if l.name() == nome:
                return l.id()
        return None

    def _rfi_sostituisci_layer(self, nome, nuovo, in_cima=True):
        """Rimuove un eventuale layer omonimo e aggiunge il nuovo (identità fresca).
        in_cima=True lo mette in testa all'albero; False lo lascia dove capita
        (poi _rfi_ordina_layer sistema lo z-order finale)."""
        for l in list(self.project.mapLayers().values()):
            if l.name() == nome:
                self.project.removeMapLayer(l.id())
        self.project.addMapLayer(nuovo, addToLegend=True)

    # ------------------------------------------------------- leggi tratte
    def _rfi_leggi_tratte(self):
        try:
            self._rfi_leggi_tratte_impl()
        except Exception as e:
            import traceback
            tb = traceback.format_exc()
            self._log_rfi("ERRORE in 'Leggi tratte':\n" + tb)
            QMessageBox.critical(
                self, "Errore lettura tratte",
                "Si è verificato un errore leggendo le tratte:\n\n%s\n\n"
                "(Dettaglio completo nel log della scheda.)" % e)

    def _rfi_leggi_tratte_impl(self):
        try:
            try:
                from . import ftth_rfi as rfi
            except ImportError:
                import ftth_rfi as rfi
        except ImportError as e:
            QMessageBox.critical(self, "Modulo mancante",
                                 "ftth_rfi non importabile:\n%s" % e)
            return
        st = self._rfi_state()
        fascia = st.get("fascia_wgs")
        # fallback: se la cache è vuota o il layer è stato ricreato/ricaricato,
        # ritrova la fascia tra i layer del progetto per nome (robustezza).
        if fascia is None or not fascia.isValid():
            fascia = self._find_layer("Fascia di rispetto RFI")
            if fascia is not None:
                st["fascia_wgs"] = fascia
        if fascia is None or not fascia.isValid():
            QMessageBox.warning(self, "Fascia mancante",
                                "Prima premi 'Scarica ferrovia + cippi (OSM)': "
                                "crea il layer 'Fascia di rispetto RFI' necessario "
                                "per individuare le tratte interferenti.")
            return
        lyr_infra = self._find_layer("03 INFRASTRUTTURE")
        lyr_poz = self._find_layer("02_POZZETTO")
        if lyr_infra is None:
            QMessageBox.warning(self, "Layer mancante",
                                "Manca '03 INFRASTRUTTURE' nel progetto.")
            return
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        # geometria fascia in WGS84 (unione di tutte le feature, per sicurezza)
        fascia_geoms = [f.geometry() for f in fascia.getFeatures() if f.hasGeometry()]
        if not fascia_geoms:
            QMessageBox.warning(self, "Fascia vuota",
                                "Il layer 'Fascia di rispetto RFI' non ha geometrie. "
                                "Riprova 'Scarica ferrovia+cippi'.")
            return
        fascia_geom = QgsGeometry.unaryUnion(fascia_geoms)
        # raccolgo metri per tecnica dentro la fascia
        metri = {}
        estremi = []   # punti WGS84 degli estremi delle tratte, per stima km
        tr_i = QgsCoordinateTransform(lyr_infra.crs(), wgs, self.project)
        campi = [f.name() for f in lyr_infra.fields()]
        campo_stato = next((c for c in ("STATO", "Stato", "stato") if c in campi), None)
        campo_tipo = next((c for c in ("TIPOLOGIA", "Tipologia") if c in campi), None)
        campo_lung = next((c for c in ("LUNGHEZZA", "Lungh", "lunghezza") if c in campi), None)
        n_tratte = 0

        def _val_str(feat, campo):
            """Valore campo come stringa pulita, gestendo NULL/None."""
            if not campo:
                return ""
            v = feat[campo]
            if v is None:
                return ""
            try:
                if v.isNull():   # QVariant NULL
                    return ""
            except AttributeError:
                pass
            return str(v).strip()

        for f in lyr_infra.getFeatures():
            if not f.hasGeometry():
                continue
            if campo_stato:
                sval = _val_str(f, campo_stato).lower()
                # se STATO valorizzato e non 'nuovo' -> salta; se vuoto -> tieni
                if sval and sval != "nuovo":
                    continue
            g = QgsGeometry(f.geometry())
            g.transform(tr_i)
            if not g.intersects(fascia_geom):
                continue
            tec = rfi.mappa_tecnica(_val_str(f, campo_tipo))
            if not tec:
                continue
            L = 0.0
            if campo_lung:
                try:
                    L = float(_val_str(f, campo_lung).replace(",", "."))
                except ValueError:
                    L = 0.0
            if L <= 0:
                L = g.length()
            metri[tec] = metri.get(tec, 0.0) + L
            n_tratte += 1
            # estremi della polilinea per la stima km (gestisce anche multipart)
            try:
                if g.isMultipart():
                    linee = g.asMultiPolyline()
                    pl = linee[0] if linee else None
                    if pl and linee:
                        pl = linee[0]
                else:
                    pl = g.asPolyline()
                if pl:
                    estremi.append((pl[0].y(), pl[0].x()))
                    estremi.append((pl[-1].y(), pl[-1].x()))
            except Exception:
                pass
        metri = {k: round(v, 2) for k, v in metri.items() if v > 0}

        # pozzetti dentro la fascia
        pozzetti = {}
        if lyr_poz is not None:
            tr_p = QgsCoordinateTransform(lyr_poz.crs(), wgs, self.project)
            campi_p = [f.name() for f in lyr_poz.fields()]
            campo_dim = next((c for c in ("TIPO_POZZE", "Tipo_Pozze") if c in campi_p), None)
            campo_stp = next((c for c in ("STATO", "Stato") if c in campi_p), None)
            for f in lyr_poz.getFeatures():
                if not f.hasGeometry():
                    continue
                sstp = _val_str(f, campo_stp).lower()
                if sstp and sstp != "nuovo":
                    continue
                g = QgsGeometry(f.geometry())
                g.transform(tr_p)
                if not g.intersects(fascia_geom):
                    continue
                dim = _val_str(f, campo_dim)
                if dim:
                    pozzetti[dim] = pozzetti.get(dim, 0) + 1

        # stima km_da / km_a dagli estremi piu' esterni
        cippi = st.get("cippi", [])
        km_da = km_a = rfi.KM_DA_VERIFICARE
        if estremi and cippi:
            # progressive di tutti gli estremi, prendo min e max "numerici"
            prog = []
            for (la, lo) in estremi:
                p = rfi.stima_progressiva(la, lo, cippi)
                prog.append(p)
            validi = [p for p in prog if p != rfi.KM_DA_VERIFICARE]
            if validi:
                # ordina per valore km+metri
                def _val(s):
                    try:
                        k, m = s.split("+"); return int(k) * 1000 + int(m)
                    except Exception:
                        return 0
                validi.sort(key=_val)
                km_da, km_a = validi[0], validi[-1]

        st["tratte"] = [rfi.Tratta(km_da=km_da, km_a=km_a, metri=metri, pozzetti=pozzetti)]
        self._log_rfi("Tratte nella fascia: %d segmenti. Metri per tecnica: %s"
                      % (n_tratte, metri or "nessuno"))
        self._log_rfi("Pozzetti nella fascia: %s" % (pozzetti or "nessuno"))
        self._log_rfi("Progressive stimate: da %s a %s" % (km_da, km_a))
        # calcolo cronoprogramma subito, per anteprima
        d = rfi.DatiIstanzaRFI(nome_comune=self.txt_rfi_comune.text().strip() or "COMUNE")
        d.tratte = st["tratte"]
        rfi.calcola_cronoprogramma(d)
        self._log_rfi("Cronoprogramma: %s -> totale %s giorni"
                      % (d.giorni_tecnica, d.giorni_totali))

    # ------------------------------------------------------------ genera
    def _rfi_raccogli_dati(self, rfi):
        import datetime
        d = rfi.DatiIstanzaRFI(
            nome_comune=self.txt_rfi_comune.text().strip().upper(),
            prov_sigla=self.txt_rfi_prov.text().strip().upper(),
            cap=self.txt_rfi_cap.text().strip(),
            indirizzo_comune=self.txt_rfi_indirizzo.text().strip(),
            comune_pec=self.txt_rfi_comune_pec.text().strip(),
            linea=self.txt_rfi_linea.text().strip().upper(),
            doit_citta=self.txt_rfi_doit_citta.text().strip().upper(),
            doit_indirizzo=self.txt_rfi_doit_ind.text().strip(),
            doit_pec=self.txt_rfi_doit_pec.text().strip(),
            data=datetime.date.today().strftime("%d/%m/%Y"),
            proc_cognome=self.txt_rfi_proc_cognome.text().strip(),
            proc_nome=self.txt_rfi_proc_nome.text().strip(),
            proc_cf=self.txt_rfi_proc_cf.text().strip(),
            proc_nato_a=self.txt_rfi_proc_nato.text().strip(),
            proc_prov=self.txt_rfi_proc_natoprov.text().strip(),
            proc_nato_il=self.txt_rfi_proc_natoil.text().strip(),
            proc_residenza=self.txt_rfi_proc_res.text().strip(),
            proc_via=self.txt_rfi_proc_via.text().strip(),
            proc_doc=self.txt_rfi_proc_doc.text().strip(),
        )
        st = self._rfi_state()
        if st.get("tratte"):
            d.tratte = st["tratte"]
            d.km_da = d.tratte[0].km_da
            d.km_a = d.tratte[0].km_a
        rfi.calcola_cronoprogramma(d)
        return d

    def _rfi_cartella_template(self):
        """Cartella dei TEMPLATE_*.docx. Cerca accanto al progetto, poi nel plugin."""
        candidati = []
        proj_path = self.project.homePath() or ""
        if proj_path:
            candidati.append(os.path.join(proj_path, "RFI TipoD"))
            candidati.append(os.path.join(proj_path, "Permesso Altro Ente", "RFI TipoD"))
        # accanto a questo file (plugin) come fallback
        qui = os.path.dirname(os.path.abspath(__file__))
        candidati.append(os.path.join(qui, "modelli_rfi"))
        for c in candidati:
            if os.path.isdir(c) and os.path.isfile(
                    os.path.join(c, "TEMPLATE_1.0_art.49.docx")):
                return c
        return None

    def _rfi_genera(self):
        try:
            try:
                from . import ftth_rfi as rfi
            except ImportError:
                import ftth_rfi as rfi
        except ImportError as e:
            QMessageBox.critical(self, "Modulo mancante", "ftth_rfi:\n%s" % e)
            return
        # dipendenza python-docx (non sempre presente nel Python di QGIS)
        try:
            import docx  # noqa: F401
        except ImportError:
            QMessageBox.critical(
                self, "Manca python-docx",
                "La generazione dei documenti Word richiede il modulo "
                "'python-docx', non installato in questo QGIS.\n\n"
                "Installalo una volta sola dalla console Python di QGIS:\n"
                "  import pip; pip.main(['install','python-docx'])\n\n"
                "oppure da OSGeo4W Shell:\n"
                "  python -m pip install python-docx")
            return
        if not self.txt_rfi_comune.text().strip():
            QMessageBox.warning(self, "Comune mancante", "Inserisci il comune.")
            return
        tpl = self._rfi_cartella_template()
        if tpl is None:
            QMessageBox.warning(
                self, "Template non trovati",
                "Non trovo i TEMPLATE_*.docx. Attesi in '<progetto>/RFI TipoD/' "
                "o in '<plugin>/modelli_rfi/'.")
            return
        d = self._rfi_raccogli_dati(rfi)
        # cartella output: accanto al progetto
        out = os.path.join(self.project.homePath() or os.path.expanduser("~"),
                           "Istanze RFI", d.nome_comune)
        try:
            prodotti = rfi.genera_istanze(d, tpl, out)
        except Exception as e:
            QMessageBox.critical(self, "Errore generazione", str(e))
            self._log_rfi("ERRORE: %s" % e)
            return
        # Excel dati
        try:
            self._rfi_scrivi_excel(d, out)
        except Exception as e:
            self._log_rfi("Excel non generato: %s" % e)
        ok = [k for k, v in prodotti.items() if v]
        self._log_rfi("Generati: %s" % ", ".join(ok))
        self._log_rfi("Cartella: %s" % out)
        QMessageBox.information(self, "Fatto",
                                "Istanze generate in:\n%s\n\nRicorda: verifica i km "
                                "'da verificare' e i campi XXXXX dell'art.49." % out)

    def _rfi_genera_tavole(self):
        """Genera le tavole di stampa RFI (Corografia + Planimetria) nel progetto."""
        try:
            try:
                from . import ftth_rfi_layout as RL
            except ImportError:
                import ftth_rfi_layout as RL
        except ImportError as e:
            QMessageBox.critical(self, "Modulo mancante", "ftth_rfi_layout:\n%s" % e)
            return
        # servono i layer RFI: almeno la ferrovia o la fascia
        if (self._find_layer("Ferrovia RFI") is None
                and self._find_layer("Fascia di rispetto RFI") is None):
            QMessageBox.warning(
                self, "Layer RFI mancanti",
                "Prima premi 'Scarica ferrovia + cippi (OSM)': le tavole "
                "inquadrano ferrovia e fascia di rispetto.")
            return
        # km: presi dalle tratte lette (se 'Leggi tratte' è stato eseguito)
        km_da = km_a = ""
        st = self._rfi_state()
        tratte = st.get("tratte") or []
        if tratte:
            km_da = getattr(tratte[0], "km_da", "") or ""
            km_a = getattr(tratte[-1], "km_a", "") or ""
        dati = {
            "comune": self.txt_rfi_comune.text().strip(),
            "linea": self.txt_rfi_linea.text().strip(),
            "km_da": km_da,
            "km_a": km_a,
            "doit_citta": self.txt_rfi_doit_citta.text().strip(),
            "fascia": str(self.spin_rfi_fascia.value()),
        }
        # logo FiberCop opzionale (se presente accanto ai template)
        logo = None
        tpl = self._rfi_cartella_template()
        if tpl:
            for cand in ("logo_fibercop.png", "logo_fibercop.jpg", "FiberCop.png"):
                p = os.path.join(tpl, cand)
                if os.path.exists(p):
                    logo = p
                    break
        try:
            nomi = RL.genera_tavole(self.project, dati,
                                    formato=(420, 297), logo_fibercop=logo)
        except Exception as e:
            import traceback
            QMessageBox.critical(self, "Errore tavole", str(e))
            self._log_rfi("ERRORE tavole:\n" + traceback.format_exc())
            return
        self._log_rfi("Tavole create nel progetto: %s" % ", ".join(nomi))
        QMessageBox.information(
            self, "Tavole create",
            "Create le tavole nel Gestore layout di stampa:\n  - %s\n\n"
            "Aprile da Progetto > Layout, verifica l'inquadramento e "
            "aggiungi il timbro/firma nel riquadro 'IL PROGETTISTA', "
            "poi esporta in PDF." % "\n  - ".join(nomi))

    def _rfi_scrivi_excel(self, d, out):
        """Excel dati modificabile (fogli DATI/SCAVI/POZZETTI/CRONO)."""
        try:
            import openpyxl
        except ImportError:
            self._log_rfi("openpyxl non disponibile: salto l'Excel.")
            return
        os.makedirs(out, exist_ok=True)
        wb = openpyxl.Workbook()
        ws = wb.active; ws.title = "DATI"
        coppie = [
            ("TIPOLOGIA", self.cb_rfi_tipologia.currentData()),
            ("NOME_COMUNE", d.nome_comune), ("PROV_SIGLA", d.prov_sigla),
            ("CAP", d.cap), ("INDIRIZZO_COMUNE", d.indirizzo_comune),
            ("COMUNE_PEC", d.comune_pec), ("LINEA", d.linea),
            ("KM_DA", d.km_da), ("KM_A", d.km_a),
            ("DOIT_CITTA", d.doit_citta), ("DOIT_INDIRIZZO", d.doit_indirizzo),
            ("DOIT_PEC", d.doit_pec),
        ]
        for r, (k, val) in enumerate(coppie, 1):
            ws.cell(r, 1, k); ws.cell(r, 2, val)
        # SCAVI
        ws2 = wb.create_sheet("SCAVI")
        ws2.append(["km_da", "km_a", "microtrincea", "nodig", "trincea", "minitrincea"])
        for tr in d.tratte:
            ws2.append([tr.km_da, tr.km_a,
                        tr.metri.get("microtrincea", 0), tr.metri.get("nodig", 0),
                        tr.metri.get("trincea", 0), tr.metri.get("minitrincea", 0)])
        # POZZETTI
        ws3 = wb.create_sheet("POZZETTI")
        dims = sorted({dd for tr in d.tratte for dd in tr.pozzetti})
        ws3.append(["km"] + dims)
        for tr in d.tratte:
            ws3.append([tr.km_da] + [tr.pozzetti.get(x, 0) for x in dims])
        # CRONO
        ws4 = wb.create_sheet("CRONOPROGRAMMA")
        ws4.append(["tecnica", "giorni"])
        for t, g in d.giorni_tecnica.items():
            ws4.append([t, g])
        ws4.append(["TOTALE", d.giorni_totali])
        path = os.path.join(out, d.nome_comune + "_Dati_Istanza_RFI.xlsx")
        wb.save(path)
        self._log_rfi("Excel dati: %s" % os.path.basename(path))
