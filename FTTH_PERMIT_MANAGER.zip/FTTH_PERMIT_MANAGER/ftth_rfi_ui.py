# -*- coding: utf-8 -*-
"""
ftth_rfi_ui.py — Scheda "Istanze RFI" del plugin FTTH Permessi Manager.

Mixin (RFIMixin) agganciato a FTTHPermessiDialog: qui solo il collante QGIS e
l'interfaccia; la logica (tipologie, raggruppamento, documenti) sta in
ftth_rfi.py e le tavole in ftth_rfi_layout.py. (c) Beexact S.r.l.

Flusso della scheda:
  1) Comune (con precompilazione dallo screening)
  2) "Scarica ferrovie, cippi e stazioni (OSM)" -> layer Ferrovia/Cippi/
     Stazioni + Fascia di rispetto (30 m)
  3) "Trova interferenze" -> tabella: una riga per interferenza con la
     tipologia proposta (A/B/C/D), km, metri, pozzetti, stazione. Si conferma
     o si corregge tutto lì.
  4) Destinatari per gestore (RFI DOIT, FS Sud Est, FER, ...)
  5) "Genera istanze" -> una cartella per istanza (tipologia x gestore x linea
     x stazione) con art.49, RT+CR (Word+PDF), Bollo, Modello B, planimetria
     PL in PDF e LEGGIMI con i promemoria.
"""
import json
import os
import urllib.parse
import urllib.request

from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFormLayout,
    QHBoxLayout, QHeaderView, QLineEdit, QMessageBox, QPlainTextEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsFillSymbol, QgsGeometry, QgsLineSymbol, QgsMarkerSymbol,
    QgsPalLayerSettings, QgsPointXY, QgsRectangle, QgsSimpleLineSymbolLayer,
    QgsSingleSymbolRenderer, QgsTextBufferSettings, QgsTextFormat,
    QgsVectorLayer, QgsVectorLayerSimpleLabeling,
)

OVERPASS_MIRRORS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]

TIPI_COMBO = ["A", "B", "C", "D", "?", "—"]     # "—" = nessuna istanza
# layer creati dalla scheda: tutti nel gruppo GRUPPO_RFI, in quest'ordine
GRUPPO_RFI = "RFI - Ferrovie"
LAYER_RFI = ["Interferenze ferroviarie", "Cippi km RFI", "Stazioni ferroviarie",
             "Ferrovia RFI", "Fascia di rispetto RFI"]
DESCR_TIPO = {
    "A": "A — attraversamento con riutilizzo esistente",
    "B": "B — attraversamento in sottovia/sopra galleria",
    "C": "C — attraversamento No Dig",
    "D": "D — parallelismo in fascia 6-30 m",
    "?": "? — da decidere",
    "—": "— nessuna istanza",
}
# colonne della tabella interferenze
C_INCL, C_ID, C_TIPO, C_GEST, C_LINEA, C_STAZ, C_KMDA, C_KMA, C_METRI, C_POZZ, C_DIST, C_PROPR, C_FOTO, C_NOTE = range(14)
INTESTAZIONI = ["Includi", "#", "Tipologia", "Gestore", "Linea (nei documenti)", "Stazione",
                "Km da", "Km a", "Metri", "Pozzetti", "Dist. (m)", "Proprietario (tipo A)",
                "Foto (tavola)", "Note"]


def _rfi_mod():
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    return rfi


def _kb():
    try:
        try:
            from . import ftth_screening as scr
        except ImportError:
            import ftth_screening as scr
        return scr.carica_kb()
    except Exception:  # noqa: BLE001
        import yaml
        qui = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(qui, "procedimenti.yaml"), encoding="utf-8") as fh:
            return yaml.safe_load(fh)


class RFIMixin:
    """Metodi della scheda Istanze RFI. Mescolato in FTTHPermessiDialog."""

    # ------------------------------------------------------------------ UI
    def _tab_rfi(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Prepara le istanze per le interferenze con le linee ferroviarie (RFI e "
            "gestori in concessione come FS Ferrovie Sud Est o FER). Il plugin trova "
            "da solo attraversamenti e parallelismi del tracciato, propone la "
            "tipologia A/B/C/D, stima i km dai cippi OSM e raggruppa le interferenze: "
            "una istanza per ogni tipologia, gestore, linea e stazione. Per ciascuna "
            "produce art. 49, relazione tecnica e cronoprogramma (Word e PDF), bollo, "
            "Modello B e la planimetria PL in PDF. Procuratore e referenti restano "
            "XXXXX da completare; i km stimati vanno sempre verificati."
        ))

        # 1) comune
        gb1 = self._gruppo("1) Comune", compresso=False)
        f1 = QFormLayout(gb1)
        self.txt_rfi_comune = QLineEdit(); self.txt_rfi_comune.setPlaceholderText("es. ANDRANO")
        self.txt_rfi_comune.setToolTip("Scritto il comune (Invio o cambio campo) provincia, CAP "
                                       "e DOIT RFI si compilano da soli.")
        self.txt_rfi_comune.editingFinished.connect(self._rfi_auto_comune)
        f1.addRow("Comune:", self.txt_rfi_comune)
        self.txt_rfi_prov = QLineEdit(); self.txt_rfi_prov.setPlaceholderText("sigla, es. LE")
        f1.addRow("Provincia (sigla):", self.txt_rfi_prov)
        self.txt_rfi_cap = QLineEdit()
        f1.addRow("CAP:", self.txt_rfi_cap)
        self.txt_rfi_indirizzo = QLineEdit(); self.txt_rfi_indirizzo.setPlaceholderText("indirizzo del Comune")
        f1.addRow("Indirizzo Comune:", self.txt_rfi_indirizzo)
        self.txt_rfi_comune_pec = QLineEdit()
        f1.addRow("PEC Comune:", self.txt_rfi_comune_pec)
        self.btn_rfi_precompila = QPushButton("Precompila dallo screening territorio")
        self.btn_rfi_precompila.setToolTip(
            "Risolve il comune (CAP, provincia, regione) e la DOIT RFI competente per "
            "la regione. Non tocca i campi già compilati.")
        self.btn_rfi_precompila.clicked.connect(self._rfi_precompila_da_screening)
        f1.addRow(self.btn_rfi_precompila)
        v.addWidget(gb1)

        # 2) ferrovie
        gb2 = self._gruppo("2) Ferrovie, cippi km e stazioni", compresso=False)
        v2 = QVBoxLayout(gb2)
        f2 = QFormLayout()
        self.spin_rfi_fascia = self._dspin(1, 200, 30, 0, " m")
        self.spin_rfi_fascia.setToolTip("Fascia di rispetto ferroviaria (art. 49 DPR 753/1980): 30 m.")
        f2.addRow("Fascia di rispetto:", self.spin_rfi_fascia)
        # cippi km da un layer del progetto: dove OSM non ha i cippi ferroviari
        # (es. Eboli) i km resterebbero tutti "da verificare"
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox
        self.cb_rfi_cippi = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        self.cb_rfi_cippi.setLayer(None)
        self.cb_rfi_cippi.setToolTip(
            "Layer di punti con i cippi chilometrici della linea (es. rilevati o forniti dal "
            "gestore). Se lo scegli sostituisce i cippi di OSM per la stima dei km.")
        f2.addRow("Cippi km dal progetto (facoltativo):", self.cb_rfi_cippi)
        self.cb_rfi_cippi_campo = QgsFieldComboBox()
        self.cb_rfi_cippi.layerChanged.connect(self.cb_rfi_cippi_campo.setLayer)
        f2.addRow("Campo con il km (es. «KM 29+417»):", self.cb_rfi_cippi_campo)
        v2.addLayout(f2)
        self.btn_rfi_osm = QPushButton("Scarica ferrovie, cippi e stazioni (OSM)")
        self.btn_rfi_osm.clicked.connect(self._rfi_scarica_osm)
        riga_osm = QHBoxLayout()
        riga_osm.addWidget(self.btn_rfi_osm)
        b_salva_rfi = QPushButton("Salva layer RFI…")
        b_salva_rfi.setToolTip(
            "Rende permanenti i layer del gruppo «%s» (ferrovia, fascia, cippi, stazioni, "
            "interferenze): un GeoPackage nella cartella che scegli, con gli stili incorporati. "
            "Nel progetto i layer temporanei vengono sostituiti da quelli salvati." % GRUPPO_RFI)
        b_salva_rfi.clicked.connect(self._rfi_salva_layer)
        riga_osm.addWidget(b_salva_rfi)
        v2.addLayout(riga_osm)
        v.addWidget(gb2)

        # 3) interferenze
        gb3 = self._gruppo("3) Interferenze: controlla e conferma", compresso=False)
        v3 = QVBoxLayout(gb3)
        riga3 = QHBoxLayout()
        self.btn_rfi_trova = QPushButton("Trova interferenze nel tracciato")
        self.btn_rfi_trova.clicked.connect(self._rfi_trova_interferenze)
        riga3.addWidget(self.btn_rfi_trova)
        self.btn_rfi_zoom = QPushButton("Zoom sulla riga selezionata")
        self.btn_rfi_zoom.clicked.connect(self._rfi_zoom_riga)
        riga3.addWidget(self.btn_rfi_zoom)
        riga3.addStretch()
        v3.addLayout(riga3)
        self.tab_rfi = QTableWidget(0, len(INTESTAZIONI))
        self.tab_rfi.setHorizontalHeaderLabels(INTESTAZIONI)
        self.tab_rfi.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tab_rfi.setMinimumHeight(220)
        self.tab_rfi.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tab_rfi.horizontalHeader().setStretchLastSection(True)
        self.tab_rfi.cellDoubleClicked.connect(self._rfi_doppio_clic)
        v3.addWidget(self.tab_rfi)
        self.lbl_rfi_riepilogo = self._desc(
            "Le righe con la stessa tipologia, gestore, linea e stazione finiscono nella "
            "stessa istanza. Doppio clic sulla colonna Foto per scegliere la foto della "
            "tavola. Tipologia «?» o «—»: la riga non genera istanze.")
        v3.addWidget(self.lbl_rfi_riepilogo)
        v.addWidget(gb3)

        # 4) destinatari
        gb4 = self._gruppo("4) Destinatari per gestore", compresso=False)
        v4 = QVBoxLayout(gb4)
        self.tab_rfi_dest = QTableWidget(0, 4)
        self.tab_rfi_dest.setHorizontalHeaderLabels(
            ["Gestore", "Destinatario (Spett.le)", "Indirizzo", "PEC"])
        self.tab_rfi_dest.horizontalHeader().setStretchLastSection(True)
        self.tab_rfi_dest.setMinimumHeight(90)
        v4.addWidget(self.tab_rfi_dest)
        f4 = QFormLayout()
        self.cb_rfi_doit = QComboBox()
        self.cb_rfi_doit.setToolTip(
            "DOIT = Direzione Operativa Infrastrutture Territoriale: l'ufficio regionale di RFI "
            "competente per la linea, a cui va indirizzata l'istanza (con la sua PEC). Il "
            "plugin la propone in base alla regione; se la linea è al confine fra due "
            "strutture scegli quella giusta.")
        self.cb_rfi_doit.currentIndexChanged.connect(self._rfi_applica_doit)
        f4.addRow("DOIT RFI:", self.cb_rfi_doit)
        v4.addLayout(f4)
        v.addWidget(gb4)

        # 5) genera
        gb5 = self._gruppo("5) Genera le istanze", compresso=False)
        v5 = QVBoxLayout(gb5)
        self.chk_rfi_pdf_tutti = QCheckBox("Converti in PDF anche art. 49, Bollo e Modello B "
                                           "(la relazione RT+CR è sempre in PDF)")
        v5.addWidget(self.chk_rfi_pdf_tutti)
        self.chk_rfi_pl = QCheckBox("Genera la planimetria 1.1 PL (layout QGIS + PDF)")
        self.chk_rfi_pl.setChecked(True)
        v5.addWidget(self.chk_rfi_pl)
        f5 = QFormLayout()
        self.cb_rfi_orto = QComboBox()
        self.cb_rfi_orto.setToolTip("Layer raster per il riquadro ORTOFOTO delle tavole. "
                                    "«automatico» aggiunge Esri World Imagery se nel progetto "
                                    "non c'è un'ortofoto.")
        f5.addRow("Ortofoto per le tavole:", self.cb_rfi_orto)
        # cartelle separate per sezioni, foto e particolari costruttivi
        # (vuote = cartelle del progetto 05_Sezioni / 04_Foto, poi il plugin)
        def _riga_cartella(chiave, segnaposto, tip):
            riga = QHBoxLayout()
            txt = QLineEdit()
            txt.setPlaceholderText(segnaposto)
            txt.setToolTip(tip)
            try:
                from qgis.core import QgsSettings
                txt.setText(QgsSettings().value("ftth_permessi/%s" % chiave, "") or "")
            except Exception:  # noqa: BLE001
                pass
            riga.addWidget(txt)
            b = QPushButton("Sfoglia…")
            b.clicked.connect(lambda _=False, t=txt, k=chiave: self._rfi_scegli_cartella(t, k))
            riga.addWidget(b)
            return riga, txt
        r_sez, self.txt_rfi_cart_sez = _riga_cartella(
            "rfi_cartella_sezioni", "vuota = 05_Sezioni del progetto",
            "Disegni delle sezioni: SEZIONE A-A'.svg (sezione disegnata nel layer Sezioni) "
            "oppure sezione_tipo_A … sezione_tipo_D. SVG consigliato, anche PNG/JPG.")
        r_foto, self.txt_rfi_cart_foto = _riga_cartella(
            "rfi_cartella_foto", "vuota = 04_Foto del progetto",
            "Foto: FOTO-n.jpg (n = NumeroFoto del punto di ripresa) oppure foto_<numero "
            "interferenza>.")
        r_part, self.txt_rfi_cartella = _riga_cartella(
            "rfi_cartella_utente", "vuota = particolari del plugin",
            "Particolari costruttivi che sostituiscono quelli del plugin, chiamati come la "
            "chiave: sezione_minitrincea, sezione_trincea, pozzetto_76x40, tubi …")
        # chi aveva messo la cartella delle sezioni nel vecchio campo unico la
        # ritrova nel campo giusto
        vecchia = self.txt_rfi_cartella.text().strip()
        if vecchia and not self.txt_rfi_cart_sez.text().strip() and \
                "sezion" in os.path.basename(vecchia.rstrip("/\\")).lower():
            self.txt_rfi_cart_sez.setText(vecchia)
            self.txt_rfi_cartella.clear()
            try:
                from qgis.core import QgsSettings
                QgsSettings().setValue("ftth_permessi/rfi_cartella_sezioni", vecchia)
                QgsSettings().setValue("ftth_permessi/rfi_cartella_utente", "")
            except Exception:  # noqa: BLE001
                pass
        f5.addRow("Cartella sezioni:", r_sez)
        f5.addRow("Cartella foto:", r_foto)
        f5.addRow("Cartella particolari:", r_part)
        v5.addLayout(f5)
        # rese del cronoprogramma, modificabili e ricordate fra le sessioni
        v5.addWidget(self._rfi_box_rese())
        # foto e sezioni da piazzare sulla mappa, come nel progetto Altri Enti
        riga_fs = QHBoxLayout()
        b_fs = QPushButton("Prepara layer Foto e Sezioni")
        b_fs.setToolTip(
            "Aggiunge al progetto, se mancano, i layer «Punto di Ripresa Fotografico» "
            "(cono orientato dal campo Rotazione, etichetta FOTO n) e «Sezioni» (linea "
            "con le sigle A-A'), con lo stile di Altri Enti.\n"
            "Poi: punto di ripresa con NumeroFoto -> in tavola la foto 04_Foto/FOTO-n.jpg; "
            "linea di sezione con sezione=A -> in tavola 05_Sezioni/SEZIONE A-A'.svg.")
        b_fs.clicked.connect(self._rfi_prepara_foto_sezioni)
        riga_fs.addWidget(b_fs)
        riga_fs.addStretch()
        v5.addLayout(riga_fs)
        riga5 = QHBoxLayout()
        self.btn_rfi_genera = QPushButton("Genera istanze")
        self.btn_rfi_genera.clicked.connect(self._rfi_genera)
        riga5.addWidget(self.btn_rfi_genera)
        self.btn_rfi_apri = QPushButton("Apri la cartella")
        self.btn_rfi_apri.clicked.connect(self._rfi_apri_cartella)
        riga5.addWidget(self.btn_rfi_apri)
        riga5.addStretch()
        v5.addLayout(riga5)
        v.addWidget(gb5)

        self.log_rfi = QPlainTextEdit(); self.log_rfi.setReadOnly(True)
        self.log_rfi.setMinimumHeight(120)
        v.addWidget(self.log_rfi)
        v.addStretch()
        self._rfi_aggiorna_orto()
        return w

    def _rfi_scegli_cartella(self, txt=None, chiave="rfi_cartella_utente"):
        from qgis.PyQt.QtWidgets import QFileDialog as _QFD
        txt = txt or self.txt_rfi_cartella
        c = _QFD.getExistingDirectory(self, "Scegli la cartella", txt.text().strip() or "")
        if c:
            txt.setText(c)
            try:
                from qgis.core import QgsSettings
                QgsSettings().setValue("ftth_permessi/%s" % chiave, c)
            except Exception:  # noqa: BLE001
                pass

    # ------------------------------------------------ rese cronoprogramma
    # (chiave in rese_complete, sottochiave o None, etichetta, unita', passo)
    VOCI_RESE = [
        ("minitrincea", None, "Scavo minitrincea", "m/giorno", 10),
        ("microtrincea", None, "Scavo microtrincea", "m/giorno", 10),
        ("trincea", None, "Scavo tradizionale", "m/giorno", 5),
        ("nodig", None, "Perforazione no-dig", "m/giorno", 5),
        ("pozzetti", "125x80", "Posa pozzetto 125x80", "pezzi/giorno", 0.5),
        ("pozzetti", "90x70", "Posa pozzetto 90x70", "pezzi/giorno", 0.5),
        ("pozzetti", "76x40", "Posa pozzetto 76x40", "pezzi/giorno", 0.5),
        ("pozzetti", "45x15", "Posa pozzetto 45x15 / 40x15", "pezzi/giorno", 0.5),
        ("ripristino", "minitrincea", "Ripristino manto minitrincea", "m/giorno", 10),
        ("ripristino", "microtrincea", "Ripristino manto microtrincea", "m/giorno", 10),
        ("ripristino", "trincea", "Ripristino manto scavo tradizionale", "m/giorno", 10),
        ("ripristino_nodig", None, "Ripristino buche no-dig", "giorni per tratta", 0.5),
        ("ripristino_chiusini", None, "Ripristino attorno ai chiusini", "pezzi/giorno", 1),
    ]

    def _rfi_box_rese(self):
        from qgis.PyQt.QtWidgets import QDoubleSpinBox, QGroupBox, QLabel, QGridLayout
        rfi = _rfi_mod()
        gb = QGroupBox("Rese per il cronoprogramma (giorni = scavo + posa pozzetti + ripristini)")
        gb.setCheckable(True)
        gb.setChecked(False)          # chiuso: si apre spuntandolo
        gb.setToolTip("Valori di produttività della squadra. Scavo minitrincea e tradizionale "
                      "vengono dalle pratiche presentate; gli altri sono stime da tarare.\n"
                      "I valori si ricordano fra una sessione e l'altra.")
        contenuto = QWidget()
        grid = QGridLayout(contenuto)
        grid.setContentsMargins(4, 4, 4, 4)
        base = rfi.rese_complete()
        salvate = self._rfi_rese_salvate()
        self._spin_rese = {}
        for n, (k, sk, nome, unita, passo) in enumerate(self.VOCI_RESE):
            sp = QDoubleSpinBox()
            sp.setDecimals(1)
            sp.setRange(0.1, 2000)
            sp.setSingleStep(passo)
            predef = base[k][sk] if sk else base[k]
            val = (salvate.get(k, {}) or {}).get(sk) if sk else salvate.get(k)
            sp.setValue(float(val) if val else float(predef))
            sp.setToolTip("Predefinito: %s %s" % (predef, unita))
            sp.valueChanged.connect(self._rfi_salva_rese)
            self._spin_rese[(k, sk)] = sp
            r, c = n % 7, (n // 7) * 3
            grid.addWidget(QLabel(nome + ":"), r, c)
            grid.addWidget(sp, r, c + 1)
            grid.addWidget(QLabel(unita), r, c + 2)
        b = QPushButton("Valori predefiniti")
        b.clicked.connect(self._rfi_rese_predefinite)
        grid.addWidget(b, 7, 0)
        lay = QVBoxLayout(gb)
        lay.addWidget(contenuto)
        contenuto.setVisible(False)
        gb.toggled.connect(contenuto.setVisible)
        return gb

    def _rfi_rese_salvate(self):
        try:
            from qgis.core import QgsSettings
            return json.loads(QgsSettings().value("ftth_permessi/rfi_rese", "") or "{}")
        except Exception:  # noqa: BLE001
            return {}

    def _rfi_rese(self):
        """Rese attuali della scheda, nel formato di ftth_rfi.rese_complete."""
        out = {}
        for (k, sk), sp in getattr(self, "_spin_rese", {}).items():
            if sk:
                out.setdefault(k, {})[sk] = sp.value()
                if k == "pozzetti" and sk == "45x15":
                    out[k]["40x15"] = sp.value()
            else:
                out[k] = sp.value()
        return out

    def _rfi_salva_rese(self, *_):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/rfi_rese", json.dumps(self._rfi_rese()))
        except Exception:  # noqa: BLE001
            pass

    def _rfi_rese_predefinite(self):
        base = _rfi_mod().rese_complete()
        for (k, sk), sp in self._spin_rese.items():
            sp.blockSignals(True)
            sp.setValue(float(base[k][sk] if sk else base[k]))
            sp.blockSignals(False)
        self._rfi_salva_rese()

    def _rfi_prepara_foto_sezioni(self):
        """Crea (se mancano) i layer per piazzare punti di ripresa e sezioni,
        in GeoPackage accanto al progetto, con lo stile del plugin."""
        from qgis.core import QgsProject, QgsVectorFileWriter, QgsFields, QgsWkbTypes
        try:
            from . import ftth_rfi_layout as L
        except ImportError:
            import ftth_rfi_layout as L
        prj = QgsProject.instance()
        home = prj.homePath()
        if not home:
            QMessageBox.warning(self, "Progetto non salvato",
                                "Salva prima il progetto: i layer vanno nella sua cartella.")
            return
        stili = os.path.join(os.path.dirname(os.path.abspath(__file__)), "styles")
        crs = prj.crs() if prj.crs().isValid() else QgsCoordinateReferenceSystem("EPSG:25832")
        definizioni = [
            (L.NOMI_LAYER_FOTO, "Punto di Ripresa Fotografico", "Point",
             os.path.join(home, "01_File shp", "Punti di Ripresa"),
             [("NumeroFoto", QVariant.Int), ("Rotazione", QVariant.Double)],
             "rfi_punto_ripresa.qml"),
            (L.NOMI_LAYER_SEZIONI, "Sezioni", "LineString",
             os.path.join(home, "01_File shp", "Sezioni"),
             [("sezione", QVariant.String), ("sezione_f", QVariant.String),
              ("etichetta", QVariant.String)],
             "rfi_sezioni.qml"),
        ]
        esiti = []
        for nomi, nome, geom, cartella, campi, qml in definizioni:
            if any(prj.mapLayersByName(n) for n in nomi):
                esiti.append("«%s»: già nel progetto" % nome)
                continue
            os.makedirs(cartella, exist_ok=True)
            gpkg = os.path.join(cartella, nome + ".gpkg")
            if not os.path.isfile(gpkg):
                fields = QgsFields()
                for c, t in campi:
                    fields.append(QgsField(c, t))
                opz = QgsVectorFileWriter.SaveVectorOptions()
                opz.driverName = "GPKG"
                opz.layerName = nome
                w = QgsVectorFileWriter.create(gpkg, fields, getattr(QgsWkbTypes, geom),
                                               crs, prj.transformContext(), opz)
                del w
            lyr = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
            if not lyr.isValid():
                esiti.append("«%s»: creazione non riuscita (%s)" % (nome, gpkg))
                continue
            p = os.path.join(stili, qml)
            if os.path.isfile(p):
                lyr.loadNamedStyle(p)
            prj.addMapLayer(lyr)
            esiti.append("«%s»: creato in %s" % (nome, os.path.relpath(gpkg, home)))
        for sotto in ("04_Foto", "05_Sezioni"):
            os.makedirs(os.path.join(home, sotto), exist_ok=True)
        testo = "\n".join(esiti) + (
            "\n\nCome si usano:\n"
            "• Punto di Ripresa: metti il punto dove stai scattando, NumeroFoto = n, "
            "Rotazione = direzione del cono (gradi). Foto in 04_Foto\\FOTO-n.jpg.\n"
            "• Sezioni: traccia una linea di traverso allo scavo, sezione = A "
            "(sezione_f = A' si può lasciare vuoto). Disegno in 05_Sezioni\\SEZIONE A-A'.svg.\n"
            "In ogni tavola compaiono quelli che cadono nella planimetria.")
        self._log_rfi(testo)
        QMessageBox.information(self, "Foto e Sezioni", testo)

    def _rfi_auto_comune(self):
        """Scritto il comune: provincia (sigla), CAP, regione e DOIT, solo se i
        campi sono vuoti. Basta Nominatim (1-2 s), niente ricerca ferrovie."""
        nome = self.txt_rfi_comune.text().strip()
        st = self._rfi_state()
        if not nome or st.get("_ultimo_comune") == nome.lower():
            return
        st["_ultimo_comune"] = nome.lower()
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
            from qgis.PyQt.QtWidgets import QApplication
            QApplication.setOverrideCursor(Qt.BusyCursor)
            try:
                c = scr.risolvi_comune(nome, None)
            finally:
                QApplication.restoreOverrideCursor()
        except Exception as e:  # noqa: BLE001
            self._log_rfi("Comune non risolto automaticamente: %s" % e)
            return
        if not c.data:
            self._log_rfi("Comune «%s» non trovato: compila provincia e CAP a mano." % nome)
            return
        d = c.data
        if not self.txt_rfi_prov.text().strip():
            self.txt_rfi_prov.setText(_rfi_mod().sigla_provincia(d.get("provincia")) or "")
        if not self.txt_rfi_cap.text().strip() and d.get("cap"):
            self.txt_rfi_cap.setText(str(d["cap"]).split(";")[0].strip())
        st["regione"] = d.get("regione")
        self._rfi_riempi_doit()
        self._log_rfi("Comune: %s (%s) — %s, CAP %s" % (
            d.get("nome"), self.txt_rfi_prov.text(), d.get("regione") or "?",
            self.txt_rfi_cap.text() or "da compilare"))

    def _log_rfi(self, msg):
        self.log_rfi.appendPlainText(str(msg))
        self.log_rfi.repaint()

    def _rfi_state(self):
        if not hasattr(self, "_rfi_dati_cache"):
            self._rfi_dati_cache = {"cippi": [], "ways": [], "stazioni": [],
                                    "interferenze": [], "regione": None,
                                    "gestori": {}, "cartella": None}
        return self._rfi_dati_cache

    # ---------------------------------------------- precompila da screening
    def _rfi_precompila_da_screening(self):
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
        except ImportError as e:
            QMessageBox.critical(self, "Screening non disponibile", str(e))
            return
        comune = self.txt_rfi_comune.text().strip()
        if not comune and hasattr(self, "txt_scr_comune"):
            comune = self.txt_scr_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune e riprova.")
            return
        self.log_rfi.clear()
        self._log_rfi("Comune e struttura RFI per %s..." % comune)
        self.btn_rfi_precompila.setEnabled(False)
        try:
            from qgis.PyQt.QtWidgets import QApplication
            QApplication.processEvents()
            rep = scr.esegui_rfi(comune, None, avanzamento=lambda m: self._log_rfi("  " + str(m)))
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Screening non riuscito", str(e))
            return
        finally:
            self.btn_rfi_precompila.setEnabled(True)
        if rep.get("errore"):
            QMessageBox.warning(self, "Comune non risolto", rep["errore"])
            return
        c = rep.get("comune") or {}

        def _se_vuoto(widget, valore):
            if valore and not widget.text().strip():
                widget.setText(str(valore))
        if c.get("nome") and not self.txt_rfi_comune.text().strip():
            self.txt_rfi_comune.setText(c["nome"].upper())
        _se_vuoto(self.txt_rfi_cap, c.get("cap"))
        _se_vuoto(self.txt_rfi_prov, _rfi_mod().sigla_provincia(c.get("provincia"))
                  or c.get("provincia"))
        self._rfi_state()["regione"] = c.get("regione")
        self._rfi_riempi_doit(rep.get("rfi"))
        self._log_rfi("Fatto. Completa a mano indirizzo e PEC del Comune se mancano.")

    def _rfi_riempi_doit(self, rfi_c=None):
        """Popola la scelta della DOIT RFI dalla kb della regione."""
        if rfi_c is None:
            try:
                try:
                    from . import ftth_screening as scr
                except ImportError:
                    import ftth_screening as scr
                rfi_c = scr.rfi_struttura(self._rfi_state().get("regione"))
            except Exception:  # noqa: BLE001
                rfi_c = None
        self.cb_rfi_doit.blockSignals(True)
        self.cb_rfi_doit.clear()
        for c in (rfi_c or {}).get("contatti") or []:
            self.cb_rfi_doit.addItem("%s — %s" % (c.get("doit"), c.get("pec")), c)
        if self.cb_rfi_doit.count() == 0 and rfi_c:
            self.cb_rfi_doit.addItem(rfi_c.get("citta") or "", {"doit": rfi_c.get("citta"), "pec": ""})
        self.cb_rfi_doit.blockSignals(False)
        if self.cb_rfi_doit.count() > 1:
            self._log_rfi("Più DOIT RFI possibili per la regione: scegli quella competente "
                          "per la linea nel punto 4.")
        self._rfi_applica_doit()

    def _rfi_applica_doit(self, *_):
        c = self.cb_rfi_doit.currentData()
        if not c:
            return
        for r in range(self.tab_rfi_dest.rowCount()):
            if self.tab_rfi_dest.item(r, 0).data(Qt.UserRole) == "rfi":
                self.tab_rfi_dest.setItem(r, 1, QTableWidgetItem(
                    "RFI - Direzione Operativa Infrastrutture Territoriale di %s"
                    % str(c.get("doit") or "").upper()))
                if c.get("pec"):
                    self.tab_rfi_dest.setItem(r, 3, QTableWidgetItem(c["pec"]))

    # ------------------------------------------------------- OSM download
    def _overpass(self, query, timeout=60):
        """Stessa richiesta a tutti i server Overpass in parallelo: vale la prima
        risposta valida. Prima i server si provavano uno dopo l'altro (con due
        tentativi ciascuno) e un server lento bloccava tutto per minuti."""
        import concurrent.futures as cf
        from qgis.PyQt.QtWidgets import QApplication
        data = urllib.parse.urlencode({"data": query}).encode()

        def _una(url):
            req = urllib.request.Request(url, data=data, headers={"User-Agent": "ftth-permessi/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                ris = json.load(r)
            if "elements" not in ris:
                raise ValueError("risposta Overpass senza dati")
            return ris

        ex = cf.ThreadPoolExecutor(max_workers=len(OVERPASS_MIRRORS))
        futuri = [ex.submit(_una, m) for m in OVERPASS_MIRRORS]
        ultimo = None
        try:
            in_corso = set(futuri)
            while in_corso:
                fatti, in_corso = cf.wait(in_corso, timeout=0.2, return_when=cf.FIRST_COMPLETED)
                QApplication.processEvents()      # la finestra resta viva durante l'attesa
                for f in fatti:
                    try:
                        return f.result()
                    except Exception as e:  # noqa: BLE001
                        ultimo = e
            raise ultimo or RuntimeError("nessun server Overpass ha risposto")
        finally:
            ex.shutdown(wait=False, cancel_futures=True)

    def _rfi_bbox_progetto(self, margine=0.006):
        """(latmin, lonmin, latmax, lonmax) WGS84 dei layer di progetto."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        rect = None
        for nome in ("03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO", "Arlo Area"):
            lyr = self._find_layer(nome)
            if lyr is None or not lyr.isValid():
                continue
            g = QgsGeometry.fromRect(lyr.extent())
            g.transform(QgsCoordinateTransform(lyr.crs(), wgs, self.project))
            b = g.boundingBox()
            if b.isEmpty():
                continue
            if rect is None:
                rect = QgsRectangle(b)
            else:
                rect.combineExtentWith(b)
        if rect is None:
            return None
        return (rect.yMinimum() - margine, rect.xMinimum() - margine,
                rect.yMaximum() + margine, rect.xMaximum() + margine)

    def _rfi_scarica_osm(self):
        self.log_rfi.clear()
        bbox = self._rfi_bbox_progetto()
        if bbox is None:
            QMessageBox.warning(self, "Progetto senza layer",
                                "Servono i layer di progetto (03 INFRASTRUTTURE / 02_POZZETTO "
                                "/ Arlo Area) per delimitare l'area.")
            return
        b = "%f,%f,%f,%f" % bbox
        # stazioni in un intorno un po' piu' largo (~3 km): la stazione di
        # riferimento puo' stare fuori dall'area di progetto
        m = 0.03
        bs = "%f,%f,%f,%f" % (bbox[0] - m, bbox[1] - m, bbox[2] + m, bbox[3] + m)
        query = ("[out:json][timeout:60];("
                 'way["railway"~"^(rail|narrow_gauge|light_rail)$"](%s);'
                 'node["railway"="milestone"](%s);'
                 'node["railway"~"^(station|halt)$"](%s);'
                 ");out body geom qt;") % (b, b, bs)
        # cache: i server Overpass pubblici rispondono in 30-60 s (misurato); per
        # la stessa zona il secondo scaricamento e' immediato per 30 giorni
        import hashlib
        import time as _time
        cache_dir = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache")
        chiave = hashlib.md5(query.encode("utf-8")).hexdigest()
        cache_p = os.path.join(cache_dir, "overpass_rfi_%s.json" % chiave)
        res = None
        if os.path.isfile(cache_p) and _time.time() - os.path.getmtime(cache_p) < 30 * 86400:
            try:
                with open(cache_p, encoding="utf-8") as fh:
                    res = json.load(fh)
                self._log_rfi("Dati OSM dalla cache (scaricati il %s)."
                              % _time.strftime("%d/%m/%Y", _time.localtime(os.path.getmtime(cache_p))))
            except Exception:  # noqa: BLE001
                res = None
        if res is None:
            self._log_rfi("Scarico da OSM ferrovie, cippi km e stazioni (i server pubblici "
                          "rispondono in 30-60 secondi, QGIS resta utilizzabile)...")
            try:
                res = self._overpass(query)
            except Exception as e:  # noqa: BLE001
                QMessageBox.critical(self, "OSM non raggiungibile",
                                     "Impossibile scaricare i dati OSM:\n%s" % e)
                return
            try:
                os.makedirs(cache_dir, exist_ok=True)
                with open(cache_p, "w", encoding="utf-8") as fh:
                    json.dump(res, fh)
            except Exception:  # noqa: BLE001
                pass
        els = res.get("elements", [])
        ways = [e for e in els if e["type"] == "way" and e.get("geometry")]
        cippi = []
        stazioni = []
        for e in els:
            if e["type"] != "node":
                continue
            t = e.get("tags", {})
            if t.get("railway") == "milestone" and t.get("railway:position"):
                try:
                    km = float(str(t["railway:position"]).replace(",", "."))
                except ValueError:
                    continue
                cippi.append({"km": km, "lat": e["lat"], "lon": e["lon"]})
            elif t.get("railway") in ("station", "halt"):
                stazioni.append({"nome": t.get("name") or "stazione senza nome",
                                 "lat": e["lat"], "lon": e["lon"]})
        st = self._rfi_state()
        st.update(cippi=cippi, ways=ways, stazioni=stazioni)
        lay = self._rfi_layer_linea(ways)
        self._rfi_layer_cippi(cippi)
        self._rfi_layer_stazioni(stazioni)
        self._rfi_layer_fascia(lay, self.spin_rfi_fascia.value())
        self._rfi_ordina_layer()
        linee = sorted({(w.get("tags", {}).get("operator") or "operatore ignoto",
                         w.get("tags", {}).get("name") or w.get("tags", {}).get("ref") or "senza nome")
                        for w in ways})
        self._log_rfi("Linee: %d tratti OSM — %s" % (
            len(ways), "; ".join("%s (%s)" % (n, o) for o, n in linee) or "nessuna"))
        self._log_rfi("Cippi km: %d · stazioni: %s" % (
            len(cippi), ", ".join(s["nome"] for s in stazioni) or "nessuna"))
        if not ways:
            QMessageBox.information(self, "Nessuna ferrovia",
                                    "OSM non riporta linee ferroviarie nell'area del progetto.")
        if not cippi:
            self._log_rfi("ATTENZIONE: nessun cippo km in OSM — le progressive saranno "
                          "«da verificare» (XXX+XXX nei documenti).")

    def _rfi_layer_linea(self, ways):
        vl = QgsVectorLayer("LineString?crs=EPSG:4326", "Ferrovia RFI", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("nome", QVariant.String), QgsField("ref", QVariant.String),
                          QgsField("operator", QVariant.String)])
        vl.updateFields()
        feats = []
        for wy in ways:
            pts = [QgsPointXY(p["lon"], p["lat"]) for p in wy["geometry"]]
            if len(pts) < 2:
                continue
            t = wy.get("tags", {})
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPolylineXY(pts))
            f["nome"] = t.get("name") or ""
            f["ref"] = t.get("ref") or ""
            f["operator"] = t.get("operator") or ""
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        self._rfi_stile_ferrovia(vl)
        self._rfi_sostituisci_layer("Ferrovia RFI", vl)
        return vl

    def _rfi_layer_cippi(self, cippi):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Cippi km RFI", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("km", QVariant.Double)])
        vl.updateFields()
        feats = []
        for c in cippi:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(c["lon"], c["lat"])))
            f["km"] = c["km"]
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        self._rfi_stile_cippi(vl)
        self._rfi_sostituisci_layer("Cippi km RFI", vl)
        return vl

    def _rfi_layer_stazioni(self, stazioni):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Stazioni ferroviarie", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("nome", QVariant.String)])
        vl.updateFields()
        feats = []
        for s in stazioni:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(s["lon"], s["lat"])))
            f["nome"] = s["nome"]
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "square", "color": "30,30,30,255", "outline_color": "255,255,255,255",
             "size": "3"})))
        self._rfi_etichetta(vl, "nome", 8)
        self._rfi_sostituisci_layer("Stazioni ferroviarie", vl)
        return vl

    def _rfi_layer_fascia(self, lay_linea, fascia_m):
        """Buffer metrico della linea (UTM della zona), restituito in WGS84."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        ext = lay_linea.extent()
        zona = int((ext.center().x() + 180) / 6) + 1
        crs_m = QgsCoordinateReferenceSystem("EPSG:%d" % (32600 + zona))
        tr_in = QgsCoordinateTransform(wgs, crs_m, self.project)
        tr_out = QgsCoordinateTransform(crs_m, wgs, self.project)
        geoms = []
        for f in lay_linea.getFeatures():
            g = QgsGeometry(f.geometry())
            g.transform(tr_in)
            geoms.append(g)
        vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "Fascia di rispetto RFI", "memory")
        if geoms:
            buff = QgsGeometry.unaryUnion(geoms).buffer(fascia_m, 8)
            buff.transform(tr_out)
            f = QgsFeature()
            f.setGeometry(buff)
            vl.dataProvider().addFeatures([f])
            vl.updateExtents()
        self._rfi_stile_fascia(vl)
        self._rfi_sostituisci_layer("Fascia di rispetto RFI", vl)
        return vl

    # ------------------------------------------------------------ stili
    def _rfi_stile_fascia(self, vl):
        sym = QgsFillSymbol.createSimple({
            "color": "255,80,80,30", "outline_color": "0,140,60,255",
            "outline_width": "0.5", "outline_style": "dash"})
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        vl.triggerRepaint()

    def _rfi_stile_ferrovia(self, vl):
        sym = QgsLineSymbol()
        sym.deleteSymbolLayer(0)
        base = QgsSimpleLineSymbolLayer(QColor(0, 0, 0))
        base.setWidth(1.0)
        sym.appendSymbolLayer(base)
        trav = QgsSimpleLineSymbolLayer(QColor(255, 255, 255))
        trav.setWidth(0.8)
        trav.setPenStyle(Qt.CustomDashLine)
        trav.setCustomDashVector([3, 3])
        trav.setUseCustomDashPattern(True)
        sym.appendSymbolLayer(trav)
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        vl.triggerRepaint()

    def _rfi_stile_cippi(self, vl):
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "255,215,0,255", "outline_color": "0,0,0,255",
            "outline_width": "0.4", "size": "2.6"})))
        self._rfi_etichetta(vl, "km", 8)

    def _rfi_etichetta(self, vl, campo, dim, espressione=False, colore=QColor(0, 0, 0)):
        pal = QgsPalLayerSettings()
        pal.fieldName = campo
        pal.isExpression = espressione
        tf = QgsTextFormat()
        fnt = QFont("Arial", dim)
        fnt.setBold(True)
        tf.setFont(fnt)
        tf.setSize(dim)
        tf.setColor(colore)
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(1.0)
        buf.setColor(QColor(255, 255, 255))
        tf.setBuffer(buf)
        pal.setFormat(tf)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
        vl.triggerRepaint()

    def _rfi_gruppo(self):
        """Gruppo «RFI - Ferrovie» in cima alla legenda (creato se manca)."""
        root = self.project.layerTreeRoot()
        g = root.findGroup(GRUPPO_RFI)
        if g is None:
            g = root.insertGroup(0, GRUPPO_RFI)
        return g

    def _rfi_ordina_layer(self):
        """I layer della scheda RFI vanno nel loro gruppo, sempre nello stesso
        ordine (interferenze sopra, fascia sotto)."""
        root = self.project.layerTreeRoot()
        gruppo = self._rfi_gruppo()
        for nome in reversed(LAYER_RFI):
            lid = self._rfi_layer_id(nome)
            nodo = root.findLayer(lid) if lid else None
            if nodo is None:
                continue
            clone = nodo.clone()
            parent = nodo.parent()
            gruppo.insertChildNode(0, clone)
            parent.removeChildNode(nodo)

    def _rfi_salva_layer(self):
        """Rende permanenti i layer RFI: un GeoPackage nella cartella scelta,
        un layer per ciascuno con lo stile incorporato (stile predefinito nel
        GeoPackage), poi nel progetto i layer temporanei sono sostituiti da
        quelli salvati, nello stesso gruppo."""
        from qgis.core import QgsVectorFileWriter, QgsSettings
        presenti = [(n, self.project.mapLayer(self._rfi_layer_id(n)))
                    for n in LAYER_RFI if self._rfi_layer_id(n)]
        if not presenti:
            QMessageBox.information(self, "Layer RFI", "Nessun layer RFI da salvare: "
                                    "scarica prima ferrovie, cippi e stazioni.")
            return
        partenza = QgsSettings().value("ftth_permessi/rfi_cartella_layer", "") or \
            os.path.join(self.project.homePath() or "", "01_File shp")
        cart = QFileDialog.getExistingDirectory(self, "Cartella dove salvare i layer RFI", partenza)
        if not cart:
            return
        QgsSettings().setValue("ftth_permessi/rfi_cartella_layer", cart)
        comune = (self.txt_rfi_comune.text().strip() or "progetto").replace(" ", "_")
        gpkg = os.path.join(cart, "Layer_RFI_%s.gpkg" % comune)
        esiti, primo = [], True
        root = self.project.layerTreeRoot()
        for nome, lyr in presenti:
            if lyr is None:
                continue
            if lyr.providerType() != "memory" and \
                    os.path.normcase(lyr.source().split("|")[0]) == os.path.normcase(gpkg):
                esiti.append("%s: già salvato" % nome)
                continue
            opz = QgsVectorFileWriter.SaveVectorOptions()
            opz.driverName = "GPKG"
            opz.layerName = nome
            opz.fileEncoding = "UTF-8"
            opz.actionOnExistingFile = (QgsVectorFileWriter.CreateOrOverwriteFile if primo
                                        else QgsVectorFileWriter.CreateOrOverwriteLayer)
            err = QgsVectorFileWriter.writeAsVectorFormatV3(
                lyr, gpkg, self.project.transformContext(), opz)
            if (err[0] if isinstance(err, tuple) else err) != QgsVectorFileWriter.NoError:
                esiti.append("%s: NON salvato (%s)" % (nome, err[1] if isinstance(err, tuple) else err))
                continue
            primo = False
            nuovo = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
            if not nuovo.isValid():
                esiti.append("%s: scritto ma non ricaricato" % nome)
                continue
            # stile identico a quello attuale, incorporato nel GeoPackage
            nuovo.setRenderer(lyr.renderer().clone())
            if lyr.labeling() is not None:
                nuovo.setLabeling(lyr.labeling().clone())
            nuovo.setLabelsEnabled(lyr.labelsEnabled())
            nuovo.setOpacity(lyr.opacity())
            nuovo.saveStyleToDatabase(nome, "Stile %s (FTTH Permessi Manager)" % nome, True, "")
            # stesso posto nel gruppo
            nodo = root.findLayer(lyr.id())
            parent = nodo.parent() if nodo is not None else self._rfi_gruppo()
            pos = parent.children().index(nodo) if nodo is not None else 0
            self.project.addMapLayer(nuovo, False)
            parent.insertLayer(pos, nuovo)
            self.project.removeMapLayer(lyr.id())
            esiti.append("%s: salvato" % nome)
        testo = "GeoPackage: %s\n\n%s\n\nGli stili sono incorporati nel file: aprendolo in " \
                "un altro progetto i layer si vedono già così.\nRicorda di salvare il " \
                "progetto." % (gpkg, "\n".join(esiti))
        self._log_rfi(testo)
        QMessageBox.information(self, "Layer RFI salvati", testo)

    def _rfi_layer_id(self, nome):
        for l in self.project.mapLayers().values():
            if l.name() == nome:
                return l.id()
        return None

    def _rfi_sostituisci_layer(self, nome, nuovo):
        for l in list(self.project.mapLayers().values()):
            if l.name() == nome:
                self.project.removeMapLayer(l.id())
        # direttamente nel gruppo RFI (poi _rfi_ordina_layer sistema l'ordine)
        self.project.addMapLayer(nuovo, False)
        self._rfi_gruppo().addLayer(nuovo)

    # ------------------------------------------------ trova interferenze
    def _rfi_wkt(self, geom, layer):
        from shapely import wkt as _wkt
        g = QgsGeometry(geom)
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        if layer.crs() != wgs:
            g.transform(QgsCoordinateTransform(layer.crs(), wgs, self.project))
        return _wkt.loads(g.asWkt(8))

    @staticmethod
    def _rfi_val(feat, campo):
        if not campo:
            return ""
        v = feat[campo]
        if v is None:
            return ""
        try:
            if v.isNull():
                return ""
        except AttributeError:
            pass
        return str(v).strip()

    @staticmethod
    def _rfi_campo(layer, *cand):
        nomi = {f.name().lower(): f.name() for f in layer.fields()}
        for c in cand:
            if c.lower() in nomi:
                return nomi[c.lower()]
        return None

    def _rfi_trova_interferenze(self):
        try:
            self._rfi_trova_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_rfi("ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore", "Ricerca interferenze non riuscita:\n%s" % e)

    def _rfi_trova_impl(self):
        from shapely.geometry import LineString, Point
        rfi = _rfi_mod()
        st = self._rfi_state()
        lay_f = self._find_layer("Ferrovia RFI")
        if lay_f is None or lay_f.featureCount() == 0:
            QMessageBox.warning(self, "Ferrovie mancanti",
                                "Prima premi «Scarica ferrovie, cippi e stazioni (OSM)».")
            return
        lyr_infra = self._find_layer("03 INFRASTRUTTURE")
        if lyr_infra is None:
            QMessageBox.warning(self, "Layer mancante", "Manca '03 INFRASTRUTTURE' nel progetto.")
            return
        # linee ferroviarie con i tag
        linee = []
        for f in lay_f.getFeatures():
            g = self._rfi_wkt(f.geometry(), lay_f)
            tags = {"name": self._rfi_val(f, "nome") if "nome" in f.fields().names() else "",
                    "ref": self._rfi_val(f, "ref") if "ref" in f.fields().names() else "",
                    "operator": self._rfi_val(f, "operator") if "operator" in f.fields().names() else ""}
            for parte in getattr(g, "geoms", [g]):
                if isinstance(parte, LineString):
                    linee.append({"geom": parte, "tags": tags})
        # tratte
        c_stato = self._rfi_campo(lyr_infra, "STATO")
        c_tipo = self._rfi_campo(lyr_infra, "TIPOLOGIA")
        c_prop = self._rfi_campo(lyr_infra, "PROPRIETA", "PROPRIETAR", "PROPRIETARIO",
                                 "PROPR", "GESTORE", "ENTE", "OWNER")
        c_lung = self._rfi_campo(lyr_infra, "LUNGHEZZA", "Lungh")
        tratte = []
        for f in lyr_infra.getFeatures():
            if not f.hasGeometry():
                continue
            try:
                lung = float(self._rfi_val(f, c_lung).replace(",", ".")) if c_lung else None
            except ValueError:
                lung = None
            tratte.append({"geom": self._rfi_wkt(f.geometry(), lyr_infra),
                           "stato": self._rfi_val(f, c_stato) or "Nuovo",
                           "tecnica": rfi.mappa_tecnica(self._rfi_val(f, c_tipo)),
                           "proprietario": self._rfi_val(f, c_prop),
                           "fid": f.id(), "lunghezza": lung if lung and lung > 0 else None})
        armadi = []
        lyr_arm = self._find_layer("01_ARMADIO OTTICO")
        if lyr_arm is not None and lyr_arm.isValid():
            c_ida = self._rfi_campo(lyr_arm, "ID_ARMADIO", "ID_ARMAD")
            c_sta = self._rfi_campo(lyr_arm, "STATO")
            for f in lyr_arm.getFeatures():
                if not f.hasGeometry():
                    continue
                g = self._rfi_wkt(f.geometry(), lyr_arm)
                armadi.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                               "stato": self._rfi_val(f, c_sta), "id": self._rfi_val(f, c_ida),
                               "fid": f.id()})
        pozzetti = []
        lyr_poz = self._find_layer("02_POZZETTO")
        if lyr_poz is not None:
            c_dim = self._rfi_campo(lyr_poz, "TIPO_POZZE", "TIPO_POZZETTO", "DIMENSIONE")
            c_sp = self._rfi_campo(lyr_poz, "STATO")
            for f in lyr_poz.getFeatures():
                if not f.hasGeometry():
                    continue
                g = self._rfi_wkt(f.geometry(), lyr_poz)
                pozzetti.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                                 "stato": self._rfi_val(f, c_sp),
                                 "dim": rfi.norm_pozzetto(self._rfi_val(f, c_dim)),
                                 "fid": f.id()})
        stazioni = [{"nome": s["nome"], "geom": Point(s["lon"], s["lat"])}
                    for s in st.get("stazioni") or []]
        cippi = self._rfi_cippi_progetto()
        if cippi:
            self._log_rfi("Km stimati dai cippi del layer '%s' (%d cippi)."
                          % (self.cb_rfi_cippi.currentLayer().name(), len(cippi)))
        else:
            cippi = st.get("cippi") or []
            if not cippi:
                self._log_rfi("Nessun cippo km (né OSM né layer di progetto): i km restano "
                              "da compilare in tabella.")
        kb = _kb()
        interf = rfi.trova_interferenze(linee, tratte, pozzetti, cippi,
                                        stazioni, kb, fascia_m=self.spin_rfi_fascia.value(),
                                        armadi=armadi)
        st["interferenze"] = interf
        # gestori trovati
        gestori = {}
        for l in linee:
            g = rfi.riconosci_gestore(l["tags"].get("operator"), l["tags"].get("name"), kb)
            gestori.setdefault(g.chiave, g)
        st["gestori"] = gestori
        self._rfi_riempi_tabella(interf, gestori)
        self._rfi_riempi_destinatari(gestori)
        if self.cb_rfi_doit.count() == 0:
            self._rfi_riempi_doit()
        self._rfi_layer_interferenze(interf)
        n = {}
        for i in interf:
            n[i.tipologia] = n.get(i.tipologia, 0) + 1
        self._log_rfi("Interferenze trovate: %d (%s)" % (
            len(interf), ", ".join("%s: %d" % (k or "—", v) for k, v in sorted(n.items(), key=str))))
        if not interf:
            QMessageBox.information(self, "Nessuna interferenza",
                                    "Nessuna tratta del progetto entra nella fascia di rispetto.")

    def _rfi_cippi_progetto(self):
        """Cippi {km, lat, lon} dal layer scelto nella scheda, o [] se non c'e'.
        Il km si legge con il parser delle chilometriche del plugin
        ('KM 29+417', '29+417', '29,417' ...)."""
        lyr = self.cb_rfi_cippi.currentLayer()
        campo = self.cb_rfi_cippi_campo.currentField()
        if lyr is None or not campo:
            return []
        try:
            from . import ftth_core as core
        except ImportError:
            import ftth_core as core
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(lyr.crs(), wgs, self.project)
        out, scartati = [], 0
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            metri = core.parse_chilometrica(self._rfi_val(f, campo))
            if metri is None:
                scartati += 1
                continue
            g = QgsGeometry(f.geometry())
            g.transform(tr)
            p = g.centroid().asPoint()
            out.append({"km": metri / 1000.0, "lat": p.y(), "lon": p.x()})
        if scartati:
            self._log_rfi("Cippi: %d valori del campo '%s' non interpretabili, scartati."
                          % (scartati, campo))
        return out

    def _rfi_riempi_tabella(self, interf, gestori):
        t = self.tab_rfi
        t.setRowCount(0)
        for i in interf:
            r = t.rowCount()
            t.insertRow(r)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked if i.includi else Qt.Unchecked)
            t.setItem(r, C_INCL, chk)
            idi = QTableWidgetItem(str(i.id))
            idi.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            idi.setData(Qt.UserRole, i.id)
            t.setItem(r, C_ID, idi)
            cb = QComboBox()
            for k in TIPI_COMBO:
                cb.addItem(DESCR_TIPO[k], k)
            cb.setCurrentIndex(TIPI_COMBO.index(i.tipologia if i.tipologia in TIPI_COMBO else "—"))
            t.setCellWidget(r, C_TIPO, cb)
            g = gestori.get(i.gestore)
            gi = QTableWidgetItem(g.nome if g else i.gestore)
            gi.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            gi.setData(Qt.UserRole, i.gestore)
            t.setItem(r, C_GEST, gi)
            t.setItem(r, C_LINEA, QTableWidgetItem(i.linea))
            t.setItem(r, C_STAZ, QTableWidgetItem(i.stazione))
            t.setItem(r, C_KMDA, QTableWidgetItem(i.km_da))
            t.setItem(r, C_KMA, QTableWidgetItem(i.km_a))
            rfi = _rfi_mod()
            metri = ", ".join("%s %s m" % (rfi.ETICH_TECNICA[k], rfi._fmt_num(v))
                              for k, v in i.metri.items() if v)
            for col, testo in ((C_METRI, metri or "—"),
                               (C_POZZ, ", ".join("%s×%d" % (d, n) for d, n in i.pozzetti.items()) or "—"),
                               (C_DIST, "attraversa" if i.attraversa else
                                ("%.1f" % i.dist_min_m if i.dist_min_m is not None else "")),
                               (C_NOTE, "; ".join(i.note))):
                it = QTableWidgetItem(testo)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if col == C_NOTE and i.note:
                    it.setForeground(QColor(170, 60, 0))
                t.setItem(r, col, it)
            t.setItem(r, C_PROPR, QTableWidgetItem(i.proprietario))
            fi = QTableWidgetItem(i.foto)
            fi.setToolTip("Doppio clic per scegliere la foto")
            t.setItem(r, C_FOTO, fi)
        t.resizeColumnsToContents()

    def _rfi_riempi_destinatari(self, gestori):
        t = self.tab_rfi_dest
        t.setRowCount(0)
        for k, g in gestori.items():
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem(g.nome)
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            it.setData(Qt.UserRole, k)
            t.setItem(r, 0, it)
            t.setItem(r, 1, QTableWidgetItem(g.dest_nome))
            t.setItem(r, 2, QTableWidgetItem(g.dest_indirizzo))
            t.setItem(r, 3, QTableWidgetItem(g.dest_pec))
        t.resizeColumnsToContents()
        self._rfi_applica_doit()

    def _rfi_layer_interferenze(self, interf):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Interferenze ferroviarie", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("id", QVariant.Int), QgsField("tipologia", QVariant.String),
                          QgsField("km", QVariant.String), QgsField("etichetta", QVariant.String)])
        vl.updateFields()
        feats = []
        rfi = _rfi_mod()
        for i in interf:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat)))
            f["id"] = i.id
            f["tipologia"] = i.tipologia or "—"
            f["km"] = rfi.etichetta_km(i.km_da, i.km_a)
            f["etichetta"] = "#%d tipo %s" % (i.id, i.tipologia or "—")
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "circle", "color": "255,60,60,110", "outline_color": "200,0,0,255",
             "size": "7"})))
        self._rfi_etichetta(vl, "etichetta", 8, colore=QColor(180, 0, 0))
        self._rfi_sostituisci_layer("Interferenze ferroviarie", vl)
        self._rfi_ordina_layer()

    def _rfi_riga_interferenza(self, r):
        rfi = _rfi_mod()
        iid = self.tab_rfi.item(r, C_ID).data(Qt.UserRole)
        return next((i for i in self._rfi_state()["interferenze"] if i.id == iid), None), rfi

    def _rfi_zoom_riga(self):
        righe = self.tab_rfi.selectionModel().selectedRows() if self.tab_rfi.selectionModel() else []
        if not righe:
            return
        i, _ = self._rfi_riga_interferenza(righe[0].row())
        if i is None:
            return
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        d = 0.0012
        rect = QgsRectangle(i.lon - d, i.lat - d, i.lon + d, i.lat + d)
        tr = QgsCoordinateTransform(wgs, self.iface.mapCanvas().mapSettings().destinationCrs(),
                                    self.project)
        self.iface.mapCanvas().setExtent(tr.transformBoundingBox(rect))
        self.iface.mapCanvas().refresh()

    def _rfi_doppio_clic(self, r, c):
        if c != C_FOTO:
            return
        p, _ = QFileDialog.getOpenFileName(self, "Foto per la tavola", "",
                                           "Immagini (*.jpg *.jpeg *.png)")
        if p:
            self.tab_rfi.setItem(r, C_FOTO, QTableWidgetItem(p))

    def _rfi_leggi_tabella(self):
        """Riporta nelle interferenze le correzioni fatte in tabella."""
        st = self._rfi_state()
        for r in range(self.tab_rfi.rowCount()):
            i, _ = self._rfi_riga_interferenza(r)
            if i is None:
                continue
            i.includi = self.tab_rfi.item(r, C_INCL).checkState() == Qt.Checked
            tip = self.tab_rfi.cellWidget(r, C_TIPO).currentData()
            i.tipologia = None if tip == "—" else tip
            txt = lambda c: (self.tab_rfi.item(r, c).text().strip() if self.tab_rfi.item(r, c) else "")
            i.linea = txt(C_LINEA) or i.linea
            i.stazione = txt(C_STAZ)
            i.km_da = txt(C_KMDA)
            i.km_a = txt(C_KMA)
            i.proprietario = txt(C_PROPR)
            i.foto = txt(C_FOTO)
        return st["interferenze"]

    def _rfi_leggi_destinatari(self):
        rfi = _rfi_mod()
        gestori = dict(self._rfi_state().get("gestori") or {})
        for r in range(self.tab_rfi_dest.rowCount()):
            k = self.tab_rfi_dest.item(r, 0).data(Qt.UserRole)
            g = gestori.get(k) or rfi.Gestore(chiave=k, nome=k, sigla=k.upper())
            txt = lambda c: (self.tab_rfi_dest.item(r, c).text().strip()
                             if self.tab_rfi_dest.item(r, c) else "")
            g.dest_nome, g.dest_indirizzo, g.dest_pec = txt(1), txt(2), txt(3)
            gestori[k] = g
        return gestori

    # ------------------------------------------------------------ genera
    def _rfi_aggiorna_orto(self):
        self.cb_rfi_orto.clear()
        self.cb_rfi_orto.addItem("automatico (ortofoto del progetto o Esri World Imagery)", None)
        try:
            from qgis.core import QgsRasterLayer
            for l in self.project.mapLayers().values():
                if isinstance(l, QgsRasterLayer):
                    self.cb_rfi_orto.addItem(l.name(), l.id())
        except Exception:  # noqa: BLE001
            pass

    def _rfi_cartella_template(self):
        qui = os.path.dirname(os.path.abspath(__file__))
        c = os.path.join(qui, "modelli_rfi")
        return c if os.path.isfile(os.path.join(c, "TEMPLATE_1.0_art.49.docx")) else None

    def _rfi_genera(self):
        try:
            self._rfi_genera_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_rfi("ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore generazione", str(e))

    def _rfi_genera_impl(self):
        rfi = _rfi_mod()
        try:
            import docx  # noqa: F401
        except ImportError:
            QMessageBox.critical(
                self, "Manca python-docx",
                "Serve il modulo 'python-docx'. Dalla console Python di QGIS:\n"
                "  import pip; pip.main(['install','python-docx'])")
            return
        comune = self.txt_rfi_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante", "Inserisci il comune.")
            return
        if not self._rfi_state()["interferenze"]:
            QMessageBox.warning(self, "Nessuna interferenza",
                                "Prima premi «Trova interferenze nel tracciato».")
            return
        tpl = self._rfi_cartella_template()
        if tpl is None:
            QMessageBox.critical(self, "Modelli mancanti", "Non trovo i modelli in <plugin>/modelli_rfi.")
            return
        interf = self._rfi_leggi_tabella()
        gestori = self._rfi_leggi_destinatari()
        istanze = rfi.raggruppa_istanze(interf, gestori, comune)
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza",
                                "Nessuna riga inclusa con tipologia A, B, C o D.")
            return
        dati = rfi.DatiComune(comune, self.txt_rfi_prov.text().strip(), self.txt_rfi_cap.text().strip(),
                              self.txt_rfi_indirizzo.text().strip(), self.txt_rfi_comune_pec.text().strip())
        radice = os.path.join(self.project.homePath() or os.path.expanduser("~"),
                              "Istanze RFI", comune.upper())
        os.makedirs(radice, exist_ok=True)
        self._rfi_state()["cartella"] = radice
        self._log_rfi("")
        self._log_rfi("Istanze da generare: %d" % len(istanze))
        try:
            from qgis.PyQt.QtWidgets import QApplication
        except ImportError:
            QApplication = None
        layout_mod = None
        if self.chk_rfi_pl.isChecked():
            try:
                try:
                    from . import ftth_rfi_layout as layout_mod
                except ImportError:
                    import ftth_rfi_layout as layout_mod
            except Exception as e:  # noqa: BLE001
                self._log_rfi("Planimetria non disponibile: %s" % e)
        riepilogo = []
        for ist in istanze:
            cart = os.path.join(radice, "%02d_%s" % (ist.numero, ist.nome_base))
            self._log_rfi("— %s (%d interferenze)" % (ist.nome_base, len(ist.interferenze)))
            if QApplication:
                QApplication.processEvents()
            prod = rfi.genera_documenti_istanza(ist, dati, tpl, cart, rese=self._rfi_rese())
            da_pdf = [prod["rt"]] + ([prod[k] for k in ("art49", "bollo", "modb")]
                                    if self.chk_rfi_pdf_tutti.isChecked() else [])
            pdf = rfi.converti_pdf([p for p in da_pdf if p])
            if not pdf.get(prod["rt"]):
                self._log_rfi("   PDF non creato: serve Microsoft Word o LibreOffice.")
            if layout_mod is not None:
                try:
                    out_pl = os.path.join(cart, rfi.NOMI_FILE["pl"].format(base=ist.nome_base))
                    avvisi_pl = []
                    ok = layout_mod.genera_pl_istanza(
                        self.project, ist, dati, out_pl,
                        orto_id=self.cb_rfi_orto.currentData(),
                        fascia_m=self.spin_rfi_fascia.value(),
                        cartella_utente=self.txt_rfi_cartella.text().strip() or None,
                        cartella_sezioni=self.txt_rfi_cart_sez.text().strip() or None,
                        cartella_foto=self.txt_rfi_cart_foto.text().strip() or None,
                        log=avvisi_pl.append)
                    for a in avvisi_pl:
                        self._log_rfi("   tavola: %s" % a)
                    self._log_rfi("   planimetria: %s" % ("OK" if ok else "NON esportata"))
                except Exception as e:  # noqa: BLE001
                    import traceback
                    self._log_rfi("   planimetria non riuscita: %s" % e)
                    self._log_rfi(traceback.format_exc())
            with open(os.path.join(cart, "LEGGIMI.txt"), "w", encoding="utf-8") as fh:
                fh.write(rfi.promemoria_istanza(ist, dati))
            riepilogo.append(ist)
        try:
            self._rfi_scrivi_excel(riepilogo, radice, comune)
        except Exception as e:  # noqa: BLE001
            self._log_rfi("Riepilogo Excel non scritto: %s" % e)
        self._log_rfi("Cartella: %s" % radice)
        incompleti = [ist.gestore.nome for ist in istanze if not ist.gestore.destinatario_completo()]
        msg = ("Generata 1 istanza in:\n%s" % radice if len(istanze) == 1
               else "Generate %d istanze in:\n%s" % (len(istanze), radice))
        if incompleti:
            msg += ("\n\nDestinatario incompleto per: %s (nei documenti resta XXXXX)."
                    % ", ".join(sorted(set(incompleti))))
        sopr = [ist.nome_base for ist in istanze if rfi.TIPOLOGIE[ist.tipologia]["sopralluogo"]]
        if sopr:
            msg += ("\n\nTipologie B/C: prima della PEC serve il sopralluogo congiunto "
                    "con il gestore (%s)." % ", ".join(sopr))
        QMessageBox.information(self, "Istanze generate", msg)

    def _rfi_apri_cartella(self):
        c = self._rfi_state().get("cartella")
        if c and os.path.isdir(c):
            os.startfile(c)
        else:
            QMessageBox.information(self, "Cartella", "Genera prima le istanze.")

    def _rfi_scrivi_excel(self, istanze, radice, comune):
        """Riepilogo di tutte le istanze del comune, una riga per interferenza."""
        try:
            import openpyxl
            from openpyxl.styles import Font
        except ImportError:
            self._log_rfi("openpyxl non disponibile: niente riepilogo Excel.")
            return
        rfi = _rfi_mod()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Istanze"
        ws.append(["Istanza", "Tipologia", "Gestore", "Destinatario", "PEC", "Linea", "Stazione",
                   "Interferenza", "Km", "Microtrincea", "No Dig", "Trincea", "Minitrincea",
                   "Pozzetti", "Note"])
        for c in ws[1]:
            c.font = Font(bold=True)
        for ist in istanze:
            for i in ist.interferenze:
                ws.append([ist.nome_base, ist.tipologia, ist.gestore.nome, ist.gestore.dest_nome,
                           ist.gestore.dest_pec, ist.linea, ist.stazione, i.id,
                           rfi.etichetta_km(i.km_da, i.km_a),
                           i.metri.get("microtrincea", 0), i.metri.get("nodig", 0),
                           i.metri.get("trincea", 0), i.metri.get("minitrincea", 0),
                           ", ".join("%s x%d" % (d, n) for d, n in i.pozzetti.items()),
                           "; ".join(i.note)])
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = min(
                60, max(10, max(len(str(c.value or "")) for c in col) + 2))
        path = os.path.join(radice, "%s_Riepilogo_istanze_ferroviarie.xlsx" % comune.upper())
        wb.save(path)
        self._log_rfi("Riepilogo: %s" % os.path.basename(path))
