# -*- coding: utf-8 -*-
"""
ftth_rfi_ui.py — Scheda "Istanze RFI" del plugin FTTH Permessi Manager.

Mixin (RFIMixin) agganciato a FTTHPermessiDialog: qui solo il collante QGIS e
l'interfaccia; la logica (tipologie, raggruppamento, documenti) sta in
ftth_rfi.py e le tavole in ftth_rfi_layout.py. (c) Beexact S.r.l.

Flusso della scheda:
  1) Comune (provincia, CAP e DOIT si compilano da soli)
  2) "Trova le ferrovie e gli enti" -> layer Ferrovia/Cippi/Stazioni + Fascia
     di rispetto (30 m) e tabella delle linee con gestore e destinatario
     (spunta, Mostra in mappa, zoom, Altre fonti da un layer del progetto)
  3) "Trova le interferenze" (solo linee spuntate) -> tabella: una riga per
     interferenza con la tipologia proposta (A/B/C/D), km, metri, pozzetti,
     stazione. Si conferma o si corregge tutto lì.
  4) Progressive per linea: cippi OSM, layer del progetto o nessuno
  5) Destinatari per gestore (RFI DOIT, FS Sud Est, FER, ...)
  6) "Genera istanze" -> una cartella per istanza (tipologia x gestore x linea
     x stazione) con art.49, RT+CR (Word+PDF), Bollo, Modello B, planimetria
     PL in PDF e LEGGIMI con i promemoria.
"""
import json
import os
import urllib.parse
import urllib.request

from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFormLayout,
    QHBoxLayout, QHeaderView, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
    QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsFillSymbol, QgsGeometry, QgsLineSymbol, QgsMarkerSymbol,
    QgsPalLayerSettings, QgsPointXY, QgsRectangle, QgsSimpleLineSymbolLayer,
    QgsSingleSymbolRenderer, QgsTextBufferSettings, QgsTextFormat,
    QgsVectorLayer, QgsVectorLayerSimpleLabeling,
)

OVERPASS_MIRRORS = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
    "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
]

TIPI_COMBO = ["A", "B", "C", "D", "?", "—"]     # "—" = nessuna istanza
# layer creati dalla scheda: tutti nel gruppo GRUPPO_RFI, in quest'ordine
GRUPPO_RFI = "RFI - Ferrovie"
LAYER_RFI = ["Interferenze ferroviarie", "Cippi km RFI", "Stazioni ferroviarie",
             "Ferrovia RFI", "Fascia di rispetto RFI"]
DESCR_TIPO = {
    "A": "A — attraversamento con riutilizzo esistente",
    "B": "B — attraversamento in sottovia/sopra galleria",
    "C": "C — attraversamento No Dig",
    "D": "D — parallelismo in fascia 6-30 m",
    "?": "? — da decidere",
    "—": "— nessuna istanza",
}
# colonne della tabella interferenze
C_INCL, C_ID, C_TIPO, C_GEST, C_LINEA, C_STAZ, C_KMDA, C_KMA, C_METRI, C_POZZ, C_DIST, C_PROPR, C_FOTO, C_NOTE = range(14)
INTESTAZIONI = ["Incl.", "N.", "Tipologia", "Gestore", "Linea (nei documenti)", "Stazione",
                "Km da", "Km a", "Metri", "Pozzetti", "Dist. (m)", "Proprietario (tipo A)",
                "Foto (tavola)", "Note"]
# tabella delle linee (punto 2) e delle progressive per linea (punto 4)
INTEST_LINEE = ["Incl.", "Linea", "Gestore", "Destinatario", "Rete in fascia (m)",
                "Distanza minima (m)", "Fonte", "Valida"]
COL_VALIDA = 7          # Conferma / Escludi, mostrata subito dopo la spunta
INTEST_KM = ["Linea", "Interferenze", "Da dove prendo il km", "Layer cippi", "Campo km",
             "Cippi usati", "Risultato"]
MODI_KM = (("automatico (consigliato)", ""), ("cippi di OpenStreetMap", "osm"),
           ("un layer cippi del progetto", "layer"),
           ("nessun cippo: solo coordinate", "nessuno"))


def _rfi_mod():
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    return rfi


def _kb():
    try:
        try:
            from . import ftth_screening as scr
        except ImportError:
            import ftth_screening as scr
        return scr.carica_kb()
    except Exception:  # noqa: BLE001
        import yaml
        qui = os.path.dirname(os.path.abspath(__file__))
        with open(os.path.join(qui, "procedimenti.yaml"), encoding="utf-8") as fh:
            return yaml.safe_load(fh)


class _RicercaInterrottaRFI(BaseException):
    """Pulsante «Interrompi» dello scaricamento OSM: BaseException apposta, cosi'
    gli `except Exception` lungo la strada non la confondono con un errore."""


class RFIMixin:
    """Metodi della scheda Istanze RFI. Mescolato in FTTHPermessiDialog."""

    # ------------------------------------------------------------------ UI
    def _tab_rfi(self):
        w = QWidget()
        v = QVBoxLayout(w)
        from . import ftth_passi as _P
        v.addWidget(_P.intro(
            self, "rfi",
            "Istanze art. 49 per le linee ferroviarie (RFI e gestori in concessione): una "
            "istanza per tipologia A/B/C/D, gestore, linea e stazione. I km stimati vanno "
            "sempre verificati."))
        try:
            from . import ftth_leggimi as _LG
            v.addWidget(_LG.riga(self, "rfi"))
        except Exception:  # noqa: BLE001
            pass

        # 1) comune
        gb1 = self._gruppo(_P.titolo(1, "rfi"), compresso=False)
        f1 = QFormLayout(gb1)
        self.txt_rfi_comune = QLineEdit(); self.txt_rfi_comune.setPlaceholderText("es. ANDRANO")
        self.txt_rfi_comune.setToolTip("Scritto il comune (Invio o cambio campo) provincia, CAP "
                                       "e DOIT RFI si compilano da soli.")
        self.txt_rfi_comune.editingFinished.connect(self._rfi_auto_comune)
        try:                                    # suggerimento comuni ISTAT
            from . import ftth_comuni as _COM
            _COM.aggiungi_suggerimenti(self.txt_rfi_comune, maiuscolo=True)
        except Exception:
            pass
        # stesso riquadro di Soprintendenza, Parchi e Strade: comune, Prov. e
        # CAP su una riga, poi indirizzo e PEC del Comune
        self.txt_rfi_prov = QLineEdit(); self.txt_rfi_prov.setMaximumWidth(60)
        self.txt_rfi_cap = QLineEdit(); self.txt_rfi_cap.setMaximumWidth(80)
        r1 = QHBoxLayout()
        r1.addWidget(self.txt_rfi_comune)
        r1.addWidget(QLabel("Prov."))
        r1.addWidget(self.txt_rfi_prov)
        r1.addWidget(QLabel("CAP"))
        r1.addWidget(self.txt_rfi_cap)
        f1.addRow("Comune:", r1)
        # indirizzo e PEC del Comune in e.p.c.: al passo 4, come in tutte le schede
        self.txt_rfi_indirizzo = QLineEdit()
        self.txt_rfi_comune_pec = QLineEdit()
        self.btn_rfi_precompila = QPushButton("Precompila dallo screening territorio")
        self.btn_rfi_precompila.setToolTip(
            "Risolve il comune (CAP, provincia, regione) e la DOIT RFI competente per "
            "la regione. Non tocca i campi già compilati.")
        self.btn_rfi_precompila.clicked.connect(self._rfi_precompila_da_screening)
        # non più nella scheda: scrivere il comune fa già lo stesso (provincia,
        # CAP, regione e DOIT), come in tutte le altre schede istanze
        self.btn_rfi_precompila.setVisible(False)
        v.addWidget(gb1)

        # 2) ferrovie ed enti
        gb2 = self._gruppo(_P.titolo(2, "rfi"), compresso=False)
        v2 = QVBoxLayout(gb2)
        f2 = QFormLayout()          # fascia e margine: nelle avanzate, in fondo al passo
        self.spin_rfi_fascia = self._dspin(1, 200, 30, 0, " m")
        self.spin_rfi_fascia.setToolTip("Fascia di rispetto ferroviaria (art. 49 DPR 753/1980): 30 m.")
        f2.addRow("Fascia di rispetto:", self.spin_rfi_fascia)
        self.spin_rfi_margine = self._dspin(0, 10, 1.0, 1, " m", step=0.5)
        self.spin_rfi_margine.setToolTip(
            "6 e 30 m si misurano dal limite della zona di occupazione della rotaia più "
            "vicina, non dall'asse del binario (la linea OSM). Il margine si somma alle "
            "distanze, così gli elementi al bordo vengono segnalati per prudenza. 0 = "
            "dall'asse.")
        f2.addRow("Margine asse binario → limite ferrovia:", self.spin_rfi_margine)
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox
        self.btn_rfi_osm = _P.primario(_P.TROVA["rfi"])
        self.btn_rfi_osm.setToolTip(
            "Scarica da OSM ferrovie, cippi km e stazioni attorno al progetto, riconosce il "
            "gestore di ogni linea (RFI, FS Sud Est, FER …) e propone le linee con rete "
            "nella fascia di rispetto.")
        self.btn_rfi_osm.clicked.connect(self._rfi_scarica_osm)
        riga_osm = QHBoxLayout()
        riga_osm.addWidget(self.btn_rfi_osm)
        try:
            try:
                from .ftth_barra import BarraAvanzamento
            except ImportError:
                from ftth_barra import BarraAvanzamento
            self.bar_rfi_osm = BarraAvanzamento(larghezza_min=260)
            riga_osm.addWidget(self.bar_rfi_osm, 1)
        except Exception:  # noqa: BLE001
            self.bar_rfi_osm = None
        self.btn_rfi_stop = QPushButton("Interrompi")
        self.btn_rfi_stop.setToolTip("Ferma lo scaricamento se i server OSM non rispondono.")
        self.btn_rfi_stop.clicked.connect(self._rfi_interrompi)
        self.btn_rfi_stop.setVisible(False)
        riga_osm.addWidget(self.btn_rfi_stop)
        riga_osm.addStretch()
        # «Riscarica da OSM» e «Salva i layer della scheda…»: nelle avanzate,
        # come in tutte le schede (accanto a Trova solo barra e Interrompi)
        riga_extra = QHBoxLayout()
        b_risc = QPushButton("Riscarica da OSM")
        b_risc.setToolTip("Rifà la ricerca chiedendo di nuovo i dati a OpenStreetMap, senza la "
                          "cache dei 30 giorni.")

        def _riscarica():
            self._rfi_senza_cache = True
            try:
                self._rfi_scarica_osm()
            finally:
                self._rfi_senza_cache = False
        b_risc.clicked.connect(_riscarica)
        riga_extra.addWidget(b_risc)
        b_salva_rfi = QPushButton("Salva i layer della scheda…")
        b_salva_rfi.setToolTip(
            "Rende permanenti i layer del gruppo «%s» (ferrovia, fascia, cippi, stazioni, "
            "interferenze): un GeoPackage nella cartella che scegli, con gli stili incorporati. "
            "Nel progetto i layer temporanei vengono sostituiti da quelli salvati." % GRUPPO_RFI)
        b_salva_rfi.clicked.connect(self._rfi_salva_layer)
        riga_extra.addWidget(b_salva_rfi)
        riga_extra.addStretch()
        v2.addLayout(riga_osm)
        from . import ftth_trovati as _TR
        self.tab_rfi_lin = QTableWidget(0, len(INTEST_LINEE))
        self.tab_rfi_lin.setHorizontalHeaderLabels(INTEST_LINEE)
        self.tab_rfi_lin.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tab_rfi_lin.setMinimumHeight(110)
        self.tab_rfi_lin.horizontalHeader().setStretchLastSection(True)
        self.tab_rfi_lin.setToolTip("Gialle = proposte (rete in fascia), non spuntate: per ognuna "
                                    "«Conferma» o «Escludi». Verdi = confermate. Doppio clic: "
                                    "zoom sulla linea.")
        self.tab_rfi_lin.horizontalHeader().moveSection(COL_VALIDA, 1)
        self.tab_rfi_lin.itemChanged.connect(
            lambda it: it.column() == 0 and self._rfi_valida_riga(it.row()))
        self.tab_rfi_lin.cellDoubleClicked.connect(self._rfi_zoom_linea)
        v2.addWidget(self.tab_rfi_lin)
        v2.addLayout(_TR.riga_pulsanti(
            self.tab_rfi_lin, 0, "le linee",
            proposti=lambda r: (self.tab_rfi_lin.item(r, 0).data(Qt.UserRole + 1) or 0) > 0,
            mostra=self._rfi_mostra_linee))
        v2.addWidget(_P.proposte(self))
        # tracciato OSM sbagliato: stesso riquadro di Strade e Acque
        from . import ftth_tracciati as _TRC
        v2.addWidget(_TRC.riquadro(self, "una ferrovia", self._rfi_correggi_tracciato,
                                   self._rfi_usa_tracciati))
        # avanzate: fascia e linee da un layer del progetto (dove OSM manca o sbaglia)
        gb_alt = self._gruppo("Avanzate: fascia di rispetto, altre fonti e salvataggio dei layer",
                              compresso=True)
        v_alt = QVBoxLayout(gb_alt)
        v_alt.addLayout(riga_extra)
        v_alt.addLayout(f2)
        f_alt = QFormLayout()
        v_alt.addLayout(f_alt)
        self.cb_rfi_alt = self._lcombo(QgsMapLayerProxyModel.LineLayer, allow_empty=True)
        self.cb_rfi_alt.setLayer(None)
        self.cb_rfi_alt.setToolTip("Layer di linee con le ferrovie (es. fornito dal gestore). "
                                   "Si leggono solo i tratti attorno al progetto.")
        f_alt.addRow("Layer delle ferrovie:", self.cb_rfi_alt)
        self.cb_rfi_alt_nome = QgsFieldComboBox()
        self.cb_rfi_alt_nome.setAllowEmptyFieldName(True)
        self.cb_rfi_alt.layerChanged.connect(self.cb_rfi_alt_nome.setLayer)
        f_alt.addRow("Campo nome della linea:", self.cb_rfi_alt_nome)
        self.cb_rfi_alt_gest = QgsFieldComboBox()
        self.cb_rfi_alt_gest.setAllowEmptyFieldName(True)
        self.cb_rfi_alt.layerChanged.connect(self.cb_rfi_alt_gest.setLayer)
        f_alt.addRow("Campo gestore (facoltativo):", self.cb_rfi_alt_gest)
        for w_ in (self.cb_rfi_alt, self.cb_rfi_alt_nome, self.cb_rfi_alt_gest):
            w_.setProperty("non_memorizzare", True)
        b_alt = QPushButton("Aggiungi le linee dal layer")
        b_alt.setToolTip("Le linee del layer entrano in «Ferrovia RFI» (con la fascia "
                         "ricalcolata). Una linea con lo stesso nome di una di OSM la sostituisce.")
        b_alt.clicked.connect(self._rfi_da_layer)
        f_alt.addRow(b_alt)
        v2.addWidget(gb_alt)
        v.addWidget(gb2)

        # 3) interferenze
        gb3 = self._gruppo(_P.titolo(3, "rfi"), compresso=False)
        v3 = QVBoxLayout(gb3)
        riga3 = QHBoxLayout()
        self.btn_rfi_trova = _P.primario("Trova le interferenze")
        self.btn_rfi_trova.clicked.connect(lambda *_a: self._rfi_trova_interferenze())
        riga3.addWidget(self.btn_rfi_trova)
        # lo zoom è il doppio clic sulla riga, come in tutte le schede
        from .ftth_barra import crea_barra
        self.bar_rfi_i = crea_barra(riga3)
        v3.addLayout(riga3)
        self.tab_rfi = QTableWidget(0, len(INTESTAZIONI))
        self.tab_rfi.setHorizontalHeaderLabels(INTESTAZIONI)
        self.tab_rfi.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tab_rfi.setMinimumHeight(220)
        self.tab_rfi.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tab_rfi.horizontalHeader().setStretchLastSection(True)
        self.tab_rfi.cellDoubleClicked.connect(self._rfi_doppio_clic)
        v3.addWidget(self.tab_rfi)
        v3.addLayout(_TR.riga_pulsanti(self.tab_rfi, C_INCL, "le interferenze",
                                       mostra=self._rfi_mostra_interferenze))
        self.lbl_rfi_riepilogo = _P.nota3(
            self, "Le righe con la stessa tipologia, gestore, linea e stazione vanno nella "
            "stessa istanza; tipologia «?» o «—»: la riga non genera istanze. Doppio clic "
            "sulla colonna Foto: foto della tavola.")
        v3.addWidget(self.lbl_rfi_riepilogo)
        # conferma e vista per istanza: dentro il passo 3, come in tutte le schede
        try:
            from . import ftth_gruppi_istanze as _GR
            v3.addWidget(_GR.riquadro(self, "rfi", self._rfi_istanze_per_gruppi))
        except Exception:  # noqa: BLE001
            pass

        # chilometriche con i cippi: dentro il passo 3, come in Strade
        gb_km = self._gruppo("Chilometriche: da dove prendo il km (una riga per linea)",
                             compresso=False)
        v_km = QVBoxLayout(gb_km)
        v_km.addWidget(self._desc(
            "Il km delle interferenze si calcola dai cippi chilometrici. Per ogni linea scegli "
            "la fonte nella colonna «Da dove prendo il km»: «automatico» usa il layer cippi "
            "qui sotto se c'è, altrimenti i cippi di OpenStreetMap. Senza cippi il km resta "
            "da compilare e nei documenti l'interferenza è indicata con le coordinate. "
            "Poi premi «Calcola le chilometriche»: la colonna «Risultato» dice com'è andata."))
        f_km = QFormLayout()
        # cippi km da un layer del progetto: dove OSM non ha i cippi ferroviari
        # (es. Eboli) i km resterebbero tutti "da verificare"
        self.cb_rfi_cippi = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        self.cb_rfi_cippi.setLayer(None)
        self.cb_rfi_cippi.setToolTip(
            "Layer di punti con i cippi chilometrici (es. rilevati o forniti dal gestore). "
            "Vale per tutte le linee che nella tabella hanno «come tutte le linee»; vuoto = "
            "cippi di OSM.")
        r_cip = QHBoxLayout()
        r_cip.addWidget(self.cb_rfi_cippi, 1)
        b_crea_c = QPushButton("Crea il layer cippi")
        b_crea_c.setToolTip("Crea il layer di punti «Cippi_Ferrovia» (linea, km) accanto al "
                            "progetto: la linea si sceglie da una tendina con le linee delle "
                            "interferenze. Il layer è subito in modifica e scelto qui.")
        b_crea_c.clicked.connect(self._rfi_crea_layer_cippi)
        r_cip.addWidget(b_crea_c)
        f_km.addRow("Layer cippi del progetto (facoltativo):", r_cip)
        self.cb_rfi_cippi_campo = QgsFieldComboBox()
        self.cb_rfi_cippi.layerChanged.connect(
            lambda l: _TR.scegli_campo_km(self.cb_rfi_cippi_campo, l))
        f_km.addRow("Campo con il km (es. «29+417»):", self.cb_rfi_cippi_campo)
        v_km.addLayout(f_km)
        self.tab_rfi_km = QTableWidget(0, len(INTEST_KM))
        self.tab_rfi_km.setHorizontalHeaderLabels(INTEST_KM)
        self.tab_rfi_km.setMinimumHeight(100)
        self.tab_rfi_km.horizontalHeader().setStretchLastSection(True)
        v_km.addWidget(self.tab_rfi_km)
        r_km = QHBoxLayout()
        b_km = QPushButton("Calcola le chilometriche")
        b_km.setProperty("primario", True)
        b_km.setToolTip("Rifà la ricerca con i cippi scelti per ogni linea. Spunte, tipologie, "
                        "proprietario e foto già scelti in tabella restano.")
        b_km.clicked.connect(lambda *_a: self._rfi_trova_interferenze(bar_nome="bar_rfi_km"))
        r_km.addWidget(b_km)
        from .ftth_barra import crea_barra
        self.bar_rfi_km = crea_barra(r_km)
        v_km.addLayout(r_km)
        v3.addWidget(gb_km)
        v.addWidget(gb3)

        # 4) enti e destinatari (uno per gestore) + Comune in e.p.c.
        gb4 = self._gruppo(_P.titolo(4, "rfi"), compresso=False)
        v4 = QVBoxLayout(gb4)
        v4.addWidget(_P.nota4(self, "Un destinatario per gestore della linea; per RFI scegli "
                                    "la DOIT competente."))
        self.tab_rfi_dest = QTableWidget(0, 4)
        self.tab_rfi_dest.setHorizontalHeaderLabels(
            ["Gestore", "Destinatario (Spett.le)", "Indirizzo", "PEC"])
        self.tab_rfi_dest.horizontalHeader().setStretchLastSection(True)
        self.tab_rfi_dest.setMinimumHeight(90)
        v4.addWidget(self.tab_rfi_dest)
        f4 = QFormLayout()
        self.cb_rfi_doit = QComboBox()
        self.cb_rfi_doit.setToolTip(
            "DOIT = Direzione Operativa Infrastrutture Territoriale: l'ufficio regionale di RFI "
            "competente per la linea, a cui va indirizzata l'istanza (con la sua PEC). Il "
            "plugin la propone in base alla regione; se la linea è al confine fra due "
            "strutture scegli quella giusta.")
        self.cb_rfi_doit.currentIndexChanged.connect(self._rfi_applica_doit)
        f4.addRow("DOIT RFI:", self.cb_rfi_doit)
        _P.comune_epc(f4, self.txt_rfi_indirizzo, self.txt_rfi_comune_pec)
        v4.addLayout(f4)
        v.addWidget(gb4)

        # 5) foto, sezioni ed etichette (quello che si disegna in mappa)
        gb_f = self._gruppo(_P.titolo(5, "rfi"), compresso=False)
        v_f = QVBoxLayout(gb_f)
        v_f.addWidget(_P.nota5(self, "rfi"))
        # tavole di dettaglio a 1:1000, divise dal plugin: si calcolano prima
        # per sapere quante sezioni disegnare (una per tavola)
        r_t = QHBoxLayout()
        r_t.addWidget(QLabel("<b>Tavole:</b>"))
        b_t = QPushButton("Calcola numero di tavole (anteprima)")
        b_t.setToolTip("Divide le interferenze di ogni istanza nel minor numero di tavole, che "
                       "non si sovrappongono (scala per tavola 1:500, 1:1000 o 1:2000 se "
                       "automatica), te le mostra e disegna i riquadri in mappa (layer «Tavole PL "
                       "(riquadri) - RFI»): disegna UNA sezione dentro ogni riquadro.")
        b_t.clicked.connect(lambda *_a: self._rfi_calcola_tavole())
        r_t.addWidget(b_t)
        self.lbl_rfi_tavole = QLabel("")
        self.lbl_rfi_tavole.setWordWrap(True)
        r_t.addWidget(self.lbl_rfi_tavole, 1)
        v_f.addLayout(r_t)
        v_f.addLayout(_P.riga_fotosez(self, lambda *_a: self._rfi_prepara_foto_sezioni("rfi"),
                                      ente="rfi"))
        # quote di distanza dalla rotaia: si disegnano a mano, la misura la
        # calcola il plugin
        r_q = QHBoxLayout()
        r_q.addWidget(QLabel("<b>Quote dalla rotaia:</b>"))
        b_q = QPushButton("Disegna quote dalla rotaia")
        b_q.setToolTip("Layer «Quote dalla rotaia» in modifica con lo strumento linea: clic "
                       "sull'elemento (pozzetto, armadio, scavo), clic sulla rotaia più vicina "
                       "perpendicolare al binario, tasto destro per finire. In tavola: frecce "
                       "e distanza orizzontale al mezzo metro.")
        b_q.clicked.connect(self._rfi_disegna_quote)
        r_q.addWidget(b_q)
        r_q.addStretch()
        v_f.addLayout(r_q)
        v.addWidget(gb_f)
        # 6) stampa: opzioni dei documenti, Genera, registro
        gb5 = self._gruppo(_P.titolo(6, "rfi"), compresso=False)
        v5 = QVBoxLayout(gb5)
        gb5_av = self._gruppo("Avanzate: PDF, cartelle, rese del cronoprogramma e loghi")
        v5_av = QVBoxLayout(gb5_av)
        self.chk_rfi_pdf_tutti = QCheckBox("Converti in PDF anche art. 49, Bollo e Modello B "
                                           "(la relazione RT+CR è sempre in PDF)")
        v5_av.addWidget(self.chk_rfi_pdf_tutti)
        try:    # logo FiberCop «Milano Cortina 2026» (stessa casella in tutte le schede)
            from . import ftth_logo as _LOGO
            v5_av.addWidget(_LOGO.crea_checkbox(self))
            from . import ftth_arlo as _ARLO
            v5_av.addWidget(_ARLO.crea_checkbox(self))
        except Exception:  # noqa: BLE001
            pass
        self.chk_rfi_pl = QCheckBox("Genera la planimetria 1.1 PL (layout QGIS + PDF)")
        self.chk_rfi_pl.setChecked(True)
        f5 = QFormLayout()
        self.cb_rfi_orto = QComboBox()
        self.cb_rfi_orto.setToolTip("Layer raster per il riquadro ORTOFOTO delle tavole. "
                                    "«automatico» aggiunge Esri World Imagery se nel progetto "
                                    "non c'è un'ortofoto.")
        f5.addRow("Ortofoto per le tavole:", self.cb_rfi_orto)
        # scala unica delle tavole della PL (ortofoto, planimetria, catasto)
        self.cb_rfi_scala = _P.combo_scala("rfi_scala_tavole", "1:500, 1:1000 o 1:2000 per tavola")
        f5.addRow("Scala delle tavole PL:", self.cb_rfi_scala)
        # cartelle separate per sezioni, foto e particolari costruttivi
        # (vuote = cartelle del progetto 05_Sezioni / 04_Foto, poi il plugin)
        def _riga_cartella(chiave, segnaposto, tip):
            riga = QHBoxLayout()
            txt = QLineEdit()
            txt.setPlaceholderText(segnaposto)
            txt.setToolTip(tip)
            self.__dict__.setdefault("_cartelle_rfi", []).append((txt, chiave))
            riga.addWidget(txt)
            b = QPushButton("Sfoglia…")
            b.clicked.connect(lambda _=False, t=txt, k=chiave: self._rfi_scegli_cartella(t, k))
            riga.addWidget(b)
            return riga, txt
        r_sez, self.txt_rfi_cart_sez = _riga_cartella(
            "rfi_cartella_sezioni", "vuota = 05_Sezioni del progetto",
            "Disegni delle sezioni: SEZIONE A-A'.svg (sezione disegnata nel layer Sezioni) "
            "oppure sezione_tipo_A … sezione_tipo_D. SVG consigliato, anche PNG/JPG.")
        r_foto, self.txt_rfi_cart_foto = _riga_cartella(
            "rfi_cartella_foto", "vuota = 04_Foto del progetto",
            "Foto: FOTO-n.jpg (n = NumeroFoto del punto di ripresa) oppure foto_<numero "
            "interferenza>.")
        r_part, self.txt_rfi_cartella = _riga_cartella(
            "rfi_cartella_utente", "vuota = particolari del plugin",
            "Particolari costruttivi che sostituiscono quelli del plugin, chiamati come la "
            "chiave: sezione_minitrincea, sezione_trincea, pozzetto_76x40, tubi …")
        # chi aveva messo la cartella delle sezioni nel vecchio campo unico la
        # ritrova nel campo giusto
        vecchia = self.txt_rfi_cartella.text().strip()
        if vecchia and not self.txt_rfi_cart_sez.text().strip() and \
                "sezion" in os.path.basename(vecchia.rstrip("/\\")).lower():
            self.txt_rfi_cart_sez.setText(vecchia)
            self.txt_rfi_cartella.clear()
            _P.salva_cartella(self.project, "rfi_cartella_sezioni", vecchia)
            _P.salva_cartella(self.project, "rfi_cartella_utente", "")
        _P.collega_cartelle(self, self.__dict__.get("_cartelle_rfi", []))
        f5_av = QFormLayout()
        f5_av.addRow("Cartella sezioni:", r_sez)
        f5_av.addRow("Cartella foto:", r_foto)
        f5_av.addRow("Cartella particolari:", r_part)
        v5_av.addLayout(f5_av)
        # rese del cronoprogramma, modificabili e ricordate fra le sessioni
        v5_av.addWidget(self._rfi_box_rese())
        v5.addLayout(f5)
        v5.addWidget(self.chk_rfi_pl)
        v5.addWidget(gb5_av)
        riga5, self.btn_rfi_genera = _P.riga_genera(self._rfi_genera, self._rfi_apri_cartella,
                                                    self, "_log_rfi", etichette_in=v_f)
        v5.addLayout(riga5)
        self.log_rfi = QPlainTextEdit(); self.log_rfi.setReadOnly(True)
        self.log_rfi.setMinimumHeight(120)
        v5.addWidget(self.log_rfi)
        v.addWidget(gb5)
        v.addStretch()
        self._rfi_aggiorna_orto()
        return w

    def _rfi_scegli_cartella(self, txt=None, chiave="rfi_cartella_utente"):
        from qgis.PyQt.QtWidgets import QFileDialog as _QFD
        txt = txt or self.txt_rfi_cartella
        c = _QFD.getExistingDirectory(self, "Scegli la cartella", txt.text().strip() or "")
        if c:
            txt.setText(c)
            _P.salva_cartella(self.project, chiave, c)

    # ------------------------------------------------ rese cronoprogramma
    # (chiave in rese_complete, sottochiave o None, etichetta, unita', passo)
    VOCI_RESE = [
        ("minitrincea", None, "Scavo minitrincea", "m/giorno", 10),
        ("microtrincea", None, "Scavo microtrincea", "m/giorno", 10),
        ("canaletta", None, "Posa canaletta VTR", "m/giorno", 10),
        ("trincea", None, "Scavo tradizionale", "m/giorno", 5),
        ("nodig", None, "Perforazione no-dig", "m/giorno", 5),
        ("pozzetti", "125x80", "Posa pozzetto 125x80", "pezzi/giorno", 0.5),
        ("pozzetti", "90x70", "Posa pozzetto 90x70", "pezzi/giorno", 0.5),
        ("pozzetti", "76x40", "Posa pozzetto 76x40", "pezzi/giorno", 0.5),
        ("pozzetti", "45x15", "Posa pozzetto 45x15 / 40x15", "pezzi/giorno", 0.5),
        ("ripristino", "minitrincea", "Ripristino manto minitrincea", "m/giorno", 10),
        ("ripristino", "microtrincea", "Ripristino manto microtrincea", "m/giorno", 10),
        ("ripristino", "trincea", "Ripristino manto scavo tradizionale", "m/giorno", 10),
        ("ripristino_nodig", None, "Ripristino buche no-dig", "giorni per tratta", 0.5),
        ("ripristino_chiusini", None, "Ripristino attorno ai chiusini", "pezzi/giorno", 1),
    ]

    def _rfi_box_rese(self):
        from qgis.PyQt.QtWidgets import QDoubleSpinBox, QGroupBox, QLabel, QGridLayout
        rfi = _rfi_mod()
        gb = QGroupBox("Rese per il cronoprogramma (giorni = scavo + posa pozzetti + ripristini)")
        gb.setCheckable(True)
        gb.setChecked(False)          # chiuso: si apre spuntandolo
        gb.setToolTip("Valori di produttività della squadra. Scavo minitrincea e tradizionale "
                      "vengono dalle pratiche presentate; gli altri sono stime da tarare.\n"
                      "I valori si ricordano fra una sessione e l'altra.")
        contenuto = QWidget()
        grid = QGridLayout(contenuto)
        grid.setContentsMargins(4, 4, 4, 4)
        base = rfi.rese_complete()
        salvate = self._rfi_rese_salvate()
        self._spin_rese = {}
        for n, (k, sk, nome, unita, passo) in enumerate(self.VOCI_RESE):
            sp = QDoubleSpinBox()
            sp.setDecimals(1)
            sp.setRange(0.1, 2000)
            sp.setSingleStep(passo)
            predef = base[k][sk] if sk else base[k]
            val = (salvate.get(k, {}) or {}).get(sk) if sk else salvate.get(k)
            sp.setValue(float(val) if val else float(predef))
            sp.setToolTip("Predefinito: %s %s" % (predef, unita))
            sp.valueChanged.connect(self._rfi_salva_rese)
            self._spin_rese[(k, sk)] = sp
            # una sola colonna: affiancate, le due colonne impedivano di
            # restringere la finestra sotto i ~700 px
            grid.addWidget(QLabel(nome + ":"), n, 0)
            grid.addWidget(sp, n, 1)
            grid.addWidget(QLabel(unita), n, 2)
        grid.setColumnStretch(3, 1)
        b = QPushButton("Valori predefiniti")
        b.clicked.connect(self._rfi_rese_predefinite)
        grid.addWidget(b, len(self.VOCI_RESE), 0)
        lay = QVBoxLayout(gb)
        lay.addWidget(contenuto)
        contenuto.setVisible(False)
        gb.toggled.connect(contenuto.setVisible)
        return gb

    def _rfi_rese_salvate(self):
        try:
            from qgis.core import QgsSettings
            return json.loads(QgsSettings().value("ftth_permessi/rfi_rese", "") or "{}")
        except Exception:  # noqa: BLE001
            return {}

    def _rfi_rese(self):
        """Rese attuali della scheda, nel formato di ftth_rfi.rese_complete."""
        out = {}
        for (k, sk), sp in getattr(self, "_spin_rese", {}).items():
            if sk:
                out.setdefault(k, {})[sk] = sp.value()
                if k == "pozzetti" and sk == "45x15":
                    out[k]["40x15"] = sp.value()
            else:
                out[k] = sp.value()
        return out

    def _rfi_salva_rese(self, *_):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/rfi_rese", json.dumps(self._rfi_rese()))
        except Exception:  # noqa: BLE001
            pass

    def _rfi_rese_predefinite(self):
        base = _rfi_mod().rese_complete()
        for (k, sk), sp in self._spin_rese.items():
            sp.blockSignals(True)
            sp.setValue(float(base[k][sk] if sk else base[k]))
            sp.blockSignals(False)
        self._rfi_salva_rese()

    def _rfi_prepara_foto_sezioni(self, ente="rfi"):
        """Crea (se mancano) i layer per piazzare punti di ripresa e sezioni,
        in GeoPackage accanto al progetto, con lo stile del plugin. Ogni
        scheda ha i suoi («… - RFI», «… - Strade», «… - Acque», «… -
        Soprintendenza», «… - Parchi»), nel gruppo dell'ente."""
        from qgis.core import QgsProject, QgsVectorFileWriter, QgsFields, QgsWkbTypes
        try:
            from . import ftth_rfi_layout as L
        except ImportError:
            import ftth_rfi_layout as L
        from . import ftth_trovati as _TR
        prj = QgsProject.instance()
        home = prj.homePath()
        if not home:
            QMessageBox.warning(self, "Progetto non salvato",
                                "Salva prima il progetto: i layer vanno nella sua cartella.")
            return
        stili = os.path.join(os.path.dirname(os.path.abspath(__file__)), "styles")
        crs = prj.crs() if prj.crs().isValid() else QgsCoordinateReferenceSystem("EPSG:25832")
        if ente not in L.ENTI_LAYER:
            ente = "rfi"
        sigla = L.ENTI_LAYER[ente]
        cart_ente = os.path.join(home, "01_File shp", sigla)
        definizioni = [
            # layer propri dell'ente («… - RFI»), nel gruppo «Altri enti > RFI»:
            # dentro l'ente tutto ciò che è suo (richiesta dell'utente)
            (L.NOMI_LAYER_FOTO, L.nome_layer_ente("Punto di Ripresa Fotografico", ente), "Point",
             cart_ente,
             [("NumeroFoto", QVariant.Int), ("Rotazione", QVariant.Double),
              (L.CAMPO_ISTANZA, QVariant.String)],
             "rfi_punto_ripresa.qml"),
        ]
        if ente != "sopr":          # la Soprintendenza ha solo foto
            definizioni.append(
                (L.NOMI_LAYER_SEZIONI, L.nome_layer_ente("Sezioni", ente), "LineString",
                 cart_ente,
                 [("sezione", QVariant.String), ("sezione_f", QVariant.String),
                  ("etichetta", QVariant.String), (L.CAMPO_ISTANZA, QVariant.String)],
                 "rfi_sezioni.qml"))
        # istanze confermate in tutte le schede (campi IST_* degli shape): la
        # tendina del campo ISTANZA e le sottocartelle di 04_Foto e 05_Sezioni
        istanze, cartelle_ist, istanze_rfi = [], [], []
        from . import ftth_gruppi_istanze as GR
        try:
            for k, v in sorted(GR.registro(prj).items()):
                if k.startswith("_") or not isinstance(v, dict) or not v.get("valore"):
                    continue
                val = GR.pulisci(v["valore"])
                if v.get("sezione") == "rfi":
                    linea = val.split(L.SEP_NOMI)[0]
                    istanze += [linea, val]
                    if ente == "rfi":
                        istanze_rfi += [linea, val]
                    cartelle_ist.append(linea)
                else:
                    istanze.append(val)
                    if v.get("sezione") == ente:
                        istanze_rfi.append(val)
                    cartelle_ist.append(val)
        except Exception:  # noqa: BLE001
            pass
        istanze = list(dict.fromkeys(istanze))
        cartelle_ist = list(dict.fromkeys(cartelle_ist))
        esiti = []
        for nomi, nome, geom, cartella, campi, qml in definizioni:
            esistente = next(iter(prj.mapLayersByName(nome)), None)
            # layer comune (anche del comunale): modello per campi e stile, e
            # da lì passano qui i punti e le sezioni già indicati come RFI
            comuni = [l for n in nomi for l in prj.mapLayersByName(n)]
            if esistente is not None:
                # layer già fatto: si aggiunge il campo ISTANZA se manca
                if esistente.fields().indexOf(L.CAMPO_ISTANZA) < 0:
                    ok = esistente.dataProvider().addAttributes(
                        [QgsField(L.CAMPO_ISTANZA, QVariant.String, len=254)])
                    esistente.updateFields()
                    esiti.append("«%s»: già nel progetto, %s il campo %s" % (
                        nome, "aggiunto" if ok else "NON riesco ad aggiungere",
                        L.CAMPO_ISTANZA))
                else:
                    esiti.append("«%s»: già nel progetto" % nome)
                _TR.tendina_campo(esistente, L.CAMPO_ISTANZA, istanze_rfi or istanze)
                L.numerazione_per_istanza(esistente)
                if nome.startswith("Punto di Ripresa Fotografico"):
                    L.rotazione_con_strumento(esistente)
                continue
            modello = comuni[0] if comuni else None
            os.makedirs(cartella, exist_ok=True)
            gpkg = os.path.join(cartella, nome + ".gpkg")
            if not os.path.isfile(gpkg):
                fields = QgsFields()
                if modello is not None:
                    for fl in modello.fields():
                        if fl.name().lower() != "fid":
                            fields.append(QgsField(fl))
                for c, t in campi:
                    if fields.indexOf(c) < 0:
                        fields.append(QgsField(c, t))
                opz = QgsVectorFileWriter.SaveVectorOptions()
                opz.driverName = "GPKG"
                opz.layerName = nome
                w = QgsVectorFileWriter.create(gpkg, fields, getattr(QgsWkbTypes, geom),
                                               crs, prj.transformContext(), opz)
                del w
            lyr = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
            if not lyr.isValid():
                esiti.append("«%s»: creazione non riuscita (%s)" % (nome, gpkg))
                continue
            p = os.path.join(stili, qml)
            if modello is not None:          # stesso aspetto del layer che già usi
                from qgis.core import QgsMapLayerStyle
                st = QgsMapLayerStyle()
                st.readFromLayer(modello)
                st.writeToLayer(lyr)
                for kp in modello.customPropertyKeys():
                    if kp.startswith("ftth/"):
                        lyr.setCustomProperty(kp, modello.customProperty(kp))
            elif os.path.isfile(p):
                lyr.loadNamedStyle(p)
            if lyr.fields().indexOf(L.CAMPO_ISTANZA) < 0:
                lyr.dataProvider().addAttributes([QgsField(L.CAMPO_ISTANZA, QVariant.String)])
                lyr.updateFields()
            _TR.tendina_campo(lyr, L.CAMPO_ISTANZA, istanze_rfi or istanze)
            L.numerazione_per_istanza(lyr)
            if nome.startswith("Punto di Ripresa Fotografico"):
                L.rotazione_con_strumento(lyr)
            prj.addMapLayer(lyr, False)
            g_ente = GR.gruppo_sezione(prj.layerTreeRoot(), ente)
            g_ente.insertLayer(0, lyr)
            esiti.append("«%s»: creato in %s, nel gruppo Altri enti > %s" % (
                nome, os.path.relpath(gpkg, home), g_ente.name()))
            # punti e sezioni già indicati come di quest'ente nel layer comune:
            # passano qui
            c_ist = L.CAMPO_ISTANZA
            chiavi_ente = {GR.chiave_nome(x) for x in istanze_rfi}

            def _dell_ente(f, c_ist=c_ist, chiavi_ente=chiavi_ente):
                if f.fields().indexOf(c_ist) < 0:
                    return False
                v = str(f[c_ist] or "").strip()
                if v in ("", "NULL"):
                    return False
                return any(GR.chiave_nome(p) in chiavi_ente or L.di_ente(ente, p, prj)
                           for p in v.split(";"))
            spostati = L.sposta_elementi(comuni, lyr, _dell_ente)
            if spostati:
                esiti.append("   %d elementi di %s spostati qui dal layer comune" % (
                    spostati, sigla))
            vuoti = sum(1 for l in comuni for f in l.getFeatures()
                        if l.fields().indexOf(c_ist) >= 0
                        and str(f[c_ist] or "").strip() in ("", "NULL"))
            if vuoti:
                esiti.append("   nel layer comune «%s» restano %d elementi con ISTANZA vuota: "
                             "se sono di %s copiali qui (le tavole %s ora usano questo "
                             "layer)" % (comuni[0].name(), vuoti, sigla, sigla))
        nuove = 0
        for sotto in ("04_Foto", "05_Sezioni"):
            os.makedirs(os.path.join(home, sotto), exist_ok=True)
            for n in cartelle_ist:
                c = os.path.join(home, sotto, L.nome_cartella(n))
                if n and not os.path.isdir(c):
                    os.makedirs(c, exist_ok=True)
                    nuove += 1
        if cartelle_ist:
            esiti.append("Sottocartelle per istanza in 04_Foto e 05_Sezioni: %s%s" % (
                ", ".join(L.nome_cartella(n) for n in cartelle_ist[:6]),
                " …" if len(cartelle_ist) > 6 else ""))
        testo = "\n".join(esiti) + (
            "\n\nCome si usano:\n"
            "• Punto di Ripresa: metti il punto dove stai scattando, NumeroFoto = n. "
            "Il cono si gira con lo strumento di QGIS «Ruota simboli puntuali» (barra "
            "Digitalizzazione avanzata, layer in modifica) o scrivendo i gradi in "
            "Rotazione. Foto in 04_Foto\\FOTO-n.jpg.\n"
            "• Sezioni: traccia una linea di traverso allo scavo, sezione = A "
            "(sezione_f = A' si può lasciare vuoto). Disegno in 05_Sezioni\\SEZIONE A-A'.svg.\n"
            "• ISTANZA: scegli dalla tendina l'istanza del punto o della sezione (per RFI "
            "anche solo la linea). Vuoto = vale per tutte. Così due istanze possono avere "
            "ognuna la sua FOTO 1 o la sua A-A': i file vanno nella sottocartella "
            "dell'istanza (04_Foto\\SP28\\FOTO-1.jpg); se lì non ci sono si cercano nella "
            "cartella.\n"
            "In ogni tavola compaiono quelli dell'istanza che cadono nella planimetria; "
            "con più sezioni di quante ne stanno nella tavola si aggiunge una tavola "
            "inquadrata su ogni sezione in più.")
        self._log_rfi(testo)
        QMessageBox.information(self, "Foto e Sezioni", testo)

    def _rfi_auto_comune(self):
        """Scritto il comune: provincia (sigla), CAP, regione e DOIT. Se il comune
        cambia, provincia e CAP vengono SOVRASCRITTI (prima restavano quelli del
        comune precedente); indirizzo e PEC del vecchio comune vengono svuotati.
        Basta Nominatim (1-2 s), niente ricerca ferrovie."""
        nome = self.txt_rfi_comune.text().strip()
        st = self._rfi_state()
        if not nome or st.get("_ultimo_comune") == nome.lower():
            return
        precedente = st.get("_ultimo_comune")
        st["_ultimo_comune"] = nome.lower()
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
            from qgis.PyQt.QtWidgets import QApplication
            QApplication.setOverrideCursor(Qt.BusyCursor)
            try:
                c = scr.risolvi_comune(nome, None)
            finally:
                QApplication.restoreOverrideCursor()
        except Exception as e:  # noqa: BLE001
            self._log_rfi("Comune non risolto automaticamente: %s" % e)
            return
        if not c.data:
            if precedente:
                for w in (self.txt_rfi_prov, self.txt_rfi_cap,
                          self.txt_rfi_indirizzo, self.txt_rfi_comune_pec):
                    w.clear()
            self._log_rfi("Comune «%s» non trovato: compila provincia e CAP a mano." % nome)
            return
        d = c.data
        self._rfi_imposta_prov_cap(d.get("provincia"), d.get("cap"))
        if precedente and precedente != nome.lower():
            for w in (self.txt_rfi_indirizzo, self.txt_rfi_comune_pec):
                w.clear()
        st["regione"] = d.get("regione")
        self._rfi_riempi_doit()
        self._log_rfi("Comune: %s (%s) — %s, CAP %s" % (
            d.get("nome"), self.txt_rfi_prov.text(), d.get("regione") or "?",
            self.txt_rfi_cap.text() or "da compilare"))

    def _rfi_imposta_prov_cap(self, provincia, cap):
        """Provincia (sigla) e CAP del comune risolto, sempre sovrascritti:
        valgono per il comune scritto, non per quello di prima."""
        sigla = _rfi_mod().sigla_provincia(provincia) if provincia else None
        self.txt_rfi_prov.setText(sigla or provincia or "")
        self.txt_rfi_cap.setText(str(cap).split(";")[0].strip() if cap else "")

    def _log_rfi(self, msg):
        self.log_rfi.appendPlainText(str(msg))
        self.log_rfi.repaint()

    def _rfi_state(self):
        if not hasattr(self, "_rfi_dati_cache"):
            self._rfi_dati_cache = {"cippi": [], "ways": [], "stazioni": [],
                                    "interferenze": [], "regione": None,
                                    "gestori": {}, "cartella": None}
        return self._rfi_dati_cache

    # ---------------------------------------------- precompila da screening
    def _rfi_precompila_da_screening(self):
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
        except ImportError as e:
            QMessageBox.critical(self, "Screening non disponibile", str(e))
            return
        comune = self.txt_rfi_comune.text().strip()
        if not comune and hasattr(self, "txt_scr_comune"):
            comune = self.txt_scr_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune e riprova.")
            return
        self.log_rfi.clear()
        self._log_rfi("Comune e struttura RFI per %s..." % comune)
        self.btn_rfi_precompila.setEnabled(False)
        try:
            from qgis.PyQt.QtWidgets import QApplication
            QApplication.processEvents()
            rep = scr.esegui_rfi(comune, None, avanzamento=lambda m: self._log_rfi("  " + str(m)))
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Screening non riuscito", str(e))
            return
        finally:
            self.btn_rfi_precompila.setEnabled(True)
        if rep.get("errore"):
            QMessageBox.warning(self, "Comune non risolto", rep["errore"])
            return
        c = rep.get("comune") or {}

        if c.get("nome") and not self.txt_rfi_comune.text().strip():
            self.txt_rfi_comune.setText(c["nome"].upper())
        self._rfi_imposta_prov_cap(c.get("provincia"), c.get("cap"))
        self._rfi_state()["_ultimo_comune"] = self.txt_rfi_comune.text().strip().lower()
        self._rfi_state()["regione"] = c.get("regione")
        self._rfi_riempi_doit(rep.get("rfi"))
        self._log_rfi("Fatto. Completa a mano indirizzo e PEC del Comune se mancano.")

    def _rfi_riempi_doit(self, rfi_c=None):
        """Popola la scelta della DOIT RFI dalla kb della regione."""
        st_ = self._rfi_state()
        if rfi_c is None and not st_.get("regione") and self.txt_rfi_comune.text().strip() \
                and not getattr(self, "_rfi_in_auto", False):
            # regione ignota (progetto riaperto): si ricava dal comune, e con
            # lei DOIT, indirizzo e PEC di RFI
            self._rfi_in_auto = True
            try:
                st_["_ultimo_comune"] = None
                self._rfi_auto_comune()
            except Exception:  # noqa: BLE001
                pass
            finally:
                self._rfi_in_auto = False
            if self.cb_rfi_doit.count():
                return
        if rfi_c is None:
            try:
                try:
                    from . import ftth_screening as scr
                except ImportError:
                    import ftth_screening as scr
                rfi_c = scr.rfi_struttura(self._rfi_state().get("regione"))
            except Exception:  # noqa: BLE001
                rfi_c = None
        self.cb_rfi_doit.blockSignals(True)
        self.cb_rfi_doit.clear()
        for c in (rfi_c or {}).get("contatti") or []:
            self.cb_rfi_doit.addItem("%s — %s" % (c.get("doit"), c.get("pec")), c)
        if self.cb_rfi_doit.count() == 0 and rfi_c:
            self.cb_rfi_doit.addItem(rfi_c.get("citta") or "", {"doit": rfi_c.get("citta"), "pec": ""})
        self.cb_rfi_doit.blockSignals(False)
        if self.cb_rfi_doit.count() > 1:
            self._log_rfi("Più DOIT RFI possibili per la regione: scegli quella competente "
                          "per la linea nel punto 4.")
        self._rfi_applica_doit()

    def _rfi_applica_doit(self, *_):
        c = self.cb_rfi_doit.currentData()
        if not c:
            return
        try:
            from . import ftth_rfi as _R
        except ImportError:
            import ftth_rfi as _R
        ind_n, pec_n = _R.sede_doit(c.get("doit"))
        noti = {v[0] for v in _R.DOIT_SEDI.values()}
        for r in range(self.tab_rfi_dest.rowCount()):
            if self.tab_rfi_dest.item(r, 0).data(Qt.UserRole) == "rfi":
                self.tab_rfi_dest.setItem(r, 1, QTableWidgetItem(
                    "RFI - Direzione Operativa Infrastrutture Territoriale di %s"
                    % str(c.get("doit") or "").upper()))
                # indirizzo della sede DOIT (fonte rfi.it): si scrive se la
                # cella è vuota o ha l'indirizzo di un'altra DOIT; un indirizzo
                # scritto a mano resta
                it_ = self.tab_rfi_dest.item(r, 2)
                vecchio = it_.text().strip() if it_ else ""
                if ind_n and (not vecchio or vecchio in noti):
                    self.tab_rfi_dest.setItem(r, 2, QTableWidgetItem(ind_n))
                if c.get("pec") or pec_n:
                    self.tab_rfi_dest.setItem(r, 3, QTableWidgetItem(c.get("pec") or pec_n))

    # ------------------------------------------------------- OSM download
    def _overpass(self, query, timeout=60):
        """Stessa richiesta a tutti i server Overpass in parallelo: vale la prima
        risposta valida. Prima i server si provavano uno dopo l'altro (con due
        tentativi ciascuno) e un server lento bloccava tutto per minuti."""
        import concurrent.futures as cf
        from qgis.PyQt.QtWidgets import QApplication
        data = urllib.parse.urlencode({"data": query}).encode()

        def _una(url):
            req = urllib.request.Request(url, data=data, headers={"User-Agent": "ftth-permessi/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                ris = json.load(r)
            if "elements" not in ris:
                raise ValueError("risposta Overpass senza dati")
            return ris

        ex = cf.ThreadPoolExecutor(max_workers=len(OVERPASS_MIRRORS))
        futuri = [ex.submit(_una, m) for m in OVERPASS_MIRRORS]
        ultimo = None
        try:
            in_corso = set(futuri)
            while in_corso:
                fatti, in_corso = cf.wait(in_corso, timeout=0.2, return_when=cf.FIRST_COMPLETED)
                QApplication.processEvents()      # la finestra resta viva durante l'attesa
                tick = getattr(self, "_attesa_tick", None)
                if tick is not None:              # barra di avanzamento / Interrompi
                    tick()
                for f in fatti:
                    try:
                        return f.result()
                    except Exception as e:  # noqa: BLE001
                        ultimo = e
            raise ultimo or RuntimeError("nessun server Overpass ha risposto")
        finally:
            ex.shutdown(wait=False, cancel_futures=True)

    def _rfi_bbox_progetto(self, margine=0.006):
        """(latmin, lonmin, latmax, lonmax) WGS84 dei layer di progetto."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        rect = None
        for nome in ("03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO", "Arlo Area"):
            lyr = self._find_layer(nome)
            if lyr is None or not lyr.isValid():
                continue
            g = QgsGeometry.fromRect(lyr.extent())
            g.transform(QgsCoordinateTransform(lyr.crs(), wgs, self.project))
            b = g.boundingBox()
            if b.isEmpty():
                continue
            if rect is None:
                rect = QgsRectangle(b)
            else:
                rect.combineExtentWith(b)
        if rect is None:
            return None
        return (rect.yMinimum() - margine, rect.xMinimum() - margine,
                rect.yMaximum() + margine, rect.xMaximum() + margine)

    def _rfi_scarica_osm(self, *_):
        """Scaricamento con barra di avanzamento e pulsante Interrompi."""
        bar = getattr(self, "bar_rfi_osm", None)
        self._rfi_stop = False
        self._rfi_state()["linee_escluse"] = set()     # nuova ricerca: elenco da capo
        self.btn_rfi_osm.setEnabled(False)
        self.btn_rfi_stop.setText("Interrompi")
        self.btn_rfi_stop.setEnabled(True)
        self.btn_rfi_stop.setVisible(True)
        if bar is not None:
            bar.azzera()

        def _tick():
            if self._rfi_stop:
                raise _RicercaInterrottaRFI()
            if bar is not None:
                bar.avanza()
        self._attesa_tick = _tick
        try:
            self._rfi_scarica_osm_impl()
        except _RicercaInterrottaRFI:
            self._log_rfi("Scaricamento interrotto dall'utente: nessun layer cambiato.")
            if bar is not None:
                bar.interrotta("Scaricamento interrotto dall'utente")
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_rfi("ERRORE:\n" + traceback.format_exc())
            if bar is not None:
                bar.interrotta("Errore: vedi il registro in fondo alla scheda")
            QMessageBox.critical(self, "Ricerca ferrovie non riuscita",
                                 "%s\n\nPuoi rilanciare la ricerca; «Riscarica da OSM» la rifà "
                                 "senza usare la cache." % e)
            self._rfi_stop = True        # la barra resta sul messaggio d'errore
        finally:
            self._attesa_tick = None
            self.btn_rfi_osm.setEnabled(True)
            self.btn_rfi_stop.setVisible(False)
            if bar is not None and bar.value() < 100 and not self._rfi_stop:
                bar.interrotta("Scaricamento non completato — vedi il registro")

    def _rfi_interrompi(self, *_):
        self._rfi_stop = True
        self.btn_rfi_stop.setEnabled(False)
        self.btn_rfi_stop.setText("Interrompo…")

    def _rfi_scarica_osm_impl(self):
        bar = getattr(self, "bar_rfi_osm", None)
        self.log_rfi.clear()
        bbox = self._rfi_bbox_progetto()
        if bbox is None:
            QMessageBox.warning(self, "Progetto senza layer",
                                "Servono i layer di progetto (03 INFRASTRUTTURE / 02_POZZETTO "
                                "/ Arlo Area) per delimitare l'area.")
            return
        b = "%f,%f,%f,%f" % bbox
        # stazioni in un intorno un po' piu' largo (~3 km): la stazione di
        # riferimento puo' stare fuori dall'area di progetto
        m = 0.03
        bs = "%f,%f,%f,%f" % (bbox[0] - m, bbox[1] - m, bbox[2] + m, bbox[3] + m)
        query = ("[out:json][timeout:60];("
                 'way["railway"~"^(rail|narrow_gauge|light_rail)$"](%s);'
                 'node["railway"="milestone"](%s);'
                 'node["railway"~"^(station|halt)$"](%s);'
                 ");out body geom qt;") % (b, b, bs)
        # cache: i server Overpass pubblici rispondono in 30-60 s (misurato); per
        # la stessa zona il secondo scaricamento e' immediato per 30 giorni
        import hashlib
        import time as _time
        cache_dir = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache")
        chiave = hashlib.md5(query.encode("utf-8")).hexdigest()
        cache_p = os.path.join(cache_dir, "overpass_rfi_%s.json" % chiave)
        if getattr(self, "_rfi_senza_cache", False) and os.path.isfile(cache_p):
            try:
                os.remove(cache_p)      # «Riscarica da OSM»: dati nuovi
            except OSError:
                pass
        res = None
        if os.path.isfile(cache_p) and _time.time() - os.path.getmtime(cache_p) < 30 * 86400:
            try:
                with open(cache_p, encoding="utf-8") as fh:
                    res = json.load(fh)
                self._log_rfi("Dati OSM dalla cache (scaricati il %s)."
                              % _time.strftime("%d/%m/%Y", _time.localtime(os.path.getmtime(cache_p))))
            except Exception:  # noqa: BLE001
                res = None
        if res is None:
            self._log_rfi("Scarico da OSM ferrovie, cippi km e stazioni (i server pubblici "
                          "rispondono in 30-60 secondi, QGIS resta utilizzabile)...")
            if bar is not None:
                bar.fase(0, 85, "1/2 scarico ferrovie, cippi km e stazioni da OSM")
            try:
                res = self._overpass(query)
            except Exception as e:  # noqa: BLE001
                QMessageBox.critical(self, "OSM non raggiungibile",
                                     "Impossibile scaricare i dati OSM:\n%s" % e)
                return
            try:
                os.makedirs(cache_dir, exist_ok=True)
                with open(cache_p, "w", encoding="utf-8") as fh:
                    json.dump(res, fh)
            except Exception:  # noqa: BLE001
                pass
        if bar is not None:
            bar.fase(85, 100, "2/2 creo i layer di ferrovia, fascia, cippi e stazioni")
        els = res.get("elements", [])
        ways = [e for e in els if e["type"] == "way" and e.get("geometry")]
        cippi = []
        stazioni = []
        for e in els:
            if e["type"] != "node":
                continue
            t = e.get("tags", {})
            if t.get("railway") == "milestone" and t.get("railway:position"):
                try:
                    km = float(str(t["railway:position"]).replace(",", "."))
                except ValueError:
                    continue
                cippi.append({"km": km, "lat": e["lat"], "lon": e["lon"]})
            elif t.get("railway") in ("station", "halt"):
                stazioni.append({"nome": t.get("name") or "stazione senza nome",
                                 "lat": e["lat"], "lon": e["lon"]})
        st = self._rfi_state()
        st.update(cippi=cippi, ways=ways, stazioni=stazioni)
        lay = self._rfi_layer_linea(ways)
        # linee corrette a mano: valgono anche dopo un nuovo scaricamento
        if self._rfi_applica_tracciati():
            lay = self._find_layer("Ferrovia RFI") or lay
        self._rfi_layer_cippi(cippi)
        self._rfi_layer_stazioni(stazioni)
        self._rfi_layer_fascia(lay, self.spin_rfi_fascia.value())
        self._rfi_ordina_layer()
        linee = sorted({(w.get("tags", {}).get("operator") or "operatore ignoto",
                         w.get("tags", {}).get("name") or w.get("tags", {}).get("ref") or "senza nome")
                        for w in ways})
        self._log_rfi("Linee: %d tratti OSM — %s" % (
            len(ways), "; ".join("%s (%s)" % (n, o) for o, n in linee) or "nessuna"))
        self._log_rfi("Cippi km: %d · stazioni: %s" % (
            len(cippi), ", ".join(s["nome"] for s in stazioni) or "nessuna"))
        self._rfi_riempi_linee()
        if bar is not None:
            bar.fine("Completato: %d linee, %d cippi km, %d stazioni"
                     % (self.tab_rfi_lin.rowCount(), len(cippi), len(stazioni)))
        if not ways:
            QMessageBox.information(self, "Nessuna ferrovia",
                                    "OSM non riporta linee ferroviarie nell'area del progetto.")
        if not cippi:
            self._log_rfi("ATTENZIONE: nessun cippo km in OSM — le progressive saranno "
                          "«da verificare» (XXX+XXX nei documenti).")

    @staticmethod
    def _rfi_pulisci_ways(ways, raggio_m=60.0):
        """OSM: i binari senza nome né numero (di servizio, di scalo, raccordi)
        non sono linee a sé. Se stanno vicino (entro raggio_m) a una linea con
        nome ne prendono nome, numero e gestore; i raccordi industriali/militari
        e quelli isolati si scartano. Ritorna (ways tenuti, n. uniti, n. scartati)."""
        import math
        from shapely.geometry import LineString
        from shapely.strtree import STRtree
        tenuti, senza = [], []
        scartati = 0
        for wy in ways:
            tg = wy.get("tags", {}) or {}
            pts = [(q["lon"], q["lat"]) for q in wy.get("geometry") or []]
            if len(pts) < 2:
                continue
            if tg.get("usage") in ("industrial", "military", "tourism", "test"):
                scartati += 1
                continue
            g = LineString(pts)
            if tg.get("name") or tg.get("ref"):
                tenuti.append((wy, g))
            else:
                senza.append((wy, g))
        uniti = 0
        if senza and tenuti:
            geoms = [g for _w, g in tenuti]
            albero = STRtree(geoms)
            for wy, g in senza:
                lat = g.centroid.y
                k = 111320.0 * max(0.2, math.cos(math.radians(lat)))
                rag = raggio_m / k
                vicini = albero.query(g.buffer(rag))
                idx = [int(i) if not hasattr(i, "geom_type") else geoms.index(i) for i in vicini]
                idx = [i for i in idx if geoms[i].distance(g) <= rag]
                if not idx:
                    scartati += 1
                    continue
                i = min(idx, key=lambda j: geoms[j].distance(g))
                src = tenuti[i][0].get("tags", {})
                tg = dict(wy.get("tags", {}) or {})
                for c in ("name", "ref", "operator"):
                    if src.get(c):
                        tg[c] = src[c]
                nuovo = dict(wy)
                nuovo["tags"] = tg
                tenuti.append((nuovo, g))
                uniti += 1
        else:
            scartati += len(senza)
        return [w for w, _g in tenuti], uniti, scartati

    def _rfi_layer_linea(self, ways):
        from shapely.geometry import LineString
        ways, uniti, scartati = self._rfi_pulisci_ways(ways)
        if uniti or scartati:
            self._log_rfi("Binari OSM senza nome: %d uniti alla linea vicina (stazioni, scali), "
                          "%d ignorati (raccordi industriali o binari isolati)." % (uniti, scartati))
        voci = []
        for wy in ways:
            pts = [(p["lon"], p["lat"]) for p in wy["geometry"]]
            if len(pts) >= 2:
                voci.append((LineString(pts), wy.get("tags", {}), "OSM"))
        return self._rfi_layer_linea_da(voci)

    def _rfi_disegna_quote(self, *_a):
        """Layer «Quote dalla rotaia» (Istanze.gpkg) in modifica, strumento
        linea attivo: l'utente disegna le quote, la PL le stampa con la misura."""
        from qgis.core import QgsLineSymbol, QgsSingleSymbolRenderer
        from . import ftth_tracciati as _TRC
        try:
            from . import ftth_rfi_layout as _RL
            nome = _RL.NOME_QUOTE_MAN
        except Exception:  # noqa: BLE001
            nome = "Quote dalla rotaia"
        try:
            lyr = _TRC.layer(self, nome, "quote_rotaia", "rfi")
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Quote dalla rotaia", "Layer non creato: %s" % e)
            return
        # in mappa come in tavola: linea rossa con le frecce e la misura
        sym = QgsLineSymbol.createSimple({"line_color": "190,30,30,255", "line_width": "0.3",
                                          "line_style": "dash"})
        try:
            from qgis.core import QgsMarkerLineSymbolLayer, QgsMarkerSymbol
            for pos, ang in (("firstvertex", "180"), ("lastvertex", "0")):
                ml = QgsMarkerLineSymbolLayer.create({"placement": pos, "rotate": "1"})
                ml.setSubSymbol(QgsMarkerSymbol.createSimple({
                    "name": "filled_arrowhead", "color": "190,30,30,255",
                    "outline_color": "190,30,30,255", "outline_width": "0.1",
                    "size": "3", "angle": ang}))
                sym.appendSymbolLayer(ml)
        except Exception:  # noqa: BLE001
            pass
        lyr.setRenderer(QgsSingleSymbolRenderer(sym))
        try:
            from qgis.core import (QgsPalLayerSettings, QgsTextBufferSettings, QgsTextFormat,
                                   QgsVectorLayerSimpleLabeling)
            pal = QgsPalLayerSettings()
            pal.isExpression = True
            # distanza vera sull'ellissoide, al mezzo metro piu' vicino
            pal.fieldName = ("replace(format_number(round($length * 2) / 2, 2), '.', ',') "
                             "|| ' m'")
            try:
                from qgis.core import Qgis
                pal.placement = Qgis.LabelPlacement.Horizontal
            except Exception:  # noqa: BLE001
                pass
            tf = QgsTextFormat()
            tf.setSize(7)
            tf.setColor(QColor(190, 30, 30))
            b = QgsTextBufferSettings()
            b.setEnabled(True)
            b.setSize(1)
            tf.setBuffer(b)
            pal.setFormat(tf)
            lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            lyr.setLabelsEnabled(True)
        except Exception:  # noqa: BLE001
            pass
        lyr.triggerRepaint()
        # ogni quota disegnata si raddrizza subito: perpendicolare al binario
        # e con la punta sulla rotaia
        if not lyr.property("ftth_quote_ortogonali"):
            lyr.setProperty("ftth_quote_ortogonali", True)

            def _raddrizza(fid, _l=lyr):
                try:
                    from qgis.core import QgsProject
                    f = _l.getFeature(fid)
                    if not f.hasGeometry():
                        return
                    g = _RL.quota_ortogonale(QgsProject.instance(), f.geometry(), _l.crs())
                    if g is not None:
                        _l.changeGeometry(fid, g)
                        _l.triggerRepaint()
                except Exception:  # noqa: BLE001
                    pass
            lyr.featureAdded.connect(_raddrizza)
        if not lyr.isEditable():
            lyr.startEditing()
        try:
            self.iface.setActiveLayer(lyr)
            self.iface.actionAddFeature().trigger()
        except Exception:  # noqa: BLE001
            pass
        self._log_rfi("Quote dalla rotaia: disegna una linea per quota (clic sull'elemento, "
                      "clic sulla rotaia, tasto destro), poi salva il layer. In tavola escono "
                      "con le frecce e la distanza al mezzo metro.")
        QMessageBox.information(
            self, "Quote dalla rotaia",
            "Il layer «%s» è in modifica con lo strumento linea.\n\n"
            "Per ogni quota: clic sul bordo dell'elemento (pozzetto, armadio, scavo), poi "
            "clic verso la rotaia; tasto destro per finire. La linea si raddrizza da sola: "
            "perpendicolare al binario, con la punta sulla rotaia.\n\nPoi salva il layer: alla generazione le quote "
            "vanno in tavola con le frecce e la distanza orizzontale al mezzo metro." % nome)

    # ------------------------------------- tracciati corretti a mano
    NOME_TRACCIATI_RFI = "Tracciati ferrovie (correzione)"

    def _rfi_riga_linea_sel(self):
        t = self.tab_rfi_lin
        righe = sorted({i.row() for i in t.selectedIndexes()})
        r = righe[0] if righe else t.currentRow()
        it = t.item(r, 0) if r >= 0 else None
        return tuple(it.data(Qt.UserRole)) if it is not None and it.data(Qt.UserRole) else None

    def _rfi_correggi_tracciato(self, *_a):
        from shapely.ops import unary_union
        from . import ftth_tracciati as _TRC
        chiave = self._rfi_riga_linea_sel()
        kb = _kb()
        gg = [l["geom"] for l in self._rfi_linee_layer()
              if chiave and self._rfi_chiave_linea(l, kb) == chiave]
        if _TRC.inizia(self, self.NOME_TRACCIATI_RFI, "tracciati_ferrovie", "rfi",
                       "%s|%s" % chiave if chiave else "", unary_union(gg) if gg else None):
            self._log_rfi("Correggi il tracciato di %s nel layer «%s» (strumento vertici), "
                          "poi premi «Usa i tracciati corretti»."
                          % (chiave[1], self.NOME_TRACCIATI_RFI))

    def _rfi_usa_tracciati(self, *_a):
        from . import ftth_tracciati as _TRC
        corr = _TRC.leggi(self, self.NOME_TRACCIATI_RFI)
        if corr is None:
            return
        self._rfi_state()["tracciati"] = corr
        n = self._rfi_applica_tracciati()
        self._rfi_riempi_linee()
        self._log_rfi("Tracciati ferroviari corretti a mano: %d (%d linee aggiornate, fascia "
                      "ricalcolata). Rifai «Trova le interferenze»." % (len(corr), n))
        QMessageBox.information(self, "Tracciati corretti",
                                "%d linee con il tracciato corretto. Ora rifai «Trova le "
                                "interferenze» al passo 3." % len(corr))

    def _rfi_applica_tracciati(self):
        """Nel layer «Ferrovia RFI» le linee corrette a mano (stato
        'tracciati' = {«gestore|linea»: WKT}) prendono il tracciato corretto;
        la fascia di rispetto si ricalcola. Ritorna quante linee ha cambiato."""
        from . import ftth_tracciati as _TRC
        corr = self._rfi_state().get("tracciati") or {}
        if not corr:
            return 0
        kb = _kb()
        voci, tags = [], {}
        for l in self._rfi_linee_layer():
            k = "%s|%s" % self._rfi_chiave_linea(l, kb)
            if k in corr:
                tags.setdefault(k, l["tags"])
                continue
            voci.append((l["geom"], l["tags"], l["fonte"]))
        if not tags:
            return 0
        for k, t in tags.items():
            for parte in _TRC.parti(corr[k]):
                voci.append((parte, t, "corretto a mano"))
        lay = self._rfi_layer_linea_da(voci)
        try:
            self._rfi_layer_fascia(lay, self.spin_rfi_fascia.value())
            self._rfi_ordina_layer()
        except Exception:  # noqa: BLE001
            pass
        return len(tags)

    def _rfi_layer_linea_da(self, voci):
        """Layer «Ferrovia RFI» da [(LineString WGS84, tags, fonte)]."""
        vl = QgsVectorLayer("LineString?crs=EPSG:4326", "Ferrovia RFI", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("nome", QVariant.String), QgsField("ref", QVariant.String),
                          QgsField("operator", QVariant.String),
                          QgsField("fonte", QVariant.String)])
        vl.updateFields()
        feats = []
        for g, t, fonte in voci:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromWkt(g.wkt))
            f["nome"] = t.get("name") or ""
            f["ref"] = t.get("ref") or ""
            f["operator"] = t.get("operator") or ""
            f["fonte"] = fonte or "OSM"
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        self._rfi_stile_ferrovia(vl)
        self._rfi_sostituisci_layer("Ferrovia RFI", vl)
        return vl

    def _rfi_layer_cippi(self, cippi):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Cippi km RFI", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("km", QVariant.Double)])
        vl.updateFields()
        feats = []
        for c in cippi:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(c["lon"], c["lat"])))
            f["km"] = c["km"]
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        self._rfi_stile_cippi(vl)
        self._rfi_sostituisci_layer("Cippi km RFI", vl)
        return vl

    def _rfi_layer_stazioni(self, stazioni):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Stazioni ferroviarie", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("nome", QVariant.String)])
        vl.updateFields()
        feats = []
        for s in stazioni:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(s["lon"], s["lat"])))
            f["nome"] = s["nome"]
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "square", "color": "30,30,30,255", "outline_color": "255,255,255,255",
             "size": "3"})))
        self._rfi_etichetta(vl, "nome", 8)
        self._rfi_sostituisci_layer("Stazioni ferroviarie", vl)
        return vl

    def _rfi_layer_fascia(self, lay_linea, fascia_m):
        """Buffer metrico della linea (UTM della zona), restituito in WGS84."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        ext = lay_linea.extent()
        if lay_linea.featureCount() == 0 or ext.isEmpty() or ext.center().x() != ext.center().x():
            # nessuna ferrovia: fascia vuota (prima: errore «NaN» e ricerca bloccata)
            vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "Fascia di rispetto RFI", "memory")
            self._rfi_stile_fascia(vl)
            self._rfi_sostituisci_layer("Fascia di rispetto RFI", vl)
            return vl
        zona = int((ext.center().x() + 180) / 6) + 1
        crs_m = QgsCoordinateReferenceSystem("EPSG:%d" % (32600 + zona))
        tr_in = QgsCoordinateTransform(wgs, crs_m, self.project)
        tr_out = QgsCoordinateTransform(crs_m, wgs, self.project)
        geoms = []
        for f in lay_linea.getFeatures():
            g = QgsGeometry(f.geometry())
            g.transform(tr_in)
            geoms.append(g)
        vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "Fascia di rispetto RFI", "memory")
        if geoms:
            # fascia 6-30 m come nelle tavole RFI: dai 6 m (proprietà del
            # gestore) ai 30 m, misurati dal limite stimato della ferrovia
            # (asse + margine); in tavola si vedono le due linee tratteggiate
            marg = self.spin_rfi_margine.value() if hasattr(self, "spin_rfi_margine") else 0.0
            asse = QgsGeometry.unaryUnion(geoms)
            buff = asse.buffer(fascia_m + marg, 8)
            dentro = asse.buffer(_rfi_mod().FASCIA_PROPRIETA_M + marg, 8)
            if fascia_m > _rfi_mod().FASCIA_PROPRIETA_M:
                buff = buff.difference(dentro)
            buff.transform(tr_out)
            f = QgsFeature()
            f.setGeometry(buff)
            vl.dataProvider().addFeatures([f])
            vl.updateExtents()
        self._rfi_stile_fascia(vl)
        self._rfi_sostituisci_layer("Fascia di rispetto RFI", vl)
        return vl

    # ------------------------------------------------------------ stili
    def _rfi_stile_fascia(self, vl):
        sym = QgsFillSymbol.createSimple({
            "color": "255,80,80,30", "outline_color": "0,140,60,255",
            "outline_width": "0.5", "outline_style": "dash"})
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        vl.triggerRepaint()

    def _rfi_stile_ferrovia(self, vl):
        sym = QgsLineSymbol()
        sym.deleteSymbolLayer(0)
        base = QgsSimpleLineSymbolLayer(QColor(0, 0, 0))
        base.setWidth(1.0)
        sym.appendSymbolLayer(base)
        trav = QgsSimpleLineSymbolLayer(QColor(255, 255, 255))
        trav.setWidth(0.8)
        trav.setPenStyle(Qt.CustomDashLine)
        trav.setCustomDashVector([3, 3])
        trav.setUseCustomDashPattern(True)
        sym.appendSymbolLayer(trav)
        vl.setRenderer(QgsSingleSymbolRenderer(sym))
        vl.triggerRepaint()

    def _rfi_stile_cippi(self, vl):
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple({
            "name": "circle", "color": "255,215,0,255", "outline_color": "0,0,0,255",
            "outline_width": "0.4", "size": "2.6"})))
        self._rfi_etichetta(vl, "km", 8)

    def _rfi_etichetta(self, vl, campo, dim, espressione=False, colore=QColor(0, 0, 0)):
        pal = QgsPalLayerSettings()
        pal.fieldName = campo
        pal.isExpression = espressione
        tf = QgsTextFormat()
        fnt = QFont("Arial", dim)
        fnt.setBold(True)
        tf.setFont(fnt)
        tf.setSize(dim)
        tf.setColor(colore)
        buf = QgsTextBufferSettings()
        buf.setEnabled(True)
        buf.setSize(1.0)
        buf.setColor(QColor(255, 255, 255))
        tf.setBuffer(buf)
        pal.setFormat(tf)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
        vl.triggerRepaint()

    def _rfi_gruppo(self):
        """Gruppo «RFI - Ferrovie» in cima alla legenda (creato se manca)."""
        root = self.project.layerTreeRoot()
        g = root.findGroup(GRUPPO_RFI)
        if g is None:
            from . import ftth_gruppi_istanze as _GRp
            g = _GRp.gruppo_sezione(root, "rfi").insertGroup(0, GRUPPO_RFI)
        if g is None:
            g = root.insertGroup(0, GRUPPO_RFI)
        return g

    def _rfi_ordina_layer(self):
        """I layer della scheda RFI vanno nel loro gruppo, sempre nello stesso
        ordine (interferenze sopra, fascia sotto)."""
        root = self.project.layerTreeRoot()
        gruppo = self._rfi_gruppo()
        for nome in reversed(LAYER_RFI):
            lid = self._rfi_layer_id(nome)
            nodo = root.findLayer(lid) if lid else None
            if nodo is None:
                continue
            clone = nodo.clone()
            parent = nodo.parent()
            gruppo.insertChildNode(0, clone)
            parent.removeChildNode(nodo)

    def _rfi_salva_layer(self):
        """Rende permanenti i layer RFI: un GeoPackage nella cartella scelta,
        un layer per ciascuno con lo stile incorporato (stile predefinito nel
        GeoPackage), poi nel progetto i layer temporanei sono sostituiti da
        quelli salvati, nello stesso gruppo."""
        from qgis.core import QgsVectorFileWriter, QgsSettings
        presenti = [(n, self.project.mapLayer(self._rfi_layer_id(n)))
                    for n in LAYER_RFI if self._rfi_layer_id(n)]
        if not presenti:
            QMessageBox.information(self, "Layer RFI", "Nessun layer RFI da salvare: "
                                    "scarica prima ferrovie, cippi e stazioni.")
            return
        partenza = QgsSettings().value("ftth_permessi/rfi_cartella_layer", "") or \
            os.path.join(self.project.homePath() or "", "01_File shp")
        cart = QFileDialog.getExistingDirectory(self, "Cartella dove salvare i layer RFI", partenza)
        if not cart:
            return
        QgsSettings().setValue("ftth_permessi/rfi_cartella_layer", cart)
        comune = (self.txt_rfi_comune.text().strip() or "progetto").replace(" ", "_")
        gpkg = os.path.join(cart, "Layer_RFI_%s.gpkg" % comune)
        esiti, primo = [], True
        root = self.project.layerTreeRoot()
        for nome, lyr in presenti:
            if lyr is None:
                continue
            if lyr.providerType() != "memory" and \
                    os.path.normcase(lyr.source().split("|")[0]) == os.path.normcase(gpkg):
                esiti.append("%s: già salvato" % nome)
                continue
            opz = QgsVectorFileWriter.SaveVectorOptions()
            opz.driverName = "GPKG"
            opz.layerName = nome
            opz.fileEncoding = "UTF-8"
            # mai riscrivere il file intero se esiste gia' (layer aperti = file
            # bloccato da Windows): si sostituisce solo il layer
            opz.actionOnExistingFile = (
                QgsVectorFileWriter.CreateOrOverwriteFile if (primo and not os.path.isfile(gpkg))
                else QgsVectorFileWriter.CreateOrOverwriteLayer)
            err = QgsVectorFileWriter.writeAsVectorFormatV3(
                lyr, gpkg, self.project.transformContext(), opz)
            if (err[0] if isinstance(err, tuple) else err) != QgsVectorFileWriter.NoError:
                esiti.append("%s: NON salvato (%s)" % (nome, err[1] if isinstance(err, tuple) else err))
                continue
            primo = False
            nuovo = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
            if not nuovo.isValid():
                esiti.append("%s: scritto ma non ricaricato" % nome)
                continue
            # stile identico a quello attuale, incorporato nel GeoPackage
            nuovo.setRenderer(lyr.renderer().clone())
            if lyr.labeling() is not None:
                nuovo.setLabeling(lyr.labeling().clone())
            nuovo.setLabelsEnabled(lyr.labelsEnabled())
            nuovo.setOpacity(lyr.opacity())
            nuovo.saveStyleToDatabase(nome, "Stile %s (FTTH Permessi Manager)" % nome, True, "")
            # stesso posto nel gruppo
            nodo = root.findLayer(lyr.id())
            parent = nodo.parent() if nodo is not None else self._rfi_gruppo()
            pos = parent.children().index(nodo) if nodo is not None else 0
            self.project.addMapLayer(nuovo, False)
            parent.insertLayer(pos, nuovo)
            self.project.removeMapLayer(lyr.id())
            esiti.append("%s: salvato" % nome)
        testo = "GeoPackage: %s\n\n%s\n\nGli stili sono incorporati nel file: aprendolo in " \
                "un altro progetto i layer si vedono già così.\nRicorda di salvare il " \
                "progetto." % (gpkg, "\n".join(esiti))
        self._log_rfi(testo)
        QMessageBox.information(self, "Layer RFI salvati", testo)

    def _rfi_layer_id(self, nome):
        for l in self.project.mapLayers().values():
            if l.name() == nome:
                return l.id()
        return None

    def _rfi_sostituisci_layer(self, nome, nuovo):
        for l in list(self.project.mapLayers().values()):
            if l.name() == nome:
                self.project.removeMapLayer(l.id())
        # su file accanto al progetto (GeoPackage di lavoro): riaperto il
        # progetto ferrovia, fascia, cippi e interferenze ci sono ancora
        from . import ftth_memoria as _MEM
        nuovo = _MEM.permanente(self.project, nuovo)
        # direttamente nel gruppo RFI (poi _rfi_ordina_layer sistema l'ordine)
        self.project.addMapLayer(nuovo, False)
        self._rfi_gruppo().addLayer(nuovo)
        return nuovo

    # ------------------------------------------------ trova interferenze
    def _rfi_wkt(self, geom, layer):
        from shapely import wkt as _wkt
        g = QgsGeometry(geom)
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        if layer.crs() != wgs:
            g.transform(QgsCoordinateTransform(layer.crs(), wgs, self.project))
        return _wkt.loads(g.asWkt(8))

    @staticmethod
    def _rfi_val(feat, campo):
        if not campo:
            return ""
        v = feat[campo]
        if v is None:
            return ""
        try:
            if v.isNull():
                return ""
        except AttributeError:
            pass
        return str(v).strip()

    @staticmethod
    def _rfi_campo(layer, *cand):
        nomi = {f.name().lower(): f.name() for f in layer.fields()}
        for c in cand:
            if c.lower() in nomi:
                return nomi[c.lower()]
        return None

    def _rfi_trova_interferenze(self, *_a, bar_nome="bar_rfi_i"):
        # barra del punto 3 (Trova) o del punto 4 (Calcola le chilometriche)
        bar = getattr(self, bar_nome, None) or getattr(self, "bar_rfi_i", None)
        self._rfi_bar_corrente = bar
        self.btn_rfi_trova.setEnabled(False)
        try:
            if bar is not None:
                bar.azzera()
                bar.fase(0, 15, "Lettura della rete e delle ferrovie")
            self._rfi_trova_impl()
            if bar is not None:
                bar.fine("Interferenze trovate: %d" % len(
                    self._rfi_state().get("interferenze") or []))
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_rfi("ERRORE:\n" + traceback.format_exc())
            if bar is not None:
                bar.interrotta("Errore: vedi il registro")
            QMessageBox.critical(self, "Errore", "Ricerca interferenze non riuscita:\n%s" % e)
        finally:
            self.btn_rfi_trova.setEnabled(True)

    def _rfi_trova_impl(self):
        from shapely.geometry import LineString, Point
        rfi = _rfi_mod()
        st = self._rfi_state()
        lay_f = self._find_layer("Ferrovia RFI")
        if lay_f is None or lay_f.featureCount() == 0:
            QMessageBox.warning(self, "Ferrovie mancanti",
                                "Prima premi «Trova le ferrovie e gli enti».")
            return
        lyr_infra = self._find_layer("03 INFRASTRUTTURE")
        if lyr_infra is None:
            QMessageBox.warning(self, "Layer mancante", "Manca '03 INFRASTRUTTURE' nel progetto.")
            return
        kb = _kb()
        # linee ferroviarie con i tag: solo quelle spuntate al punto 2
        tutte = self._rfi_linee_layer(lay_f)
        incluse = self._rfi_linee_incluse()
        linee = [l for l in tutte if incluse is None or self._rfi_chiave_linea(l, kb) in incluse]
        if not linee:
            QMessageBox.warning(self, "Nessuna linea",
                                "Nessuna linea confermata al punto 2: premi «Conferma» sulle "
                                "linee proposte (in giallo).")
            return
        if len(linee) < len(tutte):
            escluse = {self._rfi_chiave_linea(l, kb)[1] for l in tutte} - \
                {self._rfi_chiave_linea(l, kb)[1] for l in linee}
            if escluse:
                self._log_rfi("Linee non spuntate, escluse dalla ricerca: %s"
                              % ", ".join(sorted(escluse)))
        # correzioni gia' fatte in tabella: restano dopo il ricalcolo
        vecchie = {}
        if self.tab_rfi.rowCount() and st.get("interferenze"):
            try:
                for i in self._rfi_leggi_tabella():
                    vecchie[self._rfi_chiave_interf(i)] = i
            except Exception:  # noqa: BLE001
                vecchie = {}
        # tratte
        c_stato = self._rfi_campo(lyr_infra, "STATO")
        c_tipo = self._rfi_campo(lyr_infra, "TIPOLOGIA")
        c_prop = self._rfi_campo(lyr_infra, "PROPRIETA", "PROPRIETAR", "PROPRIETARIO",
                                 "PROPR", "GESTORE", "ENTE", "OWNER")
        c_lung = self._rfi_campo(lyr_infra, "LUNGHEZZA", "Lungh")
        tratte = []
        for f in lyr_infra.getFeatures():
            if not f.hasGeometry():
                continue
            try:
                lung = float(self._rfi_val(f, c_lung).replace(",", ".")) if c_lung else None
            except ValueError:
                lung = None
            tratte.append({"geom": self._rfi_wkt(f.geometry(), lyr_infra),
                           "stato": self._rfi_val(f, c_stato) or "Nuovo",
                           "tecnica": rfi.mappa_tecnica(self._rfi_val(f, c_tipo)),
                           "aerea": rfi.e_aerea(self._rfi_val(f, c_tipo)),
                           "proprietario": self._rfi_val(f, c_prop),
                           "fid": f.id(), "lunghezza": lung if lung and lung > 0 else None})
        armadi = []
        lyr_arm = self._find_layer("01_ARMADIO OTTICO")
        if lyr_arm is not None and lyr_arm.isValid():
            c_ida = self._rfi_campo(lyr_arm, "AREA_AO", "ID_ARMADIO", "ID_ARMAD")  # AREA_AO = numero ARLO
            c_sta = self._rfi_campo(lyr_arm, "STATO")
            for f in lyr_arm.getFeatures():
                if not f.hasGeometry():
                    continue
                g = self._rfi_wkt(f.geometry(), lyr_arm)
                armadi.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                               "stato": self._rfi_val(f, c_sta), "id": self._rfi_val(f, c_ida),
                               "fid": f.id()})
        pozzetti = []
        lyr_poz = self._find_layer("02_POZZETTO")
        if lyr_poz is not None:
            c_dim = self._rfi_campo(lyr_poz, "TIPO_POZZE", "TIPO_POZZETTO", "DIMENSIONE")
            c_sp = self._rfi_campo(lyr_poz, "STATO")
            for f in lyr_poz.getFeatures():
                if not f.hasGeometry():
                    continue
                g = self._rfi_wkt(f.geometry(), lyr_poz)
                pozzetti.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                                 "stato": self._rfi_val(f, c_sp),
                                 "dim": rfi.norm_pozzetto(self._rfi_val(f, c_dim)),
                                 "fid": f.id()})
        # progetto riaperto senza stato: stazioni e cippi dai layer della scheda
        # (senza stazioni le istanze diventavano «TipoD_1», «TipoD_2»)
        for chiave, nome_l, campo in (("stazioni", "Stazioni ferroviarie", "nome"),
                                      ("cippi", "Cippi km RFI", "km")):
            if st.get(chiave):
                continue
            l_ = self._find_layer(nome_l)
            if l_ is None:
                continue
            tr_ = QgsCoordinateTransform(l_.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                                         self.project)
            punti = []
            for f in l_.getFeatures():
                if not f.hasGeometry():
                    continue
                p_ = tr_.transform(f.geometry().centroid().asPoint())
                try:
                    v_ = str(f[campo]) if chiave == "stazioni" else float(f[campo])
                except (TypeError, ValueError, KeyError):
                    continue
                punti.append({("nome" if chiave == "stazioni" else "km"): v_,
                              "lat": p_.y(), "lon": p_.x()})
            st[chiave] = punti
        stazioni = [{"nome": s["nome"], "geom": Point(s["lon"], s["lat"])}
                    for s in st.get("stazioni") or []]
        cippi, per_linea, info_km = self._rfi_cippi_per_linea(linee, kb)
        from .ftth_barra import in_sottofondo
        bar = getattr(self, "_rfi_bar_corrente", None) or getattr(self, "bar_rfi_i", None)
        if bar is not None:
            bar.fase(15, 95, "Ricerca delle interferenze")
        interf = in_sottofondo(bar, rfi.trova_interferenze, linee, tratte, pozzetti, cippi,
                               stazioni, kb, fascia_m=self.spin_rfi_fascia.value(),
                               armadi=armadi,
                               margine_m=self.spin_rfi_margine.value(),
                               cippi_per_linea=per_linea)
        if bar is not None:
            bar.fase(95, 99, "Tabella e layer")
        for i in interf:
            v = vecchie.get(self._rfi_chiave_interf(i))
            if v is not None:
                i.includi, i.tipologia = v.includi, v.tipologia
                i.proprietario = v.proprietario or i.proprietario
                i.foto = v.foto or i.foto
        st["interferenze"] = interf
        st["info_km"] = info_km
        # gestori trovati
        gestori = {}
        for l in linee:
            g = rfi.riconosci_gestore(l["tags"].get("operator"), l["tags"].get("name"), kb)
            gestori.setdefault(g.chiave, g)
        st["gestori"] = gestori
        self._rfi_riempi_tabella(interf, gestori)
        self._rfi_riempi_km(interf, info_km)
        try:    # tendina «linea» del layer cippi allineata alle interferenze
            from . import ftth_trovati as _TR
            for l in self.project.mapLayersByName("Cippi_Ferrovia"):
                _TR.tendina_campo(l, "linea", self._rfi_linee_per_cippi())
        except Exception:  # noqa: BLE001
            pass
        self._rfi_riempi_destinatari(gestori, conserva=True)
        if self.cb_rfi_doit.count() == 0:
            self._rfi_riempi_doit()
        self._rfi_layer_interferenze(interf)
        try:
            self._rfi_scrivi_chilometriche(interf)
        except Exception as e:  # noqa: BLE001
            self._log_rfi("Campo Chilometrica non scritto negli shape: %s" % e)
        n = {}
        for i in interf:
            n[i.tipologia] = n.get(i.tipologia, 0) + 1
        self._log_rfi("Interferenze trovate: %d (%s)" % (
            len(interf), ", ".join("%s: %d" % (k or "—", v) for k, v in sorted(n.items(), key=str))))
        if not interf:
            QMessageBox.information(self, "Nessuna interferenza",
                                    "Nessuna tratta del progetto entra nella fascia di rispetto.")

    def _rfi_scrivi_chilometriche(self, interf):
        """Campo Chilometrica negli shape principali (come Istanze Strade):
        «dal km X al km Y» sulle tratte, il km su pozzetti e armadi."""
        rfi = _rfi_mod()
        val = {"tratte": {}, "pozzetti": {}, "armadi": {}}
        for i in interf:
            if rfi.km_valore(i.km_da) is None:
                continue
            testo = rfi.etichetta_km(i.km_da, i.km_a)
            for fid in i.tratte_fid or []:
                if fid is not None:
                    val["tratte"][int(fid)] = testo
            for e in i.elementi or []:
                if e.get("fid") is None or not e.get("km") or \
                        rfi.km_valore(e.get("km")) is None:
                    continue
                k = "armadi" if str(e.get("tipo", "")).startswith("armadio") else "pozzetti"
                val[k][int(e["fid"])] = "km %s" % e["km"]
        n = 0
        mancanti = []
        for chiave, nome in (("tratte", "03 INFRASTRUTTURE"), ("pozzetti", "02_POZZETTO"),
                             ("armadi", "01_ARMADIO OTTICO")):
            l = self._find_layer(nome)
            if l is None or not val[chiave]:
                continue
            # mai aggiungere campi agli shape aperti in QGIS (su certi shapefile
            # dava «Errore OGR nell'impostare l'elemento» e i pozzetti sparivano):
            # si scrive solo in un campo di TESTO che c'è già
            k = -1
            for nome_c in ("Chilometrica", "Chilometri", "CHILOMETRICA", "CHILOMETRI", "KM_RFI"):
                kk = l.fields().indexOf(nome_c)
                if kk >= 0 and l.fields().at(kk).type() == QVariant.String:
                    k = kk
                    break
            if k < 0:
                mancanti.append(nome)
                continue
            if l.isEditable():
                for fid, t_ in val[chiave].items():
                    l.changeAttributeValue(fid, k, t_)
            elif not l.dataProvider().changeAttributeValues(
                    {fid: {k: t_} for fid, t_ in val[chiave].items()}):
                self._log_rfi("Chilometrica NON scritta in %s: il file non accetta la modifica." % nome)
                continue
            l.triggerRepaint()
            n += len(val[chiave])
        if mancanti:
            self._log_rfi("Chilometrica non scritta in %s: manca un campo di testo «Chilometrica» "
                          "(aggiungilo tu al layer se ti serve; il plugin non modifica la "
                          "struttura degli shape)." % ", ".join(mancanti))
        if n:
            self._log_rfi("Campo Chilometrica scritto negli shape su %d elementi." % n)

    def _rfi_linee_per_cippi(self):
        """Linee per la tendina dei cippi: quelle delle interferenze, o le
        linee spuntate al punto 2."""
        st = self._rfi_state()
        nomi = [i.linea for i in st.get("interferenze") or [] if getattr(i, "includi", True)]
        if not nomi:
            incl = self._rfi_linee_incluse()
            nomi = [x["nome"] for x in st.get("linee") or []
                    if incl is None or x["chiave"] in incl]
        return list(dict.fromkeys(n for n in nomi if n))

    def _rfi_crea_layer_cippi(self):
        """Crea (se manca) «Cippi_Ferrovia» (linea, km) accanto al progetto,
        con la linea da una tendina; lo sceglie per il calcolo e mette a
        disegnare."""
        from . import ftth_trovati as _TR
        linee = self._rfi_linee_per_cippi()
        vl, err = _TR.crea_layer_cippi(self.project, getattr(self, "iface", None),
                                       "Cippi_Ferrovia", "linea", linee)
        if vl is None:
            QMessageBox.warning(self, "Crea il layer cippi", err)
            return
        self.cb_rfi_cippi.setLayer(vl)
        self.cb_rfi_cippi_campo.setLayer(vl)
        self.cb_rfi_cippi_campo.setField("km")
        testo = ("Layer «Cippi_Ferrovia» pronto, in modifica e scelto per il calcolo.\n\n"
                 "Clicca sulla mappa ogni cippo del binario: nel modulo scegli la linea dalla "
                 "tendina (%s) e scrivi il km (es. 29+417). Poi salva le modifiche del layer e "
                 "premi «Calcola le chilometriche»."
                 % ("; ".join(linee) if linee else "trova prima ferrovie e interferenze"))
        self._log_rfi(testo)
        QMessageBox.information(self, "Crea il layer cippi", testo)

    def _rfi_cippi_progetto(self, lyr=None, campo=None):
        """Cippi {km, lat, lon} dal layer scelto nella scheda, o [] se non c'e'.
        Il km si legge con il parser delle chilometriche del plugin
        ('KM 29+417', '29+417', '29,417' ...)."""
        if lyr is None:
            lyr = self.cb_rfi_cippi.currentLayer()
            campo = self.cb_rfi_cippi_campo.currentField()
        if lyr is not None and (not campo or campo.lower() in ("fid", "id", "ogc_fid")):
            from . import ftth_trovati as _TRk
            campo = _TRk.campo_km(lyr) or campo     # «fid» non è il km
        if lyr is None or not campo:
            return []
        try:
            from . import ftth_core as core
        except ImportError:
            import ftth_core as core
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(lyr.crs(), wgs, self.project)
        # campo con la linea del cippo (layer creato dal plugin: «linea»)
        c_lin = self._rfi_campo(lyr, "linea", "binario", "LINEA")
        out, scartati = [], 0
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            metri = core.parse_chilometrica(self._rfi_val(f, campo))
            if metri is None:
                scartati += 1
                continue
            g = QgsGeometry(f.geometry())
            g.transform(tr)
            p = g.centroid().asPoint()
            out.append({"km": metri / 1000.0, "lat": p.y(), "lon": p.x(),
                        "linea": self._rfi_val(f, c_lin) if c_lin else ""})
        if scartati:
            self._log_rfi("Cippi: %d valori del campo '%s' non interpretabili, scartati."
                          % (scartati, campo))
        return out

    def _rfi_riempi_tabella(self, interf, gestori):
        t = self.tab_rfi
        t.setRowCount(0)
        for i in interf:
            r = t.rowCount()
            t.insertRow(r)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked if i.includi else Qt.Unchecked)
            t.setItem(r, C_INCL, chk)
            idi = QTableWidgetItem(str(i.id))
            idi.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            idi.setData(Qt.UserRole, i.id)
            t.setItem(r, C_ID, idi)
            cb = QComboBox()
            for k in TIPI_COMBO:
                cb.addItem(DESCR_TIPO[k], k)
            cb.setCurrentIndex(TIPI_COMBO.index(i.tipologia if i.tipologia in TIPI_COMBO else "—"))
            # tipologia cambiata in tabella: subito anche in mappa
            cb.currentIndexChanged.connect(
                lambda _i, iid=i.id, c=cb: self._rfi_tipo_in_mappa(iid, c.currentData()))
            t.setCellWidget(r, C_TIPO, cb)
            g = gestori.get(i.gestore)
            gi = QTableWidgetItem(g.nome if g else i.gestore)
            gi.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            gi.setData(Qt.UserRole, i.gestore)
            t.setItem(r, C_GEST, gi)
            self._rfi_menu_gestore(
                t, r, C_GEST, g or _rfi_mod().Gestore(chiave=i.gestore, nome=i.gestore,
                                                     sigla=i.gestore.upper()),
                lambda nuovo, it_=gi: self._rfi_cambia_gestore_interf(it_, nuovo))
            t.setItem(r, C_LINEA, QTableWidgetItem(i.linea))
            t.setItem(r, C_STAZ, QTableWidgetItem(i.stazione))
            t.setItem(r, C_KMDA, QTableWidgetItem(i.km_da))
            t.setItem(r, C_KMA, QTableWidgetItem(i.km_a))
            rfi = _rfi_mod()
            metri = ", ".join("%s %s m" % (rfi.ETICH_TECNICA[k], rfi._fmt_num(v))
                              for k, v in i.metri.items() if v)
            for col, testo in ((C_METRI, metri or "—"),
                               (C_POZZ, ", ".join("%s×%d" % (d, n) for d, n in i.pozzetti.items()) or "—"),
                               (C_DIST, "attraversa" if i.attraversa else
                                ("%.1f" % i.dist_min_m if i.dist_min_m is not None else "")),
                               (C_NOTE, "; ".join(i.note))):
                it = QTableWidgetItem(testo)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if col == C_NOTE and i.note:
                    it.setForeground(QColor(170, 60, 0))
                t.setItem(r, col, it)
            t.setItem(r, C_PROPR, QTableWidgetItem(i.proprietario))
            fi = QTableWidgetItem(i.foto)
            fi.setToolTip("Doppio clic per scegliere la foto")
            t.setItem(r, C_FOTO, fi)
        t.resizeColumnsToContents()

    def _rfi_cambia_gestore_interf(self, item, nuovo):
        """Gestore cambiato su una riga del punto 3: vale per quella
        interferenza; il nuovo gestore entra fra i destinatari (punto 4)."""
        rfi = _rfi_mod()
        st = self._rfi_state()
        r = item.row()
        i, _ = self._rfi_riga_interferenza(r)
        g = rfi.riconosci_gestore(nuovo, i.linea if i is not None else "", _kb())
        if g.chiave == "rfi" and self.cb_rfi_doit.currentData():
            c = self.cb_rfi_doit.currentData()
            g = rfi.destinatario_rfi(g, c.get("doit") or "", "", c.get("pec") or "")
        item.setData(Qt.UserRole, g.chiave)
        item.setText(g.nome)
        if i is not None:
            i.gestore = g.chiave
        gest = st.setdefault("gestori", {})
        if g.chiave not in gest:
            gest[g.chiave] = g
            self._rfi_riempi_destinatari(gest, conserva=True)
            self._rfi_applica_doit()
        self._log_rfi("Interferenza %s: gestore %s." % (i.id if i is not None else r + 1, g.nome))

    def _rfi_riempi_destinatari(self, gestori, conserva=False):
        """Una riga per gestore. Con `conserva` i destinatari gia' corretti a
        mano (stesso gestore) restano come sono."""
        t = self.tab_rfi_dest
        prima = {}
        if conserva:
            for r in range(t.rowCount()):
                it = t.item(r, 0)
                if it is not None:
                    prima[it.data(Qt.UserRole)] = [
                        t.item(r, c).text() if t.item(r, c) else "" for c in (1, 2, 3)]
        t.setRowCount(0)
        for k, g in gestori.items():
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem(g.nome)
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            it.setData(Qt.UserRole, k)
            t.setItem(r, 0, it)
            valori = prima.get(k) or [g.dest_nome, g.dest_indirizzo, g.dest_pec]
            for c, val in zip((1, 2, 3), valori):
                t.setItem(r, c, QTableWidgetItem(val))
        t.resizeColumnsToContents()
        if not prima:
            self._rfi_applica_doit()

    def _rfi_da_screening(self, rep):
        """Punto 2 dalle ferrovie scaricate dallo screening (niente nuova
        richiesta a OSM). Cippi e stazioni non ci sono: per le progressive
        si preme «Trova le ferrovie e gli enti»."""
        d = rep.get("comune") or {}
        if d.get("nome") and not self.txt_rfi_comune.text().strip():
            self.txt_rfi_comune.setText(d["nome"].upper())
            self._rfi_imposta_prov_cap(d.get("provincia"), d.get("cap"))
            self._rfi_state()["_ultimo_comune"] = d["nome"].lower()
        st = self._rfi_state()
        if d.get("regione"):
            st["regione"] = d["regione"]
        ways = [e for e in rep.get("_elementi_lineari") or []
                if e.get("type") == "way" and e.get("geometry") and
                (e.get("tags") or {}).get("railway") in ("rail", "narrow_gauge", "light_rail")]
        if not ways:
            return "nessuna ferrovia vicino al progetto" if rep.get("_elementi_lineari") \
                else ""
        st["ways"] = ways
        lay = self._rfi_layer_linea(ways)
        self._rfi_layer_fascia(lay, self.spin_rfi_fascia.value())
        self._rfi_ordina_layer()
        self._rfi_riempi_linee()
        self._log_rfi("Ferrovie dallo screening: per cippi km e stazioni premi «Trova le "
                      "ferrovie e gli enti».")
        n = sum(1 for x in st.get("linee") or [] if x["metri"] > 0)
        return "%d linee, %d con rete in fascia (cippi e stazioni: «Trova le ferrovie»)" % (
            len(st.get("linee") or []), n)

    # ---------------------------------- punto 2: linee, enti, mappa, fonti
    def _rfi_linee_layer(self, lay_f=None):
        """[{geom: LineString WGS84, tags, fonte}] dal layer «Ferrovia RFI»."""
        from shapely.geometry import LineString
        lay_f = lay_f or self._find_layer("Ferrovia RFI")
        if lay_f is None:
            return []
        nomi = lay_f.fields().names()
        out = []
        for f in lay_f.getFeatures():
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lay_f)
            tags = {k: (self._rfi_val(f, c) if c in nomi else "")
                    for k, c in (("name", "nome"), ("ref", "ref"), ("operator", "operator"))}
            fonte = (self._rfi_val(f, "fonte") if "fonte" in nomi else "") or "OSM"
            for parte in getattr(g, "geoms", [g]):
                if isinstance(parte, LineString):
                    out.append({"geom": parte, "tags": tags, "fonte": fonte})
        return out

    @staticmethod
    def _rfi_chiave_linea(linea, kb):
        """(gestore, nome nei documenti): come la ricerca raggruppa le linee."""
        rfi = _rfi_mod()
        t = linea.get("tags") or {}
        g = rfi.riconosci_gestore(t.get("operator", ""), t.get("name", ""), kb or {})
        return g.chiave, rfi.nome_linea_osm(t)

    def _rfi_rete_wgs(self):
        lyr = self._find_layer("03 INFRASTRUTTURE")
        if lyr is None:
            return []
        return [self._rfi_wkt(f.geometry(), lyr) for f in lyr.getFeatures() if f.hasGeometry()]

    def _rfi_valida_riga(self, r):
        """Colori e pulsanti Conferma / Escludi della riga r (come in Strade):
        gialla = proposta (rete in fascia), verde = confermata (spuntata)."""
        t = self.tab_rfi_lin
        it = t.item(r, 0)
        if it is None:
            return
        conf = it.checkState() == Qt.Checked
        metri = it.data(Qt.UserRole + 1) or 0
        fondo = QColor(214, 240, 214) if conf else (QColor(255, 243, 190) if metri > 0 else None)
        for c in (1, 2, 4):
            x = t.item(r, c)
            if x is not None:
                x.setBackground(fondo if fondo is not None else QColor(0, 0, 0, 0))
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(2, 0, 2, 0)
        h.setSpacing(4)
        chiave = tuple(it.data(Qt.UserRole))
        if conf:
            lab = QLabel("✔ confermata")
            lab.setStyleSheet("color:#1b7a2f; font-weight:bold")
            h.addWidget(lab)
            b = QPushButton("Annulla")
            b.clicked.connect(lambda _=False, k=chiave: self._rfi_conferma_linea(k, False))
            h.addWidget(b)
        else:
            b_ok = QPushButton("Conferma")
            b_ok.setToolTip("La linea entra nella ricerca delle interferenze.")
            b_ok.clicked.connect(lambda _=False, k=chiave: self._rfi_conferma_linea(k, True))
            b_ko = QPushButton("Escludi")
            b_ko.setToolTip("La linea esce dall'elenco e dalla ricerca.")
            b_ko.clicked.connect(lambda _=False, k=chiave: self._rfi_escludi_linea(k))
            h.addWidget(b_ok)
            h.addWidget(b_ko)
        t.setCellWidget(r, COL_VALIDA, w)

    def _rfi_riga_linea(self, chiave):
        t = self.tab_rfi_lin
        for r in range(t.rowCount()):
            it = t.item(r, 0)
            if it is not None and tuple(it.data(Qt.UserRole)) == tuple(chiave):
                return r
        return -1

    def _rfi_conferma_linea(self, chiave, si):
        r = self._rfi_riga_linea(chiave)
        if r < 0:
            return
        self.tab_rfi_lin.item(r, 0).setCheckState(Qt.Checked if si else Qt.Unchecked)
        self._rfi_valida_riga(r)
        self._log_rfi("%s %s." % ("Confermata" if si else "Conferma tolta:", chiave[1]))

    def _rfi_escludi_linea(self, chiave):
        st = self._rfi_state()
        st.setdefault("linee_escluse", set()).add(tuple(chiave))
        r = self._rfi_riga_linea(chiave)
        if r >= 0:
            self.tab_rfi_lin.removeRow(r)
        st["linee"] = [x for x in st.get("linee") or [] if x["chiave"] != tuple(chiave)]
        self._log_rfi("Esclusa %s." % chiave[1])

    def _rfi_riempi_linee(self):
        """Tabella del punto 2: una riga per linea (gestore + nome), con il
        destinatario e i metri di rete nella fascia. Le spunte gia' date per
        la stessa linea restano."""
        from shapely.ops import unary_union
        rfi = _rfi_mod()
        st = self._rfi_state()
        kb = _kb()
        prima = {}
        t = self.tab_rfi_lin
        for r in range(t.rowCount()):
            it = t.item(r, 0)
            if it is not None:
                prima[tuple(it.data(Qt.UserRole))] = it.checkState() == Qt.Checked
        gruppi = {}
        for l in self._rfi_linee_layer():
            k = self._rfi_chiave_linea(l, kb)
            d = gruppi.setdefault(k, {"geoms": [], "fonti": set(), "tags": l["tags"]})
            d["geoms"].append(l["geom"])
            d["fonti"].add(l["fonte"])
        rete = self._rfi_rete_wgs()
        linee, gestori = [], {}
        fascia = self.spin_rfi_fascia.value()
        marg = self.spin_rfi_margine.value()
        for k, d in gruppi.items():
            asse = unary_union(d["geoms"])
            metri, dist = 0.0, None
            if rete:
                pr = rfi._Proiezione(asse.centroid.x, asse.centroid.y)
                am = pr.avanti(asse)
                rm = unary_union([pr.avanti(g) for g in rete])
                metri = rm.intersection(am.buffer(fascia + marg)).length
                dist = max(0.0, rm.distance(am) - marg)
            g = rfi.riconosci_gestore(d["tags"].get("operator", ""), d["tags"].get("name", ""), kb)
            gestori.setdefault(g.chiave, g)
            if k in (st.get("linee_escluse") or set()):
                continue            # esclusa dall'utente con «Escludi»
            # le proposte (rete in fascia) NON si spuntano: si confermano
            linee.append({"chiave": k, "nome": k[1], "gestore": g, "geom": asse,
                          "metri": metri, "dist": dist, "fonte": ", ".join(sorted(d["fonti"])),
                          "includi": prima.get(k, k in (st.get("linee_confermate") or ()))})
        linee.sort(key=lambda x: (-x["metri"], x["nome"]))
        st["linee"] = linee
        t.blockSignals(True)
        t.setRowCount(0)
        for x in linee:
            r = t.rowCount()
            t.insertRow(r)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked if x["includi"] else Qt.Unchecked)
            chk.setData(Qt.UserRole, list(x["chiave"]))
            chk.setData(Qt.UserRole + 1, x["metri"])
            t.setItem(r, 0, chk)
            dest = x["gestore"].dest_nome or x["gestore"].nome
            self._rfi_menu_gestore(t, r, 2, x["gestore"],
                                   lambda nuovo, k=x["chiave"]: self._rfi_cambia_gestore_linea(k, nuovo))
            for c, val in ((1, x["nome"]), (2, x["gestore"].nome), (3, dest),
                           (4, "%d" % round(x["metri"])),
                           (5, "" if x["dist"] is None else "%.1f" % x["dist"]),
                           (6, x["fonte"])):
                it = QTableWidgetItem(val)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if c == 4 and x["metri"] > 0:
                    it.setForeground(QColor(180, 0, 0))
                t.setItem(r, c, it)
            self._rfi_valida_riga(r)
        t.blockSignals(False)
        t.resizeColumnsToContents()
        # enti: i destinatari si vedono subito (punto 4)
        st["gestori"] = gestori
        self._rfi_riempi_destinatari(gestori, conserva=True)
        if self.cb_rfi_doit.count() == 0:
            self._rfi_riempi_doit()
        # destinatario come nel punto 4 (con la DOIT RFI quando c'e')
        dest = {}
        for r in range(self.tab_rfi_dest.rowCount()):
            it, d1 = self.tab_rfi_dest.item(r, 0), self.tab_rfi_dest.item(r, 1)
            if it is not None and d1 is not None and d1.text().strip():
                dest[it.data(Qt.UserRole)] = d1.text().strip()
        for r, x in enumerate(linee):
            if x["gestore"].chiave in dest:
                t.item(r, 3).setText(dest[x["gestore"].chiave])
        prop = sum(1 for x in linee if x["metri"] > 0)
        self._log_rfi("Linee trovate: %d, con rete nella fascia: %d — %s" % (
            len(linee), prop, "; ".join("%s (%s, %d m)" % (x["nome"], x["gestore"].nome,
                                                          round(x["metri"])) for x in linee)
            or "nessuna"))

    def _rfi_menu_gestore(self, t, r, col, gestore, al_cambio):
        """Menu del gestore nella cella (r, col): i gestori noti più quello
        attuale; si può anche scrivere un nome nuovo (+ Invio)."""
        rfi = _rfi_mod()
        cb = QComboBox()
        cb.setEditable(True)
        nomi = [str(g.get("nome") or g.get("chiave")) for g in rfi._kb_gestori(_kb())]
        if gestore.nome not in nomi:
            nomi.insert(0, gestore.nome)
        cb.addItems(nomi)
        cb.setCurrentText(gestore.nome)
        cb.setToolTip("Gestore della linea: sceglilo dall'elenco o scrivilo e premi Invio.")

        def _ok(*_a, c=cb):
            nuovo = c.currentText().strip()
            if nuovo and nuovo != gestore.nome:
                al_cambio(nuovo)
        cb.activated.connect(_ok)
        cb.lineEdit().editingFinished.connect(_ok)
        t.setCellWidget(r, col, cb)

    def _rfi_cambia_gestore_linea(self, chiave, nuovo):
        """Gestore cambiato a mano: si scrive nel layer «Ferrovia RFI» (campo
        operator dei tratti della linea), così vale per la ricerca delle
        interferenze, i destinatari e le istanze, anche dopo la riapertura."""
        from qgis.PyQt.QtCore import QTimer
        kb = _kb()
        lay = self._find_layer("Ferrovia RFI")
        if lay is None:
            return
        k_op = lay.fields().indexOf("operator")
        if k_op < 0:
            return
        modifiche = {}
        for f in lay.getFeatures():
            l = {"tags": {"name": self._rfi_val(f, "nome"), "ref": self._rfi_val(f, "ref"),
                          "operator": self._rfi_val(f, "operator")}}
            if self._rfi_chiave_linea(l, kb) == tuple(chiave):
                modifiche[f.id()] = {k_op: nuovo}
        if not modifiche:
            return
        if lay.isEditable():
            for fid, v in modifiche.items():
                lay.changeAttributeValue(fid, k_op, v[k_op])
        else:
            lay.dataProvider().changeAttributeValues(modifiche)
        lay.triggerRepaint()
        # la spunta resta sulla linea anche se cambia la sua chiave
        r = self._rfi_riga_linea(chiave)
        conf = r >= 0 and self.tab_rfi_lin.item(r, 0).checkState() == Qt.Checked
        rfi = _rfi_mod()
        g = rfi.riconosci_gestore(nuovo, chiave[1], kb)
        st = self._rfi_state()
        if conf:
            st.setdefault("linee_confermate", set()).add((g.chiave, chiave[1]))
        self._log_rfi("Gestore di %s: %s. Premi di nuovo «Trova le interferenze» per "
                      "aggiornare la tabella del punto 3." % (chiave[1], g.nome))
        # la tabella si rifà dopo (il menu che ha chiamato sta per essere tolto)
        QTimer.singleShot(0, self._rfi_riempi_linee)

    def _rfi_linee_incluse(self):
        """Chiavi delle linee spuntate al punto 2 (None = tabella vuota: tutte)."""
        t = getattr(self, "tab_rfi_lin", None)
        if t is None or t.rowCount() == 0:
            return None
        return {tuple(t.item(r, 0).data(Qt.UserRole)) for r in range(t.rowCount())
                if t.item(r, 0).checkState() == Qt.Checked}

    def _rfi_zoom_linea(self, r, _c=None):
        from . import ftth_trovati as _TR
        linee = self._rfi_state().get("linee") or []
        if 0 <= r < len(linee):
            _TR.zoom(getattr(self, "iface", None), self.project, linee[r]["geom"])

    def _rfi_mostra_linee(self):
        from . import ftth_trovati as _TR
        linee = self._rfi_state().get("linee") or []
        if not linee:
            QMessageBox.information(self, "Nessuna linea",
                                    "Prima premi «Trova le ferrovie e gli enti».")
            return
        incl = self._rfi_linee_incluse() or set()
        voci = [(x["geom"], {"linea": x["nome"], "gestore": x["gestore"].nome,
                             "metri_in_fascia": "%d" % round(x["metri"]),
                             "etichetta": "%s — %s" % (x["nome"], x["gestore"].nome)})
                for x in linee if x["chiave"] in incl]
        if not voci:
            QMessageBox.information(self, "Nessuna linea", "Nessuna linea spuntata.")
            return
        try:
            _TR.mostra_in_mappa(self.project, "rfi", "Ferrovie trovate", voci, "etichetta",
                                "ferrovie")
            self._log_rfi("In mappa: %d linee nel gruppo «Istanze > … > Trovati»." % len(voci))
            self.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Mostra in mappa", "Non riuscito: %s" % e)

    def _rfi_da_layer(self):
        """Ferrovie da un layer di linee del progetto (altre fonti): entrano in
        «Ferrovia RFI»; una linea con lo stesso nome di una OSM la sostituisce."""
        from qgis.core import QgsFeatureRequest
        from shapely.geometry import LineString
        lyr = self.cb_rfi_alt.currentLayer()
        if lyr is None:
            QMessageBox.warning(self, "Altre fonti", "Scegli il layer delle ferrovie.")
            return
        bbox = self._rfi_bbox_progetto(margine=0.02)
        if bbox is None:
            QMessageBox.warning(self, "Progetto senza layer", "Servono i layer di progetto "
                                "(03 INFRASTRUTTURE …) per delimitare l'area.")
            return
        c_nom = self.cb_rfi_alt_nome.currentField()
        c_gest = self.cb_rfi_alt_gest.currentField()
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        rett = QgsCoordinateTransform(wgs, lyr.crs(), self.project).transformBoundingBox(
            QgsRectangle(bbox[1], bbox[0], bbox[3], bbox[2]))
        nuove = []
        for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(rett)):
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            tags = {"name": self._rfi_val(f, c_nom) if c_nom else "", "ref": "",
                    "operator": self._rfi_val(f, c_gest) if c_gest else ""}
            for parte in getattr(g, "geoms", [g]):
                if isinstance(parte, LineString):
                    nuove.append({"geom": parte, "tags": tags, "fonte": lyr.name()})
        if not nuove:
            QMessageBox.information(self, "Altre fonti",
                                    "Nessuna linea del layer attorno al progetto.")
            return
        kb = _kb()
        chiavi = {self._rfi_chiave_linea(l, kb) for l in nuove}
        # il layer si rilegge tutto; le linee OSM con lo stesso nome escono
        tenute = [l for l in self._rfi_linee_layer()
                  if l["fonte"] != lyr.name() and self._rfi_chiave_linea(l, kb) not in chiavi]
        lay = self._rfi_layer_linea_da([(l["geom"], l["tags"], l["fonte"])
                                        for l in tenute + nuove])
        self._rfi_layer_fascia(lay, self.spin_rfi_fascia.value())
        self._rfi_ordina_layer()
        self._rfi_riempi_linee()
        self._log_rfi("Da «%s»: %d tratti, linee %s." % (
            lyr.name(), len(nuove), ", ".join(sorted(k[1] for k in chiavi))))

    # ------------------------------- punto 3: interferenze in mappa, zoom
    @staticmethod
    def _rfi_chiave_interf(i):
        return (i.gestore, i.linea, tuple(sorted(str(f) for f in i.tratte_fid)),
                bool(i.attraversa))

    def _rfi_geom_interferenza(self, i):
        from shapely.geometry import Point, box
        if getattr(i, "bbox", None):
            try:
                return box(*i.bbox)
            except Exception:  # noqa: BLE001
                pass
        return Point(i.lon, i.lat)

    def _rfi_mostra_interferenze(self):
        from . import ftth_trovati as _TR
        from shapely.geometry import Point
        interf = [i for i in (self._rfi_state().get("interferenze") or [])]
        if not interf:
            QMessageBox.information(self, "Nessuna interferenza",
                                    "Prima premi «Trova le interferenze».")
            return
        incl = [i for i in self._rfi_leggi_tabella() if i.includi]
        if not incl:
            QMessageBox.information(self, "Nessuna interferenza", "Nessuna interferenza spuntata.")
            return
        lyr = self._find_layer("03 INFRASTRUTTURE")
        geom_fid = {}
        if lyr is not None:
            fids = {f for i in incl for f in i.tratte_fid}
            from qgis.core import QgsFeatureRequest
            for f in lyr.getFeatures(QgsFeatureRequest().setFilterFids(list(fids))):
                if f.hasGeometry():
                    geom_fid[f.id()] = self._rfi_wkt(f.geometry(), lyr)
        scavi, punti = [], []
        for i in incl:
            etich = "n. %d tipo %s" % (i.id, i.tipologia or "—")
            base = {"id": i.id, "tipologia": i.tipologia or "—", "linea": i.linea,
                    "km": _rfi_mod().etichetta_km(i.km_da, i.km_a), "etichetta": etich}
            for fid in i.tratte_fid:
                if fid in geom_fid:
                    scavi.append((geom_fid[fid], base))
            for e in i.elementi:
                if e.get("tipo") in ("pozzetto", "armadio") and "lon" in e:
                    punti.append((Point(e["lon"], e["lat"]),
                                  dict(base, elemento=e["tipo"], dim=e.get("dim") or "")))
        try:
            if scavi:
                _TR.mostra_in_mappa(self.project, "rfi", "Interferenze ferrovie - scavi", scavi,
                                    "etichetta", "interferenze")
            if punti:
                _TR.mostra_in_mappa(self.project, "rfi",
                                    "Interferenze ferrovie - pozzetti e armadi", punti,
                                    None, "interferenze")
            self._log_rfi("In mappa: %d interferenze (%d scavi, %d pozzetti/armadi)."
                          % (len(incl), len(scavi), len(punti)))
            self.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Mostra in mappa", "Non riuscito: %s" % e)

    # ------------------------------ punto 4: progressive per ogni linea
    def _rfi_cippi_per_linea(self, linee, kb):
        """(cippi di base, {nome linea: cippi}, info per la tabella del punto 4).
        Per ogni linea valgono i cippi scelti nella sua riga; dei cippi si
        tengono quelli sulla linea (entro 150 m) se sono almeno due."""
        from shapely.geometry import Point
        from shapely.ops import unary_union
        rfi = _rfi_mod()
        st = self._rfi_state()
        osm = st.get("cippi") or []
        base_lyr = self.cb_rfi_cippi.currentLayer()
        base = self._rfi_cippi_progetto() if base_lyr is not None else []
        if base:
            base_nome = "layer «%s»" % base_lyr.name()
            self._log_rfi("Km stimati dai cippi del layer '%s' (%d cippi)."
                          % (base_lyr.name(), len(base)))
        else:
            base, base_nome = osm, "cippi OSM"
        geom = {}
        for l in linee:
            geom.setdefault(self._rfi_chiave_linea(l, kb)[1], []).append(l["geom"])
        righe = getattr(self, "_rfi_km_w", None) or {}
        per_linea, info = {}, {}
        for nome, gg in geom.items():
            modo, lyr, campo = "", None, None
            w = righe.get(nome)
            if w:
                try:
                    modo = w[0].currentData() or ""
                    lyr, campo = w[1].currentLayer(), w[2].currentField()
                except RuntimeError:
                    modo = ""
            if modo == "osm":
                lista, fonte = osm, "cippi OSM"
            elif modo == "layer" and lyr is not None and campo:
                lista, fonte = self._rfi_cippi_progetto(lyr, campo), "layer «%s»" % lyr.name()
            elif modo == "nessuno":
                lista, fonte = [], "nessuno"
            else:
                lista, fonte = base, base_nome
                if base is not osm and osm:
                    # automatico: se il layer del progetto non ha almeno 2 cippi
                    # su questa linea, si prova con quelli di OSM
                    from shapely.geometry import Point as _Pt
                    from shapely.ops import unary_union as _uu
                    _a = _uu(gg)
                    _pr = rfi._Proiezione(_a.centroid.x, _a.centroid.y)
                    _am = _pr.avanti(_a)

                    def _sulla(l_):
                        return sum(1 for c in l_ if _am.distance(
                            _pr.avanti(_Pt(c["lon"], c["lat"]))) <= 150)
                    if _sulla(base) < 2 <= _sulla(osm):
                        lista, fonte = osm, "cippi OSM (nel layer del progetto non ce n'erano)"
            # cippi con la linea scritta (layer creato dal plugin): solo quelli
            # di questa linea; quelli senza linea valgono per tutte
            # «Bari – Taranto» = «Bari-Taranto»: stessa linea anche nei cippi
            from . import ftth_gruppi_istanze as _GRk
            lista = [c for c in lista if not c.get("linea") or
                     _GRk.chiave_nome(c["linea"]) == _GRk.chiave_nome(nome)]
            asse = unary_union(gg)
            pr = rfi._Proiezione(asse.centroid.x, asse.centroid.y)
            am = pr.avanti(asse)
            sulla = [c for c in lista if am.distance(pr.avanti(Point(c["lon"], c["lat"]))) <= 150]
            if len(sulla) >= 2:
                lista = sulla
            per_linea[nome] = lista
            info[nome] = {"fonte": fonte, "sulla": len(sulla), "totali": len(lista),
                          "modo": modo}
        return base, per_linea, info

    def _rfi_riempi_km(self, interf, info):
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
        rfi = _rfi_mod()
        t = self.tab_rfi_km
        vecchie = {}
        for nome, (cb_f, cb_l, cb_c) in (getattr(self, "_rfi_km_w", None) or {}).items():
            try:
                vecchie[nome] = (cb_f.currentData(), cb_l.currentLayer(), cb_c.currentField())
            except RuntimeError:
                pass
        self._rfi_km_w = {}
        t.setRowCount(0)
        for nome in sorted(info):
            mie = [i for i in interf if i.linea == nome]
            ok = sum(1 for i in mie if rfi.km_valore(i.km_da) is not None)
            r = t.rowCount()
            t.insertRow(r)
            cb_f = QComboBox()
            for testo, dato in MODI_KM:
                cb_f.addItem(testo, dato)
            cb_l = QgsMapLayerComboBox()
            cb_l.setFilters(QgsMapLayerProxyModel.PointLayer)
            cb_l.setAllowEmptyLayer(True)
            cb_l.setLayer(None)
            cb_c = QgsFieldComboBox()
            from . import ftth_trovati as _TRk
            cb_l.layerChanged.connect(lambda l, c=cb_c: _TRk.scegli_campo_km(c, l))
            # scegliere un layer nella riga vuol dire usarlo
            cb_l.layerChanged.connect(
                lambda l, f=cb_f: l is not None and f.setCurrentIndex(f.findData("layer")))
            for w_ in (cb_f, cb_l, cb_c):
                w_.setProperty("non_memorizzare", True)
            v = vecchie.get(nome)
            if v:
                if v[1] is not None:
                    cb_l.setLayer(v[1])
                    if v[2] and v[2].lower() not in ("fid", "id", "ogc_fid"):
                        cb_c.setField(v[2])
                cb_f.setCurrentIndex(max(0, cb_f.findData(v[0] or "")))
            k = info[nome]
            if not mie:
                stato = "nessuna interferenza su questa linea"
            elif k.get("modo") == "nessuno":
                stato = "scelto «solo coordinate»: km da compilare a mano"
            elif ok == len(mie):
                stato = "✔ km calcolato su tutte le %d interferenze" % len(mie)
            elif ok:
                stato = ("km calcolato su %d interferenze su %d: le altre sono lontane dai "
                         "cippi, da compilare" % (ok, len(mie)))
            elif k["sulla"] < 2:
                stato = ("nessun cippo utile su questa linea (ne servono 2): km da compilare. "
                         "Aggiungili con «Crea il layer cippi» o scegli un'altra fonte")
            else:
                stato = ("cippi trovati ma i loro km non tornano con le distanze: controlla "
                         "il campo km del layer")
            usati = "%d (%s)" % (k["sulla"], k["fonte"]) if k.get("modo") != "nessuno" else "—"
            celle = {0: nome, 1: str(len(mie)), 5: usati, 6: stato}
            for c, val in celle.items():
                x = QTableWidgetItem(val)
                x.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                x.setToolTip(val)
                if c == 6 and ok < len(mie):
                    x.setForeground(QColor(170, 60, 0))
                t.setItem(r, c, x)
            t.setCellWidget(r, 2, cb_f)
            t.setCellWidget(r, 3, cb_l)
            t.setCellWidget(r, 4, cb_c)

            def _abilita(*_a, f=cb_f, l_=cb_l, c_=cb_c):
                si = f.currentData() == "layer"
                l_.setEnabled(si)
                c_.setEnabled(si)
            cb_f.currentIndexChanged.connect(_abilita)
            _abilita()
            self._rfi_km_w[nome] = (cb_f, cb_l, cb_c)
        t.resizeColumnsToContents()

    def _rfi_layer_interferenze(self, interf):
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Interferenze ferroviarie", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("id", QVariant.Int), QgsField("tipologia", QVariant.String),
                          QgsField("km", QVariant.String), QgsField("etichetta", QVariant.String)])
        vl.updateFields()
        feats = []
        rfi = _rfi_mod()
        for i in interf:
            if not getattr(i, "includi", True):
                continue            # esclusa dall'utente: non in mappa
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat)))
            f["id"] = i.id
            f["tipologia"] = i.tipologia or "—"
            f["km"] = rfi.etichetta_km(i.km_da, i.km_a)
            f["etichetta"] = "#%d tipo %s" % (i.id, i.tipologia or "—")
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "circle", "color": "255,60,60,110", "outline_color": "200,0,0,255",
             "size": "7"})))
        self._rfi_etichetta(vl, "etichetta", 8, colore=QColor(180, 0, 0))
        self._rfi_sostituisci_layer("Interferenze ferroviarie", vl)
        self._rfi_ordina_layer()

    def _rfi_tipo_in_mappa(self, iid, tipo):
        """Tipologia cambiata in tabella: la riporta subito sui layer in mappa
        (punto dell'interferenza e scavi/pozzetti trovati), etichette comprese."""
        from qgis.core import QgsProject
        tipo = tipo or "—"
        for lyr in QgsProject.instance().mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer):
                continue
            nome = lyr.name()
            if nome != "Interferenze ferroviarie" and not nome.startswith("Interferenze ferrovie"):
                continue
            idx_id = lyr.fields().indexOf("id")
            idx_t = lyr.fields().indexOf("tipologia")
            idx_e = lyr.fields().indexOf("etichetta")
            if idx_id < 0 or idx_t < 0:
                continue
            modello = "#%d tipo %s" if nome == "Interferenze ferroviarie" else "n. %d tipo %s"
            cambi = {}
            for f in lyr.getFeatures():
                if str(f[idx_id]).split(".")[0] == str(iid):
                    att = {idx_t: tipo}
                    if idx_e >= 0:
                        att[idx_e] = modello % (iid, tipo)
                    cambi[f.id()] = att
            if cambi:
                lyr.dataProvider().changeAttributeValues(cambi)
                lyr.triggerRepaint()
        try:
            self.iface.mapCanvas().refresh()
        except Exception:  # noqa: BLE001
            pass

    def _rfi_riga_interferenza(self, r):
        rfi = _rfi_mod()
        iid = self.tab_rfi.item(r, C_ID).data(Qt.UserRole)
        return next((i for i in self._rfi_state()["interferenze"] if i.id == iid), None), rfi

    def _rfi_zoom_riga(self):
        righe = self.tab_rfi.selectionModel().selectedRows() if self.tab_rfi.selectionModel() else []
        if not righe:
            return
        i, _ = self._rfi_riga_interferenza(righe[0].row())
        if i is None:
            return
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        d = 0.0012
        rect = QgsRectangle(i.lon - d, i.lat - d, i.lon + d, i.lat + d)
        tr = QgsCoordinateTransform(wgs, self.iface.mapCanvas().mapSettings().destinationCrs(),
                                    self.project)
        self.iface.mapCanvas().setExtent(tr.transformBoundingBox(rect))
        self.iface.mapCanvas().refresh()

    def _rfi_doppio_clic(self, r, c):
        if c != C_FOTO:
            from . import ftth_trovati as _TR
            i, _ = self._rfi_riga_interferenza(r)
            if i is not None:
                _TR.zoom(getattr(self, "iface", None), self.project,
                         self._rfi_geom_interferenza(i))
            return
        p, _ = QFileDialog.getOpenFileName(self, "Foto per la tavola", "",
                                           "Immagini (*.jpg *.jpeg *.png)")
        if p:
            self.tab_rfi.setItem(r, C_FOTO, QTableWidgetItem(p))

    def _rfi_leggi_tabella(self):
        """Riporta nelle interferenze le correzioni fatte in tabella."""
        st = self._rfi_state()
        for r in range(self.tab_rfi.rowCount()):
            i, _ = self._rfi_riga_interferenza(r)
            if i is None:
                continue
            i.includi = self.tab_rfi.item(r, C_INCL).checkState() == Qt.Checked
            gi = self.tab_rfi.item(r, C_GEST)
            if gi is not None and gi.data(Qt.UserRole):
                i.gestore = gi.data(Qt.UserRole)
            tip = self.tab_rfi.cellWidget(r, C_TIPO).currentData()
            i.tipologia = None if tip == "—" else tip
            txt = lambda c: (self.tab_rfi.item(r, c).text().strip() if self.tab_rfi.item(r, c) else "")
            i.linea = txt(C_LINEA) or i.linea
            i.stazione = txt(C_STAZ)
            i.km_da = txt(C_KMDA)
            i.km_a = txt(C_KMA)
            i.proprietario = txt(C_PROPR)
            i.foto = txt(C_FOTO)
        return st["interferenze"]

    def _rfi_leggi_destinatari(self):
        rfi = _rfi_mod()
        gestori = dict(self._rfi_state().get("gestori") or {})
        for r in range(self.tab_rfi_dest.rowCount()):
            k = self.tab_rfi_dest.item(r, 0).data(Qt.UserRole)
            g = gestori.get(k) or rfi.Gestore(chiave=k, nome=k, sigla=k.upper())
            txt = lambda c: (self.tab_rfi_dest.item(r, c).text().strip()
                             if self.tab_rfi_dest.item(r, c) else "")
            g.dest_nome, g.dest_indirizzo, g.dest_pec = txt(1), txt(2), txt(3)
            gestori[k] = g
        return gestori

    # ------------------------------------------------------------ genera
    def _rfi_aggiorna_orto(self):
        self.cb_rfi_orto.clear()
        self.cb_rfi_orto.addItem("automatico (ortofoto del progetto o Esri World Imagery)", None)
        try:
            from qgis.core import QgsRasterLayer
            for l in self.project.mapLayers().values():
                if isinstance(l, QgsRasterLayer):
                    self.cb_rfi_orto.addItem(l.name(), l.id())
        except Exception:  # noqa: BLE001
            pass

    def _rfi_cartella_template(self):
        qui = os.path.dirname(os.path.abspath(__file__))
        c = os.path.join(qui, "modelli_rfi")
        return c if os.path.isfile(os.path.join(c, "TEMPLATE_1.0_art.49.docx")) else None

    def _rfi_genera(self):
        try:
            self._rfi_genera_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_rfi("ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore generazione", str(e))

    NOME_RIQUADRI = "Tavole PL (riquadri) - RFI"

    def _rfi_calcola_tavole(self, avviso=True):
        """Quante tavole di dettaglio avrà ogni istanza (stessa divisione e
        stesse scale della stampa: 1:500, 1:1000 o 1:2000 per tavola, riquadri
        che non si sovrappongono) e i loro riquadri in mappa, nel gruppo RFI.
        Una sezione per tavola la disegna l'utente dove vuole. Ritorna
        [(istanza, n tavole, n con sezione)]."""
        from qgis.core import (QgsFeature, QgsField, QgsFillSymbol, QgsPalLayerSettings,
                               QgsProject, QgsSingleSymbolRenderer, QgsTextBufferSettings,
                               QgsTextFormat, QgsVectorLayerSimpleLabeling)
        try:
            from . import ftth_rfi_layout as L
        except ImportError:
            import ftth_rfi_layout as L
        from . import ftth_gruppi_istanze as GR
        istanze = self._rfi_istanze_per_gruppi()
        if not istanze:
            return []
        prj = QgsProject.instance()
        # riquadri nel CRS delle tavole (quello metrico del progetto): dritti
        # come in stampa (in un altro CRS sembravano storti)
        crs_l = L._crs_metrico(prj, sum(i.lon for i in istanze[0].interferenze) /
                               len(istanze[0].interferenze))
        lyr = QgsVectorLayer("Polygon?crs=%s" % crs_l.authid(), self.NOME_RIQUADRI, "memory")
        lyr.dataProvider().addAttributes([QgsField("tavola", QVariant.String),
                                          QgsField("istanza", QVariant.String),
                                          QgsField("scala", QVariant.Int),
                                          QgsField("sezione", QVariant.String)])
        lyr.updateFields()
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        esiti, feats, righe, scale_usate = [], [], [], {}
        for ist in istanze:
            lon0 = sum(i.lon for i in ist.interferenze) / len(ist.interferenze)
            crs = L._crs_metrico(prj, lon0)
            divise = L.tavole_istanza(prj, ist, None, crs)
            sez_l = L.layer_rilievo(prj, L.NOMI_LAYER_SEZIONI, L.nomi_istanza(ist), "rfi")
            sezioni = []
            if sez_l is not None:
                a_s = QgsCoordinateTransform(sez_l.crs(), crs, prj)
                c_i = L._campo(sez_l, L.CAMPO_ISTANZA)
                for f in sez_l.getFeatures():
                    if not L.sigla_sezione(sez_l, f):
                        continue
                    if c_i and not L.istanza_corrisponde(f[c_i], L.nomi_istanza(ist)):
                        continue
                    g_ = QgsGeometry(f.geometry())
                    g_.transform(a_s)
                    sezioni.append((L.sigla_sezione(sez_l, f), g_.centroid().asPoint()))
            a_w = QgsCoordinateTransform(crs, crs_l, prj)
            breve = "Tipo %s%s" % (ist.tipologia, (" " + ist.stazione) if ist.stazione else "")
            con_sez = 0
            for k, (r, _grp, s_k) in enumerate(divise, 1):
                dentro = [s for s, c in sezioni if r.contains(c)]
                con_sez += 1 if dentro else 0
                scale_usate[s_k] = scale_usate.get(s_k, 0) + 1
                g = QgsGeometry.fromRect(r)
                g.transform(a_w)
                f = QgsFeature(lyr.fields())
                f.setGeometry(g)
                f["tavola"] = "TAV. %d - 1:%d - %s" % (k, s_k, breve)
                f["istanza"] = ist.nome_base
                f["scala"] = s_k
                f["sezione"] = ", ".join(dentro)
                feats.append(f)
            esiti.append((ist, len(divise), con_sez))
            righe.append("%s: %d tavole (%s), %d con la sezione" % (
                ist.nome_base, len(divise),
                ", ".join("1:%d" % s for _r, _g, s in divise), con_sez))
        lyr.dataProvider().addFeatures(feats)
        lyr.updateExtents()
        lyr.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "230,60,60,30", "outline_color": "220,40,40,255", "outline_width": "0.6",
             "outline_style": "dash"})))
        pal = QgsPalLayerSettings()
        pal.fieldName = "tavola"
        tf = QgsTextFormat()
        tf.setSize(9)
        tf.setColor(QColor(200, 0, 0))
        b = QgsTextBufferSettings()
        b.setEnabled(True)
        b.setSize(1)
        tf.setBuffer(b)
        pal.setFormat(tf)
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        lyr.setLabelsEnabled(True)
        for nome_v in (self.NOME_RIQUADRI, "Dove disegnare la sezione - RFI"):
            for vecchio in prj.mapLayersByName(nome_v):
                prj.removeMapLayer(vecchio.id())
        g_rfi = GR.gruppo_sezione(prj.layerTreeRoot(), "rfi")
        prj.addMapLayer(lyr, False)
        g_rfi.insertLayer(0, lyr)
        try:        # la mappa si inquadra sulle tavole
            canvas = self.iface.mapCanvas()
            est = QgsCoordinateTransform(lyr.crs(), canvas.mapSettings().destinationCrs(),
                                         prj).transformBoundingBox(lyr.extent())
            est.scale(1.1)
            canvas.setExtent(est)
            canvas.refresh()
        except Exception:  # noqa: BLE001
            pass
        tot = sum(n for _i, n, _s in esiti)
        mancano = sum(n - s for _i, n, s in esiti)
        sintesi = "%d tavole in %d istanze (%s): servono %d sezioni%s." % (
            tot, len(esiti), ", ".join("%d a 1:%d" % (n, s) for s, n in sorted(scale_usate.items())),
            tot, (", ne mancano %d" % mancano) if mancano else ", ci sono tutte")
        self.lbl_rfi_tavole.setText(sintesi)
        testo = (sintesi + "\n\n" + "\n".join(righe) +
                 "\n\nIn mappa i riquadri rossi (layer «%s», gruppo RFI) sono le tavole, con "
                 "numero e scala: una sezione dentro ogni riquadro. La tavola n della stampa "
                 "è il riquadro «TAV. n» (pagina n+1 della PL, dopo l'inquadramento)."
                 % self.NOME_RIQUADRI)
        self._log_rfi(testo)
        if avviso:
            self._rfi_anteprima_tavole(prj, lyr, testo)
        return esiti

    def _rfi_anteprima_tavole(self, prj, lyr, testo):
        """Finestra con il disegno delle tavole (riquadri numerati, rete,
        ferrovia e dove disegnare la sezione) e il riepilogo."""
        from qgis.core import QgsMapRendererParallelJob, QgsMapSettings
        from qgis.PyQt.QtCore import QSize
        from qgis.PyQt.QtGui import QPixmap
        from qgis.PyQt.QtWidgets import QDialog, QScrollArea
        try:
            from . import ftth_rfi_layout as L
        except ImportError:
            import ftth_rfi_layout as L
        from qgis.PyQt.QtWidgets import QGridLayout

        def _solo(src, filtro, etichette):
            """Copia in memoria di `src` con le sole feature `filtro`: nella
            scheda di una tavola solo il suo riquadro e la sua linea."""
            m = QgsVectorLayer("Polygon?crs=%s" % src.crs().authid(), "t", "memory")
            m.dataProvider().addAttributes(src.fields().toList())
            m.updateFields()
            m.dataProvider().addFeatures([QgsFeature(x) for x in src.getFeatures() if filtro(x)])
            m.setRenderer(src.renderer().clone())
            if etichette and src.labeling() is not None:
                m.setLabeling(src.labeling().clone())
                m.setLabelsEnabled(True)
            return m
        strati = []
        sez_rfi = L.layer_rilievo(prj, L.NOMI_LAYER_SEZIONI, [], "rfi")
        if sez_rfi is not None:
            strati.append(sez_rfi)
        for nome in ("02_POZZETTO", "03 INFRASTRUTTURE", "Ferrovia RFI", "Fascia di rispetto RFI"):
            l_ = L._trova(prj, nome)
            if l_ is not None:
                strati.append(l_)
        dest = lyr.crs()            # lo stesso CRS della stampa: riquadri dritti
        a_d = QgsCoordinateTransform(lyr.crs(), dest, prj)
        w = QDialog(self)
        w.setWindowTitle("Anteprima numero di tavole")
        w.resize(1200, 900)
        v = QVBoxLayout(w)
        lab_t = QLabel(testo)
        lab_t.setWordWrap(True)
        v.addWidget(lab_t)
        # una scheda per tavola, inquadrata sul suo riquadro: si vede bene dove
        # va la sezione (linea blu «SEZIONE QUI»)
        corpo = QWidget()
        griglia = QGridLayout(corpo)
        for n, f in enumerate(sorted(lyr.getFeatures(), key=lambda x: (x["istanza"], x.id()))):
            est = a_d.transformBoundingBox(f.geometry().boundingBox())
            est.scale(1.06)
            tav = f["tavola"]
            ist_n = f["istanza"]
            riq1 = _solo(lyr, lambda x: x["tavola"] == tav and x["istanza"] == ist_n, False)
            ms = QgsMapSettings()
            ms.setLayers(strati + [riq1])
            ms.setDestinationCrs(dest)
            ms.setOutputSize(QSize(360, 310))
            ms.setExtent(est)
            ms.setBackgroundColor(QColor(255, 255, 255))
            job = QgsMapRendererParallelJob(ms)
            job.start()
            job.waitForFinished()
            cella = QVBoxLayout()
            tit = QLabel("<b>%s</b><br>%s%s" % (
                f["tavola"], f["istanza"],
                ("<br><span style='color:#1b7a2f'>sezione: %s</span>" % f["sezione"])
                if f["sezione"] else "<br><span style='color:#c0392b'>manca la sezione</span>"))
            cella.addWidget(tit)
            img = QLabel()
            img.setPixmap(QPixmap.fromImage(job.renderedImage()))
            img.setStyleSheet("border:1px solid #999")
            cella.addWidget(img)
            griglia.addLayout(cella, n // 3, n % 3)
        area = QScrollArea()
        area.setWidgetResizable(True)
        area.setWidget(corpo)
        v.addWidget(area, 1)
        b = QPushButton("Chiudi")
        b.clicked.connect(w.close)
        v.addWidget(b)
        w.show()
        self._finestra_tavole = w
        return w

    def _rfi_istanze_per_gruppi(self):
        """Istanze dalle righe confermate, per i gruppi di layer nel progetto."""
        rfi = _rfi_mod()
        comune = self.txt_rfi_comune.text().strip()
        if not comune or not self._rfi_state()["interferenze"]:
            QMessageBox.warning(self, "Dati mancanti",
                                "Prima scrivi il comune e trova le interferenze.")
            return None
        istanze = rfi.raggruppa_istanze(self._rfi_leggi_tabella(),
                                        self._rfi_leggi_destinatari(), comune)
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza",
                                "Nessuna riga inclusa con tipologia A, B, C o D.")
        return istanze

    def _rfi_genera_impl(self):
        rfi = _rfi_mod()
        try:
            import docx  # noqa: F401
        except ImportError:
            QMessageBox.critical(
                self, "Manca python-docx",
                "Serve il modulo 'python-docx'. Dalla console Python di QGIS:\n"
                "  import pip; pip.main(['install','python-docx'])")
            return
        comune = self.txt_rfi_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante", "Inserisci il comune.")
            return
        if not self._rfi_state()["interferenze"]:
            QMessageBox.warning(self, "Nessuna interferenza",
                                "Prima premi «Trova le interferenze».")
            return
        tpl = self._rfi_cartella_template()
        if tpl is None:
            QMessageBox.critical(self, "Modelli mancanti", "Non trovo i modelli in <plugin>/modelli_rfi.")
            return
        interf = self._rfi_leggi_tabella()
        gestori = self._rfi_leggi_destinatari()
        istanze = rfi.raggruppa_istanze(interf, gestori, comune)
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza",
                                "Nessuna riga inclusa con tipologia A, B, C o D.")
            return
        try:    # elementi aggiunti a mano al gruppo dell'istanza
            from . import ftth_gruppi_istanze as _GR
            _GR.aggiungi_da_ricerca(
                self.project, istanze, interf,
                lambda i, ist: (i.tipologia, i.gestore, i.linea, i.stazione or "") ==
                (ist.tipologia, ist.gestore.chiave, ist.linea, ist.stazione or ""),
                self._log_rfi)
        except Exception as e:  # noqa: BLE001
            self._log_rfi("Elementi aggiunti a mano non considerati: %s" % e)
        dati = rfi.DatiComune(comune, self.txt_rfi_prov.text().strip(), self.txt_rfi_cap.text().strip(),
                              self.txt_rfi_indirizzo.text().strip(), self.txt_rfi_comune_pec.text().strip())
        radice = os.path.join(self.project.homePath() or os.path.expanduser("~"),
                              "Istanze RFI", comune.upper())
        os.makedirs(radice, exist_ok=True)
        self._rfi_state()["cartella"] = radice
        self._log_rfi("")
        self._log_rfi("Istanze da generare: %d" % len(istanze))
        try:
            from qgis.PyQt.QtWidgets import QApplication
        except ImportError:
            QApplication = None
        layout_mod = None
        if self.chk_rfi_pl.isChecked():
            try:
                try:
                    from . import ftth_rfi_layout as layout_mod
                except ImportError:
                    import ftth_rfi_layout as layout_mod
            except Exception as e:  # noqa: BLE001
                self._log_rfi("Planimetria non disponibile: %s" % e)
        riepilogo = []
        for ist in istanze:
            cart = os.path.join(radice, "%02d_%s" % (ist.numero, ist.nome_base))
            self._log_rfi("— %s (%d interferenze)" % (ist.nome_base, len(ist.interferenze)))
            if QApplication:
                QApplication.processEvents()
            prod = rfi.genera_documenti_istanza(ist, dati, tpl, cart, rese=self._rfi_rese())
            try:    # logo FiberCop classico o «Milano Cortina 2026» (flag del progetto)
                from . import ftth_logo as _LOGO
                for p_doc in prod.values():
                    if p_doc and str(p_doc).lower().endswith(".docx"):
                        _LOGO.applica_docx(p_doc, _LOGO.attivo(self.project))
            except Exception as e_logo:  # noqa: BLE001
                self._log_rfi("   Logo nei documenti non sostituito: %s" % e_logo)
            da_pdf = [prod["rt"]] + ([prod[k] for k in ("art49", "bollo", "modb")]
                                    if self.chk_rfi_pdf_tutti.isChecked() else [])
            pdf = rfi.converti_pdf([p for p in da_pdf if p])
            if not pdf.get(prod["rt"]):
                self._log_rfi("   PDF non creato: serve Microsoft Word o LibreOffice.")
            if rfi.avviso_pdf():
                self._log_rfi("   " + rfi.avviso_pdf())
            if layout_mod is not None:
                try:
                    out_pl = os.path.join(cart, rfi.NOMI_FILE["pl"].format(base=ist.nome_base))
                    avvisi_pl = []
                    ok = layout_mod.genera_pl_istanza(
                        self.project, ist, dati, out_pl,
                        orto_id=self.cb_rfi_orto.currentData(),
                        fascia_m=self.spin_rfi_fascia.value(),
                        cartella_utente=self.txt_rfi_cartella.text().strip() or None,
                        cartella_sezioni=self.txt_rfi_cart_sez.text().strip() or None,
                        cartella_foto=self.txt_rfi_cart_foto.text().strip() or None,
                        log=avvisi_pl.append)
                    for a in avvisi_pl:
                        self._log_rfi("   tavola: %s" % a)
                    self._log_rfi("   planimetria: %s" % ("OK" if ok else "NON esportata"))
                except Exception as e:  # noqa: BLE001
                    import traceback
                    self._log_rfi("   planimetria non riuscita: %s" % e)
                    self._log_rfi(traceback.format_exc())
            with open(os.path.join(cart, "LEGGIMI.txt"), "w", encoding="utf-8") as fh:
                fh.write(rfi.promemoria_istanza(ist, dati))
            riepilogo.append(ist)
        try:
            self._rfi_scrivi_excel(riepilogo, radice, comune)
        except Exception as e:  # noqa: BLE001
            self._log_rfi("Riepilogo Excel non scritto: %s" % e)
        self._log_rfi("Cartella: %s" % radice)
        incompleti = [ist.gestore.nome for ist in istanze if not ist.gestore.destinatario_completo()]
        msg = ("Generata 1 istanza in:\n%s" % radice if len(istanze) == 1
               else "Generate %d istanze in:\n%s" % (len(istanze), radice))
        if incompleti:
            msg += ("\n\nDestinatario incompleto per: %s (nei documenti resta XXXXX)."
                    % ", ".join(sorted(set(incompleti))))
        sopr = [ist.nome_base for ist in istanze if rfi.TIPOLOGIE[ist.tipologia]["sopralluogo"]]
        if sopr:
            msg += ("\n\nTipologie B/C: prima della PEC serve il sopralluogo congiunto "
                    "con il gestore (%s)." % ", ".join(sopr))
        QMessageBox.information(self, "Istanze generate", msg)

    def _rfi_apri_cartella(self):
        c = self._rfi_state().get("cartella")
        if c and os.path.isdir(c):
            os.startfile(c)
        else:
            QMessageBox.information(self, "Cartella", "Genera prima le istanze.")

    def _rfi_scrivi_excel(self, istanze, radice, comune):
        """Riepilogo di tutte le istanze del comune, una riga per interferenza."""
        try:
            import openpyxl
            from openpyxl.styles import Font
        except ImportError:
            self._log_rfi("openpyxl non disponibile: niente riepilogo Excel.")
            return
        rfi = _rfi_mod()
        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "Istanze"
        ws.append(["Istanza", "Tipologia", "Gestore", "Destinatario", "PEC", "Linea", "Stazione",
                   "Interferenza", "Km", "Microtrincea", "No Dig", "Trincea", "Minitrincea",
                   "Pozzetti", "Note"])
        for c in ws[1]:
            c.font = Font(bold=True)
        for ist in istanze:
            for i in ist.interferenze:
                ws.append([ist.nome_base, ist.tipologia, ist.gestore.nome, ist.gestore.dest_nome,
                           ist.gestore.dest_pec, ist.linea, ist.stazione, i.id,
                           rfi.etichetta_km(i.km_da, i.km_a),
                           i.metri.get("microtrincea", 0), i.metri.get("nodig", 0),
                           i.metri.get("trincea", 0), i.metri.get("minitrincea", 0),
                           ", ".join("%s x%d" % (d, n) for d, n in i.pozzetti.items()),
                           "; ".join(i.note)])
        for col in ws.columns:
            ws.column_dimensions[col[0].column_letter].width = min(
                60, max(10, max(len(str(c.value or "")) for c in col) + 2))
        path = os.path.join(radice, "%s_Riepilogo_istanze_ferroviarie.xlsx" % comune.upper())
        wb.save(path)
        self._log_rfi("Riepilogo: %s" % os.path.basename(path))
