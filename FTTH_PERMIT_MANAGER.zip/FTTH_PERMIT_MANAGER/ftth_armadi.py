# -*- coding: utf-8 -*-
"""Verifica armadi: logica senza QGIS.

Per ogni armadio del progetto i collegamenti Google (Street View, mappa,
satellite) sul punto esatto, l'esito della verifica (salvato nel progetto,
non nel layer), l'eventuale posizione aggiornata e l'elenco Excel da girare
a chi decide (scrivi_csv resta per compatibilità).
"""
import csv
import json

ESITI = ["Da verificare", "Fattibile", "Non fattibile", "Da spostare"]
ESITO_INIZIALE = ESITI[0]
# colori sulla mappa per esito
COLORI = {"Da verificare": "#8a919a", "Fattibile": "#2e9e44", "Non fattibile": "#d93025",
          "Da spostare": "#ff7c02"}
PRJ_SCOPE = "ftth_verifica_armadi"
PRJ_CHIAVE = "esiti"

# campi possibili per il nome e l'indirizzo dell'armadio, in ordine di preferenza
CAMPI_ID = ("AREA_AO", "ID_ARMADIO", "NOME", "CODICE", "ARMADIO", "LABEL", "ID", "NAME", "OBJECTID")
CAMPI_INDIRIZZO = ("INDIRIZZO", "VIA", "ADDRESS", "UBICAZIONE")


def link_streetview(lat: float, lon: float) -> str:
    return ("https://www.google.com/maps/@?api=1&map_action=pano&viewpoint=%.7f,%.7f"
            % (lat, lon))


def link_mappa(lat: float, lon: float) -> str:
    return "https://www.google.com/maps/search/?api=1&query=%.7f,%.7f" % (lat, lon)


def link_satellite(lat: float, lon: float, zoom: int = 20) -> str:
    return ("https://www.google.com/maps/@?api=1&map_action=map&center=%.7f,%.7f"
            "&zoom=%d&basemap=satellite" % (lat, lon, zoom))


def scegli_campo(nomi_campi: list, preferiti: tuple) -> str:
    """Primo campo di `preferiti` presente (senza badare a maiuscole)."""
    per_nome = {n.upper(): n for n in nomi_campi}
    for p in preferiti:
        if p in per_nome:
            return per_nome[p]
    return ""


def chiave_armadio(valore_id, fid) -> str:
    """Chiave stabile dell'esito: il nome dell'armadio se c'e', se no il fid."""
    if isinstance(valore_id, float) and valore_id.is_integer():
        valore_id = int(valore_id)          # 201.0 -> 201
    v = "" if valore_id is None else str(valore_id).strip()
    return v if v and v.upper() != "NULL" else "fid:%s" % fid


def esiti_da_testo(testo: str) -> dict:
    try:
        d = json.loads(testo or "{}")
    except (ValueError, TypeError):
        return {}
    out = {}
    for k, v in (d.items() if isinstance(d, dict) else []):
        if isinstance(v, dict):
            e = v.get("esito") if v.get("esito") in ESITI else ESITO_INIZIALE
            out[str(k)] = {"esito": e, "nota": str(v.get("nota") or "")}
            nuova = v.get("nuova")
            if isinstance(nuova, (list, tuple)) and len(nuova) == 2:
                try:
                    out[str(k)]["nuova"] = [float(nuova[0]), float(nuova[1])]
                except (TypeError, ValueError):
                    pass
    return out


def esiti_in_testo(esiti: dict) -> str:
    # gli armadi ancora «da verificare», senza nota e non spostati non si salvano
    pulito = {k: v for k, v in esiti.items()
              if v.get("esito") != ESITO_INIZIALE or (v.get("nota") or "").strip()
              or v.get("nuova")}
    return json.dumps(pulito, ensure_ascii=False, sort_keys=True)


def testo_coordinate(lat, lon) -> str:
    """«40.6977860, 14.9787600» (lat, lon in gradi decimali, punto come
    separatore): si incolla così in Google Maps e Excel non lo stravolge."""
    if lat is None or lon is None:
        return ""
    return "%.7f, %.7f" % (lat, lon)


def scrivi_xlsx(percorso: str, armadi: list, esiti: dict) -> int:
    """Elenco Excel: una riga per armadio con la posizione da progetto e, se
    l'armadio va spostato, la posizione aggiornata (testo «lat, lon»), esito,
    note e i collegamenti Street View. Ritorna le righe scritte."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    wb = Workbook()
    ws = wb.active
    ws.title = "Verifica armadi"
    intest = ["Armadio", "Indirizzo", "Posizione da progetto (lat, lon)",
              "Posizione aggiornata (lat, lon)", "Esito", "Note", "Street View (progetto)",
              "Street View (aggiornata)"]
    ws.append(intest)
    for c in ws[1]:
        c.font = Font(bold=True, color="FFFFFF")
        c.fill = PatternFill("solid", fgColor="031B52")
        c.alignment = Alignment(vertical="center", wrap_text=True)
    for a in armadi:
        e = esiti.get(a["chiave"]) or {}
        nuova = e.get("nuova")
        riga = [a["nome"], a.get("indirizzo", ""), testo_coordinate(a["lat"], a["lon"]),
                testo_coordinate(*nuova) if nuova else "",
                e.get("esito", ESITO_INIZIALE), (e.get("nota") or "").replace("\n", " "),
                link_streetview(a["lat"], a["lon"]),
                link_streetview(*nuova) if nuova else ""]
        ws.append(riga)
        r = ws.max_row
        for col in (7, 8):
            c = ws.cell(row=r, column=col)
            if c.value:
                c.hyperlink = c.value
                c.value = "Apri Street View"
                c.font = Font(color="0563C1", underline="single")
        esito = e.get("esito", ESITO_INIZIALE)
        colore = COLORI.get(esito, "#8a919a").lstrip("#")
        ws.cell(row=r, column=5).font = Font(bold=True, color=colore)
    for col, larg in zip("ABCDEFGH", (16, 28, 26, 26, 15, 40, 18, 18)):
        ws.column_dimensions[col].width = larg
    ws.freeze_panes = "A2"
    wb.save(percorso)
    return len(armadi)


def riepilogo(chiavi: list, esiti: dict) -> dict:
    out = {e: 0 for e in ESITI}
    for k in chiavi:
        out[(esiti.get(k) or {}).get("esito", ESITO_INIZIALE)] += 1
    return out


def scrivi_csv(percorso: str, armadi: list, esiti: dict) -> int:
    """armadi = [{'chiave', 'nome', 'indirizzo', 'lat', 'lon'}]. Separatore
    «;» per Excel italiano. Ritorna le righe scritte."""
    with open(percorso, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";")
        w.writerow(["Armadio", "Indirizzo", "Latitudine", "Longitudine", "Esito", "Note",
                    "Street View"])
        for a in armadi:
            e = esiti.get(a["chiave"]) or {}
            w.writerow([a["nome"], a.get("indirizzo", ""), "%.7f" % a["lat"],
                        "%.7f" % a["lon"], e.get("esito", ESITO_INIZIALE),
                        (e.get("nota") or "").replace("\n", " "),
                        link_streetview(a["lat"], a["lon"])])
    return len(armadi)
