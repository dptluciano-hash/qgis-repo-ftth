# -*- coding: utf-8 -*-
"""Grafica del pannello: foglio di stile (blu FiberCop), barra laterale con
icone al posto delle linguette di primo e secondo livello, pulsanti
principali in evidenza, log a spaziatura fissa.

La barra laterale NON sostituisce i QTabWidget: ne nasconde solo le
linguette e li comanda. Tutto il codice che usa setCurrentIndex, tabText o
gli indici salvati continua a funzionare come prima.
"""
from qgis.PyQt.QtCore import QSize, Qt
from qgis.PyQt.QtGui import QColor, QFont, QIcon
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QApplication, QListWidget, QListWidgetItem, QPlainTextEdit,
    QPushButton,
)

# palette beexact, usata con misura: blu notte per testata e pulsante
# principale, arancio solo come piccolo accento (voce e linguetta attive)
NAVY = "#031B52"
BLU2 = "#1D3C78"
ARANCIO = "#FF7C02"
ACCENTO = NAVY
ACCENTO_SCURO = BLU2

# icone a linea del plugin (24x24, tratto uniforme, colorate col pannello):
# nome della linguetta -> contenuto SVG
ICONE = {
    "Seleziona elementi": '<rect x="3" y="3" width="13" height="13" rx="2" '
                          'stroke-dasharray="3 2.5"/><path d="M13 13l8 3-3.5 1.2L16 21z"/>',
    "Keyplan e tavole": '<path d="M3 6.5l6-3 6 3 6-3v14l-6 3-6-3-6 3z"/>'
                        '<path d="M9 3.5v14M15 6.5v14"/>',
    "Punti di ripresa": '<rect x="3" y="7" width="18" height="13" rx="2.5"/>'
                        '<path d="M8.5 7l1.5-3h4l1.5 3"/><circle cx="12" cy="13.5" r="3.5"/>',
    # armadio FiberCop stilizzato: alto, angoli superiori arrotondati, fascia
    # in alto, serratura, onda che richiama la fibra (scelta dell'utente, «C»)
    "Verifica armadi": '<path d="M6 21V5.5A2.5 2.5 0 0 1 8.5 3h7A2.5 2.5 0 0 1 18 5.5V21"/>'
                       '<path d="M6 8h12"/><path d="M8.5 5.5h7"/><path d="M15 13v2"/>'
                       '<path d="M8.5 18.5c1-1.5 2-1.5 3 0s2 1.5 3 0"/><path d="M4 21h16"/>',
    # binari: tratte vicino a ferrovie, acque, strade ANAS
    "Verifica interferenze": '<path d="M7 3v18M17 3v18M7 7h10M7 12h10M7 17h10"/>',
    "Esportazione":'<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/>'
                    '<path d="M14 3v5h5M12 11v7M9 15l3 3 3-3"/>',
    "Screening territorio": '<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/>'
                            '<path d="M12 12l6-6"/><circle cx="12" cy="12" r="1"/>',
    "Quadro pratiche": '<path d="M10 6h10M10 12h10M10 18h10"/>'
                       '<path d="M4 6l1.3 1.3L7.5 5M4 12l1.3 1.3 2.2-2.3M4 18l1.3 1.3 2.2-2.3"/>',
    "Istanze Strade": '<path d="M5 21L9.5 3M19 21L14.5 3"/><path d="M12 5v2.5M12 11v2.5M12 17v2.5"/>',
    "Istanze RFI": '<rect x="6" y="3" width="12" height="13" rx="3"/><path d="M6 10h12"/>'
                   '<path d="M9 13h.01M15 13h.01M8.5 20.5l2-4.5M15.5 20.5l-2-4.5"/>',
    "Istanze Acque": '<path d="M12 3c3.6 4.5 6 7.9 6 11a6 6 0 0 1-12 0c0-3.1 2.4-6.5 6-11z"/>'
                     '<path d="M9.5 15a2.5 2.5 0 0 0 2.5 2.5"/>',
    "Istanze Soprintendenza": '<path d="M3 21h18M4 9h16M12 3l8.5 4.5h-17z"/>'
                              '<path d="M6.5 9v9M10.5 9v9M13.5 9v9M17.5 9v9"/>',
    "Istanze Parchi / Natura 2000": '<path d="M12 21v-5"/><path d="M12 3l6 8h-3l4 5H5l4-5H6z"/>',
    "Fasce di rispetto": '<path d="M3 12h18"/><path d="M3 6h18M3 18h18" stroke-dasharray="3 3"/>',
    "Consegna pratiche": '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9z"/>'
                         '<path d="M4 7.5l8 4.5 8-4.5M12 12v9"/>',
    "Shape → GeoPackage": '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 12.5l9 5 9-5"/>'
                          '<path d="M3 16.5l9 5 9-5"/>',
    "Allinea": '<circle cx="12" cy="12" r="5"/><path d="M12 2.5v5M12 16.5v5M2.5 12h5M16.5 12h5"/>',
    "Edifici in carreggiata": '<rect x="4" y="3" width="10" height="18" rx="1.5"/>'
                              '<path d="M14 9h5a1 1 0 0 1 1 1v11h-6M7.5 7h3M7.5 11h3M7.5 15h3"/>',
    "Unisci tratte": '<circle cx="6" cy="5" r="2"/><circle cx="6" cy="19" r="2"/>'
                     '<circle cx="18" cy="12" r="2"/><path d="M6 7v10M6 8.5c0 3.5 4 3.5 10 3.5"/>',
}
# testi dei pulsanti che diventano «principali» (colorati)
PRINCIPALI = ("Genera", "Prepara consegna", "Avvia screening", "Esegui screening",
              "Cerca le interferenze", "Trova le strade")


def tema_scuro() -> bool:
    try:
        return QApplication.palette().window().color().lightness() < 128
    except Exception:  # noqa: BLE001
        return False


def adatta_larghezza(radice, soglia=300):
    """Rende il pannello restringibile: in Qt il testo di una QCheckBox o di
    un QRadioButton non va mai a capo, quindi la pagina non poteva diventare
    più stretta della frase più lunga (fino a ~880 px) e, rimpicciolendo la
    finestra, le scritte restavano tagliate a destra.
    - casella / radio con testo lungo: il testo passa a un'etichetta accanto
      che va a capo (clic sull'etichetta = clic sulla casella); visibilità,
      abilitazione e suggerimento seguono la casella; text()/setText()
      continuano a funzionare;
    - etichette dei moduli: a capo, e su finestra stretta la riga si spezza
      (etichetta sopra, campo sotto)."""
    from qgis.PyQt.QtCore import QEvent, QObject
    from qgis.PyQt.QtWidgets import (
        QCheckBox, QFormLayout, QHBoxLayout, QLabel, QRadioButton, QSizePolicy, QWidget,
    )

    class _Sync(QObject):
        def __init__(self, casella, cont, lbl):
            super().__init__(casella)
            self.c, self.cont, self.lbl = casella, cont, lbl

        def eventFilter(self, obj, ev):
            t = ev.type()
            if t == QEvent.ShowToParent:
                self.cont.setVisible(True)
            elif t == QEvent.HideToParent:
                self.cont.setVisible(False)
            elif t == QEvent.EnabledChange:
                self.lbl.setEnabled(self.c.isEnabled())
            elif t == QEvent.ToolTipChange:
                self.lbl.setToolTip(self.c.toolTip())
            return False

    # tendine: la larghezza minima era quella della voce più lunga (fino a
    # ~430 px); ora si restringono e mostrano la voce intera nel menu
    from qgis.PyQt.QtWidgets import QComboBox
    for cb in radice.findChildren(QComboBox):
        try:
            cb.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
            cb.setMinimumContentsLength(12)
            v = cb.view()
            if v is not None:
                v.setTextElideMode(Qt.ElideNone)
                v.setMinimumWidth(max(v.minimumWidth(), v.sizeHintForColumn(0) + 24))
        except Exception:  # noqa: BLE001
            pass

    for lay in radice.findChildren(QFormLayout):
        try:
            lay.setRowWrapPolicy(QFormLayout.WrapLongRows)
            for r in range(lay.rowCount()):
                it = lay.itemAt(r, QFormLayout.LabelRole)
                w = it.widget() if it is not None else None
                if isinstance(w, QLabel) and len(w.text()) > 30:
                    w.setWordWrap(True)
        except Exception:  # noqa: BLE001
            pass

    for c in radice.findChildren(QCheckBox) + radice.findChildren(QRadioButton):
        try:
            testo = c.text()
            if not testo or c.fontMetrics().horizontalAdvance(testo) <= soglia:
                continue
            par = c.parentWidget()
            lay = par.layout() if par is not None else None
            if lay is None:
                continue
            cont = QWidget(par)
            h = QHBoxLayout(cont)
            h.setContentsMargins(0, 0, 0, 0)
            h.setSpacing(6)
            lbl = QLabel(testo, cont)
            lbl.setWordWrap(True)
            lbl.setToolTip(c.toolTip())
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
            lbl.setEnabled(c.isEnabled())
            lbl.mousePressEvent = (lambda ev, cc=c: cc.click() if cc.isEnabled() else None)
            if lay.replaceWidget(c, cont) is None:
                cont.deleteLater()
                continue
            vis = not c.isHidden()
            c.setText("")
            c.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            h.addWidget(c, 0, Qt.AlignTop)
            h.addWidget(lbl, 1)
            cont.setVisible(vis)
            c.setVisible(True)
            c._sync = _Sync(c, cont, lbl)
            c.installEventFilter(c._sync)
            # il codice che legge o cambia il testo continua a funzionare
            c.text = lbl.text
            c.setText = lbl.setText
        except Exception:  # noqa: BLE001
            pass

    # i layout tengono in memoria le misure calcolate prima: senza questo
    # le pagine restavano larghe come prima delle modifiche qui sopra
    from qgis.PyQt.QtWidgets import QLayout
    for lay in radice.findChildren(QLayout):
        try:
            lay.invalidate()
        except Exception:  # noqa: BLE001
            pass
    for w in radice.findChildren(QWidget):
        try:
            w.updateGeometry()
        except Exception:  # noqa: BLE001
            pass


def delegati_combo(radice):
    """Con il foglio di stile, la voce evidenziata delle tendine veniva
    disegnata come una casella bianca vuota (delegato interno di QComboBox
    che prende lo stile del combo). Il delegato standard usa le regole
    «QComboBox QAbstractItemView::item» e la voce resta leggibile."""
    from qgis.PyQt.QtWidgets import QComboBox, QStyledItemDelegate
    for cb in radice.findChildren(QComboBox):
        try:
            cb.setItemDelegate(QStyledItemDelegate(cb))
        except Exception:  # noqa: BLE001
            pass


def foglio_di_stile(scuro: bool = None) -> str:
    scuro = tema_scuro() if scuro is None else scuro
    if scuro:
        c = dict(fondo="#2b2d30", barra="#232427", sel="#1d2b4a", sel_t="#c9d6ef",
                 testo="#e6e6e6", sec="#a0a0a0", bordo="#45474b", campo="#323438",
                 log="#1f2023", alt="#303236", hover="#3a3d42")
    else:
        c = dict(fondo="#ffffff", barra="#f4f6fa", sel="#e6ebf4", sel_t="#031B52",
                 testo="#1f1f1f", sec="#5f6368", bordo="#d5dbe3", campo="#ffffff",
                 log="#f7f9fb", alt="#f7f9fc", hover="#eef3f9")
    c.update(acc=ACCENTO if not scuro else "#4f6fae", acc2=ACCENTO_SCURO, ara=ARANCIO)
    # barra di avanzamento: riempimento chiaro e testo scuro in grassetto, così
    # percentuale e fase si leggono anche sopra la parte già piena
    c.update(chunk="#4f6fae" if scuro else "#b9cdf0",
             testo_barra="#ffffff" if scuro else "#031B52")
    return """
QDialog { background: %(fondo)s; }
QGroupBox { font-weight: 600; border: 1px solid %(bordo)s; border-radius: 8px;
  margin-top: 14px; padding: 10px 8px 8px 8px; }
QGroupBox::title { subcontrol-origin: margin; left: 10px; padding: 0 4px; color: %(sel_t)s; }
QPushButton { border: 1px solid %(bordo)s; border-radius: 6px; padding: 5px 12px;
  background: %(campo)s; color: %(testo)s; }
QPushButton:hover { background: %(hover)s; border-color: %(acc)s; }
QPushButton:pressed { background: %(sel)s; }
QPushButton:disabled { color: %(sec)s; }
QPushButton[primario="true"] { background: %(acc)s; color: white; border: 1px solid %(acc)s;
  font-weight: 600; padding: 6px 16px; }
QPushButton[primario="true"]:hover { background: %(acc2)s; }
QPushButton[primario="true"]:disabled { background: %(bordo)s; border-color: %(bordo)s; }
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox { border: 1px solid %(bordo)s;
  border-radius: 6px; padding: 3px 6px; background: %(campo)s; min-height: 20px; }
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus { border-color: %(acc)s; }
QComboBox QAbstractItemView { background: %(campo)s; color: %(testo)s;
  border: 1px solid %(bordo)s; outline: 0;
  selection-background-color: %(sel)s; selection-color: %(sel_t)s; }
QComboBox QAbstractItemView::item { min-height: 20px; padding: 2px 6px; border: none; }
QComboBox QAbstractItemView::item:hover, QComboBox QAbstractItemView::item:selected {
  background: %(sel)s; color: %(sel_t)s; border: none; }
QTableWidget, QTreeWidget, QTableView, QTreeView { border: 1px solid %(bordo)s;
  border-radius: 6px; gridline-color: %(bordo)s; alternate-background-color: %(alt)s;
  selection-background-color: %(sel)s; selection-color: %(sel_t)s; }
QHeaderView::section { background: %(barra)s; color: %(sec)s; border: none;
  border-bottom: 1px solid %(bordo)s; padding: 4px 6px; font-weight: 600; }
QPlainTextEdit[readOnly="true"], QTextEdit[readOnly="true"] { background: %(log)s;
  border: 1px solid %(bordo)s; border-radius: 6px; font-family: Consolas, "Courier New", monospace;
  font-size: 9pt; }
QProgressBar { border: none; border-radius: 4px; background: %(barra)s; height: 8px;
  text-align: center; color: %(testo_barra)s; font-weight: bold; }
QProgressBar::chunk { background: %(chunk)s; border-radius: 4px; }
QTabWidget::pane { border: none; border-top: 1px solid %(bordo)s; }
QTabBar::tab { background: transparent; border: none; padding: 6px 12px; color: %(sec)s;
  border-bottom: 2px solid transparent; }
QTabBar::tab:selected { color: %(sel_t)s; border-bottom: 2px solid %(ara)s; }
QTabBar::tab:hover { color: %(testo)s; }
QListWidget#barraLaterale { background: %(barra)s; border: none;
  border-right: 1px solid %(bordo)s; outline: 0; padding: 6px 4px; }
QListWidget#barraLaterale::item { padding: 6px 8px; border-radius: 6px; color: %(testo)s; }
QListWidget#barraLaterale::item:selected { background: %(sel)s; color: %(sel_t)s;
  border-left: 3px solid %(ara)s; border-top-left-radius: 0; border-bottom-left-radius: 0; }
QListWidget#barraLaterale::item:hover:!selected { background: %(hover)s; }
QScrollArea { background: transparent; }
""" % c


def _pixmap_svg(corpo, colore, lato):
    from qgis.PyQt.QtCore import QByteArray
    from qgis.PyQt.QtGui import QPainter, QPixmap
    from qgis.PyQt.QtSvg import QSvgRenderer
    svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" '
           'stroke="%s" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">'
           '%s</svg>' % (colore, corpo))
    pm = QPixmap(lato, lato)
    pm.fill(Qt.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.Antialiasing, True)
    QSvgRenderer(QByteArray(svg.encode("utf-8"))).render(p)
    p.end()
    return pm


def _icona(corpo):
    """Icona a linea: grigio ardesia, blu notte (o bianco nel tema scuro)
    sulla voce selezionata."""
    if not corpo:
        return QIcon()
    scuro = tema_scuro()
    normale, attiva = ("#b8c0cc", "#ffffff") if scuro else ("#5f6b7d", NAVY)
    ic = QIcon()
    for lato in (18, 36, 54):
        ic.addPixmap(_pixmap_svg(corpo, normale, lato), QIcon.Normal)
        ic.addPixmap(_pixmap_svg(corpo, attiva, lato), QIcon.Selected)
    return ic


def barra_laterale(tabs_principali, rami):
    """Lista a sinistra: per ogni ramo (titolo, QTabWidget) una intestazione e
    una voce per ogni linguetta del ramo. Nasconde le linguette di
    tabs_principali e dei rami, e tiene sincronizzate lista e schede."""
    lista = QListWidget()
    lista.setObjectName("barraLaterale")
    lista.setIconSize(QSize(18, 18))
    lista.setSelectionMode(QAbstractItemView.SingleSelection)
    lista.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
    voci = {}
    font_t = QFont()
    font_t.setPointSizeF(max(7.5, font_t.pointSizeF() - 1))
    font_t.setBold(True)
    larghezza = 150
    # le tre macro categorie sono menu a tendina: clic sul titolo apre/chiude
    RUOLO_RAMO = Qt.UserRole + 1
    intestazioni = {}
    aperto = {}
    try:
        from qgis.core import QgsSettings
        _set = QgsSettings()
    except Exception:  # noqa: BLE001
        _set = None

    def _titolo(i):
        return "%s  %s" % ("▾" if aperto[i] else "▸", rami[i][0].upper())

    for i_ramo, (titolo, tabs) in enumerate(rami):
        aperto[i_ramo] = True
        if _set is not None:
            aperto[i_ramo] = str(_set.value("ftth_permessi/ramo_aperto_%d" % i_ramo,
                                            "true")).lower() == "true"
        it = QListWidgetItem(_titolo(i_ramo))
        it.setFlags(Qt.ItemIsEnabled)          # cliccabile, non selezionabile
        it.setFont(font_t)
        it.setForeground(QColor("#5b6470"))
        it.setData(RUOLO_RAMO, i_ramo)
        it.setToolTip("Clic per aprire o chiudere «%s»" % titolo)
        if i_ramo:
            it.setSizeHint(QSize(0, 34))
        lista.addItem(it)
        intestazioni[i_ramo] = it
        for j in range(tabs.count()):
            nome = tabs.tabText(j)
            v = QListWidgetItem(_icona(ICONE.get(nome)), nome)
            v.setData(Qt.UserRole, (i_ramo, j))
            lista.addItem(v)
            voci[(i_ramo, j)] = v
            v.setHidden(not aperto[i_ramo])
            larghezza = max(larghezza, lista.fontMetrics().horizontalAdvance(nome) + 60)
        tabs.tabBar().hide()
        tabs.setDocumentMode(True)
    tabs_principali.tabBar().hide()
    tabs_principali.setDocumentMode(True)
    lista.setFixedWidth(min(larghezza, 250))

    def _scelta(cur, _prev=None):
        if cur is None:
            return
        dato = cur.data(Qt.UserRole)
        if not dato:
            return
        i, j = dato
        tabs_principali.setCurrentIndex(i)
        rami[i][1].setCurrentIndex(j)

    def _apri(i, si):
        aperto[i] = si
        intestazioni[i].setText(_titolo(i))
        for (ii, _j), v in voci.items():
            if ii == i:
                v.setHidden(not si)
        if _set is not None:
            _set.setValue("ftth_permessi/ramo_aperto_%d" % i, "true" if si else "false")

    def _clic(item):
        i = item.data(RUOLO_RAMO)
        if i is not None:
            _apri(i, not aperto[i])

    lista.itemClicked.connect(_clic)

    def _sincronizza(*_a):
        i = tabs_principali.currentIndex()
        if not 0 <= i < len(rami):
            return
        if not aperto.get(i, True):
            _apri(i, True)          # la scheda aperta resta sempre visibile
        v = voci.get((i, rami[i][1].currentIndex()))
        if v is not None and lista.currentItem() is not v:
            lista.blockSignals(True)
            lista.setCurrentItem(v)
            lista.blockSignals(False)

    lista.currentItemChanged.connect(_scelta)
    tabs_principali.currentChanged.connect(_sincronizza)
    for _t, tabs in rami:
        tabs.currentChanged.connect(_sincronizza)
    _sincronizza()
    lista._sincronizza = _sincronizza   # usato dopo il ripristino delle schede
    return lista


def evidenzia_principali(radice):
    """Pulsanti principali (Genera…, Prepara consegna…) colorati."""
    for b in radice.findChildren(QPushButton):
        t = (b.text() or "").replace("&", "").strip()
        if any(t.startswith(p) for p in PRINCIPALI):
            b.setProperty("primario", True)
            b.style().unpolish(b)
            b.style().polish(b)


def log_leggibili(radice):
    """I log (QPlainTextEdit in sola lettura) a spaziatura fissa."""
    for e in radice.findChildren(QPlainTextEdit):
        if e.isReadOnly():
            e.setProperty("readOnly", True)
