# -*- coding: utf-8 -*-
"""Scheda «Consegna pratiche» (Altri Enti, ultima scheda).

Elenco delle istanze generate dalle schede Strade, RFI, Acque,
Soprintendenza e Parchi; controllo dei file che mancano; per ogni istanza
scelta una cartella di consegna con i file e il PDF unico nell'ordine
stabilito (istanza, relazione, PL, bollo, allegati), con l'avviso se supera
il limite della PEC. Mescolato in FTTHPermessiDialog.
"""
import os

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QDoubleSpinBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
    QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)
from qgis.core import QgsProject


def _c():
    try:
        from . import ftth_consegna as C
    except ImportError:
        import ftth_consegna as C
    return C


COL_INCL, COL_NOME, COL_STATO, COL_MANCA, COL_VERIF, COL_FILE = range(6)
COLORI = {"completa": QColor(200, 235, 200), "incompleta": QColor(255, 205, 205),
          # STATO_WORD di ftth_consegna
          "completa, ma con file solo in Word": QColor(255, 236, 179)}


class ConsegnaMixin:
    """Metodi della scheda Consegna pratiche."""

    def _tab_consegna_pratiche(self):
        self._cons_ist = []
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Raccoglie le istanze generate dalle schede Istanze Strade, RFI, Acque, "
            "Soprintendenza e Parchi (le cartelle con i file «1.0_…», «1.1_…»). Per ogni "
            "istanza dice cosa manca (istanza, relazione, PL) e cosa verificare (bollo, "
            "documento d'identità, procura). «Prepara consegna» crea la cartella "
            "Consegna/<istanza> con i file e un PDF unico nell'ordine istanza, "
            "relazione, PL, bollo, allegati. Documento d'identità e procura restano file "
            "separati: il plugin li riconosce solo dal nome, non li apre."))
        r = QHBoxLayout()
        r.addWidget(QLabel("Cartella delle pratiche:"))
        self.txt_cons_radice = QLineEdit()
        prj = QgsProject.instance()
        self.txt_cons_radice.setText(prj.homePath() or "")
        r.addWidget(self.txt_cons_radice, 1)
        b = QPushButton("Sfoglia…")
        b.clicked.connect(self._cons_sfoglia)
        r.addWidget(b)
        b = QPushButton("Cerca istanze")
        b.clicked.connect(self._cons_cerca)
        r.addWidget(b)
        v.addLayout(r)

        self.tab_cons = QTableWidget(0, 6)
        self.tab_cons.setHorizontalHeaderLabels(
            ["", "Istanza", "Stato", "Manca", "Da verificare", "File"])
        self.tab_cons.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tab_cons.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.tab_cons.horizontalHeader().setStretchLastSection(True)
        self.tab_cons.setMinimumHeight(220)
        self.tab_cons.itemSelectionChanged.connect(self._cons_dettaglio)
        v.addWidget(self.tab_cons)
        # «Seleziona tutte» / «Nessuna», come nelle schede istanze
        try:
            from . import ftth_trovati as _TR
            v.addLayout(_TR.riga_pulsanti(self.tab_cons, COL_INCL, "le istanze"))
        except Exception:  # noqa: BLE001
            pass
        self.lbl_cons_det = QLabel("")
        self.lbl_cons_det.setWordWrap(True)
        self.lbl_cons_det.setTextInteractionFlags(Qt.TextSelectableByMouse)
        v.addWidget(self.lbl_cons_det)

        r = QHBoxLayout()
        r.addWidget(QLabel("Limite PEC (MB):"))
        self.spn_cons_mb = QDoubleSpinBox()
        self.spn_cons_mb.setRange(1, 500)
        self.spn_cons_mb.setValue(30)
        self.spn_cons_mb.setDecimals(0)
        r.addWidget(self.spn_cons_mb)
        r.addStretch(1)
        b = QPushButton("Prepara consegna (istanze spuntate)")
        b.clicked.connect(self._cons_prepara)
        r.addWidget(b)
        b = QPushButton("Apri cartella Consegna")
        b.clicked.connect(self._cons_apri)
        r.addWidget(b)
        v.addLayout(r)
        self.log_cons = QPlainTextEdit()
        self.log_cons.setReadOnly(True)
        self.log_cons.setMinimumHeight(140)
        v.addWidget(self.log_cons)
        return w

    # ------------------------------------------------------------ azioni
    def _cons_radice(self):
        return (self.txt_cons_radice.text() or "").strip()

    def _cons_cartella_consegna(self):
        return os.path.join(self._cons_radice(), _c().CARTELLA_CONSEGNA)

    def _cons_sfoglia(self):
        d = QFileDialog.getExistingDirectory(self, "Cartella delle pratiche",
                                             self._cons_radice())
        if d:
            self.txt_cons_radice.setText(d)
            self._cons_cerca()

    def _cons_cerca(self):
        C = _c()
        self._cons_ist = C.cerca_istanze(self._cons_radice())
        t = self.tab_cons
        t.setRowCount(0)
        for ist in self._cons_ist:
            k = t.rowCount()
            t.insertRow(k)
            st = C.stato(ist)
            it = QTableWidgetItem()
            it.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            it.setCheckState(Qt.Checked if st != "incompleta" else Qt.Unchecked)
            t.setItem(k, COL_INCL, it)
            valori = [ist["nome"], st, ", ".join(ist["mancano"]) or "-",
                      ", ".join(ist["verificare"]) or "-", str(len(ist["file"]))]
            for c, testo in enumerate(valori, 1):
                x = QTableWidgetItem(testo)
                x.setToolTip(ist["cartella"])
                if c == COL_STATO:
                    x.setBackground(COLORI.get(st, QColor(255, 255, 255)))
                    word = C.file_solo_word(ist)
                    if word:
                        x.setToolTip(
                            "Questi documenti ci sono solo in Word, senza il PDF:\n  • %s\n\n"
                            "Con «Prepara consegna» vengono copiati nella cartella di "
                            "consegna, ma NON entrano nel PDF unico. Per metterli: salvali in "
                            "PDF (e firmali) nella cartella dell'istanza, oppure rigenera le "
                            "istanze con «Converti in PDF anche art. 49, Bollo e Modello B»; "
                            "poi premi «Cerca istanze»." % "\n  • ".join(word))
                    elif st == "incompleta":
                        x.setToolTip("Manca un documento obbligatorio: vedi la colonna "
                                     "«Manca».")
                t.setItem(k, c, x)
        t.resizeColumnsToContents()
        self.log_cons.appendPlainText("%d istanze trovate in %s" % (len(self._cons_ist),
                                                                    self._cons_radice()))

    def _cons_dettaglio(self):
        righe = sorted({i.row() for i in self.tab_cons.selectedIndexes()})
        if not righe or righe[0] >= len(self._cons_ist):
            self.lbl_cons_det.setText("")
            return
        C = _c()
        ist = self._cons_ist[righe[0]]
        parti = ["<b>%s</b> — %s" % (ist["nome"], ist["cartella"])]
        for n, tipo, nota in ist["file"]:
            parti.append("• %s: %s%s" % (C.TIPI[tipo][1], n, (" — <i>%s</i>" % nota)
                                         if nota else ""))
        self.lbl_cons_det.setText("<br>".join(parti))

    def _cons_prepara(self):
        C = _c()
        dest = self._cons_cartella_consegna()
        fatte = 0
        for k, ist in enumerate(self._cons_ist):
            it = self.tab_cons.item(k, COL_INCL)
            if it is None or it.checkState() != Qt.Checked:
                continue
            try:
                r = C.prepara_consegna(ist, dest, self.spn_cons_mb.value())
            except Exception as e:  # noqa: BLE001
                self.log_cons.appendPlainText("- %s: ERRORE %s" % (ist["nome"], e))
                continue
            fatte += 1
            self.log_cons.appendPlainText(
                "- %s -> %s\n    PDF unico: %s (%d pagine, %.1f MB); cartella %.1f MB"
                % (ist["nome"], r["cartella"], os.path.basename(r["pdf"]) or "-",
                   r["pagine"], r["mb"], r["mb_totali"]))
            for a in r["avvisi"] + ist["note"]:
                self.log_cons.appendPlainText("    ! %s" % a)
            for m in ist["mancano"]:
                self.log_cons.appendPlainText("    ! manca: %s" % m)
            for m in ist["verificare"]:
                self.log_cons.appendPlainText("    ? non trovato, verifica: %s" % m)
        self.log_cons.appendPlainText("Consegna preparata per %d istanze in %s" % (fatte, dest))

    def _cons_apri(self):
        d = self._cons_cartella_consegna()
        if os.path.isdir(d):
            QDesktopServices.openUrl(QUrl.fromLocalFile(d))
        else:
            self.log_cons.appendPlainText("La cartella %s non c'è ancora: usa «Prepara "
                                          "consegna»." % d)
