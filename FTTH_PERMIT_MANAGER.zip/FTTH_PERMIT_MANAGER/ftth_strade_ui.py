# -*- coding: utf-8 -*-
"""Sottoscheda «Genera istanze» di Istanze Strade (mixin di FTTHPermessiDialog).

1) Comune; 2) strade classificate toccate dal progetto (OSM), con l'ente
proposto dallo screening (gestore regionale, Citta' metropolitane, concessionari,
verifica ANAS, centri abitati e abitanti); 3) interferenze in sede e in fascia
di rispetto, con le progressive del campo «Chilometrica» (sottoscheda
Chilometriche); 4) genera: istanza art. 49 (modello strade dagli esempi ANAS e
Provincia), RT+CR, bollo e PL.
"""
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QCheckBox, QComboBox, QFormLayout, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
    QPlainTextEdit, QPushButton, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)


def _mod():
    try:
        from . import ftth_strade as S
        from . import ftth_acque as A
        from . import ftth_rfi as rfi
        from . import ftth_screening as scr
    except ImportError:
        import ftth_strade as S
        import ftth_acque as A
        import ftth_rfi as rfi
        import ftth_screening as scr
    return S, A, rfi, scr


PRJ_SCOPE = "ftth_strade_istanze"


class _InterrottoSti(BaseException):
    """«Interrompi»: BaseException perche' nessun `except Exception` la fermi."""
NOMI_CAMPO_KM = ("Chilometrica", "Chilometri", "CHILOMETRICA", "KM", "Km", "PROGRESSIVA")
# colonne tabella strade
CS_INCL, CS_REF, CS_NOME, CS_METRI, CS_ENTE, CS_UFF, CS_IND, CS_PEC, CS_FASCIA, CS_EPC, \
    CS_NOTA, CS_VALIDA = range(12)
# campo con il testo dell'etichetta in tavola («KM … SCAVO …»), negli shape
CAMPO_ETICHETTA = "ETICHETTA"
GRUPPO_ETICHETTE = "Etichette in stampa"
# nomi dei campi con la sigla della strada negli stradari del progetto
CAMPI_SIGLA = ("ref", "sigla", "cod_strada", "codice", "cod_str", "sigla_str", "nome_strad")
# colonne tabella interferenze
CI_INCL, CI_N, CI_STRADA, CI_ZONA, CI_KM, CI_LAVORI, CI_NOTE = range(7)


class StradeIstanzeMixin:
    """Metodi della sottoscheda Genera istanze (Istanze Strade)."""

    def _sti_incorpora(self, titolo, widget, compresso=True):
        """Riquadro numerato che contiene un'ex sottoscheda (Chilometriche,
        Etichette, Suolo comunale). I suoi riquadri interni perdono il numero
        («1) Calcolo» -> «Calcolo») per non confondersi con i passi 1-6."""
        import re as _re
        gb = self._gruppo(titolo, compresso=compresso)
        lay = QVBoxLayout(gb)
        lay.setContentsMargins(4, 4, 4, 4)
        try:
            from qgis.gui import QgsCollapsibleGroupBox
            for g in widget.findChildren(QgsCollapsibleGroupBox):
                g.setTitle(_re.sub(r"^\s*\d+\)\s*", "", g.title()))
        except Exception:  # noqa: BLE001
            pass
        lay.addWidget(widget)
        return gb

    def _sti_avviso_incorpora(self, nome, e):
        try:
            from qgis.core import Qgis, QgsMessageLog
            QgsMessageLog.logMessage("Istanze Strade, riquadro %s: %s" % (nome, e),
                                     "FTTH Permessi", Qgis.Warning)
        except Exception:  # noqa: BLE001
            pass

    def _tab_strade_istanze(self):
        S, A, rfi, scr = _mod()
        self._sti = {"strade": [], "interferenze": [], "comune": {}}
        w = QWidget()
        v = QVBoxLayout(w)
        from . import ftth_passi as _P
        v.addWidget(_P.intro(self, "strade", "Istanze art. 49 agli enti delle strade."))
        try:
            from . import ftth_leggimi as _LG
            v.addWidget(_LG.riga(self, "strade"))
        except Exception:  # noqa: BLE001
            pass

        gb1 = self._gruppo(_P.titolo(1, "strade"), compresso=False)
        f1 = QFormLayout(gb1)
        self.txt_sti_comune = QLineEdit()
        try:                                    # suggerimento comuni ISTAT
            from . import ftth_comuni as _COM
            _COM.aggiungi_suggerimenti(self.txt_sti_comune)
        except Exception:
            pass
        for nome in ("txt_acq_comune", "txt_rfi_comune"):
            t = getattr(self, nome, None)
            if t is not None and t.text().strip():
                self.txt_sti_comune.setText(t.text().strip().title())
                break
        self.txt_sti_prov = QLineEdit()
        self.txt_sti_prov.setMaximumWidth(60)
        self.txt_sti_cap = QLineEdit()
        self.txt_sti_cap.setMaximumWidth(80)
        try:            # scritto il comune: provincia (ISTAT) e CAP da soli
            from . import ftth_comuni as _COM
            _COM.collega_prov_cap(self.txt_sti_comune, self.txt_sti_prov, self.txt_sti_cap,
                                  log=lambda m: self._log_sti(m))
            if self.txt_sti_comune.text().strip():
                self.txt_sti_prov.setText(_COM.sigla_di(self.txt_sti_comune.text()))
        except Exception:
            pass
        r1 = QHBoxLayout()
        r1.addWidget(self.txt_sti_comune)
        r1.addWidget(QLabel("Prov."))
        r1.addWidget(self.txt_sti_prov)
        r1.addWidget(QLabel("CAP"))
        r1.addWidget(self.txt_sti_cap)
        f1.addRow("Comune:", r1)
        # indirizzo e PEC del Comune in e.p.c.: al passo 4, come in tutte le schede
        self.txt_sti_ind_comune = QLineEdit()
        self.txt_sti_pec_comune = QLineEdit()
        v.addWidget(gb1)

        # il vecchio «suolo comunale» (spostava e cancellava dai layer
        # principali) e' sostituito dai gruppi per istanza: resta solo il
        # ritorno per i progetti in cui era stato usato
        try:
            if hasattr(self, "_suolo_registro") and self._suolo_registro():
                r_su = QHBoxLayout()
                lab = QLabel("In questo progetto il «suolo comunale» aveva spostato elementi "
                             "fuori dai layer principali:")
                lab.setWordWrap(True)
                b_su = QPushButton("Riporta nel livello principale")
                b_su.clicked.connect(self._riporta_suolo_comunale)
                r_su.addWidget(lab, 1)
                r_su.addWidget(b_su)
                v.addLayout(r_su)
        except Exception:  # noqa: BLE001
            pass

        gb2 = self._gruppo(_P.titolo(2, "strade"), compresso=False)
        v2 = QVBoxLayout(gb2)
        r2 = QHBoxLayout()
        b = _P.primario(_P.TROVA["strade"])
        b.setToolTip("Strade classificate (A, SS, SR, SP) entro 50 m dalla rete nuova, con "
                     "l'ente proposto: gestore regionale, Città metropolitana o Provincia, "
                     "concessionario autostradale, verifica sul sito ANAS e regola dei centri "
                     "abitati (art. 2 c. 7 e art. 26 CdS). Le strade si leggono prima dallo "
                     "stradario del progetto (veloce); OSM solo se nel progetto non c'è.\n"
                     "Le strade proposte sono evidenziate in tabella e in mappa ma NON "
                     "spuntate: per ognuna premi «Conferma» (ti chiede l'ente) o «Escludi».")
        b.clicked.connect(self._sti_trova_strade)
        r2.addWidget(b)
        self.bar_sti = None
        try:
            try:
                from .ftth_barra import BarraAvanzamento
            except ImportError:
                from ftth_barra import BarraAvanzamento
            self.bar_sti = BarraAvanzamento()
            self.bar_sti.setVisible(False)
            r2.addWidget(self.bar_sti, 1)
        except Exception:  # noqa: BLE001
            pass
        self.btn_sti_stop = QPushButton("Interrompi")
        self.btn_sti_stop.setVisible(False)
        self.btn_sti_stop.clicked.connect(self._sti_interrompi)
        r2.addWidget(self.btn_sti_stop)
        r2.addStretch()
        v2.addLayout(r2)
        self.tab_sti_strade = QTableWidget(0, 12)
        self.tab_sti_strade.setHorizontalHeaderLabels(
            ["Incl.", "Strada", "Nome", "Rete entro 50 m", "Ente destinatario", "Ufficio",
             "Indirizzo", "PEC", "Fascia (m)", "e.p.c. Comune", "Competenza (screening)",
             "Valida"])
        # «Valida» (Conferma / Escludi) subito dopo la spunta
        self.tab_sti_strade.horizontalHeader().moveSection(CS_VALIDA, 1)
        self.tab_sti_strade.setMinimumHeight(150)
        self.tab_sti_strade.horizontalHeader().setStretchLastSection(True)
        self.tab_sti_strade.cellDoubleClicked.connect(self._sti_zoom_strada)
        v2.addWidget(self.tab_sti_strade)
        from . import ftth_trovati as _TR
        v2.addLayout(_TR.riga_pulsanti(
            self.tab_sti_strade, CS_INCL, "le strade",
            proposti=lambda r: r < len(self._sti.get("strade") or []) and
            getattr(self._sti["strade"][r], "metri", 0) > 0,
            mostra=self._sti_mostra_strade))
        # altre fonti: uno stradario del progetto (es. stradario provinciale)
        gb_alt = self._gruppo("Avanzate: strade da un altro layer del progetto")
        v_alt = QVBoxLayout(gb_alt)
        v_alt.addWidget(self._desc(
            "Se manca una strada o la sigla: scegli un layer di linee e il campo con la sigla "
            "(SP18, SS45…), poi «Aggiungi»."))
        r_alt = QHBoxLayout()
        from qgis.core import QgsMapLayerProxyModel as _PM
        from qgis.gui import QgsFieldComboBox as _FC, QgsMapLayerComboBox as _LC
        self.cb_sti_alt = _LC()
        self.cb_sti_alt.setFilters(_PM.LineLayer)
        self.cb_sti_alt.setAllowEmptyLayer(True)
        self.cb_sti_alt.setLayer(None)
        self.cb_sti_alt_sigla = _FC()
        self.cb_sti_alt_nome = _FC()
        self.cb_sti_alt_nome.setAllowEmptyFieldName(True)
        self.cb_sti_alt.layerChanged.connect(self.cb_sti_alt_sigla.setLayer)
        self.cb_sti_alt.layerChanged.connect(self.cb_sti_alt_nome.setLayer)
        r_alt.addWidget(self.cb_sti_alt, 1)
        r_alt.addWidget(QLabel("sigla:"))
        r_alt.addWidget(self.cb_sti_alt_sigla)
        r_alt.addWidget(QLabel("nome:"))
        r_alt.addWidget(self.cb_sti_alt_nome)
        b_alt = QPushButton("Aggiungi")
        b_alt.clicked.connect(self._sti_da_layer)
        r_alt.addWidget(b_alt)
        v_alt.addLayout(r_alt)
        lab_c = _P.proposte(self)
        lab_c.setToolTip(
            "Nei centri abitati oltre 10.000 abitanti i tratti interni sono comunali (art. 2 "
            "c. 7 CdS); sotto i 10.000 autorizza il Comune con il nulla osta dell'ente (art. "
            "26 c. 3). Per le statali conta la classe di popolazione del centro abitato "
            "indicata da ANAS.")
        v2.addWidget(lab_c)
        v2.addWidget(gb_alt)            # avanzate: sempre in fondo al passo
        v.addWidget(gb2)

        # 3) interferenze, 4) progressive km: prima le interferenze, poi i cippi
        # (come nelle altre schede: «Trova» -> tabella -> mappa)
        gb3 = self._gruppo(_P.titolo(3, "strade"), compresso=False)
        v3 = QVBoxLayout(gb3)
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
        f3 = QFormLayout()
        # le opzioni delle progressive stanno nel punto 4 (qui sotto nel
        # codice), le legge anche «Trova le interferenze»
        gb_km = self._gruppo("Chilometriche: da dove prendo il km (una riga per strada)",
                             compresso=False)
        v_km = QVBoxLayout(gb_km)
        v_km.addWidget(self._desc(
            "Il km di scavi, pozzetti e armadi si calcola dai cippi chilometrici della strada. "
            "Qui sotto scegli da dove prendere i cippi per tutte le strade; nella tabella puoi "
            "cambiarlo per una sola strada (anche «nessun cippo: solo coordinate»). Senza "
            "almeno 2 cippi sulla strada si usa il campo Chilometrica dei layer, se c'è, "
            "altrimenti le coordinate. Poi premi «Calcola le chilometriche delle tratte»: la "
            "colonna «Risultato» dice cosa è stato usato."))
        f_km = QFormLayout()
        # opzioni usate di rado: in un riquadro chiuso sotto la tabella
        gb_km_av = self._gruppo("Avanzate: modo delle progressive e campo Chilometrica")
        v_km_av = QVBoxLayout(gb_km_av)
        f_km_av = QFormLayout()
        v_km_av.addLayout(f_km_av)
        self.cb_sti_modo_km = QComboBox()
        self.cb_sti_modo_km.addItem("Automatiche: proiezione sull'asse della strada tarata sui "
                                    "cippi", "auto")
        self.cb_sti_modo_km.addItem("Dal campo Chilometrica dei layer (strumento qui sotto)",
                                    "campo")
        self.cb_sti_modo_km.setToolTip(
            "Automatiche: per ogni scavo si proiettano sull'asse della strada solo inizio e fine "
            "(e il punto di pozzetti e armadi), tarando con i cippi del layer qui sotto e con i "
            "cippi di OSM. Le tratte storte non contano più. Se i cippi non bastano si usa il "
            "campo dei layer, poi le coordinate.")
        f_km_av.addRow("Progressive (tutte le strade):", self.cb_sti_modo_km)
        # non si ricorda fra le sessioni: si parte sempre dai cippi
        self.cb_sti_modo_km.setProperty("non_memorizzare", True)
        r_c = QHBoxLayout()
        self.cb_sti_cippi = QgsMapLayerComboBox()
        self.cb_sti_cippi.setFilters(QgsMapLayerProxyModel.PointLayer)
        self.cb_sti_cippi.setAllowEmptyLayer(True)
        self.cb_sti_cippi.setLayer(None)
        try:
            for nome_l in ("Cippi_Chilometrici", "Cippi chilometrici", "Ancore km"):
                ll = self.project.mapLayersByName(nome_l)
                if ll:
                    self.cb_sti_cippi.setLayer(ll[0])
                    break
        except Exception:  # noqa: BLE001
            pass
        self.cb_sti_campo_cippo = QgsFieldComboBox()

        def _campo_cippo(lyr):
            self.cb_sti_campo_cippo.setLayer(lyr)
            if lyr is not None:
                nomi = [f.name() for f in lyr.fields()]
                scelto = next((n for n in nomi if n.lower().startswith("chilom")), None) or \
                    next((n for n in nomi if n.lower() in ("km", "progressiva", "distance")),
                         None)
                if scelto:
                    self.cb_sti_campo_cippo.setField(scelto)
        self.cb_sti_cippi.layerChanged.connect(_campo_cippo)
        _campo_cippo(self.cb_sti_cippi.currentLayer())
        r_c.addWidget(self.cb_sti_cippi, 1)
        r_c.addWidget(QLabel("campo km:"))
        r_c.addWidget(self.cb_sti_campo_cippo)
        # scelta esplicita della fonte dei cippi (prima: layer + casella «anche
        # OSM», poco chiara); la casella resta nascosta per il codice che la legge
        self.chk_sti_cippi_osm = QCheckBox("anche i cippi di OSM")
        self.chk_sti_cippi_osm.setChecked(True)
        self.chk_sti_cippi_osm.setVisible(False)
        self.cb_sti_fonte_cippi = QComboBox()
        for testo, dato in (("Cippi creati nel progetto", "progetto"),
                            ("Cippi di OpenStreetMap", "osm"),
                            ("Cippi del progetto + OpenStreetMap", "entrambi")):
            self.cb_sti_fonte_cippi.addItem(testo, dato)
        self.cb_sti_fonte_cippi.setToolTip(
            "Da dove prendere i cippi chilometrici per tarare le progressive delle tratte: "
            "il layer dei cippi creati nel progetto (scegli layer e campo km), i cippi di "
            "OpenStreetMap, o tutti e due.")

        def _fonte_cippi(*_a):
            f = self.cb_sti_fonte_cippi.currentData()
            self.chk_sti_cippi_osm.setChecked(f in ("osm", "entrambi"))
            # scelti i cippi, le progressive si calcolano con quelli (prima un
            # «campo dei layer» rimasto nelle avanzate li faceva ignorare)
            i_auto = self.cb_sti_modo_km.findData("auto")
            if i_auto >= 0:
                self.cb_sti_modo_km.setCurrentIndex(i_auto)
            for w_ in (self.cb_sti_cippi, self.cb_sti_campo_cippo):
                w_.setEnabled(f != "osm")
        self.cb_sti_fonte_cippi.currentIndexChanged.connect(_fonte_cippi)
        self.cb_sti_fonte_cippi.setCurrentIndex(
            self.cb_sti_fonte_cippi.findData("entrambi" if self.cb_sti_cippi.currentLayer()
                                             else "osm"))
        _fonte_cippi()
        f_km.addRow("Da dove prendo il km (tutte le strade):", self.cb_sti_fonte_cippi)
        b_crea_c = QPushButton("Crea il layer cippi")
        b_crea_c.setToolTip("Crea il layer di punti «Cippi_Chilometrici» (strada, km) accanto "
                            "al progetto e ti mette a disegnare i cippi.")
        b_crea_c.clicked.connect(self._sti_crea_layer_cippi)
        r_c.addWidget(b_crea_c)
        f_km.addRow("Layer cippi del progetto (facoltativo):", r_c)
        self.chk_sti_scrivi_km = QCheckBox(
            "Scrivi Chilometrica ed ETICHETTA negli shape (tratte, pozzetti, armadi) e mostra "
            "in mappa le etichette come in stampa")
        self.chk_sti_scrivi_km.setChecked(True)
        self.chk_sti_scrivi_km.setToolTip(
            "Dopo il calcolo, in 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO: campo "
            "Chilometrica («dal km … al km …» per le tratte, il km per pozzetti e armadi) e "
            "campo ETICHETTA (il testo della tavola, es. «KM 11+756 / POSA POZZETTO 40x76»). "
            "In mappa il gruppo «Etichette in stampa» li mostra. Se correggi uno dei due campi "
            "nello shape, alla generazione vale la tua correzione. Modifica gli shape.")
        f_km.addRow(self.chk_sti_scrivi_km)
        r_k = QHBoxLayout()
        self.cb_sti_campo_km = QComboBox()
        self.cb_sti_campo_km.setEditable(True)
        for n in NOMI_CAMPO_KM:
            self.cb_sti_campo_km.addItem(n)
        self.cb_sti_campo_km.setToolTip("Campo scritto dallo strumento «Scrivi il campo "
                                        "Chilometrica sui layer» su tratte, pozzetti e armadi "
                                        "(riserva).")
        r_k.addWidget(self.cb_sti_campo_km)
        r_k.addStretch()
        f_km_av.addRow("Campo progressiva dei layer:", r_k)
        # grafica delle etichette: stessa in mappa e in stampa
        from qgis.PyQt.QtWidgets import QDoubleSpinBox
        from . import ftth_strade_layout as _SL
        dim0, riq0 = _SL.grafica_etichette()
        r_g = QHBoxLayout()
        self.spin_sti_etich = QDoubleSpinBox()
        self.spin_sti_etich.setRange(4, 14)
        self.spin_sti_etich.setSingleStep(0.5)
        self.spin_sti_etich.setValue(dim0)
        self.spin_sti_etich.setSuffix(" pt")
        self.spin_sti_etich.setProperty("non_memorizzare", True)
        self.chk_sti_etich_riq = QCheckBox("riquadro bianco con bordo")
        self.chk_sti_etich_riq.setChecked(riq0)
        self.chk_sti_etich_riq.setProperty("non_memorizzare", True)

        def _grafica(*_a):
            try:
                from qgis.core import QgsSettings
                QgsSettings().setValue("ftth_permessi/etich_dim", self.spin_sti_etich.value())
                QgsSettings().setValue("ftth_permessi/etich_riquadro",
                                       "true" if self.chk_sti_etich_riq.isChecked() else "false")
                from . import ftth_gruppi_istanze as GR
                if GR.registro(self.project).get("_etichette"):
                    self._sti_layer_etichette()
            except Exception as e:  # noqa: BLE001
                self._log_sti("Grafica etichette non applicata: %s" % e)
        self.spin_sti_etich.valueChanged.connect(_grafica)
        self.chk_sti_etich_riq.toggled.connect(_grafica)
        r_g.addWidget(QLabel("dimensione"))
        r_g.addWidget(self.spin_sti_etich)
        r_g.addWidget(self.chk_sti_etich_riq)
        r_g.addStretch()
        f_km_av.addRow("Grafica delle etichette (mappa e stampa):", r_g)
        v_km.addLayout(f_km)
        self.tab_sti_km = QTableWidget(0, 7)
        self.tab_sti_km.setHorizontalHeaderLabels(
            ["Strada", "Interferenze", "Da dove prendo il km", "Layer cippi", "Campo km",
             "Cippi usati", "Risultato"])
        self.tab_sti_km.setMinimumHeight(120)
        self.tab_sti_km.horizontalHeader().setStretchLastSection(True)
        v_km.addWidget(self.tab_sti_km)
        r_kb = QHBoxLayout()
        b_ric = QPushButton("Calcola le chilometriche delle tratte")
        b_ric.setToolTip("Calcola le progressive (km) di scavi, pozzetti e armadi delle "
                         "interferenze con i cippi scelti sopra (o quelli della riga di ogni "
                         "strada). Le spunte delle interferenze restano.")
        b_ric.setProperty("primario", True)
        r_kb.addWidget(b_ric)
        # barra del calcolo, accanto al pulsante (non quella del punto 3)
        from .ftth_barra import crea_barra
        self.bar_sti_km = crea_barra(r_kb)
        b_ric.clicked.connect(lambda *_: self._sti_trova(bar=self.bar_sti_km))
        v_km.addLayout(r_kb)
        # l'ex sottoscheda Chilometriche: scrive il campo Chilometrica sui
        # layer, serve solo per la fonte «campo dei layer»: dentro le avanzate
        if hasattr(self, "_tab_chilometriche"):
            try:
                v_km_av.addWidget(self._sti_incorpora(
                    "Strumento: scrivi il campo Chilometrica sui layer",
                    self._tab_chilometriche()))
            except Exception as e:  # noqa: BLE001
                self._sti_avviso_incorpora("Chilometriche", e)
        v_km.addWidget(gb_km_av)
        r_ca = QHBoxLayout()
        self.cb_sti_centri = QgsMapLayerComboBox()
        self.cb_sti_centri.setFilters(QgsMapLayerProxyModel.PolygonLayer)
        self.cb_sti_centri.setAllowEmptyLayer(True)
        self.cb_sti_centri.setLayer(None)
        self.cb_sti_centri_nome = QgsFieldComboBox()
        self.cb_sti_centri_nome.setAllowEmptyFieldName(True)
        self.cb_sti_centri_pop = QgsFieldComboBox()
        self.cb_sti_centri_pop.setAllowEmptyFieldName(True)
        self.cb_sti_centri.layerChanged.connect(self.cb_sti_centri_nome.setLayer)
        self.cb_sti_centri.layerChanged.connect(self.cb_sti_centri_pop.setLayer)
        self.cb_sti_centri.setToolTip(
            "Perimetro dei centri abitati deliberato dal Comune (art. 4 CdS). Dentro il centro "
            "abitato la fascia di rispetto non vale; oltre 10.000 abitanti il tratto è "
            "comunale. Per le statali, se manca, si usano i centri abitati del sito ANAS.")
        r_ca.addWidget(self.cb_sti_centri, 1)
        r_ca.addWidget(QLabel("nome:"))
        r_ca.addWidget(self.cb_sti_centri_nome)
        r_ca.addWidget(QLabel("abitanti:"))
        r_ca.addWidget(self.cb_sti_centri_pop)
        f3.addRow("Centri abitati (perimetri):", r_ca)
        gb_ca = self._gruppo("Avanzate: perimetri dei centri abitati del Comune")
        v_ca = QVBoxLayout(gb_ca)
        v_ca.addWidget(self._desc("Facoltativo: dentro il centro abitato la fascia di rispetto "
                                  "non vale. Senza layer, per le statali valgono i centri "
                                  "abitati del sito ANAS."))
        v_ca.addLayout(f3)
        r3 = QHBoxLayout()
        b3 = _P.primario("Trova le interferenze", self._sti_trova)
        r3.addWidget(b3)
        self.bar_sti_i = None
        try:
            try:
                from .ftth_barra import BarraAvanzamento
            except ImportError:
                from ftth_barra import BarraAvanzamento
            self.bar_sti_i = BarraAvanzamento()
            self.bar_sti_i.setVisible(False)
            r3.addWidget(self.bar_sti_i, 1)
        except Exception:  # noqa: BLE001
            r3.addStretch()
        v3.addLayout(r3)
        self.tab_sti = QTableWidget(0, 7)
        self.tab_sti.setHorizontalHeaderLabels(
            ["Incl.", "N.", "Strada", "Dove", "Progressiva", "Lavori", "Note"])
        self.tab_sti.setMinimumHeight(170)
        self.tab_sti.horizontalHeader().setStretchLastSection(True)
        self.tab_sti.cellDoubleClicked.connect(self._sti_zoom_interferenza)
        self.tab_sti.itemChanged.connect(
            lambda it: it.column() == CI_INCL and self._sti_aggiorna_titoli())
        v3.addWidget(self.tab_sti)
        from . import ftth_trovati as _TR
        v3.addLayout(_TR.riga_pulsanti(self.tab_sti, CI_INCL, "le interferenze",
                                       mostra=self._sti_mostra_interferenze))
        v3.addWidget(_P.nota3(self, "Dove: in sede stradale o in fascia di rispetto."))
        # conferma (campo IST_STRADE negli shape) e vista per strada con gli
        # occhi: lo stesso riquadro di tutte le schede istanze
        try:
            from . import ftth_gruppi_istanze as _GR
            self._sti_riquadro = _GR.riquadro(self, "strade", self._sti_istanze_per_gruppi)
            v3.addWidget(self._sti_riquadro)
        except Exception as e:  # noqa: BLE001
            self._sti_avviso_incorpora("Conferma e vista per istanza", e)
        # chilometriche con i cippi: dentro il passo 3, dopo la conferma
        v3.addWidget(gb_km)
        v3.addWidget(gb_ca)             # avanzate: sempre in fondo al passo
        v.addWidget(gb3)
        # titoli dei passi con lo stato («2) … — 3 da confermare»)
        self._sti_gb = {2: (gb2, gb2.title()), 3: (gb3, gb3.title()),
                        4: (gb_km, gb_km.title())}

        # 4) enti e destinatari
        gb_en = self._gruppo(_P.titolo(4, "strade"), compresso=False)
        f_en = QFormLayout(gb_en)
        f_en.addRow(_P.nota4(
            self, "L'ente di ogni strada è quello confermato al punto 2 (colonne Ente "
            "destinatario, Ufficio, Indirizzo, PEC: si correggono lì)."))
        _P.comune_epc(f_en, self.txt_sti_ind_comune, self.txt_sti_pec_comune)
        v.addWidget(gb_en)

        # 5) foto, sezioni e generazione
        gb4 = self._gruppo(_P.titolo(5, "strade"), compresso=False)
        v4 = QVBoxLayout(gb4)
        if hasattr(self, "_rfi_prepara_foto_sezioni"):
            v4.addLayout(_P.riga_foto(self, self._rfi_prepara_foto_sezioni))
        v4.addWidget(_P.nota5(self, "strade"))
        f4 = QFormLayout()
        self.cb_sti_righe = QComboBox()
        self.cb_sti_righe.addItem("Progressive chilometriche (coordinate se mancano)", "km")
        self.cb_sti_righe.addItem("Coordinate", "coordinate")
        f4.addRow("Tratti nelle tabelle RT:", self.cb_sti_righe)
        self.cb_sti_orto = QComboBox()
        self.cb_sti_orto.addItem("automatico (ortofoto del progetto o Esri World Imagery)", None)
        try:
            from qgis.core import QgsRasterLayer
            for l in self.project.mapLayers().values():
                if isinstance(l, QgsRasterLayer):
                    self.cb_sti_orto.addItem(l.name(), l.id())
        except Exception:  # noqa: BLE001
            pass
        f4.addRow("Ortofoto per le tavole:", self.cb_sti_orto)
        v4.addLayout(f4)
        self.chk_sti_pl = QCheckBox("Genera la planimetria 1.1 PL (layout QGIS + PDF)")
        self.chk_sti_pl.setChecked(True)
        self.chk_sti_a3 = QCheckBox("PL in formato A3 a quattro riquadri (come Acque e RFI) "
                                    "invece dell'A1 delle pratiche strade")
        self.chk_sti_a3.setToolTip("Senza spunta: A1 come le pratiche consegnate (inquadramento "
                                   "generale + tavole a 1:500 con sezioni e foto).")
        self.chk_sti_fascia = QCheckBox("Per ANAS: fascia di rispetto nelle tavole (solo "
                                        "tratteggio, senza riempimento)")
        self.chk_sti_fascia.setChecked(True)
        self.chk_sti_pdf = QCheckBox("Converti in PDF anche istanza e bollo (la RT è sempre in "
                                     "PDF)")
        v4.addWidget(self.chk_sti_pl)
        # opzioni usate di rado: riquadro chiuso
        gb4_av = self._gruppo("Avanzate: formato, PDF e loghi")
        v4_av = QVBoxLayout(gb4_av)
        v4_av.addWidget(self.chk_sti_a3)
        v4_av.addWidget(self.chk_sti_fascia)
        v4_av.addWidget(self.chk_sti_pdf)
        self.chk_sti_attr = QCheckBox("Segna gli attraversamenti con «*» e la nota sulla trincea "
                                      "tradizionale anche per enti diversi da ANAS")
        self.chk_sti_attr.setToolTip("Per ANAS sono sempre nella relazione (pratica SS71); per "
                                     "gli altri enti solo se spunti qui.")
        v4_av.addWidget(self.chk_sti_attr)
        try:    # logo FiberCop «Milano Cortina 2026» (stessa casella in tutte le schede)
            from . import ftth_logo as _LOGO
            v4_av.addWidget(_LOGO.crea_checkbox(self))
            from . import ftth_arlo as _ARLO
            v4_av.addWidget(_ARLO.crea_checkbox(self))
        except Exception:  # noqa: BLE001
            pass
        v4.addWidget(gb4_av)

        # l'ex strumento Etichette non serve più (le etichette sono nel campo
        # ETICHETTA, punto 4): i suoi controlli esistono ancora, nascosti,
        # perché altre parti del plugin li impostano
        if hasattr(self, "_tab_etichette"):
            try:
                w_et = self._tab_etichette()
                w_et.setVisible(False)
                v.addWidget(w_et)
            except Exception as e:  # noqa: BLE001
                self._sti_avviso_incorpora("Etichette", e)

        v6 = v4
        r4, _bg = _P.riga_genera(self._sti_genera, self._sti_apri_cartella, self, "_log_sti")
        v6.addLayout(r4)
        self.log_sti = QPlainTextEdit()
        self.log_sti.setReadOnly(True)
        self.log_sti.setMinimumHeight(110)
        v6.addWidget(self.log_sti)
        v.addWidget(gb4)
        v.addStretch()
        self._sti_ripristina()
        return w

    # ------------------------------------------------------------ utilità
    def _log_sti(self, msg):
        self.log_sti.appendPlainText(str(msg))
        self.log_sti.repaint()

    def _sti_ripristina(self):
        prj = getattr(self, "project", None)
        if prj is None:
            return
        for k, t in (("comune", self.txt_sti_comune), ("prov", self.txt_sti_prov),
                     ("cap", self.txt_sti_cap), ("ind_comune", self.txt_sti_ind_comune),
                     ("pec_comune", self.txt_sti_pec_comune)):
            val, ok = prj.readEntry(PRJ_SCOPE, k, "")
            if ok and val:
                t.setText(val)

    def _sti_salva(self):
        prj = getattr(self, "project", None)
        if prj is None:
            return
        for k, t in (("comune", self.txt_sti_comune), ("prov", self.txt_sti_prov),
                     ("cap", self.txt_sti_cap), ("ind_comune", self.txt_sti_ind_comune),
                     ("pec_comune", self.txt_sti_pec_comune)):
            prj.writeEntry(PRJ_SCOPE, k, t.text().strip())

    def _sti_sottofondo(self, funzione, *args):
        """Esegue `funzione` in un thread tenendo viva QGIS, con la barra che
        avanza e il pulsante «Interrompi» attivo."""
        import concurrent.futures as cf
        import time as _t
        from qgis.PyQt.QtWidgets import QApplication
        ex = cf.ThreadPoolExecutor(max_workers=1)
        fut = ex.submit(funzione, *args)
        try:
            while not fut.done():
                QApplication.processEvents()
                if self._sti.get("stop"):
                    raise _InterrottoSti()
                if self._sti_barra() is not None:
                    self._sti_barra().avanza()
                _t.sleep(0.1)
            return fut.result()
        finally:
            ex.shutdown(wait=False)

    def _sti_barra(self):
        """Barra della ricerca in corso (punto 2 o punto 4)."""
        return getattr(self, "_sti_bar_corrente", None) or getattr(self, "bar_sti", None)

    def _sti_fase(self, da, a, testo):
        self._log_sti(testo + "…")
        if self._sti_barra() is not None:
            self._sti_barra().fase(da, a, testo)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

    def _sti_interrompi(self, *_):
        self._sti["stop"] = True

    # ------------------------------------------------------------ strade
    def _sti_trova_strade(self):
        self._sti["stop"] = False
        self.btn_sti_stop.setVisible(True)
        try:
            self._sti_trova_strade_impl()
            if getattr(self, "bar_sti", None) is not None:
                self.bar_sti.fine("Strade proposte: %d — confermale o scartale" % sum(
                    1 for s in self._sti.get("strade") or [] if getattr(s, "metri", 0) > 0))
        except _InterrottoSti:
            self._log_sti("Interrotto.")
            if getattr(self, "bar_sti", None) is not None:
                self.bar_sti.interrotta("Interrotto")
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_sti("ERRORE:\n" + traceback.format_exc())
            if getattr(self, "bar_sti", None) is not None:
                self.bar_sti.interrotta("Errore: vedi il registro in fondo")
            QMessageBox.critical(self, "Errore", str(e))
        finally:
            self.btn_sti_stop.setVisible(False)

    def _sti_tratte_wgs(self):
        rete = self._acq_rete()
        if not rete:
            return []
        return [t["geom"] for t in rete[0] if (t.get("stato") or "").strip().lower()
                != "esistente"]

    def _sti_trova_strade_impl(self):
        S, A, rfi, scr = _mod()
        nome = self.txt_sti_comune.text().strip()
        if not nome:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune al punto 1.")
            return
        tratte = self._sti_tratte_wgs()
        if not tratte:
            QMessageBox.warning(self, "Rete mancante", "Manca la rete nuova in '03 "
                                                       "INFRASTRUTTURE'.")
            return
        self.log_sti.clear()
        if getattr(self, "bar_sti", None) is not None:
            self.bar_sti.azzera()
        self._sti_fase(0, 15, "Dati del comune")
        c = self._sti_sottofondo(scr.risolvi_comune, nome, None)
        d = c.data or {}
        self._sti["comune"] = d
        if d.get("provincia") and not self.txt_sti_prov.text().strip():
            self.txt_sti_prov.setText(rfi.sigla_provincia(d["provincia"]) or "")
        if d.get("cap") and not self.txt_sti_cap.text().strip():
            self.txt_sti_cap.setText(str(d["cap"]).split(";")[0].strip())
        self._log_sti("Comune: %s — %s, %s abitanti" % (
            d.get("nome") or nome, d.get("regione") or "?",
            d.get("popolazione") if d.get("popolazione") is not None else "n.d."))
        # strade con sigla intorno alla rete: prima lo stradario del progetto
        # (veloce), OSM solo se nel progetto non c'e'
        strade = None
        lyr_s, c_sig, c_nom = self._sti_stradario_progetto(tratte)
        if lyr_s is not None:
            self._sti_fase(15, 80, "Strade dallo stradario del progetto «%s»" % lyr_s.name())
            strade = self._sti_strade_da_layer(lyr_s, c_sig, c_nom, tratte)
            if strade:
                self._log_sti("Strade dallo stradario del progetto «%s» (campo %s): %d."
                              % (lyr_s.name(), c_sig, len(strade)))
            else:
                self._log_sti("Lo stradario «%s» non ha strade con sigla attorno alla rete: "
                              "cerco su OSM." % lyr_s.name())
        if not strade:
            strade = self._sti_strade_osm(tratte)
            if strade is None:
                return
        self._sti_fase(82, 85, "Strade vicine alla rete")
        self._sti_concludi_strade(strade, d, nome)

    def _sti_strade_osm(self, tratte):
        """Strade con sigla attorno alla rete da OSM (None se OSM non risponde)."""
        S, A, rfi, scr = _mod()
        from shapely.ops import unary_union
        x0, y0, x1, y1 = unary_union(tratte).bounds
        # ~2 km oltre la rete: l'asse delle strade deve arrivare ai cippi vicini
        # per tarare le progressive
        m = 0.02
        q = ('[out:json][timeout:120];way["highway"]["ref"](%f,%f,%f,%f);out body geom qt;'
             % (y0 - m, x0 - m, y1 + m, x1 + m))
        self._sti_fase(15, 70, "Strade con sigla intorno alla rete (OSM)")
        els, err = self._sti_sottofondo(lambda: self._acq_overpass_parallelo(q, gui=False))
        if not els:
            # zona larga troppo pesante per i server OSM: si riprova stretti
            # (meno cippi per le progressive, ma le strade ci sono)
            self._log_sti("OSM non ha risposto sulla zona larga (%s): riprovo attorno alla "
                          "rete." % err)
            m = 0.004
            q = ('[out:json][timeout:90];way["highway"]["ref"](%f,%f,%f,%f);out body geom qt;'
                 % (y0 - m, x0 - m, y1 + m, x1 + m))
            self._sti_fase(70, 82, "Nuovo tentativo OSM attorno alla rete")
            els, err = self._sti_sottofondo(lambda: self._acq_overpass_parallelo(q, gui=False))
        if not els:
            QMessageBox.warning(self, "OSM non risponde",
                                "Strade non scaricate: %s\n\nSe nel progetto c'è uno stradario "
                                "con la sigla delle strade (SP28, SS45…), sceglilo in «Altre "
                                "fonti» e riprova: non serve OSM." % err)
            return None
        return S.strade_da_osm(els, scr.normalizza_ref)

    def _sti_concludi_strade(self, strade, d, nome):
        """Metri vicino alla rete, enti, tabella e mappa. Le strade proposte
        (rete entro 50 m) NON si spuntano: si confermano una per una."""
        S, A, rfi, scr = _mod()
        tratte = self._sti_tratte_wgs()
        for s in strade:
            s.metri = S.metri_vicino(s, tratte, 50.0)
            s.includi = False
            s.confermata = False
        strade = [s for s in strade if s.metri > 0] + [s for s in strade if not s.metri][:10]
        # enti
        reg, prov, pop = d.get("regione") or "", d.get("provincia") or "", d.get("popolazione")
        ss = [s.ref for s in strade if s.classe == "SS" and s.metri > 0]
        anas = {}
        if ss and reg:
            self._sti_fase(85, 98, "Verifica sul sito ANAS")
            try:
                anas = self._sti_sottofondo(scr.anas_verifica_strade, reg, ss,
                                            d.get("nome") or nome)
            except Exception as e:  # noqa: BLE001
                self._log_sti("Sito ANAS non raggiungibile: %s" % e)
        for s in strade:
            self._sti_ente(s, reg, prov, pop, anas.get(s.ref))
        self._sti["strade"] = strade
        self._sti_riempi_strade()
        self._sti_salva()
        prop = [s for s in strade if s.metri > 0]
        self._log_sti("Strade proposte (rete entro 50 m): %d — %s. Confermale o scartale una "
                      "per una." % (len(prop), ", ".join(s.nome_documenti() for s in prop)
                                    or "nessuna"))
        # le proposte subito in mappa (non durante il ripristino né nei test
        # senza mappa)
        if prop and getattr(self, "iface", None) is not None:
            try:
                self._sti_mostra_strade(solo_proposte=True)
            except Exception as e:  # noqa: BLE001
                self._log_sti("Strade proposte non mostrate in mappa: %s" % e)

    def _sti_da_screening(self, rep):
        """Punto 2 dalle strade dello screening (o dallo stradario del
        progetto): proposte evidenziate, da confermare una per una."""
        S, A, rfi, scr = _mod()
        d = rep.get("comune") or {}
        if not d.get("nome"):
            return ""
        if not self.txt_sti_comune.text().strip():
            self.txt_sti_comune.setText(d["nome"])
        if d.get("provincia") and not self.txt_sti_prov.text().strip():
            self.txt_sti_prov.setText(rfi.sigla_provincia(d["provincia"]) or "")
        if d.get("cap") and not self.txt_sti_cap.text().strip():
            self.txt_sti_cap.setText(str(d["cap"]).split(";")[0].strip())
        self._sti["comune"] = d
        tratte = self._sti_tratte_wgs()
        if not tratte:
            return "manca la rete nuova in 03 INFRASTRUTTURE"
        strade, fonte = None, ""
        lyr, c_sig, c_nom = self._sti_stradario_progetto(tratte)
        if lyr is not None:
            strade, fonte = self._sti_strade_da_layer(lyr, c_sig, c_nom, tratte), lyr.name()
        if not strade and rep.get("_elementi_strade"):
            strade, fonte = S.strade_da_osm(rep["_elementi_strade"], scr.normalizza_ref), "OSM"
        if not strade:
            return "nessuna strada con sigla"
        self._sti_concludi_strade(strade, d, d["nome"])
        n = sum(1 for s in self._sti.get("strade") or [] if getattr(s, "metri", 0) > 0)
        return "%d strade proposte da confermare (fonte: %s)" % (n, fonte)

    # ------------------------------------- stradario del progetto, validazione
    def _sti_stradario_progetto(self, tratte):
        """(layer, campo sigla, campo nome) dello stradario da usare: quello di
        «Altre fonti» se scelto, altrimenti un layer di linee del progetto con
        un campo sigla (SP28, SS45…) attorno alla rete. (None, None, None) se
        non c'è."""
        S, A, rfi, scr = _mod()
        if self.cb_sti_alt.currentLayer() is not None and self.cb_sti_alt_sigla.currentField():
            return (self.cb_sti_alt.currentLayer(), self.cb_sti_alt_sigla.currentField(),
                    self.cb_sti_alt_nome.currentField() or None)
        from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                               QgsFeatureRequest, QgsRectangle, QgsVectorLayer, QgsWkbTypes)
        from shapely.ops import unary_union
        x0, y0, x1, y1 = unary_union(tratte).bounds
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        candidati = []
        for l in self.project.mapLayers().values():
            if not isinstance(l, QgsVectorLayer) or not l.isValid() or \
                    l.geometryType() != QgsWkbTypes.LineGeometry:
                continue
            n = l.name().lower()
            if "trovat" in n or "interferenz" in n or "infrastrutt" in n:
                continue
            nomi = {f.name().lower(): f.name() for f in l.fields()}
            c_sig = next((nomi[c] for c in CAMPI_SIGLA if c in nomi), None)
            if not c_sig:
                continue
            c_nom = next((nomi[c] for c in ("name", "nome", "denominaz", "denominazione",
                                            "nome_str") if c in nomi and nomi[c] != c_sig), None)
            try:
                rett = QgsCoordinateTransform(wgs, l.crs(), self.project).transformBoundingBox(
                    QgsRectangle(x0 - 0.005, y0 - 0.005, x1 + 0.005, y1 + 0.005))
                req = QgsFeatureRequest().setFilterRect(rett).setLimit(300)
                buone = sum(1 for f in l.getFeatures(req)
                            if scr.normalizza_ref(str(f[c_sig] or "")))
            except Exception:  # noqa: BLE001
                continue
            if buone:
                candidati.append((("strad" in n, buone), l, c_sig, c_nom))
        if not candidati:
            return None, None, None
        candidati.sort(key=lambda x: x[0], reverse=True)
        return candidati[0][1], candidati[0][2], candidati[0][3]

    def _sti_strade_da_layer(self, lyr, c_sig, c_nom, tratte):
        """Strade (S.Strada, senza ente) da un layer di linee, solo i tratti
        attorno alla rete (~2 km)."""
        S, A, rfi, scr = _mod()
        from shapely.ops import unary_union, linemerge
        from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                               QgsFeatureRequest, QgsRectangle)
        x0, y0, x1, y1 = unary_union(tratte).bounds
        tr = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"), lyr.crs(),
                                    self.project)
        rett = tr.transformBoundingBox(QgsRectangle(x0 - 0.02, y0 - 0.02, x1 + 0.02, y1 + 0.02))
        per_ref = {}
        for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(rett)):
            if not f.hasGeometry():
                continue
            parsed = scr.normalizza_ref(str(f[c_sig] or ""))
            if not parsed:
                continue
            classe, ref = parsed
            d = per_ref.setdefault(ref, {"classe": classe, "geom": [], "nome": ""})
            d["geom"].append(self._rfi_wkt(f.geometry(), lyr))
            if c_nom and not d["nome"] and f[c_nom] not in (None, "") \
                    and str(f[c_nom]) != "NULL":
                d["nome"] = str(f[c_nom])
        out = []
        for ref, d in per_ref.items():
            g = unary_union(d["geom"])
            try:
                g = linemerge(g)
            except Exception:  # noqa: BLE001
                pass
            s = S.Strada(ref=ref, classe=d["classe"], nome=d["nome"], geom=g)
            s.nota = "Da «%s». " % lyr.name()
            out.append(s)
        return out

    def _sti_aggiorna_titoli(self):
        """Stato di ogni passo nel suo titolo, così si vede a colpo d'occhio
        cosa manca (es. «2) … — 3 da confermare, 1 confermata»)."""
        gb = getattr(self, "_sti_gb", None)
        if not gb:
            return

        def titolo(n, stato):
            box, base = gb[n]
            box.setTitle(base + ("  —  " + stato if stato else ""))
        strade = self._sti.get("strade") or []
        conf = sum(1 for s in strade if getattr(s, "confermata", s.includi))
        da_conf = sum(1 for s in strade if getattr(s, "metri", 0) > 0
                      and not getattr(s, "confermata", s.includi))
        if not strade:
            titolo(2, "")
        elif da_conf:
            titolo(2, "%d da confermare, %d confermate" % (da_conf, conf))
        else:
            titolo(2, "✔ %d confermate" % conf if conf else "nessuna strada confermata")
        interf = self._sti.get("interferenze") or []
        if interf:
            t = getattr(self, "tab_sti", None)
            n_sp = sum(1 for r in range(t.rowCount()) if t.item(r, CI_INCL) is not None and
                       t.item(r, CI_INCL).checkState() == Qt.Checked) if t is not None else 0
            titolo(3, "%d interferenze, %d spuntate" % (len(interf), n_sp))
        else:
            titolo(3, "")
        tk = getattr(self, "tab_sti_km", None)
        if tk is not None and tk.rowCount():
            ok = sum(1 for r in range(tk.rowCount()) if tk.item(r, 6) is not None and
                     "— ok" in tk.item(r, 6).text().lower())
            titolo(4, ("✔ " if ok == tk.rowCount() else "") +
                   "km ok su %d di %d strade" % (ok, tk.rowCount()))
        else:
            titolo(4, "")

    def _sti_widget_valida(self, r, s):
        """Pulsanti Conferma / Escludi della riga."""
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(2, 0, 2, 0)
        h.setSpacing(4)
        # strade di un lavoro salvato prima di questa versione: spuntata = confermata
        if getattr(s, "confermata", s.includi):
            lab = QLabel("✔ confermata")
            lab.setStyleSheet("color:#1b7a2f; font-weight:bold")
            h.addWidget(lab)
            b_no = QPushButton("Annulla")
            b_no.setToolTip("Toglie la conferma (la riga resta, senza spunta).")
            b_no.clicked.connect(lambda _=False, x=s: self._sti_annulla_conferma(x))
            h.addWidget(b_no)
        else:
            b_ok = QPushButton("Conferma")
            b_ok.setToolTip("La strada entra nelle istanze: ti chiede l'ente destinatario.")
            b_ok.clicked.connect(lambda _=False, x=s: self._sti_conferma(x))
            b_ko = QPushButton("Escludi")
            b_ko.setToolTip("La strada esce dall'elenco.")
            b_ko.clicked.connect(lambda _=False, x=s: self._sti_scarta(x))
            h.addWidget(b_ok)
            h.addWidget(b_ko)
        return w

    def _sti_riga_di(self, s):
        try:
            return self._sti["strade"].index(s)
        except ValueError:
            return -1

    def _sti_conferma(self, s):
        from qgis.PyQt.QtWidgets import QInputDialog
        self._sti_leggi_strade()          # tiene le correzioni fatte in tabella
        r = self._sti_riga_di(s)
        if r < 0:
            return
        ente, ok = QInputDialog.getText(
            self, "Conferma %s" % s.nome_documenti(),
            "Ente destinatario dell'istanza per %s%s:\n(proposta: %s — controlla la colonna "
            "Competenza)" % (s.nome_documenti(), (" — " + s.nome) if s.nome else "",
                             s.ente_nome or "nessuna"),
            text=s.ente_nome or "")
        if not ok:
            return
        if not ente.strip():
            QMessageBox.warning(self, "Ente mancante", "Scrivi l'ente destinatario.")
            return
        s.ente_nome = ente.strip()
        s.includi = True
        s.confermata = True
        self._sti_riempi_strade()
        self._sti_salva()
        self._log_sti("Confermata %s — ente: %s." % (s.nome_documenti(), s.ente_nome))

    def _sti_annulla_conferma(self, s):
        self._sti_leggi_strade()
        s.includi = False
        s.confermata = False
        self._sti_riempi_strade()
        self._sti_salva()

    def _sti_scarta(self, s):
        self._sti_leggi_strade()
        r = self._sti_riga_di(s)
        if r < 0:
            return
        self._sti["strade"].pop(r)
        self._sti_riempi_strade()
        self._sti_salva()
        self._log_sti("Scartata %s." % s.nome_documenti())

    def _sti_ente(self, s, reg, prov, pop, info_anas):
        """Ente proposto e nota di competenza per una strada."""
        S, A, rfi, scr = _mod()
        sc = {"A": "Concessionario autostradale", "SS": "ANAS S.p.A.", "SR": "Regione",
              "SP": "Provincia"}.get(s.classe, "Ente proprietario")
        ente, nota_g = None, None
        if s.classe == "A":
            ente = getattr(s, "operator", "") or scr.concessionario_autostrada(s.ref)
        elif s.classe == "SS" and info_anas and not info_anas.get("non_anas"):
            st = info_anas.get("struttura") or {}
            ente = "ANAS S.p.A."
            s.ente_ufficio = (st.get("nome") or "").replace("ANAS S.p.A. - ", "")
            s.ente_indirizzo = st.get("indirizzo") or ""
            s.ente_pec = st.get("pec") or ""
        else:
            ente = getattr(s, "operator", "")
            if not ente:
                ente, nota_g = scr.gestore_regionale(s.classe, reg, prov)
        s.ente_nome = ente or sc
        s.anas = info_anas or {}
        note = [scr.nota_competenza_strada(s.classe, pop, s.ente_nome) or ""]
        if info_anas:
            note.insert(0, scr.nota_anas(info_anas))
        if nota_g:
            note.append(nota_g)
        s.nota = " ".join(n for n in note if n)

    def _sti_riempi_strade(self):
        t = self.tab_sti_strade
        t.setRowCount(0)
        for s in self._sti["strade"]:
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem("")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if s.includi else Qt.Unchecked)
            t.setItem(r, CS_INCL, it)
            epc = QTableWidgetItem("")
            epc.setFlags(epc.flags() | Qt.ItemIsUserCheckable)
            epc.setCheckState(Qt.Checked if s.epc_comune else Qt.Unchecked)
            t.setItem(r, CS_EPC, epc)
            vals = {CS_REF: s.nome_documenti(), CS_NOME: s.nome,
                    CS_METRI: "%d" % getattr(s, "metri", 0), CS_ENTE: s.ente_nome,
                    CS_UFF: s.ente_ufficio, CS_IND: s.ente_indirizzo, CS_PEC: s.ente_pec,
                    CS_FASCIA: "%g" % s.fascia_m, CS_NOTA: s.nota}
            # proposta = gialla, confermata = verde
            if getattr(s, "confermata", s.includi):
                fondo = QColor(214, 240, 214)
            elif getattr(s, "metri", 0) > 0:
                fondo = QColor(255, 243, 190)
            else:
                fondo = None
            for c, val in vals.items():
                x = QTableWidgetItem(val or "")
                if c in (CS_REF, CS_NOME, CS_METRI, CS_NOTA):
                    x.setFlags(x.flags() & ~Qt.ItemIsEditable)
                if c == CS_NOTA:
                    x.setToolTip(val or "")
                if fondo is not None and c in (CS_REF, CS_NOME, CS_METRI):
                    x.setBackground(fondo)
                t.setItem(r, c, x)
            t.setCellWidget(r, CS_VALIDA, self._sti_widget_valida(r, s))
        t.resizeColumnsToContents()
        t.setColumnWidth(CS_NOTA, 420)
        self._sti_aggiorna_titoli()
        # tendina «strada» del layer cippi sempre allineata alle strade confermate
        try:
            from . import ftth_trovati as _TR
            for l in self.project.mapLayersByName("Cippi_Chilometrici"):
                _TR.tendina_campo(l, "strada", self._sti_strade_per_cippi())
        except Exception:  # noqa: BLE001
            pass

    def _sti_leggi_strade(self):
        t = self.tab_sti_strade
        for r, s in enumerate(self._sti["strade"]):
            def _c(c):
                it = t.item(r, c)
                return it.text().strip() if it is not None else ""
            s.includi = t.item(r, CS_INCL).checkState() == Qt.Checked
            s.epc_comune = t.item(r, CS_EPC).checkState() == Qt.Checked
            s.ente_nome, s.ente_ufficio = _c(CS_ENTE), _c(CS_UFF)
            s.ente_indirizzo, s.ente_pec = _c(CS_IND), _c(CS_PEC)
            try:
                s.fascia_m = float(_c(CS_FASCIA).replace(",", "."))
            except ValueError:
                pass
        return [s for s in self._sti["strade"] if s.includi]

    # ------------------------------------------- strade: mappa, zoom, layer
    def _sti_zoom_strada(self, r, _c=None):
        from . import ftth_trovati as _TR
        strade = self._sti.get("strade") or []
        if 0 <= r < len(strade):
            _TR.zoom(getattr(self, "iface", None), self.project, strade[r].geom)

    def _sti_mostra_strade(self, solo_proposte=False):
        """In mappa le strade spuntate o, subito dopo la ricerca, le proposte
        (rete entro 50 m) e quelle confermate, con lo stato nell'etichetta."""
        from . import ftth_trovati as _TR
        if not self._sti.get("strade"):
            QMessageBox.information(self, "Nessuna strada", "Prima premi «Trova le strade e "
                                                            "gli enti».")
            return
        spuntate = self._sti_leggi_strade()
        scelte = [s for s in self._sti["strade"] if s in spuntate or
                  (solo_proposte and getattr(s, "metri", 0) > 0)]
        voci = []
        for s in scelte:
            sig = s.nome_documenti()
            stato = "confermata" if s.includi else "proposta"
            voci.append((s.geom, {"sigla": sig, "nome": s.nome or "", "ente": s.ente_nome or "",
                                  "stato": stato,
                                  "etichetta": "%s — %s (%s)" % (sig, s.ente_nome, stato)
                                  if s.ente_nome else "%s (%s)" % (sig, stato)}))
        if not voci:
            if not solo_proposte:
                QMessageBox.information(self, "Nessuna strada", "Nessuna strada spuntata.")
            return
        try:
            _TR.mostra_in_mappa(self.project, "strade", "Strade trovate", voci, "etichetta",
                                "strade")
            self._log_sti("In mappa: %d strade nel gruppo «Istanze > Strade > Trovati»."
                          % len(voci))
            self.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Mostra in mappa", "Non riuscito: %s" % e)

    def _sti_da_layer(self):
        """Strade da un layer di linee del progetto (altre fonti)."""
        S, A, rfi, scr = _mod()
        from shapely.ops import unary_union, linemerge
        lyr = self.cb_sti_alt.currentLayer()
        c_sig = self.cb_sti_alt_sigla.currentField()
        c_nom = self.cb_sti_alt_nome.currentField()
        if lyr is None or not c_sig:
            QMessageBox.warning(self, "Altre fonti", "Scegli il layer e il campo con la sigla.")
            return
        tratte = self._sti_tratte_wgs()
        if not tratte:
            QMessageBox.warning(self, "Rete mancante", "Manca la rete nuova in '03 "
                                                       "INFRASTRUTTURE'.")
            return
        # solo i tratti attorno alla rete (~2 km): gli stradari nazionali hanno
        # centinaia di migliaia di elementi
        lista = self._sti_strade_da_layer(lyr, c_sig, c_nom or None, tratte)
        if not lista:
            QMessageBox.information(self, "Altre fonti", "Nessuna sigla stradale riconosciuta "
                                                         "nel campo scelto.")
            return
        d_c = self._sti.get("comune") or {}
        reg, prov, pop = d_c.get("regione") or "", d_c.get("provincia") or "", \
            d_c.get("popolazione")
        esistenti = {s.ref: s for s in self._sti.get("strade") or []}
        nuove = 0
        for s in lista:
            s.metri = S.metri_vicino(s, tratte, 50.0) if tratte else 0
            s.includi = False          # si conferma una per una
            s.confermata = False
            nota0 = s.nota
            self._sti_ente(s, reg, prov, pop, None)
            s.nota = nota0 + (s.nota or "")
            if s.ref in esistenti:
                self._sti["strade"][self._sti["strade"].index(esistenti[s.ref])] = s
            else:
                self._sti.setdefault("strade", []).append(s)
                nuove += 1
        self._sti_riempi_strade()
        self._log_sti("Da «%s»: %d strade (%d nuove, le altre sostituiscono quelle con "
                      "la stessa sigla). Confermale o scartale una per una."
                      % (lyr.name(), len(lista), nuove))

    # ------------------------------------- progressive per strada (punto 4)
    def _sti_chiave(self, i):
        return (i.corso, i.categoria, tuple(sorted(str(f) for f in i.tratte_fid)),
                tuple(sorted(str(e.get("chiave_el") or "") for e in i.elementi)))

    def _sti_km_cfg(self, ref):
        """(modo, layer cippi o None, campo) scelti per la strada nel punto 4;
        senza scelta propria valgono le impostazioni per tutte le strade."""
        w = (getattr(self, "_sti_km_w", None) or {}).get(ref)
        base = self.cb_sti_modo_km.currentData() or "auto"
        if not w:
            return base, None, None
        cb_f, cb_l, cb_c = w
        modo = cb_f.currentData() or ""
        if not modo:
            return base, None, None
        if modo == "auto":
            return "auto", cb_l.currentLayer(), cb_c.currentField() or None
        return modo, None, None

    def _sti_riempi_km(self, strade):
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
        t = self.tab_sti_km
        vecchie = {}
        for ref, (cb_f, cb_l, cb_c) in (getattr(self, "_sti_km_w", None) or {}).items():
            try:
                vecchie[ref] = (cb_f.currentData(), cb_l.currentLayer(), cb_c.currentField())
            except RuntimeError:
                pass
        self._sti_km_w = {}
        info = self._sti.get("info_km") or {}
        t.setRowCount(0)
        for s in strade:
            k = info.get(s.ref)
            if k is None:
                continue
            r = t.rowCount()
            t.insertRow(r)
            x = QTableWidgetItem(s.nome_documenti())
            x.setFlags(x.flags() & ~Qt.ItemIsEditable)
            t.setItem(r, 0, x)
            x = QTableWidgetItem(str(k["n"]))
            x.setFlags(x.flags() & ~Qt.ItemIsEditable)
            t.setItem(r, 1, x)
            cb_f = QComboBox()
            for testo, dato in (("come scelto sopra (consigliato)", ""),
                                ("cippi di questa riga", "auto"),
                                ("campo Chilometrica dei layer", "campo"),
                                ("nessun cippo: solo coordinate", "coordinate")):
                cb_f.addItem(testo, dato)
            cb_l = QgsMapLayerComboBox()
            cb_l.setFilters(QgsMapLayerProxyModel.PointLayer)
            cb_l.setAllowEmptyLayer(True)
            cb_l.setLayer(None)
            cb_c = QgsFieldComboBox()
            cb_l.layerChanged.connect(cb_c.setLayer)
            for w_ in (cb_f, cb_l, cb_c):
                w_.setProperty("non_memorizzare", True)
            v = vecchie.get(s.ref)
            if v:
                cb_f.setCurrentIndex(max(0, cb_f.findData(v[0] or "")))
                if v[1] is not None:
                    cb_l.setLayer(v[1])
                    cb_c.setField(v[2] or "")
            t.setCellWidget(r, 2, cb_f)
            t.setCellWidget(r, 3, cb_l)
            t.setCellWidget(r, 4, cb_c)

            def _abilita(*_a, f=cb_f, l_=cb_l, c_=cb_c):
                si = f.currentData() == "auto"     # layer e campo solo per «cippi di questa riga»
                l_.setEnabled(si)
                c_.setEnabled(si)
            cb_f.currentIndexChanged.connect(_abilita)
            _abilita()
            for c, val in ((5, str(k["rif"])), (6, "%s — %s" % (k["fonte"], k["stato"]))):
                x = QTableWidgetItem(val)
                x.setFlags(x.flags() & ~Qt.ItemIsEditable)
                x.setToolTip(val)
                t.setItem(r, c, x)
            self._sti_km_w[s.ref] = (cb_f, cb_l, cb_c)
        t.resizeColumnsToContents()
        self._sti_aggiorna_titoli()

    # ------------------------------------------- interferenze: mappa, zoom
    def _sti_geom_interferenza(self, i):
        from shapely import wkt as _wkt
        from shapely.geometry import Point
        from shapely.ops import unary_union
        parti = []
        for e in i.elementi:
            if e.get("_wkt"):
                try:
                    parti.append(_wkt.loads(e["_wkt"]))
                    continue
                except Exception:  # noqa: BLE001
                    pass
            if "lon" in e and "lat" in e:
                parti.append(Point(e["lon"], e["lat"]))
        return unary_union(parti) if parti else Point(i.lon, i.lat)

    def _sti_zoom_interferenza(self, r, _c=None):
        from . import ftth_trovati as _TR
        lst = self._sti.get("interferenze") or []
        if 0 <= r < len(lst):
            _TR.zoom(getattr(self, "iface", None), self.project,
                     self._sti_geom_interferenza(lst[r]))

    def _sti_mostra_interferenze(self, silenzioso=False):
        S, A, rfi, scr = _mod()
        from . import ftth_trovati as _TR
        from shapely import wkt as _wkt
        from shapely.geometry import Point
        lst = self._sti.get("interferenze") or []
        if not lst:
            if not silenzioso:
                QMessageBox.information(self, "Nessuna interferenza",
                                        "Prima premi «Trova le interferenze».")
            return
        t = self.tab_sti
        linee, punti = [], []
        for r, i in enumerate(lst):
            it = t.item(r, CI_INCL)
            if it is not None and it.checkState() != Qt.Checked:
                continue
            dove = "in sede" if i.categoria == S.ZONA_SEDE else "in fascia"
            for e in i.elementi:
                att = {"n": str(i.id), "strada": i.corso, "dove": dove,
                       "progressiva": S.testo_km(e.get("km_da"), e.get("km_a")) or "",
                       "lavori": (e.get("testo") or "").replace("\n", " "),
                       "etichetta": "n. %s" % i.id}
                if e.get("tipo") == "scavo" and e.get("_wkt"):
                    try:
                        linee.append((_wkt.loads(e["_wkt"]), att))
                    except Exception:  # noqa: BLE001
                        pass
                elif e.get("tipo") in ("pozzetto", "armadio") and "lon" in e:
                    punti.append((Point(e["lon"], e["lat"]), dict(att, tipo=e.get("tipo"))))
        try:
            if linee:
                _TR.mostra_in_mappa(self.project, "strade", "Interferenze strade - scavi",
                                    linee, "etichetta", "interferenze")
            if punti:
                _TR.mostra_in_mappa(self.project, "strade", "Interferenze strade - pozzetti e "
                                    "armadi", punti, "etichetta", "interferenze")
            self._log_sti("In mappa: %d scavi e %d pozzetti/armadi delle interferenze spuntate."
                          % (len(linee), len(punti)))
            self.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Mostra in mappa", "Non riuscito: %s" % e)

    # ------------------------------------------------------- interferenze
    def _sti_trova(self, *_a, bar=None):
        self._sti["stop"] = False
        self._sti_bar_corrente = bar or getattr(self, "bar_sti_i", None)
        bar = self._sti_bar_corrente
        try:
            if bar is not None:
                bar.azzera()
            self._sti_trova_impl()
            if bar is not None:
                bar.fine("Interferenze trovate: %d" % len(self._sti.get("interferenze") or []))
        except _InterrottoSti:
            self._log_sti("Interrotto.")
            if bar is not None:
                bar.interrotta("Interrotto")
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_sti("ERRORE:\n" + traceback.format_exc())
            if bar is not None:
                bar.interrotta("Errore: vedi il registro in fondo")
            QMessageBox.critical(self, "Errore", str(e))
        finally:
            self._sti_bar_corrente = None

    def _sti_km_layer(self, nome_layer, tipo=None):
        """{fid: testo} (tratte) o {(tipo, fid): testo} dal campo progressiva."""
        lyr = self._find_layer(nome_layer)
        out = {}
        if lyr is None or not lyr.isValid():
            return out
        voluto = self.cb_sti_campo_km.currentText().strip()
        nomi = [f.name() for f in lyr.fields()]
        campo = next((n for n in [voluto] + list(NOMI_CAMPO_KM) if n in nomi), None)
        if not campo:
            campo = next((n for n in nomi if n.lower().startswith("chilom")), None)
        if not campo:
            return out
        for f in lyr.getFeatures():
            v = f[campo]
            if v is None or str(v) in ("", "NULL"):
                continue
            out[(tipo, f.id()) if tipo else f.id()] = str(v)
        return out

    def _sti_trova_impl(self):
        S, A, rfi, scr = _mod()
        strade = self._sti_leggi_strade()
        if not strade:
            QMessageBox.warning(self, "Nessuna strada", "Premi «Trova le strade e gli enti» e "
                                                        "spunta le strade.")
            return
        self._sti_fase(0, 10, "Lettura della rete")
        rete = self._acq_rete()
        if rete is None:
            QMessageBox.warning(self, "Layer mancante", "Manca '03 INFRASTRUTTURE'.")
            return
        tratte, pozzetti, armadi = rete
        tratte_geom = [t["geom"] for t in tratte]
        km_tratte = self._sti_km_layer("03 INFRASTRUTTURE")
        km_punti = dict(self._sti_km_layer("02_POZZETTO", "pozzetto"))
        km_punti.update(self._sti_km_layer("01_ARMADIO OTTICO", "armadio"))
        if not km_tratte and not km_punti:
            self._log_sti("Nessuna progressiva nei layer: calcolale nella sottoscheda "
                          "Chilometriche (in relazione ci saranno le coordinate).")
        strade_osm = []
        if hasattr(self, "_acq_overpass_parallelo"):
            strade_osm = [(s.geom, s.nome_documenti()) for s in strade]
        # scelte del punto 4 per ogni strada (fonte, layer cippi, campo km)
        cfg = {s.ref: self._sti_km_cfg(s.ref) for s in strade}
        auto_tutte = any(c[0] == "auto" for c in cfg.values())
        if auto_tutte:
            self._sti_fase(10, 30, "Cippi chilometrici")
        cippi = self._sti_cippi(strade) if auto_tutte else []
        perimetri = self._sti_perimetri()
        pop_comune = (self._sti.get("comune") or {}).get("popolazione")
        # spunte di una ricerca precedente: restano sulle stesse interferenze
        vecchie = {}
        if self._sti.get("interferenze") and self.tab_sti.rowCount():
            for r, i in enumerate(self._sti["interferenze"]):
                it = self.tab_sti.item(r, CI_INCL)
                if it is not None:
                    vecchie[self._sti_chiave(i)] = it.checkState() == Qt.Checked
        info_km = {}
        tutte = []
        for k_s, s in enumerate(strade):
            if self._sti.get("stop"):
                raise _InterrottoSti()
            self._sti_fase(30 + 68 * k_s // max(1, len(strade)),
                           30 + 68 * (k_s + 1) // max(1, len(strade)),
                           "Interferenze su %s (%d di %d)" % (s.nome_documenti(), k_s + 1,
                                                              len(strade)))
            zone_s = S.zone_strada(s)
            interf = self._sti_sottofondo(
                lambda z=zone_s: A.trova_interferenze_acque([], tratte, pozzetti, armadi,
                                                            strade=strade_osm, zone=z))
            # una riga per tratta, come nelle relazioni strade consegnate
            S.dividi_scavi_per_tratta(interf, tratte, zone_s)
            fonte = "coordinate"
            modo, lyr_c, campo_c = cfg[s.ref]
            n_rif = 0
            if modo == "coordinate":
                S.assegna_km(interf, {}, {}, s)
                fonte = "solo coordinate"
            elif modo == "auto":
                if lyr_c is not None:
                    # cippi scelti per questa strada (+ quelli OSM della strada)
                    cippi_s = self._sti_cippi_layer(lyr_c, campo_c) + [
                        c for c in cippi if c[2] and c[2].replace(" ", "").upper() ==
                        s.ref.upper()]
                else:
                    cippi_s = cippi
                rif = [(p, km) for p, km, ref in cippi_s
                       if not ref or ref.replace(" ", "").upper() == s.ref.upper()]
                prog = S.Progressive(s.geom, rif)
                origine = "cippi" + (" di «%s»" % lyr_c.name() if lyr_c is not None else "")
                if not prog.ok() and getattr(s, "anas", None):
                    # niente cippi: righello sulla geometria ANAS della statale
                    from shapely.ops import unary_union
                    vic = [g for g in tratte_geom if g is not None]
                    rif_a = S.riferimenti_anas(s.anas, unary_union(vic) if vic else None)
                    if rif_a:
                        prog = S.Progressive(s.geom, rif + rif_a, tolleranza_m=80.0)
                        origine = "geometria ANAS"
                n_rif = len(prog.rif)
                if prog.ok():
                    n = S.assegna_km_auto(interf, prog)
                    fonte = "automatiche (%s, %d riferimenti sull'asse)" % (origine,
                                                                           len(prog.rif))
                    S.assegna_km(interf, km_tratte, km_punti, s, solo_testi=True)
                    self._log_sti("%s: progressive automatiche su %d elementi (%s, %d "
                                  "riferimenti)" % (s.nome_documenti(), n, origine,
                                                    len(prog.rif)))
                else:
                    self._log_sti("%s: cippi insufficienti per le progressive automatiche "
                                  "(%d utili, ne servono 2): uso il campo dei layer."
                                  % (s.nome_documenti(), len(prog.rif)))
                    S.assegna_km(interf, km_tratte, km_punti, s)
                    fonte = "campo dei layer (cippi insufficienti: %d utili)" % len(prog.rif)
            else:
                S.assegna_km(interf, km_tratte, km_punti, s)
                fonte = "campo dei layer"
            con_km = sum(1 for i in interf for e in i.elementi if e.get("km_da"))
            n_el = sum(1 for i in interf for e in i.elementi
                       if e.get("tipo") in ("scavo", "pozzetto", "armadio"))
            info_km[s.ref] = {"n": len(interf), "fonte": fonte, "rif": n_rif,
                              "stato": ("ok: progressive su %d di %d elementi" % (con_km, n_el))
                              if con_km else ("senza progressive: in relazione le coordinate"
                                              if n_el else "nessuna interferenza")}
            info_anas = getattr(s, "anas", None) or {}
            conti = S.applica_centri_abitati(
                interf, s, centri_anas=info_anas.get("centri_abitati"),
                perimetri=perimetri, pop_comune=pop_comune)
            if conti["in_centro"]:
                self._log_sti("%s: %d interferenze dentro centri abitati (%d in fascia tolte, %d "
                              "al Comune)" % (s.nome_documenti(), conti["in_centro"],
                                              conti["fascia_tolte"], conti["al_comune"]))
            info_km[s.ref]["n"] = len(interf)
            s.fonte_km = fonte
            for i in interf:
                i.via = i.via or s.nome
            tutte += interf
        for n, i in enumerate(tutte, 1):
            i.id = n
            k = self._sti_chiave(i)
            if k in vecchie:
                i.includi = vecchie[k]
        self._sti["interferenze"] = tutte
        self._sti["info_km"] = info_km
        self._sti_riempi(tutte)
        self._sti_riempi_km(strade)
        self._log_sti("Interferenze trovate: %d (in sede %d, in fascia %d)." % (
            len(tutte), sum(1 for i in tutte if i.categoria == S.ZONA_SEDE),
            sum(1 for i in tutte if i.categoria == S.ZONA_FASCIA)))
        self._sti_dopo_trova(strade)

    # ------------------------------------ dopo la ricerca: mappa, vista, km
    def _sti_dopo_trova(self, strade):
        """Interferenze e fasce di rispetto subito in mappa, pannello «Vista
        per strada» pronto e, se scelto, Chilometrica scritta nei layer."""
        if getattr(self, "iface", None) is not None:
            for fn in (lambda: self._sti_mostra_interferenze(silenzioso=True),
                       lambda: self._sti_mostra_fasce(strade)):
                try:
                    fn()
                except Exception as e:  # noqa: BLE001
                    self._log_sti("Mappa non aggiornata: %s" % e)
        chk = getattr(self, "chk_sti_scrivi_km", None)
        if chk is not None and chk.isChecked():
            try:
                n = self._sti_scrivi_chilometriche()
                if n:
                    self._log_sti("Campo «%s» scritto nei layer: %d elementi."
                                  % (self._sti_nome_campo_km(), n))
            except Exception as e:  # noqa: BLE001
                self._log_sti("Chilometrica non scritta nei layer: %s" % e)

    def _sti_mostra_fasce(self, strade):
        """Sede e fascia di rispetto di ogni strada in mappa («Fasce di
        rispetto strade», gruppo Istanze > Strade > Trovati)."""
        S, A, rfi, scr = _mod()
        from . import ftth_trovati as _TR
        voci = []
        for s in strade:
            if s.geom is None or s.geom.is_empty:
                continue
            c = s.geom.centroid
            pr = rfi._Proiezione(c.x, c.y)
            asse = pr.avanti(s.geom)
            sede = asse.buffer(s.semi_sede_m, cap_style=2)
            fascia = asse.buffer(s.semi_sede_m + s.fascia_m, cap_style=2).difference(sede)
            sig = s.nome_documenti()
            voci.append((pr.indietro(fascia), {"strada": sig, "zona": "fascia di rispetto",
                                               "etichetta": "%s fascia %g m" % (sig, s.fascia_m)}))
            voci.append((pr.indietro(sede), {"strada": sig, "zona": "sede stradale",
                                             "etichetta": ""}))
        if voci:
            _TR.mostra_in_mappa(self.project, "strade", "Fasce di rispetto strade", voci,
                                "etichetta", "aree")

    # ------------------------------------------- chilometrica nei layer
    def _sti_nome_campo_km(self):
        return self.cb_sti_campo_km.currentText().strip() or "Chilometrica"

    def _sti_campo_layer(self, l, nome, crea=False, lung=60):
        """Indice del campo `nome` nel layer: quello che c'è già (anche
        accorciato a 10 caratteri dagli shapefile), altrimenti -1 o, con
        `crea`, lo crea (nome accorciato solo per gli shapefile)."""
        from qgis.core import QgsField
        from qgis.PyQt.QtCore import QVariant
        nomi = {f.name().lower(): f.name() for f in l.fields()}
        for cand in (nome, nome[:10]):
            if cand.lower() in nomi:
                return l.fields().indexOf(nomi[cand.lower()])
        if not crea:
            return -1
        shp = "shapefile" in (l.storageType() or "").lower() or \
            (l.source() or "").lower().split("|")[0].endswith(".shp")
        fld = QgsField(nome[:10] if shp else nome, QVariant.String, len=lung)
        if l.isEditable():
            l.addAttribute(fld)
        else:
            l.dataProvider().addAttributes([fld])
        l.updateFields()
        return l.fields().indexOf(fld.name())

    def _sti_scrivi_chilometriche(self):
        """Scrive nei layer principali (03 INFRASTRUTTURE, 02_POZZETTO,
        01_ARMADIO OTTICO) il campo Chilometrica degli elementi delle
        interferenze con la progressiva calcolata: «dal km 11+571 al km
        11+583» sulle tratte, «11+756» su pozzetti e armadi. Ritorna quanti."""
        S, A, rfi, scr = _mod()
        from . import ftth_gruppi_istanze as GR
        from qgis.core import QgsField
        from qgis.PyQt.QtCore import QVariant
        campo = self._sti_nome_campo_km()
        valori = {"tratte": {}, "pozzetti": {}, "armadi": {}}
        testi = {"tratte": {}, "pozzetti": {}, "armadi": {}}
        for i in self._sti.get("interferenze") or []:
            for e in i.elementi:
                da, a = e.get("km_da"), e.get("km_a")
                t = e.get("tipo")
                if t == "scavo":
                    for f in (e.get("chiave_el") or "").split("|")[-1].split(","):
                        try:
                            fid = int(f)
                        except ValueError:
                            continue
                        if e.get("testo"):
                            vecchio_t = testi["tratte"].get(fid)
                            testi["tratte"][fid] = (vecchio_t + "\n" + e["testo"]) \
                                if vecchio_t and e["testo"] not in vecchio_t else e["testo"]
                        if not da:
                            continue
                        vecchio = valori["tratte"].get(fid)
                        kms = S.km_da_testo(vecchio) + [da, a] if vecchio else [da, a]
                        d2, a2 = S.km_intervallo(kms)
                        valori["tratte"][fid] = S.testo_km(d2, a2)
                elif t in ("pozzetto", "armadio") and e.get("fid") is not None:
                    ch = "pozzetti" if t == "pozzetto" else "armadi"
                    if da:
                        valori[ch][int(e["fid"])] = da
                    if e.get("testo"):
                        testi[ch][int(e["fid"])] = e["testo"]
        n = 0
        for chiave, nome, _t in GR.LAYER:
            l = GR.layer_principale(self.project, nome)
            if l is None:
                continue
            for nome_c, vals, lung in ((campo, valori[chiave], 60),
                                       (CAMPO_ETICHETTA, testi[chiave], 254)):
                if not vals:
                    continue
                k = self._sti_campo_layer(l, nome_c, crea=True, lung=lung)
                if k < 0:
                    continue
                GR._scrivi_valori(l, k, vals)
            n += len(valori[chiave]) + len(testi[chiave])
        try:
            self._sti_layer_etichette()
        except Exception as e:  # noqa: BLE001
            self._log_sti("Etichette in mappa non create: %s" % e)
        return n

    def _sti_rileggi_dai_layer(self):
        """Prima di generare: Chilometrica ed ETICHETTA lette dagli shape
        principali (dove l'utente le può correggere) sostituiscono quelle
        calcolate, negli elementi delle interferenze. Ritorna quante cambiano."""
        S, A, rfi, scr = _mod()
        from . import ftth_gruppi_istanze as GR
        from qgis.core import QgsFeatureRequest
        campo = self._sti_nome_campo_km()
        letti = {}
        for chiave, nome, _t in GR.LAYER:
            l = GR.layer_principale(self.project, nome)
            if l is None:
                continue
            k_km = self._sti_campo_layer(l, campo)
            k_et = self._sti_campo_layer(l, CAMPO_ETICHETTA)
            if k_km < 0 and k_et < 0:
                continue
            d = {}
            for f in l.getFeatures(QgsFeatureRequest().setFlags(QgsFeatureRequest.NoGeometry)):
                km = f.attribute(k_km) if k_km >= 0 else None
                et = f.attribute(k_et) if k_et >= 0 else None
                km = "" if km is None or str(km) == "NULL" else str(km).strip()
                et = "" if et is None or str(et) == "NULL" else str(et).strip()
                if km or et:
                    d[f.id()] = (km, et)
            letti[chiave] = d
        if not letti:
            return 0

        def _fids(e):
            out = []
            for x in (e.get("chiave_el") or "").split("|")[-1].split(","):
                try:
                    out.append(int(x))
                except ValueError:
                    pass
            return out
        # una tratta con più scavi (es. in sede e in fascia) ha nel campo
        # l'intervallo di tutti: lì non si rilegge (resterebbe allargato)
        per_fid = {}
        for i in self._sti.get("interferenze") or []:
            for e in i.elementi:
                if e.get("tipo") == "scavo":
                    for f in _fids(e):
                        per_fid[f] = per_fid.get(f, 0) + 1
        n = 0
        for i in self._sti.get("interferenze") or []:
            for e in i.elementi:
                t = e.get("tipo")
                if t == "scavo":
                    fids = [f for f in _fids(e) if per_fid.get(f) == 1]
                    vals = [letti.get("tratte", {}).get(f) for f in fids]
                    vals = [v for v in vals if v]
                    if not vals:
                        continue
                    kms = [k for v in vals for k in S.km_da_testo(v[0])]
                    et = vals[0][1]
                elif t in ("pozzetto", "armadio") and e.get("fid") is not None:
                    v = letti.get("pozzetti" if t == "pozzetto" else "armadi", {}).get(
                        int(e["fid"]))
                    if not v:
                        continue
                    kms, et = S.km_da_testo(v[0]), v[1]
                else:
                    continue
                cambiato = False
                if kms:
                    da, a = S.km_intervallo(kms)
                    if (da, a) != (e.get("km_da"), e.get("km_a")):
                        e["km_da"], e["km_a"] = da, a
                        cambiato = True
                if et and " ".join(et.split()) != " ".join((e.get("testo") or "").split()):
                    e["testo"] = et
                    cambiato = True
                n += cambiato
        return n

    def _sti_layer_etichette(self):
        """In mappa le etichette come in stampa: per ogni layer principale una
        copia collegata (stessa fonte, solo gli elementi con ETICHETTA) che
        disegna soltanto il testo del campo ETICHETTA, con la grafica scelta.
        Correggendo il campo nello shape l'etichetta cambia in mappa e in
        stampa. Gruppo «Istanze > Strade > Etichette in stampa»."""
        from . import ftth_gruppi_istanze as GR
        from . import ftth_strade_layout as SL
        from qgis.core import (QgsNullSymbolRenderer, QgsPalLayerSettings, QgsTextFormat,
                               QgsTextBackgroundSettings, QgsVectorLayerSimpleLabeling,
                               QgsWkbTypes)
        from qgis.PyQt.QtCore import QSizeF
        prj = self.project
        radice = prj.layerTreeRoot()
        g_sez = GR.gruppo_sezione(radice, "strade")
        g_et = g_sez.findGroup(GRUPPO_ETICHETTE)
        if g_et is not None:
            for nodo in g_et.findLayers():
                if nodo.layer() is not None:
                    prj.removeMapLayer(nodo.layer().id())
            g_sez.removeChildNode(g_et)
        g_et = g_sez.insertGroup(0, GRUPPO_ETICHETTE)
        dim, riq = SL.grafica_etichette()
        reg = GR.registro(prj)
        reg["_etichette"] = []
        for _c, nome, _t in GR.LAYER:
            l = GR.layer_principale(prj, nome)
            if l is None or l.fields().indexOf(CAMPO_ETICHETTA) < 0:
                continue
            c = l.clone()
            c.setName("Etichette in stampa — %s" % GR._nome_pulito(l.name()))
            c.setSubsetString("\"%s\" IS NOT NULL AND \"%s\" <> ''"
                              % (CAMPO_ETICHETTA, CAMPO_ETICHETTA))
            c.setRenderer(QgsNullSymbolRenderer())
            pal = QgsPalLayerSettings()
            pal.fieldName = CAMPO_ETICHETTA
            tf = QgsTextFormat()
            tf.setSize(dim)
            bg = QgsTextBackgroundSettings()
            bg.setEnabled(riq)
            bg.setFillColor(QColor(255, 255, 255, 250))
            bg.setStrokeColor(QColor(110, 110, 110))
            bg.setStrokeWidth(0.2)
            bg.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
            bg.setSize(QSizeF(1.0, 0.5))
            tf.setBackground(bg)
            pal.setFormat(tf)
            try:
                pal.multilineAlign = QgsPalLayerSettings.MultiCenter
            except Exception:  # noqa: BLE001
                pass
            if c.geometryType() == QgsWkbTypes.LineGeometry:
                pal.placement = QgsPalLayerSettings.Horizontal
            else:
                pal.placement = QgsPalLayerSettings.OrderedPositionsAroundPoint
                pal.dist = 2.0
            c.setLabeling(QgsVectorLayerSimpleLabeling(pal))
            c.setLabelsEnabled(True)
            prj.addMapLayer(c, False)
            g_et.addLayer(c)
            reg["_etichette"].append(c.id())
        GR.registro(prj, reg)

    # ------------------------------------------------------- layer cippi
    def _sti_strade_per_cippi(self):
        """Strade per la tendina dei cippi: le confermate, o le proposte."""
        strade = self._sti.get("strade") or []
        conf = [s.ref for s in strade if getattr(s, "confermata", s.includi)]
        return conf or [s.ref for s in strade if getattr(s, "metri", 0) > 0]

    def _sti_crea_layer_cippi(self):
        """Crea (se manca) «Cippi_Chilometrici» (strada, km) accanto al
        progetto, con la strada da una tendina delle strade confermate; lo
        sceglie per il calcolo e mette subito a disegnare."""
        from . import ftth_trovati as _TR
        strade = self._sti_strade_per_cippi()
        vl, err = _TR.crea_layer_cippi(self.project, getattr(self, "iface", None),
                                       "Cippi_Chilometrici", "strada", strade)
        if vl is None:
            QMessageBox.warning(self, "Crea il layer cippi", err)
            return
        self.cb_sti_cippi.setLayer(vl)
        self.cb_sti_campo_cippo.setField("km")
        if self.cb_sti_fonte_cippi.currentData() == "osm":
            self.cb_sti_fonte_cippi.setCurrentIndex(self.cb_sti_fonte_cippi.findData("progetto"))
        testo = ("Layer «Cippi_Chilometrici» pronto, in modifica e scelto per il calcolo.\n\n"
                 "Clicca sulla mappa ogni cippo: nel modulo scegli la strada dalla tendina (%s) e "
                 "scrivi il km (es. 12+300). Poi salva le modifiche del layer e premi «Calcola le "
                 "chilometriche delle tratte»."
                 % (", ".join(strade) if strade else "conferma prima le strade al punto 2"))
        self._log_sti(testo)
        QMessageBox.information(self, "Crea il layer cippi", testo)

    def _sti_cippi_layer(self, lyr, campo):
        """[(Point WGS84, metri, ref strada o '')] da un layer di cippi."""
        S, A, rfi, scr = _mod()
        out = []
        if lyr is not None and lyr.isValid() and campo:
            nomi = [f.name() for f in lyr.fields()]
            c_str = next((n for n in nomi if n.lower() in ("strada", "ref", "sigla")), None)
            for f in lyr.getFeatures():
                if not f.hasGeometry():
                    continue
                km = S.km_in_metri(f[campo])
                if km is None:
                    continue
                g = self._rfi_wkt(f.geometry(), lyr)
                p = g if g.geom_type == "Point" else g.representative_point()
                out.append((p, km, str(f[c_str] or "") if c_str else ""))
        return out

    def _sti_cippi(self, strade, lyr=None, campo=None, con_osm=None):
        """[(Point WGS84, metri, ref strada o '')] dal layer cippi scelto e,
        se spuntato, dai cippi OSM (highway=milestone) intorno alle strade."""
        S, A, rfi, scr = _mod()
        from shapely.geometry import Point
        out = []
        if lyr is None:
            fonte = getattr(self, "cb_sti_fonte_cippi", None)
            if fonte is None or fonte.currentData() != "osm":
                lyr = self.cb_sti_cippi.currentLayer()
                campo = self.cb_sti_campo_cippo.currentField()
        if con_osm is None:
            con_osm = self.chk_sti_cippi_osm.isChecked()
        out += self._sti_cippi_layer(lyr, campo)
        if con_osm and strade:
            from shapely.ops import unary_union
            x0, y0, x1, y1 = unary_union([s.geom for s in strade]).bounds
            q = ('[out:json][timeout:90];node["highway"="milestone"](%f,%f,%f,%f);out body qt;'
                 % (y0, x0, y1, x1))
            try:
                els, _err = self._sti_sottofondo(lambda: self._acq_overpass_parallelo(q, gui=False))
            except Exception:  # noqa: BLE001
                els = None
            n_osm = 0
            for e in els or []:
                t = e.get("tags") or {}
                km = S.km_in_metri(t.get("distance") or t.get("pk") or t.get("name"))
                if km is None or "lat" not in e:
                    continue
                parsed = scr.normalizza_ref(t.get("ref") or t.get("highway:ref") or "")
                out.append((Point(e["lon"], e["lat"]), km, parsed[1] if parsed else ""))
                n_osm += 1
            self._log_sti("Cippi: %d dal layer, %d da OSM." % (len(out) - n_osm, n_osm))
        return out

    def _sti_perimetri(self):
        """[(Polygon WGS84, nome, abitanti)] dal layer dei centri abitati."""
        lyr = self.cb_sti_centri.currentLayer()
        if lyr is None or not lyr.isValid():
            return []
        c_nome = self.cb_sti_centri_nome.currentField()
        c_pop = self.cb_sti_centri_pop.currentField()
        out = []
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            if not g.is_valid:
                g = g.buffer(0)
            pop = None
            if c_pop:
                try:
                    pop = int(float(str(f[c_pop]).replace(".", "").replace(",", ".")))
                except (TypeError, ValueError):
                    pop = None
            out.append((g, str(f[c_nome]) if c_nome and f[c_nome] is not None else "", pop))
        self._log_sti("Centri abitati dal layer «%s»: %d perimetri." % (lyr.name(), len(out)))
        return out

    def _sti_riempi(self, interf):
        S, A, rfi, scr = _mod()
        t = self.tab_sti
        t.setRowCount(0)
        for i in interf:
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem("")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if i.includi else Qt.Unchecked)
            t.setItem(r, CI_INCL, it)
            kms = [v for e in i.elementi for v in (e.get("km_da"), e.get("km_a")) if v]
            da, a = S.km_intervallo(kms)
            attr = any(e.get("attraversa") for e in i.elementi)
            lav = "; ".join(e.get("testo", "").replace("\n", " ") for e in i.elementi
                            if e.get("testo"))
            vals = {CI_N: str(i.id), CI_STRADA: i.corso,
                    CI_ZONA: ("in sede" + (" (attraversamento)" if attr else ""))
                    if i.categoria == S.ZONA_SEDE else "in fascia di rispetto",
                    CI_KM: S.testo_km(da, a) or "manca (coordinate)",
                    CI_LAVORI: lav, CI_NOTE: "; ".join(i.note)}
            for c, val in vals.items():
                x = QTableWidgetItem(val or "")
                x.setFlags(x.flags() & ~Qt.ItemIsEditable)
                t.setItem(r, c, x)
        t.resizeColumnsToContents()
        self._sti_aggiorna_titoli()

    def _sti_istanze_per_gruppi(self):
        """Istanze dalle righe confermate, per i gruppi di layer nel progetto."""
        S, A, rfi, scr = _mod()
        comune = self.txt_sti_comune.text().strip()
        if not comune or not self._sti.get("interferenze"):
            QMessageBox.warning(self, "Dati mancanti", "Prima trova strade e interferenze.")
            return None
        t = self.tab_sti
        for r, i in enumerate(self._sti["interferenze"]):
            i.includi = t.item(r, CI_INCL).checkState() == Qt.Checked
        istanze = S.raggruppa_istanze_strade(
            self._sti["interferenze"], self._sti_leggi_strade(), comune,
            {"indirizzo": self.txt_sti_ind_comune.text().strip(),
             "pec": self.txt_sti_pec_comune.text().strip()})
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza", "Nessuna riga spuntata.")
        return istanze

    # -------------------------------------------------------------- genera
    def _sti_genera(self):
        try:
            self._sti_genera_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_sti("ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore generazione", str(e))

    def _sti_genera_impl(self, cartella_out=None):
        S, A, rfi, scr = _mod()
        try:
            from . import ftth_acque_layout as AL
        except ImportError:
            import ftth_acque_layout as AL
        from docx import Document
        comune = self.txt_sti_comune.text().strip()
        if not comune or not self._sti.get("interferenze"):
            QMessageBox.warning(self, "Dati mancanti", "Prima trova strade e interferenze.")
            return
        t = self.tab_sti
        for r, i in enumerate(self._sti["interferenze"]):
            i.includi = t.item(r, CI_INCL).checkState() == Qt.Checked
        # chilometriche ed etichette corrette a mano negli shape: valgono quelle
        try:
            n_c = self._sti_rileggi_dai_layer()
            if n_c:
                self._log_sti("Dagli shape: %d chilometriche/etichette corrette a mano." % n_c)
        except Exception as e:  # noqa: BLE001
            self._log_sti("Chilometriche ed etichette degli shape non rilette: %s" % e)
        strade = self._sti_leggi_strade()
        istanze = S.raggruppa_istanze_strade(
            self._sti["interferenze"], strade, comune,
            {"indirizzo": self.txt_sti_ind_comune.text().strip(),
             "pec": self.txt_sti_pec_comune.text().strip()})
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza", "Nessuna riga spuntata.")
            return
        self._sti_salva()
        try:    # elementi aggiunti a mano al gruppo dell'istanza
            from . import ftth_gruppi_istanze as _GR
            _GR.aggiungi_da_ricerca(self.project, istanze, self._sti["interferenze"],
                                    lambda i, ist: i.corso == ist.corso, self._log_sti)
        except Exception as e:  # noqa: BLE001
            self._log_sti("Elementi aggiunti a mano non considerati: %s" % e)
        if cartella_out is None:
            cartella_out = os.path.join(self.project.homePath() or os.path.expanduser("~"),
                                        "Istanze Strade", comune.upper())
        os.makedirs(cartella_out, exist_ok=True)
        self._sti["cartella"] = cartella_out
        dati_c = rfi.DatiComune(comune, self.txt_sti_prov.text().strip(),
                                self.txt_sti_cap.text().strip(),
                                self.txt_sti_ind_comune.text().strip(),
                                self.txt_sti_pec_comune.text().strip())
        qui = os.path.dirname(os.path.abspath(__file__))
        tpl_acque = os.path.join(qui, "modelli_acque")
        tpl_art49 = os.path.join(qui, "modelli_strade", "TEMPLATE_1.0_art.49.docx")
        rese = self._rfi_rese() if hasattr(self, "_rfi_rese") else None
        righe = self.cb_sti_righe.currentData() or "km"
        da_pdf = []
        self._log_sti("Istanze da generare: %d" % len(istanze))
        for ist in istanze:
            s = ist.strada
            ist.attraversamenti_sempre = bool(
                getattr(self, "chk_sti_attr", None) and self.chk_sti_attr.isChecked())
            out = os.path.join(cartella_out, ist.nome_base)
            os.makedirs(out, exist_ok=True)
            docs = []
            # 1.0 istanza art. 49 (modello strade)
            doc = Document(tpl_art49)
            rfi.applica_condizioni(doc, {"SE_EPC": bool(s and s.epc_comune)})
            rfi.sostituisci_tutto(doc, S.valori_strade(ist, dati_c, rese))
            p_art49 = os.path.join(out, rfi.NOMI_FILE["art49"].format(base=ist.nome_base))
            doc.save(p_art49)
            docs.append(os.path.basename(p_art49))
            # 1.2 RT+CR e 1.3 bollo (modelli Acque, tabelle per progressiva)
            dest = {"nome": s.ente_nome if s else "", "indirizzo": s.ente_indirizzo if s
                    else "", "pec": s.ente_pec if s else ""}
            # 1.2 RT+CR dal modello strade (tabelle sede e fascia separate, come
            # nella pratica SS71); 1.3 bollo dal modello generico
            p_rt = os.path.join(out, rfi.NOMI_FILE["rt"].format(base=ist.nome_base))
            S.genera_rt_strade(
                ist, dati_c, os.path.join(qui, "modelli_strade"), p_rt, rese,
                pl_file=rfi.NOMI_FILE["pl"].format(base=ist.nome_base),
                rt_file=os.path.basename(p_rt).replace(".docx", ".pdf"))
            prod = A.genera_documenti_istanza(
                ist, dati_c, dest, tpl_acque, out, rese, testi=S.testi_rt_strade(ist),
                solo=("bollo",))
            prod["rt"] = p_rt
            docs += [os.path.basename(p) for p in prod.values() if p]
            da_pdf.append(prod.get("rt"))
            if self.chk_sti_pdf.isChecked():
                da_pdf += [p_art49, prod.get("bollo")]
            self._log_sti("- %s: %d interferenze -> %s" % (ist.nome_base,
                                                           len(ist.interferenze), out))
            if self.chk_sti_pl.isChecked() and s is not None:
                pdf = os.path.join(out, rfi.NOMI_FILE["pl"].format(base=ist.nome_base))
                aree = self._sti_aree_pl(s)
                if not self.chk_sti_a3.isChecked():
                    try:
                        from . import ftth_strade_layout as SL
                    except ImportError:
                        import ftth_strade_layout as SL
                    ok = SL.genera_pl_strade(
                        self.project, ist, dati_c, pdf, s,
                        orto_id=self.cb_sti_orto.currentData(),
                        log=lambda m: self._log_sti("    " + m),
                        fascia=self.chk_sti_fascia.isChecked()
                        and "ANAS" in (s.ente_nome or "").upper())
                    docs.append(os.path.basename(pdf) if ok else os.path.basename(pdf) +
                                " (NON riuscita)")
                    self._log_sti("    PL A1: %d tavole — %s" % (
                        len(ist.tavole), "ok" if ok else "NON riuscita"))
                    with open(os.path.join(out, "LEGGIMI.txt"), "w", encoding="utf-8") as fh:
                        fh.write(S.promemoria_strade(ist, dati_c, docs))
                    continue
                ok = AL.genera_pl_acque(
                    self.project, ist, dati_c, pdf, ente=s.ente_nome,
                    orto_id=self.cb_sti_orto.currentData(),
                    log=lambda m: self._log_sti("    " + m),
                    vincolo={"aree": aree, "prefisso": "STRADE",
                             "titolo_legenda": "STRADA", "riquadro": "sezione",
                             "tipologia_cartiglio": (s.ente_nome or "").upper(),
                             "linea_cartiglio": ("LUNGO LA %s%s" % (
                                 s.nome_documenti(), S.specifica_centro(ist))).upper()})
                docs.append(os.path.basename(pdf) if ok else os.path.basename(pdf) +
                            " (NON riuscita)")
                self._log_sti("    PL: %d tavole — %s" % (len(ist.tavole),
                                                         "ok" if ok else "NON riuscita"))
            with open(os.path.join(out, "LEGGIMI.txt"), "w", encoding="utf-8") as fh:
                fh.write(S.promemoria_strade(ist, dati_c, docs))
        try:    # logo FiberCop classico o «Milano Cortina 2026» (flag del progetto)
            from . import ftth_logo as _LOGO
            n_logo = _LOGO.applica_cartella(cartella_out, _LOGO.attivo(self.project))
            if n_logo:
                self._log_sti("Logo FiberCop %s in %d documenti Word." % (
                    "Milano Cortina 2026" if _LOGO.attivo(self.project) else "classico", n_logo))
        except Exception as e_logo:  # noqa: BLE001
            self._log_sti("Logo nei documenti non sostituito: %s" % e_logo)
        da_pdf = [p for p in da_pdf if p]
        if da_pdf:
            self._log_sti("Conversione in PDF (Word)...")
            ris = rfi.converti_pdf(da_pdf)
            ko = [os.path.basename(p) for p, pdf in ris.items() if not pdf]
            if ko:
                self._log_sti("  PDF non creati: %s" % ", ".join(ko))
        self._log_sti("Fatto. In ogni cartella il LEGGIMI dice cosa completare.")

    def _sti_aree_pl(self, s):
        """Sede stradale e fascia di rispetto come aree tratteggiate della PL."""
        S, A, rfi, scr = _mod()

        class _Area:
            def __init__(self, tipo, geom, voce):
                self.tipo, self.geom, self._voce = tipo, geom, voce

            def voce(self):
                return self._voce
        z = S.zone_strada(s)
        return [_Area("strada_sede", z[0]["geom"], "Sede stradale %s" % s.nome_documenti()),
                _Area("strada_fascia", z[1]["geom"], "Fascia di rispetto %s (%g m, DPR "
                      "495/1992)" % (s.nome_documenti(), s.fascia_m))]

    def _sti_apri_cartella(self):
        c = self._sti.get("cartella")
        if c and os.path.isdir(c):
            os.startfile(c)  # noqa: S606
