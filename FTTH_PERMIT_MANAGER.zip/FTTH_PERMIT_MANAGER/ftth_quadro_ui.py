"""Scheda «Quadro pratiche» (Altri Enti): l'indice delle pratiche da
presentare, costruito dallo screening del territorio e dalle schede del
plugin. Mixin agganciato a FTTHPermessiDialog come RFI e Acque."""
import json

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QCheckBox, QComboBox, QHBoxLayout, QHeaderView, QLabel, QPushButton, QTreeWidget,
    QTreeWidgetItem, QVBoxLayout, QWidget,
)

PRJ_SCOPE_Q = "ftth_quadro"
COL_ENTE, COL_PERCHE, COL_RETE, COL_STATO, COL_NOTE, COL_SCHEDA = range(6)


def _q_mod():
    try:
        from . import ftth_quadro as q
    except ImportError:
        import ftth_quadro as q
    return q


class QuadroMixin:
    # ------------------------------------------------------------- scheda
    def _tab_quadro(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Indice delle pratiche da presentare per il progetto aperto, per categoria. "
            "Nasce dallo Screening territorio: per ogni ente dice se la sua competenza è "
            "toccata dalla rete in progetto («Rete in progetto: Sì»), se è solo presente "
            "nel comune o se va verificata. «Apri» porta alla scheda che prepara la "
            "pratica; lo stato di ogni pratica si salva nel progetto."))
        self.lbl_quadro = QLabel()
        self.lbl_quadro.setWordWrap(True)
        v.addWidget(self.lbl_quadro)
        riga = QHBoxLayout()
        b_scr = QPushButton("Vai allo Screening territorio")
        b_scr.setToolTip("Il quadro si aggiorna da solo alla fine di ogni screening.")
        b_scr.clicked.connect(lambda *_: self._quadro_vai("Screening territorio"))
        riga.addWidget(b_scr)
        self.chk_quadro_tutti = QCheckBox("Mostra anche gli enti solo presenti nel comune")
        self.chk_quadro_tutti.toggled.connect(lambda *_: self._quadro_riempi())
        riga.addWidget(self.chk_quadro_tutti)
        b_agg = QPushButton("Aggiorna")
        b_agg.setToolTip("Rilegge dal progetto aperto lo screening e lo stato delle schede "
                         "(interferenze trovate in RFI e Acque). Se il progetto non ha uno "
                         "screening, il quadro si svuota.")
        b_agg.clicked.connect(self._quadro_aggiorna)
        riga.addWidget(b_agg)
        riga.addStretch()
        v.addLayout(riga)
        self.tree_quadro = QTreeWidget()
        self.tree_quadro.setColumnCount(6)
        self.tree_quadro.setHeaderLabels(["Ente", "Perché", "Rete in progetto", "Stato",
                                          "Note", "Scheda"])
        self.tree_quadro.setMinimumHeight(360)
        self.tree_quadro.setAlternatingRowColors(True)
        self.tree_quadro.setWordWrap(True)
        h = self.tree_quadro.header()
        h.setSectionResizeMode(QHeaderView.Interactive)
        for col, lw in ((COL_ENTE, 260), (COL_PERCHE, 330), (COL_RETE, 120),
                        (COL_STATO, 130), (COL_NOTE, 200)):
            self.tree_quadro.setColumnWidth(col, lw)
        self.tree_quadro.itemChanged.connect(self._quadro_nota_cambiata)
        v.addWidget(self.tree_quadro)
        self.lbl_quadro_schede = QLabel()
        self.lbl_quadro_schede.setWordWrap(True)
        self.lbl_quadro_schede.setTextFormat(Qt.RichText)
        v.addWidget(self.lbl_quadro_schede)
        v.addStretch()
        try:
            self._quadro_carica_progetto()
        except Exception:  # noqa: BLE001
            pass
        self._quadro_riempi()
        # progetto aperto o chiuso con la finestra già aperta: il quadro segue
        # il progetto (prima restava quello del progetto precedente)
        try:
            self.project.readProject.connect(lambda *_: self._quadro_aggiorna())
            self.project.cleared.connect(lambda *_: self._quadro_aggiorna())
        except Exception:  # noqa: BLE001
            pass
        return w

    # -------------------------------------------------------------- dati
    def _quadro_dati(self):
        if not hasattr(self, "_quadro_cache"):
            self._quadro_cache = {"quadro": None, "stati": {}}
        return self._quadro_cache

    def _quadro_carica_progetto(self):
        """Quadro e stati salvati nel progetto (riapertura)."""
        prj = getattr(self, "project", None)
        dati = self._quadro_dati()
        dati["quadro"], dati["stati"] = None, {}
        if prj is None:
            return
        for chiave in ("quadro", "stati"):
            testo, ok = prj.readEntry(PRJ_SCOPE_Q, chiave, "")
            if ok and testo:
                try:
                    dati[chiave] = json.loads(testo)
                except ValueError:
                    pass
        dati["stati"] = dati["stati"] or {}
        self._quadro_progetto_letto = prj.fileName()

    def _quadro_salva_progetto(self):
        prj = getattr(self, "project", None)
        if prj is None:
            return
        dati = self._quadro_dati()
        if dati.get("quadro") is not None:
            prj.writeEntry(PRJ_SCOPE_Q, "quadro", json.dumps(dati["quadro"]))
        prj.writeEntry(PRJ_SCOPE_Q, "stati", json.dumps(dati.get("stati") or {}))

    def _quadro_da_screening(self, rep, scr):
        """Chiamata alla fine di uno screening riuscito: il quadro si rifà."""
        q = _q_mod()
        quadro = q.voci_da_screening(rep, scr.classifica_enti_impatto)
        self._quadro_dati()["quadro"] = quadro
        self._quadro_salva_progetto()
        if hasattr(self, "tree_quadro"):
            self._quadro_riempi()
        return quadro

    def _quadro_aggiorna(self, *_):
        """«Aggiorna»: il quadro è quello salvato nel progetto aperto. Prima
        restava in memoria quello del progetto precedente anche se il progetto
        aperto non aveva nessuno screening."""
        self._quadro_carica_progetto()
        self._quadro_riempi()

    def _quadro_al_cambio_progetto(self):
        prj = getattr(self, "project", None)
        if prj is None or getattr(self, "_quadro_progetto_letto", None) == prj.fileName():
            return
        self._quadro_carica_progetto()
        if hasattr(self, "tree_quadro"):
            self._quadro_riempi()

    # ------------------------------------------------------------ tabella
    def _quadro_riempi(self):
        q = _q_mod()
        dati = self._quadro_dati()
        quadro, stati = dati.get("quadro"), dati.get("stati") or {}
        t = self.tree_quadro
        t.blockSignals(True)
        t.clear()
        if not quadro:
            self.lbl_quadro.setText(
                "<b>Nessuno screening per questo progetto.</b> Lancia lo Screening territorio "
                "(meglio con il tracciato della rete): alla fine il quadro si compila da solo.")
            t.blockSignals(False)
            self.lbl_quadro_schede.setText(self._quadro_testo_schede())
            return
        voci = quadro.get("voci") or []
        tutti = self.chk_quadro_tutti.isChecked()
        self.lbl_quadro.setText(
            "<b>Comune di %s</b> — screening del %s, %s." % (
                quadro.get("comune") or "?", quadro.get("data") or "?",
                q.MODO_TESTO.get(quadro.get("modo"), quadro.get("modo") or "")))
        riep = q.riepilogo(quadro, stati)
        grassetto = QFont()
        grassetto.setBold(True)
        for cat, titolo, scheda in q.CATEGORIE:
            mie = [x for x in voci if x["categoria"] == cat and
                   (tutti or x["impatto"] != q.IMPATTO_TERRITORIO)]
            if not mie:
                continue
            r = riep.get(cat) or {}
            parti = []
            if r.get("da_presentare"):
                parti.append("%d da presentare" % r["da_presentare"])
            if r.get("verificare"):
                parti.append("%d da verificare" % r["verificare"])
            if r.get("fatte"):
                parti.append("%d generate" % r["fatte"])
            padre = QTreeWidgetItem(["%s%s" % (titolo, (" — " + ", ".join(parti)) if parti
                                               else " — nessuna pratica necessaria")])
            padre.setFirstColumnSpanned(True)
            padre.setFont(0, grassetto)
            padre.setFlags(Qt.ItemIsEnabled)
            t.addTopLevelItem(padre)
            padre.setFirstColumnSpanned(True)
            for x in mie:
                it = QTreeWidgetItem([x["ente"] + (("\n" + x["ruolo"]) if x["ruolo"] else ""),
                                      x["motivo"], q.IMPATTO_TESTO.get(x["impatto"], ""),
                                      "", (stati.get(x["chiave"]) or {}).get("note", ""), ""])
                it.setData(0, Qt.UserRole, x["chiave"])
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsEditable)
                it.setToolTip(COL_PERCHE, x["motivo"])
                it.setToolTip(COL_ENTE, x["ente"] + ("\nPEC: " + x["pec"] if x["pec"] else ""))
                if x["impatto"] == q.IMPATTO_RETE:
                    it.setForeground(COL_RETE, QColor(0, 120, 0))
                    it.setFont(COL_RETE, grassetto)
                elif x["impatto"] == q.IMPATTO_IGNOTO:
                    it.setForeground(COL_RETE, QColor(180, 100, 0))
                else:
                    for col in range(6):
                        it.setForeground(col, QColor(120, 120, 120))
                padre.addChild(it)
                cb = QComboBox()
                cb.addItems(q.STATI)
                cb.setCurrentText(q.stato_voce(x, stati))
                cb.setToolTip("Scegli tu lo stato della pratica. «Apri la scheda» si attiva "
                              "con «da fare».")
                cb.currentTextChanged.connect(
                    lambda s, k=x["chiave"]: self._quadro_stato_cambiato(k, s))
                t.setItemWidget(it, COL_STATO, cb)
                if scheda:
                    b = QPushButton("Apri «%s»" % scheda)
                    b.clicked.connect(lambda _=False, c=cat, e=x["ente"]: self._quadro_apri(c, e))
                    # la scheda si apre solo per le pratiche «da fare»
                    b.setEnabled(cb.currentText() == "da fare")
                    cb.currentTextChanged.connect(
                        lambda s, bb=b: bb.setEnabled(s == "da fare"))
                    t.setItemWidget(it, COL_SCHEDA, b)
                else:
                    it.setText(COL_SCHEDA, "scheda in arrivo")
                    it.setForeground(COL_SCHEDA, QColor(130, 130, 130))
            padre.setExpanded(True)
        t.blockSignals(False)
        self.lbl_quadro_schede.setText(self._quadro_testo_schede())

    def _quadro_testo_schede(self):
        """Cosa dicono le schede sul progetto (interferenze vere misurate)."""
        righe = []
        try:
            st = self._rfi_state() if hasattr(self, "_rfi_state") else {}
            interf = st.get("interferenze") or []
            if interf:
                da = sum(1 for i in interf if getattr(i, "tipologia", None))
                righe.append("<b>Istanze RFI</b>: %d interferenze con la ferrovia, %d da "
                             "presentare." % (len(interf), da))
            else:
                righe.append("<b>Istanze RFI</b>: interferenze non ancora cercate.")
        except Exception:  # noqa: BLE001
            pass
        try:
            st = self._acq_state() if hasattr(self, "_acq_state") else {}
            interf = st.get("interferenze") or []
            if interf:
                incl = [i for i in interf if i.includi]
                enti = {(i.ente_tipo, (i.ente_nome or "").strip()) for i in incl}
                righe.append("<b>Istanze Acque</b>: %d interferenze, %d in istanza, %d enti."
                             % (len(interf), len(incl), len(enti)))
            else:
                righe.append("<b>Istanze Acque</b>: interferenze non ancora cercate.")
        except Exception:  # noqa: BLE001
            pass
        return "Verifica sul progetto nelle schede — " + " · ".join(righe) if righe else ""

    # ----------------------------------------------------------- azioni
    def _quadro_stato_cambiato(self, chiave, stato):
        st = self._quadro_dati().setdefault("stati", {})
        st.setdefault(chiave, {})["stato"] = stato
        self._quadro_salva_progetto()
        # titoli delle categorie con i conteggi aggiornati
        q = _q_mod()
        quadro = self._quadro_dati().get("quadro")
        if quadro:
            riep = q.riepilogo(quadro, st)
            for k in range(self.tree_quadro.topLevelItemCount()):
                padre = self.tree_quadro.topLevelItem(k)
                cat = next((c for c, tit, _s in q.CATEGORIE
                            if padre.text(0).startswith(tit)), None)
                r = riep.get(cat) or {}
                parti = []
                if r.get("da_presentare"):
                    parti.append("%d da presentare" % r["da_presentare"])
                if r.get("verificare"):
                    parti.append("%d da verificare" % r["verificare"])
                if r.get("fatte"):
                    parti.append("%d generate" % r["fatte"])
                if cat:
                    padre.setText(0, "%s%s" % (q.TITOLO[cat], (" — " + ", ".join(parti))
                                               if parti else " — nessuna pratica necessaria"))

    def _quadro_nota_cambiata(self, item, col):
        if col != COL_NOTE:
            return
        chiave = item.data(0, Qt.UserRole)
        if not chiave:
            return
        st = self._quadro_dati().setdefault("stati", {})
        st.setdefault(chiave, {})["note"] = item.text(COL_NOTE)
        self._quadro_salva_progetto()

    def _quadro_vai(self, nome_scheda):
        tabs = getattr(self, "_tabs_altri_enti", None)
        if tabs is None:
            return None
        for k in range(tabs.count()):
            if tabs.tabText(k) == nome_scheda:
                tabs.setCurrentIndex(k)
                return tabs.widget(k)
        return None

    def _quadro_apri(self, cat, ente=""):
        """Apre la scheda della categoria con il comune del quadro."""
        q = _q_mod()
        quadro = self._quadro_dati().get("quadro") or {}
        comune = quadro.get("comune") or ""
        scheda = q.SCHEDA.get(cat)
        if not scheda:
            return
        self._quadro_vai(scheda)
        if cat == "acque" and hasattr(self, "txt_acq_comune") and comune:
            if self.txt_acq_comune.text().strip().lower() != comune.lower():
                self.txt_acq_comune.setText(comune)
                try:
                    self._acq_auto_comune()
                except Exception:  # noqa: BLE001
                    pass
        elif cat in ("paesaggio", "natura") and hasattr(self, "_vin_w") and comune:
            s = "sopr" if cat == "paesaggio" else "parchi"
            w = self._vin_w.get(s) or {}
            txt = w.get("comune")
            if txt is not None and txt.text().strip().lower() != comune.lower():
                txt.setText(comune)
        elif cat == "ferrovie" and hasattr(self, "txt_rfi_comune") and comune:
            if self.txt_rfi_comune.text().strip().lower() != comune.lower():
                self.txt_rfi_comune.setText(comune.upper())
        elif cat == "strade":
            if hasattr(self, "txt_sti_comune") and comune and \
                    self.txt_sti_comune.text().strip().lower() != comune.lower():
                self.txt_sti_comune.setText(comune)
                self.txt_sti_comune.editingFinished.emit()
            sub = getattr(self, "_tabs_strade", None)     # solo vecchio layout
            if sub is not None:
                voluta = "Suolo comunale" if ente.lower().startswith("comune") else \
                    "Chilometriche"
                for k in range(sub.count()):
                    if sub.tabText(k) == voluta:
                        sub.setCurrentIndex(k)
                        break
