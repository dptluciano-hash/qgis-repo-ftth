# -*- coding: utf-8 -*-
"""Verifica interferenze (Comune): tratte di infrastruttura vicine a
ferrovie, corsi d'acqua, strade ANAS, provinciali e autostrade, da guardare già nel permesso comunale.

Come la Verifica armadi: un pannello agganciato alla mappa scorre le tratte
trovate, centra la mappa ed evidenzia la tratta, apre Street View / Google
Maps sul punto più vicino all'opera e registra l'esito (OK, Da modificare,
Modificata) con una nota. Esiti e ultima ricerca stanno nel PROGETTO.
"""
import json
import os

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices
from qgis.PyQt.QtWidgets import (
    QApplication, QButtonGroup, QCheckBox, QComboBox, QDockWidget, QFileDialog, QFormLayout,
    QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QRadioButton, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsFeatureRequest,
    QgsGeometry, QgsLineSymbol, QgsMapLayerProxyModel, QgsPointXY, QgsProject, QgsRectangle,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsVectorLayer, QgsField, QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant
from qgis.gui import QgsMapLayerComboBox, QgsRubberBand, QgsVertexMarker


def _vr():
    try:
        from . import ftth_verifica_rete as VR
    except ImportError:
        import ftth_verifica_rete as VR
    return VR


def _ar():
    try:
        from . import ftth_armadi as AR
    except ImportError:
        import ftth_armadi as AR
    return AR


NOME_LAYER_OSM = "Verifica interferenze - ferrovie, acque, ANAS (OSM)"
AVVISO_FONTI = ("⚠ Ferrovie, corsi d'acqua, strade ANAS, provinciali e autostrade vengono da OpenStreetMap: "
                "l'attendibilità delle fonti è sempre da verificare (tracciati, gestore, "
                "classificazione della strada, corsi d'acqua mancanti o tombinati) sulle "
                "cartografie ufficiali e con l'ente competente.")


def _etichetta_avviso():
    l = QLabel(AVVISO_FONTI)
    l.setWordWrap(True)
    l.setStyleSheet("color: #b45f06; font-style: italic;")
    return l


def _carica_esiti(project):
    VR = _vr()
    t, _ok = project.readEntry(VR.PRJ_SCOPE, VR.PRJ_CHIAVE, "")
    return VR.esiti_da_testo(t)


def _salva_esiti(project, esiti):
    VR = _vr()
    project.writeEntry(VR.PRJ_SCOPE, VR.PRJ_CHIAVE, VR.esiti_in_testo(esiti))


class PannelloVerificaRete(QDockWidget):
    """Pannello «Verifica interferenze» agganciato alla mappa."""

    def __init__(self, iface, project, lyr, voci, parent=None):
        super().__init__("Verifica interferenze", parent)
        self.setObjectName("FTTHVerificaInterferenze")
        self.iface, self.project, self.lyr, self.voci = iface, project, lyr, voci
        self.esiti = _carica_esiti(project)
        self.k = 0
        self._marker, self._marker_tutti, self._banda = None, [], None
        VR, AR = _vr(), _ar()
        tr = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"), project.crs(),
                                    project)
        for v in self.voci:
            v["punto"] = tr.transform(QgsPointXY(v["lon"], v["lat"]))
        w = QWidget()
        lay = QVBoxLayout(w)
        r = QHBoxLayout()
        b = QPushButton("◀"); b.setFixedWidth(34); b.clicked.connect(lambda: self.vai(self.k - 1))
        r.addWidget(b)
        self.cb = QComboBox()
        for v in self.voci:
            self.cb.addItem("%s · tratta %s · %s" % (VR.CATEGORIE[v["categoria"]]["nome"],
                                                     v["fid"], v["nome"]))
        self.cb.currentIndexChanged.connect(self.vai)
        r.addWidget(self.cb, 1)
        b = QPushButton("▶"); b.setFixedWidth(34); b.clicked.connect(lambda: self.vai(self.k + 1))
        r.addWidget(b)
        lay.addLayout(r)
        self.lbl = QLabel("")
        self.lbl.setWordWrap(True)
        self.lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        lay.addWidget(self.lbl)
        r = QHBoxLayout()
        for testo, fn in (("Street View", AR.link_streetview), ("Google Maps", AR.link_mappa)):
            bb = QPushButton(testo)
            if testo == "Street View":
                bb.setProperty("primario", True)
            bb.clicked.connect(lambda _c=False, f=fn: self._apri(f))
            r.addWidget(bb)
        lay.addLayout(r)
        lay.addWidget(QLabel("<b>Esito</b>"))
        self.gruppo = QButtonGroup(self)
        for n, e in enumerate(VR.ESITI):
            rb = QRadioButton(e)
            rb.setStyleSheet("QRadioButton { color: %s; }" % VR.COLORI[e])
            self.gruppo.addButton(rb, n)
            lay.addWidget(rb)
        self.gruppo.buttonClicked.connect(lambda bt: self._registra(esito=bt.text()))
        lay.addWidget(QLabel("Note"))
        self.nota = QPlainTextEdit()
        self.nota.setMaximumHeight(90)
        self.nota.setPlaceholderText("Spostare lo scavo sull'altro lato della strada, "
                                     "passare in no-dig sotto il canale…")
        self.nota.textChanged.connect(lambda: self._registra(nota=self.nota.toPlainText()))
        lay.addWidget(self.nota)
        self.lbl_riep = QLabel("")
        self.lbl_riep.setWordWrap(True)
        lay.addWidget(self.lbl_riep)
        b = QPushButton("Esporta elenco CSV")
        b.clicked.connect(self.esporta_csv)
        lay.addWidget(b)
        lay.addWidget(_etichetta_avviso())
        lay.addStretch(1)
        try:
            try:
                from . import ftth_stile as _stile
            except ImportError:
                import ftth_stile as _stile
            w.setStyleSheet(_stile.foglio_di_stile())
            _stile.delegati_combo(w)
        except Exception:  # noqa: BLE001
            pass
        self.setWidget(w)
        self._disegna_tutti()
        if self.voci:
            self.vai(0)
        else:
            self.lbl.setText("Nessuna tratta vicino a ferrovie, corsi d'acqua, strade ANAS, provinciali o autostrade.")

    def _canvas(self):
        return self.iface.mapCanvas() if self.iface else None

    def vai(self, k):
        if not self.voci:
            return
        VR = _vr()
        k = max(0, min(int(k), len(self.voci) - 1))
        self.k = k
        if self.cb.currentIndex() != k:
            self.cb.blockSignals(True); self.cb.setCurrentIndex(k); self.cb.blockSignals(False)
        v = self.voci[k]
        c = VR.CATEGORIE[v["categoria"]]
        self.lbl.setText("<b>%s</b> (%d di %d)<br>%s<br>Via: %s · Stato: %s<br>%.6f, %.6f" % (
            c["nome"], k + 1, len(self.voci), VR.descrizione(v), v.get("via") or "-",
            v.get("stato") or "-", v["lat"], v["lon"]))
        e = self.esiti.get(v["chiave"]) or {}
        self.gruppo.button(VR.ESITI.index(e.get("esito", VR.ESITO_INIZIALE))).setChecked(True)
        self.nota.blockSignals(True); self.nota.setPlainText(e.get("nota", "")); self.nota.blockSignals(False)
        self._centra(v)
        self._riepilogo()

    def _centra(self, v):
        canvas = self._canvas()
        if canvas is None:
            return
        p = v["punto"]
        lato = 0.0006 if self.project.crs().isGeographic() else 60.0
        canvas.setExtent(QgsRectangle(p.x() - lato, p.y() - lato, p.x() + lato, p.y() + lato))
        canvas.refresh()
        if self._marker is None:
            self._marker = QgsVertexMarker(canvas)
            self._marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
            self._marker.setIconSize(26); self._marker.setPenWidth(3)
            self._marker.setColor(QColor("#031B52"))
        self._marker.setCenter(p)
        # tratta evidenziata
        if self._banda is None:
            self._banda = QgsRubberBand(canvas, QgsWkbTypes.LineGeometry)
            self._banda.setColor(QColor(255, 124, 2, 200)); self._banda.setWidth(6)
        self._banda.reset(QgsWkbTypes.LineGeometry)
        if self.lyr is not None:
            f = next(self.lyr.getFeatures(QgsFeatureRequest().setFilterFid(int(v["fid"]))), None)
            if f is not None and f.hasGeometry():
                self._banda.setToGeometry(f.geometry(), self.lyr)

    def _disegna_tutti(self):
        canvas = self._canvas()
        if canvas is None:
            return
        VR = _vr()
        for m in self._marker_tutti:
            canvas.scene().removeItem(m)
        self._marker_tutti = []
        for v in self.voci:
            m = QgsVertexMarker(canvas)
            m.setIconType(QgsVertexMarker.ICON_BOX); m.setIconSize(12); m.setPenWidth(3)
            e = (self.esiti.get(v["chiave"]) or {}).get("esito", VR.ESITO_INIZIALE)
            m.setColor(QColor(VR.COLORI[e])); m.setCenter(v["punto"])
            self._marker_tutti.append(m)

    def _apri(self, fn):
        if self.voci:
            v = self.voci[self.k]
            QDesktopServices.openUrl(QUrl(fn(v["lat"], v["lon"])))

    def _registra(self, esito=None, nota=None):
        if not self.voci:
            return
        VR = _vr()
        v = self.voci[self.k]
        e = dict(self.esiti.get(v["chiave"]) or {"esito": VR.ESITO_INIZIALE, "nota": ""})
        if esito is not None:
            e["esito"] = esito
        if nota is not None:
            e["nota"] = nota
        self.esiti[v["chiave"]] = e
        _salva_esiti(self.project, self.esiti)
        if self.k < len(self._marker_tutti):
            self._marker_tutti[self.k].setColor(QColor(VR.COLORI[e["esito"]]))
        self._riepilogo()

    def _riepilogo(self):
        VR = _vr()
        r = VR.riepilogo([v["chiave"] for v in self.voci], self.esiti)
        self.lbl_riep.setText(" · ".join(
            "<span style='color:%s'>%s %d</span>" % (VR.COLORI[e], e, n) for e, n in r.items()))

    def esporta_csv(self):
        VR = _vr()
        base = self.project.homePath() or os.path.expanduser("~")
        p, _f = QFileDialog.getSaveFileName(self, "Esporta verifica interferenze",
                                            os.path.join(base, "verifica_interferenze.csv"),
                                            "CSV (*.csv)")
        if p:
            n = VR.scrivi_csv(p, self.voci, self.esiti)
            self.lbl_riep.setText(self.lbl_riep.text() + "<br>Esportate %d righe in %s" % (n, p))

    def closeEvent(self, ev):
        canvas = self._canvas()
        if canvas is not None:
            for m in self._marker_tutti + ([self._marker] if self._marker else []):
                canvas.scene().removeItem(m)
            if self._banda is not None:
                canvas.scene().removeItem(self._banda)
        self._marker_tutti, self._marker, self._banda = [], None, None
        super().closeEvent(ev)


def _porta_in_primo_piano(dlg, dock):
    """Il pannello sta nella finestra principale di QGIS, che di solito è
    DIETRO la finestra del plugin (finestra separata): si porta davanti QGIS
    con il pannello, altrimenti sembra che il pannello non si apra."""
    try:
        mw = dlg.iface.mainWindow() if dlg.iface is not None else None
        if mw is None:
            return
        if mw.isMinimized():
            mw.showNormal()
        mw.raise_()
        mw.activateWindow()
        dock.raise_()
        dock.activateWindow()
    except Exception:  # noqa: BLE001
        pass


class VerificaReteMixin:
    """Voce Comune › Verifica interferenze."""

    def _tab_verifica_rete(self):
        VR = _vr()
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Trova le tratte di infrastruttura vicine a ferrovie, corsi d'acqua, strade ANAS, provinciali e autostrade "
            "(OpenStreetMap), già nel permesso comunale: lì servirà un'istanza a un altro ente "
            "e spesso conviene spostare il tracciato. Il pannello accanto alla mappa scorre le "
            "tratte, evidenzia quella corrente, apre Street View o Google Maps sul punto più "
            "vicino all'opera e registra l'esito con una nota (salvati nel progetto)."))
        f = QFormLayout()
        self.cb_vr_infra = QgsMapLayerComboBox()
        self.cb_vr_infra.setFilters(QgsMapLayerProxyModel.LineLayer)
        for l in QgsProject.instance().mapLayersByName("03 INFRASTRUTTURE"):
            self.cb_vr_infra.setLayer(l)
            break
        f.addRow("Layer infrastrutture:", self.cb_vr_infra)
        self.chk_vr_nuove = QCheckBox("Solo tratte nuove (STATO = Nuovo)")
        self.chk_vr_nuove.setChecked(True)
        f.addRow(self.chk_vr_nuove)
        self.chk_vr_aerea = QCheckBox("Escludi le tratte senza scavo (TIPOLOGIA Aerea o vuota)")
        self.chk_vr_aerea.setChecked(True)
        f.addRow(self.chk_vr_aerea)
        self.spin_vr = {}
        for k, c in VR.CATEGORIE.items():
            sp = self._dspin(0, 500, c["dist"], 0, " m")
            sp.setToolTip("Tratte entro questa distanza da: %s (istanza %s). 0 = non cercare."
                          % (c["nome"].lower(), c["ente"]))
            self.spin_vr[k] = sp
            f.addRow("Attenzione entro, %s:" % c["nome"].lower(), sp)
        v.addLayout(f)
        r = QHBoxLayout()
        b = QPushButton("Cerca le interferenze e apri il pannello")
        b.setProperty("primario", True)
        b.clicked.connect(self._vr_cerca)
        r.addWidget(b)
        b2 = QPushButton("Apri il pannello (ultima ricerca)")
        b2.setToolTip("Riapre accanto alla mappa di QGIS il pannello con le tratte dell'ultima "
                      "ricerca, senza rifarla.")
        b2.clicked.connect(self._vr_riapri)
        r.addWidget(b2)
        b3 = QPushButton("Fasce di rispetto…")
        b3.setToolTip("Apre Cartografia di base › Fasce di rispetto con le opere trovate "
                      "(ferrovie, corsi d'acqua, strade ANAS, provinciali, autostrade) come shape sorgente.")
        b3.clicked.connect(lambda: self._vr_apri_fasce(None))
        r.addWidget(b3)
        r.addStretch()
        v.addLayout(r)
        self.lbl_vr = QLabel("")
        self.lbl_vr.setWordWrap(True)
        v.addWidget(self.lbl_vr)
        v.addWidget(_etichetta_avviso())
        v.addStretch(1)
        return w

    # ------------------------------------------------------------ ricerca
    def _vr_tratte(self, lyr):
        from shapely import wkt as _wkt
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(lyr.crs(), wgs, QgsProject.instance())
        nomi = {x.name().upper(): x.name() for x in lyr.fields()}
        c_st = nomi.get("STATO"); c_tp = nomi.get("TIPOLOGIA")
        c_via = next((nomi[c] for c in ("VIA", "INDIRIZZO", "TOPONIMO") if c in nomi), None)
        out = []
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            st = str(f[c_st]) if c_st and f[c_st] not in (None, "") else ""
            if self.chk_vr_nuove.isChecked() and st.lower() != "nuovo":
                continue
            tp = str(f[c_tp]) if c_tp and f[c_tp] not in (None, "") else ""
            # senza scavo: posa aerea o TIPOLOGIA vuota (aerea o tubo esistente)
            if self.chk_vr_aerea.isChecked() and (not tp.strip() or
                                                 tp.strip().lower().startswith("aere")):
                continue
            g = QgsGeometry(f.geometry())
            g.transform(tr)
            try:
                sg = _wkt.loads(g.asWkt())
            except Exception:  # noqa: BLE001
                continue
            out.append({"fid": f.id(), "geom": sg, "stato": st,
                        "tipologia": str(f[c_tp]) if c_tp and f[c_tp] not in (None, "") else "",
                        "via": str(f[c_via]) if c_via and f[c_via] not in (None, "") else ""})
        return out

    def _vr_cerca(self):
        from qgis.PyQt.QtWidgets import QProgressDialog
        pd = QProgressDialog("Lettura delle tratte…", None, 0, 100, self)
        pd.setWindowTitle("Verifica interferenze")
        pd.setWindowModality(Qt.WindowModal)
        pd.setMinimumDuration(0)
        pd.setMinimumWidth(440)
        pd.setValue(0)
        QApplication.processEvents()
        try:
            self._vr_cerca_impl(pd)
        finally:
            pd.setValue(100)
            pd.close()

    def _vr_cerca_impl(self, pd):
        import math
        import threading
        import time
        VR = _vr()
        lyr = self.cb_vr_infra.currentLayer()
        if lyr is None:
            self.lbl_vr.setText("Scegli il layer delle infrastrutture.")
            return
        tratte = self._vr_tratte(lyr)
        if not tratte:
            self.lbl_vr.setText("Nessuna tratta da controllare nel layer.")
            return
        try:
            from . import ftth_screening as scr
        except ImportError:
            import ftth_screening as scr
        xs = [t["geom"].bounds for t in tratte]
        m = 0.005
        q = VR.query_overpass(min(b[1] for b in xs) - m, min(b[0] for b in xs) - m,
                              max(b[3] for b in xs) + m, max(b[2] for b in xs) + m)
        self.lbl_vr.setText("Interrogo OpenStreetMap (ferrovie, corsi d'acqua, strade ANAS, provinciali, autostrade)…")
        # la richiesta a OpenStreetMap gira a parte: la barra avanza e la
        # finestra resta viva mentre si aspetta la risposta
        ris = {}

        def _lavoro():
            try:
                ris["r"] = scr._overpass(q)
            except Exception as e:  # noqa: BLE001
                ris["r"] = ([], "", str(e))
        th = threading.Thread(target=_lavoro, daemon=True)
        avvio = time.monotonic()
        budget = float(getattr(scr, "OVERPASS_BUDGET_DEFAULT", 120) or 120)
        th.start()
        while th.is_alive():
            s = time.monotonic() - avvio
            pd.setLabelText("Interrogo OpenStreetMap (ferrovie, corsi d'acqua, strade ANAS, provinciali, autostrade)…\n"
                            "%d tratte da controllare · attesa %d s" % (len(tratte), s))
            # la risposta di solito arriva in 5-30 s (al massimo `budget`):
            # avanzamento rapido all'inizio, poi rallenta senza mai fermarsi
            pd.setValue(int(10 + 70 * min(1.0, max(s / budget, 1 - math.exp(-s / 15.0)))))
            QApplication.processEvents()
            time.sleep(0.1)
        els, _ep, err = ris.get("r", ([], "", "nessuna risposta"))
        if err and not els:
            self.lbl_vr.setText("OpenStreetMap non ha risposto (%s). Riprova tra poco." % err)
            return
        pd.setLabelText("Confronto delle tratte con le opere trovate…")
        pd.setValue(85)
        QApplication.processEvents()
        elementi = VR.elementi_osm(els)
        soglie = {k: sp.value() for k, sp in self.spin_vr.items()}
        voci = VR.analizza(tratte, elementi, soglie)
        pd.setLabelText("Layer delle opere e pannello…")
        pd.setValue(95)
        QApplication.processEvents()
        self._vr_layer_osm(elementi)
        prj = QgsProject.instance()
        salv = [{k: v[k] for k in v if k != "punto"} for v in voci]
        prj.writeEntry(VR.PRJ_SCOPE, "voci", json.dumps(salv, ensure_ascii=False))
        prj.writeEntry(VR.PRJ_SCOPE, "layer", lyr.id())
        r = VR.riepilogo_categorie(voci)
        self.lbl_vr.setText("Tratte da verificare: %d — %s. Opere trovate in zona: %d." % (
            len(voci), ", ".join("%s %d" % (VR.CATEGORIE[k]["nome"].lower(), n)
                                 for k, n in r.items()), len(elementi)))
        self._vr_apri(lyr, voci)
        try:
            self._vr_consiglio_fasce(voci)
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------- fasce di rispetto
    # categoria della verifica -> voce dell'ente nella scheda Fasce
    _VR_ENTE_FASCE = {"ferrovia": "RFI — ferrovia",
                      "acqua": "Acque — fiume / corso d'acqua demaniale",
                      "anas": "ANAS — fuori c.a. (tipo B)",
                      "provinciale": "Provincia/Regione — fuori c.a. (tipo C)",
                      "autostrada": "Autostrada — fuori c.a. (tipo A)"}

    def _vr_consiglio_fasce(self, voci):
        """Dopo una ricerca con tratte da verificare suggerisce le Fasce di
        rispetto (una volta per sessione, con «Non mostrare più»)."""
        from collections import Counter
        from qgis.PyQt.QtCore import QSettings
        from qgis.PyQt.QtWidgets import QMessageBox
        chiave = "FTTH_PERMIT_MANAGER/consiglio_fasce_no"
        if not voci or getattr(self, "_vr_consiglio_visto", False) or \
                QSettings().value(chiave, False, type=bool):
            return
        self._vr_consiglio_visto = True
        VR = _vr()
        cat = Counter(v["categoria"] for v in voci).most_common(1)[0][0]
        mb = QMessageBox(self)
        mb.setIcon(QMessageBox.Information)
        mb.setWindowTitle("Suggerimento: fasce di rispetto")
        mb.setText("Vuoi vedere le fasce di rispetto sulla mappa?")
        mb.setInformativeText(
            "Con <b>Cartografia di base › Fasce di rispetto</b> disegni la fascia attorno alle "
            "opere appena trovate (layer «%s»): ferrovia 30 m, corso d'acqua 10 m, strada "
            "ANAS secondo la classe. Così vedi subito quali tratte ricadono in fascia e "
            "serviranno l'istanza all'ente, e se conviene spostare il tracciato.<br><br>"
            "«Apri Fasce di rispetto» la prepara per <b>%s</b> (la categoria con più tratte): "
            "opere di quel tipo selezionate, ente e distanza impostati."
            % (NOME_LAYER_OSM, VR.CATEGORIE[cat]["nome"].lower()))
        b_apri = mb.addButton("Apri Fasce di rispetto", QMessageBox.AcceptRole)
        mb.addButton("Più tardi", QMessageBox.RejectRole)
        chk = QCheckBox("Non mostrare più")
        mb.setCheckBox(chk)
        mb.exec_()
        if chk.isChecked():
            QSettings().setValue(chiave, True)
        if mb.clickedButton() is b_apri:
            self._vr_apri_fasce(cat)

    def _vr_apri_fasce(self, cat=None):
        """Porta alla scheda Fasce di rispetto con le opere trovate come shape
        sorgente; con `cat` seleziona solo quelle di quella categoria e
        imposta l'ente."""
        VR = _vr()
        try:
            tc = self._tabs_cartografia
            self._tabs_principali.setCurrentWidget(tc)
            for i in range(tc.count()):
                if tc.tabText(i) == "Fasce di rispetto":
                    tc.setCurrentIndex(i)
        except Exception:  # noqa: BLE001
            return
        lyr = next(iter(QgsProject.instance().mapLayersByName(NOME_LAYER_OSM)), None)
        if cat and hasattr(self, "cb_fasce_ente"):
            i = self.cb_fasce_ente.findText(self._VR_ENTE_FASCE.get(cat, ""))
            if i >= 0:
                self.cb_fasce_ente.setCurrentIndex(i)
        if lyr is not None and hasattr(self, "cb_fasce_layer"):
            self.cb_fasce_layer.setLayer(lyr)
            if cat:
                nome = VR.CATEGORIE[cat]["nome"]
                lyr.selectByIds([f.id() for f in lyr.getFeatures() if f["categoria"] == nome])
                if hasattr(self, "chk_fasce_solo_sel"):
                    self.chk_fasce_solo_sel.setChecked(True)

    def _vr_riapri(self):
        VR = _vr()
        prj = QgsProject.instance()
        t, _ok = prj.readEntry(VR.PRJ_SCOPE, "voci", "")
        lid, _ok2 = prj.readEntry(VR.PRJ_SCOPE, "layer", "")
        try:
            voci = json.loads(t or "[]")
        except ValueError:
            voci = []
        if not voci:
            self.lbl_vr.setText("Nessuna ricerca salvata nel progetto: premi «Cerca».")
            return
        self._vr_apri(prj.mapLayer(lid) or self.cb_vr_infra.currentLayer(), voci)

    def _vr_apri(self, lyr, voci):
        vecchio = getattr(self, "_dock_vr", None)
        if vecchio is not None:
            try:
                vecchio.close()
                self.iface.removeDockWidget(vecchio)
            except Exception:  # noqa: BLE001
                pass
        dock = PannelloVerificaRete(self.iface, QgsProject.instance(), lyr, voci,
                                    self.iface.mainWindow() if self.iface else None)
        self._dock_vr = dock
        if self.iface is not None:
            self.iface.addDockWidget(Qt.RightDockWidgetArea, dock)
        dock.show()
        dock.raise_()
        _porta_in_primo_piano(self, dock)
        self.lbl_vr.setText(self.lbl_vr.text() + "<br><b>Pannello aperto a destra della mappa "
                            "di QGIS</b> (la finestra del plugin resta aperta dietro).")

    def _vr_layer_osm(self, elementi):
        """Ferrovie, corsi d'acqua, strade ANAS, provinciali e autostrade trovati: layer temporaneo per
        vederli sulla mappa (sostituito a ogni ricerca)."""
        VR = _vr()
        prj = QgsProject.instance()
        for l in prj.mapLayersByName(NOME_LAYER_OSM):
            prj.removeMapLayer(l.id())
        vl = QgsVectorLayer("LineString?crs=EPSG:4326", NOME_LAYER_OSM, "memory")
        vl.dataProvider().addAttributes([QgsField("categoria", QVariant.String),
                                         QgsField("nome", QVariant.String)])
        vl.updateFields()
        feats = []
        for cat, nome, g in elementi:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromWkt(g.wkt))
            f["categoria"] = VR.CATEGORIE[cat]["nome"]
            f["nome"] = nome
            feats.append(f)
        vl.dataProvider().addFeatures(feats)
        vl.updateExtents()
        cats = [QgsRendererCategory(c["nome"], QgsLineSymbol.createSimple(
            {"line_color": c["colore"], "line_width": "0.8", "line_style": "dash"}), c["nome"])
            for c in VR.CATEGORIE.values()]
        vl.setRenderer(QgsCategorizedSymbolRenderer("categoria", cats))
        prj.addMapLayer(vl)
