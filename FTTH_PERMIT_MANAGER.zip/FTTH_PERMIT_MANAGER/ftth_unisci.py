# -*- coding: utf-8 -*-
"""Motore di 'Unisci tratte': decide cosa fondere e come.

Sta fuori dall'interfaccia apposta: cosi' si puo' provare sui progetti
veri senza aprire QGIS, che e' l'unico modo per sapere se fa la cosa
giusta su 8.000 fusioni invece che su un esempio.

Le regole, nella forma in cui le ha dette chi fa il lavoro:

  - due tratte si fondono solo se hanno la STESSA tipologia di scavo e i
    capi si toccano;
  - un POZZETTO sul punto di contatto blocca la fusione (un armadio no);
  - uno scavo di tipologia DIVERSA che INTERCETTA il punto di contatto
    funge da pozzetto, anche se li' non ci finisce ma ci passa soltanto:
    quelle due tratte non vanno unite;
  - un nodo dove arrivano tre o piu' rami e' una diramazione, non una
    giunzione: non si fonde.

Il punto delicato e' il terzo: il grafo dei nodi va costruito su TUTTE le
tratte, comprese quelle che i filtri escludono dalla fusione. Una tratta
esistente che arriva sul nodo non e' fondibile, ma il ramo c'e' lo
stesso, e ignorarlo significa fondere attraverso una diramazione vera.
Eleggibilita' alla fusione e topologia sono due cose diverse.
"""
import math

try:
    from qgis.core import (QgsGeometry, QgsPointXY, QgsFeature,
                           QgsSpatialIndex, QgsRectangle)
except ImportError:      # permette l'import fuori da QGIS
    QgsGeometry = QgsPointXY = QgsFeature = QgsSpatialIndex = QgsRectangle = None


# --------------------------------------------------------------- nodi --
def _cella(pt, t):
    return (int(math.floor(pt.x() / t)), int(math.floor(pt.y() / t)))


def raggruppa_nodi(tratte, tol):
    """Raggruppa i capi che si toccano, entro 'tol' metri.

    Due trappole, entrambe viste su dati veri:

    - la sola cella di griglia non basta: due capi a un centimetro ai due
      lati di un confine di cella finivano in nodi diversi e non venivano
      mai fusi. Si guardano anche le celle vicine e si conferma con la
      distanza vera;

    - il nodo NON puo' assestarsi su una media mobile mentre lo si
      costruisce. Confrontando ogni nuovo capo con la media gia' spostata,
      tre rami sporchi (0,40 m l'uno dall'altro, tolleranza 0,50) finivano
      in due nodi diversi a seconda dell'ORDINE in cui il provider
      restituisce le feature: il terzo ramo spariva dal conto e la
      diramazione veniva fusa come se fosse una giunzione.

    Qui i capi vicini vengono uniti per chiusura transitiva (union-find):
    se A tocca B e B tocca C, finiscono tutti e tre nello stesso nodo,
    qualunque sia l'ordine di lettura. Il punto del nodo si calcola alla
    fine, a gruppo chiuso, e non influenza il raggruppamento.

    Ritorna: lista di nodi, ognuno {'pt': punto medio, 'capi': [(fid, i)]}
    con i = 0 per il capo iniziale, -1 per quello finale.
    """
    capi = []                      # [(fid, quale_capo, punto)]
    for fid, d in tratte.items():
        for i in (0, -1):
            capi.append((fid, i, d["pts"][i]))

    griglia = {}
    for k, (_fid, _i, pt) in enumerate(capi):
        griglia.setdefault(_cella(pt, tol), []).append(k)

    padre = list(range(len(capi)))
    def trova(x):
        while padre[x] != x:
            padre[x] = padre[padre[x]]
            x = padre[x]
        return x
    def unisci(a, b):
        ra, rb = trova(a), trova(b)
        if ra != rb:
            padre[rb] = ra

    t2 = tol * tol
    for k, (_fid, _i, pt) in enumerate(capi):
        cx, cy = _cella(pt, tol)
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for h in griglia.get((cx + dx, cy + dy), ()):
                    if h <= k:
                        continue
                    q = capi[h][2]
                    if (q.x() - pt.x()) ** 2 + (q.y() - pt.y()) ** 2 <= t2:
                        unisci(k, h)

    gruppi = {}
    for k in range(len(capi)):
        gruppi.setdefault(trova(k), []).append(k)

    nodi = []
    for membri in gruppi.values():
        sx = sum(capi[k][2].x() for k in membri) / float(len(membri))
        sy = sum(capi[k][2].y() for k in membri) / float(len(membri))
        nodi.append({"pt": QgsPointXY(sx, sy),
                     "capi": [(capi[k][0], capi[k][1]) for k in membri]})
    return nodi


# ---------------------------------------------------------- pozzetti --
class Pozzetti(object):
    """Pozzetti indicizzati a celle: dice se un punto ne ha uno addosso."""

    def __init__(self, punti, raggio):
        self.raggio = raggio
        self.celle = {}
        for p in punti:
            self.celle.setdefault(_cella(p, raggio), []).append(p)

    def __len__(self):
        return sum(len(v) for v in self.celle.values())

    def addosso(self, pt):
        if not self.celle:
            return False
        cx, cy = _cella(pt, self.raggio)
        r2 = self.raggio ** 2
        for dx in (-1, 0, 1):
            for dy in (-1, 0, 1):
                for p in self.celle.get((cx + dx, cy + dy), ()):
                    if (p.x() - pt.x()) ** 2 + (p.y() - pt.y()) ** 2 <= r2:
                        return True
        return False


# ------------------------------------------------------- attraversanti --
def _indice(tratte):
    idx = QgsSpatialIndex()
    for fid, d in tratte.items():
        f = QgsFeature(fid)
        f.setGeometry(d["geom"])
        idx.addFeature(f)
    return idx


def attraversa(tratte, idx, nodo, tol):
    """fid dello scavo che PASSA per il nodo senza terminarci, se c'e'.

    E' la regola dello 'scavo che fa da pozzetto': una tratta che
    attraversa il punto di contatto lo trasforma in un nodo di rete. Si
    guardano TUTTE le tratte, anche quelle escluse dai filtri, perche' il
    ramo esiste a prescindere da cosa si sta fondendo.
    """
    pt = nodo["pt"]
    presenti = set(fid for fid, _ in nodo["capi"])
    pg = QgsGeometry.fromPointXY(pt)
    r = QgsRectangle(pt.x() - tol, pt.y() - tol, pt.x() + tol, pt.y() + tol)
    for fid in idx.intersects(r):
        if fid in presenti:
            continue
        d = tratte[fid]
        if d["geom"].distance(pg) > tol:
            continue
        c0, c1 = d["pts"][0], d["pts"][-1]
        dist_capo = min(math.hypot(pt.x() - c0.x(), pt.y() - c0.y()),
                        math.hypot(pt.x() - c1.x(), pt.y() - c1.y()))
        if dist_capo > tol:          # non ci termina: ci passa
            return fid
    return None


# ------------------------------------------------------------ analisi --
def analizza(tratte, poz_punti, tol, tol_poz, usa_stato=True):
    """Decide quali giunzioni sono fondibili. Non modifica niente.

    'tratte' deve contenere TUTTE le tratte lette dal layer; quelle non
    fondibili vanno marcate con eleggibile=False, non omesse.

    Ritorna (giunzioni, motivi) dove giunzioni e' una lista di archi
    (a, ia, b, ib, punto_nodo) e motivi conta perche' gli altri nodi sono
    stati lasciati stare.
    """
    poz = Pozzetti(poz_punti, tol_poz)
    nodi = raggruppa_nodi(tratte, tol)
    idx = _indice(tratte)

    giunzioni = []
    motivi = {"capo_libero": 0, "diramazione": 0, "pozzetto": 0,
              "attraversato": 0, "tipologia": 0, "stato": 0,
              "non_eleggibile": 0, "anello": 0}
    esempi = {"attraversato": [], "diramazione": [], "pozzetto": []}

    for nodo in nodi:
        capi = nodo["capi"]
        if len(capi) == 1:
            motivi["capo_libero"] += 1
            continue
        if len(capi) > 2:
            motivi["diramazione"] += 1
            if len(esempi["diramazione"]) < 5:
                esempi["diramazione"].append((nodo["pt"], [f for f, _ in capi]))
            continue
        (a, ia), (b, ib) = capi
        if a == b:
            motivi["anello"] += 1
            continue
        if not (tratte[a].get("eleggibile", True) and tratte[b].get("eleggibile", True)):
            motivi["non_eleggibile"] += 1
            continue
        if poz.addosso(nodo["pt"]):
            motivi["pozzetto"] += 1
            if len(esempi["pozzetto"]) < 5:
                esempi["pozzetto"].append((nodo["pt"], [a, b]))
            continue
        fid_x = attraversa(tratte, idx, nodo, tol)
        if fid_x is not None:
            motivi["attraversato"] += 1
            if len(esempi["attraversato"]) < 5:
                esempi["attraversato"].append((nodo["pt"], [a, b, fid_x]))
            continue
        if tratte[a]["tip"] != tratte[b]["tip"]:
            motivi["tipologia"] += 1
            continue
        if usa_stato and tratte[a]["stato"] != tratte[b]["stato"]:
            motivi["stato"] += 1
            continue
        giunzioni.append((a, ia, b, ib, nodo["pt"]))
    return giunzioni, motivi, esempi


# ------------------------------------------------------------ catene --
def gruppi_da_giunzioni(tratte, giunzioni):
    """Componenti connesse: ogni gruppo e' una catena da fondere."""
    padre = {}
    def trova(x):
        padre.setdefault(x, x)
        while padre[x] != x:
            padre[x] = padre[padre[x]]
            x = padre[x]
        return x
    for a, ia, b, ib, pt in giunzioni:
        ra, rb = trova(a), trova(b)
        if ra != rb:
            padre[rb] = ra
    gruppi = {}
    for fid in padre:
        gruppi.setdefault(trova(fid), []).append(fid)
    return [v for v in gruppi.values() if len(v) > 1]


def ordina_catena(membri, giunzioni):
    """Mette in fila le tratte di una catena, col verso giusto.

    Ritorna [(fid, invertita)] oppure None se il gruppo non e' una catena
    semplice (anello, o diramazione sfuggita ai controlli). In quel caso
    e' piu' onesto non fondere che improvvisare.
    """
    ms = set(membri)
    adiac = {}
    for a, ia, b, ib, pt in giunzioni:
        if a in ms and b in ms:
            adiac.setdefault(a, []).append((b, ia, ib))
            adiac.setdefault(b, []).append((a, ib, ia))
    if any(len(v) > 2 for v in adiac.values()):
        return None                      # diramazione
    estremi = [f for f in membri if len(adiac.get(f, [])) == 1]
    if len(estremi) != 2:
        return None                      # anello o pezzi staccati
    partenza = min(estremi)              # deterministico: stesso esito ogni volta
    ordine = []
    visti = set()
    prec = None
    corrente = partenza
    while True:
        if corrente in visti:
            return None                  # ci si rigira dentro: non e' una catena
        visti.add(corrente)
        avanti = [v for v in adiac.get(corrente, []) if v[0] != prec]
        if avanti:
            # la tratta deve FINIRE sul capo che la lega alla successiva:
            # se quel capo e' il suo iniziale, va percorsa al contrario
            succ, mio_capo, _suo = avanti[0]
            ordine.append((corrente, mio_capo == 0))
            prec, corrente = corrente, succ
        else:
            # ultima della fila: deve COMINCIARE dal capo che la lega alla
            # precedente, quindi si inverte se quel capo e' il suo finale
            legame = [v for v in adiac.get(corrente, []) if v[0] == prec]
            mio_capo = legame[0][1] if legame else -1
            ordine.append((corrente, mio_capo == -1))
            break
    if len(ordine) != len(membri):
        return None                      # pezzi staccati nel gruppo
    return ordine


def punti_catena(tratte, ordine, tol):
    """Lista di punti della tratta fusa, cucendo i capi che si toccano.

    I capi vengono cuciti davvero (si tiene un solo punto per giunto):
    la versione precedente si affidava a unaryUnion+mergeLines, che
    ricuce solo se le coordinate coincidono ESATTAMENTE. Con uno scarto
    di un centimetro il risultato restava spezzato in due parti, e le
    tratte membro venivano cancellate lo stesso.
    """
    fusi = []
    for fid, invertita in ordine:
        pts = list(tratte[fid]["pts"])
        if invertita:
            pts.reverse()
        if not fusi:
            fusi.extend(pts)
            continue
        ultimo = fusi[-1]
        primo = pts[0]
        if math.hypot(ultimo.x() - primo.x(), ultimo.y() - primo.y()) <= tol:
            # giunto: un punto solo, a meta' strada fra i due capi
            fusi[-1] = QgsPointXY((ultimo.x() + primo.x()) / 2.0,
                                  (ultimo.y() + primo.y()) / 2.0)
            fusi.extend(pts[1:])
        else:
            return None                  # non si toccano: non fondere
    return fusi
