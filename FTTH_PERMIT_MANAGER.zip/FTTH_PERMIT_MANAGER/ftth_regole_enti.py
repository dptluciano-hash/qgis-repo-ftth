# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Regole di un ente stradale (direttive del territorio) per le istanze Strade.

Un profilo dice, per le strade di un ente, cosa chiede l'ente in più rispetto
all'istanza art. 49 standard: procedura (nulla osta o autorizzazione), scale
delle planimetrie, profondità minima, foto, modulo dell'ente, piano di
cantiere, sopralluogo per i grandi scavi. Primo profilo: Città Metropolitana
di Genova (strade provinciali). Per un nuovo ente basta un altro profilo in
PROFILI.
"""
import os

PROFILI = [{
    "id": "cm_genova",
    "nome": "Città Metropolitana di Genova",
    "classi": ("SP",),
    "province": ("GE",),
    "parole_ente": ("genova",),
    # dentro i centri abitati sotto 10.000 abitanti la Città Metropolitana
    # rilascia il nulla osta e lo trasmette al Comune, che autorizza
    "nulla_osta_dentro_ca": True,
    "scala_inquadramento": 5000,
    "scala_tavole": 200,
    "scale_tavole_ammesse": (100, 200),
    "scala_sezioni": "1:10 o 1:20",
    "profondita_min_m": 1.0,
    # tecniche che non arrivano a 1 m dal piano viabile all'estradosso
    "tecniche_poco_profonde": ("minitrincea", "microtrincea"),
    "foto": "panoramiche e di dettaglio",
    "modulo": "Modulorottura-occupazionesuolopubblico",
    "modulo_dentro_ca": "Modulorottura-occupazionesuolopubblico1",
    "piano_cantiere": True,
    "grandi_scavi_m": 500.0,
    "contatto_sopralluogo": "l'indirizzo e-mail indicato nei contatti della Città Metropolitana",
    "allegati": [
        "Modulo di istanza della Città Metropolitana di Genova debitamente compilato",
        "Planimetria dell'area interessata in scala 1:5.000 con evidenziato il luogo "
        "dell'intervento",
        "Planimetria quotata in scala 1:200",
        "Sezioni di scavo in scala 1:20 (profondità minima dal piano viabile "
        "all'estradosso del manufatto non inferiore a 1 m)",
        "Piano di cantiere con le superfici di occupazione di suolo pubblico (a tratte "
        "lavorate, schemi del C.d.S.) e relativa durata",
    ],
}]

# larghezza dell'occupazione del cantiere per tecnica (m): scavo + spazio di
# lavoro e delimitazione. Stime, modificabili nel piano generato.
LARGHEZZA_CANTIERE_M = {"trincea": 2.5, "minitrincea": 1.5, "microtrincea": 1.2,
                        "nodig": 3.0, "canaletta": 1.5}
# lunghezza massima di una tratta lavorata (cantiere mobile)
TRATTA_LAVORATA_M = 100.0
SCHEMA_CDS = ("D.M. 10/07/2002 – Tav. 64 (lavori sulla banchina/margine) o Tav. 66 "
              "(strettoia con senso unico alternato): da scegliere per ogni tratta")


def _sigla(v):
    return (v or "").strip().upper()


def profilo_per(strada, prov_sigla="") -> dict:
    """Profilo dell'ente della strada, o None. Non vale per i tratti passati
    al Comune (centri abitati oltre 10.000 abitanti)."""
    if strada is None:
        return None
    ente = (getattr(strada, "ente_nome", "") or "").lower()
    if ente.startswith("comune"):
        return None
    for p in PROFILI:
        if getattr(strada, "classe", "") not in p["classi"]:
            continue
        if _sigla(prov_sigla) in p.get("province", ()) or any(
                w and w in ente for w in p.get("parole_ente", ())):
            return p
    return None


def procedura(profilo, ist) -> str:
    """'nulla_osta' (dentro centro abitato sotto 10.000 ab.) o 'autorizzazione'."""
    if profilo and profilo.get("nulla_osta_dentro_ca") and getattr(ist, "centro", "") == "dentro":
        return "nulla_osta"
    return "autorizzazione"


def _scavi(ist):
    for i in ist.interferenze:
        for e in i.elementi:
            if e.get("tipo") == "scavo":
                yield i, e


def metri_scavo(ist) -> float:
    tot = 0.0
    for _i, e in _scavi(ist):
        try:
            tot += float(e.get("metri") or 0)
        except (TypeError, ValueError):
            pass
    return tot


def controlli(profilo, ist) -> list:
    """Avvisi per l'istanza secondo le regole dell'ente."""
    if not profilo:
        return []
    out = []
    poco = {}
    for _i, e in _scavi(ist):
        t = e.get("tecnica")
        if t in profilo.get("tecniche_poco_profonde", ()):
            try:
                poco[t] = poco.get(t, 0.0) + float(e.get("metri") or 0)
            except (TypeError, ValueError):
                pass
    if poco:
        out.append("%s chiede una profondità minima di %g m dal piano viabile all'estradosso: "
                   "%s non ci arriva%s. Usa scavo tradizionale o no-dig, o concordalo con "
                   "l'ente." % (profilo["nome"], profilo["profondita_min_m"],
                                " e ".join("%s (%d m)" % (t, round(m)) for t, m in poco.items()),
                                "no" if len(poco) > 1 else ""))
    soglia = profilo.get("grandi_scavi_m")
    m = metri_scavo(ist)
    if soglia and m >= soglia:
        out.append("Grande scavo (%d m, soglia %d m): prima di presentare il progetto %s chiede "
                   "un sopralluogo preventivo, da richiedere al%s."
                   % (round(m), round(soglia), profilo["nome"],
                      " " + profilo.get("contatto_sopralluogo", "") if
                      profilo.get("contatto_sopralluogo") else "l'ente"))
    return out


def scala_tavole(profilo, scelta=None) -> int:
    """Scala delle tavole: quella scelta se ammessa dall'ente, altrimenti
    quella del profilo (automatica = profilo)."""
    if not profilo:
        return int(scelta) if scelta else None
    if scelta and int(scelta) in profilo.get("scale_tavole_ammesse", ()):
        return int(scelta)
    return profilo["scala_tavole"]


# ------------------------------------------------------- piano di cantiere
def righe_piano_cantiere(ist, rese=None) -> list:
    """Una riga per tratta lavorata (al massimo TRATTA_LAVORATA_M): progressiva,
    tecnica, lunghezza, larghezza, superficie occupata, giorni."""
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    r = rfi.rese_complete(rese)
    righe = []
    for i, e in _scavi(ist):
        try:
            m = float(e.get("metri") or 0)
        except (TypeError, ValueError):
            m = 0.0
        if m <= 0:
            continue
        t = e.get("tecnica") or "trincea"
        larg = LARGHEZZA_CANTIERE_M.get(t, 2.0)
        n = max(1, int(-(-m // TRATTA_LAVORATA_M)))
        pezzo = m / n
        km = ""
        if e.get("km_da"):
            km = ("km %s" % e["km_da"]) if not e.get("km_a") or e["km_a"] == e["km_da"] else \
                "dal km %s al km %s" % (e["km_da"], e["km_a"])
        for k in range(n):
            giorni = rfi.arrotonda_mezzo_sup(pezzo / r.get(t, 50.0))
            righe.append({"n": len(righe) + 1, "interferenza": getattr(i, "id", ""),
                          "progressiva": km or "vedi planimetria",
                          "fase": "%d di %d" % (k + 1, n) if n > 1 else "",
                          "tecnica": t, "lunghezza": pezzo, "larghezza": larg,
                          "superficie": pezzo * larg, "giorni": giorni})
    return righe


def scrivi_piano_cantiere(percorso, ist, comune, profilo, rese=None) -> str:
    """Piano di cantiere (Word): tabella delle tratte lavorate con superfici
    di occupazione e durata. Ritorna il percorso, o '' se non ci sono scavi."""
    from docx import Document
    from docx.shared import Pt
    righe = righe_piano_cantiere(ist, rese)
    if not righe:
        return ""
    s = getattr(ist, "strada", None)
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Arial"
    st.font.size = Pt(10)
    doc.add_heading("PIANO DI CANTIERE", level=1)
    strada = (s.nome_documenti() if s else ist.corso)
    try:
        from . import ftth_strade as S
    except ImportError:
        import ftth_strade as S
    doc.add_paragraph("Comune di %s – %s%s" % (getattr(comune, "nome", comune), strada,
                                                S.specifica_centro(ist)))
    doc.add_paragraph("Ente: %s. Occupazione temporanea di suolo pubblico per tratte "
                      "lavorate (cantiere mobile, al massimo %d m per tratta): ogni tratta si "
                      "apre, si scava, si posa, si richiude e si ripristina prima di aprire la "
                      "successiva." % (profilo["nome"] if profilo else
                                       (s.ente_nome if s else ""), TRATTA_LAVORATA_M))
    tab = doc.add_table(rows=1, cols=8)
    tab.style = "Table Grid"
    for c, h in zip(tab.rows[0].cells, ("N.", "Interf.", "Progressiva", "Tecnica",
                                         "Lungh. (m)", "Largh. (m)", "Superficie (m²)",
                                         "Durata (gg)")):
        c.text = h
        for p in c.paragraphs:
            for run in p.runs:
                run.bold = True
    f = lambda v: ("%.1f" % v).replace(".", ",")  # noqa: E731
    for r in righe:
        c = tab.add_row().cells
        prog = r["progressiva"] + ((" (tratta %s)" % r["fase"]) if r["fase"] else "")
        for cell, v in zip(c, (str(r["n"]), str(r["interferenza"]), prog, r["tecnica"],
                               f(r["lunghezza"]), f(r["larghezza"]), f(r["superficie"]),
                               f(r["giorni"]))):
            cell.text = v
    sup = sum(r["superficie"] for r in righe)
    gg = sum(r["giorni"] for r in righe)
    c = tab.add_row().cells
    c[0].text = "Totale"
    c[6].text = f(sup)
    c[7].text = f(gg)
    doc.add_paragraph("")
    doc.add_paragraph("Superficie massima occupata contemporaneamente: %s m² (la tratta più "
                      "grande). Durata complessiva stimata: %s giorni lavorativi, salvo "
                      "imprevisti." % (f(max(r["superficie"] for r in righe)), f(gg)))
    doc.add_paragraph("Segnaletica di cantiere: %s." % SCHEMA_CDS)
    doc.add_paragraph("Larghezze e durate sono stime per tecnica di scavo: verificarle con "
                      "l'impresa esecutrice.")
    os.makedirs(os.path.dirname(percorso), exist_ok=True)
    doc.save(percorso)
    return percorso


# ------------------------------------------------ testo dell'istanza art. 49
def _sostituisci(par, vecchio, nuovo) -> bool:
    if vecchio not in par.text:
        return False
    for run in par.runs:
        if vecchio in run.text:
            run.text = run.text.replace(vecchio, nuovo)
            return True
    testo = par.text.replace(vecchio, nuovo)
    for k, run in enumerate(par.runs):
        run.text = testo if k == 0 else ""
    return True


def adatta_istanza(doc, profilo, ist, comune_nome="") -> None:
    """Istanza art. 49 secondo le regole dell'ente: nulla osta dentro i centri
    abitati (da trasmettere al Comune) e allegati chiesti dall'ente."""
    import copy
    if not profilo:
        return
    if procedura(profilo, ist) == "nulla_osta":
        for p in doc.paragraphs:
            _sostituisci(p, "Istanza di autorizzazione per", "Istanza di nulla osta per")
            _sostituisci(p, "il rilascio dell’autorizzazione per l’intervento di seguito "
                            "descritto:",
                         "il rilascio del nulla osta, da trasmettere al Comune di %s competente "
                         "al rilascio dell’autorizzazione (e per conoscenza alla scrivente), per "
                         "l’intervento di seguito descritto:" % (comune_nome or "XXXXX"))
    if profilo.get("foto"):
        for p in doc.paragraphs:
            if p.text.strip() == "Documentazione fotografica dei luoghi":
                _sostituisci(p, "dei luoghi", "dei luoghi (%s)" % profilo["foto"])
    # allegati dell'ente dopo «Grafici illustrativi» (relazione e foto ci sono già)
    rif = next((p for p in doc.paragraphs if p.text.strip() == "Grafici illustrativi"), None)
    if rif is None:
        return
    dopo = rif
    for testo in profilo.get("allegati", []):
        if testo.lower().startswith(("relazione tecnica", "documentazione fotografica")):
            continue
        nuovo = copy.deepcopy(rif._p)
        dopo._p.addnext(nuovo)
        from docx.text.paragraph import Paragraph
        par = Paragraph(nuovo, rif._parent)
        for k, run in enumerate(par.runs):
            run.text = testo if k == 0 else ""
        dopo = par


def modulo_ente(profilo, cartelle, ist=None) -> str:
    """Il modulo dell'ente (docx) nella prima cartella che lo contiene. Con
    «modulo_dentro_ca» l'istanza di nulla osta usa quel modulo (Genova:
    …pubblico1.docx dentro i centri abitati, …pubblico.docx fuori)."""
    if not profilo or not profilo.get("modulo"):
        return ""
    nomi = []
    if ist is not None and procedura(profilo, ist) == "nulla_osta" and \
            profilo.get("modulo_dentro_ca"):
        nomi.append((profilo["modulo_dentro_ca"].lower(), True))
    nomi.append((profilo["modulo"].lower(), False))
    for chiave, esatto in nomi:
        for c in cartelle:
            if not c or not os.path.isdir(c):
                continue
            for n in sorted(os.listdir(c)):
                b, est = os.path.splitext(n.lower())
                if est != ".docx" or n.startswith("~$"):
                    continue
                if (b == chiave) if esatto else b.startswith(chiave):
                    return os.path.join(c, n)
    return ""


# ------------------------------------- regole lette da un file dell'utente
import json  # noqa: E402
import re  # noqa: E402

CAMPI_PROFILO = ("id", "nome", "classi", "province", "parole_ente", "nulla_osta_dentro_ca",
                 "scala_inquadramento", "scala_tavole", "scale_tavole_ammesse",
                 "scala_sezioni", "profondita_min_m", "tecniche_poco_profonde", "foto",
                 "modulo", "modulo_dentro_ca", "piano_cantiere", "grandi_scavi_m", "contatto_sopralluogo",
                 "allegati")
_PROFILI_BASE = list(PROFILI)


def testo_da_file(percorso) -> str:
    """Testo di un file di regole: .txt/.md, .docx o .pdf."""
    est = os.path.splitext(percorso)[1].lower()
    if est == ".docx":
        from docx import Document
        d = Document(percorso)
        righe = [p.text for p in d.paragraphs]
        for t in d.tables:
            for r in t.rows:
                righe.append(" ".join(c.text for c in r.cells))
        return "\n".join(righe)
    if est == ".pdf":
        try:
            import fitz  # PyMuPDF
            with fitz.open(percorso) as doc:
                return "\n".join(p.get_text() for p in doc)
        except ImportError:
            pass
        try:
            from pypdf import PdfReader
        except ImportError:
            from PyPDF2 import PdfReader
        return "\n".join(p.extract_text() or "" for p in PdfReader(percorso).pages)
    for enc in ("utf-8", "cp1252", "latin-1"):
        try:
            with open(percorso, encoding=enc) as fh:
                return fh.read()
        except UnicodeDecodeError:
            continue
    return ""


def _scale_in(testo):
    # «1:5000», «1.5000» (refuso frequente), «1:5.000»; non «1.0» o «1,5»
    out = []
    for m in re.finditer(r"\b1\s*[:.]\s*(\d{1,2}\.\d{3}|\d{2,5})\b", testo):
        try:
            v = int(m.group(1).replace(".", ""))
        except ValueError:
            continue
        if 10 <= v <= 100000:
            out.append(v)
    return out


def _frase(testo, parola):
    """Le righe del testo che contengono `parola` (minuscole)."""
    return [r for r in testo.splitlines() if parola in r.lower()]


def estrai_regole(testo: str) -> dict:
    """Profilo dedotto dal testo delle direttive di un ente (da far
    confermare all'utente). Solo le voci riconosciute; `trovate` le elenca."""
    t = testo or ""
    low = t.lower()
    p = {"trovate": []}
    m = re.search(r"(Citt[àa] Metropolitana di [A-Z][\w' ]+?|Provincia (?:di|del|della) "
                  r"[A-Z][\w' ]+?|Regione [A-Z][\w' ]+?)(?:[\s,.;:)]|$)", t)
    if m:
        nome = " ".join(m.group(1).split())
        p["nome"] = nome
        p["parole_ente"] = [nome.split()[-1].lower()]
        p["trovate"].append("ente: %s" % nome)
    classi = []
    if "provincial" in low:
        classi.append("SP")
    if "regional" in low:
        classi.append("SR")
    if "statal" in low:
        classi.append("SS")
    if classi:
        p["classi"] = classi
        p["trovate"].append("strade: %s" % ", ".join(classi))
    if "nulla osta" in low and "centr" in low and "10.000" in t:
        p["nulla_osta_dentro_ca"] = True
        p["trovate"].append("nulla osta nei centri abitati sotto 10.000 abitanti")
    for r in _frase(t, "planimetria"):
        sc = _scale_in(r)
        if not sc:
            continue
        if "quotat" in r.lower() or "dettagli" in r.lower():
            p["scale_tavole_ammesse"] = sorted(set(sc))
            p["scala_tavole"] = max(sc)
            p["trovate"].append("planimetria quotata: %s" % " o ".join("1:%d" % s for s in sc))
        elif "scala_inquadramento" not in p:
            p["scala_inquadramento"] = max(sc)
            p["trovate"].append("planimetria dell'area: 1:%d" % max(sc))
    for r in _frase(t, "sezion"):
        sc = _scale_in(r)
        if sc:
            p["scala_sezioni"] = " o ".join("1:%d" % s for s in sorted(set(sc)))
            p["trovate"].append("sezioni: %s" % p["scala_sezioni"])
            break
    m = re.search(r"profondit[àa]\s+minim\w*[^.;\n]*?(?:\bm\.?\s*(\d+(?:[.,]\d+)?)|"
                  r"(\d+(?:[.,]\d+)?)\s*(?:m\b|metr|cm\b))", low)
    if m:
        v = float((m.group(1) or m.group(2)).replace(",", "."))
        if "cm" in m.group(0)[-4:]:
            v /= 100.0
        p["profondita_min_m"] = v
        p["tecniche_poco_profonde"] = ["minitrincea", "microtrincea"] if v >= 0.6 else []
        p["trovate"].append("profondità minima: %g m" % v)
    if "fotografic" in low:
        p["foto"] = "panoramiche e di dettaglio" if "panoramic" in low else "dei luoghi"
        p["trovate"].append("foto %s" % p["foto"])
    if "piano di cantiere" in low or "cronoprogramma" in low:
        p["piano_cantiere"] = True
        p["trovate"].append("piano di cantiere")
    if "sopralluogo" in low:
        m = re.search(r"(\d+(?:\.\d{3})?)\s*(?:m\b|metri)[^.\n]*scav|scav[^.\n]*?"
                      r"(\d+(?:\.\d{3})?)\s*(?:m\b|metri)", low)
        p["grandi_scavi_m"] = float((m.group(1) or m.group(2)).replace(".", "")) if m else 500.0
        p["contatto_sopralluogo"] = "l'indirizzo indicato nei contatti dell'ente"
        p["trovate"].append("sopralluogo preventivo per i grandi scavi (soglia %d m%s)"
                            % (p["grandi_scavi_m"], "" if m else ", da confermare"))
    m = re.search(r"([\w\-]*modul[\w\-]*)\.docx", low)
    if m:
        p["modulo"] = m.group(1)
        p["trovate"].append("modulo dell'ente: %s.docx" % m.group(1))
    elif "modulo" in low:
        p["trovate"].append("modulo dell'ente citato (allegalo con «Modulo dell'ente»)")
    # allegati: righe dopo «costituita da:» / «allegare» fino a NOTA o riga vuota
    m = re.search(r"(?:costituit[ao] da|allegare[^:\n]*):\s*\n(.+?)(?:\n\s*\n|\nNOTA|\Z)",
                  t, re.S | re.I)
    if m:
        al = [" ".join(r.strip(" -•;\t").split()) for r in m.group(1).splitlines()]
        al = [a[0].upper() + a[1:] for a in al if len(a) > 3 and not a.lower().startswith("nota")]
        if al:
            p["allegati"] = al
            p["trovate"].append("%d allegati" % len(al))
    return p


def completa(p: dict) -> dict:
    """Profilo completo: i valori mancanti sono quelli dell'istanza standard."""
    out = {"id": "", "nome": "", "classi": ["SP"], "province": [], "parole_ente": [],
           "nulla_osta_dentro_ca": False, "scala_inquadramento": 2000,
           "scala_tavole": 500, "scale_tavole_ammesse": [], "scala_sezioni": "",
           "profondita_min_m": 0.0, "tecniche_poco_profonde": [], "foto": "",
           "modulo": "", "modulo_dentro_ca": "", "piano_cantiere": False, "grandi_scavi_m": 0.0,
           "contatto_sopralluogo": "", "allegati": []}
    out.update({k: v for k, v in (p or {}).items() if k in CAMPI_PROFILO})
    if not out["id"]:
        out["id"] = re.sub(r"\W+", "_", (out["nome"] or "ente").lower()).strip("_")
    for k in ("classi", "province", "parole_ente", "scale_tavole_ammesse",
              "tecniche_poco_profonde", "allegati"):
        out[k] = tuple(out[k] or ())
    return out


def cartella_utente() -> str:
    try:
        from qgis.core import QgsApplication
        base = QgsApplication.qgisSettingsDirPath()
    except Exception:  # noqa: BLE001
        base = os.path.expanduser("~")
    return os.path.join(base, "FTTH_regole_enti")


def salva_profilo(p: dict, cartella=None) -> str:
    p = completa(p)
    cartella = cartella or cartella_utente()
    os.makedirs(cartella, exist_ok=True)
    percorso = os.path.join(cartella, p["id"] + ".json")
    with open(percorso, "w", encoding="utf-8") as fh:
        json.dump({k: list(v) if isinstance(v, tuple) else v for k, v in p.items()}, fh,
                  ensure_ascii=False, indent=2)
    ricarica(cartella)
    return percorso


def ricarica(cartella=None) -> list:
    """PROFILI = profili del plugin + quelli salvati dall'utente (un profilo
    dell'utente con lo stesso id sostituisce quello del plugin)."""
    cartella = cartella or cartella_utente()
    utente = {}
    if os.path.isdir(cartella):
        for n in sorted(os.listdir(cartella)):
            if n.lower().endswith(".json"):
                try:
                    with open(os.path.join(cartella, n), encoding="utf-8") as fh:
                        q = completa(json.load(fh))
                    utente[q["id"]] = q
                except Exception:  # noqa: BLE001
                    continue
    PROFILI[:] = [utente.pop(b["id"], b) for b in _PROFILI_BASE] + list(utente.values())
    return PROFILI


def promemoria(profilo, ist) -> list:
    """Righe per il LEGGIMI dell'istanza."""
    if not profilo:
        return []
    righe = ["", "REGOLE %s" % profilo["nome"].upper(),
             "Procedura: %s." % (("NULLA OSTA (tratto dentro centro abitato sotto 10.000 "
                                  "abitanti): %s lo trasmette al Comune, che rilascia "
                                  "l'autorizzazione" % profilo["nome"])
                                 if procedura(profilo, ist) == "nulla_osta"
                                 else "AUTORIZZAZIONE rilasciata dall'ente"),
             "Documentazione chiesta dall'ente:"]
    righe += ["  - %s" % a for a in profilo.get("allegati", [])]
    if profilo.get("foto"):
        righe.append("  - Documentazione fotografica %s" % profilo["foto"])
    righe.append("  - Relazione tecnica illustrativa")
    righe += ["ATTENZIONE: " + a for a in controlli(profilo, ist)]
    return righe
