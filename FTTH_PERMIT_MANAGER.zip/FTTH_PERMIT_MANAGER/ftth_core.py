# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Logica pura del plugin FTTH Permessi Manager.

Questo modulo NON importa niente da qgis/PyQt: contiene le funzioni di puro
calcolo (parsing, formattazione, geometria elementare su numeri) estratte dal
dialogo, così da poterle eseguire e testare con un normale interprete Python,
senza QGIS installato (vedi tests/test_core.py).

Regola di manutenzione: se una funzione ha bisogno di un oggetto QGIS o di un
widget, NON va qui — va nel dialogo. Qui entrano solo funzioni che ricevono
valori semplici (stringhe, numeri, tuple, oggetti con .x()/.y()) e ritornano
valori semplici.
"""
import math
import re


class UnionFind:
    """Union-find con compressione di cammino: raggruppa elementi collegati
    (usato per ricucire in corridoi le tratte di uno stradario spezzettato)."""

    def __init__(self, ids):
        self._p = {i: i for i in ids}

    def find(self, i):
        while self._p[i] != i:
            self._p[i] = self._p[self._p[i]]; i = self._p[i]
        return i

    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb: self._p[rb] = ra

    def groups(self):
        out = {}
        for i in self._p:
            out.setdefault(self.find(i), []).append(i)
        return out


def fit_similarity(coppie):
    """Miglior trasformazione di similitudine (traslazione + rotazione
    + scala uniforme, NESSUNA deformazione locale) che porta i punti
    sorgente sui punti di riferimento, ai minimi quadrati. Ogni punto è
    trattato come numero complesso (x+iy): la trasformazione è
    z' = a*z + b, dove |a| è la scala e arg(a) la rotazione. Con 2
    coppie la soluzione è esatta; con più coppie minimizza lo scarto
    complessivo (coppie imprecise si compensano a vicenda). Ritorna
    (a, b, residuo_rms_metri) o None se le coppie sono meno di 2 o
    tutte coincidenti (nessuna informazione di scala/rotazione).

    `coppie` è una lista di (sorgente, riferimento); ogni punto è un
    qualunque oggetto con metodi .x() e .y() (QgsPointXY va bene, ma il
    modulo non lo richiede)."""
    if len(coppie) < 2: return None
    s = [complex(p.x(), p.y()) for p, _ in coppie]
    t = [complex(p.x(), p.y()) for _, p in coppie]
    n = len(s)
    ms = sum(s) / n; mt = sum(t) / n
    num = sum((ti - mt) * (si - ms).conjugate() for si, ti in zip(s, t))
    den = sum(abs(si - ms) ** 2 for si in s)
    if den == 0: return None
    a = num / den
    b = mt - a * ms
    residui = [abs(ti - (a * si + b)) for si, ti in zip(s, t)]
    rms = (sum(r * r for r in residui) / n) ** 0.5
    return a, b, rms


# prefisso descrittivo tollerato davanti al valore di un cippo
# ("KM 17+100", "PK 17+100", "progr. 17+100", ...)
PREFISSI_KM = r"^(k\.?m\.?t?|p\.?k\.?|progr(\.|essiva)?|cippo|prog)\s*[:=]?\s*"


def parse_chilometrica(testo, formato="km_m"):
    """Valore del cippo → metri. Ritorna None se il testo non è
    interpretabile.

    Tollera il prefisso descrittivo con cui i cippi vengono normalmente
    etichettati ('KM 17+100', 'PK 17+100', 'progr. 17+100'): senza questa
    pulizia 'KM 17+100' finiva in float('KM17') e il cippo veniva scartato
    in silenzio, quindi il calcolo non partiva affatto.

    `formato` sceglie come leggere le due parti attorno al '+': 'km_m' è lo
    standard (17+100 = km 17 e 100 m), 'invertito' serve quando il valore è
    stato digitato al rovescio (100+17 significa km 17+100), 'metri' e
    'km_dec' per i valori senza '+'."""
    if testo is None:
        return None
    t = str(testo).strip().lower().replace(" ", "")
    t = re.sub(PREFISSI_KM, "", t)
    t = t.lstrip("+:=.")
    if not t:
        return None

    if "+" in t:
        sinistra, destra = t.split("+", 1)
        try:
            a = float(sinistra.replace(",", "."))
            b = float(destra.replace(",", "."))
        except ValueError:
            return None
        if formato == "invertito":
            a, b = b, a
        return a * 1000 + b

    try:
        valore = float(t.replace(",", "."))
    except ValueError:
        return None
    if formato == "metri":
        return valore
    if formato == "km_dec":
        return valore * 1000
    # senza '+' e senza formato esplicito: valori piccoli sono km decimali
    # (es. "17,1"), non metri — un pozzetto non sta al metro 17 di una SP
    return valore * 1000 if valore < 1000 else valore


def format_chilometrica(metri):
    """Metri → testo 'km+mmm' (es. 17600 → '17+600')."""
    segno = "-" if metri < 0 else ""
    assoluto = abs(metri)
    km = int(assoluto // 1000)
    m = assoluto - km * 1000
    return f"{segno}{km}+{m:03.0f}"


def unisci_intervalli(intervalli, vuoto_max):
    """Fonde gli intervalli separati da meno di `vuoto_max`.

    È il punto che dà continuità al retino: senza questo passaggio ogni
    elemento produce la sua fascetta e fra due scavi consecutivi, o dove il
    progetto si scosta dall'asse oltre la tolleranza, restano buchi."""
    if not intervalli:
        return []
    ordinati = sorted(intervalli)
    uniti = [list(ordinati[0])]
    for da, a in ordinati[1:]:
        if da - uniti[-1][1] <= vuoto_max:
            uniti[-1][1] = max(uniti[-1][1], a)
        else:
            uniti.append([da, a])
    return [tuple(x) for x in uniti]


def formatta_numero(valore, decimali):
    """Numero con la virgola decimale italiana, come si scrive sulle tavole.

    Arrotonda per eccesso a metà (8,5 → 9): la formattazione nativa di
    Python arrotonda al pari più vicino e darebbe 8, che su una misura
    stampata in tavola sembra un errore."""
    fattore = 10 ** decimali
    arrotondato = math.floor(abs(valore) * fattore + 0.5) / fattore
    if valore < 0:
        arrotondato = -arrotondato
    return f"{arrotondato:.{decimali}f}".replace(".", ",")


def nome_da_chiave(chiave):
    """Il nome della strada dalla chiave del corridoio, che può essere
    'SR56' oppure 'SR56 – tronco 2' quando la strada si spezza."""
    testo = str(chiave)
    pezzo = testo.split(" – tronco ")[0].strip()
    return "" if pezzo in ("tutte le tratte", "None", "") else pezzo
