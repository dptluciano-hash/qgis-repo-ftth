# -*- coding: utf-8 -*-
"""Planimetria 1.1 PL delle istanze strade nel formato delle pratiche consegnate
(ANAS SS71, Provincia SP306), A1 orizzontale:

- pagina 1 INQUADRAMENTO GENERALE: ortofoto (sopra) e cartografia (sotto) con i
  riquadri TAV. n delle tavole; a destra particolari costruttivi, legenda e
  cartiglio (strada, «ISTANZA DI AUTORIZZAZIONE SCAVI E POSA POZZETTI»,
  committente, progettista, KEYPLAN);
- una pagina per tavola, scala 1:500: planimetria grande con le etichette
  «KM ... SCAVO ...», sotto le sezioni (layer Sezioni) e le foto (punti di
  ripresa); a destra particolari, legenda e cartiglio «TAV. k / N».

Riusa i mattoni di ftth_rfi_layout e ftth_acque_layout (etichette senza
sovrapposizioni, rete sull'ortofoto, foto, sezioni, particolari).
"""
import datetime
import os

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsFillSymbol, QgsGeometry, QgsLayoutExporter, QgsLayoutItemLegend, QgsLayoutItemPage,
    QgsLayoutSize, QgsLegendStyle, QgsPalLayerSettings, QgsPointXY, QgsPrintLayout,
    QgsRectangle, QgsSingleSymbolRenderer, QgsVectorLayer, QgsVectorLayerSimpleLabeling,
)

try:
    from . import ftth_rfi_layout as L
    from . import ftth_acque_layout as AL
    from . import ftth_acque as A
except ImportError:
    import ftth_rfi_layout as L
    import ftth_acque_layout as AL
    import ftth_acque as A

MM = L.MM
PAGINA_A1 = (841.0, 594.0)
MARG = 10.0
COL_W = 205.0                    # colonna destra: particolari, legenda, cartiglio
GAP = 6.0
TIT = 7.0
SCALA_TAVOLE = 500
ROSSO_TAV = QColor(220, 40, 40)


def _riquadri_layer(project, pref, riquadri, tr_inv, numeri=None):
    """Riquadri TAV. n dell'inquadramento generale (rosso trasparente con il
    nome), come nelle pratiche consegnate."""
    vl = AL._mem(project, "Polygon", "%s - riquadri tavole" % pref, [("tav", QVariant.String)],
                 "Tavole")
    feats = []
    for k, r in zip(numeri or range(1, len(riquadri) + 1), riquadri):
        g = QgsGeometry.fromRect(r)
        g.transform(tr_inv)
        f = QgsFeature(vl.fields())
        f.setGeometry(g)
        f["tav"] = "TAV. %d" % k
        feats.append(f)
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    vl.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
        {"color": "230,60,60,45", "outline_color": "220,40,40,255", "outline_width": "0.5"})))
    pal = QgsPalLayerSettings()
    pal.fieldName = "tav"
    try:
        pal.placement = QgsPalLayerSettings.OverPoint
    except Exception:  # noqa: BLE001
        pass
    tf = AL._formato(24, ROSSO_TAV, True, False, 1.2)
    f_ = tf.font()
    f_.setFamily(SERIF)
    tf.setFont(f_)
    pal.setFormat(tf)
    pal.displayAll = True
    vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    vl.setLabelsEnabled(True)
    vl.setCustomProperty("rfi/nome_legenda", "Tavole")
    return L._aggiungi_base(project, vl)


SERIF = "Times New Roman"


def _t(layout, pag, x, y, w, h, testo, size, bold=False, align=Qt.AlignHCenter, frame=False,
       colore=None):
    """Testo con il carattere a grazie delle PL strade consegnate."""
    it = L._lbl(layout, pag, x, y, w, h, testo, size, bold, align, frame=frame, colore=colore)
    f = QFont(SERIF)
    f.setPointSizeF(float(size))
    f.setBold(bold)
    it.setFont(f)
    return it


COLORE_FASCIA = QColor(0, 112, 192)


def _png_simbolo(sym, path, px_mm=16.0, w=260, h=130):
    """Disegna un simbolo marker del progetto (stile vero del layer) in PNG."""
    from qgis.PyQt.QtCore import QPointF
    from qgis.PyQt.QtGui import QImage, QPainter
    from qgis.core import QgsRenderContext
    img = QImage(w, h, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.Antialiasing)
    ctx = QgsRenderContext.fromQPainter(p)
    ctx.setScaleFactor(px_mm)
    s = sym.clone()
    s.startRender(ctx)
    s.renderPoint(QPointF(w / 2.0, h / 2.0), None, ctx)
    s.stopRender(ctx)
    p.end()
    img.save(path)
    return path


def _png_fascia(path, w=260, h=130):
    from qgis.PyQt.QtGui import QImage, QPainter, QPen
    img = QImage(w, h, QImage.Format_ARGB32)
    img.fill(Qt.transparent)
    p = QPainter(img)
    pen = QPen(COLORE_FASCIA, 7)
    pen.setStyle(Qt.DashLine)
    p.setPen(pen)
    p.drawRect(20, 25, w - 40, h - 50)
    p.end()
    img.save(path)
    return path


def simboli_legenda(project, cartella, fascia=False):
    """Voci a destra della legenda prese dagli stili VERI dei layer 02_POZZETTO
    e 01_ARMADIO OTTICO (tutti alla stessa scala, come in mappa), piu' la
    fascia di rispetto tratteggiata se c'e'. [(png, testo)]."""
    os.makedirs(cartella, exist_ok=True)
    out = []
    for nome, armadio in (("02_POZZETTO", False), ("01_ARMADIO OTTICO", True)):
        lyr = L._trova(project, nome)
        if lyr is None or lyr.renderer() is None:
            continue
        for n, it in enumerate(lyr.renderer().legendSymbolItems()):
            sym = it.symbol()
            if sym is None:
                continue
            lab = (it.label() or "").strip()
            if armadio:
                testo = "ARMADIO OTTICO NUOVA POSA"
            elif lab.lower().startswith("esist"):
                testo = "POZZETTO FIBERCOP ESISTENTE"
            else:
                testo = "POZZETTO FIBERCOP %s NUOVA POSA" % lab.lower()
            png = os.path.join(cartella, "legenda_%s_%d.png" % ("arm" if armadio else "pozz", n))
            try:
                out.append((_png_simbolo(sym, png), testo))
            except Exception:  # noqa: BLE001
                pass
    if fascia:
        out.append((_png_fascia(os.path.join(cartella, "legenda_fascia.png")),
                    "FASCIA DI RISPETTO STRADALE"))
    return out


def _legenda(layout, pag, x, y, w, h, simboli=None):
    """Legenda delle PL strade consegnate (stessa in tutte le pagine): a
    sinistra confini, tecniche di scavo, canaletta, punto di ripresa e sezioni
    (immagine degli esempi); a destra pozzetti, armadio (e fascia) disegnati
    con lo stile dei layer del progetto, tutti leggibili."""
    _t(layout, pag, x, y, w, 10, "LEGENDA", 20)
    img = os.path.join(L.ASSETS, "legenda_strade.png")
    if not simboli:
        if os.path.isfile(img):
            L._immagine(layout, pag, x + 2, y + 11, w - 4, h - 12, img)
        return
    sx = os.path.join(os.path.dirname(simboli[0][0]), "legenda_sx.png")
    if os.path.isfile(img) and not os.path.isfile(sx):
        from qgis.PyQt.QtGui import QImage
        q = QImage(img)
        q.copy(0, 0, int(q.width() * 0.525), q.height()).save(sx)
    w_sx = w * 0.52
    if os.path.isfile(sx):
        L._immagine(layout, pag, x + 2, y + 11, w_sx - 4, h - 12, sx)
    xr = x + w_sx
    hr = (h - 12) / max(len(simboli), 7)
    for n, (png, testo) in enumerate(simboli):
        yr = y + 11 + n * hr
        L._immagine(layout, pag, xr, yr + 0.5, 16, hr - 1, png)
        _t(layout, pag, xr + 18, yr, w - w_sx - 18, hr, testo, 8, False, Qt.AlignLeft)


def _particolari(layout, pag, x, y, w, h, disponibili, titolo):
    _t(layout, pag, x, y, w, 8, titolo, 13, True)
    L._box(layout, pag, x, y + 9, w, h - 9, 0.2, QColor(160, 160, 160))
    if not disponibili:
        L._lbl(layout, pag, x, y + 9, w, h - 9, "Particolari non disponibili", 8,
               colore=QColor(150, 150, 150))
        return
    # i particolari riempiono il riquadro (scala la piu' grande possibile)
    _s, pagine = L.impagina_particolari(disponibili, w - 8, h - 16, gap=2.5, scala_max=8.0,
                                        scala_min=0.2)
    pezzi = pagine[0] if pagine else []
    for _k, f, px, py, pw, ph in pezzi:
        L._immagine(layout, pag, x + 4 + px, y + 12 + py, pw, ph, f)


def _cartiglio_a1(layout, pag, x, y, w, h, dati, nome_pagina, sigla_pagina):
    """Cartiglio come nelle PL strade consegnate (caratteri a grazie): strada,
    «ISTANZA DI AUTORIZZAZIONE SCAVI E POSA POZZETTI», nome della pagina,
    committente, progettista, sigla pagina + file / data / Formato A1."""
    unita = h / 10.0
    righe = [(unita * 1.8, dati["strada"], 26 if "\n" not in dati["strada"] else 15, True),
             (unita * 1.9, "ISTANZA DI AUTORIZZAZIONE\nSCAVI E POSA POZZETTI", 19, True),
             (unita * 1.4, nome_pagina, 19, False)]
    yy = y
    for hh, testo, size, bold in righe:
        _t(layout, pag, x, yy, w, hh, testo, size, bold, frame=True)
        yy += hh
    logo_fc = L.logo_fibercop()    # classico o «Milano Cortina 2026»
    logo_be = os.path.join(L.ASSETS, "beexact_logo.svg")
    if not os.path.isfile(logo_be):
        logo_be = os.path.join(L.ASSETS, "beexact_logo_nuovo.png")
    h_logo = unita * 1.9
    for titolo, logo in (("COMMITTENTE", logo_fc), ("PROGETTISTA", logo_be)):
        L._box(layout, pag, x, yy, w, h_logo, 0.25)
        _t(layout, pag, x, yy + 2, w, 10, titolo, 19)
        if os.path.isfile(logo):
            L._immagine(layout, pag, x + w * 0.2, yy + 13, w * 0.6, h_logo - 16, logo)
        yy += h_logo
    resto = y + h - yy
    _t(layout, pag, x, yy, w * 0.6, resto, sigla_pagina, 26, False, frame=True)
    _t(layout, pag, x + w * 0.6, yy, w * 0.4, resto, "%s\n%s\nFormato A1" % (
        dati["nome_file"], dati["data"]), 10, False, Qt.AlignRight, frame=True)


def _colonna_destra(layout, pag, dati, mappa, legenda_layers, disponibili, nome_pagina,
                    sigla_pagina, titolo_part="PARTICOLARI COSTRUTTIVI", simboli=None):
    pw, ph = PAGINA_A1
    x = pw - MARG - COL_W
    L._box(layout, pag, x, MARG, COL_W, ph - 2 * MARG, 0.4)
    xi, wi = x + 3, COL_W - 6
    h_tot = ph - 2 * MARG - 6
    h_part = h_tot * 0.34
    h_leg = h_tot * 0.15
    y = MARG + 3
    _particolari(layout, pag, xi, y, wi, h_part, disponibili, titolo_part)
    y += h_part + 3
    _legenda(layout, pag, xi, y, wi, h_leg, simboli)
    y += h_leg + 3
    _cartiglio_a1(layout, pag, xi, y, wi, MARG + 3 + h_tot - y, dati, nome_pagina,
                  sigla_pagina)


def grafica_etichette():
    """(dimensione, riquadro) delle etichette «KM … SCAVO …», scelti nella
    scheda Istanze Strade (stessi in mappa e in stampa)."""
    try:
        from qgis.core import QgsSettings
        s = QgsSettings()
        dim = float(s.value("ftth_permessi/etich_dim", 7) or 7)
        riq = str(s.value("ftth_permessi/etich_riquadro", "true")).lower() == "true"
        return dim, riq
    except Exception:  # noqa: BLE001
        return 7.0, True


def _stile_etichette(et_l):
    """Etichette come nelle PL strade consegnate: testo nero normale in un
    riquadro bianco col bordo grigio, richiamo sottile grigio scuro."""
    try:
        from qgis.core import QgsLineSymbol, QgsTextBackgroundSettings
        from qgis.PyQt.QtCore import QSizeF
        pal = et_l.labeling().settings()
        dim, riq = grafica_etichette()
        tf = AL._formato(dim, QColor(0, 0, 0), False, False, 0)
        bg = QgsTextBackgroundSettings()
        bg.setEnabled(riq)
        bg.setFillColor(QColor(255, 255, 255, 250))
        bg.setStrokeColor(QColor(110, 110, 110))
        bg.setStrokeWidth(0.2)
        bg.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
        bg.setSize(QSizeF(1.0, 0.5))
        tf.setBackground(bg)
        pal.setFormat(tf)
        c = pal.callout()
        if c is not None:
            c.setLineSymbol(QgsLineSymbol.createSimple({"line_color": "60,60,60,255",
                                                        "line_width": "0.15"}))
        try:
            pal.multilineAlign = QgsPalLayerSettings.MultiCenter
        except Exception:  # noqa: BLE001
            pass
        et_l.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    except Exception:  # noqa: BLE001
        pass


def particolari_libreria(cartelle):
    """Tutti i particolari disponibili (inquadramento generale: «sono generali
    e tutti»): [(chiave, file, w, h)]."""
    visti, out = set(), []
    for c in cartelle:
        if not c or not os.path.isdir(c):
            continue
        for f in sorted(os.listdir(c)):
            nome, ext = os.path.splitext(f)
            if ext.lower() not in (".svg", ".png", ".jpg") or nome.lower() in visti:
                continue
            visti.add(nome.lower())
            p = os.path.join(c, f)
            w_, h_ = L.dimensioni_svg(p) if ext.lower() == ".svg" else (60.0, 40.0)
            out.append((nome, p, w_, h_))
    return out


def _layer_strada(project, pref, strada, ritaglio):
    """Strada evidenziata nell'inquadramento generale (linea arancione larga,
    come nella PL SP306 consegnata)."""
    from qgis.core import QgsLineSymbol
    vl = AL._mem(project, "LineString", "%s - strada" % pref, [("ref", QVariant.String)],
                 strada.nome_documenti())
    g = strada.geom.intersection(ritaglio) if ritaglio is not None else strada.geom
    feats = []
    for parte in getattr(g, "geoms", [g]):
        if parte.geom_type != "LineString" or parte.is_empty:
            continue
        f = QgsFeature(vl.fields())
        f.setGeometry(QgsGeometry.fromWkt(parte.wkt))
        f["ref"] = strada.ref
        feats.append(f)
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    vl.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
        {"line_color": "255,170,0,230", "line_width": "2.2", "capstyle": "round"})))
    vl.setCustomProperty("rfi/gruppo_legenda", "strada")
    vl.setCustomProperty("rfi/nome_legenda", strada.nome_documenti())
    return L._aggiungi_base(project, vl)


def _layer_fascia_anas(project, pref, strada, ritaglio):
    """Fascia di rispetto per le PL ANAS: solo il bordo tratteggiato, senza
    riempimento (le tabelle della relazione separano gia' sede e fascia)."""
    from qgis.core import QgsSimpleLineSymbolLayer
    try:
        from . import ftth_strade as _S
    except ImportError:
        import ftth_strade as _S
    z = _S.zone_strada(strada)
    g = z[1]["geom"]
    try:
        from shapely.ops import unary_union
        g = unary_union([z[0]["geom"], z[1]["geom"]])
        if ritaglio is not None:
            g = g.intersection(ritaglio)
    except Exception:  # noqa: BLE001
        pass
    # solo il bordo ESTERNO (niente linea al limite della sede, niente anelli
    # interni a rotatorie e incroci) e con linee morbide: si lavora in metri,
    # si chiudono le rientranze piccole e si arrotonda
    from qgis.core import QgsLineSymbol
    qg = QgsGeometry.fromWkt(g.wkt)
    try:
        # disegno: asse semplificato (niente zig-zag dei pezzi OSM), buffer
        # con giunti tondi, rientranze chiuse, solo gli anelli esterni
        from shapely.geometry import LineString, MultiLineString, Polygon
        from shapely.ops import unary_union
        try:
            from . import ftth_rfi as _R
        except ImportError:
            import ftth_rfi as _R
        pr = _R._Proiezione(strada.geom.centroid.x, strada.geom.centroid.y)
        asse = pr.avanti(strada.geom).simplify(4.0)
        d = strada.semi_sede_m + strada.fascia_m
        area = asse.buffer(d, resolution=24, join_style=1, cap_style=1)
        area = area.buffer(15.0, resolution=24).buffer(-15.0, resolution=24)
        parti = list(getattr(area, "geoms", [area]))
        bordi = [LineString(p.exterior.coords) for p in parti if isinstance(p, Polygon)]
        linee = pr.indietro(MultiLineString(bordi).simplify(0.8))
        if ritaglio is not None:
            linee = linee.intersection(ritaglio)
        qg = QgsGeometry.fromWkt(linee.wkt).smooth(2, 0.25)
        if qg is None or qg.isEmpty():
            raise ValueError("vuota")
    except Exception:  # noqa: BLE001
        qg = QgsGeometry.fromWkt(g.boundary.wkt)
    vl = AL._mem(project, "MultiLineString", "%s - fascia" % pref, [("m", QVariant.Double)],
                 "Fascia di rispetto %s (%g m, DPR 495/1992)" % (strada.nome_documenti(),
                                                                 strada.fascia_m))
    f = QgsFeature(vl.fields())
    f.setGeometry(qg)
    f["m"] = strada.fascia_m
    vl.dataProvider().addFeatures([f])
    vl.updateExtents()
    sym = QgsLineSymbol.createSimple({"line_style": "no"})
    bordo = QgsSimpleLineSymbolLayer(COLORE_FASCIA, 0.5)
    bordo.setPenStyle(Qt.DashLine)
    bordo.setPenJoinStyle(Qt.RoundJoin)
    try:
        from qgis.core import QgsUnitTypes
        bordo.setUseCustomDashPattern(True)
        bordo.setCustomDashVector([3.0, 2.0])
        bordo.setCustomDashPatternUnit(QgsUnitTypes.RenderMillimeters)
    except Exception:  # noqa: BLE001
        pass
    sym.appendSymbolLayer(bordo)
    vl.setRenderer(QgsSingleSymbolRenderer(sym))
    vl.setCustomProperty("rfi/gruppo_legenda", "strada")
    vl.setCustomProperty("rfi/nome_legenda", "Fascia di rispetto %s (%g m)"
                         % (strada.nome_documenti(), strada.fascia_m))
    return L._aggiungi_base(project, vl)


def tavole_lungo_strada(punti, w_m, h_m):
    """Copertura col minor numero di tavole: punti = [(pos, x, y, idx)] in
    metri (pos = progressiva lungo la strada). Si scorre la strada e si chiude
    la tavola quando il punto successivo non ci sta piu'. Ritorna
    [(cx, cy, set(idx))] (centro sull'ingombro dei punti della tavola)."""
    # 1) scansione lungo la strada
    gruppi, box_g, cur, b = [], [], [], None
    for _pos, x, y, k in sorted(punti, key=lambda p: p[0]):
        if b is not None:
            u = (min(b[0], x), min(b[1], y), max(b[2], x), max(b[3], y))
            if (u[2] - u[0]) <= w_m and (u[3] - u[1]) <= h_m:
                b = u
                cur.append(k)
                continue
            gruppi.append(cur)
            box_g.append(b)
        b, cur = (x, y, x, y), [k]
    if b is not None:
        gruppi.append(cur)
        box_g.append(b)
    # 2) si uniscono le tavole che stanno insieme in un riquadro (scavi
    # laterali o tratti che tornano indietro spezzavano la sequenza)
    while True:
        migliore = None
        for a in range(len(gruppi)):
            for c in range(a + 1, len(gruppi)):
                u = (min(box_g[a][0], box_g[c][0]), min(box_g[a][1], box_g[c][1]),
                     max(box_g[a][2], box_g[c][2]), max(box_g[a][3], box_g[c][3]))
                if (u[2] - u[0]) > w_m or (u[3] - u[1]) > h_m:
                    continue
                area = (u[2] - u[0]) * (u[3] - u[1])
                if migliore is None or area < migliore[0]:
                    migliore = (area, a, c, u)
        if migliore is None:
            break
        _ar, a, c, u = migliore
        gruppi[a] += gruppi[c]
        box_g[a] = u
        del gruppi[c], box_g[c]
    # 3) numerazione lungo la strada (TAV. 1 all'inizio, poi in fila)
    pos_idx = {}
    for pos, _x, _y, k in punti:
        pos_idx[k] = min(pos, pos_idx.get(k, pos))
    out = [((bx[0] + bx[2]) / 2.0, (bx[1] + bx[3]) / 2.0, set(g))
           for g, bx in zip(gruppi, box_g)]
    out.sort(key=lambda t: sum(pos_idx[k] for k in t[2]) / len(t[2]))
    return out


def _punti_rete(project, interf, tr, asse_m=None, passo=8.0):
    """Punti (metri) di scavi, pozzetti e armadi di ogni interferenza: le
    tratte vere di 03 INFRASTRUTTURE densificate (ritagliate vicino alla
    strada) piu' gli elementi. [(pos, x, y, indice interferenza)]."""
    infra = L._trova(project, "03 INFRASTRUTTURE")
    tr_l = None
    if infra is not None:
        tr_l = QgsCoordinateTransform(infra.crs(), tr.destinationCrs(), project)
    vicino = None
    if asse_m is not None:
        try:
            vicino = QgsGeometry.fromWkt(asse_m.buffer(60.0).wkt)   # asse_m: shapely
        except Exception:  # noqa: BLE001
            vicino = None
    # progressiva lungo l'asse anche se la strada e' in piu' pezzi: pezzi in
    # fila lungo la direzione principale, lunghezze cumulate
    parti, offs = [], []
    if asse_m is not None:
        parti = list(getattr(asse_m, "geoms", [asse_m]))
        xs_ = [c[0] for p in parti for c in p.coords]
        ys_ = [c[1] for p in parti for c in p.coords]
        lungo_x = (max(xs_) - min(xs_)) >= (max(ys_) - min(ys_))
        parti.sort(key=lambda p: p.centroid.x if lungo_x else -p.centroid.y)
        tot = 0.0
        for p in parti:
            offs.append(tot)
            tot += p.length

    def _pos(x, y):
        if not parti:
            return 0.0
        q = _sh_point(x, y)
        n = min(range(len(parti)), key=lambda j: parti[j].distance(q))
        return offs[n] + parti[n].project(q)

    out = []
    for k, i in enumerate(interf):
        pts = [tr.transform(QgsPointXY(i.lon, i.lat))]
        pts += [tr.transform(QgsPointXY(e["lon"], e["lat"])) for e in i.elementi
                if e.get("lon") is not None and e.get("lat") is not None]
        if infra is not None:
            for fid in i.tratte_fid:
                try:
                    g = QgsGeometry(infra.getFeature(int(fid)).geometry())
                except Exception:  # noqa: BLE001
                    continue
                if g is None or g.isEmpty():
                    continue
                g.transform(tr_l)
                if vicino is not None:
                    g = g.intersection(vicino)
                    if g.isEmpty():
                        continue
                g = g.densifyByDistance(passo)
                pts += [QgsPointXY(v.x(), v.y()) for v in g.vertices()]
        for p in pts:
            out.append((_pos(p.x(), p.y()), p.x(), p.y(), k))
    return out


def _ritaglia_layer(project, lyr, rettangoli, crs_m):
    """Tiene nel layer in memoria solo cio' che cade nei riquadri (metri,
    crs_m): le linee tagliate sul bordo, i punti fuori tolti."""
    if lyr is None or not rettangoli:
        return lyr
    area = QgsGeometry.unaryUnion([QgsGeometry.fromRect(r) for r in rettangoli])
    area.transform(QgsCoordinateTransform(crs_m, lyr.crs(), project))
    pr = lyr.dataProvider()
    togli, cambia = [], {}
    for f in lyr.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty() or not g.intersects(area):
            togli.append(f.id())
        elif g.type() != 0:   # linee: tagliate sul bordo
            cambia[f.id()] = g.intersection(area)
    if togli:
        pr.deleteFeatures(togli)
    if cambia:
        pr.changeGeometryValues(cambia)
    lyr.updateExtents()
    return lyr


def _sh_point(x, y):
    from shapely.geometry import Point
    return Point(x, y)


def _gruppi_inquadramento(riquadri, w_m, h_m):
    """Riquadri delle tavole raggruppati in pagine di inquadramento a 1:2000
    (come la PL SS71: piu' pagine se le tavole non stanno in una)."""
    gruppi = [[k] for k in range(len(riquadri))]
    box = [(r.xMinimum(), r.yMinimum(), r.xMaximum(), r.yMaximum()) for r in riquadri]

    def unione(a, b):
        return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))
    while True:
        migliore = None
        for a in range(len(gruppi)):
            for b in range(a + 1, len(gruppi)):
                u = unione(box[a], box[b])
                if (u[2] - u[0]) > w_m or (u[3] - u[1]) > h_m:
                    continue
                area = (u[2] - u[0]) * (u[3] - u[1])
                if migliore is None or area < migliore[0]:
                    migliore = (area, a, b, u)
        if migliore is None:
            break
        _ar, a, b, u = migliore
        gruppi[a] += gruppi[b]
        box[a] = u
        del gruppi[b], box[b]
    for g in gruppi:
        g.sort()
    gruppi.sort(key=lambda g: g[0])
    return gruppi


# riquadri SEZIONE della tavola A1 (2x2, come le tavole consegnate)
SEZIONI_PER_TAVOLA = 4


def genera_pl_strade(project, ist, comune, out_pdf, strada, aree=None, orto_id=None, log=None,
                     cartella_foto=None, cartella_sezioni=None, cartella_utente=None,
                     esporta=True, fascia=False):
    """Layout 'STRADE PL - <istanza>' A1 e PDF, come le PL strade consegnate:
    nelle tavole niente sede ne' fascia evidenziate (solo, con fascia=True, il
    bordo tratteggiato della fascia di rispetto, per ANAS). Ritorna True se il
    PDF e' scritto."""
    if not ist.interferenze:
        return False
    avvisa = log or (lambda _t: None)
    home = project.homePath() or os.path.dirname(project.fileName() or "")
    cart_sez = [cartella_sezioni, os.path.join(home, "05_Sezioni") if home else None,
                cartella_utente, os.path.join(L.ASSETS, "rfi_sezioni")]
    cart_foto = [cartella_foto, os.path.join(home, "04_Foto") if home else None, cartella_utente]
    cart_part = [cartella_utente, os.path.join(L.ASSETS, "rfi_particolari")]

    # foto e sezioni di questa istanza: prima la sua sottocartella (04_Foto/SP28,
    # 05_Sezioni/<linea>…), poi la cartella; i punti di altre istanze no
    nomi_ist = L.nomi_istanza(ist)
    cart_sez = L.cartelle_istanza(cart_sez, nomi_ist)
    cart_foto = L.cartelle_istanza(cart_foto, nomi_ist)
    pw, ph = PAGINA_A1
    area_w = pw - 2 * MARG - COL_W - GAP
    area_h = ph - 2 * MARG

    # tavole a 1:500: la planimetria occupa ~70% dell'altezza
    h_pl = (area_h - TIT) * 0.70
    h_basso = area_h - TIT - h_pl - GAP - TIT
    frame_m = (area_w * SCALA_TAVOLE / 1000.0 - 30, h_pl * SCALA_TAVOLE / 1000.0 - 24)
    lon0 = sum(i.lon for i in ist.interferenze) / len(ist.interferenze)
    crs = L._crs_metrico(project, lon0)
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    tr = QgsCoordinateTransform(wgs, crs, project)
    tr_inv = QgsCoordinateTransform(crs, wgs, project)
    pref = "STRADE tavole %s" % ist.nome_base

    # tavole: si scorre la strada coprendo scavi, pozzetti e armadi veri col
    # minor numero di riquadri (margine per le etichette)
    centri_tav = None
    try:
        asse_m = None
        if strada is not None and getattr(strada, "geom", None) is not None:
            from shapely import wkt as _wkt
            from shapely.ops import linemerge
            g = QgsGeometry.fromWkt(strada.geom.wkt)
            g.transform(tr)
            asse_m = _wkt.loads(g.asWkt())
            if asse_m.geom_type == "MultiLineString":
                asse_m = linemerge(asse_m)
        punti = _punti_rete(project, ist.interferenze, tr, asse_m)
        cop = tavole_lungo_strada(punti, frame_m[0], frame_m[1])
        if os.environ.get("FTTH_DEBUG_TAVOLE"):
            avvisa("tavole lungo la strada (debug): %d punti, %d interferenze, %d tavole, "
                   "asse %s" % (len(punti), len(ist.interferenze), len(cop),
                                getattr(asse_m, "geom_type", None)))
        tavole, visti = [], set()
        for _cx, _cy, idx in cop:
            tavole.append([ist.interferenze[k] for k in sorted(idx)])
        for n, t in enumerate(tavole, 1):
            for i in t:
                if id(i) not in visti:
                    i.tavola = n
                    visti.add(id(i))
        ordine = []
        for t in tavole:
            for i in t:
                if i not in ordine:
                    ordine.append(i)
        ist.tavole = tavole
        ist.interferenze = ordine
        centri_tav = [QgsPointXY(cx, cy) for cx, cy, _i in cop]
    except Exception as ex:  # noqa: BLE001
        avvisa("tavole lungo la strada non calcolate (%s): uso il raggruppamento per zona" % ex)
        ist.tavole = A.tavole_per_zona(ist.interferenze, frame_m)
        ist.interferenze = [i for t in ist.tavole for i in t]

    from shapely.geometry import box as _box
    xs, ys = [i.lon for i in ist.interferenze], [i.lat for i in ist.interferenze]
    ritaglio = _box(min(xs) - 0.02, min(ys) - 0.015, max(xs) + 0.02, max(ys) + 0.015)
    strada_l = _layer_strada(project, pref, strada, ritaglio) if strada is not None else None
    fascia_l = _layer_fascia_anas(project, pref, strada, ritaglio) \
        if (fascia and strada is not None) else None
    num_l, et_l = AL._layer_interferenze(project, pref, ist)
    _stile_etichette(et_l)

    infra = L._trova(project, "03 INFRASTRUTTURE")
    pozz = L._trova(project, "02_POZZETTO")
    arm = L._trova(project, "01_ARMADIO OTTICO")
    originali = (infra, pozz, arm)
    fid_tratte = {f for i in ist.interferenze for f in i.tratte_fid}
    fid_pozz = {e.get("fid") for i in ist.interferenze for e in i.elementi
                if e.get("tipo") in ("pozzetto", "pozzetto_fuori")}
    fid_arm = {e.get("fid") for i in ist.interferenze for e in i.elementi
               if e.get("tipo") in ("armadio", "armadio_fuori")}
    # gruppo dell'istanza nel progetto (Istanze > Strade > ...): la PL
    # disegna il suo contenuto, anche gli elementi aggiunti a mano
    da_gruppo = AL.rete_dal_gruppo(project, ist, L.copia_filtrata, pref, avvisa)
    if da_gruppo:
        infra, pozz, arm = da_gruppo
        fid_tratte = fid_tratte or {"gruppo"}
    else:   # mai la rete intera: fuori dall'istanza (suolo comunale) non si stampa
        infra = L.copia_filtrata(project, infra, fid_tratte, pref) or infra
        pozz = L.copia_filtrata(project, pozz, fid_pozz, pref) if pozz is not None else None
        arm = L.copia_filtrata(project, arm, fid_arm, pref) if arm is not None else None
    if fid_tratte:
        AL.rete_sempre_visibile(infra)
        for l in (infra, pozz, arm):
            if l is not None:
                l.setLabelsEnabled(False)
    rete_orto = L.rete_ortofoto(project, pref, infra, pozz, arm) if fid_tratte else []
    base = L._base_stampe(project)
    orto = L._ortofoto(project, orto_id)
    foto_l = next((l for n in L.NOMI_LAYER_FOTO for l in project.mapLayersByName(n)), None)
    sez_l = next((l for n in L.NOMI_LAYER_SEZIONI for l in project.mapLayersByName(n)), None)
    cart_img = os.path.join(os.path.dirname(out_pdf) or ".", "_immagini_tavole")
    try:
        simboli = simboli_legenda(project, cart_img, fascia=fascia_l is not None)
    except Exception:  # noqa: BLE001
        simboli = None

    try:
        from . import ftth_strade as _S
    except ImportError:
        import ftth_strade as _S
    spec = _S.specifica_centro(ist).strip(" ()")
    dati = {"strada": (strada.nome_documenti() if strada is not None else ist.corso) +
            (("\n" + spec.upper()) if spec else ""),
            "data": datetime.date.today().strftime("%d/%m/%Y"),
            "nome_file": os.path.basename(out_pdf), "comune": comune.nome}

    # particolari: nell'inquadramento generale TUTTI quelli della libreria,
    # in ogni tavola solo quelli che servono agli elementi di quella tavola
    tutti_part = particolari_libreria(cart_part)

    def _part_tavola(interf):
        class _I:
            interferenze = interf
        out = []
        for chiave in L.particolari_necessari(_I):
            nomi = [chiave] + ([L.LIBRERIA_PC[chiave]] if chiave in L.LIBRERIA_PC else [])
            f = L.cerca_file(nomi, cart_part)
            if f and all(f != o[1] for o in out):
                w_, h_ = L.dimensioni_svg(f)
                out.append((chiave, f, w_, h_))
        return out

    # riquadri delle tavole (centri delle zone, dimensione della planimetria 1:500)
    def _rect_punti(lista):
        pts = [tr.transform(QgsPointXY(i.lon, i.lat)) for i in lista]
        return QgsRectangle(min(p.x() for p in pts), min(p.y() for p in pts),
                            max(p.x() for p in pts), max(p.y() for p in pts))
    dxv = area_w * SCALA_TAVOLE / 2000.0
    dyv = h_pl * SCALA_TAVOLE / 2000.0
    def _rect_tavola(lista):
        # ingombro reale di scavi, pozzetti e armadi (bbox), non solo i punti
        pts = []
        for i in lista:
            b = getattr(i, "bbox", None)
            if b and len(b) == 4:
                pts += [QgsPointXY(b[0], b[1]), QgsPointXY(b[2], b[3])]
            pts.append(QgsPointXY(i.lon, i.lat))
            pts += [QgsPointXY(e["lon"], e["lat"]) for e in i.elementi
                    if e.get("lon") is not None and e.get("lat") is not None]
        pts = [tr.transform(p) for p in pts]
        return QgsRectangle(min(p.x() for p in pts), min(p.y() for p in pts),
                            max(p.x() for p in pts), max(p.y() for p in pts))
    centri = list(centri_tav) if centri_tav else []
    for t in ([] if centri_tav else ist.tavole):
        try:
            centri.append(_rect_tavola(t).center())
        except Exception:  # noqa: BLE001
            centri.append(_rect_punti(t).center())
    riquadri = [QgsRectangle(c.x() - dxv, c.y() - dyv, c.x() + dxv, c.y() + dyv) for c in centri]
    # questa PL ha 4 sezioni per tavola: se in un riquadro ce ne sono di più,
    # le altre vanno in tavole in più, centrate sulle loro sezioni
    tav_pl = []          # (interferenze, centro, riquadro, sezioni o None)
    for tav, c_, q_ in zip(ist.tavole, centri, riquadri):
        sez0 = [f for f, _d in L.feature_nel_riquadro(project, sez_l, crs, q_, c_,
                                                      istanza=nomi_ist)
                if L.sigla_sezione(sez_l, f)]
        if len(sez0) <= SEZIONI_PER_TAVOLA:
            tav_pl.append((tav, c_, q_, None))
            continue
        a_crs = QgsCoordinateTransform(sez_l.crs(), crs, project)
        for n0 in range(0, len(sez0), SEZIONI_PER_TAVOLA):
            pezzo = sez0[n0:n0 + SEZIONI_PER_TAVOLA]
            if n0 == 0:
                tav_pl.append((tav, c_, q_, pezzo))
                continue
            r_s = None
            for f in pezzo:
                g_ = QgsGeometry(f.geometry())
                g_.transform(a_crs)
                b_ = g_.boundingBox()
                r_s = QgsRectangle(b_) if r_s is None else (r_s.combineExtentWith(b_) or r_s)
            cs = r_s.center()
            tav_pl.append((tav, cs, QgsRectangle(cs.x() - dxv, cs.y() - dyv,
                                                 cs.x() + dxv, cs.y() + dyv), pezzo))
        avvisa("%d sezioni nella stessa tavola (ne stanno %d): tavole in più"
               % (len(sez0), SEZIONI_PER_TAVOLA))
    centri = [t[1] for t in tav_pl]
    riquadri = [t[2] for t in tav_pl]
    # controllo: pozzetti e armadi dell'istanza fuori da tutte le tavole
    fuori = []
    for i in ist.interferenze:
        for e in i.elementi:
            if e.get("lon") is None or e.get("lat") is None:
                continue
            p = tr.transform(QgsPointXY(e["lon"], e["lat"]))
            if not any(r.contains(p) for r in riquadri):
                fuori.append("%s %s" % (e.get("tipo"), e.get("fid")))
    if fuori:
        avvisa("tavole lungo la strada: %d elementi fuori dalle tavole (%s)"
               % (len(fuori), ", ".join(fuori[:8])))

    # inquadramento generale a 1:2000 (come gli esempi): piu' pagine se serve
    mezza = (area_h - 2 * TIT - GAP) / 2.0
    S_INQ = 2000
    gruppi = _gruppi_inquadramento(riquadri, area_w * S_INQ / 1000.0 - 60,
                                   mezza * S_INQ / 1000.0 - 40)
    n_inq = len(gruppi)

    nome_layout = "STRADE PL - %s" % ist.nome_base
    mgr = project.layoutManager()
    vecchio = mgr.layoutByName(nome_layout)
    if vecchio is not None:
        mgr.removeLayout(vecchio)
    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName(nome_layout)
    pc = layout.pageCollection()
    pc.pages()[0].setPageSize(QgsLayoutSize(pw, ph, MM))
    for _ in range(n_inq - 1 + len(tav_pl)):
        p = QgsLayoutItemPage(layout)
        p.setPageSize(QgsLayoutSize(pw, ph, MM))
        pc.addPage(p)

    strada_lst = [l for l in (strada_l,) if l is not None]
    for g_n, gruppo in enumerate(gruppi):
        # solo i riquadri delle tavole di QUESTA pagina (niente pezzi di
        # tavole di altre pagine)
        riq_l = _riquadri_layer(project, "%s p%d" % (pref, g_n + 1),
                                [riquadri[k] for k in gruppo], tr_inv, [k + 1 for k in gruppo])
        # con piu' pagine di inquadramento ogni pagina mostra solo la rete delle
        # SUE tavole: niente scavi o pozzetti che sembrano fuori dai riquadri
        rete_p, orto_p = (infra, pozz, arm), rete_orto
        if len(gruppi) > 1 and fid_tratte:
            sub = [i for k in gruppo for i in tav_pl[k][0]]
            fp = "%s p%d" % (pref, g_n + 1)
            ft = {f for i in sub for f in i.tratte_fid}
            fpz = {e.get("fid") for i in sub for e in i.elementi
                   if e.get("tipo") in ("pozzetto", "pozzetto_fuori")}
            fa = {e.get("fid") for i in sub for e in i.elementi
                  if e.get("tipo") in ("armadio", "armadio_fuori")}
            if da_gruppo:   # tutto il gruppo, ritagliato sui riquadri qui sotto
                i_p, p_p, a_p = AL.rete_dal_gruppo(project, ist, L.copia_filtrata, fp)
                i_p = i_p or infra
            else:
                i_p = L.copia_filtrata(project, originali[0], ft, fp) or infra
                p_p = L.copia_filtrata(project, originali[1], fpz, fp) \
                    if originali[1] is not None else None
                a_p = L.copia_filtrata(project, originali[2], fa, fp) \
                    if originali[2] is not None else None
            AL.rete_sempre_visibile(i_p)
            for l in (i_p, p_p, a_p):
                if l is not None:
                    l.setLabelsEnabled(False)
                    if l is not infra:
                        _ritaglia_layer(project, l, [riquadri[k] for k in gruppo], crs)
            rete_p = (i_p, p_p, a_p)
            orto_p = L.rete_ortofoto(project, fp, i_p, p_p, a_p)
        r_g = None
        for k in gruppo:
            q = riquadri[k]
            r_g = QgsRectangle(q) if r_g is None else (r_g.combineExtentWith(q) or r_g)
        s_inq = max(S_INQ, L._scala_che_contiene(r_g, area_w, mezza, S_INQ))
        m_inq = None
        for k, (titolo, strati) in enumerate((
                ("ORTOFOTO INQUADRAMENTO GENERALE", [riq_l] + orto_p + strada_lst + [orto]),
                ("INQUADRAMENTO GENERALE", [riq_l] + list(rete_p) + strada_lst + base))):
            y0 = MARG + k * (TIT + mezza + GAP)
            _t(layout, g_n, MARG, y0, area_w * 0.6, TIT, titolo, 14, True, Qt.AlignLeft)
            _t(layout, g_n, MARG + area_w * 0.6, y0, area_w * 0.4, TIT,
               "SCALA 1:%d" % s_inq, 14, True, Qt.AlignRight)
            m = L._mappa(layout, g_n, MARG, y0 + TIT, area_w, mezza, crs, strati,
                         r_g.center(), s_inq)
            AL._nord(layout, g_n, MARG + area_w - 20, y0 + TIT + 3, m, 14)
            if k == 1:
                m_inq = m
        _colonna_destra(layout, g_n, dati, m_inq, [infra, pozz, arm] + strada_lst,
                        tutti_part, "INQUADRAMENTO\nGENERALE", "KEYPLAN", simboli=simboli)

    # ---- tavole 1:500 ----
    n_tav = len(tav_pl)
    for k, (tav, c_pl, vis, sez_fisse) in enumerate(tav_pl, 1):
        pag = n_inq - 1 + k
        linee_ost, box_ost = AL._ostacoli_tavola(project, vis, c_pl, SCALA_TAVOLE, area_w, h_pl,
                                                 crs, [(infra, 3000)], [pozz, arm])
        et_k = AL._etichette_tavola(project, pref, k, ist, et_l, vis, c_pl, SCALA_TAVOLE,
                                    area_w, h_pl, tr, tr_inv, linee_ost, box_ost, unire=False)
        foto_in = L.feature_nel_riquadro(project, foto_l, crs, vis, c_pl, istanza=nomi_ist)
        sez_in = [(f, 0.0) for f in sez_fisse] if sez_fisse else \
            L.feature_nel_riquadro(project, sez_l, crs, vis, c_pl, istanza=nomi_ist)
        foto_c = L.copia_filtrata(project, foto_l, [f.id() for f, _ in foto_in],
                                  "%s %d" % (pref, k), "Punto di ripresa fotografica",
                                  "rilievo") if foto_in else None
        sez_c = L.copia_filtrata(project, sez_l, [f.id() for f, _ in sez_in],
                                 "%s %d" % (pref, k), "Sezioni", "rilievo") if sez_in else None
        _t(layout, pag, MARG, MARG, area_w * 0.6, TIT, "TAVOLA %d" % k, 14, True, Qt.AlignLeft)
        _t(layout, pag, MARG + area_w * 0.6, MARG, area_w * 0.4, TIT,
           "SCALA 1:%d" % SCALA_TAVOLE, 14, True, Qt.AlignRight)
        m_pl = L._mappa(layout, pag, MARG, MARG + TIT, area_w, h_pl, crs,
                        [et_k, foto_c, sez_c, pozz, arm, infra, fascia_l] + base, c_pl,
                        SCALA_TAVOLE)
        AL._nord(layout, pag, MARG + area_w - 20, MARG + TIT + 3, m_pl, 14)

        # in basso: sezioni affiancate (fino a 4, come la tavola 2 della SS71)
        # e foto a destra, una sopra l'altra
        yb = MARG + TIT + h_pl + GAP
        w_sez_tot = area_w * 0.66
        w_foto = area_w - w_sez_tot - GAP
        sezioni = []
        for f, _d in sez_in:
            sigla = L.sigla_sezione(sez_l, f)
            if not sigla:
                continue
            p = L.cerca_file(["SEZIONE %s" % sigla, "SEZIONE_%s" % sigla, sigla], cart_sez)
            if p:
                if all(p != q for _t, q in sezioni):
                    sezioni.append((AL.titolo_da_file(p, "SEZIONE %s" % sigla), p))
            else:
                avvisa("tavola %d: sezione %s disegnata ma file 'SEZIONE %s' non trovato in "
                       "05_Sezioni" % (k, sigla, sigla))
            if len(sezioni) == 4:
                break
        if not sezioni:
            # come negli esempi: quattro riquadri SEZIONE A-A'..D-D' da completare
            avvisa("tavola %d: nessuna sezione disegnata nel layer Sezioni" % k)
            sezioni = [("SEZIONE A-A'", None), ("SEZIONE B-B'", None),
                       ("SEZIONE C-C'", None), ("SEZIONE D-D'", None)]
        # sempre 4 riquadri, come nelle tavole consegnate
        for sig in ("A-A'", "B-B'", "C-C'", "D-D'"):
            if len(sezioni) >= 4:
                break
            if all(sig not in t for t, _p in sezioni):
                sezioni.append(("SEZIONE %s" % sig, None))
        # come nelle tavole consegnate: riquadri larghi e bassi, due per riga
        # (2x2), alti come quelli delle foto
        ws = (w_sez_tot - GAP) / 2.0
        hs = (h_basso - GAP - TIT) / 2.0
        for n, (t, p) in enumerate(sezioni):
            xs_ = MARG + (n % 2) * (ws + GAP)
            ys_ = yb + (n // 2) * (TIT + hs + GAP)
            _t(layout, pag, xs_, ys_, ws, TIT, t, 14, True, Qt.AlignLeft)
            L._box(layout, pag, xs_, ys_ + TIT, ws, hs)
            if p:
                L._immagine(layout, pag, xs_ + 1, ys_ + TIT + 1, ws - 2, hs - 2, p)
            else:
                L._lbl(layout, pag, xs_, ys_ + TIT, ws, hs,
                       "Sezione da inserire: traccia la sezione nel layer Sezioni e metti il "
                       "disegno in 05_Sezioni", 8, colore=QColor(150, 150, 150))
        foto = []
        for f, _d in foto_in:
            n_ = L.numero_foto(foto_l, f)
            p = L.cerca_file(L.nomi_file_foto(n_), cart_foto) if n_ else None
            if p:
                foto.append((AL.titolo_da_file(p, "FOTO %s" % n_), p))
            elif n_:
                avvisa("tavola %d: punto di ripresa FOTO %s senza file FOTO-%s.jpg in 04_Foto"
                       % (k, n_, n_))
            if len(foto) == 2:
                break
        xf = MARG + w_sez_tot + GAP
        h_f = (h_basso - GAP - TIT) / 2.0
        if not foto:
            avvisa("tavola %d: nessuna foto" % k)
            foto = [("FOTO 1", None), ("FOTO 2", None)]
        if len(foto) == 1:
            foto.append(("FOTO", None))
        for n, (t, p) in enumerate(foto):
            yf = yb + n * (TIT + h_f + GAP)
            _t(layout, pag, xf, yf, w_foto, TIT, t, 14, True, Qt.AlignLeft)
            L._box(layout, pag, xf, yf + TIT, w_foto, h_f)
            if p:
                pf = L.foto_ritagliata(p, w_foto - 2, h_f - 2, cart_img)
                L._immagine(layout, pag, xf + 1, yf + TIT + 1, w_foto - 2, h_f - 2, pf)
            else:
                L._lbl(layout, pag, xf, yf + TIT, w_foto, h_f,
                       "Foto da inserire: punto di ripresa con FOTO-n.jpg in 04_Foto", 8,
                       colore=QColor(150, 150, 150))

        _colonna_destra(layout, pag, dati, m_pl, [infra, pozz, arm, foto_c, sez_c, fascia_l],
                        _part_tavola(tav), "TAVOLA DI\nINQUADRAMENTO",
                        "TAV. %d / %d" % (k, n_tav),
                        "PARTICOLARI COSTRUTTIVI DI PROGETTO", simboli=simboli)

    mgr.addLayout(layout)
    if not esporta:
        return True
    os.makedirs(os.path.dirname(out_pdf) or ".", exist_ok=True)
    exp = QgsLayoutExporter(layout)
    s = QgsLayoutExporter.PdfExportSettings()
    s.dpi = 200
    try:
        from qgis.core import Qgis
        s.textRenderFormat = Qgis.TextRenderFormat.AlwaysText
    except Exception:  # noqa: BLE001
        pass
    r = exp.exportToPdf(out_pdf, s)
    return r == QgsLayoutExporter.Success and os.path.isfile(out_pdf)
