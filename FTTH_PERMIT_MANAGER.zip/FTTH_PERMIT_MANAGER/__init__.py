# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""
FTTH Permessi Manager
----------------------
Plugin QGIS per la gestione dei permessi FTTH: analisi spaziale,
rilevamento conflitti e selezione/rimozione elementi.

Questo file viene letto da QGIS per istanziare il plugin.
"""


def _librerie_incluse():
    """Le librerie che non arrivano con QGIS (python-docx, per i Word) sono
    dentro il plugin, in ext_libs: in coda al percorso, così una versione già
    installata sul PC ha la precedenza. Prima, sui PC senza python-docx
    «Genera istanze» si fermava con «Manca python-docx»."""
    import os
    import sys
    cart = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ext_libs")
    if os.path.isdir(cart) and cart not in sys.path:
        sys.path.append(cart)


_librerie_incluse()


def classFactory(iface):
    """Punto di ingresso richiesto da QGIS.

    :param iface: interfaccia QGIS (QgisInterface)
    :return: istanza del plugin
    """
    from .ftth_permessi import FTTHPermessiPlugin
    return FTTHPermessiPlugin(iface)
