# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""
FTTH Permessi Manager
----------------------
Plugin QGIS per la gestione dei permessi FTTH: analisi spaziale,
rilevamento conflitti e selezione/rimozione elementi.

Questo file viene letto da QGIS per istanziare il plugin.
"""


def classFactory(iface):
    """Punto di ingresso richiesto da QGIS.

    :param iface: interfaccia QGIS (QgisInterface)
    :return: istanza del plugin
    """
    from .ftth_permessi import FTTHPermessiPlugin
    return FTTHPermessiPlugin(iface)
