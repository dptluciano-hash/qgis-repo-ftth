# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Rotella del mouse nelle finestre del plugin.

Scorrendo una scheda con la rotella, quando il puntatore passava sopra una
tendina (layer, campo, scelta) o una casella numerica il valore cambiava da
solo (utente, 2026-11-27). Qui, in tutto il plugin, la rotella su quei campi
non cambia niente: fa scorrere la finestra come altrove. Si cambia il valore
cliccando o con la tastiera.
"""
from qgis.PyQt.QtCore import QEvent, QObject
from qgis.PyQt.QtWidgets import QAbstractSpinBox, QApplication, QComboBox

PACCHETTO = __name__.rsplit(".", 1)[0] if "." in __name__ else "FTTH_PERMIT_MANAGER"


def del_plugin(widget):
    """Vero se il campo sta in una finestra/scheda/pannello del plugin (una
    classe di uno dei suoi moduli fra i contenitori)."""
    w = widget
    while w is not None:
        mod = type(w).__module__ or ""
        if mod.startswith(PACCHETTO) or mod.startswith("ftth_"):
            return True
        if w.property("ftth_plugin"):
            return True
        w = w.parentWidget()
    return False


class FiltroRotella(QObject):
    def eventFilter(self, obj, ev):  # noqa: N802 (nome Qt)
        try:
            if ev.type() == QEvent.Wheel and isinstance(obj, (QComboBox, QAbstractSpinBox)) \
                    and del_plugin(obj):
                padre = obj.parentWidget()
                if padre is not None:
                    # la rotella va al contenitore: la finestra scorre
                    QApplication.sendEvent(padre, ev)
                return True
        except Exception:  # noqa: BLE001
            return False
        return False


_FILTRO = None


def attiva():
    """Installa il filtro (una volta sola) su tutta l'applicazione."""
    global _FILTRO
    app = QApplication.instance()
    if app is None or _FILTRO is not None:
        return _FILTRO
    _FILTRO = FiltroRotella()
    app.installEventFilter(_FILTRO)
    return _FILTRO


def disattiva():
    global _FILTRO
    app = QApplication.instance()
    if app is not None and _FILTRO is not None:
        app.removeEventFilter(_FILTRO)
    _FILTRO = None
