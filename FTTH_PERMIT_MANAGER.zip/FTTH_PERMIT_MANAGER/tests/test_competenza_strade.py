"""Competenza sulle strade (centri abitati, abitanti) e verifica ANAS (senza rete)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ftth_screening as S  # noqa: E402


class TestCompetenza(unittest.TestCase):
    def test_grande_centro(self):
        t = S.nota_competenza_strada("SP", 15000, "Provincia")
        self.assertIn("art. 2 c. 7", t)
        self.assertIn("COMUNE", t)
        self.assertIn("15.000", t)
        self.assertIn(S.RIF_COMPETENZA_STRADE, t)

    def test_piccolo_centro_nulla_osta(self):
        t = S.nota_competenza_strada("SS", 4200, "ANAS")
        self.assertIn("NULLA OSTA", t)
        self.assertIn("art. 26 c. 3", t)
        self.assertIn("15 giorni", t)

    def test_popolazione_ignota_e_autostrade(self):
        self.assertIn("non nota", S.nota_competenza_strada("SR", None, "Regione"))
        self.assertIn("concessionario", S.nota_competenza_strada("A", 50000, "Concessionario"))
        self.assertIsNone(S.nota_competenza_strada("COMUNALE", 50000, "Comune"))

    def test_gestori(self):
        g, _n = S.gestore_regionale("SP", "Campania", "Napoli")
        self.assertEqual(g, "Citta' metropolitana di Napoli")
        g, _n = S.gestore_regionale("SP", "Campania", "Salerno")
        self.assertEqual(g, "Provincia di Salerno")
        g, n = S.gestore_regionale("SR", "Campania", "Salerno")
        self.assertNotIn("ACaMIR /", g)
        self.assertIn("ACaMIR", n)            # spiegato nella nota, non come gestore
        g, _n = S.gestore_regionale("SP", "Sicilia", "Trapani")
        self.assertEqual(g, "Libero Consorzio comunale di Trapani")
        g, _n = S.gestore_regionale("SP", "Sicilia", "Città metropolitana di Palermo")
        self.assertEqual(g, "Citta' metropolitana di Palermo")
        g, _n = S.gestore_regionale("SP", "Friuli-Venezia Giulia", "Udine")
        self.assertIn("EDR", g)
        g, _n = S.gestore_regionale("SS", "Trentino-Alto Adige/Südtirol", "Trento")
        self.assertIn("Provincia Autonoma di Trento", g)
        g, _n = S.gestore_regionale("SR", "Veneto", "Padova")
        self.assertNotIn("CAV", g)
        self.assertIn("Autostrade Alto Adriatico", S.concessionario_autostrada("A4"))
        self.assertIn("ANAS", S.concessionario_autostrada("A2"))
        self.assertIsNone(S.concessionario_autostrada("SS71"))

    def test_km_anas(self):
        self.assertEqual(S._km_anas("100,200"), "100+200")
        self.assertEqual(S._km_anas("12,572"), "12+572")
        self.assertEqual(S._km_anas("103,67"), "103+670")

    def test_nota_anas(self):
        info = {"id": "SS71", "nome": "71 - UMBRO CASENTINESE ROMAGNOLA",
                "tratte": [{"dal": "29+594", "al": "110+173", "capisaldi": "", "competenza": ""}],
                "centri_abitati": [{"nome": "CASTIGLIONE DEL LAGO", "dal": "100+200",
                                    "al": "103+670", "sotto_10000": True}],
                "struttura": {"nome": "ANAS S.p.A. - Struttura territoriale Umbria",
                              "indirizzo": "Via XX Settembre, 33 - 06121 Perugia",
                              "pec": "servizioclienti@postacert.stradeanas.it"}}
        t = S.nota_anas(info)
        self.assertIn("km 29+594-110+173", t)
        self.assertIn("CASTIGLIONE DEL LAGO dal km 100+200 al km 103+670", t)
        self.assertIn("sotto i 10.000", t)
        self.assertIn("servizioclienti@postacert.stradeanas.it", t)


if __name__ == "__main__":
    unittest.main()
