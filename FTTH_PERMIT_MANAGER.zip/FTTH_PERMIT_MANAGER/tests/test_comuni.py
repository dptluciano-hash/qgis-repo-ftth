import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_comuni as C  # noqa: E402


class TestComuni(unittest.TestCase):
    def test_elenco_istat(self):
        self.assertGreater(len(C.elenco()), 7800)

    def test_cerca(self):
        self.assertIn(("Castiglione del Lago", "PG"), C.cerca("castiglione del l"))
        # prima chi inizia col testo, poi chi lo contiene
        r = C.cerca("lago")
        self.assertTrue(r[0][0].lower().startswith("lago"))
        self.assertEqual(C.cerca(""), [])


if __name__ == "__main__":
    unittest.main()
