import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_acque as A  # noqa: E402
import ftth_vincoli as V  # noqa: E402


def _interf(n, lon, lat, armadi=0):
    el = [{"tipo": "pozzetto", "fid": 100 + n, "lon": lon, "lat": lat}]
    el += [{"tipo": "armadio", "fid": 200 + n * 10 + k, "lon": lon + k * 1e-5, "lat": lat}
           for k in range(armadi)]
    return A.InterferenzaAcqua(id=n, tipo="parallelismo", corso="SOPR", categoria="paesaggio",
                               ente_tipo="soprintendenza", metri={"minitrincea": 30},
                               pozzetti={"40x76": 1}, lon=lon, lat=lat, elementi=el,
                               tratte_fid=[n])


class TestSoloArmadi(unittest.TestCase):
    def test_max_per_tavola(self):
        # 6 armadi vicinissimi: con 4 foto 2 tavole (4+2), con 2 foto 3 tavole
        for max_per, attese in ((4, 2), (2, 3)):
            interf = [_interf(1, 14.9, 40.6, 3), _interf(2, 14.9001, 40.6, 3),
                      _interf(3, 14.9002, 40.6, 0)]
            ist = A.IstanzaAcqua(numero=1, ente_tipo="soprintendenza", ente_nome="X",
                                 interferenze=interf)
            self.assertTrue(V.solo_armadi(ist, max_per))
            self.assertEqual(len(ist.interferenze), 6)
            self.assertEqual(len(ist.tavole), attese)
            self.assertTrue(all(len(t) <= max_per for t in ist.tavole))
            # conteggi solo armadi, planimetria con scavi e pozzetti
            self.assertTrue(all(not i.metri and not i.pozzetti for i in ist.interferenze))
            self.assertEqual(len(ist.interferenze_pl), 2)

    def test_etichetta_arlo(self):
        self.assertEqual(A.testo_elemento_auto({"tipo": "armadio", "id": "201.0"}),
                         "POSA ARMADIO ARLO 201")
        self.assertEqual(A.testo_elemento_auto({"tipo": "armadio", "id": ""}), "POSA ARMADIO")
        self.assertEqual(A.testo_elemento_auto({"tipo": "armadio", "id": "NULL"}), "POSA ARMADIO")

    def test_senza_armadi(self):
        ist = A.IstanzaAcqua(numero=1, ente_tipo="soprintendenza", ente_nome="X",
                             interferenze=[_interf(1, 14.9, 40.6, 0)])
        self.assertFalse(V.solo_armadi(ist, 2))


if __name__ == "__main__":
    unittest.main()
