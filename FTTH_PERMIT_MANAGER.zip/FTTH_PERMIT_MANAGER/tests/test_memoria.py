# -*- coding: utf-8 -*-
"""Memoria del lavoro delle schede istanze: errori mai più taciuti."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_memoria as M  # noqa: E402


class _Prj:
    def __init__(self, fn):
        self._fn = fn
        self.dirty = False

    def fileName(self):
        return self._fn

    def isDirty(self):
        return self.dirty

    def setDirty(self, v=True):
        self.dirty = v


class _Dlg:
    def __init__(self):
        self.righe = {"rfi": [], "strade": [], "sopr": []}
        self._sti = {"strade": [], "interferenze": []}

    def _log_rfi(self, m):
        self.righe["rfi"].append(m)

    def _log_sti(self, m):
        self.righe["strade"].append(m)

    def _vin_log(self, s, m):
        self.righe[s].append(m)

    def _sti_riempi_strade(self):
        pass

    def _sti_riempi(self, _i):
        raise RuntimeError("tabella rotta")


class TestMemoria(unittest.TestCase):
    def setUp(self):
        self.cart = tempfile.mkdtemp()
        self.prj = _Prj(os.path.join(self.cart, "prova.qgz"))

    def test_lista_tiene_gli_elementi_buoni(self):
        scartati = []
        out = M.solo_salvabile({"interferenze": [1, lambda: 0, 3], "x": 5}, scartati,
                               "Istanze Strade")
        self.assertEqual(out["interferenze"], [1, 3])
        self.assertEqual(out["x"], 5)
        self.assertEqual(len(scartati), 1)
        self.assertEqual(M.chiave_scheda(scartati[0]), "strade")

    def test_errore_non_cancella_il_salvataggio_precedente(self):
        ok, motivo = M.scrivi_esito(self.prj, {"strade": {"stato": {"a": 1}}})
        self.assertTrue(ok, motivo)
        ok, motivo = M.scrivi_esito(self.prj, {"strade": {"stato": {"a": lambda: 0}}})
        self.assertFalse(ok)
        self.assertTrue(motivo)
        self.assertEqual(M.leggi(self.prj)["strade"]["stato"]["a"], 1)
        self.assertFalse(os.path.exists(M.percorso(self.prj) + ".tmp"))

    def test_progetto_mai_salvato(self):
        ok, motivo = M.scrivi_esito(_Prj(""), {})
        self.assertFalse(ok)
        self.assertIn("mai salvato", motivo)

    def test_file_illeggibile_detto(self):
        with open(M.percorso(self.prj), "wb") as fh:
            fh.write(b"rotto")
        dati, motivo = M.leggi_esito(self.prj)
        self.assertEqual(dati, {})
        self.assertIn("non leggibile", motivo)

    def test_ripresa_nel_registro_della_scheda(self):
        d = _Dlg()
        d._sti_riempi = lambda _i: None
        M.ripristina(d, {"strade": {"stato": {"strade": [], "interferenze": [1]}}})
        self.assertTrue(any("ripreso" in r for r in d.righe["strade"]))
        self.assertEqual(d.righe["rfi"], [])

    def test_ripresa_fallita_avvisa_la_scheda(self):
        d = _Dlg()
        M.ripristina(d, {"strade": {"stato": {"interferenze": [1]}}})
        self.assertTrue(any("ATTENZIONE" in r and "tabella rotta" in r
                            for r in d.righe["strade"]))


if __name__ == "__main__":
    unittest.main()
