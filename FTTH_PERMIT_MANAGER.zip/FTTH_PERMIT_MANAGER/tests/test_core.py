# -*- coding: utf-8 -*-
"""Test della logica pura (ftth_core). Girano senza QGIS:

    cd ftth_permessi && python -m pytest tests/ -v
    (oppure: python -m unittest discover tests)

I casi vengono dai banchi di prova citati nel README (parser dei cippi
v0.54, continuità del retino v0.66, trasformazione di similitudine v0.72+).
"""
import math
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from ftth_core import (
    UnionFind, fit_similarity, parse_chilometrica, format_chilometrica,
    unisci_intervalli, formatta_numero, nome_da_chiave,
)


class _P:
    """Punto minimo con .x()/.y(), al posto di QgsPointXY."""
    def __init__(self, x, y): self._x, self._y = x, y
    def x(self): return self._x
    def y(self): return self._y


class TestParseChilometrica(unittest.TestCase):
    def test_formato_standard(self):
        self.assertEqual(parse_chilometrica("17+100"), 17100)

    def test_prefissi_descrittivi(self):
        # il caso che mandava in errore il parser prima della v0.54
        for testo in ("KM 17+100", "km17+100", "PK 17+100", "P.K. 17+100",
                      "progr. 17+100", "progressiva 17+100", "prog 17+100",
                      "cippo 17+100", "KMT 17+100"):
            self.assertEqual(parse_chilometrica(testo), 17100, testo)

    def test_virgola_decimale(self):
        self.assertEqual(parse_chilometrica("17+100,5"), 17100.5)

    def test_invertito(self):
        self.assertEqual(parse_chilometrica("100+17", formato="invertito"), 17100)

    def test_metri(self):
        self.assertEqual(parse_chilometrica("17100", formato="metri"), 17100)

    def test_km_decimali(self):
        self.assertEqual(parse_chilometrica("17,1", formato="km_dec"), 17100)

    def test_euristica_senza_piu(self):
        # valori piccoli sono km decimali, grandi sono metri
        self.assertEqual(parse_chilometrica("17,1"), 17100)
        self.assertEqual(parse_chilometrica("17100"), 17100)

    def test_non_interpretabile(self):
        for testo in (None, "", "  ", "abc", "km", "+", "a+b"):
            self.assertIsNone(parse_chilometrica(testo), repr(testo))


class TestFormatChilometrica(unittest.TestCase):
    def test_base(self):
        self.assertEqual(format_chilometrica(17600), "17+600")

    def test_zero_padding(self):
        self.assertEqual(format_chilometrica(17005), "17+005")

    def test_zero(self):
        self.assertEqual(format_chilometrica(0), "0+000")

    def test_negativo(self):
        self.assertEqual(format_chilometrica(-500), "-0+500")

    def test_andata_e_ritorno(self):
        for metri in (0, 5, 999, 1000, 17100, 123456):
            self.assertEqual(parse_chilometrica(format_chilometrica(metri)), metri)


class TestUnisciIntervalli(unittest.TestCase):
    def test_vuoto(self):
        self.assertEqual(unisci_intervalli([], 5), [])

    def test_fusione_sotto_soglia(self):
        # due scavi separati da 4 m con soglia 5: un tratto unico
        self.assertEqual(unisci_intervalli([(0, 10), (14, 20)], 5), [(0, 20)])

    def test_nessuna_fusione_sopra_soglia(self):
        self.assertEqual(unisci_intervalli([(0, 10), (16, 20)], 5),
                         [(0, 10), (16, 20)])

    def test_ordina_prima_di_fondere(self):
        self.assertEqual(unisci_intervalli([(14, 20), (0, 10)], 5), [(0, 20)])

    def test_intervallo_contenuto(self):
        self.assertEqual(unisci_intervalli([(0, 20), (5, 10)], 0), [(0, 20)])

    def test_tre_frammenti_in_uno(self):
        # il caso del README v0.66: scavi intervallati → tratto unico
        self.assertEqual(unisci_intervalli([(0, 100), (105, 300), (308, 400)], 10),
                         [(0, 400)])


class TestFitSimilarity(unittest.TestCase):
    def test_traslazione_pura(self):
        coppie = [(_P(0, 0), _P(10, 5)), (_P(1, 0), _P(11, 5))]
        a, b, rms = fit_similarity(coppie)
        self.assertAlmostEqual(abs(a), 1.0)
        self.assertAlmostEqual(b.real, 10.0)
        self.assertAlmostEqual(b.imag, 5.0)
        self.assertAlmostEqual(rms, 0.0)

    def test_rotazione_90_gradi(self):
        coppie = [(_P(0, 0), _P(0, 0)), (_P(1, 0), _P(0, 1))]
        a, b, rms = fit_similarity(coppie)
        self.assertAlmostEqual(math.degrees(math.atan2(a.imag, a.real)), 90.0)
        self.assertAlmostEqual(abs(a), 1.0)
        self.assertAlmostEqual(rms, 0.0)

    def test_scala(self):
        coppie = [(_P(0, 0), _P(0, 0)), (_P(1, 0), _P(2, 0)), (_P(0, 1), _P(0, 2))]
        a, b, rms = fit_similarity(coppie)
        self.assertAlmostEqual(abs(a), 2.0)
        self.assertAlmostEqual(rms, 0.0)

    def test_minimi_quadrati_con_rumore(self):
        # tre coppie quasi coerenti: il residuo resta piccolo ma non nullo
        coppie = [(_P(0, 0), _P(10, 0)), (_P(1, 0), _P(11, 0.1)),
                  (_P(0, 1), _P(10, 1))]
        ris = fit_similarity(coppie)
        self.assertIsNotNone(ris)
        self.assertLess(ris[2], 0.1)

    def test_casi_degeneri(self):
        self.assertIsNone(fit_similarity([]))
        self.assertIsNone(fit_similarity([(_P(0, 0), _P(1, 1))]))
        # punti sorgente tutti coincidenti: nessuna informazione di scala
        self.assertIsNone(fit_similarity([(_P(0, 0), _P(1, 1)),
                                          (_P(0, 0), _P(2, 2))]))


class TestFormattaNumero(unittest.TestCase):
    def test_virgola_italiana(self):
        self.assertEqual(formatta_numero(8.25, 2), "8,25")

    def test_arrotonda_meta_per_eccesso(self):
        # la ragione della funzione: round(8.5) darebbe 8
        self.assertEqual(formatta_numero(8.5, 0), "9")
        self.assertEqual(formatta_numero(0.125, 2), "0,13")

    def test_negativi(self):
        self.assertEqual(formatta_numero(-8.5, 0), "-9")


class TestNomeDaChiave(unittest.TestCase):
    def test_nome_semplice(self):
        self.assertEqual(nome_da_chiave("SR56"), "SR56")

    def test_con_tronco(self):
        self.assertEqual(nome_da_chiave("SR56 – tronco 2"), "SR56")

    def test_chiavi_di_servizio(self):
        for chiave in ("tutte le tratte", "None", "", None):
            self.assertEqual(nome_da_chiave(chiave), "")


class TestUnionFind(unittest.TestCase):
    def test_gruppi(self):
        uf = UnionFind([1, 2, 3, 4, 5])
        uf.union(1, 2); uf.union(2, 3); uf.union(4, 5)
        gruppi = sorted(sorted(g) for g in uf.groups().values())
        self.assertEqual(gruppi, [[1, 2, 3], [4, 5]])

    def test_singoli(self):
        uf = UnionFind([1, 2])
        self.assertEqual(len(uf.groups()), 2)


if __name__ == "__main__":
    unittest.main()
