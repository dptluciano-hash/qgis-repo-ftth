import hashlib
import os
import re
import shutil
import sys
import tempfile
import unittest
import zipfile

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, QUI)
import ftth_logo as LG  # noqa: E402


def _hash_media(path):
    with zipfile.ZipFile(path) as z:
        return {hashlib.sha1(z.read(n)).hexdigest() for n in z.namelist()
                if n.startswith("word/media/")}


class TestLogo(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _copia(self, rel):
        dst = os.path.join(self.tmp, os.path.basename(rel))
        shutil.copy(os.path.join(QUI, rel), dst)
        return dst

    def test_rt_milano_cortina_e_ritorno(self):
        p = self._copia(os.path.join("modelli_acque", "TEMPLATE_1.2_RT+CR.docx"))
        self.assertTrue(_hash_media(p) & LG.HASH_CLASSICO)
        self.assertEqual(LG.applica_docx(p, True), 2)
        h = _hash_media(p)
        self.assertFalse(h & LG.HASH_CLASSICO)
        # riquadri con le proporzioni del logo olimpico (603x166)
        with zipfile.ZipFile(p) as z:
            xml = z.read("word/document.xml").decode("utf-8")
        self.assertTrue(re.search(r'<w:drawing>', xml))
        # il file resta un docx valido e rileggibile
        self.assertEqual(LG.applica_docx(p, True), 0)

    def test_bollo_classico(self):
        p = self._copia(os.path.join("modelli_acque", "TEMPLATE_1.3_Bollo.docx"))
        self.assertTrue(_hash_media(p) & LG.HASH_MC)
        self.assertEqual(LG.applica_docx(p, False), 1)
        self.assertFalse(_hash_media(p) & LG.HASH_MC)
        self.assertEqual(LG.applica_docx(p, True), 0)   # nessun logo classico noto

    def test_art49(self):
        for cart in ("modelli_acque", "modelli_rfi", "modelli_strade"):
            p = self._copia(os.path.join(cart, "TEMPLATE_1.0_art.49.docx"))
            self.assertEqual(LG.applica_docx(p, True), 1, cart)

    def test_dim(self):
        with open(LG.LOGO_MC["jpg"], "rb") as fh:
            self.assertEqual(LG._dim_png_jpg(fh.read()), (603, 166))
        with open(LG.LOGO_MC["png"], "rb") as fh:
            self.assertEqual(LG._dim_png_jpg(fh.read()), (603, 166))


if __name__ == "__main__":
    unittest.main()
