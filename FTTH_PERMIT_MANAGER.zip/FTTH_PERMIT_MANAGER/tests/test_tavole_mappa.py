# -*- coding: utf-8 -*-
"""Riquadri delle tavole in mappa: la stampa usa quelli (cancellati, spostati)."""
import os
import sys
import unittest
from types import SimpleNamespace as NS

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import (QgsApplication, QgsCoordinateReferenceSystem,  # noqa: E402
                       QgsCoordinateTransform, QgsPointXY, QgsProject, QgsRectangle)

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_tavole_mappa as TM  # noqa: E402
import ftth_acque_layout as AL  # noqa: E402
import ftth_rfi_layout as L  # noqa: E402


def _ist(nome="X_SP1"):
    # due gruppi di interferenze a ~2 km di distanza (Eboli, lon 15.05)
    interf = [NS(lon=15.05 + k * 0.0002, lat=40.6, bbox=None, elementi=[]) for k in range(3)] + \
             [NS(lon=15.08 + k * 0.0002, lat=40.6, bbox=None, elementi=[]) for k in range(3)]
    return NS(nome_base=nome, interferenze=interf, tavole=[interf[:3], interf[3:]], corso="X")


class TestTavoleMappa(unittest.TestCase):
    def tearDown(self):
        prj = QgsProject.instance()
        for l in prj.mapLayersByName(TM.nome_layer("acque")):
            prj.removeMapLayer(l.id())

    def test_calcolo_scrittura_e_cancellazione(self):
        prj = QgsProject.instance()
        ist = _ist()
        crs, s_pl, tav = AL.riquadri_tavole(prj, ist, None, mappa=False)
        self.assertEqual(len(tav), 2)
        voci = [(ist.nome_base, n, s_pl, r, "TAV. %d" % n, "") for n, (_t, _c, r)
                in enumerate(tav, 1)]
        lyr = TM.scrivi(prj, "acque", voci, crs, permanente=False)
        self.assertEqual(lyr.featureCount(), 2)
        # la stampa legge i riquadri in mappa
        ist2 = _ist()
        _c, _s, tav2 = AL.riquadri_tavole(prj, ist2, None, ente="acque")
        self.assertEqual(len(tav2), 2)
        # l'utente cancella la tavola 2: la stampa ne fa una sola
        f2 = next(f for f in lyr.getFeatures() if f["n"] == 2)
        lyr.dataProvider().deleteFeatures([f2.id()])
        avvisi = []
        ist3 = _ist()
        _c, _s, tav3 = AL.riquadri_tavole(prj, ist3, None, ente="acque", avvisa=avvisi.append)
        self.assertEqual(len(tav3), 1)
        self.assertEqual(len(ist3.tavole), 1)
        self.assertTrue(any("fuori da tutti i riquadri" in a for a in avvisi))
        # un'altra istanza senza riquadri: divisione automatica
        _c, _s, tav4 = AL.riquadri_tavole(prj, _ist("ALTRA"), None, ente="acque")
        self.assertEqual(len(tav4), 2)

    def test_dividi(self):
        fin = [QgsRectangle(0, 0, 10, 10), QgsRectangle(20, 0, 30, 10)]
        g, fuori = TM.dividi([1, 25, 50], fin, lambda x: QgsPointXY(x, 5))
        self.assertEqual(g, [[1], [25]])
        self.assertEqual(fuori, [50])


if __name__ == "__main__":
    unittest.main()
