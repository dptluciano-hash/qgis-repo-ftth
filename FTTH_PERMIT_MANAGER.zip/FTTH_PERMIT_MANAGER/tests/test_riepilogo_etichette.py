# -*- coding: utf-8 -*-
"""Riepilogo di «Modifica etichette in mappa»: quante etichette e perché mancano."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import (QgsApplication, QgsFeature, QgsGeometry, QgsPointXY,  # noqa: E402
                       QgsVectorLayer)

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_passi as P  # noqa: E402


class TestRiepilogo(unittest.TestCase):
    def test_conteggi_e_motivi(self):
        l = QgsVectorLayer("Point?crs=EPSG:4326&field=istanza:string&field=testo:string",
                           "et", "memory")
        f = QgsFeature(l.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(0, 0)))
        f["istanza"] = "EBOLI_SP30"
        l.dataProvider().addFeatures([f, QgsFeature(f)])
        righe = ["- EBOLI_SP30: 3 interferenze -> C:/x", "- EBOLI_SP31: 2 interferenze -> C:/y",
                 "    tavola 1: nessuna sezione disegnata nel layer Sezioni"]
        breve, dett, tot = P.riepilogo_etichette(l, righe)
        self.assertEqual(tot, 2)
        self.assertIn("EBOLI_SP30: 2 etichette", dett)
        self.assertIn("EBOLI_SP31: 0 etichette", dett)
        self.assertIn("ATTENZIONE", dett)
        self.assertIn("nessuna sezione", dett)

    def test_etichette_di_istanze_sparite(self):
        from qgis.core import QgsProject
        import ftth_rfi_layout as L
        prj = QgsProject.instance()
        l = QgsVectorLayer("Point?crs=EPSG:4326&field=istanza:string&field=testo:string",
                           L.nome_etich("strade"), "memory")
        feats = []
        for ist in ("X_SS1", "X_SS1_DENTRO_CA", "X_SS1_FUORI_CA"):
            f = QgsFeature(l.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(0, 0)))
            f["istanza"] = ist
            feats.append(f)
        l.dataProvider().addFeatures(feats)
        prj.addMapLayer(l)
        try:
            L.inizio_generazione()
            L.etichette_inizio("X_SS1_DENTRO_CA")
            L.etichette_inizio("X_SS1_FUORI_CA")
            self.assertEqual(L.togli_etichette_orfane(prj, "strade"), 1)
            self.assertEqual({f["istanza"] for f in l.getFeatures()},
                             {"X_SS1_DENTRO_CA", "X_SS1_FUORI_CA"})
            # senza generazione (nessuna istanza): non si toglie niente
            self.assertEqual(L.togli_etichette_orfane(prj, "strade"), 0)
        finally:
            prj.removeMapLayer(l.id())

    def test_niente_da_preparare(self):
        _b, dett, tot = P.riepilogo_etichette(None, [])
        self.assertEqual(tot, 0)
        self.assertIn("nessuna istanza", dett)
        self.assertIn("non creato", dett)


if __name__ == "__main__":
    unittest.main()
