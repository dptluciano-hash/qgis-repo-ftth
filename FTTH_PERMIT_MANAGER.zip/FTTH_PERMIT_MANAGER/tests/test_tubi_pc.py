# -*- coding: utf-8 -*-
"""Tubi del particolare costruttivo scelti dall'utente (passo 6)."""
import os
import sys
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_rfi_layout as L  # noqa: E402


class _Ist:
    interferenze = []


class TestTubiPC(unittest.TestCase):
    def tearDown(self):
        L.TUBI_SCELTI = []

    def test_senza_scelta_fender4(self):
        self.assertEqual(L.particolari_necessari(_Ist())[-1], "tubi")

    def test_scelti_tutti_trovati(self):
        L.TUBI_SCELTI = [k for k, _t in L.TUBI_PC]
        ch = L.particolari_necessari(_Ist())
        self.assertNotIn("tubi", ch)
        for k, _t in L.TUBI_PC:
            self.assertIn(k, ch)
            f = L.cerca_particolare(k, [os.path.join(L.ASSETS, "rfi_particolari")])
            self.assertTrue(f and os.path.basename(f).startswith(L.LIBRERIA_PC[k]), k)

    def test_tubi_progetto(self):
        prj = types.SimpleNamespace(
            readEntry=lambda s, k, d: ("tritubo_50,xx,tubo_16", True))
        self.assertEqual(L.tubi_progetto(prj), ["tritubo_50", "tubo_16"])


if __name__ == "__main__":
    unittest.main()
