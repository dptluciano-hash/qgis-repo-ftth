import os
import sys
import unittest

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, QUI)

try:
    from qgis.core import QgsApplication, QgsFeature, QgsProject, QgsVectorLayer
    HA_QGIS = True
except ImportError:
    HA_QGIS = False


@unittest.skipUnless(HA_QGIS, "QGIS non disponibile")
class TestComuneShape(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QgsApplication.instance() or QgsApplication([], False)
        if QgsApplication.instance() is cls.app:
            cls.app.initQgis()
        import ftth_comuni as C
        cls.C = C
        cls.prj = QgsProject()
        for nome, valori in (("02_POZZETTO", ["Deruta"] * 30 + [None] * 5),
                             ("CIVICI", ["DERUTA"] * 60 + ["Torgiano"] * 2),
                             ("03 INFRASTRUTTURE", [None] * 10)):
            l = QgsVectorLayer("Point?field=COMUNE:string", nome, "memory")
            feats = []
            for v in valori:
                f = QgsFeature(l.fields())
                f["COMUNE"] = v
                feats.append(f)
            l.dataProvider().addFeatures(feats)
            cls.prj.addMapLayer(l)

    def test_comuni_degli_shape(self):
        voci, letti = self.C.comuni_degli_shape(self.prj)
        self.assertEqual(voci[0][1], 90)
        self.assertEqual(self.C.norm(voci[0][0]), "deruta")
        self.assertEqual(set(letti), {"02_POZZETTO", "CIVICI"})

    def test_controllo(self):
        self.assertIsNone(self.C.controlla_con_shape("Deruta", self.prj))
        self.assertIsNone(self.C.controlla_con_shape("DERUTA", self.prj))
        esito = self.C.controlla_con_shape("Sortino", self.prj)
        self.assertEqual(self.C.norm(esito[0]), "deruta")
        # comune presente in pochissimi elementi (sotto il 5%): non basta
        self.assertIsNotNone(self.C.controlla_con_shape("Torgiano", self.prj))
        self.assertIsNone(self.C.controlla_con_shape("", self.prj))
        self.assertIsNone(self.C.controlla_con_shape("Sortino", QgsProject()))


if __name__ == "__main__":
    unittest.main()
