# -*- coding: utf-8 -*-
"""Pozzetti esistenti sugli scavi dell'istanza: entrano da soli in tavola."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import (QgsApplication, QgsFeature, QgsGeometry, QgsPointXY,  # noqa: E402
                       QgsProject, QgsVectorLayer)

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_rfi_layout as L  # noqa: E402


def _pozzetti(punti):
    l = QgsVectorLayer("Point?crs=EPSG:32633&field=STATO:string&field=TIPO_POZZE:string",
                       "02_POZZETTO", "memory")
    feats = []
    for x, y, st in punti:
        f = QgsFeature(l.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(x, y)))
        f["STATO"] = st
        f["TIPO_POZZE"] = "40x76"
        feats.append(f)
    l.dataProvider().addFeatures(feats)
    return l


class TestPozzettiEsistenti(unittest.TestCase):
    def test_aggiunti_solo_esistenti_sugli_scavi(self):
        prj = QgsProject.instance()
        pz_o = _pozzetti([(0, 0, "Esistente"),       # sullo scavo
                          (50, 2, "Esistente"),      # a 2 m dallo scavo
                          (100, 0, "Nuovo"),         # nuovo sullo scavo: anche lui
                          (300, 300, "Esistente")])  # lontano
        infra = QgsVectorLayer("LineString?crs=EPSG:32633", "scavi", "memory")
        f = QgsFeature()
        f.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(0, 0), QgsPointXY(120, 0)]))
        infra.dataProvider().addFeatures([f])
        pozz = L.copia_filtrata(prj, pz_o, [], "prova")
        self.assertEqual(L.aggiungi_pozzetti_esistenti(prj, pz_o, pozz, infra), 3)
        self.assertEqual(pozz.featureCount(), 3)
        self.assertEqual({f_["TIPO_POZZE"] for f_ in pozz.getFeatures()}, {"40x76"})
        # di nuovo: niente doppioni
        self.assertEqual(L.aggiungi_pozzetti_esistenti(prj, pz_o, pozz, infra), 0)

    def test_stile_senza_voce_o_spento(self):
        from qgis.core import (QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsSymbol,
                               QgsWkbTypes)
        prj = QgsProject.instance()
        pz_o = _pozzetti([(0, 0, "Nuovo")])          # TIPO_POZZE 40x76
        sym = QgsSymbol.defaultSymbol(QgsWkbTypes.PointGeometry)
        pz_o.setRenderer(QgsCategorizedSymbolRenderer("TIPO_POZZE", [
            QgsRendererCategory("125x80", sym.clone(), "125x80"),
            QgsRendererCategory("40x76", sym.clone(), "40x76", False)]))   # voce spenta
        pozz = L.copia_filtrata(prj, pz_o, [f.id() for f in pz_o.getFeatures()], "prova")
        self.assertGreater(L.rendi_visibili(pozz), 0)
        cat = [c for c in pozz.renderer().categories() if c.value() == "40x76"][0]
        self.assertTrue(cat.renderState())
        # tipo senza voce nello stile: si aggiunge «Altri»
        pz2 = _pozzetti([(0, 0, "Nuovo")])
        pz2.setRenderer(QgsCategorizedSymbolRenderer("TIPO_POZZE", [
            QgsRendererCategory("125x80", sym.clone(), "125x80")]))
        c2 = L.copia_filtrata(prj, pz2, [f.id() for f in pz2.getFeatures()], "prova2")
        self.assertEqual(L.rendi_visibili(c2), 1)
        self.assertEqual(len(c2.renderer().categories()), 2)

    def test_mai_sulla_rete_intera(self):
        prj = QgsProject.instance()
        pz_o = _pozzetti([(0, 0, "Esistente")])
        self.assertEqual(L.aggiungi_pozzetti_esistenti(prj, pz_o, pz_o, None), 0)


if __name__ == "__main__":
    unittest.main()
