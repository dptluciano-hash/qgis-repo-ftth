# -*- coding: utf-8 -*-
"""Layer propri di RFI (foto, sezioni, etichette) nel gruppo RFI."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import QgsApplication, QgsFeature, QgsField, QgsGeometry, QgsPointXY, \
    QgsProject, QgsVectorLayer  # noqa: E402
from qgis.PyQt.QtCore import QVariant  # noqa: E402

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_rfi_layout as L  # noqa: E402


def _punti(nome, valori):
    l = QgsVectorLayer("Point?crs=EPSG:3857", nome, "memory")
    l.dataProvider().addAttributes([QgsField("NumeroFoto", QVariant.Int),
                                    QgsField("ISTANZA", QVariant.String)])
    l.updateFields()
    fs = []
    for k, v in enumerate(valori):
        f = QgsFeature(l.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(k, k)))
        f["NumeroFoto"] = k + 1
        f["ISTANZA"] = v
        fs.append(f)
    l.dataProvider().addFeatures(fs)
    return l


class TestLayerEnte(unittest.TestCase):
    def setUp(self):
        self.prj = QgsProject()

    def test_nomi(self):
        self.assertEqual(L.nome_layer_ente("Sezioni", "rfi"), "Sezioni - RFI")
        self.assertEqual(L.nome_layer_ente("Sezioni", "strade"), "Sezioni - Strade")
        self.assertEqual(L.nome_layer_ente("Sezioni", "parchi"), "Sezioni - Parchi")
        self.assertEqual(L.nome_layer_ente("Sezioni", "comunale"), "Sezioni")
        L.ENTE_CORRENTE = "rfi"
        try:
            self.assertEqual(L.nome_etich(), "Etichette PL (spostabili) - RFI")
        finally:
            L.ENTE_CORRENTE = ""
        self.assertEqual(L.nome_etich(), "Etichette PL (spostabili)")
        self.assertTrue(L.di_ente("rfi", "EBOLI_RFI_TipoA_EBOLI"))
        self.assertFalse(L.di_ente("rfi", "SP28"))

    def test_layer_rilievo_preferisce_ente(self):
        com = _punti("Punto di Ripresa Fotografico", [""])
        rfi = _punti("Punto di Ripresa Fotografico - RFI", [""])
        self.prj.addMapLayers([com, rfi])
        self.assertIs(L.layer_rilievo(self.prj, L.NOMI_LAYER_FOTO, ["X"], "rfi"), rfi)
        self.assertIs(L.layer_rilievo(self.prj, L.NOMI_LAYER_FOTO, ["X"]), com)

    def test_layer_rilievo_senza_ente_usa_comune(self):
        com = _punti("Punto di Ripresa Fotografico", [""])
        self.prj.addMapLayer(com)
        self.assertIs(L.layer_rilievo(self.prj, L.NOMI_LAYER_FOTO, ["X"], "rfi"), com)

    def test_sposta_elementi(self):
        com = _punti("Punto di Ripresa Fotografico", ["", "SP28", "Linea 124", ""])
        rfi = _punti("Punto di Ripresa Fotografico - RFI", [])
        self.prj.addMapLayers([com, rfi])
        n = L.sposta_elementi([com], rfi, lambda f: f["ISTANZA"] == "Linea 124")
        self.assertEqual(n, 1)
        self.assertEqual(com.featureCount(), 3)
        self.assertEqual([f["NumeroFoto"] for f in rfi.getFeatures()], [3])


if __name__ == "__main__":
    unittest.main()
