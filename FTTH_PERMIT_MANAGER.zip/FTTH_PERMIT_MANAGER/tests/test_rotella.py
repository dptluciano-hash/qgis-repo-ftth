# -*- coding: utf-8 -*-
"""La rotella non cambia tendine e numeri nelle finestre del plugin."""
import unittest

from qgis.PyQt.QtCore import QPoint, QPointF, Qt
from qgis.PyQt.QtGui import QWheelEvent
from qgis.PyQt.QtWidgets import QApplication, QComboBox, QSpinBox, QVBoxLayout, QWidget

try:
    from FTTH_PERMIT_MANAGER import ftth_rotella as ROT
except ImportError:  # pragma: no cover
    import ftth_rotella as ROT


def _rotella(w):
    ev = QWheelEvent(QPointF(5, 5), QPointF(5, 5), QPoint(0, -120), QPoint(0, -120),
                     Qt.NoButton, Qt.NoModifier, Qt.NoScrollPhase, False)
    QApplication.sendEvent(w, ev)


class TestRotella(unittest.TestCase):
    def setUp(self):
        ROT.attiva()

    def tearDown(self):
        ROT.disattiva()

    def _campi(self, del_plugin):
        cont = QWidget()
        if del_plugin:
            cont.setProperty("ftth_plugin", True)
        v = QVBoxLayout(cont)
        cb = QComboBox()
        cb.addItems(["a", "b", "c"])
        sp = QSpinBox()
        sp.setValue(5)
        v.addWidget(cb)
        v.addWidget(sp)
        return cont, cb, sp

    def test_plugin_non_cambia(self):
        cont, cb, sp = self._campi(True)
        _rotella(cb)
        _rotella(sp)
        self.assertEqual(cb.currentIndex(), 0)
        self.assertEqual(sp.value(), 5)

    def test_fuori_dal_plugin_resta_come_qgis(self):
        cont, cb, sp = self._campi(False)
        self.assertFalse(ROT.del_plugin(cb))


if __name__ == "__main__":
    unittest.main()
