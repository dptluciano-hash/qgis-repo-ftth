"""Test del quadro delle pratiche (logica, senza QGIS)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ftth_quadro as Q  # noqa: E402


def _classifica_finta(rep):
    """Come ftth_screening.classifica_enti_impatto: (modo, {impatto: [(ente, motivo)]})."""
    g = {Q.IMPATTO_RETE: [], Q.IMPATTO_TERRITORIO: [], Q.IMPATTO_IGNOTO: []}
    for e in rep["enti"]:
        g[e["_imp"]].append((e, e.get("_motivo", "")))
    return "tracciato", g


REP = {"comune": {"nome": "Eboli", "provincia": "Salerno", "regione": "Campania"}, "enti": [
    {"ente": "Comune di Eboli", "ruolo": "Ente proprietario del suolo pubblico comunale",
     "_origine": "comune", "_imp": "impatto", "livello": 4},
    {"ente": "Provincia di Salerno", "ruolo": "Strade provinciali", "_origine": "strada",
     "_imp": "impatto", "_motivo": "SP 30: attraversamento", "livello": 3},
    {"ente": "ANAS", "ruolo": "Strade statali", "_origine": "strada", "_imp": "territorio",
     "livello": 1},
    {"ente": "RFI", "ruolo": "Ferrovie", "_origine": "ferrovia", "_imp": "impatto", "livello": 1},
    {"ente": "Consorzio di bonifica", "ruolo": "Reticolo di bonifica", "_origine": "bonifica",
     "_imp": "ignoto", "livello": 2},
    {"ente": "Soprintendenza ABAP Salerno e Avellino", "ruolo": "Soprintendenza (paesaggio)",
     "_origine": "soprintendenza", "_imp": "impatto", "livello": 1,
     "contatti": {"pec": "sabap-sa@pec.cultura.gov.it"}},
    {"ente": "Regione Campania", "ruolo": "Vincolo paesaggistico art. 142",
     "_origine": "vincolo", "_chiave_vincolo": "art142_c", "_imp": "impatto", "livello": 2},
    {"ente": "Ente Parco", "ruolo": "Parco regionale", "_origine": "parchi",
     "_imp": "ignoto", "livello": 2},
    {"ente": "Autorità di bacino", "ruolo": "PAI", "_origine": "idrogeologico",
     "_imp": "territorio", "livello": 2},
]}


class TestQuadro(unittest.TestCase):
    def setUp(self):
        self.q = Q.voci_da_screening(REP, _classifica_finta)

    def test_categorie(self):
        cat = {v["ente"]: v["categoria"] for v in self.q["voci"]}
        self.assertEqual(cat["Comune di Eboli"], "strade")
        self.assertEqual(cat["RFI"], "ferrovie")
        self.assertEqual(cat["Consorzio di bonifica"], "acque")
        self.assertEqual(cat["Regione Campania"], "paesaggio")
        self.assertEqual(cat["Ente Parco"], "natura")
        self.assertEqual(cat["Autorità di bacino"], "idrogeo")

    def test_ordine_e_impatto(self):
        voci = self.q["voci"]
        self.assertEqual(voci[0]["categoria"], "strade")
        strade = [v for v in voci if v["categoria"] == "strade"]
        # prima i toccati dalla rete, in fondo quelli solo presenti nel comune
        self.assertEqual(strade[-1]["ente"], "ANAS")
        self.assertEqual(self.q["comune"], "Eboli")
        self.assertEqual(next(v for v in voci if v["ente"].startswith("Soprint"))["pec"],
                         "sabap-sa@pec.cultura.gov.it")

    def test_stati_e_riepilogo(self):
        stati = {}
        r = Q.riepilogo(self.q, stati)
        self.assertEqual(r["strade"], {"da_presentare": 2, "fatte": 0, "verificare": 0})
        self.assertEqual(r["acque"]["verificare"], 1)
        k = next(v["chiave"] for v in self.q["voci"] if v["ente"] == "RFI")
        stati[k] = {"stato": "generata"}
        self.assertEqual(Q.riepilogo(self.q, stati)["ferrovie"]["fatte"], 1)
        # stati tolti (inviata, autorizzata): nei progetti gia' salvati = generata
        self.assertNotIn("inviata", Q.STATI)
        stati[k] = {"stato": "inviata"}
        voce = next(v for v in self.q["voci"] if v["chiave"] == k)
        self.assertEqual(Q.stato_voce(voce, stati), "generata")
        # senza scelta lo stato è vuoto (lo sceglie l'utente)
        self.assertEqual(Q.stato_voce(voce, {}), "")

    def test_chiave_stabile(self):
        # rifacendo lo screening la chiave (e quindi lo stato) non cambia
        q2 = Q.voci_da_screening(REP, _classifica_finta)
        self.assertEqual([v["chiave"] for v in self.q["voci"]],
                         [v["chiave"] for v in q2["voci"]])


if __name__ == "__main__":
    unittest.main()
