"""Test della scheda Consegna pratiche (logica, senza QGIS)."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ftth_consegna as C  # noqa: E402


def _pdf(path, testo="x"):
    try:
        from pypdf import PdfWriter
    except ImportError:
        try:
            from PyPDF2 import PdfWriter
        except ImportError:
            open(path, "wb").write(b"%PDF-1.4\n%%EOF\n")
            return
    w = PdfWriter()
    w.add_blank_page(width=200, height=200)
    with open(path, "wb") as f:
        w.write(f)


class TestConsegna(unittest.TestCase):
    def test_tipo_file(self):
        self.assertEqual(C.tipo_file("1.0_EBOLI_SS18_art.49.docx"), "istanza")
        self.assertEqual(C.tipo_file("1.1_EBOLI_SS18_PL.pdf"), "planimetria")
        self.assertEqual(C.tipo_file("1.2_EBOLI_SS18_RT+CR.pdf"), "relazione")
        self.assertEqual(C.tipo_file("1.3_EBOLI_SS18_Bollo.docx"), "bollo")
        self.assertEqual(C.tipo_file("1.4_X_MODELLO B.docx"), "allegato")
        self.assertEqual(C.tipo_file("ProcuraFiberCop.pdf"), "procura")
        self.assertEqual(C.tipo_file("Documento identita.pdf"), "documento")
        self.assertEqual(C.tipo_file("1.0_X_art.49.pdf.p7m"), "istanza")

    def test_scegli_pdf_prima_del_word_e_ordine(self):
        nomi = ["1.2_A_RT+CR.docx", "1.2_A_RT+CR.pdf", "1.1_A_PL.pdf", "1.0_A_art.49.docx",
                "1.3_A_Bollo.docx", "~$lock.docx", "note.txt"]
        scelti = C.scegli_file(nomi)
        self.assertEqual([n for n, _t, _x in scelti],
                         ["1.0_A_art.49.docx", "1.2_A_RT+CR.pdf", "1.1_A_PL.pdf",
                          "1.3_A_Bollo.docx"])
        self.assertIn("solo Word", scelti[0][2])
        self.assertEqual(scelti[1][2], "")

    def test_cerca_e_prepara(self):
        with tempfile.TemporaryDirectory() as d:
            ist = os.path.join(d, "Strade", "EBOLI_SS18")
            os.makedirs(ist)
            for n in ("1.0_EBOLI_SS18_art.49.pdf", "1.1_EBOLI_SS18_PL.pdf",
                      "1.2_EBOLI_SS18_RT+CR.pdf", "Procura.pdf"):
                _pdf(os.path.join(ist, n))
            incompleta = os.path.join(d, "RFI", "X")
            os.makedirs(incompleta)
            for n in ("1.0_X_art.49.docx", "1.3_X_Bollo.docx"):
                open(os.path.join(incompleta, n), "wb").write(b"x")
            trovate = C.cerca_istanze(d)
            self.assertEqual([t["nome"] for t in trovate], ["EBOLI_SS18", "X"])
            self.assertEqual(C.stato(trovate[0]), "completa")
            self.assertIn("Imposta di bollo", trovate[0]["verificare"])
            self.assertEqual(C.stato(trovate[1]), "incompleta")
            self.assertIn("Planimetria (PL)", trovate[1]["mancano"])
            r = C.prepara_consegna(trovate[0], os.path.join(d, C.CARTELLA_CONSEGNA))
            self.assertTrue(os.path.isfile(r["pdf"]))
            self.assertEqual(r["pagine"], 3)        # procura non unita
            self.assertTrue(os.path.isfile(os.path.join(r["cartella"], "Procura.pdf")))
            # la cartella Consegna non si rilegge come istanza
            self.assertEqual(len(C.cerca_istanze(d)), 2)


if __name__ == "__main__":
    unittest.main()
