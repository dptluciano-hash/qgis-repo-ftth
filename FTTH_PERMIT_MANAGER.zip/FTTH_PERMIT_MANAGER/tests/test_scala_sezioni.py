# -*- coding: utf-8 -*-
"""Sezioni alla misura vera e ordine dei riquadri tavole come l'etichetta."""
import os
import tempfile
import unittest

from qgis.core import QgsApplication  # noqa: F401  (QGIS già avviato dai test)

try:
    from FTTH_PERMIT_MANAGER import ftth_rfi_layout as L
    from FTTH_PERMIT_MANAGER import ftth_tavole_mappa as TM
except ImportError:  # pragma: no cover
    import ftth_rfi_layout as L
    import ftth_tavole_mappa as TM


def _svg(w, h):
    fd, p = tempfile.mkstemp(suffix=".svg")
    with os.fdopen(fd, "w") as fh:
        fh.write('<?xml version="1.0"?>\n<svg xmlns="http://www.w3.org/2000/svg" '
                 'width="%s" height="%s" viewBox="0 0 10 10"></svg>' % (w, h))
    return p


class _Box:
    def __init__(self):
        self.chiamate = []


class TestScalaSezioni(unittest.TestCase):
    def setUp(self):
        self.vecchio = L._immagine
        self.box = _Box()
        L._immagine = lambda *a: self.box.chiamate.append(a[2:7])

    def tearDown(self):
        L._immagine = self.vecchio

    def test_misure(self):
        self.assertEqual(L.misura_mm(_svg("120mm", "50mm")), (120.0, 50.0))
        w, h = L.misura_mm(_svg("12cm", "1in"))
        self.assertAlmostEqual(w, 120.0)
        self.assertAlmostEqual(h, 25.4)
        self.assertIsNone(L.misura_mm(_svg("100%", "100%")))

    def test_centrata_non_ingrandita(self):
        msg = []
        f = L.immagine_in_scala(None, 1, 10, 20, 196, 148, _svg("120mm", "50mm"), msg.append)
        self.assertEqual(f, 1.0)
        self.assertEqual(msg, [])
        x, y, w, h, _p = self.box.chiamate[0]
        self.assertAlmostEqual(w, 120.0)
        self.assertAlmostEqual(h, 50.0)
        self.assertAlmostEqual(x, 10 + 38.0)
        self.assertAlmostEqual(y, 20 + 49.0)

    def test_troppo_grande_ridotta_con_avviso(self):
        msg = []
        f = L.immagine_in_scala(None, 1, 0, 0, 100, 100, _svg("200mm", "50mm"), msg.append)
        self.assertAlmostEqual(f, 0.5)
        self.assertTrue(msg and "50%" in msg[0])

    def test_etichetta_riquadro_mostra_n(self):
        from qgis.core import (QgsExpression, QgsExpressionContext, QgsFeature, QgsField,
                               QgsFields)
        from qgis.PyQt.QtCore import QVariant
        fs = QgsFields()
        fs.append(QgsField("tavola", QVariant.String))
        fs.append(QgsField("n", QVariant.Int))
        f = QgsFeature(fs)
        f["tavola"] = "TAV. 18 - 1:1000 - SP31"
        f["n"] = 19
        ctx = QgsExpressionContext()
        ctx.setFeature(f)
        self.assertEqual(QgsExpression(TM.ESPR_ETICHETTA).evaluate(ctx),
                         "TAV. 19 - 1:1000 - SP31")

    def test_istanze_accorpate_nel_progetto(self):
        from qgis.core import QgsProject
        try:
            from FTTH_PERMIT_MANAGER import ftth_acque_layout as AL
        except ImportError:  # pragma: no cover
            import ftth_acque_layout as AL
        prj = QgsProject.instance()
        AL.imposta_accorpate(prj, ["SP31"], True)
        self.assertIn("SP31", AL.istanze_accorpate(prj))
        AL.imposta_accorpate(prj, ["SP31"], False)
        self.assertNotIn("SP31", AL.istanze_accorpate(prj))

    def test_numero_etichetta(self):
        self.assertEqual(TM.numero_etichetta("TAV. 18 - 1:1000 - SP31"), 18)
        self.assertEqual(TM.numero_etichetta("tav 9"), 9)
        self.assertEqual(TM.numero_etichetta("19"), 19)
        self.assertIsNone(TM.numero_etichetta("riquadro"))
        self.assertIsNone(TM.numero_etichetta(None))


if __name__ == "__main__":
    unittest.main()
