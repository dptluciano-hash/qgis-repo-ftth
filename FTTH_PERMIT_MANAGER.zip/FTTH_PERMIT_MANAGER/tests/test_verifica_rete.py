import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from shapely.geometry import LineString  # noqa: E402
import ftth_verifica_rete as VR  # noqa: E402

MY = 1 / 110540.0
MX = 1 / (111320.0 * 0.7593)


def L(*pts):
    return LineString([(15.0 + x * MX, 40.6 + y * MY) for x, y in pts])


class TestVerificaRete(unittest.TestCase):
    def setUp(self):
        self.osm = VR.elementi_osm([
            {"type": "way", "tags": {"railway": "rail", "name": "Linea X"},
             "geometry": [{"lon": 15.0, "lat": 40.6}, {"lon": 15.0 + 500 * MX, "lat": 40.6}]},
            {"type": "way", "tags": {"waterway": "ditch"},
             "geometry": [{"lon": 15.0 + 200 * MX, "lat": 40.6 - 100 * MY},
                          {"lon": 15.0 + 200 * MX, "lat": 40.6 + 100 * MY}]},
            {"type": "way", "tags": {"highway": "primary", "ref": "SS 18"},
             "geometry": [{"lon": 15.0, "lat": 40.6 + 60 * MY},
                          {"lon": 15.0 + 500 * MX, "lat": 40.6 + 60 * MY}]},
        ])

    def test_categorie(self):
        self.assertEqual(sorted(c for c, _n, _g in self.osm), ["acqua", "anas", "ferrovia"])

    def test_analizza(self):
        tratte = [{"fid": 1, "geom": L((100, 20), (150, 20)), "stato": "Nuovo",
                   "tipologia": "Mini trincea"},                     # 20 m dalla ferrovia
                  {"fid": 2, "geom": L((190, 50), (210, 50)), "stato": "Nuovo",
                   "tipologia": "Tradizionale"},                    # attraversa il fosso, 10 m dalla SS
                  {"fid": 3, "geom": L((400, -200), (450, -200)), "stato": "Nuovo",
                   "tipologia": "Tradizionale"}]                    # lontana da tutto
        voci = VR.analizza(tratte, self.osm)
        chiavi = {(v["fid"], v["categoria"]) for v in voci}
        self.assertIn((1, "ferrovia"), chiavi)
        self.assertIn((2, "acqua"), chiavi)
        self.assertIn((2, "anas"), chiavi)
        self.assertFalse(any(v["fid"] == 3 for v in voci))
        acqua = [v for v in voci if v["categoria"] == "acqua"][0]
        self.assertTrue(acqua["attraversa"])
        # soglia a 0: categoria non cercata
        self.assertFalse(any(v["categoria"] == "anas" for v in
                             VR.analizza(tratte, self.osm, {"ferrovia": 30, "acqua": 10, "anas": 0})))

    def test_esiti_csv(self):
        voci = VR.analizza([{"fid": 1, "geom": L((100, 20), (150, 20))}], self.osm)
        es = VR.esiti_da_testo(VR.esiti_in_testo({voci[0]["chiave"]: {"esito": "Da modificare",
                                                                      "nota": "x"}}))
        self.assertEqual(es[voci[0]["chiave"]]["esito"], "Da modificare")
        p = os.path.join(tempfile.mkdtemp(), "v.csv")
        self.assertEqual(VR.scrivi_csv(p, voci, es), len(voci))


if __name__ == "__main__":
    unittest.main()
