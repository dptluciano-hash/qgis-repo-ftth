"""Test delle schede Soprintendenza e Parchi / Natura 2000 (logica, senza QGIS)."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shapely.geometry import LineString, Point, box  # noqa: E402

import ftth_acque as A  # noqa: E402
import ftth_vincoli as V  # noqa: E402

LON0, LAT0 = 15.000, 40.600
M = 1.0 / 111000.0          # circa un metro in gradi (basta per i test)


def _area(tipo, x0, y0, x1, y1, **kw):
    g = box(LON0 + x0 * M * 1.3, LAT0 + y0 * M, LON0 + x1 * M * 1.3, LAT0 + y1 * M)
    return V.AreaVincolo(tipo=tipo, geom=g, ente_tipo=kw.pop("ente_tipo", "soprintendenza"),
                         **kw)


def _linea(x0, y0, x1, y1):
    return LineString([(LON0 + x0 * M * 1.3, LAT0 + y0 * M), (LON0 + x1 * M * 1.3, LAT0 + y1 * M)])


def _punto(x, y):
    return Point(LON0 + x * M * 1.3, LAT0 + y * M)


def _tratta(fid, tecnica, x0, y0, x1, y1, stato="Nuovo"):
    return {"geom": _linea(x0, y0, x1, y1), "stato": stato, "tecnica": tecnica, "fid": fid,
            "lunghezza": None}


STRADE = [(_linea(-500, 0, 2000, 0), "Via Roma"), (_linea(-500, 1000, 2000, 1000), "Via Lago")]


class TestTipi(unittest.TestCase):
    def test_etichette_screening(self):
        self.assertEqual(V.tipo_da_etichetta("Vincolo paesaggistico decretato (art. 136)"),
                         "art136")
        self.assertEqual(V.tipo_da_etichetta(
            "Fascia di rispetto fiumi/corsi d'acqua 150 m (art. 142 c.1 lett. c)"), "art142c")
        self.assertEqual(V.tipo_da_etichetta("Aree boscate ex art. 142 lett. g"), "art142g")
        self.assertEqual(V.tipo_da_etichetta("Natura 2000 — SIC/ZSC"), "natura2000")
        self.assertEqual(V.tipo_da_etichetta("Parco nazionale — Vesuvio"), "parco")

    def test_aree_da_geometrie_uniscono_i_pezzi(self):
        from shapely.geometry import mapping
        f1 = {"geometry": mapping(box(0, 0, 1, 1)), "properties": {"vincolo": "x"}}
        f2 = {"geometry": mapping(box(1, 0, 2, 1)), "properties": {"vincolo": "x"}}
        f3 = {"geometry": mapping(box(5, 5, 6, 6)),
              "properties": {"codice": "IT8050001", "nome": "Sito"}}
        aree = V.aree_da_geometrie([("Fascia costiera 300 m (art. 142 c.1 lett. a)", f1),
                                    ("Fascia costiera 300 m (art. 142 c.1 lett. a)", f2),
                                    ("Natura 2000 — SIC/ZSC", f3)])
        self.assertEqual(len(aree), 2)
        a = [x for x in aree if x.tipo == "art142a"][0]
        self.assertAlmostEqual(a.geom.area, 2.0)
        n = [x for x in aree if x.tipo == "natura2000"][0]
        self.assertEqual(n.scheda(), V.SCHEDA_PARCHI)
        self.assertIn("IT8050001", n.voce())

    def test_descr_vincoli(self):
        self.assertEqual(V.descr_vincoli(["art136", "art142c", "art142a"]),
                         "art. 136 e art. 142 lett. a) e c) del D.Lgs. 42/2004")


class TestInterferenze(unittest.TestCase):
    def setUp(self):
        # area 136 da x 0 a 300, 142c sovrapposta da 200 a 600
        self.aree = [_area("art136", 0, -50, 300, 50), _area("art142c", 200, -50, 600, 50)]
        self.tratte = [_tratta(1, "minitrincea", -200, 0, 100, 0),     # 100 m dentro
                       _tratta(2, "trincea", 100, 0, 500, 0),          # 400 m dentro
                       _tratta(3, "minitrincea", 800, 0, 900, 0),      # fuori
                       _tratta(4, "trincea", 250, 0, 280, 0, stato="Esistente")]
        self.zone = V.zone_per_motore(self.aree, V.SCHEDA_SOPR, "Soprintendenza X")

    def test_una_zona_per_la_soprintendenza(self):
        self.assertEqual(len(self.zone), 1)

    def test_rete_dentro_senza_doppioni(self):
        interf = A.trova_interferenze_acque([], self.tratte, strade=STRADE, zone=self.zone)
        tot = {}
        for i in interf:
            for t, m in i.metri.items():
                tot[t] = tot.get(t, 0) + m
        # 100 m di minitrincea + 400 di trincea; l'esistente e il tratto fuori no
        # (metri convertiti in gradi in modo approssimato: tolleranza del 2%)
        self.assertAlmostEqual(tot.get("minitrincea", 0), 100, delta=2)
        self.assertAlmostEqual(tot.get("trincea", 0), 400, delta=8)
        self.assertTrue(all(i.via == "Via Roma" for i in interf))
        self.assertTrue(all(i.ente_nome == "Soprintendenza X" for i in interf))

    def test_vincoli_e_regime(self):
        interf = A.trova_interferenze_acque([], self.tratte, strade=STRADE, zone=self.zone)
        V.assegna_vincoli(interf, self.aree)
        tipi = {t for i in interf for t in i.vincoli}
        self.assertEqual(tipi, {"art136", "art142c"})
        # con trincea tradizionale serve l'autorizzazione
        self.assertTrue(any(V.regime_soprintendenza(i) == "autorizzazione" for i in interf))

    def test_solo_minitrincea_e_comunicazione(self):
        tr = [_tratta(1, "minitrincea", 10, 0, 90, 0)]
        interf = A.trova_interferenze_acque([], tr, strade=STRADE, zone=self.zone)
        self.assertEqual(len(interf), 1)
        self.assertEqual(V.regime_soprintendenza(interf[0]), "comunicazione")

    def test_giorni_comunicazione(self):
        self.assertEqual(V.giorni_comunicazione(0), 8)
        self.assertEqual(V.giorni_comunicazione(199), 8)
        self.assertEqual(V.giorni_comunicazione(200), 15)
        self.assertEqual(V.giorni_comunicazione(None), 8)

    def test_armadio_senza_scavo_e_interferenza(self):
        arm = [{"geom": _punto(150, 20), "stato": "Nuovo", "id": "A1", "fid": 9}]
        tr = [_tratta(1, "minitrincea", 800, 0, 900, 0)]       # scavo fuori dall'area
        interf = A.trova_interferenze_acque([], tr, armadi=arm, strade=STRADE, zone=self.zone)
        self.assertEqual(len(interf), 1)
        self.assertTrue(any(e["tipo"] == "armadio" for e in interf[0].elementi))
        self.assertEqual(V.regime_soprintendenza(interf[0]), "autorizzazione")

    def test_istanza_e_testi(self):
        interf = A.trova_interferenze_acque([], self.tratte, strade=STRADE, zone=self.zone)
        V.assegna_vincoli(interf, self.aree)
        ist = V.raggruppa_istanze_vincoli(interf, "Eboli", V.SCHEDA_SOPR)
        self.assertEqual(len(ist), 1)
        self.assertTrue(ist[0].nome_base.startswith("EBOLI_SOPR"))
        t = V.testi_istanza_vincoli(ist[0], "Soprintendenza X")
        self.assertIn("Via Roma", t["oggetto"])
        self.assertIn("art. 136", t["oggetto"])
        self.assertEqual(t["ente"], "Soprintendenza X")
        self.assertNotIn("archeolog", t["oggetto"])
        self.assertFalse(V.ha_archeologico(ist[0]))

    def test_testi_archeologici(self):
        interf = A.trova_interferenze_acque([], self.tratte, strade=STRADE, zone=self.zone)
        V.assegna_vincoli(interf, self.aree)
        ist = V.raggruppa_istanze_vincoli(interf, "Eboli", V.SCHEDA_SOPR)[0]
        for i in ist.interferenze:
            i.vincoli = ["art142m"]
        self.assertTrue(V.solo_archeologico(ist))
        t = V.testi_istanza_vincoli(ist)
        self.assertIn("interesse archeologico", t["oggetto"])
        self.assertNotIn("paesaggistica", t["oggetto"])
        self.assertIn("ARCHEOLOGO", V.promemoria_vincoli(
            ist, type("C", (), {"nome": "Eboli", "prov_sigla": "SA"})(), {}, []))
        ist.interferenze[0].vincoli = ["art136", "archeologia"]
        self.assertFalse(V.solo_archeologico(ist))
        t = V.testi_istanza_vincoli(ist)
        self.assertIn("paesaggistica e archeologica", t["oggetto"])


class TestNatura2000(unittest.TestCase):
    def setUp(self):
        self.sito = _area("natura2000", 0, -50, 1000, 1050, ente_tipo="natura2000",
                          codice="IT8050010", nome="Fiume Sele", sottotipo="SIC/ZSC")
        # Via Roma 150 m di scavo (esonero), Via Lago 250 m (VIncA)
        self.tratte = [_tratta(1, "minitrincea", 100, 0, 250, 0),
                       _tratta(2, "minitrincea", 100, 1000, 350, 1000)]
        self.zone = V.zone_per_motore([self.sito], V.SCHEDA_PARCHI)

    def test_regola_200_m_per_via(self):
        interf = A.trova_interferenze_acque([], self.tratte, strade=STRADE, zone=self.zone)
        es = V.esiti_vinca(interf)
        self.assertEqual(es["Via Roma"][1], "esonero")
        self.assertEqual(es["Via Lago"][1], "vinca")
        ist = V.raggruppa_istanze_vincoli(interf, "Eboli", V.SCHEDA_PARCHI)
        esiti = sorted(i.esito for i in ist)
        self.assertEqual(esiti, ["esonero", "vinca"])
        self.assertTrue(any(i.nome_base.endswith("_ESONERO") for i in ist))
        self.assertTrue(all("IT8050010" in i.nome_base for i in ist))

    def test_distanza_dal_sito(self):
        fuori = [_tratta(1, "minitrincea", 1100, 0, 1200, 0)]    # 100 m fuori dal sito
        self.assertEqual(A.trova_interferenze_acque([], fuori, zone=self.zone), [])
        zone = V.zone_per_motore([self.sito], V.SCHEDA_PARCHI, distanza_natura=150)
        self.assertEqual(len(A.trova_interferenze_acque([], fuori, zone=zone)), 1)

    def test_documenti(self):
        try:
            import docx  # noqa: F401
        except ImportError:
            self.skipTest("python-docx non installato")
        import ftth_vincoli_doc as D
        import ftth_rfi as rfi
        interf = A.trova_interferenze_acque([], self.tratte, strade=STRADE, zone=self.zone)
        ist = V.raggruppa_istanze_vincoli(interf, "Eboli", V.SCHEDA_PARCHI)
        com = rfi.DatiComune("Eboli", "SA", "84025")
        with tempfile.TemporaryDirectory() as d:
            for i in ist:
                es = V.esiti_vinca(i.interferenze)
                if i.esito == "esonero":
                    p = D.autodichiarazione_esonero(i, com, {}, "IT8050010 Fiume Sele", es,
                                                    os.path.join(d, "a.docx"))
                else:
                    p = D.format_vinca(i, com, "Campania", "Salerno", "IT8050010", "Fiume Sele",
                                       "SIC/ZSC", None, [], "Zona periurbana", es,
                                       os.path.join(d, "f.docx"))
                testo = "\n".join(par.text for par in docx.Document(p).paragraphs)
                self.assertIn("EBOLI", testo)
                self.assertNotIn("<<", testo)
            # relazione paesaggistica con le lettere spuntate
            aree = [_area("art142c", 0, -50, 600, 50)]
            z = V.zone_per_motore(aree, V.SCHEDA_SOPR)
            interf = A.trova_interferenze_acque([], [_tratta(1, "trincea", 0, 0, 100, 0)],
                                                strade=STRADE, zone=z)
            V.assegna_vincoli(interf, aree)
            ist = V.raggruppa_istanze_vincoli(interf, "Eboli", V.SCHEDA_SOPR)[0]
            p = D.relazione_paesaggistica(ist, com, os.path.join(d, "r.docx"))
            testo = "\n".join(par.text for par in docx.Document(p).paragraphs)
            self.assertIn("%s c) fiumi" % D.SI, testo)
            self.assertIn("%s a) territori costieri" % D.NO, testo)


if __name__ == "__main__":
    unittest.main()
