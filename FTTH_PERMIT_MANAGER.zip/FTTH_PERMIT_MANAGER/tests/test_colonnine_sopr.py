"""Colonnine PTE nuove come elementi fuori terra (Soprintendenza, opzionali)
e particolare costruttivo della colonnina."""
import os
import sys
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_acque as A  # noqa: E402
import ftth_vincoli as V  # noqa: E402


def _interf(n, elementi, metri=None, pozzetti=None, lon=11.9, lat=43.34):
    return A.InterferenzaAcqua(id=n, tipo="area", corso="SOPR", categoria="paesaggio",
                               ente_tipo="soprintendenza", ente_nome="SABAP",
                               metri=metri or {}, pozzetti=pozzetti or {}, lon=lon, lat=lat,
                               elementi=elementi, tratte_fid=[])


COL = {"tipo": "colonnina", "fid": 7, "lon": 11.9, "lat": 43.34}
ARM = {"tipo": "armadio", "fid": 3, "lon": 11.9001, "lat": 43.34}


class TestColonnine(unittest.TestCase):
    def test_togli_colonnine(self):
        sola = _interf(1, [dict(COL)])
        mista = _interf(2, [dict(COL), {"tipo": "scavo", "metri": 5}], metri={"minitrincea": 5})
        con_arm = _interf(3, [dict(COL), dict(ARM)])
        out = V.togli_colonnine([sola, mista, con_arm])
        self.assertEqual([i.id for i in out], [2, 3])
        self.assertFalse(any(e["tipo"] == "colonnina" for i in out for e in i.elementi))
        # gli originali non si toccano (la tabella resta com'era)
        self.assertEqual(len(mista.elementi), 2)

    def test_fuori_terra_e_regime(self):
        i = _interf(1, [dict(COL)])
        self.assertTrue(V.ha_fuori_terra(i))
        self.assertEqual(V.regime_soprintendenza(i), "autorizzazione")
        self.assertIn("colonnina PTE", V.motivo_regime(i))
        # filtra_elementi: la colonnina basta a tenere l'intervento
        self.assertIsNotNone(V.filtra_elementi(i, {"armadi"}))

    def test_solo_armadi_con_colonnine(self):
        ist = A.IstanzaAcqua(numero=1, ente_tipo="soprintendenza", ente_nome="SABAP",
                             interferenze=[_interf(1, [dict(COL)]),
                                           _interf(2, [dict(ARM)], lon=11.95)])
        self.assertTrue(V.solo_armadi(ist, 1))
        self.assertEqual(sorted(e["tipo"] for i in ist.interferenze for e in i.elementi),
                         ["armadio", "colonnina"])
        self.assertEqual(len(ist.tavole), 2)

    def test_etichette(self):
        self.assertEqual(A.testo_elemento_auto(COL), "POSA COLONNINA PTE")
        i = _interf(1, [dict(COL, chiave_el="C|7")])
        self.assertIn("POSA COLONNINA PTE", A.etichetta_automatica(i))
        self.assertEqual(len(A.elementi_etichettabili(i)), 1)

    def test_ricerca_in_zona(self):
        from shapely.geometry import LineString, Point, box
        zona = {"nome": "Vincolo", "categoria": "paesaggio", "ente_tipo": "soprintendenza",
                "ente_nome": "SABAP", "geom": box(11.89, 43.33, 11.91, 43.35), "distanza": 0}
        tratte = [{"geom": LineString([(12.5, 43.0), (12.501, 43.0)]), "stato": "Nuovo",
                   "tecnica": "minitrincea", "fid": 1, "lunghezza": None}]
        col = [{"geom": Point(11.9, 43.34), "stato": "Nuovo", "id": "", "fid": 42}]
        interf = A.trova_interferenze_acque([], tratte, [], [], zone=[zona], colonnine=col)
        el = [e for i in interf for e in i.elementi]
        self.assertEqual([(e["tipo"], e["fid"], e["chiave_el"]) for e in el],
                         [("colonnina", 42, "C|42")])
        # senza colonnine nessun intervento (Acque, Strade… invariati)
        self.assertEqual(A.trova_interferenze_acque([], tratte, [], [], zone=[zona]), [])


class TestParticolareColonnina(unittest.TestCase):
    def test_chiave_solo_su_richiesta(self):
        import ftth_rfi_layout as L
        ist = types.SimpleNamespace(interferenze=[_interf(1, [dict(COL)])])
        self.assertNotIn("colonnina", L.particolari_necessari(ist))
        ist.particolare_colonnina = True
        chiavi = L.particolari_necessari(ist)
        self.assertIn("colonnina", chiavi)
        self.assertEqual(chiavi[-1], "tubi")

    def test_file_nel_plugin(self):
        import ftth_rfi_layout as L
        f = L.cerca_particolare("colonnina", [os.path.join(L.ASSETS, "rfi_particolari")])
        self.assertTrue(f and f.endswith("PC-20_colonnina-pte.svg"))
        w, h = L.dimensioni_svg(f)
        self.assertAlmostEqual(w, 90.0, 1)
        self.assertGreater(h, w)


class TestDescrizione(unittest.TestCase):
    def test_descr_lavori(self):
        try:
            import ftth_vincoli_doc as D
        except ImportError as e:      # python-docx assente
            self.skipTest(str(e))
        ist = types.SimpleNamespace(interferenze=[_interf(1, [dict(COL)]),
                                                  _interf(2, [dict(COL), dict(ARM)])])
        t = D.descr_lavori(ist)
        self.assertIn("2 colonnine PTE", t)
        self.assertIn("1 armadio ottico", t)


class TestRelazioneTecnica(unittest.TestCase):
    """Paragrafo «COLONNINE PTE» nella RT come quello dell'armadio."""

    def _rt(self, elementi):
        try:
            import docx  # noqa: F401
        except ImportError as e:
            self.skipTest(str(e))
        import tempfile
        import ftth_rfi as R
        from docx import Document
        qui = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        ist = A.IstanzaAcqua(numero=1, ente_tipo="soprintendenza", ente_nome="SABAP",
                             interferenze=[_interf(1, elementi, metri={"minitrincea": 10})],
                             nome_base="SOPRINTENDENZA")
        comune = R.DatiComune("Castiglion Fiorentino", "AR", "52043", "", "")
        with tempfile.TemporaryDirectory() as out:
            prod = A.genera_documenti_istanza(ist, comune, {}, os.path.join(qui, "modelli_acque"),
                                              out, solo=("rt",))
            doc = Document(prod["rt"])
            return "\n".join(p.text for p in doc.paragraphs)

    def test_con_colonnina(self):
        t = self._rt([dict(COL)])
        self.assertIn("COLONNINE PTE", t)
        self.assertIn("tettuccio rosso", t)
        self.assertIn("vincoli monumentali", t)
        self.assertNotIn("<<SE_", t)
        self.assertNotIn("ARMADIO OTTICO", t)

    def test_senza_colonnina(self):
        t = self._rt([dict(ARM)])
        self.assertNotIn("COLONNINE PTE", t)
        self.assertIn("ARMADIO OTTICO", t)
        self.assertNotIn("<<SE_", t)


if __name__ == "__main__":
    unittest.main()
