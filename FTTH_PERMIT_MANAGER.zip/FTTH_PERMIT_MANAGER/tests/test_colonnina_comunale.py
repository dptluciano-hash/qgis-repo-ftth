# -*- coding: utf-8 -*-
"""Colonnina PTE nella consegna comunale: capitolo nella RT e pagina del PC."""
import os
import tempfile
import unittest

from qgis.core import QgsProject  # noqa: F401

try:
    from FTTH_PERMIT_MANAGER import ftth_comunale as CM
except ImportError:  # pragma: no cover
    import ftth_comunale as CM


class TestColonninaComunale(unittest.TestCase):
    def test_riquadro_centrato(self):
        x, y, w, h = CM.riquadro_centrato((10, 20, 200, 100), (50, 100))
        self.assertAlmostEqual(h, 100)
        self.assertAlmostEqual(w, 50)
        self.assertAlmostEqual(x + w / 2, 110)
        self.assertAlmostEqual(y + h / 2, 70)

    def test_capitolo_nella_rt(self):
        from docx import Document
        cart = tempfile.mkdtemp()
        tab = {"scavi": None, "pi": None, "pozzetti": None, "armadi": None}
        senza = Document(CM.genera_relazione("Prova", tab, cart))
        self.assertFalse(any(p.text.strip() == "COLONNINA PTE" for p in senza.paragraphs))
        con = Document(CM.genera_relazione("Prova", tab, cart, colonnina=True))
        testi = [p.text.strip() for p in con.paragraphs]
        k = testi.index("COLONNINA PTE")
        self.assertGreater(k, testi.index("ARMADIO OTTICO"))
        self.assertIn("Posa di colonnine PTE.", testi)
        self.assertIn("Posa di armadi ottici;", testi)
        self.assertIn("*Particolari costruttivi allegati al documento PROVA_PL.pdf", testi[k:])
        # stessa formattazione del titolo ARMADIO OTTICO
        arm = con.paragraphs[testi.index("ARMADIO OTTICO")]
        col = con.paragraphs[k]
        self.assertEqual(arm.style.name, col.style.name)

    def test_pagina_pc(self):
        self.assertTrue(CM.file_particolare_colonnina())
        p = os.path.join(tempfile.mkdtemp(), "pc.pdf")
        self.assertEqual(CM.pdf_particolare_colonnina(QgsProject.instance(), p, 420, 297, dpi=72), p)
        self.assertGreater(os.path.getsize(p), 1000)


if __name__ == "__main__":
    unittest.main()
