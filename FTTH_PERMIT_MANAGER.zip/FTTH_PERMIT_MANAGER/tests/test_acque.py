# -*- coding: utf-8 -*-
"""Test della logica Istanze Acque (ftth_acque.py), senza QGIS."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shapely.geometry import LineString, Point, Polygon  # noqa: E402

import ftth_acque as A  # noqa: E402

# un metro in gradi, attorno a lat 45 (Besnate)
LAT0, LON0 = 45.689, 8.770
DY = 1 / 110540.0
DX = 1 / (111320.0 * __import__("math").cos(__import__("math").radians(LAT0)))


def P(x, y):
    """Punto a x,y metri dall'origine, in lon/lat."""
    return (LON0 + x * DX, LAT0 + y * DY)


def L(*pts):
    return LineString([P(*p) for p in pts])


def tratta(geom, tecnica="nodig", stato="Nuovo", fid=1):
    return {"geom": geom, "tecnica": tecnica, "stato": stato, "fid": fid}


class TestClassificazione(unittest.TestCase):
    def test_categoria_osm(self):
        self.assertEqual(A.categoria_osm({"waterway": "river"}), "demanio")
        self.assertEqual(A.categoria_osm({"waterway": "stream"}), "demanio")
        self.assertEqual(A.categoria_osm({"waterway": "ditch"}), "bonifica")
        self.assertEqual(A.categoria_osm({"waterway": "canal"}), "bonifica")

    def test_ente_da_testo(self):
        self.assertEqual(A.ente_da_testo("RIB"), "consorzio")
        self.assertEqual(A.ente_da_testo("RIM"), "comune")
        self.assertEqual(A.ente_da_testo("RIP"), "genio_civile")
        self.assertEqual(A.ente_da_testo("Consorzio Est Ticino Villoresi"), "consorzio")
        self.assertEqual(A.ente_da_testo("Dividente demaniale marittima"), "demanio_marittimo")
        self.assertIsNone(A.ente_da_testo(""))

    def test_da_osm(self):
        els = [
            {"type": "way", "id": 1, "tags": {"waterway": "canal", "name": "Fontanile Vecchio",
                                              "tunnel": "culvert"},
             "geometry": [{"lon": LON0, "lat": LAT0}, {"lon": LON0 + 0.001, "lat": LAT0}]},
            {"type": "way", "id": 2, "tags": {"natural": "coastline"},
             "geometry": [{"lon": LON0, "lat": LAT0}, {"lon": LON0, "lat": LAT0 + 0.001}]},
            {"type": "way", "id": 3, "tags": {"highway": "secondary", "name": "Via Gallarate",
                                              "bridge": "yes"},
             "geometry": [{"lon": LON0, "lat": LAT0}, {"lon": LON0, "lat": LAT0 + 0.001}]},
        ]
        d = A.da_osm(els)
        self.assertEqual(len(d["corsi"]), 2)
        c = d["corsi"][0]
        self.assertTrue(c.tombino)
        self.assertEqual(c.categoria, "bonifica")
        self.assertEqual(d["corsi"][1].categoria, "marittimo")
        self.assertEqual(len(d["ponti"]), 1)
        self.assertEqual(d["strade"][0][1], "Via Gallarate")


class TestInterferenze(unittest.TestCase):
    def setUp(self):
        # canale lungo l'asse x, da -200 a 200 m
        self.canale = A.CorsoAcqua(geom=L((-200, 0), (200, 0)), nome="Fontanile Vecchio",
                                   waterway="canal", categoria="bonifica")

    def test_attraversamento_nodig(self):
        t = tratta(L((0, -30), (0, 30)), "nodig")
        r = A.trova_interferenze_acque([self.canale], [t])
        self.assertEqual(len(r), 1)
        i = r[0]
        self.assertEqual(i.tipo, "attraversamento")
        self.assertEqual(i.tecnica_attr, "nodig")
        self.assertEqual(i.ente_tipo, "consorzio")
        # solo la parte in fascia (canale consortile: 12 m per lato)
        self.assertEqual(i.metri, {"nodig": 24})
        self.assertTrue(i.coord_da and i.coord_a and i.coord_da != i.coord_a)

    def test_tombino(self):
        self.canale.tombino = True
        t = tratta(L((0, -30), (0, 30)), "trincea")
        i = A.trova_interferenze_acque([self.canale], [t])[0]
        self.assertEqual(i.tecnica_attr, "tombino")

    def test_ponte(self):
        t = tratta(L((0, -30), (0, 30)), "trincea")
        ponte = L((2, -15), (2, 15))
        i = A.trova_interferenze_acque([self.canale], [t], ponti=[ponte])[0]
        self.assertEqual(i.tecnica_attr, "ponte")

    def test_cielo_aperto_segnalato(self):
        t = tratta(L((0, -30), (0, 30)), "minitrincea")
        i = A.trova_interferenze_acque([self.canale], [t])[0]
        self.assertEqual(i.tecnica_attr, "cielo_aperto")
        self.assertTrue(i.note)

    def test_esistente_escluso(self):
        t = tratta(L((0, -30), (0, 30)), None, stato="Esistente")
        i = A.trova_interferenze_acque([self.canale], [t])[0]
        self.assertEqual(i.tecnica_attr, "esistente")
        self.assertFalse(i.includi)
        self.assertEqual(i.metri, {})

    def test_parallelismo(self):
        t = tratta(L((-50, 6), (50, 6)), "minitrincea")
        r = A.trova_interferenze_acque([self.canale], [t])
        self.assertEqual(len(r), 1)
        self.assertEqual(r[0].tipo, "parallelismo")
        self.assertAlmostEqual(r[0].dist_min_m, 6.0, delta=0.3)
        self.assertEqual(r[0].metri, {"minitrincea": 100})

    def test_fuori_fascia(self):
        t = tratta(L((-50, 25), (50, 25)), "minitrincea")
        self.assertEqual(A.trova_interferenze_acque([self.canale], [t]), [])

    def test_fascia_consortile_4_12(self):
        # canale consortile: fascia 4-12 m, uno scavo a 11 m è in fascia
        self.assertEqual(A.testo_fascia("bonifica", 12), "4-12 m")
        self.assertEqual(A.testo_fascia("demanio", 10), "10 m")
        t = tratta(L((-50, 11), (50, 11)), "minitrincea")
        self.assertEqual(len(A.trova_interferenze_acque([self.canale], [t])), 1)
        # torrente del demanio: resta 10 m, a 11 m è fuori
        torrente = A.CorsoAcqua(geom=L((-200, 0), (200, 0)), nome="Torrente",
                                waterway="stream", categoria="demanio")
        self.assertEqual(A.trova_interferenze_acque([torrente], [t]), [])

    def test_fascia_personalizzata(self):
        t = tratta(L((-50, 8), (50, 8)), "minitrincea")
        r = A.trova_interferenze_acque([self.canale], [t], fasce={"bonifica": 5})
        self.assertEqual(r, [])

    def test_avvicinamento_unito(self):
        # no-dig che attraversa + minitrincea in fascia attaccata: una sola interferenza
        t1 = tratta(L((0, -9), (0, 9)), "nodig", fid=1)
        t2 = tratta(L((0, 9), (40, 9)), "minitrincea", fid=2)
        r = A.trova_interferenze_acque([self.canale], [t1, t2])
        self.assertEqual(len(r), 1)
        self.assertEqual(set(r[0].metri), {"nodig", "minitrincea"})
        self.assertEqual(r[0].tratte_fid, [1, 2])

    def test_esistente_non_assorbe_nuovi(self):
        t1 = tratta(L((0, -9), (0, 9)), None, stato="Esistente", fid=1)
        t2 = tratta(L((0, 9), (40, 9)), "minitrincea", fid=2)
        r = A.trova_interferenze_acque([self.canale], [t1, t2])
        self.assertEqual(len(r), 2)
        par = next(i for i in r if i.tipo == "parallelismo")
        self.assertTrue(par.includi)
        self.assertEqual(par.metri, {"minitrincea": 40})

    def test_senza_tecnica_non_spuntata(self):
        t = tratta(L((0, -30), (0, 30)), None)
        i = A.trova_interferenze_acque([self.canale], [t])[0]
        self.assertFalse(i.includi)

    def test_pozzetti_in_fascia(self):
        t = tratta(L((0, -30), (0, 30)), "nodig")
        poz = [{"geom": Point(*P(0, 8)), "stato": "Nuovo", "dim": "76x40", "fid": 9},
               {"geom": Point(*P(0, 25)), "stato": "Nuovo", "dim": "76x40", "fid": 10},
               {"geom": Point(*P(0, -8)), "stato": "Esistente", "dim": "76x40", "fid": 11}]
        i = A.trova_interferenze_acque([self.canale], [t], pozzetti=poz)[0]
        # dentro fascia uno solo (quello a 25 m e' fuori, l'esistente non conta)
        self.assertEqual(i.pozzetti, {"76x40": 1})

    def test_via_e_consorzio(self):
        t = tratta(L((0, -30), (0, 30)), "nodig")
        strada = (L((-3, -100), (-3, 100)), "Via Gallarate")
        compr = [{"geom": Polygon([P(-500, -500), P(500, -500), P(500, 500), P(-500, 500)]),
                  "nome": "Consorzio Est Ticino Villoresi"}]
        i = A.trova_interferenze_acque([self.canale], [t], strade=[strada],
                                       comprensori=compr)[0]
        self.assertEqual(i.via, "Via Gallarate")
        self.assertEqual(i.ente_nome, "Consorzio Est Ticino Villoresi")

    def test_alveo_largo(self):
        # fiume con alveo largo 40 m: la fascia parte dalla sponda
        fiume = A.CorsoAcqua(geom=L((-200, 0), (200, 0)), nome="Sele", waterway="river",
                             categoria="demanio")
        alveo = Polygon([P(-200, -20), P(200, -20), P(200, 20), P(-200, 20)])
        t = tratta(L((-50, 27), (50, 27)), "minitrincea")
        senza = A.trova_interferenze_acque([fiume], [t])
        con = A.trova_interferenze_acque([fiume], [t], alvei=[alveo])
        self.assertEqual(senza, [])
        self.assertEqual(len(con), 1)
        self.assertEqual(con[0].ente_tipo, "genio_civile")

    def test_anonimi_separati(self):
        f1 = A.CorsoAcqua(geom=L((-200, 0), (200, 0)), nome="Fosso senza nome",
                          waterway="ditch", categoria="bonifica", con_nome=False)
        f2 = A.CorsoAcqua(geom=L((-200, 300), (200, 300)), nome="Fosso senza nome",
                          waterway="ditch", categoria="bonifica", con_nome=False)
        t = tratta(L((0, -30), (0, 330)), "nodig")
        r = A.trova_interferenze_acque([f1, f2], [t])
        self.assertEqual(len(r), 2)

    def test_marittimo(self):
        costa = A.CorsoAcqua(geom=L((-300, 0), (300, 0)), nome="Demanio marittimo",
                             waterway="coastline", categoria="marittimo")
        t = tratta(L((-100, 20), (100, 20)), "trincea")
        r = A.trova_interferenze_acque([costa], [t])
        self.assertEqual(len(r), 1)
        self.assertEqual(r[0].ente_tipo, "demanio_marittimo")
        self.assertEqual(A.descr_tipo(r[0].tipo, r[0].categoria), "In fascia di competenza")
        # a 40 m e' fuori dai 30 m
        t2 = tratta(L((-100, 40), (100, 40)), "trincea")
        self.assertEqual(A.trova_interferenze_acque([costa], [t2]), [])


class TestEtichette(unittest.TestCase):
    def _verifica(self, ancore, dim, w, h):
        pos = A.disponi_etichette(ancore, dim, w, h)
        box = [(cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2)
               for (cx, cy), (bw, bh) in zip(pos, dim)]
        linee = [(a, A._attacco(a, b)) for a, b in zip(ancore, box)]
        for i in range(len(box)):
            b = box[i]
            self.assertTrue(b[0] >= 0 and b[1] >= 0 and b[2] <= w and b[3] <= h, "fuori")
            for j in range(i + 1, len(box)):
                c = box[j]
                sov = min(b[2], c[2]) - max(b[0], c[0]) > 0 and min(b[3], c[3]) - max(b[1], c[1]) > 0
                self.assertFalse(sov, "etichette %d e %d sovrapposte" % (i, j))
                self.assertFalse(A._seg_incrocia(linee[i][0], linee[i][1],
                                                 linee[j][0], linee[j][1]),
                                 "richiami %d e %d incrociati" % (i, j))
                self.assertFalse(A._seg_box(linee[i][0], linee[i][1], c), "richiamo %d su %d" % (i, j))
                self.assertFalse(A._seg_box(linee[j][0], linee[j][1], b), "richiamo %d su %d" % (j, i))

    def test_grappolo_eboli(self):
        # sei interferenze vicine come in Via Cupe Inferiore (tavola 153x131 mm)
        ancore = [(95, 30), (98, 33), (101, 31), (92, 52), (110, 50), (80, 60)]
        dim = [(48, 9)] * 3 + [(45, 9), (45, 9), (50, 13)]
        self._verifica(ancore, dim, 153, 131)

    def test_non_copre_scavi(self):
        # scavo orizzontale a y=60 e verticale a x=80: le etichette non ci vanno sopra
        linee = [((10, 60), (140, 60), 3000), ((80, 10), (80, 120), 3000)]
        ancore = [(50, 60), (80, 40), (110, 60)]
        dim = [(40, 9)] * 3
        pos = A.disponi_etichette(ancore, dim, 153, 131, linee=linee)
        for a, (cx, cy), (bw, bh) in zip(ancore, pos, dim):
            box = (cx - bw / 2 - 0.8, cy - bh / 2 - 0.8, cx + bw / 2 + 0.8, cy + bh / 2 + 0.8)
            att = A._attacco(a, (cx - bw / 2, cy - bh / 2, cx + bw / 2, cy + bh / 2))
            for q1, q2, _p in linee:
                self.assertFalse(A._seg_tocca_box(q1, q2, box), "etichetta sopra uno scavo")
                self.assertFalse(A._seg_incrocia(a, att, q1, q2), "richiamo che taglia uno scavo")
            self.assertLess(((att[0] - a[0]) ** 2 + (att[1] - a[1]) ** 2) ** 0.5, 28,
                            "richiamo troppo lungo")

    def test_accorpa_solo_vicini(self):
        voci = [(50, 50, "SCAVO TRADIZIONALE Mt 13", "scavo", "SCAVO TRADIZIONALE", "T1"),
                (52, 51, "POSA POZZETTO 40X76", "pozzetto", "40X76", "T1"),
                (53, 49, "POSA POZZETTO 40X76", "pozzetto", "40X76", "T1"),
                (54, 50, "SCAVO MINITRINCEA Mt 26", "scavo", "SCAVO MINITRINCEA", "T2")]
        # separati: un'etichetta per voce
        self.assertEqual(len(A.accorpa_etichette(voci, False)), 4)
        # uniti: solo lo scavo T1 con i suoi pozzetti; lo scavo T2, anche se
        # vicinissimo, resta separato
        r = A.accorpa_etichette(voci, True)
        self.assertEqual(len(r), 2)
        testi = sorted(t for _, _, t in r)
        self.assertEqual(testi[0], "SCAVO MINITRINCEA Mt 26")
        self.assertEqual(testi[1], "SCAVO TRADIZIONALE Mt 13\nPOSA 2 POZZETTI 40X76")
        self.assertEqual([t for x, y, t in r if x == 50][0], testi[1])  # agganciata allo scavo

    def test_allineate(self):
        ancore = [(30 + 12 * k, 65) for k in range(7)]
        self._verifica(ancore, [(40, 9)] * 7, 153, 131)


class TestScreening(unittest.TestCase):
    def test_riepilogo(self):
        vicino = A.CorsoAcqua(geom=L((-200, 0), (200, 0)), nome="Fontanile Vecchio",
                              categoria="bonifica")
        lontano = A.CorsoAcqua(geom=L((-200, 900), (200, 900)), nome="Rio Lontano",
                               categoria="demanio")
        fosso1 = A.CorsoAcqua(geom=L((0, 50), (0, 80)), nome="Fosso senza nome",
                              categoria="bonifica", con_nome=False)
        fosso2 = A.CorsoAcqua(geom=L((50, 50), (50, 80)), nome="Scolina senza nome",
                              categoria="bonifica", con_nome=False, tombino=True)
        rete = [L((-10, -30), (-10, 30))]
        r = A.riepilogo_screening([vicino, lontano, fosso1, fosso2], rete)
        nomi = [g["nome"] for g in r]
        self.assertEqual(nomi[0], "Fontanile Vecchio")
        self.assertEqual(nomi[-1], "Rio Lontano")
        fv = r[0]
        self.assertTrue(fv["in_fascia"] and fv["proposto"])
        self.assertAlmostEqual(fv["km"], 0.4, delta=0.01)
        anon = next(g for g in r if g["nome"] == "Canali e fossi senza nome")
        self.assertEqual(anon["tratti"], 2)
        self.assertEqual(anon["tombini"], 1)
        rio = r[-1]
        self.assertFalse(rio["proposto"])
        self.assertEqual(rio["ente_tipo"], "genio_civile")

    def test_senza_progetto(self):
        c = A.CorsoAcqua(geom=L((0, 0), (100, 0)), nome="Canale", categoria="bonifica")
        r = A.riepilogo_screening([c], [])
        self.assertIsNone(r[0]["dist_m"])
        self.assertFalse(r[0]["proposto"])

    def test_siti(self):
        s = A.siti_utili("Eboli", "SA", "Campania", "https://sit2.regione.campania.it/")
        titoli = [t for t, _, _ in s]
        self.assertEqual(titoli[0], "Geoportale della Regione Campania")
        self.assertTrue(any("consorzio+di+bonifica+Eboli+SA" in u for _, u, _ in s))


class TestIstanze(unittest.TestCase):
    def test_una_istanza_per_ente(self):
        mk = lambda n, et, en, inc=True: A.InterferenzaAcqua(  # noqa: E731
            id=n, tipo="attraversamento", corso="C%d" % n, categoria="bonifica",
            ente_tipo=et, ente_nome=en, includi=inc, via="Via %d" % n)
        interf = [mk(1, "consorzio", "Consorzio Est Ticino Villoresi"),
                  mk(2, "consorzio", "Consorzio Est Ticino Villoresi"),
                  mk(3, "genio_civile", ""),
                  mk(4, "comune", "", inc=False)]
        for i in interf[:2]:
            i.corso = "Fontanile Vecchio"
        ist = A.raggruppa_istanze_acque(interf, "Besnate")
        self.assertEqual(len(ist), 2)
        nomi = sorted(i.nome_base for i in ist)
        self.assertEqual(nomi, ["BESNATE_CONS EST TICINO VILLORESI_FONTANILE VECCHIO",
                                "BESNATE_GENIO CIVILE_C3"])
        self.assertEqual(A.sigla_ente("consorzio", "Consorzio di Bonifica in Destra del Fiume Sele"),
                         "CB DESTRA FIUME SELE")
        self.assertEqual(A.sigla_ente("demanio_marittimo", ""), "DEMANIO MARITTIMO")
        cons = next(i for i in ist if i.ente_tipo == "consorzio")
        self.assertEqual(cons.corso, "Fontanile Vecchio")
        self.assertEqual(sorted(cons.vie()), ["Via 1", "Via 2"])

    def test_un_corso_una_istanza(self):
        mk = lambda n, corso, lat: A.InterferenzaAcqua(  # noqa: E731
            id=n, tipo="attraversamento", corso=corso, categoria="bonifica",
            ente_tipo="consorzio", ente_nome="CB", lat=lat, lon=8.77,
            bbox=(8.7699, lat - 0.0001, 8.7701, lat + 0.0001))
        interf = [mk(1, "Canale A", 45.0), mk(2, "Canale B", 45.0),
                  mk(3, "Fosso senza nome", 45.0), mk(4, "Scolina senza nome", 45.1)]
        ist = A.raggruppa_istanze_acque(interf, "X")
        corsi = sorted(i.corso for i in ist)
        self.assertEqual(corsi, ["Canale A", "Canale B", "Canali e fossi senza nome"])
        anon = next(i for i in ist if i.corso.startswith("Canali"))
        # le due interferenze senza nome sono lontane 11 km: due tavole
        self.assertEqual(len(anon.tavole), 2)

    def test_istanza_unica_per_ente(self):
        mk = lambda n, corso, lat: A.InterferenzaAcqua(  # noqa: E731
            id=n, tipo="attraversamento", corso=corso, categoria="bonifica",
            ente_tipo="consorzio", ente_nome="CB", lat=lat, lon=8.77,
            bbox=(8.7699, lat - 0.0001, 8.7701, lat + 0.0001))
        interf = [mk(1, "Canale A", 45.0), mk(2, "Canale B", 45.01),
                  mk(3, "Fosso senza nome", 45.02)]
        ist = A.raggruppa_istanze_acque(interf, "X", per_corso=False)
        self.assertEqual(len(ist), 1)
        self.assertEqual(ist[0].nome_base, "X_CB")
        self.assertEqual(ist[0].corsi_chiavi, ["Canale A", "Canale B",
                                               "Canali e fossi senza nome"])
        self.assertEqual(len(ist[0].tavole), 3)

    def test_tavole_per_zona(self):
        mk = lambda n, lat, lon: A.InterferenzaAcqua(  # noqa: E731
            id=n, tipo="attraversamento", corso="C", categoria="bonifica",
            ente_tipo="consorzio", lat=lat, lon=lon,
            bbox=(lon - 0.0002, lat - 0.0002, lon + 0.0002, lat + 0.0002))
        # due vicine (50 m) e una a 2 km
        interf = [mk(1, 45.0, 8.0), mk(2, 45.0004, 8.0), mk(3, 45.02, 8.0)]
        tav = A.tavole_per_zona(interf)
        self.assertEqual(len(tav), 2)
        self.assertEqual(sorted(len(t) for t in tav), [1, 2])
        # numerazione da nord: la piu' a nord e' la tavola 1
        self.assertEqual(interf[2].tavola, 1)

    def test_relazione_per_tavola(self):
        mk = lambda n, lat, via, m: A.InterferenzaAcqua(  # noqa: E731
            id=n, tipo="attraversamento", corso="C", categoria="bonifica",
            ente_tipo="consorzio", ente_nome="CB", lat=lat, lon=8.0, via=via,
            metri=m, pozzetti={"76x40": 1},
            bbox=(7.9998, lat - 0.0002, 8.0002, lat + 0.0002))
        interf = [mk(1, 45.0, "Via A", {"nodig": 10}), mk(2, 45.0004, "Via B", {"trincea": 5})]
        ist = A.raggruppa_istanze_acque(interf, "X")[0]
        tr = A.tratte_istanza(ist)
        self.assertEqual(len(tr), 1)
        self.assertEqual(tr[0].metri, {"nodig": 10, "trincea": 5})
        self.assertEqual(tr[0].pozzetti, {"76x40": 2})
        self.assertIn("(Tavola 1)", tr[0].descrizione())


class TestTesti(unittest.TestCase):
    def _ist(self, interf, et="consorzio", en="Consorzio Est Ticino Villoresi"):
        return A.IstanzaAcqua(numero=1, ente_tipo=et, ente_nome=en, interferenze=interf,
                              nome_base="BESNATE_X")

    def _i(self, tipo="attraversamento", corso="Fontanile Vecchio", cat="bonifica",
           via="Via Gallarate", metri=None, pozz=None):
        return A.InterferenzaAcqua(id=1, tipo=tipo, corso=corso, categoria=cat,
                                   ente_tipo="consorzio", via=via, metri=metri or {"nodig": 15},
                                   pozzetti=pozz or {})

    def test_oggetto_besnate(self):
        t = A.testi_istanza(self._ist([self._i()]), "Consorzio Est Ticino Villoresi")
        self.assertEqual(t["oggetto"], "lungo Via Gallarate, nella fascia di rispetto del canale "
                                       "«Fontanile Vecchio», di competenza del Consorzio Est "
                                       "Ticino Villoresi.")
        self.assertEqual(t["titolo"], "IN INTERFERENZA CON IL CANALE «FONTANILE VECCHIO»")

    def test_anonimi_e_misti(self):
        ist = self._ist([self._i(), self._i(tipo="parallelismo", corso="Fosso senza nome",
                                            via="Via Roma")])
        t = A.testi_istanza(ist, "Consorzio di Bonifica Destra Sele")
        self.assertIn("Via Gallarate e Via Roma", t["oggetto"])
        self.assertIn("nella fascia di rispetto del canale «Fontanile Vecchio» e canali e fossi "
                      "del reticolo di bonifica", t["oggetto"])
        self.assertNotIn("CON BONIFICA", t["titolo"])

    def test_marittimo(self):
        i = self._i(corso="Demanio marittimo", cat="marittimo", via="Via Marco Polo")
        t = A.testi_istanza(self._ist([i], "demanio_marittimo", ""),
                            "Regione Siciliana - Demanio Marittimo")
        self.assertEqual(t["oggetto"], "lungo Via Marco Polo, nella fascia di competenza del "
                                       "Demanio Marittimo (Regione Siciliana - Demanio Marittimo).")

    def test_articoli(self):
        self.assertEqual(A.articolo_di("Regione Lombardia"), "della Regione Lombardia")
        self.assertEqual(A.articolo_di("Ufficio del Genio Civile"), "dell'Ufficio del Genio Civile")
        self.assertEqual(A.articolo_di("Consorzio X"), "del Consorzio X")

    def test_tratte_tabella(self):
        ist = self._ist([self._i(pozz={"76x40": 1}),
                         self._i(corso="Fosso senza nome", via="", metri={"trincea": 4})])
        tr = A.tratte_istanza(ist)
        self.assertEqual(tr[0].descrizione(), "Via Gallarate (Tavola 1)")
        self.assertEqual(tr[0].righe_pozzetti, [(tr[0].descrizione(), {"76x40": 1})])
        # senza via: le coordinate al posto del nome generico
        self.assertEqual(tr[1].descrizione(), "Tavola 2\n0.000000, 0.000000")
        self.assertEqual(tr[1].tavola, 2)

    def test_tratte_tabella_coordinate(self):
        a = self._i(pozz={"76x40": 1})
        a.coord_da, a.coord_a = "40.61234567,14.91234567", "40.61290123,14.91301234"
        ist = self._ist([a])
        coord = "inizio 40.612346, 14.912346\nfine 40.612901, 14.913012"
        self.assertEqual(A.tratte_istanza(ist, "via")[0].descrizione(),
                         "Via Gallarate (Tavola 1)")
        self.assertEqual(A.tratte_istanza(ist, "coordinate")[0].descrizione(),
                         "Tavola 1\n%s" % coord)
        tr = A.tratte_istanza(ist, "via_coordinate")[0]
        self.assertEqual(tr.descrizione(), "Via Gallarate (Tavola 1)\n%s" % coord)
        self.assertEqual(tr.righe_pozzetti[0][0], tr.descrizione())

    def test_tavola_senza_lavori_senza_riga(self):
        vuota = self._i(via="Via Vuota")
        vuota.metri = {}                  # solo posa aerea / in infrastruttura esistente
        ist = self._ist([self._i(pozz={"76x40": 1}), vuota])
        tr = A.tratte_istanza(ist)
        self.assertEqual([t.tavola for t in tr], [1])

    def test_etichetta(self):
        i = self._i(pozz={"76x40": 1})
        i.tecnica_attr = "tombino"
        # niente tipologia: solo le lavorazioni
        self.assertEqual(A.testo_etichetta(3, i),
                         "3 - PERFORAZIONE NO DIG Mt 15\nPOSA 1 POZZETTO 76X40")
        i.etichetta = "ATTRAVERSAMENTO CANALE\nNO DIG Mt 15"
        self.assertEqual(A.testo_etichetta(3, i), "3 - ATTRAVERSAMENTO CANALE\nNO DIG Mt 15")

    def test_testi_per_elemento(self):
        # due tratte attaccate della stessa tecnica = uno scavo continuo con
        # chiave stabile; il testo corretto torna dopo una nuova ricerca
        canale = A.CorsoAcqua(geom=L((-200, 0), (200, 0)), nome="Canale", categoria="bonifica")
        t1 = tratta(L((0, -9), (0, 0)), "nodig", fid=1)
        t2 = tratta(L((0, 0), (0, 9)), "nodig", fid=2)
        poz = [{"geom": Point(*P(0, 9)), "stato": "Nuovo", "dim": "76x40", "dim_testo": "40x76",
                "fid": 7}]
        r = A.trova_interferenze_acque([canale], [t1, t2], pozzetti=poz)
        el = A.elementi_etichettabili(r[0])
        scavi = [e for e in el if e["tipo"] == "scavo"]
        self.assertEqual(len(scavi), 1)
        self.assertEqual(scavi[0]["chiave_el"], "S|nodig|1,2")
        pz = [e for e in el if e["tipo"] == "pozzetto"][0]
        self.assertEqual(pz["gruppo"], scavi[0]["gruppo"])            # pozzetto del suo scavo
        self.assertEqual(A.testo_elemento_auto(pz), "POSA POZZETTO 40X76")
        scavi[0]["testo"] = "PERFORAZIONE SOTTO IL CANALE Mt 18"
        salvati = A.testi_modificati(r)
        r2 = A.trova_interferenze_acque([canale], [t1, t2], pozzetti=poz)
        self.assertEqual(A.riapplica_testi(r2, *salvati), 0)
        s2 = [e for e in A.elementi_etichettabili(r2[0]) if e["tipo"] == "scavo"][0]
        self.assertEqual(s2["testo"], "PERFORAZIONE SOTTO IL CANALE Mt 18")
        # una tratta in piu' che parte DAL POZZETTO e' uno scavo a se' (il
        # pozzetto spezza lo scavo continuo): il testo corretto resta
        t3 = tratta(L((0, 9), (5, 9)), "nodig", fid=3)
        r3 = A.trova_interferenze_acque([canale], [t1, t2, t3], pozzetti=poz)
        self.assertEqual(A.riapplica_testi(r3, *salvati), 0)
        chiavi = sorted(e["chiave_el"] for i in r3 for e in A.elementi_etichettabili(i)
                        if e["tipo"] == "scavo")
        self.assertEqual(chiavi, ["S|nodig|1,2", "S|nodig|3"])
        # se invece la tratta in piu' si attacca dove non c'e' pozzetto, lo
        # scavo cambia: il testo si perde ed e' segnalato
        t4 = tratta(L((0, -9), (-5, -9)), "nodig", fid=4)
        r4 = A.trova_interferenze_acque([canale], [t1, t2, t4], pozzetti=poz)
        self.assertEqual(A.riapplica_testi(r4, *salvati), 1)

    def test_accorpa_con_testo_modificato(self):
        voci = [(50, 50, "PERFORAZIONE SOTTO IL CANALE", "scavo_mod", "PERFORAZIONE NO DIG", "S1"),
                (52, 51, "POSA POZZETTO 40X76", "pozzetto", "40X76", "S1")]
        r = A.accorpa_etichette(voci, True)
        self.assertEqual(r, [(50, 50, "PERFORAZIONE SOTTO IL CANALE\nPOSA POZZETTO 40X76")])

    def test_sezione_tipo(self):
        i = self._i()
        i.tecnica_attr = "tombino"
        nomi, tit, _ = A.sezione_tipo(i, {"sezione_nodig": "PC-12"})
        self.assertEqual(tit, "SEZIONE TIPO ATTRAVERSAMENTO SOPRA IL TOMBINO")
        self.assertEqual(nomi, ["sezione_tipo_tombino", "sezione_nodig", "PC-12"])


class TestMarittimo(unittest.TestCase):
    """Fascia del demanio marittimo solo verso terra; metri in fascia dal disegno."""
    # costa OSM verso est: per convenzione OSM la terra e' a sinistra (nord)
    COSTA = LineString([(0, 0), (200, 0)])

    def test_costa_osm_solo_lato_terra(self):
        zona, ori = A.zona_marittima_m([(self.COSTA, True)], 30)
        self.assertTrue(ori)
        self.assertTrue(zona.contains(Point(100, 20)))
        self.assertFalse(zona.contains(Point(100, -20)))     # mare: niente fascia
        self.assertFalse(zona.contains(Point(100, 40)))

    def test_dividente_spiaggia_piu_30_m(self):
        for div in (LineString([(0, 40), (200, 40)]), LineString([(200, 40), (0, 40)])):
            zona, ori = A.zona_marittima_m([(div, False)], 30, [self.COSTA])
            self.assertTrue(ori)
            self.assertTrue(zona.contains(Point(100, 20)))   # spiaggia demaniale
            self.assertTrue(zona.contains(Point(100, 60)))   # entro 30 m dalla dividente
            self.assertFalse(zona.contains(Point(100, 80)))
            self.assertFalse(zona.contains(Point(100, -10)))  # mare

    def test_dividente_senza_costa(self):
        zona, ori = A.zona_marittima_m([(LineString([(0, 40), (200, 40)]), False)], 30)
        self.assertFalse(ori)
        self.assertTrue(zona.contains(Point(100, 60)))

    def test_lunghezza_incoerente_ignorata(self):
        t = {"gm": LineString([(0, 0), (11, 0)]), "lunghezza": 60}
        self.assertEqual(A._fattore_lunghezza(t), 1.0)
        t["lunghezza"] = 11.5
        self.assertAlmostEqual(A._fattore_lunghezza(t), 11.5 / 11)

    def test_metri_in_fascia_scavo_parziale(self):
        # scavo di 100 m perpendicolare alla costa, di cui 30 in fascia; il
        # campo LUNGHEZZA (60) e' sbagliato: contano i metri disegnati
        costa = A.CorsoAcqua(geom=LineString([(14.0, 40.0), (14.01, 40.0)]),
                             nome="Demanio marittimo", categoria="marittimo",
                             fonte=A.FONTE_OSM)
        dy = 100 / 111320.0
        tratta = {"geom": LineString([(14.005, 40.0 + dy * 0.0001), (14.005, 40.0 + dy)]),
                  "stato": "Nuovo", "tecnica": "microtrincea", "fid": 1, "lunghezza": 60}
        i = A.trova_interferenze_acque([costa], [tratta], fasce={"marittimo": 30})
        self.assertEqual(len(i), 1)
        self.assertTrue(28 <= sum(i[0].metri.values()) <= 31, i[0].metri)
        self.assertTrue(any("LUNGHEZZA" in n for n in i[0].note))


if __name__ == "__main__":
    unittest.main()
