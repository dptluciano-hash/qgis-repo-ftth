"""PDF senza l'etichetta Microsoft Purview che Word aggiunge salvando."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_rfi as R  # noqa: E402


class TestPulisciPdf(unittest.TestCase):
    def test_toglie_etichetta(self):
        try:
            from pypdf import PdfReader, PdfWriter
        except ImportError as e:
            self.skipTest(str(e))
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "rt.pdf")
            w = PdfWriter()
            w.add_blank_page(595, 842)
            w.add_blank_page(595, 842)
            w.add_metadata({"/Title": "Relazione", "/MSIP_Label_abc_Enabled": "true"})
            with open(p, "wb") as fh:
                w.write(fh)
            self.assertEqual(R.pulisci_pdf(p), "pulito")
            r = PdfReader(p)
            self.assertEqual(len(r.pages), 2)
            self.assertNotIn("/MSIP_Label_abc_Enabled", r.metadata)
            self.assertEqual(r.metadata.get("/Title"), "Relazione")
            self.assertEqual(R.pulisci_pdf(p), "")          # gia' pulito

    def test_pdf_cifrato_non_si_tocca(self):
        """Involucro Purview (pagina d'avviso + documento cifrato dentro): prima
        veniva ricostruito e restava solo l'avviso."""
        try:
            from pypdf import PdfWriter
        except ImportError as e:
            self.skipTest(str(e))
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "rt.pdf")
            w = PdfWriter()
            w.add_blank_page(595, 842)
            w.add_metadata({"/MSIP_Label_abc_Enabled": "true"})
            w.add_attachment("message.rpmsg", b"cifrato")
            w._root_object[__import__("pypdf").generic.NameObject("/EncryptedPayload")] = \
                __import__("pypdf").generic.NameObject("/MicrosoftIRMServices")
            with open(p, "wb") as fh:
                w.write(fh)
            with open(p, "rb") as fh:
                prima = fh.read()
            self.assertTrue(R.pdf_protetto(p))
            self.assertEqual(R.pulisci_pdf(p), "protetto")
            with open(p, "rb") as fh:
                self.assertEqual(fh.read(), prima)

    def test_pdf_senza_etichetta_non_si_tocca(self):
        try:
            from pypdf import PdfWriter
        except ImportError as e:
            self.skipTest(str(e))
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "pl.pdf")
            w = PdfWriter()
            w.add_blank_page(100, 100)
            with open(p, "wb") as fh:
                w.write(fh)
            prima = os.path.getmtime(p)
            self.assertEqual(R.pulisci_pdf(p), "")
            self.assertEqual(os.path.getmtime(p), prima)


if __name__ == "__main__":
    unittest.main()
