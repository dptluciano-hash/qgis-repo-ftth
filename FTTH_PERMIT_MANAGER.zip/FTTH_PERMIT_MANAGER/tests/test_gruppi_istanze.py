"""Gruppi di layer per istanza: parte senza QGIS (fid, nomi, elementi aggiunti)."""
import os
import sys
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ftth_gruppi_istanze as GR  # noqa: E402


def _ist(**kw):
    i1 = types.SimpleNamespace(tratte_fid=[3, 5, None], elementi=[
        {"tipo": "pozzetto", "fid": 7}, {"tipo": "pozzetto_fuori", "fid": "8"},
        {"tipo": "armadio", "fid": 2}, {"tipo": "ingresso", "fid": 99}])
    i2 = types.SimpleNamespace(tratte_fid=[5, 6], elementi=[])
    base = dict(nome_base="DERUTA_SS45", corso="SS45", ente_nome="ANAS S.p.A.",
                interferenze=[i1, i2])
    base.update(kw)
    return types.SimpleNamespace(**base)


class TestGruppi(unittest.TestCase):
    def test_fid(self):
        f = GR.fid_istanza(_ist())
        self.assertEqual(f["tratte"], {3, 5, 6})
        self.assertEqual(f["pozzetti"], {7, 8})
        self.assertEqual(f["armadi"], {2})

    def test_solo_armadi_usa_interferenze_pl(self):
        pl = [types.SimpleNamespace(tratte_fid=[1], elementi=[{"tipo": "armadio", "fid": 4}])]
        f = GR.fid_istanza(_ist(interferenze_pl=pl))
        self.assertEqual(f["tratte"], {1})
        self.assertEqual(f["armadi"], {4})

    def test_etichette(self):
        self.assertEqual(GR.etichetta("strade", _ist()), "SS45 — ANAS S.p.A.")
        self.assertEqual(GR.etichetta("acque", _ist(corso="Canale Villoresi")),
                         "Canale Villoresi")
        rfi = types.SimpleNamespace(nome_base="X", linea="Linea Milano-Venezia",
                                    tipologia="D", stazione="Brescia", interferenze=[])
        self.assertEqual(GR.etichetta("rfi", rfi), "Linea Milano-Venezia — Tipo D — Brescia")
        self.assertEqual(GR.etichetta("sopr", _ist(corso="")), "DERUTA_SS45")

    def test_tabella(self):
        self.assertEqual(GR.tabella("strade", "DERUTA_SS 3-bis", "tratte"),
                         "strade_deruta_ss_3_bis_tratte")


class TestElementiAggiunti(unittest.TestCase):
    """Gli elementi aggiunti al gruppo prendono l'interferenza della ricerca."""

    def _tutte(self):
        a = types.SimpleNamespace(id=1, tratte_fid=[10, 11], elementi=[], lon=0, lat=0)
        b = types.SimpleNamespace(id=2, tratte_fid=[20], lon=1, lat=1,
                                  elementi=[{"tipo": "pozzetto", "fid": 70}])
        c = types.SimpleNamespace(id=3, tratte_fid=[30], elementi=[], lon=2, lat=2)
        return [a, b, c]

    def test_interferenze_per_elementi(self):
        tutte = self._tutte()
        trovate, fuori = GR.interferenze_per_elementi(
            tutte, {"tratte": {11, 99}, "pozzetti": {70}, "armadi": set()})
        self.assertEqual([i.id for i in trovate], [1, 2])
        self.assertEqual(fuori["tratte"], {99})       # fuori dalle zone: 0 m
        self.assertEqual(fuori["pozzetti"], set())

    def test_tavola_piu_vicina(self):
        tutte = self._tutte()
        ist = types.SimpleNamespace(tavole=[[tutte[0]], [tutte[2]]])
        nuova = types.SimpleNamespace(lon=1.9, lat=2.1)
        GR._aggiungi_alla_tavola(ist, nuova)
        self.assertIn(nuova, ist.tavole[1])

    def test_ristretta_agli_elementi_spostati(self):
        # interferenza con due scavi e due pozzetti: in un'altra istanza va
        # solo lo scavo della tratta 5 e il pozzetto 7 (spostati in mappa)
        i = types.SimpleNamespace(
            tratte_fid=[4, 5], metri={"minitrincea": 30, "tradizionale": 10},
            pozzetti={"40x76": 2},
            elementi=[{"tipo": "scavo", "tecnica": "minitrincea", "metri": 30,
                       "chiave_el": "x|4"},
                      {"tipo": "scavo", "tecnica": "tradizionale", "metri": 10, "fid": 5},
                      {"tipo": "pozzetto", "fid": 7, "dim": "40x76"},
                      {"tipo": "pozzetto", "fid": 8, "dim": "40x76"}])
        j = GR._ristretta(i, {"tratte": {5}, "pozzetti": {7}, "armadi": set()})
        self.assertEqual(j.tratte_fid, [5])
        self.assertEqual(j.metri, {"tradizionale": 10})
        self.assertEqual(j.pozzetti, {"40x76": 1})
        self.assertEqual(len(j.elementi), 2)
        self.assertEqual(i.metri, {"minitrincea": 30, "tradizionale": 10})   # originale intatta


if __name__ == "__main__":
    unittest.main()
