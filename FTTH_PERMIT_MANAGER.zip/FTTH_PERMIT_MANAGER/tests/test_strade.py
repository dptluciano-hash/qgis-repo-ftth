"""Test della sottoscheda Istanze Strade › Genera istanze (logica, senza QGIS)."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from shapely.geometry import LineString  # noqa: E402

import ftth_acque as A  # noqa: E402
import ftth_strade as S  # noqa: E402

LON0, LAT0 = 12.05, 43.12
M = 1.0 / 111000.0


def _l(x0, y0, x1, y1):
    return LineString([(LON0 + x0 * M * 1.37, LAT0 + y0 * M), (LON0 + x1 * M * 1.37, LAT0 + y1 * M)])


def _strada():
    return S.Strada(ref="SP306", classe="SP", nome="Via Castiglionese", geom=_l(-500, 0, 1500, 0),
                    ente_nome="Provincia di Perugia", fascia_m=30.0, semi_sede_m=6.0)


class TestStrade(unittest.TestCase):
    def test_km(self):
        self.assertEqual(S.km_da_testo("dal km 11+571 al km 11+583"), ["11+571", "11+583"])
        self.assertEqual(S.km_da_testo("11+756"), ["11+756"])
        self.assertEqual(S.km_intervallo(["11+583", "11+571", "11+580"]), ("11+571", "11+583"))
        self.assertEqual(S.testo_km("11+571", "11+571"), "km 11+571")
        self.assertEqual(S.testo_km("11+571", "11+583"), "dal km 11+571 al km 11+583")

    def test_sede_fascia_attraversamento(self):
        s = _strada()
        tratte = [
            {"geom": _l(100, -20, 100, 20), "stato": "Nuovo", "tecnica": "trincea", "fid": 1},
            {"geom": _l(300, 20, 400, 20), "stato": "Nuovo", "tecnica": "minitrincea", "fid": 2},
            {"geom": _l(600, 200, 700, 200), "stato": "Nuovo", "tecnica": "minitrincea", "fid": 3},
        ]
        interf = A.trova_interferenze_acque([], tratte, zone=S.zone_strada(s))
        zone = {i.categoria for i in interf}
        self.assertEqual(zone, {S.ZONA_SEDE, S.ZONA_FASCIA})
        S.assegna_km(interf, {1: "dal km 11+100 al km 11+100", 2: "dal km 11+300 al km 11+400"},
                     {}, s)
        sede = [i for i in interf if i.categoria == S.ZONA_SEDE]
        self.assertTrue(any(e.get("attraversa") for i in sede for e in i.elementi))
        testi = [e.get("testo") for i in interf for e in i.elementi if e.get("testo")]
        self.assertTrue(any(t.startswith("KM 11+100") for t in testi))
        self.assertTrue(any("SCAVO Minitrincea" in t and t.endswith(" m") for t in testi))
        self.assertFalse(any("IN FASCIA DI RISPETTO" in t or " Mt " in t for t in testi))
        ist = S.raggruppa_istanze_strade(interf, [s], "Castiglione del Lago")
        self.assertEqual(len(ist), 1)
        self.assertEqual(ist[0].nome_base, "CASTIGLIONE DEL LAGO_SP306")
        righe = [tr.descrizione() for tr in S.tratte_rt(ist[0])]
        # Provincia: niente «*» (solo ANAS), a meno della casella nelle avanzate
        self.assertFalse(any(r.endswith("*") for r in righe))
        ist[0].attraversamenti_sempre = True
        righe = [tr.descrizione() for tr in S.tratte_rt(ist[0])]
        self.assertTrue(any(r.endswith("*") for r in righe))
        self.assertTrue(any("(fascia di rispetto)" in r for r in righe))
        import ftth_rfi as rfi
        v = S.valori_strade(ist[0], rfi.DatiComune("Castiglione del Lago", "PG", "06061"))
        self.assertEqual(v["STRADA"], "SP 306")
        self.assertEqual(v["DEST_NOME"], "Provincia di Perugia")
        self.assertIn("km 11+100", v["TRATTI_KM"])

    def test_classe_anas_vale_piu_del_comune(self):
        """Arenzano: Comune con 11.000 ab., ma il centro abitato ANAS è sotto i
        10.000 -> la strada resta ANAS anche dentro (istanze dentro/fuori)."""
        from types import SimpleNamespace as NS
        from shapely.geometry import box
        s = _strada()
        centri = [{"nome": "ARENZANO", "dal": "547+945", "al": "549+120", "sotto_10000": True}]
        dentro = NS(lon=LON0, lat=LAT0, elementi=[{"tipo": "scavo", "km_da": "548+100",
                                                    "km_a": "548+120"}], categoria=S.ZONA_SEDE,
                    note=[])
        fuori = NS(lon=LON0, lat=LAT0, elementi=[{"tipo": "scavo", "km_da": "551+000",
                                                   "km_a": "551+010"}], categoria=S.ZONA_SEDE,
                   note=[])
        S.applica_centri_abitati([dentro, fuori], s, centri_anas=centri, pop_comune=11129)
        self.assertEqual((dentro.centro_abitato, dentro.competenza), ("ARENZANO", "ente"))
        self.assertEqual((fuori.centro_abitato, fuori.competenza), ("", "ente"))
        # perimetro del progetto senza popolazione: vale la classe ANAS, non il Comune
        perim = [(box(LON0 - 0.01, LAT0 - 0.01, LON0 + 0.01, LAT0 + 0.01), "Arenzano", None)]
        x = NS(lon=LON0, lat=LAT0, elementi=[], categoria=S.ZONA_SEDE, note=[])
        S.applica_centri_abitati([x], s, centri_anas=centri, perimetri=perim, pop_comune=11129)
        self.assertEqual(x.competenza, "ente")

    def test_un_cippo_e_verso_anas(self):
        """Un solo cippo + linea ANAS (nel verso dei km crescenti): km su
        tutto l'asse."""
        s = _strada()                                   # asse da x=-500 a x=1500
        from shapely.geometry import Point
        cippo = Point(LON0, LAT0)                       # x=0 -> km 548+000
        prog = S.Progressive(s.geom, [(cippo, 548000)])
        self.assertFalse(prog.ok())
        # linea ANAS disegnata da est a ovest: i km crescono verso ovest
        geo = [[(LON0 + 1000 * M * 1.37, LAT0), (LON0 - 400 * M * 1.37, LAT0)]]
        v = S.verso_da_anas(prog, {"geo": geo})
        self.assertEqual(v, -1.0)
        prog.verso = v
        self.assertTrue(prog.ok())
        km = prog.km(Point(LON0 - 100 * M * 1.37, LAT0))    # 100 m a ovest
        self.assertAlmostEqual(km, 548100, delta=3)

    def test_nomi_istanze_dentro_fuori(self):
        import ftth_gruppi_istanze as GR
        from types import SimpleNamespace as NS
        d = NS(corso="SS1", ente_nome="ANAS S.p.A.", centro="dentro", nome_base="X_SS1_DENTRO_CA")
        f = NS(corso="SS1", ente_nome="ANAS S.p.A.", centro="fuori", nome_base="X_SS1_FUORI_CA")
        self.assertEqual(GR.valore("strade", d), "SS1 - centro abitato")
        self.assertEqual(GR.valore("strade", f), "SS1 - fuori centro abitato")
        self.assertFalse(GR.simili(GR.valore("strade", d), GR.valore("strade", f)))
        self.assertNotEqual(GR.etichetta("strade", d), GR.etichetta("strade", f))

    def test_regione_da_provincia(self):
        import ftth_screening as scr
        self.assertEqual(scr.regione_da_provincia("Genova"), "Liguria")
        self.assertEqual(scr.regione_da_provincia("Città Metropolitana di Genova"), "Liguria")
        self.assertEqual(scr.regione_da_provincia("SA"), "Campania")
        self.assertIsNone(scr.regione_da_provincia(""))

    def test_strada_a_pezzi_senza_buchi(self):
        """SS1 Arenzano: la strada OSM arriva a pezzi; vicino alla giunzione
        (curva) uno scavo a pochi metri dall'asse va trovato."""
        from shapely.geometry import MultiLineString
        a = _l(-300, 0, 0, 0)
        b = _l(0, 0, 200, 200)            # secondo pezzo, a 45 gradi
        s = S.Strada(ref="SS1", classe="SS", nome="Aurelia",
                     geom=MultiLineString([a, b]), ente_nome="ANAS S.p.A.",
                     fascia_m=30.0, semi_sede_m=6.0)
        # scavo all'esterno della curva, a ~5 m dalla giunzione
        tr = [{"geom": _l(3, -4, 6, -2), "stato": "Nuovo", "tecnica": "minitrincea", "fid": 9}]
        interf = A.trova_interferenze_acque([], tr, zone=S.zone_strada(s))
        self.assertTrue(interf)
        self.assertEqual(interf[0].categoria, S.ZONA_SEDE)


class TestUnaRigaPerTratta(unittest.TestCase):
    def test_tratte_consecutive_non_unite(self):
        """Due no-dig attaccati (come 328 e 330 sulla SS71): due righe, non 155 m."""
        s = _strada()
        tratte = [{"geom": _l(100, 3, 210, 3), "stato": "Nuovo", "tecnica": "nodig", "fid": 328},
                  {"geom": _l(210, 3, 255, 3), "stato": "Nuovo", "tecnica": "nodig", "fid": 330}]
        zone = S.zone_strada(s)
        interf = A.trova_interferenze_acque([], tratte, zone=zone)
        S.dividi_scavi_per_tratta(interf, tratte, zone)
        scavi = [e for i in interf for e in i.elementi if e.get("tipo") == "scavo"]
        self.assertEqual(sorted(e["chiave_el"] for e in scavi), ["S|nodig|328", "S|nodig|330"])
        self.assertEqual(sorted(round(e["metri"] / 5) * 5 for e in scavi), [45, 110])


class TestRelazioneStrade(unittest.TestCase):
    def test_tabelle_sede_e_fascia_separate(self):
        try:
            import docx
        except ImportError:
            self.skipTest("python-docx non installato")
        import tempfile
        import ftth_rfi as rfi
        s = _strada()
        tratte = [{"geom": _l(100, -20, 100, 20), "stato": "Nuovo", "tecnica": "trincea",
                   "fid": 1},
                  {"geom": _l(300, 20, 400, 20), "stato": "Nuovo", "tecnica": "minitrincea",
                   "fid": 2}]
        interf = A.trova_interferenze_acque([], tratte, zone=S.zone_strada(s))
        S.assegna_km(interf, {1: "11+100", 2: "dal km 11+300 al km 11+400"}, {}, s)
        qui = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

        def _rt(ente):
            s.ente_nome = ente
            ist = S.raggruppa_istanze_strade(interf, [s], "Castiglione del Lago")[0]
            with tempfile.TemporaryDirectory() as d:
                p = S.genera_rt_strade(ist, rfi.DatiComune("Castiglione del Lago", "PG",
                                                           "06061"),
                                       os.path.join(qui, "modelli_strade"),
                                       os.path.join(d, "rt.docx"), pl_file="PL.pdf",
                                       rt_file="RT.pdf")
                doc = docx.Document(p)
                testo = "\n".join(x.text for x in doc.paragraphs)
                intest = [[c.text for c in t.rows[0].cells] for t in doc.tables[1:]]
                xml = doc.tables[1]._tbl.xml
            return testo, intest, xml
        # Provincia (come la pratica SP306): tabella unica, niente fascia
        testo, intest, xml = _rt("Provincia di Perugia")
        self.assertIn("TABELLA INTERVENTI:", testo)
        self.assertNotIn("FASCIA RISPETTO SCAVI:", testo)
        self.assertNotIn("<<", testo)
        self.assertNotIn("MICROTRINCEA", testo)                  # tecnica assente: via
        self.assertIn("MINITRINCEA", testo)
        self.assertEqual(intest[0], ["Chilometrica", "Minitrincea (m)", "Tradizionale (m)",
                                     "Totale (m)"])
        self.assertIn("0070C0", xml)                             # intestazione blu
        # Provincia: niente «*» né nota sulla trincea (solo ANAS)
        self.assertNotIn("“*” = Scavo tradizionale in attraversamento", testo)
        self.assertNotIn("Si specifica che la tecnica", testo)
        # ANAS (come la pratica SS71): sede e fascia in tabelle separate
        testo, intest, _x = _rt("ANAS S.p.A.")
        self.assertIn("TABELLA NUOVI SCAVI:", testo)
        self.assertIn("FASCIA RISPETTO SCAVI:", testo)
        self.assertNotIn("FASCIA RISPETTO POZZETTI:", testo)     # nessun pozzetto: via
        self.assertIn("“*” = Scavo tradizionale in attraversamento", testo)


class TestProgressiveAutomatiche(unittest.TestCase):
    def test_km_in_metri(self):
        self.assertEqual(S.km_in_metri("11+571"), 11571)
        self.assertEqual(S.km_in_metri("11,571"), 11571)
        self.assertEqual(S.km_in_metri("11.5"), 11500)
        self.assertEqual(S.km_in_metri("12"), 12000)
        self.assertEqual(S.km_in_metri("11571"), 11571)
        self.assertIsNone(S.km_in_metri("abc"))
        self.assertEqual(S.metri_in_km(11571.4), "11+571")

    def test_proiezione_sull_asse_con_tratta_storta(self):
        from shapely.geometry import Point
        s = _strada()
        # cippi al km 10 (x=0) e 11 (x=1000): km crescenti verso est
        rif = [(Point(LON0, LAT0), 10000), (Point(LON0 + 1000 * M * 1.37, LAT0), 11000)]
        prog = S.Progressive(s.geom, rif)
        self.assertTrue(prog.ok())
        # scavo a zig-zag lungo la strada fra x=300 e x=400: conta solo la
        # proiezione degli estremi, non la lunghezza percorsa
        zig = LineString([(LON0 + x * M * 1.37, LAT0 + y * M)
                          for x, y in ((300, 3), (320, -3), (340, 3), (360, -3), (400, 3))])
        tratte = [{"geom": zig, "stato": "Nuovo", "tecnica": "minitrincea", "fid": 1}]
        interf = A.trova_interferenze_acque([], tratte, zone=S.zone_strada(s))
        S.assegna_km_auto(interf, prog)
        e = [e for i in interf for e in i.elementi if e.get("tipo") == "scavo"][0]
        da, a = S.km_in_metri(e["km_da"]), S.km_in_metri(e["km_a"])
        self.assertAlmostEqual(da, 10300, delta=12)
        self.assertAlmostEqual(a, 10400, delta=12)
        # oltre l'ultimo cippo si estrapola nello stesso verso
        self.assertAlmostEqual(prog.km(Point(LON0 + 1200 * M * 1.37, LAT0)), 11200, delta=15)

    def test_centri_abitati(self):
        from shapely.geometry import Point
        s = _strada()
        tratte = [{"geom": _l(100, -20, 100, 20), "stato": "Nuovo", "tecnica": "trincea",
                   "fid": 1},
                  {"geom": _l(300, 20, 400, 20), "stato": "Nuovo", "tecnica": "minitrincea",
                   "fid": 2}]
        interf = A.trova_interferenze_acque([], tratte, zone=S.zone_strada(s))
        perimetro = Point(LON0 + 250 * M * 1.37, LAT0).buffer(400 * M)
        conti = S.applica_centri_abitati(interf, s, perimetri=[(perimetro, "Centro", 15000)])
        self.assertGreater(conti["in_centro"], 0)
        # in fascia dentro il centro abitato: resta (art. 18 CdS), con la nota
        self.assertTrue(all(i.includi for i in interf if i.categoria == S.ZONA_FASCIA))
        sede = [i for i in interf if i.categoria == S.ZONA_SEDE]
        self.assertTrue(all(i.competenza == "comune" for i in sede))
        ist = S.raggruppa_istanze_strade(interf, [s], "Castiglione del Lago",
                                         {"pec": "comune@pec.it"})
        self.assertEqual(ist[0].nome_base, "CASTIGLIONE DEL LAGO_SP306_COMUNE")
        self.assertEqual(ist[0].strada.ente_nome, "Comune di Castiglione del Lago")
        self.assertFalse(ist[0].strada.epc_comune)
        # ANAS: classe sotto 10.000 -> resta all'ente
        for i in interf:
            i.includi = True
            for e in i.elementi:
                e["km_da"] = e["km_a"] = "100+500"
        S.applica_centri_abitati(interf, s, centri_anas=[
            {"nome": "CASTIGLIONE DEL LAGO", "dal": "100+200", "al": "103+670",
             "sotto_10000": True}], pop_comune=15000)
        self.assertTrue(all(i.competenza == "ente" for i in interf))

    def test_due_istanze_dentro_fuori_centro(self):
        """Competenza all'ente anche dentro il centro abitato: due istanze allo
        stesso ente, DENTRO e FUORI centro abitato."""
        s = _strada()
        tratte = [{"geom": _l(100, 2, 200, 2), "stato": "Nuovo", "tecnica": "minitrincea",
                   "fid": 1},
                  {"geom": _l(1200, 2, 1300, 2), "stato": "Nuovo", "tecnica": "minitrincea",
                   "fid": 2}]
        interf = A.trova_interferenze_acque([], tratte, zone=S.zone_strada(s))
        for i in interf:
            for e in i.elementi:
                e["km_da"] = e["km_a"] = "100+500" if i.lon < LON0 + 600 * M * 1.37 else "105+000"
        S.applica_centri_abitati(interf, s, centri_anas=[
            {"nome": "CASTIGLIONE DEL LAGO", "dal": "100+200", "al": "103+670",
             "sotto_10000": True}])
        ist = S.raggruppa_istanze_strade(interf, [s], "Castiglione del Lago")
        nomi = sorted(i.nome_base for i in ist)
        self.assertEqual(nomi, ["CASTIGLIONE DEL LAGO_SP306_DENTRO_CA",
                                "CASTIGLIONE DEL LAGO_SP306_FUORI_CA"])
        self.assertTrue(all(i.strada.ente_nome == "Provincia di Perugia" for i in ist))
        dentro = [i for i in ist if i.centro == "dentro"][0]
        self.assertIn("tratto interno al centro abitato di CASTIGLIONE DEL LAGO",
                      S.specifica_centro(dentro))
        import ftth_rfi as rfi
        v = S.valori_strade(dentro, rfi.DatiComune("Castiglione del Lago", "PG", "06061"))
        self.assertIn("(tratto interno al centro abitato", v["STRADA"])


if __name__ == "__main__":
    unittest.main()
