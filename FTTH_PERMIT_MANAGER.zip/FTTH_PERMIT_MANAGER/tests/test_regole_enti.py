# -*- coding: utf-8 -*-
"""Regole degli enti stradali (Città Metropolitana di Genova) e lettura da file."""
import os
import sys
import tempfile
import unittest
from types import SimpleNamespace as NS

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_regole_enti as RE  # noqa: E402
import ftth_strade as S  # noqa: E402

TESTO_GENOVA = """La domanda per il rilascio dell'autorizzazione/concessione o nulla osta è presentata alla Città Metropolitana di Genova:

In caso di scavo su tratto di strada provinciale ricadente all'interno di centri abitati con popolazione inferiore a 10.000 abitanti, il nulla osta è rilasciato dalla Città Metropolitana di Genova e inviato al Comune competente al rilascio dell'autorizzazione e per conoscenza al soggetto richiedente;
All'istanza occorre allegare la documentazione obbligatoria (timbrata e firmata da tecnico abilitato alla professione) costituita da:
Modulo di istanza in allegato debitamente compilato
planimetria dell'area interessata in scala 1.5000 con evidenziato il luogo dell'intervento;
planimetria quotata in scala 1:100 o 1:200;
sezioni di scavo in scala 1:10 o 1:20 (come da sezione tipo in uso, con profondità minima dal piano viabile all'estradosso del manufatto non inferiore a m 1);
documentazione fotografica panoramica e di dettaglio;
relazione tecnica illustrativa
piano di cantiere con indicazione delle superfici di occupazione suolo pubblico (a tratte lavorate, come da schemi del C.d.S.) e relativa durata;
NOTA: per GRANDI SCAVI di società di servizi pubblici è obbligatorio, prima della presentazione del progetto, richiedere sopralluogo preventivo
Modulorottura-occupazionesuolopubblico1.docx
"""


def _strada(ente="Città Metropolitana di Genova", classe="SP"):
    return S.Strada(ref="SP1", classe=classe, nome="Via Aurelia", ente_nome=ente)


def _ist(centro="", scavi=(("minitrincea", 250.0), ("trincea", 300.0))):
    el = [{"tipo": "scavo", "tecnica": t, "metri": m, "km_da": "1+100", "km_a": "1+350"}
          for t, m in scavi]
    return NS(strada=_strada(), centro=centro, centri=[], corso="SP1",
              interferenze=[NS(id=1, elementi=el)], nome_base="X_SP1")


class TestRegoleGenova(unittest.TestCase):
    def setUp(self):
        RE.PROFILI[:] = RE._PROFILI_BASE

    def test_profilo(self):
        self.assertEqual(RE.profilo_per(_strada(), "GE")["id"], "cm_genova")
        self.assertEqual(RE.profilo_per(_strada(), "")["id"], "cm_genova")   # dal nome
        self.assertIsNone(RE.profilo_per(_strada("Provincia di Savona"), "SV"))
        self.assertIsNone(RE.profilo_per(_strada("Comune di Genova"), "GE"))
        self.assertIsNone(RE.profilo_per(_strada(classe="SS"), "GE"))

    def test_procedura_e_avvisi(self):
        p = RE.PROFILI[0]
        self.assertEqual(RE.procedura(p, _ist("dentro")), "nulla_osta")
        self.assertEqual(RE.procedura(p, _ist("fuori")), "autorizzazione")
        avv = RE.controlli(p, _ist())
        self.assertTrue(any("minitrincea" in a and "1 m" in a for a in avv))
        self.assertTrue(any("sopralluogo" in a for a in avv))       # 550 m >= 500
        self.assertEqual(RE.scala_tavole(p, None), 200)
        self.assertEqual(RE.scala_tavole(p, 100), 100)
        self.assertEqual(RE.scala_tavole(p, 500), 200)

    def test_piano_cantiere(self):
        righe = RE.righe_piano_cantiere(_ist())
        # 250 m -> 3 tratte, 300 m -> 3 tratte
        self.assertEqual(len(righe), 6)
        self.assertAlmostEqual(sum(r["lunghezza"] for r in righe), 550.0)
        d = tempfile.mkdtemp()
        p = RE.scrivi_piano_cantiere(os.path.join(d, "piano.docx"), _ist(),
                                     NS(nome="Rapallo"), RE.PROFILI[0])
        self.assertTrue(os.path.isfile(p))

    def test_istanza_nulla_osta(self):
        from docx import Document
        qui = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        doc = Document(os.path.join(qui, "modelli_strade", "TEMPLATE_1.0_art.49.docx"))
        RE.adatta_istanza(doc, RE.PROFILI[0], _ist("dentro"), "Rapallo")
        testo = "\n".join(p.text for p in doc.paragraphs)
        self.assertIn("Istanza di nulla osta per", testo)
        self.assertIn("trasmettere al Comune di Rapallo", testo)
        self.assertIn("Planimetria quotata in scala 1:200", testo)
        self.assertIn("Piano di cantiere", testo)

    def test_modulo_dentro_fuori(self):
        d = tempfile.mkdtemp()
        for n in ("Modulorottura-occupazionesuolopubblico.docx",
                  "Modulorottura-occupazionesuolopubblico1.docx"):
            open(os.path.join(d, n), "wb").close()
        p = RE.PROFILI[0]
        self.assertTrue(RE.modulo_ente(p, [d], _ist("dentro")).endswith("pubblico1.docx"))
        self.assertTrue(RE.modulo_ente(p, [d], _ist("fuori")).endswith("pubblico.docx"))


class TestRegoleDaFile(unittest.TestCase):
    def tearDown(self):
        RE.PROFILI[:] = RE._PROFILI_BASE

    def test_estrai_genova(self):
        r = RE.estrai_regole(TESTO_GENOVA)
        self.assertEqual(r["nome"], "Città Metropolitana di Genova")
        self.assertEqual(r["classi"], ["SP"])
        self.assertTrue(r["nulla_osta_dentro_ca"])
        self.assertEqual(r["scala_inquadramento"], 5000)
        self.assertEqual(r["scale_tavole_ammesse"], [100, 200])
        self.assertEqual(r["scala_tavole"], 200)
        self.assertEqual(r["scala_sezioni"], "1:10 o 1:20")
        self.assertEqual(r["profondita_min_m"], 1.0)
        self.assertTrue(r["piano_cantiere"])
        self.assertIn("grandi_scavi_m", r)
        self.assertEqual(r["modulo"], "modulorottura-occupazionesuolopubblico1")
        self.assertEqual(len(r["allegati"]), 7)
        self.assertTrue(r["allegati"][2].startswith("Planimetria quotata"))

    def test_salva_e_ricarica(self):
        d = tempfile.mkdtemp()
        p = RE.completa(RE.estrai_regole(TESTO_GENOVA.replace("Genova", "Savona")))
        p["province"] = ("SV",)
        RE.salva_profilo(p, d)
        self.assertEqual(len(RE.PROFILI), 2)
        s = _strada("Provincia di Savona")
        self.assertEqual(RE.profilo_per(s, "SV")["nome"], "Città Metropolitana di Savona")
        # un profilo salvato con lo stesso id sostituisce quello del plugin
        g = dict(RE._PROFILI_BASE[0], scala_tavole=100)
        RE.salva_profilo(g, d)
        self.assertEqual(RE.profilo_per(_strada(), "GE")["scala_tavole"], 100)


if __name__ == "__main__":
    unittest.main()
