"""Canaletta VTR e scritte col trattino nelle relazioni (prima venivano
scartate come la linea aerea)."""
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import ftth_rfi as R  # noqa: E402
import ftth_comunale as C  # noqa: E402

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


class TestRiconoscimento(unittest.TestCase):
    def test_istanze(self):
        casi = {"Canaletta": "canaletta", "Canaletta VTR": "canaletta",
                "CANALA IN VTR/FeZn": "canaletta", "Micro-trincea": "microtrincea",
                "Mini-trincea": "minitrincea", "MINI_TRINCEA": "minitrincea",
                "No-Dig": "nodig", "No  Dig": "nodig", "Tradizionale": "trincea",
                "Aerea": None, "": None, None: None}
        for v, atteso in casi.items():
            self.assertEqual(R.mappa_tecnica(v), atteso, v)

    def test_comunale(self):
        self.assertEqual(C.normalizza_tipologia("Canaletta VTR"), "CANALETTA")
        self.assertEqual(C.normalizza_tipologia("Micro-trincea"), "MICROTRINCEA")
        self.assertEqual(C.normalizza_tipologia("Aerea"), "")

    def test_cronoprogramma_senza_ripristino(self):
        tr = R.Tratta("", "", {"canaletta": 100}, {}, "", [])
        scavo, _pz, rip = R.giorni_tratta(tr)
        self.assertEqual(scavo["canaletta"], 1.0)        # 100 m a 100 m/giorno
        self.assertEqual(rip, 0)                        # niente manto da rifare

    def test_attraversamento_da_decidere(self):
        tip, note = R.classifica_tipologia(True, "Nuovo", "canaletta")
        self.assertEqual(tip, "?")
        self.assertTrue(any("canaletta" in n for n in note))


class TestRelazioneIstanze(unittest.TestCase):
    """RT (modello acque, usato anche da Soprintendenza e Parchi)."""

    def _rt(self, metri):
        try:
            from docx import Document
        except ImportError as e:
            self.skipTest(str(e))
        import ftth_acque as A
        i = A.InterferenzaAcqua(id=1, tipo="area", corso="SOPR", categoria="paesaggio",
                                ente_tipo="soprintendenza", ente_nome="SABAP", metri=metri,
                                pozzetti={}, lon=11.9, lat=43.34, elementi=[], tratte_fid=[])
        ist = A.IstanzaAcqua(numero=1, ente_tipo="soprintendenza", ente_nome="SABAP",
                             interferenze=[i], nome_base="SOPRINTENDENZA")
        comune = R.DatiComune("Comune", "XX", "00000", "", "")
        with tempfile.TemporaryDirectory() as out:
            prod = A.genera_documenti_istanza(ist, comune, {},
                                              os.path.join(QUI, "modelli_acque"), out,
                                              solo=("rt",))
            doc = Document(prod["rt"])
            testo = "\n".join(p.text for p in doc.paragraphs)
            # senza pozzetti la loro tabella sparisce: l'ultima è il cronoprogramma
            scavi = doc.tables[R.RT_TAB_SCAVI]
            crono = doc.tables[-1]
            righe_s = [[c.text.strip() for c in r.cells] for r in scavi.rows]
            righe_c = [[c.text.strip() for c in r.cells] for r in crono.rows]
            return testo, righe_s, righe_c

    def test_con_canaletta(self):
        testo, scavi, crono = self._rt({"minitrincea": 10, "canaletta": 40})
        self.assertIn("CANALA IN VTR", testo)
        piatto = [c for r in scavi for c in r]
        self.assertIn("Canaletta VTR", piatto)
        tot = [r for r in scavi if r and r[0] == "Totale complessivo"][0]
        self.assertIn("40", tot)
        self.assertIn("50", tot)                         # totale 10 + 40
        self.assertIn("Canaletta VTR (m)", [c for r in crono for c in r])

    def test_senza_canaletta(self):
        testo, scavi, _c = self._rt({"minitrincea": 10})
        self.assertNotIn("CANALA IN VTR", testo)
        self.assertNotIn("Canaletta VTR", [c for r in scavi for c in r])


class TestRelazioneComunale(unittest.TestCase):
    def _righe(self, tip):
        return [{"name": "Via Roma", "TIPOLOGIA": tip, "STATO": "Nuovo", "Lungh": 30,
                 "PROPRIETA": "TIM"},
                {"name": "Via Roma", "TIPOLOGIA": "Mini trincea", "STATO": "Nuovo",
                 "Lungh": 20, "PROPRIETA": "TIM"}]

    def _rt(self, tip):
        try:
            from docx import Document
        except ImportError as e:
            self.skipTest(str(e))
        tab = {"scavi": C.tabella_scavi(self._righe(tip))}
        with tempfile.TemporaryDirectory() as out:
            p = C.genera_relazione("Comune", tab, out)
            return tab, "\n".join(x.text for x in Document(p).paragraphs)

    def test_con_canaletta(self):
        tab, testo = self._rt("Canaletta")
        self.assertIn("Canaletta (m)", tab["scavi"]["intest"])
        self.assertIn("CANALA IN VTR", testo)

    def test_senza_canaletta(self):
        tab, testo = self._rt("Micro-trincea")
        self.assertIn("Microtrincea (m)", tab["scavi"]["intest"])
        self.assertNotIn("CANALA IN VTR", testo)


if __name__ == "__main__":
    unittest.main()
