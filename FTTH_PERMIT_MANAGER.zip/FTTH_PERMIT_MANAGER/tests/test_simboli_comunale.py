# -*- coding: utf-8 -*-
"""Simboli del sinottico nella PL comunale: colonnine e armadi per taglia,
applicati solo per l'esportazione e poi tolti."""
import unittest

from qgis.core import QgsFeature, QgsProject, QgsVectorLayer, QgsGeometry, QgsPointXY

try:
    from FTTH_PERMIT_MANAGER import ftth_simboli_comunale as SC
except ImportError:  # pragma: no cover
    import ftth_simboli_comunale as SC


def _layer(nome, campi, righe):
    uri = "Point?crs=EPSG:32632&" + "&".join("field=%s:%s" % c for c in campi)
    l = QgsVectorLayer(uri, nome, "memory")
    fs = []
    for k, r in enumerate(righe):
        f = QgsFeature(l.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(k, k)))
        for c, v in r.items():
            f[c] = v
        fs.append(f)
    l.dataProvider().addFeatures(fs)
    return l


class TestSimboliComunale(unittest.TestCase):
    def setUp(self):
        self.prj = QgsProject.instance()
        self.pte = _layer("ROE PTE", [("TIPO", "string"), ("NewColoninn", "string"),
                                      ("NewBasament", "string")],
                          [{"TIPO": "Colonnina", "NewColoninn": "Si", "NewBasament": "Si"},
                           {"TIPO": "Colonnina", "NewColoninn": None, "NewBasament": "True"},
                           {"TIPO": "Colonnina", "NewColoninn": None, "NewBasament": None},
                           {"TIPO": "Muro Esterno", "NewColoninn": None, "NewBasament": None}])
        self.arm = _layer("ARMADIO OTTICO", [("FO_USCENTI", "integer")],
                          [{"FO_USCENTI": 384}, {"FO_USCENTI": 576}, {"FO_USCENTI": 576}])
        self.prj.addMapLayers([self.pte, self.arm])

    def tearDown(self):
        self.prj.removeMapLayers([self.pte.id(), self.arm.id()])

    def test_trova_layer_e_taglie(self):
        self.assertIs(SC.layer_pte(self.prj), self.pte)
        self.assertIs(SC.layer_armadi(self.prj), self.arm)
        self.assertEqual(SC.taglie_presenti(self.arm), [384, 576])
        self.assertEqual(SC.taglia("384 fo"), 384)
        self.assertIsNone(SC.taglia(200))

    def test_tutte_o_solo_nuove(self):
        self.assertEqual(SC.conta(self.pte, SC.ESPR_COLONNINA[SC.MODO_TUTTE]), 3)
        self.assertEqual(SC.conta(self.pte, SC.ESPR_COLONNINA[SC.MODO_NUOVE]), 1)
        self.assertEqual(SC.MODO_PREDEFINITO, SC.MODO_BASAMENTO)
        self.assertEqual(SC.conta(self.pte, SC.ESPR_COLONNINA[SC.MODO_BASAMENTO]), 2)

    def test_applica_e_ripristina(self):
        prima_pte = self.pte.renderer().type()
        prima_arm = self.arm.renderer().type()
        with SC.Simboli(self.prj, colonnina=SC.MODO_BASAMENTO, armadi=True) as s:
            self.assertEqual(self.pte.renderer().type(), "RuleRenderer")
            voci = [i.label() for i in self.arm.renderer().legendSymbolItems()]
            self.assertIn("ARMADIO OTTICO LARGE (384 fo)", voci)
            self.assertIn("ARMADIO OTTICO EXTRA LARGE (576 fo)", voci)
            self.assertNotIn("ARMADIO OTTICO SMALL (128 fo)", voci)
            self.assertIn("PTE A COLONNINA",
                          [i.label() for i in self.pte.renderer().legendSymbolItems()])
            self.assertTrue(any("2 colonnine" in r and "NewBasament" in r for r in s.righe))
        self.assertEqual(self.pte.renderer().type(), prima_pte)
        self.assertEqual(self.arm.renderer().type(), prima_arm)


class TestTavolaParticolari(unittest.TestCase):
    def test_ricomposta_con_nuovi_e_senza_onucab(self):
        import os
        import re
        import tempfile
        d = tempfile.mkdtemp()
        src = os.path.join(d, "tavola.svg")
        with open(src, "w", encoding="utf-8") as fh:
            fh.write('<?xml version="1.0"?><svg xmlns="http://www.w3.org/2000/svg" '
                     'width="200mm" height="190mm" viewBox="0 0 200 190">'
                     '<g id="PC-01"><rect x="5" y="5" width="30" height="50" fill="#000"/></g>'
                     '<g id="PC-06"><rect x="50" y="5" width="40" height="55" fill="#000"/></g>'
                     '<g id="PC-12"><rect x="100" y="5" width="90" height="35" fill="#000"/></g>'
                     '</svg>')
        out = os.path.join(d, "out.svg")
        nuovi = SC.pezzi_nuovi(True, [576])
        self.assertEqual([s for s, _t, _f in nuovi], ["PC-AO576", "PC-20"])
        n = SC.componi_particolari(src, out, 186, 265, nuovi, togli=("PC-06",))
        self.assertEqual(n, 4)               # PC-01, PC-12 + armadio 576 + colonnina
        testo = open(out, encoding="utf-8").read()
        self.assertNotIn('id="PC-06"', testo)
        self.assertIn("PARTICOLARE COLONNINA PTE", testo)
        self.assertTrue(re.search(r'width="186.00mm" height="265.00mm"', testo))
        self.assertIsNone(SC.componi_particolari(os.path.join(d, "x.pdf"), out, 186, 265, nuovi))


if __name__ == "__main__":
    unittest.main()
