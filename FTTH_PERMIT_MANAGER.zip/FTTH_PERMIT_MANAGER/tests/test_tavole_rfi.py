# -*- coding: utf-8 -*-
"""Tavole RFI a 1:1000: interferenze nel minor numero di tavole."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import QgsApplication  # noqa: E402

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_rfi_layout as L  # noqa: E402


def _q(x, y, d=2):
    return (x - d, y - d, x + d, y + d)


class TestTavoleRFI(unittest.TestCase):
    def test_finestra_1000(self):
        w, h = L.finestra_tavola_m(1000)
        self.assertAlmostEqual(w, 153.0, 1)
        self.assertAlmostEqual(h, 131.5, 1)
        self.assertEqual(L.SCALA_TAVOLE_RFI, 1000)

    def test_vicine_in_una_tavola(self):
        voci = [(1, _q(0, 0)), (2, _q(40, 30)), (3, _q(80, 10))]
        t = L.dividi_in_tavole(voci, 153, 131.5, 12)
        self.assertEqual(len(t), 1)
        self.assertEqual(sorted(t[0][1]), [1, 2, 3])

    def test_lontane_tavole_diverse(self):
        voci = [(1, _q(0, 0)), (2, _q(1000, 0)), (3, _q(1050, 20))]
        t = L.dividi_in_tavole(voci, 153, 131.5, 12)
        self.assertEqual(len(t), 2)
        self.assertIn([2, 3], [sorted(k) for _r, k in t])

    def test_lunga_si_spezza(self):
        # scavo lungo 400 m: entra in 4 tavole da 129 m utili
        t = L.dividi_in_tavole([(1, (0, 0, 400, 5))], 153, 131.5, 12)
        self.assertEqual(len(t), 4)
        for (x0, y0, x1, y1), k in t:
            self.assertLessEqual(x1 - x0, 129 + 1e-6)
            self.assertEqual(k, [1])

    def test_lungo_la_ferrovia_diagonale(self):
        # punti ogni 50 m lungo una diagonale: tavole consecutive, nessuna vuota
        voci = [(n, _q(n * 35, n * 35)) for n in range(10)]
        t = L.dividi_in_tavole(voci, 153, 131.5, 12)
        self.assertEqual(sum(len(k) for _r, k in t), 10)
        self.assertLessEqual(len(t), 4)


if __name__ == "__main__":
    unittest.main()
