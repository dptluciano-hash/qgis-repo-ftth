# -*- coding: utf-8 -*-
"""Tavole RFI a 1:1000: interferenze nel minor numero di tavole."""
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import QgsApplication  # noqa: E402

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_rfi_layout as L  # noqa: E402


def _q(x, y, d=2):
    return (x - d, y - d, x + d, y + d)


class TestTavoleRFI(unittest.TestCase):
    def test_finestra_1000(self):
        w, h = L.finestra_tavola_m(1000)
        self.assertAlmostEqual(w, 153.0, 1)
        self.assertAlmostEqual(h, 131.5, 1)
        self.assertEqual(L.SCALA_TAVOLE_RFI, 1000)

    def test_vicine_in_una_tavola(self):
        voci = [(1, _q(0, 0)), (2, _q(40, 30)), (3, _q(80, 10))]
        t = L.dividi_in_tavole(voci, 153, 131.5, 12)
        self.assertEqual(len(t), 1)
        self.assertEqual(sorted(t[0][1]), [1, 2, 3])

    def test_lontane_tavole_diverse(self):
        voci = [(1, _q(0, 0)), (2, _q(1000, 0)), (3, _q(1050, 20))]
        t = L.dividi_in_tavole(voci, 153, 131.5, 12)
        self.assertEqual(len(t), 2)
        self.assertIn([2, 3], [sorted(k) for _r, k in t])

    def test_lunga_si_spezza(self):
        # scavo lungo 400 m: entra in 4 tavole da 129 m utili
        t = L.dividi_in_tavole([(1, (0, 0, 400, 5))], 153, 131.5, 12)
        self.assertEqual(len(t), 4)
        for (x0, y0, x1, y1), k in t:
            self.assertLessEqual(x1 - x0, 129 + 1e-6)
            self.assertEqual(k, [1])

    def test_lungo_la_ferrovia_diagonale(self):
        # punti ogni 50 m lungo una diagonale: tavole consecutive, nessuna vuota
        voci = [(n, _q(n * 35, n * 35)) for n in range(10)]
        t = L.dividi_in_tavole(voci, 153, 131.5, 12)
        self.assertEqual(sum(len(k) for _r, k in t), 10)
        self.assertLessEqual(len(t), 4)


    def _no_sovrapposte(self, t):
        for a in range(len(t)):
            for b in range(a + 1, len(t)):
                ra, rb = t[a][0], t[b][0]
                ox = min(ra[2], rb[2]) - max(ra[0], rb[0])
                oy = min(ra[3], rb[3]) - max(ra[1], rb[1])
                self.assertFalse(ox > 0.05 and oy > 0.05, (ra, rb))

    def test_scala_secondo_ingombro(self):
        # una sola interferenza piccola -> 1:500; un gruppo di 120 m -> 1:1000;
        # un gruppo di 250 m -> 1:2000 (una tavola, non due)
        self.assertEqual(L.tavole_con_scala([(1, _q(0, 0))])[0][1], 500)
        t = L.tavole_con_scala([(1, _q(0, 0)), (2, _q(120, 0))])
        self.assertEqual([(s, sorted(k)) for _r, s, k in t], [(1000, [1, 2])])
        t = L.tavole_con_scala([(1, _q(0, 0)), (2, _q(250, 0))])
        self.assertEqual([(s, sorted(k)) for _r, s, k in t], [(2000, [1, 2])])

    def test_mai_sovrapposte(self):
        # interferenze lungo una ferrovia, a passi che fanno toccare i riquadri
        voci = [(n, _q(n * 160, n * 40)) for n in range(12)] + \
               [(100, (0, 500, 900, 505))]               # scavo lunghissimo
        t = L.tavole_con_scala(voci)
        self._no_sovrapposte(t)
        tutte = sorted(k for _r, _s, ks in t for k in ks)
        self.assertEqual(sorted(set(tutte)), sorted(k for k, _b in voci))
        for r, s, _k in t:
            self.assertIn(s, (500, 1000, 2000))

    def test_casuali_mai_sovrapposte(self):
        import random
        rnd = random.Random(7)
        for _prova in range(200):
            voci, x, y = [], 0.0, 0.0
            for k in range(rnd.randint(1, 12)):
                x += rnd.uniform(10, 400)
                y += rnd.uniform(-80, 80)
                lw, lh = rnd.choice([(4, 4), (30, 8), (rnd.uniform(50, 600), 6)])
                voci.append((k, (x, y, x + lw, y + lh)))
            t = L.tavole_con_scala(voci)
            self._no_sovrapposte(t)
            self.assertEqual({k for _r, _s, ks in t for k in ks}, {k for k, _b in voci})
            # un'interferenza più piccola di una tavola sta TUTTA in una tavola
            # che la cita (prima a 1:500 restava tagliata)
            w2, h2 = L.finestra_tavola_m(2000)
            if any(b[2] - b[0] > w2 / 2.0 for _k, b in voci):
                continue        # scavi lunghi mezza tavola o più: possono restare divisi
            for k, b in voci:
                if b[2] - b[0] > w2 - 30 or b[3] - b[1] > h2 - 30:
                    continue
                self.assertTrue(any(k in ks and r[0] <= b[0] + 1e-6 and r[1] <= b[1] + 1e-6
                                    and r[2] >= b[2] - 1e-6 and r[3] >= b[3] - 1e-6
                                    for r, _s, ks in t), (k, b, t))

    def test_vicine_non_sovrapposte(self):
        # due gruppi appena troppo lontani per una tavola a 1:2000
        voci = [(1, _q(0, 0)), (2, _q(280, 0)), (3, _q(330, 0))]
        t = L.tavole_con_scala(voci)
        self._no_sovrapposte(t)


if __name__ == "__main__":
    unittest.main()
