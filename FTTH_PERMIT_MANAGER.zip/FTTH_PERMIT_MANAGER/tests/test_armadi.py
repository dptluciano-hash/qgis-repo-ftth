"""Test della verifica armadi (logica, senza QGIS)."""
import csv
import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import ftth_armadi as AR  # noqa: E402


class TestArmadi(unittest.TestCase):
    def test_link(self):
        self.assertIn("map_action=pano&viewpoint=43.1234567,12.0500000",
                      AR.link_streetview(43.1234567, 12.05))
        self.assertIn("basemap=satellite", AR.link_satellite(43.1, 12.0))
        self.assertIn("query=43.1000000,12.0000000", AR.link_mappa(43.1, 12.0))

    def test_campi_e_chiavi(self):
        self.assertEqual(AR.scegli_campo(["fid", "Indirizzo", "id"], AR.CAMPI_INDIRIZZO),
                         "Indirizzo")
        self.assertEqual(AR.scegli_campo(["fid", "id"], AR.CAMPI_ID), "id")
        self.assertEqual(AR.chiave_armadio("ARM-12", 5), "ARM-12")
        self.assertEqual(AR.chiave_armadio(None, 5), "fid:5")
        self.assertEqual(AR.chiave_armadio("NULL", 7), "fid:7")

    def test_esiti_e_csv(self):
        esiti = {"A": {"esito": "Fattibile", "nota": ""},
                 "B": {"esito": "Da verificare", "nota": ""},
                 "C": {"esito": "Da spostare", "nota": "marciapiede stretto"}}
        testo = AR.esiti_in_testo(esiti)
        letti = AR.esiti_da_testo(testo)
        self.assertEqual(set(letti), {"A", "C"})          # B non si salva
        self.assertEqual(AR.esiti_da_testo("non json"), {})
        r = AR.riepilogo(["A", "B", "C", "D"], letti)
        self.assertEqual(r["Da verificare"], 2)
        self.assertEqual(r["Fattibile"], 1)
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "armadi.csv")
            n = AR.scrivi_csv(p, [{"chiave": "C", "nome": "C", "indirizzo": "Via Roma",
                                   "lat": 43.1, "lon": 12.0}], letti)
            self.assertEqual(n, 1)
            with open(p, encoding="utf-8-sig") as f:
                righe = list(csv.reader(f, delimiter=";"))
            self.assertEqual(righe[1][4], "Da spostare")
            self.assertEqual(righe[1][5], "marciapiede stretto")

    def test_posizione_aggiornata_e_excel(self):
        esiti = {"C": {"esito": "Da spostare", "nota": "", "nuova": [43.1001234, 12.0004321]},
                 "D": {"esito": "Da verificare", "nota": "", "nuova": [43.2, 12.1]}}
        letti = AR.esiti_da_testo(AR.esiti_in_testo(esiti))
        self.assertEqual(letti["C"]["nuova"], [43.1001234, 12.0004321])
        self.assertIn("D", letti)                     # spostato: si salva anche se da verificare
        self.assertEqual(AR.testo_coordinate(40.697786, 14.97876), "40.6977860, 14.9787600")
        try:
            from openpyxl import load_workbook
        except ImportError:
            self.skipTest("openpyxl non disponibile")
        with tempfile.TemporaryDirectory() as d:
            p = os.path.join(d, "armadi.xlsx")
            AR.scrivi_xlsx(p, [{"chiave": "C", "nome": "Armadio 201", "indirizzo": "Via Roma",
                                "lat": 43.1, "lon": 12.0},
                               {"chiave": "E", "nome": "Armadio 202", "indirizzo": "",
                                "lat": 43.3, "lon": 12.3}], letti)
            ws = load_workbook(p).active
            self.assertEqual(ws["C2"].value, "43.1000000, 12.0000000")
            self.assertEqual(ws["D2"].value, "43.1001234, 12.0004321")
            self.assertEqual(ws["D3"].value, None)
            self.assertIn("viewpoint=43.1001234", ws["H2"].hyperlink.target)


if __name__ == "__main__":
    unittest.main()
