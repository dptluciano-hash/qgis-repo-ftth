import os
import sys
import tempfile
import unittest

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, QUI)
import ftth_comunale as C  # noqa: E402

try:
    import docx  # noqa: F401
    HA_DOCX = True
except ImportError:
    HA_DOCX = False


def S(name, tip, stato, L, prop="TIM", note=""):
    return {"OBJECTID": 1, "TIPOLOGIA": tip, "STATO": stato, "name": name, "Lungh": L,
            "PROPRIETA": prop, "NOTES": note}


SCAVI = [S("Via Roma", "Mini trincea", "Nuovo", 10.2), S("Via Roma", "Tradizionale", "Nuovo", 5),
         S("Localitá Monte", "Mini-Trincea", "Nuovo", 3.1),
         S("Via Roma", "Tradizionale", "Esistente", 99),             # non conta
         S("Via Po", "Tradizionale", "Nuovo", 7, prop="IP"),          # pubblica illuminazione
         S("Via Po", "Aerea", "Esistente", 20, prop="", note="")]     # PI (proprietà vuota)
POZZ = [{"STATO": "Nuovo", "name": "Via Roma", "TIPO_POZZE": "40x76"},
        {"STATO": "Nuovo", "name": "Via Roma", "TIPO_POZZE": "125X80"},
        {"STATO": "Esistente", "name": "Via Roma", "TIPO_POZZE": "40x76"}]
ARM = [{"AREA_AO": 202.0, "INDIRIZZO": "SAN NICOLO' DI CELLE", "CIVICO": 9999, "NumeroFoto": 3.0},
       {"AREA_AO": 201.0, "INDIRIZZO": "DELL'ARTE", "CIVICO": 15, "NumeroFoto": 1.0}]


class TestComunale(unittest.TestCase):
    def test_scavi(self):
        t = C.tabella_scavi(SCAVI)
        self.assertEqual(t["intest"], ["Nome Strada\\Piazza", "Minitrincea (m)",
                                       "Tradizionale (m)", "Totale Strada (m)"])
        self.assertEqual(t["righe"][0], ["Via Roma", 11, 5, 16])        # 10,2 -> 11 (per eccesso)
        self.assertEqual(t["righe"][-1][0], "TOTALE GENERALE")
        self.assertEqual(t["esclusi_pi"], 1)

    def test_pi(self):
        t = C.tabella_pi(SCAVI)
        self.assertEqual(t["righe"], [["Via Po", 27], ["TOTALE GENERALE", 27]])

    def test_pozzetti(self):
        t = C.tabella_pozzetti(POZZ)
        self.assertEqual(t["intest"], ["Nome Strada\\Piazza", "125x80", "40x76", "Totale Strada"])
        self.assertEqual(t["righe"][0], ["Via Roma", 1, 1, 2])

    def test_armadi_e_refusi(self):
        t = C.tabella_armadi(ARM)
        self.assertEqual(t["righe"][0], ["201", "DELL'ARTE", "15", "1"])     # ordine per numero
        self.assertEqual(t["righe"][1], ["202", "SAN NICOLÒ DI CELLE", "SNC", "3"])
        self.assertEqual(C.pulisci_testo("Localitá Montecchio"), "Località Montecchio")
        self.assertEqual(C.pulisci_testo("GIOSUE' CARDUCCI"), "GIOSUÈ CARDUCCI")
        tab = C.calcola_tabelle(SCAVI, POZZ, ARM)
        self.assertIn("Località Monte", [r[0] for r in tab["scavi"]["righe"]])

    def test_ordine_pl(self):
        nomi = ["04_Inquadramento 6Foto", "03_Inquadramento_2.0", "02_Keyplan INQUA_2.0",
                "01_Keyplan ORTO_2.0", "00_Keyplan ORTO+INQUA_2.0"]
        self.assertEqual(C.ordina_layout_pl(nomi),
                         ["01_Keyplan ORTO_2.0", "00_Keyplan ORTO+INQUA_2.0",
                          "02_Keyplan INQUA_2.0", "03_Inquadramento_2.0",
                          "04_Inquadramento 6Foto"])
        self.assertEqual(C.ordina_layout_pl(["Tavole", "Planimetria", "Ortofoto"]),
                         ["Ortofoto", "Planimetria", "Tavole"])
        alt = C.alternative_pl(nomi)
        self.assertEqual(len(alt), 2)
        self.assertEqual(alt[0][1][0][1], ["00_Keyplan ORTO+INQUA_2.0"])
        self.assertEqual(alt[0][1][-1][1], ["01_Keyplan ORTO_2.0", "02_Keyplan INQUA_2.0"])
        self.assertEqual([o[1] for o in alt[1][1][:2]],
                         [["03_Inquadramento_2.0"], ["04_Inquadramento 6Foto"]])
        self.assertEqual(C.alternative_pl(["01_Keyplan ORTO_2.0", "02_Keyplan INQUA_2.0",
                                           "03_Inquadramento_2.0"]), [])

    @unittest.skipUnless(HA_DOCX, "python-docx non disponibile")
    def test_relazione(self):
        from docx import Document
        tab = C.calcola_tabelle(SCAVI, POZZ, ARM)
        out = C.genera_relazione("Prova", tab, tempfile.mkdtemp())
        self.assertTrue(out.endswith("PROVA_RT.docx"))
        d = Document(out)
        testo = "\n".join(p.text for p in d.paragraphs)
        self.assertNotIn("<<NOME_COMUNE>>", testo)
        self.assertGreaterEqual(len(d.tables), 1 + 4)     # copertina + 4 tabelle
        # senza pubblica illuminazione il capitolo sparisce
        senza = dict(tab, pi=None)
        d2 = Document(C.genera_relazione("Prova2", senza, tempfile.mkdtemp()))
        t2 = "\n".join(p.text for p in d2.paragraphs)
        self.assertNotIn("PUBBLICA ILLUMINAZIONE:", t2)
        self.assertIn("SCELTE PROGETTUALI", t2)


if __name__ == "__main__":
    unittest.main()
