# -*- coding: utf-8 -*-
"""Test delle istanze ferroviarie (ftth_rfi). Senza QGIS e senza rete:
servono shapely e yaml; i test sui documenti Word girano solo se c'e'
python-docx (nel Python di QGIS c'e').

    python -m unittest discover tests
"""
import datetime
import os
import sys
import tempfile
import unittest

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, QUI)

import yaml  # noqa: E402
from shapely.geometry import LineString, Point  # noqa: E402

import ftth_rfi as R  # noqa: E402

try:
    import docx  # noqa: F401
    HA_DOCX = True
except ImportError:
    HA_DOCX = False

KB = yaml.safe_load(open(os.path.join(QUI, "procedimenti.yaml"), encoding="utf-8"))

# binario orizzontale a Y0; 1 m in latitudine ~ 1/110540 gradi
X0, Y0 = 14.98, 40.60
MY = 1 / 110540.0
MX = 1 / (111320.0 * 0.7593)      # cos(40.6°)


def _x(m):
    return X0 + m * MX


def _y(m):
    return Y0 + m * MY


LINEA = [{"geom": LineString([(_x(0), _y(0)), (_x(3000), _y(0))]),
          "tags": {"name": "Ferrovia Battipaglia-Potenza", "operator": "Rete Ferroviaria Italiana"}}]
CIPPI = [{"km": 10.0 + k, "lat": _y(0), "lon": _x(k * 1000)} for k in range(4)]
STAZIONI = [{"nome": "Stazione Alfa", "geom": Point(_x(100), _y(40))},
            {"nome": "Stazione Beta", "geom": Point(_x(2900), _y(40))}]


def _tratta(coords_m, stato="Nuovo", tecnica="minitrincea", proprietario=""):
    return {"geom": LineString([(_x(a), _y(b)) for a, b in coords_m]),
            "stato": stato, "tecnica": tecnica, "proprietario": proprietario}


TRATTE = [
    _tratta([(200, 15), (300, 15)]),                               # D a 15 m
    _tratta([(800, 20), (800, -20)], tecnica="nodig"),             # C attraversamento
    _tratta([(800, 20), (800, 28), (850, 28)], tecnica="trincea"),  # avvicinamento al No Dig
    _tratta([(1500, 25), (1500, -25)], stato="Esistente", tecnica="trincea",
            proprietario="TIM"),                                    # A riutilizzo
    _tratta([(2700, 3), (2760, 3)], tecnica="trincea"),            # D a 3 m
    _tratta([(1000, 50), (1100, 50)]),                             # fuori fascia
    _tratta([(2000, 10), (2100, 10)], stato="Esistente"),          # esistente in parallelo
]
POZZETTI = [{"geom": Point(_x(250), _y(15)), "stato": "Nuovo", "dim": "76x40"},
            {"geom": Point(_x(2000), _y(10)), "stato": "Esistente", "dim": "76x40"}]


class TestTipologia(unittest.TestCase):
    def test_regole(self):
        self.assertEqual(R.classifica_tipologia(True, "Esistente", "trincea")[0], "A")
        self.assertEqual(R.classifica_tipologia(True, "Nuovo", "nodig")[0], "C")
        self.assertEqual(R.classifica_tipologia(True, "Nuovo", "minitrincea")[0], "B")
        self.assertEqual(R.classifica_tipologia(True, "Nuovo", None)[0], "?")
        self.assertEqual(R.classifica_tipologia(False, "Nuovo", "trincea", 15)[0], "D")
        self.assertIsNone(R.classifica_tipologia(False, "Esistente", "trincea", 15)[0])
        tip, note = R.classifica_tipologia(False, "Nuovo", "trincea", 3)
        self.assertEqual(tip, "D")
        self.assertTrue(any("6 m" in n for n in note))


class TestGestori(unittest.TestCase):
    def test_riconoscimento(self):
        self.assertEqual(R.riconosci_gestore("Rete Ferroviaria Italiana", "", KB).chiave, "rfi")
        self.assertEqual(R.riconosci_gestore("Ferrovie del Sud Est", "", KB).chiave, "fse")
        self.assertEqual(R.riconosci_gestore("Ferrovie Emilia Romagna", "", KB).chiave, "fer")
        g = R.riconosci_gestore("Ferrovia Inventata Srl", "", KB)
        self.assertTrue(g.chiave.startswith("altro_"))
        self.assertFalse(g.destinatario_completo())

    def test_destinatario_rfi(self):
        g = R.destinatario_rfi(R.riconosci_gestore("RFI", "", KB), "Napoli", "Via X 1", "a@pec.it")
        self.assertIn("Territoriale di NAPOLI", g.dest_nome)
        self.assertEqual(g.dest_pec, "a@pec.it")


class TestInterferenze(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.interf = R.trova_interferenze(LINEA, TRATTE, POZZETTI, CIPPI, STAZIONI, KB)

    def test_tipologie_trovate(self):
        tip = sorted(i.tipologia for i in self.interf)
        self.assertEqual(tip, ["A", "C", "D", "D"])

    def test_parallelo_15m(self):
        d = [i for i in self.interf if i.tipologia == "D" and i.dist_min_m > 10][0]
        self.assertAlmostEqual(d.metri["minitrincea"], 100, delta=2)
        self.assertEqual(d.pozzetti, {"76x40": 1})
        self.assertEqual(d.stazione, "Stazione Alfa")
        self.assertEqual(d.km_da, "10+200")
        self.assertEqual(d.km_a, "10+300")
        self.assertEqual(d.gestore, "rfi")
        self.assertEqual(d.linea, "Ferrovia Battipaglia-Potenza")

    def test_scavo_continuo_fuori_fascia(self):
        # corre a 15 m per 100 m e poi esce fino a 80 m: in tavola si vede tutto,
        # nel computo solo la parte in fascia (100 + 15 m = 115 m); il pozzetto
        # alla fine (fuori fascia) si disegna ma non si conta; tratta e pozzetto
        # del tutto fuori fascia: esclusi
        tr = [dict(_tratta([(200, 15), (300, 15), (300, 80)]), fid=11),
              dict(_tratta([(1000, 60), (1100, 60)]), fid=12)]
        pz = [{"geom": Point(_x(300), _y(80)), "stato": "Nuovo", "dim": "125x80", "fid": 21},
              {"geom": Point(_x(1050), _y(60)), "stato": "Nuovo", "dim": "76x40", "fid": 22}]
        lst = R.trova_interferenze(LINEA, tr, pz, CIPPI, STAZIONI, KB)
        self.assertEqual(len(lst), 1)
        i = lst[0]
        self.assertAlmostEqual(i.metri["minitrincea"], 115, delta=2)
        self.assertEqual(i.tratte_fid, [11])
        self.assertEqual(i.pozzetti, {})
        tipi = sorted(e["tipo"] for e in i.elementi)
        self.assertEqual(tipi, ["fuori", "ingresso", "pozzetto_fuori", "scavo"])
        # etichetta dello scavo: sua tecnica e soli metri in fascia
        sc = [e for e in i.elementi if e["tipo"] == "scavo"][0]
        self.assertEqual(sc["tecnica"], "minitrincea")
        self.assertAlmostEqual(sc["metri"], 115, delta=2)
        ingr = [e for e in i.elementi if e["tipo"] == "ingresso"][0]
        self.assertEqual(ingr["km"], "10+300")
        self.assertEqual([e["fid"] for e in i.elementi if e["tipo"] == "pozzetto_fuori"], [21])

    def test_righe_pozzetti_per_km(self):
        i = R.Interferenza(1, "D", "L", "rfi", km_da="74+725", km_a="74+813",
                           metri={"microtrincea": 134}, pozzetti={"76x40": 1},
                           elementi=[{"tipo": "pozzetto", "dim": "76x40", "km": "74+813"},
                                     {"tipo": "ingresso", "km": "74+725"}])
        self.assertEqual(i.tratta().righe_pozzetti, [("Al km 74+813", {"76x40": 1})])
        senza = R.Interferenza(2, "D", "L", "rfi", km_da="1+000", km_a="1+050",
                               metri={"trincea": 50})
        self.assertEqual(senza.tratta().righe_pozzetti, [])

    def test_lunghezza_proporzionata(self):
        # LUNGHEZZA 330 su 165 m di geometria, 115 m in fascia -> 230 m
        tr = [dict(_tratta([(200, 15), (300, 15), (300, 80)]), fid=1, lunghezza=330.0)]
        i = R.trova_interferenze(LINEA, tr, [], CIPPI, STAZIONI, KB)[0]
        self.assertAlmostEqual(i.metri["minitrincea"], 230, delta=3)

    def test_lunghezza_dal_campo(self):
        tr = [dict(_tratta([(200, 15), (300, 15)]), fid=1, lunghezza=104.5)]
        i = R.trova_interferenze(LINEA, tr, [], CIPPI, STAZIONI, KB)[0]
        # metri a cifra tonda, mezzo metro per eccesso
        self.assertEqual(i.metri["minitrincea"], 105)
        self.assertIsInstance(i.metri["minitrincea"], int)

    def test_elementi_con_km(self):
        d = [i for i in self.interf if i.tipologia == "D" and i.dist_min_m > 10][0]
        el = [e for e in d.elementi if e["tipo"] != "scavo"]
        self.assertEqual(len(el), 1)
        e = el[0]
        self.assertEqual((e["tipo"], e["dim"], e["km"]), ("pozzetto", "76x40", "10+250"))

    def test_armadio_in_fascia(self):
        arm = [{"geom": Point(_x(260), _y(18)), "stato": "Nuovo", "id": "AO-1"},
               {"geom": Point(_x(260), _y(80)), "stato": "Nuovo", "id": "AO-2"}]
        lst = R.trova_interferenze(LINEA, TRATTE, POZZETTI, CIPPI, STAZIONI, KB, armadi=arm)
        d = [i for i in lst if i.tipologia == "D" and i.dist_min_m > 10][0]
        arm_el = [e for e in d.elementi if e["tipo"] == "armadio"]
        self.assertEqual(len(arm_el), 1)          # quello a 80 m e' fuori fascia
        self.assertEqual(arm_el[0]["km"], "10+260")

    def test_nodig_con_avvicinamento(self):
        c = [i for i in self.interf if i.tipologia == "C"][0]
        self.assertTrue(c.attraversa)
        self.assertEqual(c.km_da, "10+800")
        self.assertAlmostEqual(c.metri["nodig"], 40, delta=2)
        self.assertGreater(c.metri.get("trincea", 0), 50)   # l'avvicinamento e' con il C

    def test_riutilizzo(self):
        a = [i for i in self.interf if i.tipologia == "A"][0]
        self.assertEqual(a.proprietario, "TIM")
        self.assertEqual(a.km_da, "11+500")

    def test_entro_6m(self):
        d = [i for i in self.interf if i.tipologia == "D" and i.dist_min_m < 6][0]
        self.assertTrue(any("6 m" in n for n in d.note))
        self.assertEqual(d.stazione, "Stazione Beta")

    def test_raggruppamento(self):
        g = {"rfi": R.destinatario_rfi(R.riconosci_gestore("RFI", "", KB), "Napoli")}
        ist = R.raggruppa_istanze(self.interf, g, "Battipaglia")
        chiavi = sorted((x.tipologia, x.stazione) for x in ist)
        # i due D sono vicini a stazioni diverse: due istanze D distinte
        self.assertEqual(chiavi, [("A", "Stazione Alfa"), ("C", "Stazione Alfa"),
                                  ("D", "Stazione Alfa"), ("D", "Stazione Beta")])
        nomi = sorted(x.nome_base for x in ist)
        self.assertIn("BATTIPAGLIA_RFI_TipoD_STAZIONE ALFA", nomi)
        self.assertIn("BATTIPAGLIA_RFI_TipoD_STAZIONE BETA", nomi)
        self.assertEqual(len(set(nomi)), len(nomi))

    def test_esclusione(self):
        lst = [R.Interferenza(1, "D", "L", "rfi", stazione="S"),
               R.Interferenza(2, "D", "L", "rfi", stazione="S", includi=False),
               R.Interferenza(3, "?", "L", "rfi", stazione="S")]
        ist = R.raggruppa_istanze(lst, {}, "X")
        self.assertEqual(len(ist), 1)
        self.assertEqual([i.id for i in ist[0].interferenze], [1])


class TestTesti(unittest.TestCase):
    def _ist(self, tip, gk="fse"):
        g = R.riconosci_gestore({"fse": "Ferrovie del Sud Est", "rfi": "RFI"}[gk], "", KB)
        if gk == "rfi":
            g = R.destinatario_rfi(g, "Bari", "Piazza Moro 1", "rfi@pec.it")
        i = R.Interferenza(1, tip, "Ferrovia Zollino/Gagliano del Capo", g.chiave,
                           km_da="28+543", km_a="28+543", metri={"trincea": 3.0},
                           pozzetti={"76x40": 1})
        return R.raggruppa_istanze([i], {g.chiave: g}, "Andrano")[0]

    def test_valori_tipo_d(self):
        v = R.valori_istanza(self._ist("D"), R.DatiComune("Andrano", "LE", "73032"),
                             datetime.date(2026, 11, 9))
        self.assertEqual(v["OGGETTO_LINEA"],
                         "la Linea FS Ferrovie Sud Est - Ferrovia Zollino/Gagliano del Capo al km 28+543.")
        self.assertIn("in fascia di rispetto della linea", v["OGGETTO_MODB"])
        self.assertIn("posa nuovo pozzetto 76x40", v["OGGETTO_MODB"])
        self.assertEqual(v["PL_FILE"], "1.1_ANDRANO_FS FERROVIE SUD EST_TipoD_PL.pdf")
        self.assertEqual(v["MESE_ANNO"], "11/2026")
        self.assertEqual(v["PROC_COGNOME"], "XXXXX")

    def test_valori_rfi_tipo_c(self):
        v = R.valori_istanza(self._ist("C", "rfi"), R.DatiComune("Andrano", "LE", "73032"))
        self.assertTrue(v["LINEA_KM"].startswith("Linea Ferroviaria Ferrovia Zollino"))
        self.assertIn("NO-DIG", v["TIPOLOGIA_TITOLO"])
        self.assertIn("Territoriale di BARI", v["DEST_NOME"])

    def test_sigla_provincia(self):
        self.assertEqual(R.sigla_provincia("Salerno"), "SA")
        self.assertEqual(R.sigla_provincia("Città Metropolitana di Napoli"), "NA")
        self.assertEqual(R.sigla_provincia("Libero consorzio comunale di Ragusa"), "RG")
        self.assertEqual(R.sigla_provincia("le"), "LE")
        self.assertEqual(R.sigla_provincia("Bolzano - Bozen"), "BZ")
        self.assertEqual(R.sigla_provincia("Atlantide"), "")

    def test_modello_b_senza_linea_doppia(self):
        v = R.valori_istanza(self._ist("A", "rfi"), R.DatiComune("Eboli", "SA"))
        self.assertNotIn("linea Linea", v["OGGETTO_MODB"])
        self.assertIn("della linea Ferrovia Zollino", v["OGGETTO_MODB"])
        i = R.Interferenza(1, "D", "Linea 124 Ferrovia Battipaglia", "rfi", km_da="1+000")
        g = R.destinatario_rfi(R.riconosci_gestore("RFI", "", KB), "Napoli")
        ist = R.raggruppa_istanze([i], {"rfi": g}, "Eboli")[0]
        v = R.valori_istanza(ist, R.DatiComune("Eboli", "SA"))
        self.assertIn("della Linea 124 Ferrovia Battipaglia", v["OGGETTO_MODB"])
        self.assertNotIn("linea Linea", v["OGGETTO_MODB"])

    def test_km_mancanti(self):
        i = R.Interferenza(1, "D", "L", "fse", km_da=R.KM_DA_VERIFICARE, km_a=R.KM_DA_VERIFICARE)
        self.assertEqual(R.etichetta_km(i.km_da, i.km_a), "Al km XXX+XXX")

    def test_promemoria(self):
        t = R.promemoria_istanza(self._ist("C"), R.DatiComune("Andrano", "LE"))
        self.assertIn("sopralluogo", t)

    @unittest.skipUnless(HA_DOCX, "python-docx non disponibile")
    def test_giorni_cronoprogramma(self):
        # 67 m minitrincea + 6 m trincea + 2 pozzetti 76x40
        tr = R.Tratta("1+000", "1+000", metri={"minitrincea": 67, "trincea": 6},
                      pozzetti={"40x76": 2})
        scavo, pz, rip = R.giorni_tratta(tr)
        self.assertEqual(scavo, {"minitrincea": 1.0, "trincea": 0.5})
        self.assertEqual(pz, 0.5)       # 2 / 4 al giorno
        self.assertEqual(rip, 1.0)      # 67/250 + 6/120 + 2/8 = 0,57 -> 1 (mezzo giorno sup.)
        # i gg della riga comprendono i ripristini: senza sarebbero 2, con 3
        self.assertEqual(sum(scavo.values()) + pz + rip, 3.0)
        # rese della scheda: squadra piu' lenta sulla minitrincea e sui ripristini
        scavo2, pz2, rip2 = R.giorni_tratta(tr, {"minitrincea": 30,
                                                 "ripristino": {"minitrincea": 50},
                                                 "pozzetti": {"76x40": 1}})
        self.assertEqual(scavo2["minitrincea"], 2.5)    # 67 / 30
        self.assertEqual(pz2, 2.0)                      # 2 / 1
        self.assertEqual(rip2, 2.0)                     # 67/50 + 6/120 + 2/8 = 1,64
        # valori assurdi ignorati: resta il predefinito
        self.assertEqual(R.rese_complete({"trincea": 0, "nodig": "x"})["trincea"],
                         R.RESE_DEFAULT["trincea"])
        # no-dig: ripristino delle sole buche
        tr = R.Tratta("1+000", "1+000", metri={"nodig": 40})
        self.assertEqual(R.giorni_tratta(tr)[2], R.GIORNI_RIPRISTINO_NODIG)

    def test_documenti_tutte_le_tipologie(self):
        from docx import Document
        tpl = os.path.join(QUI, "modelli_rfi")
        for tip in "ABCD":
            with tempfile.TemporaryDirectory() as d:
                ist = self._ist(tip)
                prod = R.genera_documenti_istanza(
                    ist, R.DatiComune("Andrano", "LE", "73032", "Via Michelangelo, 25", "p@pec.it"),
                    tpl, d)
                self.assertTrue(all(prod.values()), prod)
                for k, p in prod.items():
                    doc = Document(p)
                    testo = "\n".join(R.testo_paragrafo(x) for x in R._tutti_i_paragrafi(doc))
                    self.assertNotIn("<<", testo, "%s %s" % (tip, k))
                    self.assertNotIn("MILANO", testo, "%s %s" % (tip, k))
                    self.assertNotIn("Milano-Venezia", testo)
                    self.assertNotIn("Bertacchi", testo)
                    if k == "modb":
                        self.assertIn(R.TIPOLOGIE[tip]["titolo"], testo)
                        self.assertEqual("Verbale di sopralluogo" in testo, tip in "BC")
                        self.assertEqual("Allegato J" in testo, tip == "A")
                    if k == "rt":
                        self.assertIn("Al km 28+543", testo)
                        # pozzetti presenti: blocchi pozzetto/chiusino si', armadio no
                        self.assertIn("POZZETTO CLS", testo)
                        self.assertIn("CHIUSINO GHISA", testo)
                        self.assertNotIn("ARMADIO OTTICO", testo)
                        self.assertNotIn("<<SE_", testo)
                        # nota sotto il cronoprogramma: i gg comprendono i ripristini
                        self.assertIn(R.NOTA_CRONOPROGRAMMA, testo)
                        dopo = doc.tables[R.RT_TAB_CRONO]._tbl.getnext()
                        self.assertIn("ripristini stradali",
                                      "".join(x.text or "" for x in dopo.iter(
                                          "{http://schemas.openxmlformats.org/"
                                          "wordprocessingml/2006/main}t")))
                        # spaziature uniformi: dal titolo PREMESSA in poi nessuna
                        # riga vuota e corpo sempre 1,5 righe + 6 pt dopo
                        pars = doc.paragraphs
                        i0 = next(i for i, x in enumerate(pars)
                                  if x.text.strip() == "PREMESSA"
                                  and not x.style.name.lower().startswith("toc"))
                        corpo = set()
                        for x in pars[i0:]:
                            if not x.text.strip():
                                # resta solo se porta un'interruzione di pagina/sezione
                                ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
                                self.assertTrue(
                                    x._p.find(".//" + ns + "br") is not None
                                    or x._p.find(".//" + ns + "sectPr") is not None,
                                    "riga vuota rimasta in RT %s" % tip)
                            elif x.paragraph_format.line_spacing == 1.5 and \
                                    x._p.find(".//{http://schemas.openxmlformats.org/"
                                              "wordprocessingml/2006/main}numPr") is None:
                                corpo.add(x.paragraph_format.space_after.pt)
                        self.assertEqual(corpo, {6.0}, tip)


if __name__ == "__main__":
    unittest.main()
