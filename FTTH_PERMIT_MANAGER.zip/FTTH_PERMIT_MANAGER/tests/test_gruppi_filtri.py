# -*- coding: utf-8 -*-
"""Gruppi per istanza come FILTRI sugli shape comunali (niente copie)."""
import os
import sys
import types
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from qgis.core import (QgsApplication, QgsFeature, QgsGeometry, QgsPointXY,  # noqa: E402
                       QgsProject, QgsVectorLayer)

_APP = QgsApplication.instance() or QgsApplication([], False)
import ftth_gruppi_istanze as GR  # noqa: E402


def _linee(n):
    """03 INFRASTRUTTURE su file (GeoPackage temporaneo), come gli shape veri."""
    import tempfile
    from qgis.core import QgsCoordinateTransformContext, QgsVectorFileWriter
    m = QgsVectorLayer("LineString?crs=EPSG:32632&field=TIPOLOGIA:string", "m", "memory")
    feats = []
    for k in range(n):
        f = QgsFeature(m.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY([QgsPointXY(k * 10, 0), QgsPointXY(k * 10 + 5, 0)]))
        f["TIPOLOGIA"] = "Tradizionale"
        feats.append(f)
    m.dataProvider().addFeatures(feats)
    p = os.path.join(tempfile.mkdtemp(), "infra.gpkg")
    opz = QgsVectorFileWriter.SaveVectorOptions()
    opz.driverName = "GPKG"
    QgsVectorFileWriter.writeAsVectorFormatV3(m, p, QgsCoordinateTransformContext(), opz)
    return QgsVectorLayer(p, "03 INFRASTRUTTURE", "ogr")


class TestGruppiFiltri(unittest.TestCase):
    def setUp(self):
        self.prj = QgsProject.instance()
        self.prj.clear()
        self.infra = _linee(5)
        self.prj.addMapLayer(self.infra)

    def tearDown(self):
        self.prj.clear()

    def test_filtro_istanza(self):
        f = GR.filtro_istanza("IST_STRADE", "SP1")
        self.assertIn("\"IST_STRADE\" = 'SP1'", f)
        self.assertIn("LIKE '%; SP1'", f)

    def test_gruppo_creato_aggiornato_tolto(self):
        ids = [f.id() for f in self.infra.getFeatures()]
        ist = types.SimpleNamespace(nome_base="X_SP1", corso="SP1", ente_nome="Provincia",
                                    interferenze=[types.SimpleNamespace(tratte_fid=ids[:2],
                                                                        elementi=[])])
        GR.crea_gruppo(self.prj, "strade", ist)
        gruppi = GR.gruppi_istanze(self.prj)
        self.assertEqual(len(gruppi), 1)
        g, sez, val = gruppi[0]
        self.assertEqual((sez, val), ("strade", "SP1"))
        vista = g.findLayers()[0].layer()
        self.assertTrue(vista.subsetString())
        self.assertEqual(vista.featureCount(), 2)
        # il layer principale resta quello comunale, completo
        self.assertIs(GR.layer_principale(self.prj, "03 INFRASTRUTTURE"), self.infra)
        self.assertEqual(self.infra.featureCount(), 5)
        # un altro aggiornamento non rifà i layer
        prima = [n.layerId() for n in g.findLayers()]
        GR.sincronizza_gruppi(self.prj)
        self.assertEqual(prima, [n.layerId() for n in g.findLayers()])
        # istanza tolta dal registro: via il gruppo
        reg = GR.registro(self.prj)
        reg.pop("X_SP1")
        GR.registro(self.prj, reg)
        GR.sincronizza_gruppi(self.prj)
        self.assertEqual(GR.gruppi_istanze(self.prj), [])


if __name__ == "__main__":
    unittest.main()
