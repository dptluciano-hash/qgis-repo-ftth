import os
import sys
import unittest

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, QUI)
import ftth_arlo as AR  # noqa: E402
import ftth_rfi as R  # noqa: E402

try:
    import docx  # noqa: F401
    HA_DOCX = True
except ImportError:
    HA_DOCX = False


def _tr(et, metri, pozz, arlo):
    t = R.Tratta("", "", metri, pozz, et, [(et, pozz)] if pozz else [])
    t._elementi = [{"tipo": "scavo", "arlo": arlo}]
    return t


class TestArlo(unittest.TestCase):
    def test_assegna_ordina(self):
        tr = [_tr("A", {"trincea": 5}, {}, "210"), _tr("B", {"trincea": 3}, {}, "201"),
              _tr("C", {"trincea": 1}, {}, "")]
        self.assertTrue(AR.assegna(tr))
        AR.ordina(tr)
        self.assertEqual([t.etichetta for t in tr], ["B", "A", "C"])
        senza = [R.Tratta("", "", {"trincea": 1}, {}, "X", [])]
        senza[0]._elementi = [{"tipo": "scavo"}]
        self.assertFalse(AR.assegna(senza))

    def test_numero(self):
        self.assertEqual(AR.chiave_numero("225 - 05")[0], 225)
        self.assertEqual(AR._fmt(["210", "201", "", "201"]), "201, 210")

    @unittest.skipUnless(HA_DOCX, "python-docx non disponibile")
    def test_colonna_nella_rt(self):
        from docx import Document
        doc = Document(os.path.join(QUI, "modelli_acque", "TEMPLATE_1.2_RT+CR.docx"))
        tr = [_tr("Via B", {"trincea": 5}, {"76x40": 1}, "210"),
              _tr("Via A", {"minitrincea": 3}, {"125x80": 1}, "201")]
        AR.assegna(tr)
        AR.ordina(tr)
        R.riempi_tabelle_rt(doc, tr)
        n0 = len(doc.tables[R.RT_TAB_SCAVI].columns)
        AR.colonne_rt(doc, tr)
        tb = doc.tables[R.RT_TAB_SCAVI]
        self.assertEqual(len(tb.columns), n0 + 1)
        testi = [[c.text.strip() for c in r.cells] for r in tb.rows]
        self.assertTrue(any(AR.INTESTAZIONE in r for r in testi))
        dati = [r for r in testi if r[0] in ("Via A", "Via B")]
        self.assertEqual([(r[0], r[1]) for r in dati], [("Via A", "201"), ("Via B", "210")])
        tp = doc.tables[R.RT_TAB_POZZETTI]
        dati_p = [[c.text.strip() for c in r.cells][:2] for r in tp.rows
                  if r.cells[0].text.strip() in ("Via A", "Via B")]
        self.assertEqual(dati_p, [["Via A", "201"], ["Via B", "210"]])


if __name__ == "__main__":
    unittest.main()
