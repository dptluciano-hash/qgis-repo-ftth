import os
import sys
import unittest

QUI = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, QUI)
import ftth_vincoli as V  # noqa: E402
import ftth_acque as A  # noqa: E402


def _interf(vincoli):
    i = A.InterferenzaAcqua(id=1, tipo="area", corso="X", categoria="vincolo",
                            ente_tipo="soprintendenza", ente_nome="S")
    i.metri = {"trincea": 20, "minitrincea": 50, "nodig": 10}
    i.pozzetti = {"125x80": 1}
    i.elementi = [{"tipo": "scavo", "tecnica": "trincea", "metri": 20},
                  {"tipo": "scavo", "tecnica": "minitrincea", "metri": 50},
                  {"tipo": "pozzetto", "dim": "125x80"},
                  {"tipo": "armadio"}]
    i.vincoli = vincoli
    return i


class TestElementiSopr(unittest.TestCase):
    def test_proposta(self):
        self.assertEqual(V.proposta_elementi(["art142c"])[0], {"armadi", "comunicazione"})
        self.assertEqual(V.proposta_elementi(["art142c", "art142m"])[0], V.TUTTI_ELEMENTI)
        self.assertEqual(V.proposta_elementi(["art136"])[0], V.TUTTI_ELEMENTI)
        self.assertEqual(V.proposta_elementi(["art142g"])[0], V.TUTTI_ELEMENTI)
        self.assertEqual(V.proposta_elementi([])[0], V.TUTTI_ELEMENTI)

    def test_filtro(self):
        i = _interf(["art142c"])
        j = V.filtra_elementi(i, V.proposta_elementi(i.vincoli)[0])
        self.assertEqual(j.metri, {"minitrincea": 50})
        self.assertEqual(j.pozzetti, {})
        self.assertEqual([e["tipo"] for e in j.elementi], ["scavo", "armadio"])
        self.assertEqual(j.vincoli, ["art142c"])
        # tutto
        self.assertEqual(V.filtra_elementi(i, V.TUTTI_ELEMENTI).metri, i.metri)
        # niente da presentare
        self.assertIsNone(V.filtra_elementi(_senza_nodig(i), {"nodig"}))


def _senza_nodig(i):
    import dataclasses
    j = dataclasses.replace(i, metri={"trincea": 20}, pozzetti={},
                            elementi=[{"tipo": "scavo", "tecnica": "trincea", "metri": 20}])
    j.vincoli = i.vincoli
    return j


if __name__ == "__main__":
    unittest.main()
