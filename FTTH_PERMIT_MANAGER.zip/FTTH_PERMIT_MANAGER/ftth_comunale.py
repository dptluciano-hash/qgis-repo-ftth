# -*- coding: utf-8 -*-
"""Tabelle e relazione tecnica dell'istanza comunale (senza QGIS).

Porta nel plugin le due macro usate finora:
- «Macro_Quantificazione delle Opere» (Excel): dai file del join della scheda
  Esportazione (SCAVI_STRADE, POZZETTI_STRADE, ARMADI_FOTO) le tabelle
  01 Scavi, 01b Pubblica Illuminazione, 02 Pozzetti, 03 Armadi, con le stesse
  regole e la stessa grafica;
- «NOME_COMUNE_RT» (Word): il modello della relazione compilato con nome del
  comune, nome del file, data e le tabelle; il capitolo della Pubblica
  Illuminazione sparisce se non ci sono tratte.
Le righe dei layer arrivano come dizionari {campo: valore} (vedi la UI).
"""
import datetime
import math
import os
import re

# come la costante della macro: le tratte di Pubblica Illuminazione vanno
# nella tabella 01b e NON anche negli scavi
ESCLUDI_PI_DA_SCAVI = True

TECNICHE = [("MICROTRINCEA", "Microtrincea (m)"), ("MINITRINCEA", "Minitrincea (m)"),
            ("TRADIZIONALE", "Tradizionale (m)"), ("NODIG", "No-Dig (m)"),
            ("CANALETTA", "Canaletta (m)")]
POZZETTI = ["40x15", "50x50", "90x70", "125x80", "40x76"]
COL_VIA = "Nome Strada\\Piazza"
TOTALE = "TOTALE GENERALE"
BLU = "0070C0"

FILE_SCAVI = "01_Quantificazione_Scavi.xlsx"
FILE_PI = "01b_Quantificazione_Pubblica_Illuminazione.xlsx"
FILE_POZZETTI = "02_Quantificazione_Pozzetti.xlsx"
FILE_ARMADI = "03_Posizionamento_Armadi.xlsx"
TEMPLATE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "modelli_comunale",
                        "TEMPLATE_RT_COMUNALE.docx")
ANCORE = {"scavi": "TABELLA INTERVENTI:", "pozzetti": "TABELLA POZZETTI NUOVA POSA:",
          "armadi": "UBICAZIONE ARMADI:",
          "pi": "TABELLA INFRASTRUTTURE PUBBLICA ILLUMINAZIONE:"}
SEGNALIBRO_PI = "PubblicaIlluminazione_Blocco"

_RE_IP = re.compile(r"\bIP\b", re.I)
_RE_3P = re.compile(r"(3\s*(RD|TH)|THIRD)[\s_-]*PART", re.I)


# ------------------------------------------------------------ utilità
def _campo(riga: dict, *nomi):
    """Valore del primo campo presente (senza badare alle maiuscole)."""
    low = {}
    for k in riga:                       # il primo campo con quel nome, come Excel
        low.setdefault(k.lower(), k)
    for n in nomi:
        if n.lower() in low:
            v = riga[low[n.lower()]]
            return v
    return None


def _ha_campo(righe: list, *nomi) -> bool:
    if not righe:
        return False
    low = {k.lower() for k in righe[0]}
    return any(n.lower() in low for n in nomi)


def _testo(v) -> str:
    if v is None:
        return ""
    s = str(v)
    return "" if s.upper() in ("NULL", "NONE") else s


_ACCENTI = {"á": "à", "í": "ì", "ó": "ò", "ú": "ù", "Á": "À", "Í": "Ì", "Ó": "Ò", "Ú": "Ù"}
_GRAVE = {"A": "À", "E": "È", "I": "Ì", "O": "Ò", "U": "Ù",
          "a": "à", "e": "è", "i": "ì", "o": "ò", "u": "ù"}


def pulisci_testo(s) -> str:
    """Refusi dei DBF: testo letto con la codifica sbagliata («Nicol├▓»,
    «LocalitÃ ») e accento acuto al posto del grave su a/i/o/u
    («Localitá» -> «Località»): in italiano su quelle vocali va il grave."""
    t = _testo(s)
    if any(c in t for c in ("Ã", "├", "Â")):
        for enc in ("cp1252", "cp437", "latin-1"):
            try:
                cand = t.encode(enc).decode("utf-8")
                t = cand
                break
            except (UnicodeEncodeError, UnicodeDecodeError):
                continue
    for a, b in _ACCENTI.items():
        t = t.replace(a, b)
    # accento scritto come apostrofo in fondo alla parola: GIOSUE' -> GIOSUÈ,
    # NICOLO' -> NICOLÒ (non tocca DELL'ARTE, dove dopo c'è una lettera)
    t = re.sub(r"([AEIOUaeiou])['’](?=$|[\s,.;:)\-])",
               lambda m: _GRAVE[m.group(1)], t)
    return " ".join(t.split())


def civico_pulito(v) -> str:
    """Civico: 9999 (o 999), il «senza numero» dei DBF, diventa SNC."""
    s = _testo(v).strip()
    if re.fullmatch(r"\d+\.0", s):
        s = s[:-2]
    return "SNC" if s in ("9999", "999") else s


def _num(v) -> float:
    try:
        return float(str(v).replace(",", "."))
    except (TypeError, ValueError):
        return 0.0


def _arrotonda_su(x: float) -> int:
    # RoundUp(x, 0) di Excel: per eccesso (i metri sono positivi)
    return int(math.ceil(round(x, 9)))


def normalizza_tipologia(s) -> str:
    t = _testo(s).strip().upper().replace("-", "").replace(" ", "").replace("_", "")
    if t.startswith("CANAL"):            # «Canaletta VTR», «Canala in VTR/FeZn»
        return "CANALETTA"
    return t if t in {k for k, _ in TECNICHE} else ""


def togli_paragrafo_canala(doc) -> bool:
    """Senza canaletta nella tabella scavi: via il paragrafo «CANALA IN
    VTR/FeZn…» (titolo, testo e la riga vuota dopo)."""
    ps = doc.paragraphs
    k = next((i for i, p in enumerate(ps)
              if p.text.strip().upper().startswith("CANALA IN VTR")), None)
    if k is None:
        return False
    via = [ps[k]]
    for p in ps[k + 1:]:
        via.append(p)
        if not p.text.strip():
            break
    for p in via:
        p._p.getparent().remove(p._p)
    return True


def e_pubblica_illuminazione(riga: dict, ha_prop: bool, ha_note: bool) -> bool:
    """Stessa regola della macro (e dello stile QGIS): PROPRIETA «IP» o vuota
    (se il campo c'è), oppure «IP» / «third party» nelle note."""
    if ha_prop:
        p = _testo(_campo(riga, "PROPRIETA")).strip().upper()
        if p in ("IP", ""):
            return True
    if ha_note:
        n = _testo(_campo(riga, "NOTES", "NOTE"))
        if _RE_IP.search(n) or _RE_3P.search(n):
            return True
    return False


def _vie_in_ordine(righe):
    """Vie nell'ordine in cui compaiono (come «Rimuovi duplicati» di Excel)."""
    viste = []
    for r in righe:
        v = _testo(_campo(r, "name")).strip()
        if v and v not in viste:
            viste.append(v)
    return viste


def _via(r) -> str:
    return _testo(_campo(r, "name")).strip()


def _togli_colonne_vuote(intest, righe, prima=1, ultima=None):
    """Toglie le colonne numeriche (da `prima` a `ultima` esclusa) che sommano
    a zero, come la macro."""
    ultima = len(intest) - 1 if ultima is None else ultima
    tenere = [k for k in range(len(intest))
              if k < prima or k >= ultima or sum(r[k] for r in righe) != 0]
    return [intest[k] for k in tenere], [[r[k] for k in tenere] for r in righe]


def _con_totale(intest, righe):
    tot = [TOTALE] + [sum(r[k] for r in righe) for k in range(1, len(intest))]
    return righe + [tot]


# ------------------------------------------------------------ tabelle
def tabella_scavi(righe: list) -> dict:
    """01 Scavi. Ritorna {'intest', 'righe' (con TOTALE GENERALE), 'esclusi_pi'}
    oppure None se non ci sono i campi necessari."""
    if not righe or not all(_ha_campo(righe, c) for c in ("TIPOLOGIA", "STATO", "name", "Lungh")):
        return None
    ha_prop, ha_note = _ha_campo(righe, "PROPRIETA"), _ha_campo(righe, "NOTES", "NOTE")
    tenute, esclusi = [], 0
    for r in righe:
        if not _testo(_campo(r, "name")).strip():
            continue
        if not normalizza_tipologia(_campo(r, "TIPOLOGIA")):
            continue
        if _testo(_campo(r, "STATO")).strip().upper() != "NUOVO":
            continue
        if ESCLUDI_PI_DA_SCAVI and e_pubblica_illuminazione(r, ha_prop, ha_note):
            esclusi += 1
            continue
        tenute.append(r)
    intest = [COL_VIA] + [t for _k, t in TECNICHE] + ["Totale Strada (m)"]
    out = []
    for via in _vie_in_ordine(tenute):
        vals = []
        for k, _t in TECNICHE:
            s = sum(_num(_campo(r, "Lungh")) for r in tenute
                    if _testo(_campo(r, "name")).strip() == via
                    and normalizza_tipologia(_campo(r, "TIPOLOGIA")) == k)
            vals.append(_arrotonda_su(s))
        out.append([via] + vals + [sum(vals)])
    intest, out = _togli_colonne_vuote(intest, out)
    return {"intest": intest, "righe": _con_totale(intest, out) if out else [],
            "esclusi_pi": esclusi}


def tabella_pi(righe: list) -> dict:
    """01b Pubblica Illuminazione (qualsiasi STATO e TIPOLOGIA). None se il
    DBF non ha né PROPRIETA né NOTES, o se non ci sono tratte."""
    if not righe or not all(_ha_campo(righe, c) for c in ("name", "Lungh")):
        return None
    ha_prop, ha_note = _ha_campo(righe, "PROPRIETA"), _ha_campo(righe, "NOTES", "NOTE")
    if not ha_prop and not ha_note:
        return None
    pi = [r for r in righe if _testo(_campo(r, "name")).strip()
          and e_pubblica_illuminazione(r, ha_prop, ha_note)]
    if not pi:
        return None
    intest = [COL_VIA, "Lunghezza Infrastruttura (m)"]
    out = [[via, _arrotonda_su(sum(_num(_campo(r, "Lungh")) for r in pi
                                   if _testo(_campo(r, "name")).strip() == via))]
           for via in _vie_in_ordine(pi)]
    return {"intest": intest, "righe": _con_totale(intest, out), "n": len(pi)}


def tabella_pozzetti(righe: list) -> dict:
    if not righe or not all(_ha_campo(righe, c) for c in ("STATO", "name", "TIPO_POZZE")):
        return None
    tenuti = [r for r in righe if _testo(_campo(r, "name")).strip()
              and _testo(_campo(r, "STATO")).strip() != "Esistente"]
    intest = [COL_VIA] + POZZETTI + ["Totale Strada"]
    out = []
    for via in _vie_in_ordine(tenuti):
        vals = [sum(1 for r in tenuti if _testo(_campo(r, "name")).strip() == via
                    and _testo(_campo(r, "TIPO_POZZE")).strip().lower() == d.lower())
                for d in POZZETTI]
        out.append([via] + vals + [sum(vals)])
    intest, out = _togli_colonne_vuote(intest, out)
    return {"intest": intest, "righe": _con_totale(intest, out) if out else []}


def tabella_armadi(righe: list) -> dict:
    if not righe or not all(_ha_campo(righe, c) for c in ("AREA_AO", "INDIRIZZO", "CIVICO")):
        return None
    ha_foto = _ha_campo(righe, "NumeroFoto")

    def _t(v):
        s = _testo(v)
        return s[:-2] if re.fullmatch(r"\d+\.0", s) else s
    out = [[_t(_campo(r, "AREA_AO")), pulisci_testo(_campo(r, "INDIRIZZO")),
            civico_pulito(_campo(r, "CIVICO")), _t(_campo(r, "NumeroFoto")) if ha_foto else ""]
           for r in righe if _testo(_campo(r, "INDIRIZZO")).strip()]

    def _ordine(riga):
        m = re.search(r"\d+", riga[0])
        return (int(m.group(0)) if m else 10 ** 9, riga[0])
    out.sort(key=_ordine)                      # in ordine di numero di armadio
    return {"intest": ["ARMADIO", "INDIRIZZO", "CIVICO", "FOTO"], "righe": out}


# ------------------------------------------------------------ Excel
def scrivi_xlsx(percorso: str, tab: dict, con_totale: bool = True):
    """Come FormattaE_Salva della macro: Times New Roman, bordi sottili,
    intestazione (e TOTALE GENERALE) blu con testo bianco in grassetto."""
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
    wb = Workbook()
    ws = wb.active
    righe = [tab["intest"]] + tab["righe"]
    sottile = Side(style="thin")
    blu = PatternFill("solid", fgColor=BLU)
    for i, r in enumerate(righe, 1):
        for j, v in enumerate(r, 1):
            c = ws.cell(row=i, column=j, value=v)
            evid = i == 1 or (con_totale and i == len(righe) and str(r[0]) == TOTALE)
            c.font = Font(name="Times New Roman", bold=evid, color="FFFFFF" if evid else "000000")
            if evid:
                c.fill = blu
            c.border = Border(left=sottile, right=sottile, top=sottile, bottom=sottile)
            c.alignment = Alignment(horizontal="left", vertical="center")
            if isinstance(v, (int, float)):
                c.number_format = "0"
    for j in range(1, len(tab["intest"]) + 1):
        larg = max(len(str(r[j - 1])) for r in righe)
        ws.column_dimensions[ws.cell(row=1, column=j).column_letter].width = min(60, larg + 3)
    wb.save(percorso)


# ------------------------------------------------------------ Word
def _imposta_cella(cella, testo, evid):
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt, RGBColor
    cella.text = ""
    p = cella.paragraphs[0]
    run = p.add_run(str(testo))
    run.font.name = "Times New Roman"
    run.font.size = Pt(10)
    rpr = run._r.get_or_add_rPr()
    fonts = rpr.find(qn("w:rFonts"))
    if fonts is None:
        fonts = OxmlElement("w:rFonts"); rpr.insert(0, fonts)
    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        fonts.set(qn(a), "Times New Roman")
    pf = p.paragraph_format
    pf.space_before = Pt(0); pf.space_after = Pt(0)
    # lo stile normale del modello tiene i paragrafi «con il successivo»:
    # nelle celle la catena unirebbe tutte le tabelle e Word le sposterebbe
    # in blocco alla pagina dopo
    pf.keep_with_next = False
    pf.keep_together = False
    if evid:
        run.bold = True
        run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
        sh = OxmlElement("w:shd")
        sh.set(qn("w:val"), "clear"); sh.set(qn("w:color"), "auto"); sh.set(qn("w:fill"), BLU)
        cella._tc.get_or_add_tcPr().append(sh)


def _tabella_word(doc, tab):
    """Tabella Word come quelle incollate dalla macro: Times New Roman 10,
    bordi, larga quanto il testo, centrata; intestazione e TOTALE in blu."""
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    righe = [tab["intest"]] + tab["righe"]
    t = doc.add_table(rows=len(righe), cols=len(tab["intest"]))
    tblpr = t._tbl.tblPr
    bordi = OxmlElement("w:tblBorders")
    for lato in ("top", "left", "bottom", "right", "insideH", "insideV"):
        b = OxmlElement("w:%s" % lato)
        b.set(qn("w:val"), "single"); b.set(qn("w:sz"), "4"); b.set(qn("w:color"), "000000")
        bordi.append(b)
    tblpr.append(bordi)
    jc = OxmlElement("w:jc"); jc.set(qn("w:val"), "center"); tblpr.append(jc)
    tw = tblpr.find(qn("w:tblW"))
    if tw is None:
        tw = OxmlElement("w:tblW"); tblpr.append(tw)
    # tutte le tabelle uniformi: larghe quanto il testo della pagina, colonne
    # distribuite da Word secondo il contenuto
    tw.set(qn("w:w"), "5000"); tw.set(qn("w:type"), "pct")
    lay = OxmlElement("w:tblLayout"); lay.set(qn("w:type"), "autofit"); tblpr.append(lay)
    for i, r in enumerate(righe):
        evid = i == 0 or (i == len(righe) - 1 and str(r[0]) == TOTALE)
        for j, v in enumerate(r):
            _imposta_cella(t.rows[i].cells[j], v, evid)
    for tc in t._tbl.iter(qn("w:tc")):
        pr = tc.tcPr
        w = pr.find(qn("w:tcW")) if pr is not None else None
        if w is not None:
            w.set(qn("w:w"), "0"); w.set(qn("w:type"), "auto")
    for g in t._tbl.iter(qn("w:gridCol")):
        if g.get(qn("w:w")):
            del g.attrib[qn("w:w")]
    return t


def _inserisci_dopo(doc, testo_ancora, tab, togli_salto_dopo=True) -> bool:
    """Tabella subito dopo il paragrafo che contiene `testo_ancora`, con una
    riga vuota dopo (come la tabella incollata dalla macro)."""
    from docx.oxml import OxmlElement
    for p in doc.paragraphs:
        if testo_ancora in p.text:
            from docx.text.paragraph import Paragraph
            from docx.oxml.ns import qn
            # nel modello vuoto dopo il titolo c'è un'interruzione di pagina:
            # incollando la tabella la macro la sostituiva, qui si toglie
            # (anche nel paragrafo vuoto subito dopo, che il modello usa per
            # andare a pagina nuova)
            succ = p._p.getnext()
            zone = [p._p]
            if togli_salto_dopo and succ is not None and succ.tag == qn("w:p") and \
                    not "".join(t.text or "" for t in succ.iter(qn("w:t"))).strip():
                zone.append(succ)
            for el in zone:
                for br in list(el.iter(qn("w:br"))):
                    if br.get(qn("w:type")) == "page":
                        run = br.getparent()
                        run.remove(br)
                        if not any(c.tag != qn("w:rPr") for c in run):
                            run.getparent().remove(run)
            t = _tabella_word(doc, tab)
            p._p.addnext(t._tbl)
            vuoto = OxmlElement("w:p")
            t._tbl.addnext(vuoto)
            Paragraph(vuoto, p._parent).paragraph_format.keep_with_next = False
            return True
    return False


def _togli_segnalibro(doc, nome) -> bool:
    """Toglie il contenuto del segnalibro (i paragrafi dall'inizio alla fine),
    come EliminaSegnalibro della macro."""
    from docx.oxml.ns import qn
    body = doc.element.body
    start = next((b for b in body.iter(qn("w:bookmarkStart")) if b.get(qn("w:name")) == nome),
                 None)
    if start is None:
        return False
    bid = start.get(qn("w:id"))
    end = next((b for b in body.iter(qn("w:bookmarkEnd")) if b.get(qn("w:id")) == bid), None)

    def _blocco(el):
        while el is not None and el.getparent() is not body:
            el = el.getparent()
        return el
    a, z = _blocco(start), _blocco(end) if end is not None else None
    if a is None:
        return False
    if z is None:
        z = a
    figli = list(body)
    i, j = figli.index(a), figli.index(z)
    if z is not a and end is not None:
        # fine del segnalibro all'inizio del paragrafo successivo (prima di
        # qualsiasi testo): quel paragrafo è il capitolo dopo e resta
        testo_prima = False
        for el in z.iter():
            if el is end:
                break
            if el.tag == qn("w:t") and (el.text or "").strip():
                testo_prima = True
                break
        if not testo_prima:
            j -= 1
    for el in figli[i:j + 1]:
        if not el.tag.endswith("}sectPr"):
            body.remove(el)
    return True


def _ripara_stili(doc) -> int:
    """Il modello (salvato da un Word in inglese) richiama alcuni stili con il
    nome («Title») invece che con l'id del file («Titolo»): Word allora usa il
    suo stile predefinito e la copertina scivola su due pagine. Quando la
    macro girava dentro Word la correzione la faceva Word; qui si rimappano i
    riferimenti al loro id."""
    from docx.oxml.ns import qn
    st = doc.styles.element
    ids = {s.get(qn("w:styleId")) for s in st.iter(qn("w:style"))}
    per_nome = {}
    for s in st.iter(qn("w:style")):
        n = s.find(qn("w:name"))
        if n is not None:
            per_nome.setdefault(n.get(qn("w:val")), s.get(qn("w:styleId")))
            per_nome.setdefault(n.get(qn("w:val")).replace(" ", ""), s.get(qn("w:styleId")))
    n_fix = 0
    parti = [doc.element] + [hf._element for s in doc.sections for hf in (s.header, s.footer)
                             if not hf.is_linked_to_previous]
    for radice in parti:
        for tag in ("w:pStyle", "w:rStyle", "w:tblStyle"):
            for el in radice.iter(qn(tag)):
                v = el.get(qn("w:val"))
                if v and v not in ids and v in per_nome:
                    el.set(qn("w:val"), per_nome[v])
                    n_fix += 1
    return n_fix


# testo dell'utente (2026-11-27)
TITOLO_COLONNINA = "COLONNINE PTE"
TESTI_COLONNINA = (
    "La Colonnina in materiale metallico e colorazione grigia con tettuccio rosso, dove "
    "all’interno viene posato il PTE, rappresenta il punto di consegna delle fibre dei cavi "
    "ottici provenienti dalla rete esterna in prossimità delle sedi dei Clienti, in una "
    "posizione esterna rispetto agli edifici.",
    "La posa delle colonnine è prevista sempre in prossimità a terminazioni già esistenti, al "
    "fine di ridurre l’impatto visivo.",
)


def aggiungi_colonnina(doc, comune: str = "") -> bool:
    """Capitolo «COLONNINA PTE» in fondo alla RT comunale, con la stessa
    formattazione del capitolo «ARMADIO OTTICO» (titolo numerato: entra
    nell'indice quando Word lo aggiorna), più la voce «Posa di colonnine PTE»
    nell'elenco della premessa e il rimando ai particolari della PL."""
    import copy
    ps = doc.paragraphs

    def _trova(cond):
        return next((p for p in ps if cond(p.text.strip())), None)

    tit = _trova(lambda t: t.upper() == "ARMADIO OTTICO")
    if tit is None:
        return False
    k = ps.index(tit)
    corpo = ps[k + 1] if k + 1 < len(ps) else None
    nota = None
    for p in reversed(ps[:k]):
        if p.text.strip().startswith("*Particolari costruttivi"):
            nota = p
            break

    def _testo(p, testo):
        runs = p.runs
        if runs:
            runs[0].text = testo
            for r in runs[1:]:
                r._r.getparent().remove(r._r)
        else:
            p.add_run(testo)
        return p

    from docx.oxml.ns import qn
    from docx.text.paragraph import Paragraph
    # in fondo, DOPO tutto il capitolo armadio (anche la sua figura: prima il
    # capitolo finiva fra il testo dell'armadio e la figura)
    body = doc.element.body
    dove = None
    for el in reversed(list(body)):
        if el.tag == qn("w:sectPr"):
            continue
        testo_el = "".join(el.itertext()).strip()
        figura = el.find(".//" + qn("w:drawing")) is not None or \
            el.find(".//" + qn("w:pict")) is not None
        if testo_el or figura:
            dove = el
            break
    if dove is None:
        return False
    padre = tit._parent
    aggiunti = []

    def _dopo(modello, testo):
        nonlocal dove
        el = copy.deepcopy(modello._p)
        dove.addnext(el)
        dove = el
        p = _testo(Paragraph(el, padre), testo)
        aggiunti.append(p)
        return p
    t_ = _dopo(tit, TITOLO_COLONNINA)
    t_.paragraph_format.page_break_before = True       # pagina nuova, come l'armadio
    for t in TESTI_COLONNINA:
        if corpo is not None:
            _dopo(corpo, t)
    # figura della colonnina (il disegno PC-20), centrata, come quella dell'armadio
    png = _png_colonnina()
    if png and corpo is not None:
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.shared import Cm
        p = _dopo(corpo, "")
        for r in p.runs:
            r.text = ""
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        (p.runs[0] if p.runs else p.add_run()).add_picture(png, width=Cm(13))
    if nota is not None:
        _dopo(nota, "*Particolari costruttivi allegati al documento %s_PL.pdf"
              % ((comune or "").strip().upper() or "<<NOME_COMUNE>>"))
    # premessa: «Posa di armadi ottici.» → «…;» + «Posa di colonnine PTE.»
    voce = _trova(lambda t: t.lower().startswith("posa di armadi ottici"))
    if voce is not None:
        el = copy.deepcopy(voce._p)
        voce._p.addnext(el)
        _testo(voce, voce.text.rstrip(". ") + ";")
        _testo(Paragraph(el, voce._parent), "Posa di colonnine PTE.")
    return True


def _png_colonnina():
    """PNG del disegno della colonnina (dentro l'SVG PC-20 c'è l'immagine)
    per la figura della relazione. None se non si trova."""
    import base64
    import re
    import tempfile
    svg = file_particolare_colonnina()
    if not svg:
        return None
    if svg.lower().endswith(".png"):
        return svg
    try:
        testo = open(svg, encoding="utf-8", errors="ignore").read()
        m = re.search(r"data:image/png;base64,([A-Za-z0-9+/=\s]+)", testo)
        if not m:
            return None
        out = os.path.join(tempfile.gettempdir(), "ftth_colonnina_rt.png")
        with open(out, "wb") as fh:
            fh.write(base64.b64decode(re.sub(r"\s", "", m.group(1))))
        return out
    except Exception:  # noqa: BLE001
        return None


def file_particolare_colonnina():
    """Il particolare costruttivo della colonnina PTE del plugin (PC-20)."""
    import glob
    cart = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets", "rfi_particolari")
    trovati = sorted(glob.glob(os.path.join(cart, "*colonnina*.svg"))) or \
        sorted(glob.glob(os.path.join(cart, "*colonnina*.png")))
    return trovati[0] if trovati else None


def riquadro_centrato(area, dim):
    """(x, y, w, h) del disegno di misura `dim` (w, h) ingrandito/ridotto per
    stare nell'area (x, y, w, h) e centrato nei due sensi."""
    ax, ay, aw, ah = area
    wn, hn = dim
    f = min(aw / wn, ah / hn)
    w, h = wn * f, hn * f
    return ax + (aw - w) / 2.0, ay + (ah - h) / 2.0, w, h


def contenuto_disegno(path, lato_px=800):
    """Dove sta il disegno vero nel file (senza i margini bianchi o
    trasparenti, spesso diversi a destra e a sinistra): (x0, y0, x1, y1) in
    frazioni 0..1 del file. (0, 0, 1, 1) se non si riesce a leggere."""
    from qgis.PyQt.QtCore import QRectF, Qt as _Qt
    from qgis.PyQt.QtGui import QColor, QImage, QPainter
    try:
        if path.lower().endswith(".svg"):
            from qgis.PyQt.QtSvg import QSvgRenderer
            r = QSvgRenderer(path)
            s = r.defaultSize()
            if s.width() <= 0 or s.height() <= 0:
                return 0.0, 0.0, 1.0, 1.0
            k = lato_px / float(max(s.width(), s.height()))
            img = QImage(max(1, int(s.width() * k)), max(1, int(s.height() * k)),
                         QImage.Format_ARGB32)
            img.fill(_Qt.white)
            p = QPainter(img)
            r.render(p, QRectF(0, 0, img.width(), img.height()))
            p.end()
        else:
            img = QImage(path)
            if img.isNull():
                return 0.0, 0.0, 1.0, 1.0
            img = img.scaled(lato_px, lato_px, _Qt.KeepAspectRatio)
        w, h = img.width(), img.height()
        xs, ys = [], []
        for y in range(0, h, 2):
            for x in range(0, w, 2):
                c = QColor(img.pixel(x, y))
                if c.alpha() > 20 and min(c.red(), c.green(), c.blue()) < 235:
                    xs.append(x)
                    ys.append(y)
        if not xs:
            return 0.0, 0.0, 1.0, 1.0
        return (min(xs) / w, min(ys) / h, min(1.0, (max(xs) + 2) / w), min(1.0, (max(ys) + 2) / h))
    except Exception:  # noqa: BLE001
        return 0.0, 0.0, 1.0, 1.0


def riquadro_sul_contenuto(area, dim, cont):
    """Come riquadro_centrato, ma conta il disegno vero (`cont`, frazioni del
    file): è il disegno a stare al centro dell'area e a riempirla, i margini
    bianchi del file possono uscire dall'area. Ritorna (x, y, w, h) del file."""
    ax, ay, aw, ah = area
    wn, hn = dim
    x0, y0, x1, y1 = cont
    cw, ch = wn * (x1 - x0), hn * (y1 - y0)
    f = min(aw / cw, ah / ch)
    W, H = wn * f, hn * f
    return (ax + aw / 2.0 - (x0 + x1) / 2.0 * W, ay + ah / 2.0 - (y0 + y1) / 2.0 * H, W, H)


CARTELLA_PC_COMUNALE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets",
                                    "particolari_comunale")
# particolari degli armadi per taglia (FO_USCENTI); 128 SMALL dal materiale
# fornito (scheda «AO 128 SMALL»: disegno della struttura + foto, senza quote)
FILE_PC_ARMADIO = {128: "PC-23_armadio-128-small.svg", 384: "PC-21_armadio-384-large.svg",
                   576: "PC-22_armadio-576-extra-large.svg"}
TITOLI_PC_ARMADIO = {128: "ARMADIO OTTICO 128 fo (SMALL)", 384: "ARMADIO OTTICO 384 fo (LARGE)",
                     576: "ARMADIO OTTICO 576 fo (EXTRA LARGE)"}


def file_particolare_armadio(fo):
    n = FILE_PC_ARMADIO.get(fo)
    p = os.path.join(CARTELLA_PC_COMUNALE, n) if n else None
    return p if p and os.path.isfile(p) else None


def pdf_particolare_colonnina(project, percorso, w_mm=420.0, h_mm=297.0, dpi=300):
    """Pagina «PARTICOLARE COSTRUTTIVO - COLONNINA PTE» della PL comunale."""
    svg = file_particolare_colonnina()
    if not svg:
        return None
    return pdf_particolare(project, svg, "PARTICOLARE COSTRUTTIVO - COLONNINA PTE", percorso,
                           w_mm, h_mm, dpi)


def pdf_particolare(project, svg, titolo, percorso, w_mm=420.0, h_mm=297.0, dpi=300):
    """Pagina di un particolare costruttivo della PL comunale, alla misura
    della pagina dei layout esportati: cornice, titolo e disegno centrato sul
    suo contenuto vero nello spazio sotto il titolo. Ritorna il percorso o
    None."""
    from qgis.core import (QgsLayoutExporter, QgsLayoutItemLabel, QgsLayoutItemPicture,
                           QgsLayoutItemShape, QgsLayoutPoint, QgsLayoutSize, QgsPrintLayout,
                           QgsUnitTypes, QgsLayoutItem)
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QFont
    try:
        from . import ftth_rfi_layout as L
    except ImportError:
        import ftth_rfi_layout as L
    lay = QgsPrintLayout(project)
    lay.initializeDefaults()
    lay.setName(titolo)
    pag = lay.pageCollection().page(0)
    pag.setPageSize(QgsLayoutSize(w_mm, h_mm, QgsUnitTypes.LayoutMillimeters))
    m = 10.0

    def _mv(it, x, y, w, h):
        it.attemptMove(QgsLayoutPoint(x, y, QgsUnitTypes.LayoutMillimeters))
        it.attemptResize(QgsLayoutSize(w, h, QgsUnitTypes.LayoutMillimeters))
    cornice = QgsLayoutItemShape(lay)
    cornice.setShapeType(QgsLayoutItemShape.Rectangle)
    try:
        from qgis.core import QgsFillSymbol
        cornice.setSymbol(QgsFillSymbol.createSimple(
            {"color": "255,255,255,0", "outline_color": "0,0,0", "outline_width": "0.4"}))
    except Exception:  # noqa: BLE001
        pass
    lay.addLayoutItem(cornice)
    _mv(cornice, m, m, w_mm - 2 * m, h_mm - 2 * m)
    h_tit = max(12.0, h_mm * 0.05)
    tit = QgsLayoutItemLabel(lay)
    tit.setText(titolo)
    f = QFont("Arial")
    f.setBold(True)
    f.setPointSizeF(max(14.0, h_mm / 18.0))
    try:
        from qgis.core import QgsTextFormat
        tf = QgsTextFormat.fromQFont(f)
        tf.setSize(f.pointSizeF())
        tit.setTextFormat(tf)
    except Exception:  # noqa: BLE001
        tit.setFont(f)
    tit.setHAlign(Qt.AlignHCenter)
    tit.setVAlign(Qt.AlignVCenter)
    lay.addLayoutItem(tit)
    _mv(tit, m, m + 4, w_mm - 2 * m, h_tit)
    # area del disegno: sotto il titolo, con 10 mm d'aria per lato
    area = (m + 10, m + 4 + h_tit + 6, w_mm - 2 * m - 20, h_mm - 2 * m - h_tit - 4 - 6 - 10)
    dim = L.misura_mm(svg) or L.dimensioni_svg(svg)
    # centrato sul disegno vero, non sul riquadro del file (margini bianchi
    # diversi ai lati spostavano il disegno)
    x, y, w, h = riquadro_sul_contenuto(area, dim, contenuto_disegno(svg))
    pic = QgsLayoutItemPicture(lay)
    pic.setPicturePath(svg)
    pic.setResizeMode(QgsLayoutItemPicture.Zoom)
    pic.setPictureAnchor(QgsLayoutItem.Middle)
    lay.addLayoutItem(pic)
    _mv(pic, x, y, w, h)
    # il file ha lo sfondo bianco: cornice e titolo sopra il disegno
    pic.setZValue(1)
    cornice.setZValue(5)
    tit.setZValue(6)
    st = QgsLayoutExporter.PdfExportSettings()
    st.dpi = dpi
    os.makedirs(os.path.dirname(percorso) or ".", exist_ok=True)
    esito = QgsLayoutExporter(lay).exportToPdf(percorso, st)
    return percorso if esito == QgsLayoutExporter.Success else None


def nome_file_rt(comune: str) -> str:
    return "%s_RT" % (comune or "COMUNE").strip().upper()


def genera_relazione(comune: str, tabelle: dict, cartella: str, oggi=None,
                     modello: str = TEMPLATE, colonnina: bool = False) -> str:
    """Compila il modello: <<NOME_COMUNE>>, <<NOME_FILE_COMPLETO>> (con .pdf),
    <<DATA>>, le tabelle dopo i loro titoli, il capitolo Pubblica
    Illuminazione tolto se manca la tabella 01b. Ritorna il .docx."""
    from docx import Document
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    oggi = oggi or datetime.date.today()
    doc = Document(modello)
    _ripara_stili(doc)
    nome = nome_file_rt(comune)
    rfi.sostituisci_tutto(doc, {"NOME_COMUNE": (comune or "").strip().upper(),
                                "NOME_FILE_COMPLETO": nome + ".pdf",
                                "DATA": oggi.strftime("%d/%m/%Y")})
    # le tabelle una dopo l'altra sulla stessa pagina; dopo l'ultima (armadi)
    # il salto di pagina resta: il capitolo dopo parte da pagina nuova
    for chiave in ("scavi", "pozzetti", "armadi"):
        tab = tabelle.get(chiave)
        if tab and tab.get("righe"):
            _inserisci_dopo(doc, ANCORE[chiave], tab, togli_salto_dopo=chiave != "armadi")
    sc = tabelle.get("scavi")
    if sc and sc.get("righe") and "Canaletta (m)" not in sc.get("intest", []):
        togli_paragrafo_canala(doc)
    if tabelle.get("pi") and tabelle["pi"].get("righe"):
        _inserisci_dopo(doc, ANCORE["pi"], tabelle["pi"], togli_salto_dopo=False)
    else:
        _togli_segnalibro(doc, SEGNALIBRO_PI)
    if colonnina:       # pulsante «Colonnina PTE» della consegna comunale
        aggiungi_colonnina(doc, comune)
    os.makedirs(cartella, exist_ok=True)
    out = os.path.join(cartella, nome + ".docx")
    doc.save(out)
    return out


def _pulisci_vie(righe: list) -> list:
    """Nomi delle vie senza refusi (codifica, accenti) prima di raggrupparli."""
    out = []
    for r in righe or []:
        k = next((c for c in r if c.lower() == "name"), None)
        out.append(dict(r, **{k: pulisci_testo(r[k])}) if k else r)
    return out


def calcola_tabelle(scavi: list, pozzetti: list, armadi: list) -> dict:
    scavi, pozzetti = _pulisci_vie(scavi), _pulisci_vie(pozzetti)
    return {"scavi": tabella_scavi(scavi), "pi": tabella_pi(scavi),
            "pozzetti": tabella_pozzetti(pozzetti), "armadi": tabella_armadi(armadi)}


def scrivi_tabelle_xlsx(tabelle: dict, cartella: str) -> list:
    os.makedirs(cartella, exist_ok=True)
    fatti = []
    for chiave, nome, tot in (("scavi", FILE_SCAVI, True), ("pi", FILE_PI, True),
                              ("pozzetti", FILE_POZZETTI, True), ("armadi", FILE_ARMADI, False)):
        tab = tabelle.get(chiave)
        if tab and tab.get("righe"):
            p = os.path.join(cartella, nome)
            scrivi_xlsx(p, tab, tot)
            fatti.append(p)
    return fatti


# ─────────────────────────────── PL: ordine dei layout e unione dei PDF
def gruppo_layout_pl(nome: str) -> int:
    """Posto del layout nella PL unita: 0 ortofoto, 1 planimetria (anche il
    keyplan combinato ORTO+INQUA), 2 tavole di inquadramento, 3 altro."""
    n = nome.upper()
    orto = "ORTO" in n
    plan = "INQUA" in n or "PLANIM" in n or re.search(r"(?<![A-Z])PLAN(?![A-Z])", n) is not None
    if orto and not plan:
        return 0
    if plan and "INQUADRAMENTO" not in n:
        return 1
    if "INQUADRAMENTO" in n or "TAVOL" in n:
        return 2
    if "KEYPLAN" in n:
        return 1
    return 3


def ordina_layout_pl(nomi: list) -> list:
    """Ortofoto → planimetria → tavole; a parità vale il numero iniziale del
    nome (01_, 02_…), poi l'ordine originale."""
    def _num(s):
        m = re.match(r"\s*(\d+)", s)
        return int(m.group(1)) if m else 9999
    return [n for _, n in sorted(enumerate(nomi), key=lambda t: (
        gruppo_layout_pl(t[1]), _num(t[1]), t[0]))]


def alternative_pl(nomi: list) -> list:
    """Layout selezionati che sono alternative fra loro, da far scegliere
    prima di unire. Ritorna [(titolo, [opzione, ...])] dove ogni opzione è
    (etichetta, [layout da tenere]):
    - keyplan combinato (ORTO+INQUA) insieme a ortofoto e/o planimetria
      separate;
    - più layout di tavole (es. 03_Inquadramento e 04_Inquadramento 6Foto)."""
    nomi = ordina_layout_pl(nomi)
    out = []
    comb = [n for n in nomi if gruppo_layout_pl(n) == 1 and "ORTO" in n.upper()]
    separati = [n for n in nomi if n not in comb and gruppo_layout_pl(n) in (0, 1)]
    if comb and separati:
        opz = [("%s (combinato)" % c, [c]) for c in comb]
        opz.append((" + ".join(separati) + " (separati)", separati))
        out.append(("Keyplan: combinato oppure ortofoto e planimetria separate?", opz))
    tav = [n for n in nomi if gruppo_layout_pl(n) == 2]
    if len(tav) > 1:
        out.append(("Tavole: quale layout usare?", [(t, [t]) for t in tav]
                    + [("tutti (" + " + ".join(tav) + ")", tav)]))
    return out


def unisci_pdf(percorsi: list, uscita: str):
    """Unisce i PDF nell'ordine dato. Ritorna (file uniti, file saltati).
    Usa pypdf / PyPDF2, altrimenti PyMuPDF (fitz)."""
    esistenti = [p for p in percorsi if p and os.path.isfile(p)]
    saltati = [p for p in percorsi if p not in esistenti]
    if not esistenti:
        raise RuntimeError("nessun PDF da unire")
    try:
        try:
            from pypdf import PdfWriter
        except ImportError:
            from PyPDF2 import PdfWriter
        w = PdfWriter()
        for p in esistenti:
            w.append(p)
        tmp = uscita + ".tmp"
        with open(tmp, "wb") as fh:
            w.write(fh)
    except ImportError:
        try:
            import pymupdf as fitz
        except ImportError:
            import fitz
        out = fitz.open()
        for p in esistenti:
            with fitz.open(p) as d:
                out.insert_pdf(d)
        tmp = uscita + ".tmp"
        out.save(tmp, garbage=3, deflate=True)
        out.close()
    os.replace(tmp, uscita)
    return len(esistenti), saltati
