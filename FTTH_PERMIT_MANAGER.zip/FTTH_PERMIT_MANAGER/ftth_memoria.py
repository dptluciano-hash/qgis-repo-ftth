# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Memoria del lavoro delle schede istanze, insieme al progetto QGIS.

Prima, riaperto un progetto, le schede erano vuote: ferrovie, fasce,
interferenze trovate erano layer temporanei (persi alla chiusura) e le
tabelle vivevano solo in memoria, quindi bisognava rifare screening e
ricerche (e «Calcola le chilometriche» chiedeva di riscaricare le ferrovie).

Ora:
- i layer creati dal plugin (ferrovia, fascia, cippi, stazioni, corsi
  d'acqua, interferenze, trovati) si scrivono in «01_File shp/FTTH_lavoro.gpkg»
  accanto al progetto: restano nel progetto salvato;
- salvando il progetto, lo stato di ogni scheda (comune, righe confermate,
  interferenze con tipologie, proprietari, foto) va in
  «<progetto>_FTTH_lavoro.dat» accanto al .qgz; riaprendo il progetto le
  schede si ricompilano da lì, senza rifare le ricerche.
"""
import io
import os
import pickle

GPKG = "FTTH_lavoro.gpkg"
SUFFISSO = "_FTTH_lavoro.dat"
VERSIONE = 1

# moduli ammessi nel file di stato (niente codice arbitrario da un file)
_MODULI_OK = ("FTTH_PERMIT_MANAGER", "ftth_", "shapely", "builtins", "collections",
              "datetime", "copyreg", "decimal", "numpy", "_codecs")


class _Lettore(pickle.Unpickler):
    def find_class(self, module, name):
        if not module.startswith(_MODULI_OK):
            raise pickle.UnpicklingError("classe non ammessa: %s.%s" % (module, name))
        if module == "builtins" and name in ("eval", "exec", "compile", "open",
                                             "__import__", "getattr", "setattr"):
            raise pickle.UnpicklingError("funzione non ammessa: %s" % name)
        return super().find_class(module, name)


# --------------------------------------------------------------- layer
def permanente(project, vl):
    """Scrive il layer temporaneo `vl` nel GeoPackage di lavoro accanto al
    progetto e ritorna il layer su file (stesso nome, stile, etichette e
    proprietà). Progetto non ancora salvato o errore: ritorna `vl`."""
    try:
        from qgis.core import QgsVectorFileWriter, QgsVectorLayer
        if vl is None or vl.providerType() != "memory":
            return vl
        home = project.homePath()
        if not home or not project.fileName():
            return vl
        cart = os.path.join(home, "01_File shp")
        os.makedirs(cart, exist_ok=True)
        gpkg = os.path.join(cart, GPKG)
        nome = vl.name()
        tabella = "".join(c if c.isalnum() else "_" for c in nome).strip("_") or "layer"
        opz = QgsVectorFileWriter.SaveVectorOptions()
        opz.driverName = "GPKG"
        opz.layerName = tabella
        opz.fileEncoding = "UTF-8"
        opz.actionOnExistingFile = (QgsVectorFileWriter.CreateOrOverwriteLayer
                                    if os.path.isfile(gpkg)
                                    else QgsVectorFileWriter.CreateOrOverwriteFile)
        err = QgsVectorFileWriter.writeAsVectorFormatV3(vl, gpkg, project.transformContext(), opz)
        if (err[0] if isinstance(err, tuple) else err) != QgsVectorFileWriter.NoError:
            return vl
        nuovo = QgsVectorLayer("%s|layername=%s" % (gpkg, tabella), nome, "ogr")
        if not nuovo.isValid():
            return vl
        if vl.renderer() is not None:
            nuovo.setRenderer(vl.renderer().clone())
        if vl.labeling() is not None:
            nuovo.setLabeling(vl.labeling().clone())
        nuovo.setLabelsEnabled(vl.labelsEnabled())
        nuovo.setOpacity(vl.opacity())
        for k in vl.customPropertyKeys():
            nuovo.setCustomProperty(k, vl.customProperty(k))
        for k in range(vl.fields().count()):
            j = nuovo.fields().indexOf(vl.fields().at(k).name())
            if j >= 0:
                nuovo.setEditorWidgetSetup(j, vl.editorWidgetSetup(k))
        return nuovo
    except Exception:  # noqa: BLE001
        return vl


# ---------------------------------------------------------------- stato
def percorso(project):
    fn = project.fileName() if project is not None else ""
    if not fn:
        return None
    return os.path.splitext(fn)[0] + SUFFISSO


def solo_salvabile(d: dict) -> dict:
    """Le voci dello stato che si possono scrivere (via layer e oggetti Qt)."""
    out = {}
    for k, v in (d or {}).items():
        try:
            pickle.dumps(v)
            out[k] = v
        except Exception:  # noqa: BLE001
            pass
    return out


def scrivi(project, schede: dict) -> bool:
    p = percorso(project)
    if not p:
        return False
    try:
        with open(p, "wb") as fh:
            pickle.dump({"versione": VERSIONE, "schede": schede}, fh)
        return True
    except Exception:  # noqa: BLE001
        return False


def leggi(project) -> dict:
    p = percorso(project)
    if not p or not os.path.isfile(p):
        return {}
    try:
        with open(p, "rb") as fh:
            dati = _Lettore(io.BytesIO(fh.read())).load()
        return dati.get("schede") or {}
    except Exception:  # noqa: BLE001
        return {}


# ----------------------------------------------------- schede del plugin
def _testi(dlg, nomi):
    out = {}
    for n in nomi:
        w = getattr(dlg, n, None)
        if w is not None and hasattr(w, "text"):
            out[n] = w.text()
    return out


def _metti_testi(dlg, valori):
    for n, v in (valori or {}).items():
        w = getattr(dlg, n, None)
        if w is not None and hasattr(w, "setText") and v:
            w.blockSignals(True)
            w.setText(v)
            w.blockSignals(False)


CAMPI = {
    "rfi": ["txt_rfi_comune", "txt_rfi_prov", "txt_rfi_cap", "txt_rfi_indirizzo",
            "txt_rfi_comune_pec"],
    "strade": ["txt_sti_comune", "txt_sti_prov", "txt_sti_cap", "txt_sti_ind_comune",
               "txt_sti_pec_comune"],
    "acque": ["txt_acq_comune", "txt_acq_prov", "txt_acq_cap", "txt_acq_indirizzo",
              "txt_acq_pec"],
}


def raccogli(dlg) -> dict:
    """Stato di tutte le schede istanze del dialogo (prima si riportano nello
    stato le correzioni fatte nelle tabelle: tipologie, spunte, enti…)."""
    for nome, args in (("_rfi_leggi_tabella", ()), ("_acq_leggi_tabella", ()),
                       ("_sti_leggi_strade", ()),
                       ("_vin_leggi_aree", ("sopr",)), ("_vin_leggi_tabella", ("sopr",)),
                       ("_vin_leggi_aree", ("parchi",)), ("_vin_leggi_tabella", ("parchi",))):
        fn = getattr(dlg, nome, None)
        if fn is not None:
            try:
                fn(*args)
            except Exception:  # noqa: BLE001
                pass
    schede = {}
    if hasattr(dlg, "_rfi_state"):
        st = dict(dlg._rfi_state())
        try:
            st["linee_confermate"] = set(dlg._rfi_linee_incluse() or [])
        except Exception:  # noqa: BLE001
            pass
        schede["rfi"] = {"campi": _testi(dlg, CAMPI["rfi"]), "stato": solo_salvabile(st)}
    if hasattr(dlg, "_sti"):
        schede["strade"] = {"campi": _testi(dlg, CAMPI["strade"]),
                            "stato": solo_salvabile(dlg._sti)}
    if hasattr(dlg, "_acq_state"):
        schede["acque"] = {"campi": _testi(dlg, CAMPI["acque"]),
                           "stato": solo_salvabile(dlg._acq_state())}
    for s in ("sopr", "parchi"):
        if s in (getattr(dlg, "_vin_st", None) or {}):
            w_ = dlg._vin_w[s]
            campi = {k: w_[k].text() for k in ("comune", "prov", "cap", "pec_comune",
                                               "ind_comune") if k in w_}
            schede[s] = {"campi": campi, "stato": solo_salvabile(dlg._vin_st[s])}
    return schede


def _prova(log, nome, fn):
    try:
        fn()
    except Exception as e:  # noqa: BLE001
        log("Memoria del lavoro, %s: non ripristinato (%s)" % (nome, e))


def ripristina(dlg, schede: dict, log=None) -> list:
    """Ricompila le schede dallo stato salvato. Ritorna le schede riprese."""
    log = log or (lambda _m: None)
    fatte = []
    d = schede.get("rfi")
    if d and hasattr(dlg, "_rfi_state"):
        def _rfi():
            _metti_testi(dlg, d.get("campi"))
            st = dlg._rfi_state()
            st.update(d.get("stato") or {})
            if dlg._find_layer("Ferrovia RFI") is not None:
                dlg._rfi_riempi_linee()
            interf = st.get("interferenze") or []
            if interf:
                dlg._rfi_riempi_tabella(interf, st.get("gestori") or {})
                if hasattr(dlg, "_rfi_riempi_km"):
                    dlg._rfi_riempi_km(interf, st.get("info_km") or {})
                dlg._rfi_riempi_destinatari(st.get("gestori") or {}, conserva=True)
            if dlg.cb_rfi_doit.count() == 0 and st.get("regione"):
                dlg._rfi_riempi_doit()
            fatte.append("Istanze RFI")
        _prova(log, "RFI", _rfi)
    d = schede.get("strade")
    if d and hasattr(dlg, "_sti"):
        def _sti():
            _metti_testi(dlg, d.get("campi"))
            dlg._sti.update(d.get("stato") or {})
            if dlg._sti.get("strade"):
                dlg._sti_riempi_strade()
            if dlg._sti.get("interferenze"):
                dlg._sti_riempi(dlg._sti["interferenze"])
            fatte.append("Istanze Strade")
        _prova(log, "Strade", _sti)
    d = schede.get("acque")
    if d and hasattr(dlg, "_acq_state"):
        def _acq():
            _metti_testi(dlg, d.get("campi"))
            st = dlg._acq_state()
            st.update(d.get("stato") or {})
            righe = (st.get("screening") or {}).get("righe")
            if righe:
                dlg._acq_riempi_screening(righe)
            if st.get("interferenze"):
                dlg._acq_riempi_tabella(st["interferenze"])
                dlg._acq_riempi_enti()
                if hasattr(dlg, "_acq_aggiorna_destinatari"):
                    dlg._acq_aggiorna_destinatari()
            fatte.append("Istanze Acque")
        _prova(log, "Acque", _acq)
    for s, nome in (("sopr", "Soprintendenza"), ("parchi", "Parchi")):
        d = schede.get(s)
        if d and s in (getattr(dlg, "_vin_st", None) or {}):
            def _vin(s=s, d=d, nome=nome):
                w_ = dlg._vin_w[s]
                for k, v in (d.get("campi") or {}).items():
                    if k in w_ and v:
                        w_[k].setText(v)
                dlg._vin_st[s].update(d.get("stato") or {})
                if dlg._vin_st[s].get("aree"):
                    dlg._vin_riempi_aree(s)
                if dlg._vin_st[s].get("interferenze"):
                    dlg._vin_riempi_tabella(s)
                    dlg._vin_riempi_dest(s)
                fatte.append(nome)
            _prova(log, nome, _vin)
    return fatte


def collega(dlg):
    """Salva lo stato quando si salva il progetto, lo rilegge quando si apre."""
    prj = getattr(dlg, "project", None)
    if prj is None or getattr(dlg, "_memoria_collegata", False):
        return
    dlg._memoria_collegata = True

    def _salva(*_a):
        try:
            scrivi(prj, raccogli(dlg))
        except Exception:  # noqa: BLE001
            pass

    def _carica(*_a):
        # la vista per istanza è fatta di copie temporanee: riaperto il
        # progetto non c'è più, e i layer principali vanno riaccesi
        try:
            try:
                from . import ftth_gruppi_istanze as GR
            except ImportError:
                import ftth_gruppi_istanze as GR
            ids = GR.registro(prj).get("_viste") or []
            if ids and not all(prj.mapLayer(i) is not None for i in ids):
                GR.togli_vista(prj)
        except Exception:  # noqa: BLE001
            pass
        dati = leggi(prj)
        if dati:
            fatte = ripristina(dlg, dati, getattr(dlg, "_log_rfi", None))
            if fatte and hasattr(dlg, "_log_rfi"):
                try:
                    dlg._log_rfi("Lavoro ripreso dal progetto: %s." % ", ".join(fatte))
                except Exception:  # noqa: BLE001
                    pass
    try:
        prj.writeProject.connect(_salva)
        prj.readProject.connect(_carica)
    except Exception:  # noqa: BLE001
        pass
    dlg._memoria_carica = _carica
    dlg._memoria_salva = _salva
    # dialogo aperto su un progetto già caricato: si riprende subito
    if prj.fileName():
        _carica()
