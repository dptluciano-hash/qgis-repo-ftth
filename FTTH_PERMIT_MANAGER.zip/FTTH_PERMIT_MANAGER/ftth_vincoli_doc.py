# -*- coding: utf-8 -*-
"""Documenti in piu' delle schede Soprintendenza e Parchi / Natura 2000,
scritti con python-docx e precompilati dal progetto:

- 1.4 Relazione paesaggistica semplificata (Allegato D, art. 8 c. 1 DPR 31/2017);
- 1.5 Dichiarazione di non parentela (L. 190/2012), se la Soprintendenza la chiede;
- 1.4 Autodichiarazione di esclusione dalla VIncA (vie con meno di 200 m di
  scavo, art. 40 c. 3-bis DL 77/2021 come modificato dal DL 19/2026);
- 1.4 Format di supporto allo screening VIncA - proponente (Linee guida
  nazionali VIncA 2019; le Regioni ne hanno versioni proprie).

Firmatari e dati del procuratore restano XXXXX, come in tutte le istanze.
"""
import datetime
import os

try:
    from . import ftth_vincoli as V
    from . import ftth_acque as A
except ImportError:
    import ftth_vincoli as V
    import ftth_acque as A

X = "XXXXX"
SI, NO = "☒", "☐"          # casella spuntata / vuota

NOMI_FILE_EXTRA = {
    "relazione_paes": "1.4_{base}_Relazione paesaggistica semplificata.docx",
    "non_parentela": "1.5_{base}_Dichiarazione di non parentela.docx",
    "esonero_vinca": "1.4_{base}_Autodichiarazione esclusione VIncA.docx",
    "format_vinca": "1.4_{base}_Format screening VIncA.docx",
}

CONTESTI = ["centro o nucleo storico", "area urbana", "area periurbana",
            "insediamento rurale (sparso e nucleo)", "area agricola", "area naturale",
            "area boscata", "ambito fluviale", "ambito lacustre"]
MORFOLOGIE = ["pianura", "versante", "crinale (collinare/montano)",
              "altopiano/promontorio", "costa (bassa/alta)"]
CONTESTI_VINCA = ["Centro urbano", "Zona periurbana", "Aree agricole", "Aree industriali",
                  "Aree naturali"]

TESTO_RICHIEDENTE = ("FiberCop S.p.A., con sede in Milano, Via Marco Aurelio 24, qui rappresentata "
                     "nella persona di %s, nato a %s (XX) il XX/XX/XXXX, nella sua qualità di "
                     "procuratore della società" % (X, X))


# --------------------------------------------------------------------------- #
#  Mattoni
# --------------------------------------------------------------------------- #
def _nuovo():
    from docx import Document
    from docx.shared import Pt, Cm
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Arial"
    st.font.size = Pt(10)
    for s in doc.sections:
        s.left_margin = s.right_margin = Cm(2.0)
        s.top_margin = s.bottom_margin = Cm(1.8)
    return doc


def _titolo(doc, testo, dim=12, centro=True):
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    p = doc.add_paragraph()
    r = p.add_run(testo)
    r.bold = True
    r.font.size = Pt(dim)
    if centro:
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    return p


def _sezione(doc, testo):
    from docx.shared import Pt
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10)
    r = p.add_run(testo)
    r.bold = True
    return p


def _par(doc, testo, giustificato=True, grassetto=False, corsivo=False):
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    p = doc.add_paragraph()
    r = p.add_run(testo)
    r.bold = grassetto
    r.italic = corsivo
    if giustificato:
        p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    return p


def _caselle(doc, voci, scelte, altro=None):
    """Una riga per voce con la casella spuntata se e' fra le scelte."""
    for v in voci:
        doc.add_paragraph("%s %s" % (SI if v in scelte else NO, v))
    if altro is not None:
        doc.add_paragraph("%s altro: %s" % (SI if altro else NO, altro or "..............."))


def _firme(doc, sinistra="Firma del richiedente", destra="Firma del progettista"):
    t = doc.add_table(rows=2, cols=2)
    t.cell(0, 0).text = sinistra
    t.cell(0, 1).text = destra
    t.cell(1, 0).text = "\n\n.........................................."
    t.cell(1, 1).text = "\n\n.........................................."


def _lavori(ist) -> dict:
    tot, pozz, armadi = {}, 0, 0
    for i in ist.interferenze:
        for t, m in i.metri.items():
            tot[t] = tot.get(t, 0) + m
        pozz += sum(i.pozzetti.values())
        armadi += sum(1 for e in i.elementi if e.get("tipo") == "armadio")
    return {"metri": tot, "pozzetti": pozz, "armadi": armadi}


def descr_lavori(ist) -> str:
    """'scavi in minitrincea (120 m) e in trincea tradizionale (35 m), posa di 3
    pozzetti e di 1 armadio ottico'."""
    lv = _lavori(ist)
    nomi = {"minitrincea": "minitrincea", "microtrincea": "microtrincea",
            "trincea": "trincea tradizionale", "nodig": "perforazione no-dig"}
    scavi = ["%s (%d m)" % (nomi.get(t, t), m) for t, m in lv["metri"].items() if m]
    parti = []
    if scavi:
        parti.append("scavi in " + A._elenco(scavi))
    if lv["pozzetti"]:
        parti.append("posa di %d pozzett%s" % (lv["pozzetti"],
                                               "o" if lv["pozzetti"] == 1 else "i"))
    if lv["armadi"]:
        parti.append("posa di %d armadi%s ottic%s" % (
            lv["armadi"], "o" if lv["armadi"] == 1 else "", "o" if lv["armadi"] == 1 else "i"))
    return A._elenco(parti) or "posa di infrastrutture in fibra ottica senza scavo"


def _vincoli_ist(ist) -> list:
    tipi = []
    for i in ist.interferenze:
        for t in getattr(i, "vincoli", []) or []:
            if t not in tipi:
                tipi.append(t)
    return tipi


# --------------------------------------------------------------------------- #
#  1.4 Relazione paesaggistica semplificata (Allegato D DPR 31/2017)
# --------------------------------------------------------------------------- #
def relazione_paesaggistica(ist, comune, out_path, contesti=None, morfologie=None,
                            piano="", pl_file="", oggi=None):
    """Allegato D precompilato: tipologia (punto B.10 / circolare MiBACT
    37/2017), vincoli art. 136/142 toccati dai lavori, descrizioni standard
    dalle pratiche presentate. contesti/morfologie: voci di CONTESTI/MORFOLOGIE."""
    doc = _nuovo()
    tipi = _vincoli_ist(ist)
    nome_c = comune.nome.upper()
    _titolo(doc, "RELAZIONE PAESAGGISTICA SEMPLIFICATA")
    _titolo(doc, "(Allegato D di cui all'art. 8, comma 1, del D.P.R. 13 febbraio 2017, n. 31)",
            9)
    _par(doc, "Comune di %s — %s" % (nome_c, ist.nome_base), giustificato=False, corsivo=True)

    _sezione(doc, "1. RICHIEDENTE")
    _par(doc, TESTO_RICHIEDENTE + ".")
    _caselle(doc, ["persona fisica", "società", "impresa", "ente"], ["società"])

    _sezione(doc, "2. TIPOLOGIA DELL'OPERA E/O DELL'INTERVENTO")
    _par(doc, "L'intervento è destinato all'installazione e allo sviluppo della rete di "
              "comunicazione elettronica a Banda Ultra Larga con tecnologia FTTH, per il "
              "collegamento dei punti di pubblico interesse e degli utenti nel Comune di %s, "
              "come richiamato dalla Circolare MiBACT n. 37/2017." % nome_c)
    _par(doc, "L'opera consiste in %s (punto B.10 dell'Allegato B del D.P.R. 31/2017; gli "
              "interventi interamente interrati rientrano nel punto A.15 dell'Allegato A)."
         % descr_lavori(ist))

    _sezione(doc, "3. CARATTERE DELL'INTERVENTO")
    _caselle(doc, ["temporaneo", "permanente"], ["permanente"])

    _sezione(doc, "4. DESTINAZIONE D'USO")
    _caselle(doc, ["residenziale", "ricettiva/turistica", "industriale/artigianale",
                   "agricolo", "commerciale/direzionale"], [], altro="telecomunicazioni")

    _sezione(doc, "5. CONTESTO PAESAGGISTICO DELL'INTERVENTO E/O DELL'OPERA")
    _caselle(doc, CONTESTI, contesti or ["area urbana"])

    _sezione(doc, "6. MORFOLOGIA DEL CONTESTO PAESAGGISTICO")
    _caselle(doc, MORFOLOGIE, morfologie or ["pianura"])

    _sezione(doc, "7. UBICAZIONE DELL'OPERA E/O DELL'INTERVENTO")
    _par(doc, "a) estratto cartografico (catasto, CTR, ortofoto) con l'area di intervento "
              "evidenziata: vedi %s." % (pl_file or "planimetria allegata"))
    _par(doc, "b) estratto degli strumenti della pianificazione urbanistica comunale: "
              "%s." % X)
    _par(doc, "c) estratto degli strumenti della pianificazione paesaggistica: vedi corografia "
              "con i vincoli nella planimetria allegata.")

    _sezione(doc, "8. DOCUMENTAZIONE FOTOGRAFICA")
    _par(doc, "Vedi tavole allegate: %s (foto e fotoinserimenti)." % (pl_file or "PL"))

    _sezione(doc, "9.a PRESENZA DI IMMOBILI ED AREE DI NOTEVOLE INTERESSE PUBBLICO "
                  "(art. 136, 141, 157 D.Lgs. 42/2004)")
    _caselle(doc, ["a) cose immobili", "b) ville, giardini, parchi",
                   "c) complessi di cose immobili", "d) bellezze panoramiche"],
             ["c) complessi di cose immobili"] if "art136" in tipi else [])
    _par(doc, "Estremi del provvedimento di tutela, denominazione e motivazione: %s"
         % ("da indicare (vincolo decretato art. 136)" if "art136" in tipi else "—"),
         corsivo=True)

    _sezione(doc, "9.b PRESENZA DI AREE TUTELATE PER LEGGE (art. 142 D.Lgs. 42/2004)")
    _caselle(doc, ["%s) %s" % (l, d) for l, d in V.LETTERE_142.items()],
             ["%s) %s" % (t[-1], V.LETTERE_142[t[-1]]) for t in tipi
              if t.startswith("art142") and t[-1] in V.LETTERE_142])

    _sezione(doc, "10. DESCRIZIONE SINTETICA DELLO STATO ATTUALE DELL'IMMOBILE O DELL'AREA "
                  "DI INTERVENTO")
    vinc = V.descr_vincoli(tipi)
    _par(doc, "Le aree di intervento si trovano nel territorio comunale di %s, lungo %s, "
              "in aree sottoposte a tutela%s. Si tratta di sedi stradali e marciapiedi "
              "esistenti." % (nome_c, A._elenco(ist.vie()) or "le vie indicate nelle tavole",
                               (" ai sensi dell'%s" % vinc) if vinc else ""))

    _sezione(doc, "11. DESCRIZIONE SINTETICA DELL'INTERVENTO E DELLE CARATTERISTICHE "
                  "DELL'OPERA")
    _par(doc, "Il progetto comprende la realizzazione di un'infrastruttura in fibra ottica: "
              "%s. Gli scavi sono ripristinati come da norme UNI/PdR 7:2014 e prescrizioni "
              "dell'ente proprietario della strada; gli armadi ottici hanno dimensioni massime "
              "98,8 x 25,2 x 158,5 cm, in acciaio inox verniciato RAL 7035." % descr_lavori(ist))

    _sezione(doc, "12. EFFETTI CONSEGUENTI ALLA REALIZZAZIONE DELL'OPERA")
    _par(doc, "Le installazioni previste non comportano modifiche degli elementi costitutivi "
              "del paesaggio né alterazioni percettive, come si evince dagli allegati grafici e "
              "dai fotoinserimenti di dettaglio. Gli scavi sono interrati e ripristinati allo "
              "stato originario.")

    _sezione(doc, "13. EVENTUALI MISURE DI INSERIMENTO PAESAGGISTICO")
    _par(doc, "Per la scelta del sito di posa degli armadi ottici si è tenuto conto del "
              "contesto specifico, cercando il più possibile di mantenere l'apparato allineato a "
              "condutture e tubazioni esistenti, allineato e/o centrale rispetto alle finestre "
              "sovrastanti, affiancato agli eventuali altri elementi tecnologici già presenti. "
              "Sono stati evitati posizionamenti nei pressi di edifici monumentali e in sezioni "
              "stradali la cui larghezza non garantisca la viabilità pedonale e/o carrabile.")

    _sezione(doc, "14. CONFORMITÀ CON I CONTENUTI DELLA DISCIPLINA PAESAGGISTICA VIGENTE")
    _par(doc, "L'intervento si attiene alla disciplina del %s (art. 143 del D.Lgs. 42/2004): "
              "le opere, di lieve entità, non contrastano con le prescrizioni e non alterano il "
              "contesto paesaggistico%s." % (
                  piano or "Piano Paesaggistico Regionale",
                  (", nel rispetto della disciplina dei beni tutelati ai sensi dell'%s" % vinc)
                  if vinc else ""))

    doc.add_paragraph()
    oggi = oggi or datetime.date.today()
    _par(doc, "%s, lì XX/XX/%d" % (X, oggi.year), giustificato=False)
    _firme(doc)
    doc.save(out_path)
    return out_path


# --------------------------------------------------------------------------- #
#  1.5 Dichiarazione di non parentela (L. 190/2012)
# --------------------------------------------------------------------------- #
def non_parentela(ist, comune, dest_nome, out_path, oggi=None):
    doc = _nuovo()
    _titolo(doc, "DICHIARAZIONE SOSTITUTIVA DI NON SUSSISTENZA DI VINCOLI DI PARENTELA")
    _titolo(doc, "(L. 6 novembre 2012, n. 190, art. 1, comma 5, lett. a) e comma 9, lett. e))",
            9)
    _par(doc, "Oggetto: istanza di autorizzazione ai sensi dell'art. 49 del D.Lgs. 259/2003 "
              "(Codice delle comunicazioni elettroniche) per scavi e opere civili finalizzati "
              "allo sviluppo della rete in fibra ottica nel Comune di %s." % comune.nome.upper(),
         grassetto=True)
    _par(doc, TESTO_RICHIEDENTE + ", con sede in Milano, Via Marco Aurelio 24,")
    _par(doc, "consapevole delle sanzioni penali in caso di dichiarazioni false e della "
              "conseguente decadenza dai benefici eventualmente conseguiti (artt. 75 e 76 "
              "D.P.R. 445/2000), sotto la propria responsabilità")
    _titolo(doc, "DICHIARA", 11)
    _par(doc, "l'inesistenza di rapporti di coniugio, parentela o affinità, entro il secondo "
              "grado, con i dirigenti e i dipendenti %s deputati alla trattazione del "
              "procedimento, ai sensi del combinato disposto dell'art. 1, comma 5, lettera a), e "
              "comma 9, lettera e), della Legge 6 novembre 2012, n. 190."
         % (A.articolo_di(dest_nome) if dest_nome else "della Soprintendenza"))
    doc.add_paragraph()
    oggi = oggi or datetime.date.today()
    _par(doc, "%s, lì XX/XX/%d" % (X, oggi.year), giustificato=False)
    _par(doc, "Il dichiarante\n\n..........................................", giustificato=False)
    doc.save(out_path)
    return out_path


# --------------------------------------------------------------------------- #
#  1.4 Autodichiarazione di esclusione dalla VIncA (< 200 m per via)
# --------------------------------------------------------------------------- #
def autodichiarazione_esonero(ist, comune, dest, sito, esiti, out_path, pl_file="",
                              rt_file="", oggi=None):
    """Comunicazione di inizio lavori con autodichiarazione di esclusione
    dalla Valutazione di Incidenza per le vie con meno di 200 m di scavo.
    esiti = {via: (metri, esito)} (solo le vie di questa istanza)."""
    dest = dest or {}
    doc = _nuovo()
    _par(doc, "Spett.le\n%s\n%s\nPEC: %s" % (dest.get("nome") or ist.ente_nome or
                                             "Autorità competente per la Valutazione di "
                                             "Incidenza", dest.get("indirizzo") or X,
                                             dest.get("pec") or X), giustificato=False)
    _par(doc, "e p.c. Spett.le Comune di %s" % comune.nome, giustificato=False)
    doc.add_paragraph()
    _par(doc, "Oggetto: comunicazione di inizio lavori e autodichiarazione di esclusione dalla "
              "procedura di Valutazione di Incidenza (art. 5 D.P.R. 357/1997) ai sensi dell'%s, "
              "per scavi di lunghezza inferiore a %d metri per la posa di infrastrutture a banda "
              "ultralarga nel Comune di %s, in relazione al sito della Rete Natura 2000 %s."
         % (V.NORMA_ESONERO, V.SOGLIA_VINCA_M, comune.nome.upper(), sito), grassetto=True)
    _par(doc, TESTO_RICHIEDENTE + ",")
    _par(doc, "visto l'%s, secondo cui, per gli interventi relativi ai lavori di scavo di "
              "lunghezza inferiore a 200 metri per la posa di infrastruttura a banda ultralarga, "
              "non è richiesta la procedura di valutazione d'incidenza di cui all'art. 5 del "
              "D.P.R. 8 settembre 1997, n. 357, e l'operatore di rete si limita a comunicare, con "
              "un preavviso di almeno trenta giorni, l'inizio dei lavori all'autorità competente, "
              "allegando un'autodichiarazione per l'esclusione dalla procedura e una descrizione "
              "sintetica dell'intervento con documentazione fotografica;" % V.NORMA_ESONERO)
    _par(doc, "consapevole delle sanzioni penali in caso di dichiarazioni false (artt. 75 e 76 "
              "D.P.R. 445/2000),")
    _titolo(doc, "COMUNICA E DICHIARA", 11)
    _par(doc, "• che i lavori avranno inizio non prima di trenta giorni dalla data di "
              "ricezione della presente, presumibilmente il XX/XX/%d;" % (
                  (oggi or datetime.date.today()).year))
    _par(doc, "• che ciascun intervento comporta scavi di lunghezza inferiore a %d metri, "
              "come riepilogato di seguito, e rientra pertanto nell'esclusione dalla procedura "
              "di Valutazione di Incidenza;" % V.SOGLIA_VINCA_M)
    t = doc.add_table(rows=1, cols=3)
    t.style = "Table Grid"
    for c, h in enumerate(("Via / tratto", "Scavo (m)", "Lavori")):
        t.cell(0, c).text = h
    for via, (m, _e) in sorted(esiti.items()):
        lav = [i for i in ist.interferenze if V.chiave_via(i) == via]
        r = t.add_row().cells
        r[0].text = via
        r[1].text = str(m)
        r[2].text = "; ".join(V.motivo_regime(i) for i in lav)
    _par(doc, "• che gli scavi saranno eseguiti nella sede stradale esistente e ripristinati "
              "allo stato originario, senza interessare habitat naturali, vegetazione o aree "
              "esterne alla viabilità.")
    _sezione(doc, "Descrizione sintetica dell'intervento")
    _par(doc, "Posa di infrastruttura in fibra ottica per la rete a banda ultralarga (FTTH): "
              "%s. I dettagli sono nella relazione tecnica %s e nella planimetria %s, "
              "con la documentazione fotografica." % (descr_lavori(ist), rt_file or "allegata",
                                                      pl_file or "allegata"))
    _sezione(doc, "Allegati")
    for a in ("Planimetria con ortofoto e documentazione fotografica (%s)" % (pl_file or "PL"),
              "Relazione tecnica (%s)" % (rt_file or "RT"),
              "Procura e documento d'identità del dichiarante"):
        doc.add_paragraph("- " + a)
    doc.add_paragraph()
    _par(doc, "%s, lì XX/XX/%d" % (X, (oggi or datetime.date.today()).year),
         giustificato=False)
    _par(doc, "FiberCop S.p.A.\nIl procuratore %s\n\n.........................................."
         % X, giustificato=False)
    doc.save(out_path)
    return out_path


# --------------------------------------------------------------------------- #
#  1.4 Format di supporto screening VIncA - proponente
# --------------------------------------------------------------------------- #
def format_vinca(ist, comune, regione, provincia, sito_codice, sito_nome, sito_tipo,
                 distanza_m, aree_protette, contesto, esiti, out_path, pl_file="",
                 rt_file="", oggi=None):
    """Format proponente (Linee guida nazionali VIncA 2019) precompilato. distanza_m None = dentro il sito; aree_protette = [voce]."""
    doc = _nuovo()
    _titolo(doc, "FORMAT DI SUPPORTO SCREENING DI V.INC.A. — PROPONENTE")
    _titolo(doc, "Piani / Programmi / Progetti / Interventi / Attività", 9)
    vie = A._elenco(sorted(esiti)) or A._elenco(ist.vie())
    _par(doc, "Oggetto P/P/P/I/A: scavi e posa di infrastrutture per la rete in fibra ottica "
              "(FTTH) in %s, Comune di %s." % (vie or "vie indicate nelle tavole",
                                               comune.nome.upper()), grassetto=True)
    _caselle(doc, ["Piano/Programma", "Progetto/intervento", "Attività"],
             ["Progetto/intervento"])
    _par(doc, "Il progetto/intervento ricade nelle tipologie degli Allegati II, II-bis, III e IV "
              "alla Parte Seconda del D.Lgs. 152/2006: %s Sì (infrastruttura per dati e "
              "telefonia)   %s No" % (SI, NO), giustificato=False)
    _par(doc, "Finanziato con risorse pubbliche: %s Sì   %s No (finanziamento privato)" % (NO, SI),
         giustificato=False)
    _par(doc, "Opera pubblica: %s Sì   %s No (servizi di accesso a banda ultra larga)" % (NO, SI),
         giustificato=False)
    _par(doc, "Proposta pre-valutata (tipologia): %s Realizzazione di reti per comunicazioni "
              "elettroniche ad alta velocità in fibra ottica — da verificare negli atti di "
              "pre-valutazione della Regione %s." % (SI, regione or X), giustificato=False)
    _par(doc, "Proponente: FiberCop S.p.A., Via Marco Aurelio 24, 20127 Milano — procuratore %s"
         % X, giustificato=False)

    _sezione(doc, "SEZIONE 1 - LOCALIZZAZIONE ED INQUADRAMENTO TERRITORIALE")
    _par(doc, "Regione: %s    Comune: %s    Provincia: %s" % (
        (regione or X).upper(), comune.nome.upper(), (provincia or comune.prov_sigla or X)
        .upper()), giustificato=False)
    _par(doc, "Indirizzo: %s" % (vie or X), giustificato=False)
    _par(doc, "Contesto localizzativo:", giustificato=False)
    _caselle(doc, CONTESTI_VINCA, [contesto] if contesto else [])
    _par(doc, "Particelle catastali: vedi stralcio catastale nelle tavole (%s)." % (
        pl_file or "PL"), giustificato=False)
    _par(doc, "Coordinate geografiche (WGS84): vedi tabelle della relazione tecnica (%s)."
         % (rt_file or "RT"), giustificato=False)

    _sezione(doc, "SEZIONE 2 - LOCALIZZAZIONE IN RELAZIONE AI SITI NATURA 2000")
    t = doc.add_table(rows=2, cols=3)
    t.style = "Table Grid"
    for c, h in enumerate(("Tipo", "Codice", "Denominazione")):
        t.cell(0, c).text = h
    t.cell(1, 0).text = sito_tipo or "SIC/ZSC/ZPS"
    t.cell(1, 1).text = sito_codice or "IT_______"
    t.cell(1, 2).text = sito_nome or X
    _par(doc, "È stata presa visione degli Obiettivi e delle Misure di Conservazione e/o del "
              "Piano di Gestione del sito: %s Sì   %s No — atto consultato: %s" % (NO, NO, X),
         giustificato=False)
    _par(doc, "2.1 - Il P/P/P/I/A interessa aree naturali protette nazionali o regionali?  "
              "%s Sì   %s No%s" % (SI if aree_protette else NO, NO if aree_protette else SI,
                                   (" — " + "; ".join(aree_protette)) if aree_protette else ""),
         giustificato=False)
    if distanza_m:
        _par(doc, "2.2 - P/P/P/I/A esterno al sito: sito cod. %s, distanza dal sito circa %d m."
             % (sito_codice or "IT_______", int(distanza_m)), giustificato=False)
    else:
        _par(doc, "2.2 - Il P/P/P/I/A ricade all'interno del sito %s." % (sito_codice or ""),
             giustificato=False)

    _sezione(doc, "SEZIONE 3 - VERIFICA DI CORRISPONDENZA DI PROPOSTE PRE-VALUTATE")
    _par(doc, "Si richiede la Verifica di Corrispondenza per P/P/P/I/A pre-valutati?  "
              "%s Sì   %s No — da scegliere secondo gli atti della Regione %s." % (
                  NO, NO, regione or X), giustificato=False)

    _sezione(doc, "SEZIONE 4 - DESCRIZIONE DEL P/P/P/I/A")
    _par(doc, "Ai fini dello sviluppo della Banda Ultra Larga e a vantaggio degli utilizzatori "
              "della rete del Comune di %s, si rende necessario realizzare %s, lungo la "
              "viabilità esistente (%s). Gli scavi saranno riempiti e ripristinati adottando gli "
              "accorgimenti necessari a evitare cedimenti del corpo stradale, secondo le norme "
              "UNI/PdR 7:2014 e le prescrizioni dell'ente proprietario della strada."
         % (comune.nome.upper(), descr_lavori(ist), vie or "vie indicate nelle tavole"))
    t = doc.add_table(rows=1, cols=2)
    t.style = "Table Grid"
    t.cell(0, 0).text = "Via / tratto"
    t.cell(0, 1).text = "Scavo (m)"
    for via, (m, _e) in sorted(esiti.items()):
        r = t.add_row().cells
        r[0].text = via
        r[1].text = str(m)
    _par(doc, "4.1 - Documentazione allegata:", giustificato=False)
    _caselle(doc, ["Planimetria di progetto e delle eventuali aree di cantiere",
                   "Ortofoto con localizzazione delle aree di intervento",
                   "Documentazione fotografica ante operam",
                   "Relazione tecnica"],
             ["Planimetria di progetto e delle eventuali aree di cantiere",
              "Ortofoto con localizzazione delle aree di intervento",
              "Documentazione fotografica ante operam", "Relazione tecnica"])

    _sezione(doc, "SEZIONE 5 - DECODIFICA DEL P/P/P/I/A")
    for dom, si in (("È prevista trasformazione di uso del suolo?", False),
                    ("Sono previsti movimenti terra/sbancamenti/scavi?", True),
                    ("Verranno livellate superfici naturali o effettuati spietramenti?", False),
                    ("Sono previste aree di cantiere e/o di stoccaggio materiali?", True),
                    ("È necessaria l'apertura o la sistemazione di piste di accesso?", False),
                    ("È previsto il taglio o l'eliminazione di vegetazione?", False)):
        _par(doc, "%s  %s Sì   %s No" % (dom, SI if si else NO, NO if si else SI),
             giustificato=False)
    _par(doc, "Scavi: scavo e posa di infrastrutture con copertura immediata e ripristino della "
              "pavimentazione stradale. Cantiere: area di cantiere mobile lungo la strada con "
              "occupazione temporanea.", corsivo=True)
    doc.add_paragraph()
    _par(doc, "%s, lì XX/XX/%d" % (X, (oggi or datetime.date.today()).year),
         giustificato=False)
    _par(doc, "Il proponente\n\n..........................................", giustificato=False)
    _par(doc, "Nota: se la Regione ha un proprio modello di Format (es. Friuli Venezia Giulia, "
              "Allegato 2), riportare questi dati su quel modello.", corsivo=True)
    doc.save(out_path)
    return out_path


def nome_file(chiave, base):
    return NOMI_FILE_EXTRA[chiave].format(base=base)


def cartella_ok(path):
    os.makedirs(path, exist_ok=True)
    return path
