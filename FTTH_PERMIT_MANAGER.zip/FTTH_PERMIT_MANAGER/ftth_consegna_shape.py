"""Cartella di consegna degli shape (istanza comunale).

Esporta in shapefile (ESRI Shapefile, UTF-8, stesso sistema di riferimento del
layer) tutti i layer del gruppo «Ottico» del progetto (cavo ottico, ROE/PTE,
raccordi, muffole, aree Arlo...) e i layer della rete del permesso
03 INFRASTRUTTURE, 02_POZZETTO, 01_ARMADIO OTTICO, anche se sono GeoPackage.
I layer del progetto non si toccano.
"""
import datetime
import os
import re
import zipfile

GRUPPO_OTTICO = "ottico"
# senza gruppo «Ottico»: layer riconosciuti dal nome
NOMI_OTTICO = ("cavo ottico", "roe", "pte", "raccord", "muffola", "arlo")
RETE = (("03 INFRASTRUTTURE", "INFRASTRUTTURE"), ("02_POZZETTO", "POZZETTO"),
        ("01_ARMADIO OTTICO", "ARMADIO OTTICO"))
ESTENSIONI_SHP = (".shp", ".shx", ".dbf", ".prj", ".cpg")


def nome_file(nome_layer: str) -> str:
    """«03 INFRASTRUTTURE» -> «INFRASTRUTTURE»; caratteri non validi tolti."""
    n = re.sub(r"^\s*\d+\s*[_ .-]\s*", "", nome_layer or "").strip() or nome_layer or "layer"
    n = re.sub(r'[<>:"/\\|?*]+', "_", n).strip(" .")
    return n or "layer"


def nome_cartella(base: str, oggi=None) -> str:
    oggi = oggi or datetime.date.today()
    return "%s_Consegna_shape_%s" % (base, oggi.strftime("%Y%m%d")) if base else \
        "Consegna_shape_%s" % oggi.strftime("%Y%m%d")


def _gruppi(nodo):
    from qgis.core import QgsLayerTreeGroup
    for c in nodo.children():
        if isinstance(c, QgsLayerTreeGroup):
            yield c
            yield from _gruppi(c)


def layer_da_consegnare(project) -> list:
    """[(layer, nome file senza estensione)] nell'ordine: ottico, poi rete."""
    from qgis.core import QgsVectorLayer
    try:
        from . import ftth_gruppi_istanze as GR
    except ImportError:
        import ftth_gruppi_istanze as GR
    nostri = GR._id_gruppi(project)
    out, visti = [], set()

    def add(l, nome):
        if l is None or not isinstance(l, QgsVectorLayer) or not l.isValid() \
                or l.id() in visti or l.id() in nostri:
            return
        visti.add(l.id())
        out.append((l, nome))

    g = next((x for x in _gruppi(project.layerTreeRoot())
              if x.name().strip().lower() == GRUPPO_OTTICO), None)
    if g is not None:
        for nodo in g.findLayers():
            add(nodo.layer(), nome_file(nodo.layer().name() if nodo.layer() else ""))
    else:
        for l in project.mapLayers().values():
            n = l.name().lower()
            if any(k in n for k in NOMI_OTTICO) and "armadio" not in n:
                add(l, nome_file(l.name()))
    for nome, file in RETE:
        add(GR.layer_principale(project, nome), file)
    return nomi_unici(out)


def nomi_unici(coppie: list) -> list:
    """[(layer, nome file)] con i nomi file resi unici (_2, _3 ...)."""
    usati = {}
    finale = []
    for l, n in coppie:
        k = n.lower()
        usati[k] = usati.get(k, 0) + 1
        finale.append((l, n if usati[k] == 1 else "%s_%d" % (n, usati[k])))
    return finale


def layer_vettoriali(project) -> list:
    """Layer vettoriali validi del progetto, nell'ordine della legenda."""
    from qgis.core import QgsVectorLayer
    out = []
    for nodo in project.layerTreeRoot().findLayers():
        l = nodo.layer()
        if isinstance(l, QgsVectorLayer) and l.isValid() and l not in out:
            out.append(l)
    return out


def voci_istanze(project) -> list:
    """[(etichetta, sezione, istanza, {chiave: {fid}})] delle istanze
    confermate (campi IST_* negli shape principali), più la rete comunale
    (rete senza istanze) per prima."""
    from . import ftth_vista_istanze as VI
    dati = VI.dati_progetto(project)
    titoli = dict(VI.TITOLI)
    out = [("Istanza comunale (rete senza istanze)", "", "Istanza comunale", dati.get("") or {})]
    for sez, _t in VI.TITOLI:
        for ist in sorted(dati.get(sez) or {}):
            out.append(("%s — %s" % (titoli[sez], ist), sez, ist, dati[sez][ist]))
    return out


def layer_istanza(project, istanza: str, fids: dict, comunale: bool = False) -> list:
    """[(layer in memoria, nome file)] di un'istanza: tratte, pozzetti e
    armadi che le appartengono (copie filtrate) e i suoi layer di rilievo
    «Punto di Ripresa Fotografico - <istanza>», «Sezioni - <istanza>»."""
    from qgis.core import QgsFeatureRequest
    from . import ftth_gruppi_istanze as GR
    out = []
    for chiave, nome, _t in GR.LAYER:
        sel = sorted(fids.get(chiave) or ())
        l = GR.layer_principale(project, nome)
        if l is None or not sel:
            continue
        copia = l.materialize(QgsFeatureRequest().setFilterFids(sel))
        copia.setName(l.name())
        out.append((copia, nome_file(l.name())))
    from . import ftth_rfi_layout as L
    for nomi, base in ((L.NOMI_LAYER_FOTO, "Punto di Ripresa Fotografico"),
                       (L.NOMI_LAYER_SEZIONI, "Sezioni")):
        # comunale: i layer comuni; altre istanze: «<layer> - <istanza>»
        cerca = list(nomi) if comunale else ["%s - %s" % (base, istanza)]
        l = next((x for n in cerca for x in project.mapLayersByName(n)), None)
        if l is not None and l.featureCount():
            out.append((l, base))
    return nomi_unici(out)


def esporta(project, cartella: str, layers: list, zip_finale: bool = True,
            log=None) -> dict:
    """Scrive gli shapefile in `cartella`. Ritorna {'ok': [(file, n)],
    'ko': [(nome, errore)], 'zip': percorso o None}."""
    from qgis.core import QgsVectorFileWriter
    log = log or (lambda _m: None)
    os.makedirs(cartella, exist_ok=True)
    ok, ko = [], []
    for l, nome in layers:
        path = os.path.join(cartella, nome + ".shp")
        opt = QgsVectorFileWriter.SaveVectorOptions()
        opt.driverName = "ESRI Shapefile"
        opt.fileEncoding = "UTF-8"
        opt.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
        try:
            ris = QgsVectorFileWriter.writeAsVectorFormatV3(
                l, path, project.transformContext(), opt)
        except Exception as e:  # noqa: BLE001
            ris = (1, str(e))
        if ris[0] != QgsVectorFileWriter.NoError:
            ko.append((l.name(), ris[1] or "errore di scrittura"))
            log("  %s: NON esportato (%s)" % (l.name(), ris[1]))
            continue
        lunghi = [f.name() for f in l.fields() if len(f.name()) > 10]
        ok.append((os.path.basename(path), l.featureCount()))
        log("  %s.shp: %d elementi%s" % (
            nome, l.featureCount(),
            (" — campi con nome oltre 10 caratteri accorciati dallo shapefile: %s"
             % ", ".join(lunghi)) if lunghi else ""))
    zp = None
    if zip_finale and ok:
        zp = cartella.rstrip("\\/") + ".zip"
        with zipfile.ZipFile(zp, "w", zipfile.ZIP_DEFLATED) as z:
            for f in sorted(os.listdir(cartella)):
                if os.path.splitext(f)[1].lower() in ESTENSIONI_SHP:
                    z.write(os.path.join(cartella, f), f)
        log("  ZIP: %s" % zp)
    return {"ok": ok, "ko": ko, "zip": zp}
