# -*- coding: utf-8 -*-
"""Logica della sottoscheda «Genera istanze» di Istanze Strade.

Come nelle pratiche consegnate (ANAS SS71, Provincia SP306): una istanza per
strada e destinatario, con
- TABELLA NUOVI SCAVI per progressiva chilometrica (minitrincea, tradizionale,
  no-dig; «*» = attraversamento), scavi in sede stradale;
- scavi in FASCIA DI RISPETTO (fuori dalla sede, entro la fascia del DPR
  495/1992);
- pozzetti e armadi per progressiva;
- cronoprogramma; PL con tavole e etichette «KM ... SCAVO ...».

Il motore delle interferenze e' quello delle Acque (zone = sede e fascia
della strada); le progressive vengono dal campo «Chilometrica» calcolato nella
sottoscheda Chilometriche (cippi). Senza progressiva si usano le coordinate.
Niente QGIS qui: geometrie shapely WGS84.
"""
import re
from dataclasses import dataclass, field

try:
    from . import ftth_acque as A
    from . import ftth_rfi as rfi
except ImportError:  # test fuori dal pacchetto
    import ftth_acque as A
    import ftth_rfi as rfi

CLASSI = {"A": "autostrada", "SS": "strada statale", "SR": "strada regionale",
          "SP": "strada provinciale", "RA": "raccordo autostradale",
          "NSA": "strada ANAS (NSA)"}
# meta' larghezza della sede (carreggiata + banchina) dall'asse OSM, in metri:
# serve a distinguere i lavori IN SEDE da quelli in fascia di rispetto
SEMI_SEDE_M = {"A": 15.0, "RA": 12.0, "SS": 7.5, "NSA": 7.5, "SR": 7.0, "SP": 6.0}
# fascia di rispetto fuori dai centri abitati (DPR 495/1992 art. 26), come
# nella base dati dello screening; si corregge strada per strada
FASCIA_M = {"A": 60.0, "RA": 40.0, "SS": 40.0, "NSA": 30.0, "SR": 30.0, "SP": 30.0}

ZONA_SEDE = "sede"
ZONA_FASCIA = "fascia"
ETICHETTA_TECNICA = {"minitrincea": "Minitrincea", "microtrincea": "Microtrincea",
                     "trincea": "Tradizionale", "nodig": "No-Dig", "canaletta": "Canaletta VTR"}


@dataclass
class Strada:
    ref: str                        # SP306, SS71
    classe: str                     # A, SS, SR, SP...
    nome: str = ""                  # nome OSM (es. Via Castiglionese)
    geom: object = None             # shapely (Multi)LineString WGS84
    ente_nome: str = ""             # destinatario dell'istanza
    ente_ufficio: str = ""
    ente_indirizzo: str = ""
    ente_pec: str = ""
    epc_comune: bool = True         # «e p.c.» al Comune
    fascia_m: float = 30.0
    semi_sede_m: float = 7.0
    includi: bool = True
    nota: str = ""                  # competenza (centro abitato, ANAS, gestore)

    def sigla(self) -> str:
        """'SP306' -> 'SP306'; per i documenti 'SP 306'."""
        return self.ref

    def nome_documenti(self) -> str:
        m = re.match(r"^([A-Z]+)\s*(\d.*)$", self.ref)
        return "%s %s" % (m.group(1), m.group(2)) if m else self.ref


def strade_da_osm(elements: list, normalizza_ref) -> list:
    """Way OSM con ref -> [Strada] (una per ref, geometrie unite).
    normalizza_ref = ftth_screening.normalizza_ref ('SP006' -> ('SP','SP6'))."""
    from shapely.geometry import LineString
    from shapely.ops import linemerge, unary_union
    per_ref = {}
    for e in elements or []:
        if e.get("type") != "way" or not e.get("geometry"):
            continue
        t = e.get("tags") or {}
        parsed = normalizza_ref(t.get("ref", ""))
        if not parsed:
            continue
        classe, ref = parsed
        if classe not in CLASSI:
            continue
        pts = [(p["lon"], p["lat"]) for p in e["geometry"]]
        if len(pts) < 2:
            continue
        d = per_ref.setdefault(ref, {"classe": classe, "linee": [], "nomi": [],
                                     "operator": []})
        d["linee"].append(LineString(pts))
        if t.get("name") and t["name"] not in d["nomi"]:
            d["nomi"].append(t["name"])
        if t.get("operator") and t["operator"] not in d["operator"]:
            d["operator"].append(t["operator"])
    out = []
    for ref, d in per_ref.items():
        u = unary_union(d["linee"])
        try:
            u = linemerge(u)
        except Exception:  # noqa: BLE001
            pass
        s = Strada(ref=ref, classe=d["classe"], nome=", ".join(d["nomi"][:2]), geom=u,
                   fascia_m=FASCIA_M.get(d["classe"], 30.0),
                   semi_sede_m=SEMI_SEDE_M.get(d["classe"], 7.0))
        s.operator = ", ".join(d["operator"])
        out.append(s)
    out.sort(key=lambda s: (list(CLASSI).index(s.classe), _num(s.ref)))
    return out


def _num(ref):
    m = re.search(r"\d+", ref or "")
    return int(m.group(0)) if m else 0


def metri_vicino(strada, tratte_wgs: list, dist_m: float) -> float:
    """Metri di rete entro dist_m dall'asse (per proporre le strade toccate)."""
    if strada.geom is None or not tratte_wgs:
        return 0.0
    c = strada.geom.centroid
    pr = rfi._Proiezione(c.x, c.y)
    zona = pr.avanti(strada.geom).buffer(dist_m)
    tot = 0.0
    for g in tratte_wgs:
        if g is None or g.is_empty:
            continue
        gm = pr.avanti(g)
        if gm.intersects(zona):
            tot += gm.intersection(zona).length
    return round(tot, 0)


def zone_strada(strada) -> list:
    """Due `zone` per il motore delle Acque: la SEDE (asse +- semi_sede) e la
    FASCIA di rispetto (oltre la sede, fino a semi_sede + fascia)."""
    c = strada.geom.centroid
    pr = rfi._Proiezione(c.x, c.y)
    asse = pr.avanti(strada.geom)
    # la strada di OSM arriva a pezzi (una «way» per tratto): con le estremità
    # tagliate dritte (cap piatto) fra un pezzo e l'altro, nelle curve e alle
    # rotatorie restavano buchi nella sede e nella fascia, e scavi a pochi
    # metri dall'asse non risultavano interferenze (SS1 ad Arenzano). Pezzi
    # uniti ed estremità arrotondate: conta la distanza vera dall'asse.
    try:
        from shapely.ops import linemerge
        if asse.geom_type == "MultiLineString":
            asse = linemerge(asse)
    except Exception:  # noqa: BLE001
        pass
    sede = asse.buffer(strada.semi_sede_m, cap_style=1)
    fascia = asse.buffer(strada.semi_sede_m + strada.fascia_m, cap_style=1).difference(sede)
    comuni = {"ente_tipo": strada.classe, "ente_nome": strada.ente_nome,
              "nome": strada.ref}

    def _valido(g):
        g = pr.indietro(g)
        return g if g.is_valid else g.buffer(0)
    return [dict(comuni, categoria=ZONA_SEDE, geom=_valido(sede)),
            dict(comuni, categoria=ZONA_FASCIA, geom=_valido(fascia))]


# --------------------------------------------------------------------------- #
#  Progressive chilometriche AUTOMATICHE
# --------------------------------------------------------------------------- #
# Il km di un punto e' la sua proiezione sull'ASSE della strada, tarata sui
# cippi: non si percorre la tratta (le tratte storte o a zig-zag sbagliavano
# il conto), si proietta solo l'inizio e la fine di ogni scavo e ogni pozzetto.

def km_in_metri(valore):
    """'11+571' -> 11571; '11.571' / '11,571' (km) -> 11571; '11571' (m) ->
    11571; numero < 1000 senza separatori = km. None se non leggibile."""
    if valore is None:
        return None
    s = str(valore).strip().lower().replace("km", "").strip()
    if not s or s == "null":
        return None
    m = _RE_KM.search(s)
    if m:
        return int(m.group(1)) * 1000 + int(m.group(2))
    try:
        v = float(s.replace(",", "."))
    except ValueError:
        return None
    if "," in s or "." in s or v < 1000:
        return int(round(v * 1000))
    return int(round(v))


def metri_in_km(m) -> str:
    m = int(round(m))
    return "%d+%03d" % (m // 1000, m % 1000) if m >= 0 else ""


class Progressive:
    """Taratura dell'asse di una strada con i cippi (o altri riferimenti noti).
    riferimenti = [(Point WGS84, metri)]. Fra due riferimenti si interpola,
    fuori si estrapola con la pendenza dei due piu' vicini (+-1 m/m)."""

    def __init__(self, asse_wgs, riferimenti, tolleranza_m=60.0):
        from shapely.ops import linemerge, unary_union
        c = asse_wgs.centroid
        self.pr = rfi._Proiezione(c.x, c.y)
        g = self.pr.avanti(asse_wgs)
        try:
            g = linemerge(unary_union(g))
        except Exception:  # noqa: BLE001
            pass
        parti = list(getattr(g, "geoms", [g]))
        self.parti = [p for p in parti if p.length > 0]
        self.rif = []           # (parte, distanza lungo la parte, metri)
        self.scartati = 0
        for p, km in riferimenti:
            pm = self.pr.avanti(p)
            parte = min(self.parti, key=lambda q: q.distance(pm)) if self.parti else None
            if parte is None or parte.distance(pm) > tolleranza_m or km is None:
                self.scartati += 1
                continue
            self.rif.append((parte, parte.project(pm), km))

    def ok(self) -> bool:
        """Servono almeno due riferimenti sulla stessa parte dell'asse (il
        secondo da' il verso dei km)."""
        return any(sum(1 for q, _d, _k in self.rif if q is p) >= 2 for p in self.parti)

    def km(self, punto_wgs):
        """Metri progressivi del punto, o None se non tarabile."""
        if not self.rif:
            return None
        pm = self.pr.avanti(punto_wgs)
        parte = min(self.parti, key=lambda q: q.distance(pm))
        rif = sorted([(d, k) for q, d, k in self.rif if q is parte])
        if not rif:
            return None
        d = parte.project(pm)
        if len(rif) == 1:
            return None
        # pendenza: verso dei km rispetto al disegno della linea
        for (d0, k0), (d1, k1) in zip(rif[:-1], rif[1:]):
            if d0 <= d <= d1 and d1 > d0:
                return k0 + (k1 - k0) * (d - d0) / (d1 - d0)
        (d0, k0), (d1, k1) = (rif[0], rif[1]) if d < rif[0][0] else (rif[-2], rif[-1])
        segno = 1.0 if (k1 - k0) * (d1 - d0) >= 0 else -1.0
        return k0 + segno * (d - d0) if d < rif[0][0] else k1 + segno * (d - d1)


def riferimenti_anas(info_anas: dict, vicino=None, passo_m: float = 250.0,
                     raggio_m: float = 3000.0) -> list:
    """Riferimenti chilometrici dalla geometria ANAS della strada: ogni tratta
    ANAS (dal/al km) e' abbinata alla linea di lunghezza piu' vicina e i km
    sono distribuiti in proporzione lungo la linea (la differenza fra linea
    e km dichiarati, es. 0,3% sulla SS71, si spalma su tutta la tratta).
    La linea ANAS e' disegnata nel verso dei km crescenti.
    vicino = geometria WGS84 attorno a cui servono i riferimenti (entro
    raggio_m), per non generarne migliaia. Ritorna [(Point WGS84, metri)]."""
    from shapely.geometry import LineString
    geo = info_anas.get("geo") or []
    tratte = [t for t in info_anas.get("tratte_m") or [] if None not in t]
    if not geo or not tratte:
        return []
    out = []
    for dal, al in tratte:
        atteso = abs(al - dal)
        migliore = None
        for pts in geo:
            ln = LineString(pts)
            c = ln.centroid
            pr = rfi._Proiezione(c.x, c.y)
            lm = pr.avanti(ln)
            scarto = abs(lm.length - atteso) / max(atteso, 1.0)
            if migliore is None or scarto < migliore[0]:
                migliore = (scarto, lm, pr)
        if migliore is None or migliore[0] > 0.03:
            continue
        _sc, lm, pr = migliore
        zona = pr.avanti(vicino).buffer(raggio_m) if vicino is not None else None
        d = 0.0
        while d <= lm.length:
            p = lm.interpolate(d)
            if zona is None or zona.contains(p):
                out.append((pr.indietro(p), dal + (al - dal) * d / lm.length))
            d += passo_m
    return out


def dividi_scavi_per_tratta(interferenze: list, tratte: list, zone: list) -> None:
    """Strade: uno scavo per TRATTA del progetto, come nelle relazioni
    consegnate («dal km 101+938 al km 102+045 = 109», «dal km 102+045 al km
    102+092 = 47»), invece dello scavo continuo per tecnica delle Acque che
    univa tratte consecutive."""
    per_fid = {t.get("fid"): t for t in tratte}
    zg = {z["categoria"]: z["geom"] for z in zone}
    for i in interferenze:
        zona = zg.get(i.categoria)
        nuovi = []
        for e in i.elementi:
            fids = [f for f in (e.get("chiave_el") or "").split("|")[-1].split(",") if f] \
                if e.get("tipo") == "scavo" else []
            if len(fids) <= 1 or zona is None:
                nuovi.append(e)
                continue
            for f in fids:
                try:
                    t = per_fid.get(int(f))
                except ValueError:
                    t = None
                if t is None or t.get("geom") is None:
                    continue
                g = t["geom"].intersection(zona)
                if g.is_empty:
                    continue
                c = g.centroid
                pr = rfi._Proiezione(c.x, c.y)
                gm = pr.avanti(g)
                if gm.length < 0.5:
                    continue
                metri = max(1, int(gm.length * A._fattore_lunghezza(dict(t, gm=pr.avanti(
                    t["geom"]))) + 0.5))
                lungo = max(getattr(gm, "geoms", [gm]), key=lambda q: q.length)
                w = pr.indietro(lungo.interpolate(0.5, normalized=True))
                chiave = "S|%s|%s" % (e.get("tecnica"), f)
                nuovi.append({"tipo": "scavo", "tecnica": e.get("tecnica"), "metri": metri,
                              "lon": w.x, "lat": w.y, "km": "", "gruppo": chiave,
                              "chiave_el": chiave, "_wkt": g.wkt})
        i.elementi = nuovi


def assegna_km_auto(interferenze: list, prog) -> int:
    """Progressive da Progressive (proiezione sull'asse): per gli scavi i due
    estremi del pezzo nella zona, per pozzetti e armadi il punto. Ritorna il
    numero di elementi con progressiva."""
    from shapely import wkt as _wkt
    from shapely.geometry import Point
    n = 0
    for i in interferenze:
        for e in i.elementi:
            t = e.get("tipo")
            if t == "scavo" and e.get("_wkt"):
                try:
                    g = _wkt.loads(e["_wkt"])
                except Exception:  # noqa: BLE001
                    continue
                punti = []
                for parte in getattr(g, "geoms", [g]):
                    cc = list(parte.coords)
                    punti += [cc[0], cc[-1]]
                vals = [prog.km(Point(p)) for p in punti]
                vals = [v for v in vals if v is not None]
                if vals:
                    e["km_da"], e["km_a"] = metri_in_km(min(vals)), metri_in_km(max(vals))
                    n += 1
            elif t in ("pozzetto", "armadio") and "lon" in e:
                v = prog.km(Point(e["lon"], e["lat"]))
                if v is not None:
                    e["km_da"] = e["km_a"] = metri_in_km(v)
                    n += 1
    return n


def dentro_centri_anas(km_m, centri: list):
    """Centro abitato ANAS che contiene la progressiva (metri), o None.
    centri = [{'nome','dal','al','sotto_10000'}] con dal/al '100+200'."""
    for c in centri or []:
        a, b = km_in_metri(c.get("dal")), km_in_metri(c.get("al"))
        if a is not None and b is not None and min(a, b) <= km_m <= max(a, b):
            return c
    return None


def applica_centri_abitati(interferenze: list, strada, centri_anas: list = None,
                           perimetri: list = None, pop_comune=None) -> dict:
    """Centri abitati (art. 4 CdS) sulle interferenze di una strada:
    - perimetri = [(Polygon WGS84, nome, popolazione o None)] dal layer del
      progetto (delibera di delimitazione) -> test geometrico;
    - centri_anas = centri abitati della statale dal sito ANAS (km dal/al,
      classe di popolazione) -> test sulla progressiva degli elementi.
    Dentro un centro abitato:
    - la fascia di rispetto del DPR 495/1992 (art. 26, fuori dai centri) non
      vale: le interferenze in fascia escono dall'istanza (spunta tolta);
    - in sede: oltre 10.000 abitanti il tratto e' comunale (art. 2 c. 7 CdS),
      quindi i.competenza = 'comune'; fino a 10.000 resta l'ente proprietario
      con il nulla osta / rilascio del Comune (art. 26 c. 3).
    Popolazione: quella del perimetro o della classe ANAS; se manca, quella
    del Comune (approssimazione, scritta nella nota). Ritorna i conteggi."""
    from shapely.geometry import Point
    conti = {"in_centro": 0, "fascia_tolte": 0, "al_comune": 0}
    for i in interferenze:
        centro, pop, fonte = None, None, ""
        if perimetri:
            p = Point(i.lon, i.lat)
            for g, nome, popolazione in perimetri:
                try:
                    if g.contains(p):
                        centro, pop, fonte = nome or "centro abitato", popolazione, \
                            "perimetro del progetto"
                        break
                except Exception:  # noqa: BLE001
                    continue
        if centro is None and centri_anas:
            kms = [km_in_metri(v) for e in i.elementi for v in (e.get("km_da"), e.get("km_a"))]
            kms = [k for k in kms if k is not None]
            if kms:
                c = dentro_centri_anas(sum(kms) / len(kms), centri_anas)
                if c:
                    centro = c.get("nome") or "centro abitato"
                    pop = 5000 if c.get("sotto_10000") else 20000
                    fonte = "sito ANAS"
        if centro is None:
            i.centro_abitato = ""
            i.competenza = "ente"
            continue
        conti["in_centro"] += 1
        i.centro_abitato = centro
        approx = pop is None
        if approx:
            pop = pop_comune
        grande = pop is not None and pop > 10000
        if i.categoria == ZONA_FASCIA:
            # dentro i centri abitati le fasce restano (art. 18 CdS, art. 28 DPR
            # 495/1992), ridotte secondo il tipo di strada; nella pratica ANAS la
            # tabella «fascia di rispetto» c'e' anche nel centro abitato
            i.note.append("in fascia di rispetto dentro il centro abitato %s (%s): fasce "
                          "dell'art. 18 CdS / art. 28 DPR 495/1992, da verificare col "
                          "gestore" % (centro, fonte))
            i.competenza = "comune" if grande else "ente"
            if grande:
                conti["al_comune"] += 1
        elif grande:
            i.competenza = "comune"
            conti["al_comune"] += 1
            i.note.append("dentro il centro abitato %s (%s) con oltre 10.000 abitanti%s: tratto "
                          "comunale (art. 2 c. 7 CdS), istanza al Comune"
                          % (centro, fonte, " (popolazione del Comune)" if approx else ""))
        else:
            i.competenza = "ente"
            i.note.append("dentro il centro abitato %s (%s) fino a 10.000 abitanti: autorizza il "
                          "Comune previo nulla osta dell'ente proprietario (art. 26 c. 3 CdS)"
                          % (centro, fonte))
    return conti


# --------------------------------------------------------------------------- #
#  Progressive dal campo Chilometrica (calcolate nella sottoscheda)
# --------------------------------------------------------------------------- #
_RE_KM = re.compile(r"(\d+)\s*\+\s*(\d{1,3})")


def km_da_testo(testo) -> list:
    """'dal km 11+571 al km 11+583' -> ['11+571', '11+583']; '11+756' -> ['11+756']."""
    return ["%d+%03d" % (int(a), int(b)) for a, b in _RE_KM.findall(str(testo or ""))]


def km_intervallo(valori: list) -> tuple:
    """Da piu' progressive (anche di tratte attaccate) -> (min, max) come testo."""
    kms = sorted({v for v in valori if rfi.km_valore(v) is not None}, key=rfi.km_valore)
    if not kms:
        return "", ""
    return kms[0], kms[-1]


def testo_km(da: str, a: str) -> str:
    if not da:
        return ""
    if not a or a == da:
        return "km %s" % da
    return "dal km %s al km %s" % (da, a)


def assegna_km(interferenze: list, km_tratte: dict, km_punti: dict, strada=None,
               solo_testi: bool = False) -> None:
    """Scrive in ogni elemento la progressiva: e['km_da'], e['km_a'] (testo
    «11+571») dal campo Chilometrica dei layer (km_tratte = {fid tratta: testo},
    km_punti = {(tipo, fid): testo}); segna gli attraversamenti (scavo in sede
    che taglia l'asse) con e['attraversa']. Imposta anche il testo in tavola
    «KM ... SCAVO ...» (e['testo'])."""
    from shapely import wkt as _wkt
    asse = strada.geom if strada is not None else None
    for i in interferenze:
        for e in i.elementi:
            t = e.get("tipo")
            if t == "scavo":
                if not solo_testi or not e.get("km_da"):
                    fids = [f for f in (e.get("chiave_el") or "").split("|")[-1].split(",")
                            if f]
                    vals = []
                    for f in fids:
                        try:
                            vals += km_da_testo(km_tratte.get(int(f)))
                        except ValueError:
                            continue
                    if vals or not solo_testi:
                        e["km_da"], e["km_a"] = km_intervallo(vals)
                e["attraversa"] = False
                if asse is not None and i.categoria == ZONA_SEDE and e.get("_wkt"):
                    try:
                        g = _wkt.loads(e["_wkt"])
                        e["attraversa"] = bool(g.crosses(asse))
                    except Exception:  # noqa: BLE001
                        pass
            elif t in ("pozzetto", "armadio"):
                if not solo_testi or not e.get("km_da"):
                    v = km_da_testo(km_punti.get((t, e.get("fid"))))
                    e["km_da"] = e["km_a"] = v[0] if v else ""
            else:
                continue
            e["testo"] = testo_tavola(e, i.categoria)


def testo_tavola(e: dict, zona: str) -> str:
    """Etichetta in tavola come nelle PL consegnate:
    'KM 11+756\\nPOSA POZZETTO 40x76', 'dal km 11+571 al km 11+583\\nSCAVO
    Tradizionale 11 m' (niente 'Mt', niente 'IN FASCIA DI RISPETTO')."""
    km = testo_km(e.get("km_da"), e.get("km_a"))
    if e.get("tipo") == "scavo" and e.get("km_da") and e.get("km_a"):
        # scavo trasversale (attraversa l'asse, o la progressiva avanza meno
        # di meta' della lunghezza): una sola progressiva, quella dell'asse
        try:
            m_da, m_a = km_in_metri(e["km_da"]), km_in_metri(e["km_a"])
            lung = float(e.get("metri") or 0)
            if e.get("attraversa") or (lung and abs(m_a - m_da) < 0.5 * lung):
                km = testo_km(metri_in_km((m_da + m_a) / 2.0), None)
        except Exception:  # noqa: BLE001
            pass
    if e.get("tipo") == "scavo":
        tec = A.TECNICA_ETICHETTA.get(e.get("tecnica"), str(e.get("tecnica") or "").upper())
        if tec.startswith("SCAVO "):
            tec = "SCAVO " + tec[6:].capitalize()
        try:
            m = float(e.get("metri") or 0)
            m = ("%d" % round(m)) if abs(m - round(m)) < 0.05 else ("%.1f" % m)
        except (TypeError, ValueError):
            m = str(e.get("metri"))
        riga = "%s %s m" % (tec, m)
    elif e.get("tipo") == "pozzetto":
        riga = "POSA POZZETTO %s" % str(e.get("dim_testo") or e.get("dim") or "").lower()
    else:
        riga = A.testo_elemento_auto(e)
    if km.lower().startswith("km"):
        km = km.upper()
    return ("%s\n%s" % (km, riga)) if km else riga


# --------------------------------------------------------------------------- #
#  Istanze e righe della relazione
# --------------------------------------------------------------------------- #
def raggruppa_istanze_strade(interferenze: list, strade: list, comune: str,
                             dati_comune: dict = None) -> list:
    """Una istanza per strada (con sede e fascia insieme), in ordine di
    progressiva. I tratti dentro i centri abitati oltre 10.000 abitanti
    (i.competenza == 'comune') vanno in una istanza a parte intestata al
    Comune. Ogni istanza ha .strada (Strada). dati_comune = {indirizzo, pec}."""
    import copy
    per_ref = {}
    for i in interferenze:
        if not i.includi:
            continue
        comp = getattr(i, "competenza", "ente") or "ente"
        # competenza all'ente anche dentro il centro abitato: istanze separate
        # DENTRO e FUORI centro abitato (stesso ente)
        dove = ("dentro" if getattr(i, "centro_abitato", "") else "fuori") \
            if comp == "ente" else ""
        per_ref.setdefault((i.corso, comp, dove), []).append(i)
    # la distinzione dentro/fuori serve solo se la strada ha lavori da tutte e
    # due le parti; altrimenti l'istanza resta unica (ma dice dove sta)
    parti_ente = {}
    for ref, comp, dove in per_ref:
        if comp == "ente":
            parti_ente.setdefault(ref, set()).add(dove)
    s_per_ref = {s.ref: s for s in strade}
    istanze = []
    for n, ((ref, comp, dove), lst) in enumerate(
            sorted(per_ref.items(), key=lambda kv: (_num(kv[0][0]), kv[0][1], kv[0][2])), 1):
        s = s_per_ref.get(ref)
        doppia = comp == "ente" and len(parti_ente.get(ref, ())) > 1
        if s is not None and comp == "comune":
            s = copy.copy(s)
            s.ente_nome = "Comune di %s" % comune
            s.ente_ufficio = "Settore Lavori Pubblici / Viabilità"
            s.ente_indirizzo = (dati_comune or {}).get("indirizzo") or ""
            s.ente_pec = (dati_comune or {}).get("pec") or ""
            s.epc_comune = False
            s.nota = ("Tratto interno al centro abitato con oltre 10.000 abitanti: strada "
                      "comunale ai sensi dell'art. 2 c. 7 CdS. " + (s.nota or ""))
        ist = A.IstanzaAcqua(numero=n, ente_tipo=s.classe if s else "", ente_nome=(
            s.ente_nome if s else ""), interferenze=lst, corso=ref, corsi_chiavi=[ref])
        ist.strada = s
        centri = []
        for i in lst:
            c = getattr(i, "centro_abitato", "")
            if c and c not in centri:
                centri.append(c)
        # dove: 'dentro' / 'fuori' centro abitato ('' = non distinto)
        ist.centro = dove if (comp == "ente" and (doppia or dove == "dentro")) else ""
        ist.centri = centri
        suff = {"comune": "_COMUNE"}.get(comp, "")
        if ist.centro == "dentro":
            suff = "_DENTRO_CA"
        elif ist.centro == "fuori" and doppia:
            suff = "_FUORI_CA"
        ist.nome_base = "%s_%s%s" % ((comune or "COMUNE").upper(), ref, suff)
        ist.tavole = A.tavole_per_zona(lst)
        ist.interferenze = [i for t in ist.tavole for i in t]
        istanze.append(ist)
    return istanze


def _valore_km(e):
    return rfi.km_valore(e.get("km_da") or "") or 10 ** 9


def segna_attraversamenti(ist) -> bool:
    """«*» sugli attraversamenti e nota sulla trincea tradizionale: solo per
    le istanze ANAS (come la pratica SS71), o se l'utente lo chiede nelle
    avanzate (ist.attraversamenti_sempre)."""
    if getattr(ist, "attraversamenti_sempre", False):
        return True
    s = getattr(ist, "strada", None)
    return bool(s and "ANAS" in (getattr(s, "ente_nome", "") or "").upper())


def tratte_rt(ist, righe: str = "km") -> list:
    """Righe della relazione (rfi.Tratta): una per scavo e una per pozzetto,
    in ordine di progressiva, come nelle pratiche consegnate. Scavi in fascia
    con la nota «(fascia di rispetto)», attraversamenti con «*». Senza
    progressiva: la via e le coordinate."""
    scavi, pozz = [], []
    for i in ist.interferenze:
        for e in i.elementi:
            if e.get("tipo") == "scavo" and e.get("metri") and e.get("tecnica"):
                scavi.append((i, e))
            elif e.get("tipo") == "pozzetto" and (e.get("dim") or e.get("dim_testo")):
                pozz.append((i, e))
    out = []

    def _etich(i, e):
        km = testo_km(e.get("km_da"), e.get("km_a"))
        if not km or righe == "coordinate":
            km = ("%s (%s)" % (i.via, A.fmt_coord(e["lat"], e["lon"]))) if i.via else \
                A.fmt_coord(e["lat"], e["lon"])
        if e.get("attraversa") and segna_attraversamenti(ist):
            km += "*"
        if i.categoria == ZONA_FASCIA:
            km += " (fascia di rispetto)"
        return km
    for i, e in sorted(scavi, key=lambda ie: _valore_km(ie[1])):
        tr = rfi.Tratta(e.get("km_da") or "", e.get("km_a") or "", {e["tecnica"]: e["metri"]},
                        {}, _etich(i, e), [])
        tr._elementi = [e]                       # colonna «N. ARLO»
        out.append(tr)
    for i, e in sorted(pozz, key=lambda ie: _valore_km(ie[1])):
        dim = rfi.norm_pozzetto(e.get("dim")) or e.get("dim")
        et = _etich(i, e)
        tr = rfi.Tratta(e.get("km_da") or "", e.get("km_a") or "", {}, {dim: 1}, et,
                        [(et, {dim: 1})])
        tr._elementi = [e]
        tr._pozzetti_el = [[e]]
        out.append(tr)
    return out


# --------------------------------------------------------------------------- #
#  Relazione tecnica strade (modello ricavato dalla RT ANAS SS71 consegnata)
# --------------------------------------------------------------------------- #
ORDINE_TECNICHE = ("minitrincea", "microtrincea", "trincea", "nodig", "canaletta")


def _righe_tabelle(ist):
    """Righe delle tabelle della relazione, come nella pratica SS71:
    {'scavi': [...], 'fascia_scavi': [...], 'pozzetti': [...],
     'fascia_pozzetti': [...], 'armadi': [...]} con
    scavi: (etichetta, {tecnica: metri}), pozzetti: (etichetta, {dim: n}),
    armadi: (etichetta, id). Etichetta = progressiva (dal km al km / km),
    con «*» sugli attraversamenti; senza progressiva via e coordinate."""
    out = {k: [] for k in ("scavi", "fascia_scavi", "pozzetti", "fascia_pozzetti", "armadi")}
    # numeri ARLO paralleli alle righe (colonna «N. ARLO», ftth_arlo)
    out["_arlo"] = {k: [] for k in ("scavi", "fascia_scavi", "pozzetti", "fascia_pozzetti")}
    out["_con_arlo"] = any("arlo" in e for i in ist.interferenze for e in i.elementi)

    def _etich(i, e):
        km = testo_km(e.get("km_da"), e.get("km_a")).replace("km ", "", 1) \
            if e.get("km_da") == e.get("km_a") else testo_km(e.get("km_da"), e.get("km_a"))
        if not e.get("km_da"):
            km = ("%s (%s)" % (i.via, A.fmt_coord(e["lat"], e["lon"]))) if i.via else \
                A.fmt_coord(e["lat"], e["lon"])
        return km + ("*" if e.get("attraversa") and segna_attraversamenti(ist) else "")
    elem = []
    for i in ist.interferenze:
        for e in i.elementi:
            elem.append((i, e))
    elem.sort(key=lambda ie: _valore_km(ie[1]))
    for i, e in elem:
        fascia = i.categoria == ZONA_FASCIA
        t = e.get("tipo")
        if t == "scavo" and e.get("metri") and e.get("tecnica"):
            out["fascia_scavi" if fascia else "scavi"].append(
                (_etich(i, e), {e["tecnica"]: e["metri"]}))
            out["_arlo"]["fascia_scavi" if fascia else "scavi"].append(e.get("arlo") or "")
        elif t == "pozzetto" and (e.get("dim") or e.get("dim_testo")):
            dim = rfi.norm_pozzetto(e.get("dim")) or e.get("dim")
            out["fascia_pozzetti" if fascia else "pozzetti"].append((_etich(i, e), {dim: 1}))
            out["_arlo"]["fascia_pozzetti" if fascia else "pozzetti"].append(e.get("arlo") or "")
        elif t == "armadio":
            out["armadi"].append((_etich(i, e), e.get("id") or "", i.via or ""))
    return out


def _con_arlo(r, chiave, rows, intest, tot_r):
    """Con il flag «N. ARLO»: colonna col numero dell'armadio accanto alla
    chilometrica e righe in ordine di numero (ftth_arlo)."""
    if not r.get("_con_arlo"):
        return rows, intest, tot_r
    try:
        from . import ftth_arlo as ARLO
    except ImportError:
        import ftth_arlo as ARLO
    nums = r["_arlo"].get(chiave) or [""] * len(rows)
    coppie = sorted(zip(nums, rows), key=lambda nr: ARLO.chiave_numero(nr[0]))
    rows = [[row[0], n or "-"] + row[1:] for n, row in coppie]
    return rows, [intest[0], ARLO.INTESTAZIONE] + intest[1:], [tot_r[0], ""] + tot_r[1:]


def _tabella_word(doc, segnaposto_p, intest, righe, totale=None, larghe=None):
    """Tabella al posto del paragrafo segnaposto: bordi semplici, intestazione
    in grassetto, testo centrato (come nelle relazioni consegnate)."""
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml import OxmlElement
    from docx.oxml.ns import qn
    from docx.shared import Pt
    n_r = 1 + len(righe) + (1 if totale else 0)
    t = doc.add_table(rows=n_r, cols=len(intest))
    tblpr = t._tbl.tblPr
    bordi = OxmlElement("w:tblBorders")
    for lato in ("top", "left", "bottom", "right", "insideH", "insideV"):
        b = OxmlElement("w:%s" % lato)
        b.set(qn("w:val"), "single")
        b.set(qn("w:sz"), "4")
        b.set(qn("w:color"), "000000")
        bordi.append(b)
    tblpr.append(bordi)
    jc = OxmlElement("w:jc")
    jc.set(qn("w:val"), "center")
    tblpr.append(jc)

    from docx.shared import RGBColor

    def _cella(c, testo, grassetto=False, blu=False):
        """Come le relazioni consegnate: corpo 10, intestazione e totale su
        fondo blu 0070C0 con testo bianco in grassetto; carattere del documento."""
        c.text = ""
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(testo))
        r.bold = grassetto or blu
        r.font.size = Pt(10)
        if blu:
            r.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)
            sh = OxmlElement("w:shd")
            sh.set(qn("w:val"), "clear")
            sh.set(qn("w:color"), "auto")
            sh.set(qn("w:fill"), "0070C0")
            c._tc.get_or_add_tcPr().append(sh)
    for k, h in enumerate(intest):
        _cella(t.rows[0].cells[k], h, blu=True)
    for n, riga in enumerate(righe, 1):
        for k, v in enumerate(riga):
            _cella(t.rows[n].cells[k], v)
    if totale:
        for k, v in enumerate(totale):
            _cella(t.rows[-1].cells[k], v, blu=True)
    if larghe:
        from docx.shared import Mm
        for r in t.rows:
            for k, w in enumerate(larghe):
                r.cells[k].width = Mm(w)
    segnaposto_p._p.addnext(t._tbl)
    segnaposto_p._p.getparent().remove(segnaposto_p._p)
    return t


def _togli_blocco(segnaposto_p):
    """Tabella vuota: via il segnaposto e il titolo che lo precede
    (es. «FASCIA RISPETTO POZZETTI:»)."""
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    el = segnaposto_p._p.getprevious()
    while el is not None and el.tag == W + "p":
        t = "".join(x.text or "" for x in el.iter(W + "t")).strip()
        prec = el.getprevious()
        if t:
            if t.endswith(":"):
                el.getparent().remove(el)
            break
        el.getparent().remove(el)
        el = prec
    segnaposto_p._p.getparent().remove(segnaposto_p._p)


def genera_rt_strade(ist, comune, cartella_template, out_path, rese=None, pl_file="",
                     rt_file="", oggi=None):
    """1.2 RT+CR della strada dal modello strade: tabelle nuovi scavi e
    fascia di rispetto separate (solo le tecniche presenti), pozzetti, armadi,
    cronoprogramma; capitoli delle tecniche, pozzetti e armadio solo se servono."""
    import datetime
    import os
    from docx import Document
    tpl = os.path.join(cartella_template, "TEMPLATE_1.2_RT+CR.docx")
    doc = Document(tpl)
    oggi = oggi or datetime.date.today()
    try:                                # colonna «N. ARLO» (flag del progetto)
        from . import ftth_arlo as _ARLO
    except ImportError:
        import ftth_arlo as _ARLO
    _ARLO.annota_progetto(ist.interferenze)
    r = _righe_tabelle(ist)
    s = ist.strada
    # ANAS (pratica SS71): sede e fascia in tabelle separate. Gli altri enti
    # (pratica SP306 Provincia): un'unica TABELLA INTERVENTI, pozzetti e
    # UBICAZIONE ARMADI, senza tabelle di fascia
    anas = bool(s and "ANAS" in (s.ente_nome or "").upper())
    if not anas:
        _ord = lambda lst: sorted(lst, key=lambda em: (km_in_metri(  # noqa: E731
            (re.findall(r"\d+\+\d{3}", em[0]) or ["999999+999"])[0]) or 0))
        r["scavi"] = _ord(r["scavi"] + r["fascia_scavi"])
        r["pozzetti"] = _ord(r["pozzetti"] + r["fascia_pozzetti"])
        r["fascia_scavi"], r["fascia_pozzetti"] = [], []
        nuovi_titoli = {"TABELLA NUOVI SCAVI:": "TABELLA INTERVENTI:",
                        "FASCIA RISPETTO ARMADI:": "UBICAZIONE ARMADI:"}
        for p_ in doc.paragraphs:
            nuovo = nuovi_titoli.get(p_.text.strip())
            if nuovo and p_.runs:
                # il titolo e' spezzato in piu' run: testo nel primo, gli altri vuoti
                p_.runs[0].text = nuovo
                for run in p_.runs[1:]:
                    run.text = ""
    tec = [t for t in ORDINE_TECNICHE
           if any(m.get(t) for _e, m in r["scavi"] + r["fascia_scavi"])]
    dims = sorted({d for _e, p in r["pozzetti"] + r["fascia_pozzetti"] for d in p})
    n_arm = len(r["armadi"])
    rfi.applica_condizioni(doc, {
        "SE_MICRO": "microtrincea" in tec, "SE_MINI": "minitrincea" in tec,
        "SE_TRINCEA": "trincea" in tec, "SE_NODIG": "nodig" in tec, "SE_CANALA": "canaletta" in tec,
        "SE_POZZETTI": bool(dims), "SE_ARMADI": bool(n_arm),
        "SE_ATTRAVERSAMENTI": any(e.endswith("*") for e, _m in r["scavi"])})
    if not segna_attraversamenti(ist):
        # nota sulla trincea tradizionale solo con gli attraversamenti segnati (ANAS)
        for p_ in list(doc.paragraphs):
            if p_.text.strip().startswith("Si specifica che la tecnica"):
                p_._p.getparent().remove(p_._p)
    nome = (s.nome_documenti() if s else ist.corso) + specifica_centro(ist)
    rfi.sostituisci_tutto(doc, {
        # come nelle pratiche: «ANAS SS71» per ANAS, l'ente per gli altri
        # («PROVINCIA DI PERUGIA»)
        "TITOLO_RT": (("ANAS %s" % nome) if s and "ANAS" in (s.ente_nome or "").upper()
                      else ((s.ente_nome if s else "") or nome)).upper(),
        "DEST_NOME": (s.ente_nome if s else "") or rfi.XXX,
        "NOME_COMUNE": comune.nome.upper(), "STRADA": nome,
        "PL_FILE": pl_file, "RT_FILE": rt_file, "DATA_RT": oggi.strftime("%d/%m/%Y")})
    par = {p.text.strip(): p for p in doc.paragraphs if p.text.strip().startswith("<<TAB_")}
    nomi_tec = {"minitrincea": "Minitrincea", "microtrincea": "Microtrincea",
                "trincea": "Tradizionale", "nodig": "No-Dig", "canaletta": "Canaletta VTR"}

    def _scavi(chiave, segn):
        righe = r[chiave]
        p = par.get(segn)
        if p is None:
            return
        if not righe:
            _togli_blocco(p)
            return
        rows, tot = [], {t: 0 for t in tec}
        for et, m in righe:
            rows.append([et] + [str(int(m.get(t, 0))) for t in tec] +
                        [str(int(sum(m.values())))])
            for t in tec:
                tot[t] += m.get(t, 0)
        intest = ["Chilometrica"] + ["%s (m)" % nomi_tec[t] for t in tec] + ["Totale (m)"]
        tot_r = ["TOTALE COMPLESSIVO (m)"] + [str(int(tot[t])) for t in tec] + \
            [str(int(sum(tot.values())))]
        rows, intest, tot_r = _con_arlo(r, chiave, rows, intest, tot_r)
        _tabella_word(doc, p, intest, rows, tot_r)

    def _pozz(chiave, segn):
        righe = r[chiave]
        p = par.get(segn)
        if p is None:
            return
        if not righe:
            _togli_blocco(p)
            return
        rows, tot = [], {d: 0 for d in dims}
        for et, pz in righe:
            rows.append([et] + [str(pz.get(d, 0)) for d in dims] + [str(sum(pz.values()))])
            for d in dims:
                tot[d] += pz.get(d, 0)
        intest = ["Chilometrica"] + list(dims) + ["Totale"]
        tot_r = ["TOTALE COMPLESSIVO"] + [str(tot[d]) for d in dims] + [str(sum(tot.values()))]
        rows, intest, tot_r = _con_arlo(r, chiave, rows, intest, tot_r)
        _tabella_word(doc, p, intest, rows, tot_r)
    _scavi("scavi", "<<TAB_SCAVI>>")
    _scavi("fascia_scavi", "<<TAB_FASCIA_SCAVI>>")
    _pozz("pozzetti", "<<TAB_POZZETTI>>")
    _pozz("fascia_pozzetti", "<<TAB_FASCIA_POZZETTI>>")
    p = par.get("<<TAB_ARMADI>>")
    if p is not None:
        if r["armadi"]:
            if anas:
                _tabella_word(doc, p, ["Chilometrica", "Area ARLO", "Foto"],
                              [[et, ida or "", ""] for et, ida, _v in r["armadi"]],
                              ["Totale complessivo", str(n_arm), ""])
            else:
                _tabella_word(doc, p, ["ARMADIO", "INDIRIZZO", "CIVICO", "CHILOMETRICA", "FOTO"],
                              [[ida or "-", via or "-", "-", et, "-"]
                               for et, ida, via in r["armadi"]])
        else:
            _togli_blocco(p)
    p = par.get("<<TAB_CRONO>>")
    if p is not None:
        metri = {t: sum(m.get(t, 0) for _e, m in r["scavi"] + r["fascia_scavi"]) for t in tec}
        n_pz = sum(sum(pz.values()) for _e, pz in r["pozzetti"] + r["fascia_pozzetti"])
        tr = rfi.Tratta("", "", metri, {"76x40": n_pz} if n_pz else {}, "", [])
        gg_sc, gg_pz, gg_rip = rfi.giorni_tratta(tr, rese)
        # giorni interi come nelle relazioni consegnate (35 m -> 1 gg)
        import math
        f = lambda v: "%d" % math.ceil(v - 1e-9) if v else "0"  # noqa: E731
        intest = [""] + ["%s (m)" % nomi_tec[t] for t in tec] + \
            (["Pozzetti (n)"] if n_pz else []) + ["gg"]
        tot_gg = sum(gg_sc.values()) + gg_pz + gg_rip
        riga = [nome] + [str(int(metri[t])) for t in tec] + ([str(n_pz)] if n_pz else []) + \
            [f(tot_gg)]
        totale = ["Totale giorni lavorazione"] + [f(gg_sc.get(t, 0)) for t in tec] + \
            ([f(gg_pz)] if n_pz else []) + [f(tot_gg)]
        _tabella_word(doc, p, intest, [riga], totale)
    cp = doc.core_properties
    cp.author = cp.last_modified_by = "FTTH Permessi Manager"
    doc.save(out_path)
    return out_path


def tecniche_ist(ist) -> dict:
    tot = {}
    for i in ist.interferenze:
        for t, m in i.metri.items():
            tot[t] = tot.get(t, 0) + m
    return {t: m for t, m in tot.items() if m}


def valori_strade(ist, comune, rese=None) -> dict:
    """Segnaposto del modello d'istanza strade (modelli_strade)."""
    s = ist.strada
    tec = tecniche_ist(ist)
    nomi = {"minitrincea": "la tecnica della minitrincea", "microtrincea":
            "la tecnica della microtrincea", "trincea": "la tecnica tradizionale (trincea)",
            "nodig": "la perforazione teleguidata (no-dig)",
            "canaletta": "la posa in canaletta VTR/FeZn"}
    frase = A._elenco([nomi.get(t, t) for t in tec]) or "posa senza scavo"
    breve = ", ".join("%s %d m" % (ETICHETTA_TECNICA.get(t, t).lower(), m)
                      for t, m in tec.items()) or "nessuno"
    n_pozz = sum(sum(i.pozzetti.values()) for i in ist.interferenze)
    n_arm = sum(1 for i in ist.interferenze for e in i.elementi if e.get("tipo") == "armadio")
    pose = []
    if n_pozz:
        pose.append("la posa di %d pozzett%s" % (n_pozz, "o" if n_pozz == 1 else "i"))
    if n_arm:
        pose.append("la posa di %d armadi%s" % (n_arm, "o" if n_arm == 1 else ""))
    # giorni: stesse rese del cronoprogramma RFI
    tot = rfi.Tratta("", "", tec, {"76x40": n_pozz} if n_pozz else {}, "", [])
    gg_scavo, gg_pozz, gg_rip = rfi.giorni_tratta(tot, rese)
    kms = [v for i in ist.interferenze for e in i.elementi
           for v in (e.get("km_da"), e.get("km_a")) if v]
    da, a = km_intervallo(kms)
    X = rfi.XXX
    g = lambda v: ("%g" % v).replace(".", ",") if v else "—"  # noqa: E731
    return {
        "NOME_COMUNE_TITOLO": comune.nome, "NOME_COMUNE": comune.nome.upper(),
        "PROV_SIGLA": comune.prov_sigla.upper(), "CAP": comune.cap,
        "INDIRIZZO_COMUNE": comune.indirizzo or X, "COMUNE_PEC": comune.pec or X,
        "DEST_NOME": (s.ente_nome if s else "") or X,
        "DEST_UFFICIO": (s.ente_ufficio if s else "") or "",
        "DEST_INDIRIZZO": (s.ente_indirizzo if s else "") or X,
        "DEST_PEC": (s.ente_pec if s else "") or X,
        "STRADA": (s.nome_documenti() if s else ist.corso) + specifica_centro(ist),
        "TRATTI_KM": ("dal km %s al km %s" % (da, a)) if da and a and da != a else (
            ("km %s" % da) if da else "tratti indicati negli elaborati grafici"),
        "TECNICHE_FRASE": frase, "TECNICHE_BREVE": breve,
        "FRASE_POSE": (", " + A._elenco(pose)) if pose else "",
        "GG_SCAVO": g(sum(gg_scavo.values())), "GG_ARMADIO": g(n_arm and 1.0),
        "GG_POSA": g(gg_pozz), "GG_ATTESA": g(1.0 if tec else 0),
        "GG_RIPRISTINO": g(gg_rip),
    }


def specifica_centro(ist) -> str:
    """' (tratto interno al centro abitato di X)' / ' (tratti esterni al centro
    abitato)' quando l'istanza e' divisa dentro/fuori centro abitato."""
    dove = getattr(ist, "centro", "")
    if dove == "dentro":
        centri = getattr(ist, "centri", []) or []
        return " (tratto interno al centro abitato%s)" % (
            (" di " + A._elenco(centri)) if centri else "")
    if dove == "fuori":
        return " (tratti esterni al centro abitato)"
    return ""


def testi_rt_strade(ist) -> dict:
    """Frasi per la relazione (modello Acque: stesse chiavi di testi_istanza)."""
    s = ist.strada
    nome = (s.nome_documenti() if s else ist.corso) + specifica_centro(ist)
    ente = (s.ente_nome if s else "") or "Ente proprietario della strada"
    nucleo = "la %s, di competenza %s" % (nome, A.articolo_di(ente))
    return {"oggetto": "lungo %s." % nucleo, "premessa": "lungo la %s" % nome,
            "bollo": "lungo %s, per la propria competenza." % nucleo,
            "titolo": ("LUNGO LA %s" % nome).upper(), "descr": "Scavi e posa lungo la strada",
            "tabella": ("LUNGO LA %s" % nome).upper(), "ente": ente}


def promemoria_strade(ist, comune, documenti: list) -> str:
    s = ist.strada
    righe = ["ISTANZA %d — %s" % (ist.numero, ist.nome_base), "",
             "Strada: %s %s%s" % (s.nome_documenti() if s else ist.corso,
                                  ("(%s)" % s.nome) if s and s.nome else "",
                                  specifica_centro(ist)),
             "Destinatario: %s — %s — PEC %s" % (
                 (s.ente_nome if s else "") or "XXXXX",
                 (s.ente_indirizzo if s else "") or "XXXXX", (s.ente_pec if s else "") or "XXXXX"),
             ""]
    if s and s.nota:
        righe += ["Competenza (dallo screening): " + s.nota, ""]
    senza_km = sum(1 for i in ist.interferenze for e in i.elementi
                   if e.get("tipo") in ("scavo", "pozzetto", "armadio") and not e.get("km_da"))
    if senza_km:
        righe += ["ATTENZIONE: %d elementi senza progressiva chilometrica (in relazione ci sono "
                  "le coordinate): scegli i cippi della strada al punto 3 (Chilometriche "
                  "con i cippi) della scheda Istanze Strade, ricalcola e rigenera."
                  % senza_km,
                  ""]
    righe += ["Documenti prodotti:"] + ["  - %s" % d for d in documenti]
    righe += ["", "Da completare: firmatari e dati del procuratore (XXXXX), referenti, impresa, "
                  "procura e documento d'identità, sezioni e foto, marche da bollo."]
    return "\n".join(righe) + "\n"
