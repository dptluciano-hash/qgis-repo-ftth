# Changelog — FTTH Permessi Manager

## Versione 1.5

- **Cache su disco delle soprintendenze SITAP (velocizzazione).** Il download
  completo dei layer soprintendenze (~16 MB, ~31 s misurati) è il pezzo più lento
  dello screening e cambia una volta ogni anni. Ora il risultato viene salvato
  nella cache temporanea di sistema (`%TEMP%/ftth_screening_cache/`, scadenza 30
  giorni): dal secondo screening in poi quel dato si legge dal disco in ~0,2 s
  invece di riscaricarlo. Misurato: 31,4 s → 0,22 s (140× più veloce) a parità di
  dati (44 soprintendenze). La cache è per-macchina, condivisa tra tutti i
  progetti, fuori dalla cartella del plugin (non si perde agli aggiornamenti né
  entra nel pacchetto).

## Versione 1.4

Correzioni emerse dal test end-to-end sul progetto reale Comune_Verifica (Stornarella):

- **Layer con filtro/sorgente non valido — recupero automatico.** Diversi progetti
  hanno sui layer 03 INFRASTRUTTURE / 01_ARMADIO OTTICO un subset filter salvato
  che referenzia un campo inesistente (es. `"SUOLO" IS NULL OR "SUOLO" <> 'COMUNALE'`
  dove il campo SUOLO non c'è nello shapefile): OGR rende il layer INVALIDO, quindi
  `getFeatures()` non itera e il tracciato risultava vuoto → "servono i layer 03
  INFRASTRUTTURE..." e lo screening sul tracciato NON partiva affatto. Ora il plugin
  rileva il layer non leggibile e lo RICARICA dalla sorgente pulita (senza il subset
  rotto), con messaggio nel log. Verificato su Stornarella: tracciato di 347 elementi
  costruito, 194 tratte Esistenti escluse.
- **Filtro STATO=Nuovo — rete di sicurezza.** Se il campo STATO esiste ma non ha
  alcuna tratta 'Nuovo' (campo vuoto/non compilato), il plugin NON filtra (analizza
  tutte le tratte) invece di produrre un tracciato vuoto.

## Versione 1.3

Controllo attivo del vincolo paesaggistico ex lege art. 142 (D.Lgs 42/2004):

- **Aree boscate (art. 142 lett. g).** Oltre all'avvertenza testuale, lo screening
  ora RACCOGLIE attivamente i boschi/aree forestali da OSM (natural=wood,
  landuse=forest) e li segnala come vincolo paesaggistico. In modalità tracciato
  misura la distanza reale (attraversamento ≤0,5 m / entro 150 m); in modalità
  comune segnala la presenza. Compaiono come ente da interpellare (Soprintendenza,
  art. 142 lett. g, livello 2) e nel foglio Excel "Vincoli e fonti". Verificato:
  Coriano 1 area, Bagno di Romagna 2 (inclusa "Abetina di Brasco").
- **Corsi d'acqua entro 150 m (art. 142 lett. c).** La logica di prossimità
  paesaggistica (già presente) resta: distingue attraversamento demaniale
  (R.D. 523/1904) da semplice prossimità entro la fascia dei 150 m.

Resta valido il principio: SITAP è incompleto sui vincoli ex lege, che valgono
per legge anche se non cartografati. Ora il plugin li cerca attivamente in OSM
invece di limitarsi ad avvisare.

## Versione 1.2

Correzioni emerse dal test su Stornarella (FG):

- **Foglio Riepilogo — strade solo-OSM incluse.** Il foglio "Riepilogo"
  elencava solo il Comune e le strade presenti nello stradario di riferimento,
  saltando le SP/SS presenti solo in OSM (non nel DBSN). Ora unisce le tre reti
  (primaria + solo-OSM + non-misurate) come già fa `componi_enti`: le strade
  attraversate/in fascia compaiono tutte (Stornarella: SP81 e SP88 ora nel
  Riepilogo). Le strade "fuori fascia" restano escluse (solo informative).
- **Soprintendenza SITAP — retry su errori transitori.** Il download completo
  delle soprintendenze (~16 MB, 30-40 s) sotto carico risponde a intermittenza
  502/503/timeout. Aggiunti 3 tentativi con backoff (4 s, 8 s) prima di
  arrendersi: recupera la PEC quando il servizio è solo momentaneamente
  sovraccarico, invece di riportare subito "HTTP 400/502".

## Versione 1.1

Migliorie allo Screening territorio (5 punti):

1. **INFRASTRUTTURE — solo Stato=Nuovo.** Il tracciato di analisi ora esclude le
   tratte con `STATO=Esistente` in 03 INFRASTRUTTURE, considerando solo quelle
   nuove (oggetto del permesso). Pozzetti e armadi restano tutti. Prima venivano
   incluse anche le reti già posate, inquinando l'analisi (es. Coriano 363
   tratte Esistenti su 566 Nuove).
2. **Confine comunale — verifica e trasparenza.** Registrato l'`admin_level` del
   confine risolto (deve essere 8=comunale) con avviso se si cade su un'area
   vasta. Le geometrie dei vincoli salvate nello shapefile sono ora RITAGLIATE
   sul confine comunale (prima potevano sforare nei comuni confinanti perché il
   WFS interroga per bbox rettangolare). Confine OSM verificato accurato su dati
   reali (Coriano -0,2%, Montelabbate -6,7% vs superficie ISTAT).
3. **Analisi enti gerarchica.** Gli enti da interpellare sono ora ordinati dal
   nazionale al comunale (L1 Stato: ANAS/autostrade, RFI, MiC/Soprintendenza,
   UNESCO → L2 regionale: SR, vincoli paesaggistici/ambientali, corsi d'acqua,
   idrogeologico → L3 provinciale: SP, Province → L4 Comune). Ordinamento
   stabile: nessun ente viene perso.
4. **RFI — struttura territoriale competente.** Quando nel territorio c'è una
   linea ferroviaria RFI, il report associa la Struttura Territoriale RFI
   competente per regione con il range del Fascicolo Circolazione Linee (PGOS
   Art.2), dalla tabella ufficiale RFI (20 regioni mappate sulle 15 strutture).
5. **Soprintendenza — fix HTTP 400 + geoportali regionali.** La query SITAP delle
   soprintendenze paesaggio non usa più il filtro bbox (che dava HTTP 400 per via
   dei poligoni giurisdizionali enormi): scarica l'elenco completo e fa il match
   spaziale in locale sul confine comunale. Recupera denominazione + PEC corrette
   (Montelabbate → SABAP AN-PU, Coriano → SABAP RA). Aggiunta la kb dei
   geoportali regionali (20 regioni): quando SITAP è parziale, il report rimanda
   al geoportale della regione giusta per la verifica manuale dei vincoli
   (Vincoli in Rete del MiC non è agganciabile: richiede autenticazione, HTTP
   401). Estensibile: campo WFS popolabile per regione (Lazio già verificato).

## Versione 1.0

Prima release stabile pubblica. Consolida tutte le funzionalità sviluppate nelle
versioni 0.x: gestione completa dell'iter di permesso (Comune e Altri Enti),
screening territoriale con fonti nazionali (ISPRA IdroGEO, SITAP, OSM), analisi
sul tracciato con fasce di rispetto, export Excel multi-foglio e shapefile dei
vincoli. Vedi le voci sottostanti per il dettaglio delle singole funzioni.

## Novità versione 0.106

**Shapefile dei vincoli SITAP.** Insieme all'Excel, lo screening ora salva un
shapefile permanente dei vincoli paesaggistici intercettati (art.136, art.142,
boschi, fasce fluviali, ...) accanto al report: `<comune>_vincoli_SITAP.shp`, in
EPSG:4326, campo `vincolo`. Le geometrie GeometryCollection di SITAP vengono
normalizzate a MultiPolygon (compatibili shapefile). Serve per verificare i
vincoli in mappa senza dipendere dal servizio SITAP online.

## Novità versione 0.105

**Fix — enti stradali da strade solo-OSM.** Le strade classificate presenti solo
in OSM (non nel DBSN/stradario) ora generano correttamente l'ente da interpellare
(ANAS/Provincia). Prima una SP attraversata dal tracciato ma assente nel DBSN non
compariva tra gli enti (caso Montelabbate: SP423 con 3 attraversamenti).

**Fix — corso d'acqua: attraversamento demaniale vs prossimità paesaggistica.**
Un corso d'acqua entro la fascia 150 m ma NON attraversato non viene più
etichettato come attraversamento demaniale (che richiederebbe concessione R.D.
523/1904): viene segnalato come vincolo paesaggistico fascia fluviale (art.142
lett.c), senza concessione demaniale se non si tocca l'alveo. La distinzione usa
la distanza reale misurata sul tracciato.

**Robustezza — centroide vuoto.** `_metrico` ripiega sul centro del bounding box
se il centroide della geometria è vuoto (GeometryCollection con parti degeneri),
evitando un crash dell'analisi sul tracciato.

## Novità versione 0.104

**Foglio "Fonti e affidabilità" nel report di screening.** Ogni export Excel ora
include un foglio dedicato con la tabella delle fonti usate (ISPRA IdroGEO, SITAP,
Nominatim, Overpass, stradario, gestori regionali): endpoint, tipo, se autoritativa
e confidenza, colorati per lettura a colpo d'occhio.

## Novità versione 0.103

**Fix critico — strade "solo OSM" con affiancamento longitudinale ora visibili.**
Le strade classificate presenti in OSM ma non nello stradario di riferimento
venivano stampate nel foglio "Strade classificate" SENZA i dati del tracciato
(distanza, affiancamento, attraversamenti), anche quando erano state misurate.
Risultato: strade su cui il tracciato corre in affiancamento longitudinale per
km apparivano con celle vuote, indistinguibili da un "fuori fascia". Ora i dati
del tracciato vengono mostrati anche per queste strade. (Caso reale Coriano:
SP41 affiancamento ~1.928 m + 7 attraversamenti e SP49 ~5.416 m + 22
attraversamenti risultavano vuote; erano le due strade più interessate.)

**Strade classificate senza geometria non più scartate in silenzio.** Se una
strada è classificata in OSM ma manca la geometria in un dato run, ora finisce
in una sezione dedicata "NON misurate" con warning, invece di sparire: così un
possibile affiancamento non misurato resta una verifica aperta segnalata.

**Gestori stradali regionali (SR/SS).** Nuova knowledge base 'gestori_regionali':
quando OSM non porta il tag operator, per le strade regionali lo strumento
propone il gestore probabile in base alla regione (es. Lazio→ASTRAL,
Veneto→Veneto Strade, FVG→FVG Strade), marcato "~ … (da confermare)". È un
suggerimento da verificare, non una certificazione.

## Novità versione 0.102

**Logo beexact ufficiale (SVG) su sfondo bianco.** Il banner ora usa il logo
vettoriale ufficiale beexact (file SVG) su fascia bianca, al posto della versione
disegnata a mano. Essendo vettoriale e renderizzato alla densità reale dello
schermo, è perfettamente nitido a qualsiasi scaling di Windows.

## Novità versione 0.101

**Logo beexact leggermente più piccolo** nel banner (più margine bianco attorno).

## Novità versione 0.100

**Logo beexact nitido anche con scaling schermo (HiDPI).** La sgranatura residua
era causata dallo scaling di Windows (es. 125%): il logo veniva disegnato a pixel
logici e poi stirato dal sistema. Ora il pixmap è renderizzato alla densità reale
dello schermo (letta da devicePixelRatio/logicalDpi) e marcato con
setDevicePixelRatio, così viene mostrato 1:1 sui pixel fisici — testo e frecce
restano nitidi a qualsiasi livello di scaling.

## Novità versione 0.99

**Logo beexact nitido nel banner.** Rifatto il rendering del logo per eliminare
la pixellatura e il chevron impastato: la scritta 'beexact' viene ritagliata dal
logo e scalata con supersampling (bordi netti), mentre le due frecce chevron
sono ridisegnate nativamente come poligoni (una bianca e una arancione, sagome
distinte e pulite) invece di rimpicciolire il JPEG che le fondeva in un blocco.

## Novità versione 0.98

**Rifinitura banner beexact.** Su indicazione: ripristinata l'icona QGIS di
default nella barra del titolo (rimossa l'icona beexact dalla finestra); banner
reso più stretto (da 40 a 30 px); logo spostato più a sinistra (margine ridotto)
e ritagliato via software per eliminare il padding navy attorno, così il chevron
bianco appare pulito e il logo parte a filo del bordo sinistro.

## Novità versione 0.97

**Logo beexact nel pannello.** Aggiunto un banner con il logo beexact (su sfondo
navy) a tutta larghezza in cima al pannello del plugin, e impostata l'icona
beexact nella barra del titolo della finestra e nella taskbar. La barra del
titolo di Windows con l'icona di sistema non è ricolorabile, quindi
l'identità del brand è resa dal banner interno appena sotto.

## Novità versione 0.96

**Default dei layer aggiornati per le schede del ramo Comune.** All'apertura del
pannello, i menu a tendina delle schede Comune si preimpostano sui layer tipici
del progetto Fibercop:

- **Seleziona elementi:** Infrastrutture → 03 INFRASTRUTTURE, Civici → CIVICI,
  ROE PTE → ROE PTE, Pozzetto → 02_POZZETTO, Cavo ottico → CAVO OTTICO,
  Cavo Raccordo → RACCORDI (prima cercava "CAVO RACCORDO"), Edifici → Edifici
  (prima senza default);
- **Esportazione:** Foto → Punto di Ripresa Fotografico, Armadio →
  01_ARMADIO OTTICO, Infrastrutture → 03 INFRASTRUTTURE, Stradario →
  Stradario_Italia (nuovo default), Pozzetto → 02_POZZETTO.

I default scattano solo se il layer esiste nel progetto; altrimenti il combo
resta com'è e lo imposti a mano (con la barra di ricerca introdotta in 0.94).

## Novità versione 0.95

**Correzione barra di ricerca layer: ora si può lasciare il campo vuoto.** Nei
combo che ammettono l'opzione "nessun layer" (Stradario, Armadio, ecc.) svuotare
il campo di ricerca ora imposta correttamente "nessun layer", invece di
riproporre l'ultimo selezionato. Sui combo che richiedono un layer, un testo non
valido continua a ripristinare l'ultima scelta buona.

## Novità versione 0.94

**Barra di ricerca nei menu a tendina dei layer.** Tutti i combo di selezione
layer del plugin (in ogni scheda) sono ora ricercabili: basta iniziare a
digitare una parte del nome per filtrare la lista, senza distinzione tra
maiuscole/minuscole e cercando la parola ovunque nel nome (non solo all'inizio).
Comodo nei progetti con molti layer. Se digiti un testo che non corrisponde a
nessun layer e clicchi altrove, il combo torna automaticamente all'ultimo layer
valido, senza lasciare selezioni sospese.

Corretto anche un errore introdotto in 0.93 che poteva impedire l'apertura del
pannello dopo lo spostamento dell'evidenza strade.

## Novità versione 0.93

**"Evidenza delle strade interessate" spostata nel solo ramo Altri Enti.** Il
gruppo di controlli per evidenziare in tavola le strade classificate toccate dal
progetto serve solo per le pratiche verso gli altri enti (ANAS, Provincia…), non
per la pratica comunale. Ora compare esclusivamente nella scheda Esportazione
del ramo Altri Enti; nel ramo Comune la scheda è più snella. Le impostazioni
dell'evidenza restano indipendenti e vengono salvate solo dove la funzione esiste.

## Novità versione 0.92

**Correzione conteggio ARLO.** I poligoni del layer Arlo Area senza etichetta
(campo `Label` vuoto/NULL) non vengono più conteggiati come zona ARLO: erano
in genere artefatti sovrapposti a un'area già etichettata e gonfiavano il
numero (es. 7 invece di 6). Il numero di poligoni scartati è indicato nel log
dello screening. Il foglio "Riepilogo" e la colonna ARLO AREA riflettono ora
solo le zone realmente etichettate.

## Novità versione 0.91

**Foglio "Riepilogo" al posto di "ARLO Area".** Sostituito il foglio per-zona
(troppo articolato) con una tabella piatta di riepilogo, una riga per ente/
interferenza, sul modello richiesto:

| Comune | Provincia | Regione | Ente | AREA ARMADIO | n° ARLO |

- una riga per ciascun ente/vincolo coinvolto (Comune, strade classificate,
  Soprintendenza, ferrovie, corsi d'acqua);
- **AREA ARMADIO** ricavata dal suffisso della Label ARLO (es. 387-04 → 04),
  elencando tutte le aree armadio toccate da quell'ente;
- **n° ARLO** = numero di zone ARLO interessate.

Molto più compatto e leggibile, adatto a essere consultato o incollato in un
prospetto. Il foglio compare solo se il progetto ha il layer Arlo Area.

## Novità versione 0.90

**Nuovo foglio Excel "ARLO Area" — vista per zona di progetto.** Oltre alle
colonne ARLO nei fogli esistenti, ora c'è un foglio dedicato che, per ogni
ARLO AREA, riassume:

- le **infrastrutture di progetto** che vi ricadono: tratte (03 INFRASTRUTTURE)
  con numero e metri totali + le loro label, armadi ottici, pozzetti;
- le **strade interessate** con classe e stato (attraversamento/affiancamento);
- i **vincoli paesaggistici**, le **ferrovie** e i **corsi d'acqua** che toccano
  quella zona.

Così per ogni area di progetto vedi in un colpo d'occhio quanto scavo comporta e
quali enti/vincoli la riguardano. Il foglio compare solo se nel progetto c'è il
layer Arlo Area. Se due poligoni ARLO si sovrappongono, gli elementi in comune
compaiono in entrambe le zone (rispecchia la sovrapposizione reale).

## Novità versione 0.89

**Colonna "ARLO AREA" nell'Excel dello screening.** Ogni strada, vincolo e
interferenza lineare viene attribuito alla/e zona/e ARLO che tocca (dal campo
`Label` del layer Arlo Area), così sai subito quale area di progetto è
interessata da ciascun vincolo:

- foglio "Strade classificate": colonna ARLO AREA con l'etichetta della zona
  attraversata/affiancata (o "—" se la strada è nel comune ma fuori da ogni ARLO);
- foglio "Vincoli e fonti": colonna ARLO AREA su vincoli paesaggistici, ferrovie
  e corsi d'acqua. La pericolosità idrogeologica ISPRA è un dato per comune,
  quindi riporta "intero comune".

La colonna compare solo quando nel progetto è presente il layer Arlo Area.
I poligoni ARLO senza etichetta compilata (`Label` vuoto) prendono "ARLO n".

## Novità versione 0.88

**Excel dello screening più chiaro e mai muto:**

- **Grafica ripulita:** intestazioni verdi coerenti su tutti i fogli, righe con
  bordi e zebratura, titolo e disclaimer distinti, colonne ridimensionate. Il
  foglio "Vincoli e fonti" — prima tre tabelle appiccicate — ora ha 4 sezioni
  titolate: 1) vincoli paesaggistici, 2) interferenze e pericolosità, 3) fonti
  e affidabilità, 4) avvertenze.
- **Foglio "Strade classificate" mai vuoto/silenzioso:** in testa una riga
  spiega sempre la fonte (stradario o OSM). Se non risulta nessuna strada, una
  nota rossa dice il MOTIVO reale — Overpass non raggiungibile in quel run
  (≠ assenza di strade) vs nessuna strada classificata che interseca il
  tracciato — con l'indicazione di rilanciare o caricare uno stradario.
- **Strade fuori fascia a titolo informativo:** in modalità tracciato, le
  strade classificate del comune che NON ricadono in fascia sono elencate in
  una sezione dedicata (nessun obbligo), così il foglio resta utile anche
  quando il tracciato non tocca nulla.

## Novità versione 0.87

**Secondo giro di correzioni dall'audit indipendente** (robustezza e completezza
delle fonti):

- **Paginazione WFS SITAP (bug critico):** le richieste ai vincoli erano
  troncate a un tetto fisso (400/800 poligoni) senza paginazione. Su comuni
  densi di vincoli (coste, aree boschive) i poligoni oltre il tetto venivano
  ignorati e un vincolo cogente realmente presente poteva risultare ASSENTE.
  Ora si pagina con startIndex fino a esaurire il dataset.
- **Risoluzione comune (admin_level=8):** per i capoluoghi omonimi della
  provincia (Roma, Milano, Napoli...) c'era il rischio di analizzare la Città
  Metropolitana invece del Comune. Ora si filtra esplicitamente il confine
  comunale.
- **Overpass timeout mascherato:** una risposta HTTP 200 con "remark" di
  timeout e dati parziali/vuoti veniva presa per buona. Ora attiva il failover
  sull'endpoint successivo.
- **Sito UNESCO senza ente:** il vincolo UNESCO veniva rilevato ma non generava
  alcun ente da interpellare (scheda mancante). Aggiunta la scheda in kb +
  warning automatico per qualsiasi vincolo intercettato privo di scheda.
- **Assenza interferenze lineari:** anche quando la query va a buon fine ma non
  trova ferrovie/corsi d'acqua, il report ora avvisa che OSM non è esaustivo
  (prima il caveat compariva solo in caso di errore di rete).
- **Caveat centro abitato sulle fasce stradali:** nei comuni >10.000 ab, una
  strada in sola prossimità (non attraversata) è marcata "(se fuori centro
  abitato)" perché le fasce di rispetto non valgono dentro il perimetro urbano.

## Novità versione 0.86

**Revisione a 360° della logica di analisi (screening territorio).** Audit
completo del motore, con fix di correttezza geometrica e di dominio:

- **Percentuali vincoli oltre il 100% (bug):** le aree dei poligoni SITAP
  sovrapposti venivano sommate (es. "boschi 159,8% del territorio"). Ora le
  intersezioni col comune/area sono unite (unary_union) prima di misurare
  l'area: le percentuali sono corrette e limitate al 100%.
- **Ref stradali multipli OSM (bug):** una way con `ref="E45;SS3bis"` veniva
  scartata perché leggeva solo il primo ref (E45 = itinerario europeo, senza
  competenza) e perdeva la SS3bis (ANAS). Ora si valutano tutti i ref e si
  tiene quello con competenza (priorità A>SS>SR>SP).
- **Competenza nei centri abitati >10.000 ab (art. 2 c.7 CdS):** per i comuni
  con oltre 10.000 abitanti il report segnala che i TRATTI INTERNI al centro
  abitato di SS/SR/SP sono strade comunali ex lege (Cons. Stato 403/2014):
  competenza del Comune, non dell'ente proprietario. Fuori dal centro resta
  l'ente. Nota riportata su ogni strada interessata (report ed Excel).
- **Analisi sul tracciato — affiancamento vs attraversamento:** oltre alla
  distanza minima, ora si misurano i METRI DI AFFIANCAMENTO (posa longitudinale
  lungo la strada) e il numero di ATTRAVERSAMENTI puntuali. Sono ciò che conta
  per canone e regime autorizzativo. Nuove colonne nell'Excel.
- **Soglie vincoli per tipo:** in modalità tracciato i vincoli areali (art. 136,
  boschi, parchi) contano se il tracciato li ATTRAVERSA o ricade entro il
  margine scelto — non più una fascia fittizia di 150 m attorno a ogni vincolo
  (i 150 m valgono solo per la fascia fluviale, già nei poligoni SITAP).
- **Distanze dalla fonte primaria (bug):** con stradario DBSN attivo, le
  distanze non vengono più sovrascritte da quelle OSM (meno accurate).
- **Corsi d'acqua senza nome:** i rii demaniali minori privi di tag `name` non
  vengono più scartati (erano interferenze reali perse).
- **Match ISPRA IdroGEO robusto:** confronto ISTAT normalizzato che gestisce lo
  zero iniziale delle province 01-09 (es. Genova 010032).

Il tool ora funziona anche su progetti SENZA i tuoi layer (niente ARLO, niente
DBSN/stradario): basta 03 INFRASTRUTTURE + pozzetti per il tracciato, e le
strade arrivano da OSM, i vincoli da SITAP. Verificato su Masone (GE).

## Novità versione 0.85

**Screening territorio — analisi sul TRACCIATO con fasce di rispetto
ufficiali:** nuova modalità (ora di default) che misura la distanza reale in
metri tra il tracciato di progetto (03 INFRASTRUTTURE + 02_POZZETTO +
01_ARMADIO OTTICO uniti) e ogni strada/vincolo/interferenza, e la confronta con
la fascia di rispetto ufficiale di quell'ente:
- strade: 40 m (SS), 60 m (autostrade), 30 m (SP/SR) — art. 26 DPR 495/1992;
- ferrovie: 30 m dalla rotaia più esterna (DPR 753/1980);
- corsi d'acqua: 150 m fascia paesaggistica (art. 142 D.Lgs 42/2004).
Ogni ente riceve lo stato "ATTRAVERSAMENTO" o "entro fascia di rispetto (N m)";
ciò che è oltre la fascia viene escluso dagli enti (non genera obbligo). Le
distanze sono calcolate sulla geometria della fonte primaria (DBSN/stradario
regionale se attivo, altrimenti OSM). L'elenco enti diventa così esattamente le
istanze da protocollare per quello scavo. In alternativa resta l'analisi
sull'AREA di progetto (ARLO), più prudente. Margine attorno al tracciato
regolabile (default 20 m).

Il report Markdown e l'Excel guadagnano le colonne "Distanza dal tracciato",
"Stato" e "Fascia di rispetto". Nota: le distanze OSM/SITAP hanno accuratezza
posizionale variabile; per gli attraversamenti critici verificare in campo.

## Novità versione 0.84

**Screening territorio — vincolo idrogeologico e rischio alluvioni (ISPRA
IdroGEO):** nuovo stadio che interroga l'API nazionale ISPRA IdroGEO e riporta,
per il comune, le aree a pericolosità idraulica (PGRA: P1/P2/P3) e da frana
(PAI: P1-P4) come percentuale di territorio. Fonte autoritativa (ISPRA),
confidenza alta. Se la pericolosità supera l'1% del territorio il report genera
l'ente competente (Regione/ente delegato + Autorità di Bacino Distrettuale) con
titolo, documentazione e criticità. Nuova sezione "3-bis" nel Markdown e righe
dedicate nel foglio "Vincoli e fonti" dell'Excel. È un dato per COMUNE, non per
area di progetto: dice se il territorio ha aree vincolate; se il tracciato ci
ricade, la perimetrazione di dettaglio va letta sul PAI del distretto e sul
geoportale regionale (il report lo dichiara).

## Novità versione 0.83

**Screening territorio — lo stradario di riferimento si sceglie da solo:**
all'apertura del pannello il combo dello stradario viene preselezionato sul
miglior layer presente nel progetto, con la spunta già attiva. Priorità:
1) DBSN Strade (carreggiata reale, IGM — indipendente da OSM); 2) grafo
regionale (Stradario FVG/Veneto/…); 3) estratto OSM (ANAS_Italia, Stradario
Provincia Italia) solo come ultima scelta. Nei progetti che caricano più DBSN
regionali insieme, viene scelto quello la cui estensione copre davvero l'area
di progetto (ARLO), non il primo dell'elenco. Resta tutto modificabile a mano
e la spunta si può togliere. Il campo con la sigla è riconosciuto in
automatico (tr_str_nom per il DBSN, trim_str_c per FVG, ref per gli estratti
OSM).

## Novità versione 0.82

**Screening territorio — stradario di riferimento come fonte primaria delle
strade:** nuova spunta "Usa uno stradario del progetto come fonte primaria",
con combo del layer e del campo che contiene la sigla (SP/SS/…). Quando
attiva, la classificazione delle strade viene letta da QUEL layer (filtrato
sull'area di progetto) e OSM/Overpass resta come **controprova**: ogni strada
nel report è marcata "Confermata OSM sì/no", le strade presenti in OSM ma non
nello stradario finiscono in una riga a parte "solo OSM — da verificare", e
ogni discordanza genera un warning. Il tool **riconosce da solo** se il layer
scelto è un estratto OpenStreetMap (campo osm_id): in quel caso avverte che la
controprova NON è indipendente e tiene la confidenza "media"; con una fonte
vera (grafo regionale, DBSN) la confidenza sale ad "alta". Dove lo stradario
regionale ha il campo dell'ente gestore (es. Stradario FVG: "FVG Strade",
"Provincia di Udine"), quell'ente reale sostituisce il generico nel report e
nell'Excel. Il file .xlsx guadagna la colonna "Confermata OSM".

Nota tecnica utile: i layer "ANAS_Italia" e "Stradario Provincia Italia" del
progetto sono estratti OSM (Geofabrik), NON fonti indipendenti — usarli come
riferimento dà coerenza col dato in mappa ma non aggiunge autorevolezza. Per
una verifica davvero indipendente da OSM usare il DBSN (IGM) o un grafo
regionale (BDTRE, Stradario FVG/Veneto/Lazio). Non esiste ad oggi un servizio
ANAS ufficiale interrogabile a caldo: il grafo ANAS su dati.mit.gov.it è fermo
al 2015 e il sito stradeanas.it non espone la rete come geodato.

## Novità versione 0.81

**Screening territorio — restrizione all'area di progetto (ARLO):** nuova
spunta "Restringi all'area di progetto" (attiva per default, con il combo
preimpostato sul layer ARLO AREA/Arlo Area quando esiste nel progetto): lo
screening tiene solo le strade, i vincoli e le interferenze che intersecano
davvero l'area — l'elenco enti diventa la lista delle istanze da protocollare,
non l'inventario dell'intero comune. Le percentuali dei vincoli sono
ricalcolate sull'area e ogni strada dichiara i segmenti dentro l'area accanto
a quelli comunali. Il filtro avviene sulle geometrie vere (unione dei poligoni
ARLO riproiettata in WGS84), non sui conteggi.

**Screening territorio — report Excel:** nuova spunta per il file .xlsx
accanto al progetto, tre fogli: "Enti da interpellare" (riga per ente con
ruolo, trigger, titolo richiesto, norme, PEC, documentazione e criticità),
"Strade classificate" (ref, classe, ente, gestore OSM, segmenti
comune/area), "Vincoli e fonti" (vincoli, interferenze, provenienza e
confidenza, warning). Scritto con openpyxl, incluso in QGIS.

**Screening territorio — ex sedimi ferroviari:** la query delle interferenze
ora intercetta anche railway=abandoned/disused/razed. Il sedime delle linee
dismesse resta di norma di proprietà RFI anche dove riconvertito a greenway
(caso reale: la Voghera–Varzi a Rivanazzano Terme) e l'attraversamento
richiede comunque il nulla osta: nuova voce 'ferrovia_dismessa' nella kb, ente
dedicato nel report. In più: se lo stadio ferrovie/acque fallisce per rete, il
report ora lo dice con un warning esplicito invece di mostrare un elenco
vuoto; il registro della scheda mostra il perché di ogni ente (trigger).

## Novità versione 0.80

**Nuova scheda — "Screening territorio" (ramo Altri Enti):** scrivi il nome del
comune e il plugin interroga le fonti nazionali per la pre-istruttoria dello
scavo su suolo pubblico: rete stradale classificata (SS ANAS, SP, SR,
autostrade) con l'ente gestore da OSM, Soprintendenza ABAP competente con PEC
(SITAP/MiC, dato autoritativo), vincoli paesaggistici nazionali (art. 136,
art. 142, parchi, UNESCO), ferrovie (fascia 30 m ex DPR 753/1980) e corsi
d'acqua. Produce l'elenco degli enti da interpellare — titolo richiesto,
riferimenti normativi, documentazione tipica, criticità note — un report
Markdown salvato accanto al progetto e, a scelta, i layer in mappa nel gruppo
"Screening <comune>" (confine, strade, vincoli, interferenze) con zoom
automatico sul comune. Un secondo screening sullo stesso comune sostituisce il
gruppo invece di duplicarlo.

La logica vive in `ftth_screening.py` (nessun import qgis/PyQt, testabile
fuori da QGIS come ftth_core) e la mappa infrastruttura→ente→procedimento in
`procedimenti.yaml`, knowledge base curata a mano e versionata. La confidenza
di ogni fonte è propagata fino al report: è una ricognizione, non una
certificazione — OSM non è autoritativo per le strade, SITAP è ricognitivo e i
vincoli ex art. 142 operano anche se non cartografati. Failover automatico tra
4 endpoint Overpass; gli errori di rete finiscono nel registro della scheda,
mai in un crash del pannello.

## Novità versione 0.78.5

**Default — "Su una tratta misura" parte su "dal km … al km …":** è la
dicitura che va nelle tavole, e il valore salvato dalle versioni precedenti
("inizio della tratta") la scavalcava a ogni apertura — era il motivo per cui
il campo continuava a ricevere un valore solo. Migrazione una tantum come per
la scheda Edifici: il vecchio valore salvato viene dimenticato una volta sola,
poi le scelte dell'utente tornano a essere ricordate.

**Novità — aggancio dei capi delle tratte ai pozzetti:** i capi delle tratte
di Infrastruttura coincidono con i pozzetti della rete. Nuovo selettore
"Pozzetti (aggancia i capi delle tratte)" nel punto 3: quando un capo cade su
un pozzetto entro la tolleranza di aggancio (default 1 unità), la sua
chilometrica viene misurata ESATTAMENTE nel punto del pozzetto — così il
valore scritto sulla tratta e quello scritto sul pozzetto sono identici, e
tratte consecutive che condividono un pozzetto ricevono lo stesso km sul capo
comune. Dove il capo non tocca nessun pozzetto la chilometrica si calcola come
sempre sul corridoio. Il log dichiara quanti capi sono stati agganciati, tratta
per tratta.

**Interfaccia — i layer della scheda Chilometriche sono preimpostati
all'apertura:** cippi ('Cippi_Chilometrici'), target ('03 INFRASTRUTTURE'),
pozzetti ('02_POZZETTO') e linea di riferimento (il primo presente fra
'Stradario Provincia Italia', 'ANAS_Italia', 'Stradario', 'Rete stradale'),
con la solita regola: il nome atteso ha la precedenza quando il layer esiste
nel progetto.

## Novità versione 0.78.4

**Novità — misura "dal km … al km …" per le tratte (scheda Chilometriche):**
quarta voce nel menù "Su una tratta misura": scrive nell'attributo il testo
esteso con inizio e fine della tratta, es. "dal km 17+100 al km 17+145".
L'inizio è sempre il capo con la chilometrica minore — il verso di crescita
della strada — a prescindere dal verso in cui la polilinea è stata disegnata.
Pensata per le Infrastrutture, dove la dicitura entra così com'è nelle tavole
e nelle relazioni per l'ente.

**Fix — lunghezza del campo chilometrica:** il campo testo creato dal punto 0
passa da 20 a 40 caratteri, perché "dal km 999+999 al km 999+999" (30) non ci
stava e il provider avrebbe troncato in silenzio. Sui campi ESISTENTI creati
corti dalle versioni precedenti il calcolo ora avvisa nel log — con le misure
lunghe (intervallo e testo esteso) — indicando di ricreare il campo.

## Novità versione 0.78.3

**Novità — filtro sulla quota d'area in carreggiata (nuovo campo nel punto 2,
default 50%).** L'attraversamento dice che un bordo taglia l'edificio, ma non
quanto dell'edificio sta sulla strada: un edificio a filo carreggiata, tagliato
appena da un bordo, veniva selezionato come uno che ci sta in mezzo. Ora un
edificio preso dall'attraversamento o dal corridoio viene tenuto solo se almeno
la quota impostata della sua AREA sta fra i bordi.

Poiché coi bordi la carreggiata non esiste come poligono, la quota si stima
campionando una griglia di punti dentro l'edificio e verificando per ciascuno
se sta fra due bordi (versione puntuale del test del corridoio). Sui dati veri
della Valle d'Aosta la distribuzione delle quote è bimodale — 257 edifici sotto
il 25% (tagliati appena, i falsi positivi lamentati), 100 sopra il 75% (davvero
in mezzo alla strada) — quindi la soglia al 50% separa i due gruppi nella valle
naturale: dei 417 presi prima ne restano 127, e il log dichiara quanti sono
stati scartati dal filtro. Con 0 il filtro è spento e il comportamento torna
quello della 0.78.2. Il valore vale solo nel flusso coi bordi (test del
corridoio attivo): con gli assi la carreggiata fra i bordi non esiste e la
quota non sarebbe stimabile.

La diagnostica "Perché questo edificio?" riporta la quota stimata e il minimo
richiesto, così un verdetto "tenuto dal filtro area" è spiegato per intero.

## Novità versione 0.78.2

**La scheda "Edifici in carreggiata" ora funziona con i soli default: si
sceglie la regione e si preme Analizza.** Tre interventi:

**Default — criterio attraversamento + test del corridoio accesi di
fabbrica.** Il flusso di lavoro reale è il DBSN, dove il livello strade del
gruppo regione contiene i BORDI della carreggiata: con i vecchi default
(buffer + corridoio spento) l'analisi trovava 2 edifici su 20.871. Chi lavora
su un livello di assi può sempre tornare al buffer dal punto 2.

**Fix — rimosso il preset "Strade DBSN" del selettore "Usa invece questo
livello strade".** Introdotto nella 0.77, riempiva il selettore a ogni
apertura e così SCAVALCAVA il livello giusto riconosciuto dentro il gruppo
della regione ('DBSN Strade (carreggiata reale)'): l'analisi girava su un
layer sbagliato qualunque regione si scegliesse — era la causa dei "sempre 9
edifici" a prescindere dalle impostazioni. Vuoto è il default corretto:
significa "usa il livello del gruppo della regione selezionata".

**Novità — migrazione una tantum delle impostazioni memorizzate.** Il pannello
ricorda i valori fra le sessioni, quindi i nuovi default non basterebbero: chi
ha usato le versioni precedenti ha in memoria criterio=buffer e
corridoio=spento, che tornerebbero a ogni apertura. Alla prima apertura della
0.78.2 quei due valori vengono dimenticati (solo quelli, una volta sola); da
lì in poi le scelte dell'utente tornano a essere ricordate come sempre.

## Novità versione 0.78.1

**Fix — "Edifici in carreggiata" su 'DBSN Strade (carreggiata reale)' trovava
una manciata di edifici su migliaia (misurato: 2 su 20.871 in Valle d'Aosta).**
Tre cause concatenate, verificate sui dati veri:

1. **Il preset era il criterio sbagliato per quel livello.** Il buffer da 3 m
   col contenimento è tarato sugli ASSI stradali; su un livello che contiene i
   BORDI della carreggiata l'area del buffer copre solo una fascetta attorno a
   ciascun bordo e la parte centrale della strada resta scoperta: quasi nessun
   edificio risulta "contenuto". Ora, quando il nome del livello dichiara i
   bordi (contiene "carreggiata", "bordi" o "limiti"), l'analisi lo riconosce e
   propone di passare ad attraversamento + test del corridoio — la combinazione
   costruita apposta per quei livelli. Con essa gli edifici trovati passano da
   2 a 417.

2. **Il test del corridoio scartava il bordo opposto quando stava nella stessa
   feature del bordo vicino.** Le due parallele di una strada possono essere
   parti della stessa polilinea: il test escludeva per intero la feature del
   bordo più vicino, quindi non trovava mai il bordo opposto e l'edificio
   sfuggiva — è il caso dell'edificio grigio accanto a quello giallo segnalato
   nella verifica su mappa. Poiché il raggio parte dal centro dell'edificio e
   va dalla parte OPPOSTA al punto più vicino, un'intersezione con la stessa
   feature è per forza un altro tratto di linea: ora viene contata.

3. **Il test del corridoio non girava affatto se l'edificio non toccava
   nessun bordo col proprio rettangolo di ingombro:** un `continue` anticipato
   saltava tutto. Ma un edificio in mezzo a una carreggiata larga, lontano da
   entrambi i bordi, è esattamente il caso che il corridoio deve prendere. Ora
   col criterio dell'attraversamento il corridoio gira anche a candidati vuoti.

Il verdetto sul singolo edificio è stato estratto in un metodo statico
(`_verdetto_edificio`) senza stato del pannello: la stessa identica logica gira
nell'analisi, nella diagnostica e nei test fuori QGIS, quindi non può più
divergere fra i tre punti.

## Novità versione 0.78

**Struttura — la logica di puro calcolo vive ora in `ftth_core.py`:** parser e
formattatore delle chilometriche, fusione degli intervalli del retino,
trasformazione di similitudine dell'allineamento, arrotondamento all'italiana
delle misure e union-find della ricucitura corridoi. Il modulo non importa
niente da QGIS né da Qt: si esegue e si testa con un normale interprete
Python. Il dialogo delega a queste funzioni, quindi il comportamento è
identico; cambia solo dove il codice abita.

**Novità — test automatici in `tests/test_core.py`:** 32 casi che fissano i
comportamenti conquistati nelle versioni passate — i prefissi dei cippi che
mandavano in errore il parser (v0.54), la continuità del retino (v0.66),
l'arrotondamento 8,5 → 9 delle misure in tavola, i casi degeneri della
trasformazione. Girano senza QGIS: `python -m unittest discover tests`.
Ogni regressione futura su questa logica viene catturata prima del rilascio,
non sui dati veri.

**Fix — le eccezioni non fatali non spariscono più in silenzio:** nove punti
in cui un errore veniva ingoiato con `except: pass` (salvataggio impostazioni,
preset dei layer, personalizzazione del retino, rimozione layer) ora lasciano
una riga di avviso nel pannello "Log dei messaggi" di QGIS, scheda
"FTTH Permessi". Il comportamento non cambia — l'operazione prosegue come
prima — ma un malfunzionamento diventa diagnosticabile. Restano muti solo i
ripieghi per-feature deliberati, dove il fallback È il comportamento.

**Fix — guardia sul doppio contesto della scheda Esportazione:** le due copie
della scheda (Comune e Altri Enti) condividono la logica scambiando il set di
widget attivo. Se un widget nuovo viene aggiunto alla scheda ma dimenticato
nell'elenco `_ATTR_CONSEGNA`, le due copie lo condividerebbero in silenzio,
mescolando le impostazioni dei due rami: ora il caso viene rilevato e
segnalato con un errore esplicito al primo click, durante lo sviluppo.

**Documentazione — README e changelog separati:** il README è ora la pagina
di presentazione (cos'è, come si installa, come è organizzato), il changelog
completo — questa cronologia — sta in CHANGELOG.md.

## Novità versione 0.77

**Interfaccia — la scheda "Edifici in carreggiata" si apre già sulla
configurazione collaudata:** criterio del contenimento nella carreggiata
ricostruita col buffer, larghezza 3 m, attraversamento minimo 0 m, larghezza
massima di carreggiata 14 m, unione dei tronchi adiacenti attiva, test del
corridoio spento. Sono i valori con cui la scheda è stata messa a punto sui dati
veri, e trovarli già impostati evita di doverli ricostruire a mano ad ogni nuova
installazione. Restano tutti modificabili, e da quel momento il pannello ricorda
le impostazioni di chi lavora come per ogni altra scheda.

**Interfaccia — il livello strade viene preimpostato** cercando nel progetto,
nell'ordine, "Strade DBSN", "CTR_Strade_OSM" e "Strade". I combo dei layer non
si salvano fra le sessioni, perché puntano a un progetto specifico, quindi il
nome atteso va riproposto all'apertura. A differenza degli altri preset qui si
interviene solo se il combo è ancora vuoto: il campo ammette la scelta vuota,
quindi vuoto significa davvero "non ho scelto", e sovrascrivere una scelta fatta
a mano sarebbe peggio che non preimpostare nulla.

## Novità versione 0.76

**Fix — il test del corridoio ora è spento di partenza.** Serve solo quando il
livello strade contiene i limiti della carreggiata. Se le linee sono gli assi —
il caso normale — il test cerca "un'altra linea dalla parte opposta" e la trova
nella strada parallela vicina: in un centro abitato dichiarerebbe in carreggiata
gli edifici che stanno fra due strade, a decine.

L'equivoco è facile e vale la pena scriverlo: una simbologia a doppio tratto
(una linea scura spessa disegnata sotto e una chiara più sottile sopra, la
tecnica del *casing*) fa sembrare due bordi paralleli quella che è una sola
geometria. Si riconosce dal file di stile, dove ogni simbolo ha due strati
SimpleLine sullo stesso tracciato con `symbollevels` attivo, oppure cliccando su
una delle due linee con lo strumento Informazioni: se risponde una feature sola,
sono assi.

Quando il test è attivo il log ora lo dichiara e ricorda di controllare il
conteggio "racchiusi fra due bordi" prima di eliminare.

## Novità versione 0.75

**Novità — test del corridoio, per i livelli che contengono i BORDI della
carreggiata:** nel DBSN il livello delle strade non contiene gli assi ma i limiti
della carreggiata, due linee parallele per ogni strada con in mezzo la sede
stradale, che però non esiste come geometria. Il criterio dell'attraversamento
prende gli edifici che toccano un limite, ma lascerebbe lì un edificio minore
piccolo che sta tutto dentro la carreggiata senza arrivare a toccarne i bordi.

Il test guarda il bordo più vicino al centro dell'edificio e cerca un altro bordo
dalla parte opposta, lungo la perpendicolare, entro una larghezza massima di
carreggiata impostabile. Un edificio appena fuori strada ha un bordo da un lato e
niente dall'altro, quindi non scatta; uno in mezzo a due strade parallele lontane
non scatta perché il raggio non ci arriva. Su un banco di prova con sei casi —
compreso il centro dell'edificio esattamente sopra un bordo — il metodo estratto
dal sorgente dà sei verdetti corretti su sei. Il conteggio nel log distingue
quanti edifici sono stati riconosciuti solo grazie a questo test.

**Fix — il contenimento totale penalizzava gli edifici grandi:** a parità di
posizione sulla strada, un edificio sottile risultava contenuto nel buffer mentre
uno più grande, attraversato dalla stessa linea, ne sporgeva e veniva lasciato lì.
Non era una questione di distanza ma della forma del criterio, ed è la ragione
per cui l'attraversamento è ora il predefinito sui livelli lineari.

## Novità versione 0.74

**Novità — nuovo criterio "l'asse stradale attraversa l'edificio", predefinito
sui livelli lineari:** se l'asse della strada passa dentro un edificio, quello è
in mezzo alla strada, e non serve sapere quanto è larga la carreggiata. La
larghezza era il punto debole del buffer: sulla stessa regione convivono strade
da quattro metri e da dodici, mentre il buffer ne usa una sola. Su un banco di
prova con sei casi tipici, il buffer sbaglia due volte con qualunque valore —
troppo stretto perde gli edifici laterali delle strade larghe, troppo largo
prende quelli a bordo delle strade strette — mentre l'attraversamento sbaglia
una volta sola.

Soprattutto, l'attraversamento sbaglia **solo per difetto**: può lasciare lì un
edificio che sta in carreggiata di lato, ma non dichiara mai dentro qualcosa che
sta fuori. Trattandosi di una cancellazione è l'errore preferibile, perché ciò
che sfugge si prende al giro dopo mentre ciò che viene cancellato per sbaglio va
ripescato dal file. Il criterio del buffer resta disponibile nel punto 2 per chi
lo preferisce, e sui livelli poligonali il test è sempre il contenimento nel
poligono.

Il parametro "attraversamento minimo" evita che il criterio scatti quando l'asse
sfiora appena un angolo dell'edificio: con zero basterebbe un contatto puntuale.
Con questo criterio l'unione dei tronchi adiacenti non viene calcolata, perché un
asse che passa dentro l'edificio lo attraversa comunque, a prescindere da come i
tronchi sono spezzati.

**Interfaccia — il log e la diagnostica dichiarano il criterio in uso** e ne
adattano le colonne: con l'attraversamento la misura utile è la lunghezza del
tratto di asse interno all'edificio, non la percentuale di area sovrapposta.

## Novità versione 0.73

**Novità — il livello strade si può scegliere a mano:** nuovo selettore nel
punto 1 della scheda "Edifici in carreggiata". Lasciandolo vuoto vale il
riconoscimento per nome dentro il gruppo della regione, come prima;
impostandolo, quel livello viene usato per tutte le regioni. Serve quando le
strade stanno in un livello unico fuori dai gruppi regione, e quando nel gruppo
esiste più di un livello il cui nome contiene la chiave di ricerca: il primo che
il riconoscimento incontra non è per forza quello giusto, e il selettore è
l'unico modo per dirlo con certezza. Il log dichiara sempre quale livello è
stato usato e da dove viene.

**Fix — avviso sul buffer applicato a linee che non sono assi stradali:**
allargare una linea produce area sui due lati. Va bene se le linee sono gli assi;
se invece sono i limiti della carreggiata — due parallele per ogni strada, come
nel DBSN — il risultato è sbagliato in entrambe le direzioni: gli edifici a filo
strada finiscono dentro il buffer del limite pur stando fuori, e quelli davvero
in mezzo alla carreggiata cadono nella fascia scoperta fra i due buffer e
sfuggono. Su un banco di prova con quattro casi tipici, tre verdetti su quattro
risultano sbagliati. L'avviso ora compare nel log dell'analisi, nella
diagnostica e nel suggerimento del campo larghezza, con l'indicazione di usare
un livello poligonale.

**Novità — pulsante "Perché questo edificio?":** rifà il ragionamento su un solo
elemento selezionato in mappa e ne riporta i passaggi — quali tronchi di strada
ha considerato, quanto lo sovrappongono in percentuale, la distanza, l'esito
dell'unione e il verdetto con la sua ragione. Quando l'edificio viene tenuto
riporta anche la sovrapposizione massima raggiunta: se sfiora il cento per cento
il problema è il criterio del contenimento totale, se è bassa l'edificio è
davvero fuori. È lo strumento da usare quando il risultato non torna, al posto
di cambiare i parametri a tentativi — stesso ruolo del pulsante Diagnostica
delle chilometriche.

## Novità versione 0.72

**Novità — nuovo ramo "Cartografia di base":** raccoglie gli interventi sul dato
di partenza (CTR, DBSN, stradari), distinti da quelli sui dati di progetto.
"Allinea cartografia" si è spostata qui dal ramo Comune, dove stava per comodità
ma non c'entrava con la pratica comunale, e si chiama ora solo "Allinea". Il ramo
è in fondo, dopo Altri Enti, per non spostare l'ordine delle schede già note.

**Novità — scheda "Edifici in carreggiata":** nei dati DBSN capita che geometrie
di *Edifici minori* cadano dentro il poligono della carreggiata: sono errori del
dato di base, non edifici. La scheda percorre l'albero dei livelli, riconosce i
gruppi che contengono sia le strade sia gli edifici minori — una riga per
regione — e lavora una regione alla volta. L'analisi trova e seleziona in mappa
senza modificare niente; il secondo pulsante scrive gli elementi in un
GeoPackage e solo dopo aver verificato che il salvataggio sia completo li
cancella; il terzo li rimette dentro rileggendoli dal file.

L'abbinamento fra strade ed edifici avviene sui **figli diretti** dello stesso
gruppo e non sull'intera discendenza: i gruppi regione sono annidati dentro un
gruppo padre, e con una ricerca ricorsiva il padre sarebbe risultato lavorabile
a sua volta, facendo confrontare gli edifici di una regione con le strade di
un'altra.

Il criterio è il **contenimento totale**: un edificio che sporge anche di poco
dalla carreggiata non viene toccato, perché a bordo strada gli edifici veri
toccano quasi sempre il poligono. La carreggiata però è spezzata in tronchi, e
un edificio a cavallo di due tronchi adiacenti non è contenuto in nessuno dei
due preso singolarmente: per questo, quando nessun tronco singolo lo contiene,
i tronchi vicini vengono uniti e il test si ripete sull'unione. È lo stesso
motivo per cui le chilometriche misurano sui corridoi ricuciti e non sulle
singole tratte. L'unione si calcola solo per i casi dubbi, non a monte su tutta
la rete regionale. Il log dice quanti edifici sono stati riconosciuti soltanto
grazie a lei.

Se il livello delle strade è lineare non esiste un poligono in cui essere
contenuti: in quel caso la carreggiata viene ricostruita allargando l'asse della
larghezza indicata, e il log dichiara che il contenimento vale su una carreggiata
stimata. Poiché una larghezza in metri non ha senso in coordinate geografiche —
e il DBSN è distribuito così — in quel caso i confronti passano nel CRS di
progetto, se metrico; se non lo è, l'analisi si ferma con l'indicazione di cosa
cambiare.

**Novità — l'analisi non blocca l'interfaccia:** barra di avanzamento con il
conteggio degli elementi esaminati e pulsante Interrompi che ferma davvero. Il
tempo dipende dalla regione e non dalla dimensione del progetto: le strade
vengono lette ristrette all'estensione degli edifici di quel gruppo, così anche
indicando per sbaglio un livello stradale nazionale non si legge l'Italia intera
per confrontarla con una regione sola. Gli attributi non vengono letti affatto,
né sulle strade né sugli edifici: al confronto geometrico non servono e sono la
parte pesante della lettura. La cancellazione avviene con una sola chiamata per
tutti gli identificativi e un solo commit.

**Fix — la chiusura del pannello durante l'analisi non manda più in crash QGIS:**
il ciclo chiama processEvents() per tenere viva l'interfaccia, e durante quelle
chiamate Qt consegnava anche la richiesta di chiusura; il dialogo veniva
distrutto mentre il ciclo stava ancora scrivendo su barra e log, cioè su oggetti
C++ già liberati — un errore che nessun try/except Python intercetta. Ora la
chiusura viene rifiutata e tradotta in una richiesta di interruzione.

**Interfaccia — il file degli scarti è un GeoPackage e non uno Shapefile:**
conserva i nomi di campo per intero, mentre gli attributi DBSN superano i dieci
caratteri e su DBF verrebbero troncati, rendendo impreciso il ripristino. Un
livello per regione dentro lo stesso file: la cancellazione di una regione
riscrive solo il proprio livello e lascia intatti gli altri.

## Novità versione 0.71

**Interfaccia — all'apertura tutte le sezioni sono chiuse:** ogni scheda si
presenta come un elenco di titoli, si apre quello che serve e il resto resta
fuori dai piedi. Il salvataggio automatico dello stato di QgsCollapsibleGroupBox
è stato disattivato di proposito: quel widget memorizza in QgsSettings se il
riquadro era aperto e lo ripristina quando viene mostrato, sovrascrivendo la
chiusura impostata alla costruzione, quindi i riquadri lasciati aperti nella
sessione precedente si sarebbero riaperti da soli. Nuovo pulsante "Chiudi tutte
le sezioni" in fondo al pannello, per tornare alla vista d'insieme senza
chiudere e riaprire.

**Interfaccia — scheda di installazione riscritta** con il testo definitivo:
una riga di descrizione, tre righe sul flusso di lavoro e il rimando alla guida
contestuale e al README.

## Novità versione 0.70

**Novità — scheda "Suolo comunale" nel ramo Altri Enti:** individua gli elementi
di progetto che non ricadono sugli stradari di competenza dell'ente (SP, ANAS,
altro) e li separa in un gruppo di livelli a sé, che si spegne quando si stampa
la tavola per quell'ente. Lavora in due passi: prima li seleziona in mappa e
inquadra la zona, perché li si possa controllare a vista e ritoccare la
tolleranza; solo dopo la conferma li sposta. Lo spostamento non cancella e non
duplica geometrie: scrive un campo SUOLO che distingue i due casi, crea un
gruppo di livelli filtrati sul valore COMUNALE e applica agli originali il
filtro complementare. I livelli del gruppo nuovo sono cloni di quelli originali,
quindi conservano sorgente e simbologia — a vedersi sono identici. Un terzo
pulsante annulla tutto rimuovendo il gruppo e azzerando i filtri. Sui livelli
temporanei, dove il filtro non è applicabile, le feature vengono copiate e
l'originale resta intero: il log lo segnala.

**Interfaccia — i riquadri di log non occupano più spazio da vuoti:** erano
undici rettangoli bianchi che nelle schede più cariche allontanavano i controlli
fra loro. Ora sono richiudibili, partono chiusi e si aprono da sé quando c'è
qualcosa da leggere.

**Interfaccia — i riquadri di sola impostazione partono chiusi:** creazione del
campo chilometrica, filtri e grafica delle etichette, unione PDF. Le azioni di
ogni giorno restano aperte. Un primo tentativo chiudeva per posizione — primo
riquadro aperto, gli altri chiusi — ma nelle Chilometriche avrebbe chiuso proprio
il riquadro del calcolo.

**Interfaccia — scheda di installazione sintetizzata:** descrizione e testo
"about" in metadata.txt erano un paragrafo unico di circa 1100 caratteri; ora
sono una riga e cinque righe divise per ramo.

## Novità versione 0.69

**Interfaccia — impostazioni ricordate fra le sessioni:** il pannello memorizza
i valori dei campi alla chiusura e li rimette all'apertura, così non si
riparte ogni volta dai valori di fabbrica. I combo dei layer sono esclusi di
proposito, perché puntano a layer di un progetto specifico e ripristinarli su
un altro progetto darebbe riferimenti sbagliati: per quelli restano i preset
automatici. Le due copie della scheda Esportazione (Comune e Altri Enti) hanno
memorie separate, quindi puoi tenere impostazioni diverse nei due rami. Un
pulsante "Ripristina i valori iniziali" in fondo al pannello riporta tutto ai
predefiniti.

**Interfaccia — riquadri comprimibili:** ogni riquadro si chiude con un clic
sul titolo e QGIS ne ricorda lo stato. Con sette schede e ventisette riquadri
la finestra era diventata un muro di controlli.

**Interfaccia — pulsante Guida in ogni scheda:** apre una finestra non modale
con la spiegazione di quella parte del plugin, il flusso passo per passo e le
cause tipiche dei problemi. Si può lavorare con la guida aperta accanto.

**Interfaccia — versione nel titolo della finestra:** il pannello si intitola
ora "Gestione Permessi FTTH — v0.69". Serve a rispondere a colpo d'occhio alla
domanda "sto usando la versione nuova?", che durante lo sviluppo ha fatto
perdere tempo più di una volta.

**Aspetto — nuova icona nei colori beexact:** fondo blu #011e5a, chevron
arancione #ff7e01 e tre fibre bianche che convergono. Disegnata per essere
leggibile a 24 px, che è la dimensione con cui QGIS disegna la barra degli
strumenti: il primo tentativo aveva anche un punto luminoso nel mezzo, ma a
quella scala si impastava col chevron.

**Default — evidenza delle strade:** all'apertura sono ora preselezionati
tinta unita, tratte intere, corpo del nome strada a 16 pt.

## Novità versione 0.68

**Interfaccia — riquadro dell'evidenza riorganizzato:** era un elenco di
tredici controlli in fila, in fondo al quarto riquadro di una scheda lunga, e
la spunta del nome della strada risultava introvabile. Ora è diviso in due
sezioni, "Quali strade" e "Aspetto in stampa", con le opzioni di resa
raggruppate dove chi le cerca va a guardare.

## Novità versione 0.67

**Novità — nome della strada sull'evidenza, una volta per strada:** il layer di
evidenza contiene ora una feature per strada invece di una sola geometria
dissolta, ed è questo che permette di scrivere il nome una sola volta ciascuna.
Le tre impostazioni che evitano la ripetizione sono `labelPerPart = False` —
una scritta sola anche quando la fascia di una strada è spezzata in più parti —
nessuna distanza di ripetizione, che è ciò che nello stradario produce le sigle
minute ogni pochi centimetri di carta, e il piazzamento libero, che ruota il
testo per farlo stare dentro la fascia. Corpo regolabile, grassetto con alone
bianco, priorità alta perché la scritta non venga scartata per collisione con
le etichette dei pozzetti.

**Novità — spunta per spegnere le etichette dello stradario:** le sigle
ripetute lungo la strada vengono dall'etichettatura del layer stradario, non
dall'evidenza. Spenta per default, perché modifica un layer che l'utente non ha
chiesto di toccare; quando la si usa il log dice cosa è stato fatto e come
annullarlo.

**Fix — lunghezza nell'attributo:** era ricavata dall'area della fascia divisa
per la larghezza, ora è misurata direttamente sulla porzione di corridoio.

## Novità versione 0.66

**Fix — continuità del retino:** l'evidenza copriva le singole tratte toccate,
quindi dove una tratta intermedia non veniva sfiorata si apriva un buco. Ora lo
stradario viene ricucito in corridoi continui, su ciascuno si calcolano gli
intervalli di progressiva interessati e i vuoti sotto soglia vengono colmati.
Su scavi intervallati lungo due chilometri si passa da tre frammenti separati a
un tratto unico. Nuovi parametri "Colma i vuoti fino a" e "Salda le fasce che
si sfiorano", che con una chiusura morfologica chiude la fessura agli incroci —
dove due strade sono due corridoi distinti — con raggio limitato a metà
larghezza per non fondere strade parallele vicine.

**Fix — la causa vera dei buchi era la tolleranza:** "Distanza max elemento →
tratta" era a 2 m, ma lo stradario è l'asse e gli scavi corrono a bordo strada:
su una carreggiata di 8-10 m il bordo dista 4-5 m dall'asse, quindi quei tratti
venivano scartati in silenzio. Default portato a 8 m, e il log elenca ora
quanti elementi sono rimasti fuori e a che distanza stanno.

**Novità — stile dell'evidenza personalizzabile:** selettore di colore, quattro
stili (retino diagonale, retino incrociato, retino con bordo, tinta unita),
passo, spessore e angolo del retino. Passo e spessore sono in millimetri sul
foglio, quindi restano identici in stampa a qualunque scala.

## Novità versione 0.65

**Fix — crash di QGIS premendo "Evidenzia le strade interessate":** per mettere
il layer in fondo all'elenco era stato usato `insertLayer(-1, layer)`, con
l'idea che -1 significasse "in coda" come in Python. Quell'indice finisce in
`QList::insert()`, che pretende `0 <= indice <= numero di figli`: con -1 Qt
scrive prima dell'inizio dell'array e il processo muore di corruzione
dell'heap. È un crash nativo, quindi il try/except intorno non poteva
intercettarlo. Il metodo corretto è `addLayer()`, che accoda.

**Fix — secondo crash latente nel retino:** a `setSubSymbol()` veniva passato lo
stesso oggetto ottenuto da `subSymbol()`. Quel metodo distrugge il sotto-simbolo
corrente e prende possesso di quello nuovo, quindi rigirargli lo stesso
puntatore lo fa usare dopo la liberazione. Ora si passa un clone.

**Perf — lo stradario non viene più letto per intero:** l'evidenza scorreva
tutte le feature del layer di riferimento, che su un grafo provinciale sono
centinaia di migliaia, e se il layer è servito via WFS anche altrettante righe
dalla rete a ogni pressione del pulsante. Ora si legge solo l'intorno degli
elementi di progetto: su uno stradario di prova da 4200 tratte ne legge 17, con
risultato identico. Avviso nel log se il layer è remoto, tetto di sicurezza a
100.000 tratte, cursore di attesa durante l'unione delle fasce.

## Novità versione 0.64

**Fix — l'evidenza copriva gli elementi di progetto invece delle strade:** il
layer di riferimento veniva preso dal campo "Stradario" della scheda
Esportazione, che è opzionale e senza valore preimpostato; se lì c'era un layer
lineare qualsiasi — Infrastrutture è lineare — il retino veniva costruito su
quello, senza che nulla lo segnalasse. L'evidenza ha ora un proprio selettore
con preset, accetta layer lineari e poligonali, rifiuta con un messaggio
esplicito i layer di progetto e dichiara nel log quale stradario ha usato.

## Novità versione 0.63

**Novità — stile del testo delle etichette:** menù "Leggibilità sullo sfondo"
con quattro varianti — solo testo, alone bianco, riquadro bianco
semitrasparente, riquadro con ombra sottile. Su una CTR il testo nero cade su un
intreccio di linee nere e con il solo alone il tratteggio continua a leggersi
dentro le lettere: il riquadro semitrasparente stacca il testo da qualunque
sfondo restando discreto. Ombra tenuta breve — 0,7 mm a 135°, opacità 45%,
posizionata sotto il riquadro e non dietro le lettere. Selettore del carattere
di sistema e grassetto. La costruzione di riquadro e ombra è isolata con una
propria gestione degli errori: se una costante manca in quella versione di QGIS
si perde solo il riquadro, non tutta l'etichettatura.

## Novità versione 0.62

**Novità — chilometrica per singolo layer nelle etichette:** una spunta per
riga nella griglia, spenta per Infrastrutture, dove ripetere la chilometrica
era una duplicazione. Conseguenza utile: le tratte senza chilometrica calcolata
non vengono più saltate.

**Fix — l'etichettatura esistente non viene più cancellata:** QGIS ammette una
sola etichettatura per layer e `setLabeling()` sostituisce quella che c'era.
Con la nuova spunta "Conserva l'etichettatura già presente" quella esistente
viene convertita in regola e la nuova si aggiunge come seconda regola, che è
l'unico modo di averne due contemporaneamente.

## Novità versione 0.61

**Fix — punto interrogativo nelle etichette:** il separatore predefinito era un
trattino tipografico (U+2013), che uno shapefile senza file .cpg — quindi in
codepage ANSI — non sa scrivere e sostituisce con "?". Ora i separatori sono
ASCII e prima di scrivere il testo viene provato nella codifica del layer, con i
caratteri tipografici ricondotti all'equivalente ASCII.

**Novità — etichette in mappa con la grafica delle tavole:** testo nero
multiriga allineato a sinistra, scostato dall'elemento e collegato da una linea
di richiamo, con corpo e distanza regolabili. Spunta per mettere la chilometrica
in fondo all'etichetta, come nelle tavole.

**Novità — evidenza delle strade interessate:** nuovo riquadro nella scheda
Esportazione che copre con una fascia le tratte dello stradario su cui ricadono
gli elementi di progetto. Le fasce vengono dissolte, altrimenti con la
trasparenza le sovrapposizioni fra tratte adiacenti scurirebbero il colore.

## Novità versione 0.60

**Fix — errori di conteggio delle chilometriche fra elementi diversi:** tre
cause distinte, tutte a monte del calcolo. L'area entro cui veniva letto lo
stradario dipendeva dalla selezione, quindi il corridoio veniva ricucito
diverso a ogni lancio e lo stesso pozzetto elaborato con due selezioni diverse
otteneva due valori: ora l'area si calcola sull'estensione dei layer.
`mergeLines()` unisce solo le linee che condividono un vertice esatto, mentre
negli stradari i tronchi si chiudono a pochi centimetri e agli incroci la
strada viene tagliata: c'è ora una tolleranza di ricucitura che segue la
prosecuzione più diritta, con un limite di 75° oltre il quale non aggancia, per
non svoltare nella laterale. Sulle tratte veniva misurato il punto medio, per
cui due scavi consecutivi ricevevano valori distanti mentre il primo finiva
dove il secondo cominciava: ora si misura il capo con la chilometrica minore,
con la possibilità di scrivere l'intervallo completo.

**Novità — punto 0 dichiarato e controverifica:** il log apre indicando quale
cippo è il riferimento, avvisa se i corridoi in uso sono più di uno — caso in
cui gli elementi non sono confrontabili fra loro — e per ogni altro cippo
confronta il valore dichiarato con quello che la progressione prevede per la sua
posizione.

## Novità versione 0.59

**Fix — le chilometriche non erano progressive:** l'interpolazione fra i cippi
riscalava le distanze sui valori dichiarati, quindi un cippo mal posizionato
comprimeva o dilatava tutto il tratto. Ora il conteggio parte dal cippo con la
chilometrica più bassa e somma la distanza reale percorsa lungo la strada, un
metro per un metro, nel verso in cui i chilometri crescono: i valori sono
monotoni e confrontabili. Su tre cippi reali un pozzetto a 500 m dal primo dava
17+444 e ora dà 17+600. L'interpolazione resta disponibile come terza opzione.

## Novità versione 0.58

**Interfaccia — aiuto contestuale richiudibile:** ogni scheda si apriva con un
paragrafo giustificato di otto-dieci righe che spingeva i controlli sotto la
piega. Ora resta visibile la prima frase, con un "dettagli" che apre il resto.

**Interfaccia — esito inline invece dei popup di conferma:** nelle schede
Chilometriche ed Etichette il risultato è una riga in grassetto sopra il log.
Gli errori restano popup.

**Interfaccia — la finestra ricorda dimensione e scheda aperta**, i log usano un
carattere a larghezza fissa, la scheda Etichette è divisa in passi numerati.

## Novità versione 0.57

**Fix — dicitura dello scavo:** rimosso "IN" dalla dicitura predefinita, che con
valori aggettivali dava "SCAVO IN TRADIZIONALE". Nuova dicitura dedicata per le
tratte aeree, dove "SCAVO AEREA" non vuol dire niente, e filtro per i soli
elementi con STATO = 'Nuovo', dato che nei layer di progetto convivono le
tratte in progetto e quelle esistenti.

## Novità versione 0.56

**Novità — riconoscimento del campo per contenuto:** i campi di origine delle
etichette si scelgono ora da un elenco invece di digitarne il nome, e
l'auto-riconoscimento guarda i valori contenuti prima del nome del campo — una
corrispondenza sul contenuto vale tre punti, una sul nome uno. Serve perché in
questo modello dati 'TIPOLOGIA' esiste ma può contenere Aerea/Interrata invece
della tecnica di scavo. Nuovo pulsante "Ispeziona i campi", che elenca ogni
campo con alcuni valori di esempio.

## Novità versione 0.55

**Novità — scheda Etichette:** compila un campo di testo su Armadio, Pozzetto e
Infrastrutture con la dicitura di posa, componendola dalla chilometrica più la
lavorazione. Il campo viene creato se manca. Diciture e campi di origine sono
modificabili dall'interfaccia. La lunghezza ripiega sul campo alternativo del
modello dati e infine sulla lunghezza geometrica reale, così l'etichetta non
resta senza metri per un campo non ancora calcolato. Anteprima prima di
scrivere.

## Novità versione 0.54

**Novità — parser dei cippi più tollerante:** il prefisso descrittivo con cui i
cippi sono normalmente etichettati ("KM 17+100", "PK 17+100", "progr. 17+100")
mandava il parser in errore e i cippi venivano scartati in silenzio, quindi il
calcolo non partiva affatto. Ora il prefisso viene ignorato e il formato del
valore si dichiara da un menù, compresa la forma invertita metri+km.

**Novità — controllo di coerenza dei cippi:** se fra due cippi la chilometrica
non cresce di circa un metro per metro percorso, il log lo segnala invece di
scrivere valori plausibili all'apparenza e completamente sbagliati.

## Novità versione 0.53

**Fix — calcolo delle chilometriche su stradari spezzettati:** la progressiva
veniva misurata sulla singola feature del riferimento e si pretendeva che cippo
ed elemento ricadessero sulla stessa; in uno stradario, spezzato in centinaia
di tratte, due punti a cinquanta metri stanno quasi sempre su tratte diverse,
quindi veniva scartato tutto con "nessuna ancora sulla stessa linea". Ora le
tratte contigue vengono ricucite in corridoi continui e la misura avviene lungo
quelli. Un cippo vicino a un bivio serve tutti i corridoi che ha entro
tolleranza, non solo il più vicino. Nuovo pulsante Diagnostica, che dice quanti
cippi sono stati letti e quali scartati, quanti corridoi ricuciti, quanti
elementi si agganciano e di quanto sono fuori tolleranza gli altri.

**Novità — campo dei cippi selezionabile** invece di essere cablato su
'Chilometrica', con preselezione automatica, e scrittura su più layer target in
un colpo.

## Novità versione 0.52

**Fix — creazione del campo 'Chilometrica' sugli shapefile:** il formato DBF
limita i nomi campo a dieci caratteri, quindi QGIS chiedeva 'Chilometrica' e
OGR restituiva 'Chilometri': il commit falliva con "il campo con indice 14 non
è uguale!" e faceva rollback. Il nome viene ora adattato al provider prima di
aggiungere il campo, e la ricerca del campo tollera nomi troncati e differenze
di maiuscole. Su GeoPackage e PostGIS il nome resta intero.

**Novità — scheda Esportazione anche nel ramo Altri Enti,** come copia
indipendente: layer, layout e liste PDF possono essere diversi dai due lati.

## Novità versione 0.51

**Perf — Stradario/Provinciali/ANAS ritagliati su ARLO AREA:** su
richiesta, Stradario, Provinciali e ANAS non vengono più letti per
intero (comuni shape a scala nazionale, es. Stradario Italia) ma solo
entro ARLO AREA (fusa, dalla scheda "Keyplan e tavole") allargata di
un margine impostabile (nuovo campo "Ritaglia Stradario/Provinciali/
ANAS a: ARLO AREA + margine", default 500 unità progetto). Il filtro è
un bbox lato provider (rapido anche su shapefile grandi grazie
all'indice .qix). Se ARLO AREA non è impostata, il log finale avvisa
che i layer sono stati letti per intero.

## Novità versione 0.50

**Fix — Punti di ripresa lentissimi (fino a 3 min):** la ricerca del
piede sullo Stradario re-interrogava il layer via bbox, con raggio
raddoppiato fino a 9 volte, PER OGNI candidato di OGNI tavola — su uno
Stradario grande (es. Stradario Italia) era il vero collo di
bottiglia. Ora l'indice spaziale su Stradario si costruisce UNA sola
volta, prima del ciclo sulle tavole, e ogni ricerca costa una
`nearestNeighbor()` sull'indice in RAM invece di una nuova scansione
del layer.

**Fix — rotazione dei coni sugli attraversamenti:** i punti di
attraversamento (Infrastruttura×Strada) sono per costruzione già
posizionati SULLA strada — proiettarli di nuovo sulla strada più
vicina ritornava il punto stesso: distanza zero, camera "sopra"
l'oggetto, rotazione indefinita. Ora, quando il soggetto giace già
sulla strada, la camera viene spostata della Distanza di ripresa
lungo la strada (resta sulla sua stessa linea) e l'inquadratura è
forzata perpendicolare alla strada — una vera foto di attraversamento
invece di un cono piazzato sul soggetto.

**Interfaccia — scheda "Punti di ripresa" unificata:** i campi Armadio
Ottico, Punto di Ripresa, Stradario, Sedime Pubblico, raggio e
distanze — prima in un blocco separato dal box "Coni per Tavola di
Inquadramento" pur essendo usati solo da quest'ultimo — sono ora
dentro lo stesso box, un'unica scheda con un solo scopo.

**Rinominata la scheda "Shape di consegna" in "Esportazione".**

## Novità versione 0.49

**Nuovo — Unisci PDF (Shape di consegna):** nuova sezione "Unisci PDF in un
ordine stabilito" sotto l'esportazione Atlante: elenco riordinabile
(↑/↓, Aggiungi, Rimuovi) che si autopopola con i PDF appena esportati,
nello stesso ordine; unisce i file scelti in un unico PDF. Richiede il
pacchetto Python 'pypdf' (fallback 'PyPDF2'); se assente, avvisa con le
istruzioni di installazione invece di fallire in silenzio.

**Fix — attivazione Atlante verificata davvero:** `setEnabled(True)` da
solo non garantiva il refresh delle feature coperte se il layer/filtro
di copertura era cambiato dopo l'ultima apertura del layout. Aggiunta
una chiamata esplicita a `updateFeatures()` dopo l'attivazione, e un
controllo che blocca l'esportazione con un messaggio chiaro se
l'Atlante risulta comunque a 0 elementi — così l'attivazione è
verificata, non solo presunta dal risultato dell'export.

**Fix — Punti di ripresa, coni ravvicinati/fuori criterio:**
1. La ricerca del piede sullo Stradario ignorava la tavola: poteva
   agganciarsi alla strada più vicina in assoluto anche se fuori
   tavola, per poi essere spinta sul bordo — posizionamento arbitrario,
   senza legame con una strada reale della tavola. Ora un segmento
   realmente dentro la tavola ha sempre priorità su uno fuori, anche se
   più lontano in linea d'aria.
2. Le soglie anti-duplicato erano troppo strette (0,5 m sul soggetto
   inquadrato, 0,10 m sulla posizione camera): bastavano pochi metri di
   scarto tra pool diversi (es. stesso incrocio digitalizzato
   leggermente diverso su Provinciale e su Stradario) per sfuggire al
   controllo e produrre coni ravvicinati puntati, di fatto, allo stesso
   oggetto. Alzate rispettivamente a 3 m e 1 m.

**Testi dell'interfaccia sintetizzati:** tutte le descrizioni delle
sezioni (regole di selezione, allinea cartografia, coni, keyplan,
consegna, esporta PDF) sono state accorciate, mantenendo il contenuto
tecnico.

## Novità versione 0.48

**Rimozioni (Seleziona elementi):** eliminate la Regola 4b (Accorcia
tratte fino al bordo edificio) e la Regola 6 (Verifica Civici senza
Edificio / Recupera Edifici da riferimento).

**Regola 5 — Sedime Pubblico da shape locale:** nuovo pulsante "1b)
Genera Sedime Pubblico da Stradario locale": stessa bufferizzazione della
generazione OSM (linee bufferizzate, poligoni presi come superficie
piena), stesso layer temporaneo risultante, ma leggendo un layer già
caricato in locale (es. uno Stradario Italia) invece di scaricare da OSM
— nessuna chiamata di rete. Resta anche il campo "Sedime già pronto" per
un poligono di sedime già finito da usare direttamente.

**Punti di ripresa:**
1. Eliminato il pulsante standalone "Genera coni davanti agli Armadi
   Ottici": la stessa cosa (con priorità assoluta) la fa già "Coni per
   Tavola di Inquadramento", che riusa Stradario/Sedime Pubblico/raggio
   di ricerca/distanza di riserva impostati in cima alla scheda.
2. Nuovo livello di priorità "attraversamenti Infrastrutture×Stradario":
   prima venivano individuati solo gli attraversamenti su Provinciale/
   ANAS, perdendo la maggioranza degli attraversamenti reali (su strade
   comunali generiche, mai classificate Provinciale/ANAS).
3. Ogni punto di ripresa calcolato viene ora sempre riportato dentro il
   perimetro della tavola se lo Stradario lo avesse spostato fuori.
4. Nuovo controllo anti-duplicato sul SOGGETTO inquadrato (non solo
   sulla posizione della camera): evita che due coni diversi puntino
   allo stesso oggetto.

**Fix esportazione PDF (Shape di consegna):** il messaggio di errore
mostrato anche per esportazioni riuscite ("errore nell'esportazione
codice (0, '')") era un bug del plugin, non un vero errore: l'overload
statico per l'esportazione Atlante restituisce una coppia (risultato,
messaggio), non il solo codice come le esportazioni normali — il
confronto sbagliato segnalava sempre errore anche a PDF scritto
correttamente. Corretto.

## Novità versione 0.47

**Nuova funzione — Recupera Edifici mancanti da un layer di riferimento
(Regola 6, Seleziona elementi):** per ogni Civico senza Edificio, cerca
nel layer di riferimento impostato (fonte-agnostico: footprint
Microsoft/Google scaricati per l'area, CTR regionale, un altro shape già
pronto — non solo OSM) un elemento che lo copre entro la Tolleranza e lo
copia nello shape Edifici. Utile proprio quando lo shape Edifici del
progetto è già derivato da OSM: ripartire da OSM non aggiungerebbe nulla
di nuovo, serve una fonte diversa. I Civici rimasti scoperti anche dopo
vengono selezionati su Civici — solo quelli vanno tracciati a mano.
Modifica Edifici sul posto: chiede conferma prima di procedere.

## Novità versione 0.46

**Nuova sezione "Esporta PDF (Atlante)" (Shape di consegna):** esporta in
PDF, via Atlante, i layout di stampa già presenti nel progetto QGIS
(configurati con il loro layer di copertura Atlante nel Compositore — non
impostati da qui). Elenco a selezione multipla dei layout disponibili,
pulsante "Aggiorna elenco layout" se ne aggiungi di nuovi dopo aver
aperto il plugin, e un pulsante che sceglie la cartella ed esporta un PDF
per ciascun layout selezionato (nome del file = nome del layout);
l'Atlante viene attivato automaticamente se non lo è già, e riportato
allo stato originale al termine.

**Nuova Regola 6 (Seleziona elementi) — Verifica Civici senza Edificio:**
seleziona i Civici che non toccano/intersecano nessun elemento del layer
Edifici entro la Tolleranza — un edificio mancante da recuperare. Avviso
esplicito con il conteggio se ne trova; altrimenti conferma che tutti i
Civici hanno un Edificio associato.

## Novità versione 0.45

**Fix errore "Seleziona tratte da accorciare" (Regola 4b):**
"'QgsGeometry' object has no attribute 'boundary'" — il metodo
`QgsGeometry.boundary()` non è disponibile in tutte le versioni di
QGIS/PyQGIS. Il perimetro dell'edificio (usato per trovare il punto di
taglio) viene ora costruito a mano dagli anelli del poligono (esterno +
eventuali fori), senza dipendere da quel metodo.

## Novità versione 0.44

**Fix coni ancora appiccicati agli oggetti (Punti di ripresa):** il campo
Sedime Pubblico correggeva ANCHE i punti già trovati correttamente sullo
Stradario — se un Sedime Pubblico residuo di una sessione precedente
(o troppo stretto) risultava impostato, poteva risagomare/spostare un
punto già giusto verso l'oggetto fotografato. Ora il Sedime Pubblico
interviene SOLO sul ripiego "nessuna strada trovata", mai su un punto
già trovato correttamente sullo Stradario. Rimossa anche
l'autoselezione automatica del campo Sedime Pubblico (ora sempre
volontaria) per evitare che un layer residuo venga usato senza che te ne
accorga.

**Fix accorcia tratte (Regola 4b):** un PTE posizionato esattamente sul
bordo dell'edificio (il caso più comune, PTE a muro) non veniva
riconosciuto come "tocca l'edificio" — il controllo usava `contains()`,
che in senso stretto esclude i punti sul perimetro. Ora usa
`intersects()`, che riconosce anche il contatto sul bordo.

**Fix numerazione Keyplan (Keyplan e tavole):** il campo di default per
la numerazione del Keyplan ora è "Numero Tav" (lo stesso delle Tavole di
Inquadramento, come richiesto), non più "Numero KP". Il messaggio
finale ora riporta anche quanti elementi sono stati letti dal layer: se
il numero è molto più basso delle tavole/keyplan attese (es. sempre 1),
segnala di verificare che il layer impostato sia quello giusto (non un
filtro attivo, o il layer modello invece di quello generato).

## Novità versione 0.43

**Punti di ripresa:**
1. La ricerca dello Stradario ora parte dal raggio impostato e RADDOPPIA
   (fino a 256 volte il raggio iniziale) finché non trova una strada,
   invece di ricadere subito sul ripiego "a Nord" con un raggio troppo
   piccolo: era la causa più probabile dei coni che restavano appiccicati
   agli oggetti (Armadio/Pozzetto/Infrastruttura) invece di stare
   sull'asse della strada, e degli attraversamenti persi.
2. Nuovo campo opzionale "Sedime Pubblico": se impostato (es. quello
   generato dalla Regola 5), un punto di ripresa che cade fuori dal
   sedime pubblico viene spostato al punto più vicino dentro di esso —
   per evitare di piazzare il fotografo in un'area non accessibile (es.
   un cortile privato).
3. Rinforzato il controllo anti-duplicati già introdotto in v0.42 (ora
   coerente su tutte le chiamate, incluso il nuovo aggancio al Sedime).

**Keyplan e tavole — nuova numerazione:** pulsante separato "Numera
Keyplan e Tavole" che numera i due layer (indipendentemente) in ordine di
lettura: righe da nord a sud, e all'interno di ogni riga da ovest a est
(alto-sinistra → basso-destra). Campo creato se manca.

**Seleziona elementi:**
1. La selezione "Tratte + Pozzetti toccati da Edifici" ora esclude
   sempre le tratte TIPOLOGIA='Aerea', a prescindere dalla spunta
   STATO='Nuovo'.
2. "Accorcia tratte fino al bordo edificio" è ora in due passi: prima
   "Seleziona tratte da accorciare" (nessuna modifica, solo selezione da
   verificare sulla mappa), poi "Accorcia tratte selezionate" (agisce
   solo su quelle rimaste selezionate, con conferma).

## Novità versione 0.42

**Fix rotazione sempre a 180° (Punti di ripresa):** il filtro spaziale
per cercare lo Stradario vicino era costruito in CRS di progetto ma
inviato al layer Stradario senza convertirlo nel SUO CRS — su progetti
con Stradario in un CRS diverso da quello di progetto, il filtro non
trovava mai nessuna tratta, e la funzione ricadeva SEMPRE sul ripiego "a
Nord" (che dà, per costruzione, sempre rotazione 180°). Ora il
rettangolo di ricerca viene convertito nel CRS del layer Stradario prima
di interrogarlo.

**Fix coni duplicati sullo stesso punto (soprattutto sugli Armadi):**
"Coni Armadi" e "Coni per Tavola di Inquadramento" calcolano la STESSA
posizione (stessa proiezione sullo Stradario) per lo stesso Armadio:
eseguendo entrambi i pulsanti (o rieseguendo lo stesso più volte)
finivano due Foto diverse impilate sul punto identico. Ora entrambe le
funzioni tengono traccia dei punti già occupati (Foto già presenti nel
layer + quelle appena aggiunte in questa esecuzione): un Armadio il cui
punto coincide con un cono già esistente conta comunque come "coperto"
ma non viene duplicato; per attraversamenti/Pozzetto Nuovo/tratta un
candidato duplicato viene scartato e si prova il successivo, senza
sprecare uno dei 3 posti della tavola.

## Novità versione 0.41

**Fix errore "Regola 4b" (Accorcia tratte fino al bordo edificio):**
"MultiLineString geometry cannot be converted to a polyline" — molti
shapefile salvano anche le tratte logicamente singole come
MultiLineString con una sola parte, e la conversione usata non lo
gestiva. Ora la funzione riconosce questo caso e ricostruisce l'output
nello stesso formato (MultiLineString) atteso dal layer. Tratte con più
parti realmente disgiunte restano non toccate (nessun lato PTE/lato da
mantenere univoco in quel caso).

## Novità versione 0.40

**Allinea cartografia — spostamento esclusivo dei selezionati:** la
checkbox "Sposta SOLO gli elementi selezionati" ora è davvero esclusiva:
un layer impostato ma SENZA una selezione attiva viene saltato per
intero (nessun elemento spostato), invece di ricadere nello spostare
tutto il layer come accadeva prima.

**Seleziona elementi — Regola 4b, nuova (Accorcia tratte fino al bordo
edificio):** per ogni tratta Infrastrutture STATO='Nuovo' (esclusa
TIPOLOGIA='Aerea') che tocca un ROE PTE con TIPO diverso da "Interno
Edificio"/"Muro Interno" (quindi un PTE non interno a QUELL'edificio) e
che attraversa un elemento del layer Edifici, la tratta viene accorciata
fino al primo punto in cui tocca il bordo dell'edificio, eliminando il
tratto che prosegue dentro l'edificio verso quel PTE. Modifica le
geometrie sul posto: chiede sempre conferma prima di procedere. Richiede
un layer Edifici poligonale (non lineare).

## Novità versione 0.39

**Fix Keyplan che non contiene le Tavole di inquadramento:** aggiunto un
campo "Tavole di Inquadramento" condiviso nella sezione Keyplan — se
impostato, SIA il pulsante standard "Genera copertura Keyplan sull'area
di progetto" SIA "Rigenera Keyplan" (rigenerazione mirata) coprono
esclusivamente l'impronta di quelle tavole, ignorando del tutto ARLO
AREA. In precedenza il pulsante standard restava sempre legato ad ARLO
AREA (causa reale dei Keyplan che non contenevano le tavole vicine nello
screenshot), e la rigenerazione mirata dipendeva da un riferimento
interno valido solo nella stessa sessione in cui le tavole erano state
generate (fragile se il progetto veniva riaperto). Il campo si
autocompila cercando un layer chiamato "Poligoni Inquadramento".

**Punti di ripresa — numerazione che perdeva alcuni coni:** i coni
generati da "Coni per Tavola di Inquadramento" sono ora collegati alla
loro tavola con un campo interno esplicito ('ID_Tavola'), non più solo
per contenimento geometrico: un punto di ripresa spostato sullo Stradario
può finire fuori dal perimetro della tavola, e in quel caso il vecchio
test geometrico non lo trovava più — la Numerazione automatica Foto lo
lasciava senza numero. Le Foto senza questo collegamento (es. dal
pulsante Coni Armadi) continuano a usare il ripiego geometrico.

**Punti di ripresa — nuova priorità Pozzetto Nuovo:** aggiunto un livello
di priorità intermedio tra gli attraversamenti Provinciale/ANAS e la
tratta generica: i Pozzetti Nuovi che toccano un'Infrastruttura Nuova
sono ora un punto di interesse a sé, con priorità più bassa degli
attraversamenti ma più alta della tratta.

**Punti di ripresa — ancoraggio uniforme:** TUTTI i tipi di cono
(Armadio, attraversamenti, Pozzetto Nuovo, tratta) sono ora ancorati allo
stesso modo — proiezione perpendicolare sullo Stradario (o un altro
shape lineare a scelta) — non più solo l'Armadio.

## Novità versione 0.38

**Fix Keyplan che non contiene le Tavole di inquadramento vicine:** la
copertura adattiva valutava ogni posizione candidata solo contro la
singola componente connessa del 'buco' scoperto scelto come riferimento
— Tavole di inquadramento (o gruppi di Infrastrutture/Pozzetto Nuovi)
vicine ma non tecnicamente a contatto diretto sono componenti connesse
SEPARATE, quindi venivano ignorate anche quando cadevano comodamente
dentro la stessa tavola/keyplan. Ora ogni posizione viene valutata contro
TUTTO lo scoperto rimasto, non solo quella componente: un Keyplan (o una
Tavola di inquadramento) può quindi raccogliere più elementi vicini in
una volta sola, contenendoli davvero.

**Fix STATO='Nuovo'/TIPOLOGIA='Aerea' ancora aggirabile nella
rigenerazione mirata delle Tavole di inquadramento:** stesso bug di
confronto case/spazi-sensibile già corretto altrove in v0.37, ora esteso
anche a `_target_ottimizza_inquadramento` (il target usato dal pulsante
'Rigenera tavole di inquadramento solo sulla rete nuova').

**Punti di ripresa — priorità assoluta sugli Armadi:** ogni Armadio
Ottico presente in una Tavola di Inquadramento ha ora SEMPRE un cono
dedicato, anche se ce ne sono più di 3 nella stessa tavola (in quel caso
il tetto di 3 coni totali viene superato pur di non saltarne nessuno). Il
budget per attraversamenti/tratte si adatta di conseguenza.

**Punti di ripresa — logica parallela/perpendicolare sullo Stradario:**
il punto di ripresa via Stradario ora scompone esplicitamente ogni
segmento nella componente parallela (direzione della strada) e
perpendicolare (scarto laterale, cioè il punto di ripresa): un vero piede
perpendicolare (che cade dentro il segmento) è sempre preferito a un
punto d'estremo/incrocio, anche se quest'ultimo fosse leggermente più
vicino in linea d'aria — un estremo clampato non è una vera inquadratura
perpendicolare alla strada.

## Novità versione 0.37

**Fix coni su infrastruttura aerea (Punti di ripresa):** il confronto
TIPOLOGIA='Aerea' era case/spazi-sensibile: un dato scritto 'AEREA', '
Aerea ' ecc. non veniva riconosciuto come aereo e la tratta passava il
filtro. Ora il confronto (STATO e TIPOLOGIA) ignora maiuscole/minuscole e
spazi iniziali/finali.

**Numerazione automatica Foto (Punti di ripresa):** nuovo pulsante che
numera le Foto a blocchi fissi di 3 per Tavola di Inquadramento, ma SOLO
se le tavole sono già numerate in un campo esistente (letto, non generato
dal plugin) — altrimenti non fa nulla e spiega perché. Se una tavola ha
meno di 3 coni, il/i numero/i mancante/i del suo blocco vengono saltati,
non riassegnati alla tavola successiva.

**Allinea cartografia:** rimosso il calcolo automatico da shapefile di
riferimento; resta solo l'allineamento tramite punti di controllo
manuali (utile anche sopra un WMS).

**Keyplan/Tavole di inquadramento — fix centraggio:** la copertura
adattiva ora, oltre alla griglia di posizioni-angolo di sempre, prova
anche a centrare la tavola sul baricentro di tutto il contenuto che le
ricade attorno in una finestra grande quanto la tavola stessa; se quel
contenuto ci sta quasi per intero in una tavola sola, la posizione
centrata vince sempre. Le tavole risultano quindi centrate su quello che
devono inquadrare (Infrastrutture/Pozzetto Nuovi per le Tavole di
inquadramento, le Tavole di inquadramento stesse per il Keyplan) invece
di essere ancorate per un angolo/bordo.

## Novità versione 0.36

**Nuova scheda "Allinea cartografia":** sposta in blocco Armadio Ottico,
Infrastrutture, Pozzetto, ROE PTE, Cavo Ottico e Cavo Raccordo per
allinearli alla cartografia ufficiale del permesso (WMS o shapefile, a
seconda del territorio), preservando la topologia della rete — la
trasformazione (traslazione + rotazione + scala) è UNA sola, applicata
tutta insieme a tutti i layer scelti, non uno snap elemento per elemento
che romperebbe i collegamenti tra pozzetti e tratte.

Due modi per calcolarla:
- **A) Automatico da uno shapefile di riferimento**: abbina i vertici di
  un layer "àncora" (es. Infrastrutture) al punto più vicino su un layer
  di riferimento ufficiale entro una tolleranza, scarta gli abbinamenti
  anomali, calcola la trasformazione che minimizza lo scarto residuo
  complessivo (minimi quadrati).
- **B) Punti di controllo manuali**: utile sopra un WMS, che non ha
  geometrie proprie da agganciare automaticamente. Si clicca sulla mappa
  una coppia di punti alla volta (uno sulla rete, uno sul riferimento);
  con 2 o più coppie si calcola la stessa trasformazione.

In entrambi i casi viene mostrata un'anteprima (rotazione, scala,
traslazione, errore residuo) prima di applicare, e la conferma è
obbligatoria: l'operazione modifica le geometrie sul posto.

## Novità versione 0.35

**Ordine schede:** "Keyplan e tavole" spostata prima di "Punti di ripresa"
(le Tavole di inquadramento vanno generate prima, essendo ora un
riferimento per i punti di ripresa).

**Punti di ripresa:**
- Le Infrastrutture di interesse sono ora sempre solo STATO='Nuovo',
  escluse TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL (non più un filtro
  opzionale disattivabile).
- Il posizionamento del cono per l'Armadio Ottico non usa più gli
  Edifici come punto di ancoraggio: il punto di ripresa è ora la
  proiezione perpendicolare dell'Armadio sulla tratta di Stradario più
  vicina, con l'inquadratura rivolta verso l'Armadio dall'altro lato
  della strada. Rimosso il layer Edifici/Fabbricati, aggiunto Stradario
  (opzionale) sia nel pulsante Armadi singolo sia nei Coni per Tavola di
  Inquadramento.

**Seleziona elementi — Regola 5:** il Sedime Pubblico (OSM) ora include
anche marciapiedi e vie pedonali (già mappati come highway in OSM) e, dove
disponibili, tratta piazze e aree pedonali chiuse come superficie piena
invece che come una fascia bufferizzata attorno al solo perimetro — una
piazza larga non risultava quasi tutta scoperta (e quindi segnalata come
possibile privato) solo per un limite del buffer stradale.

**Keyplan/Tavole di inquadramento (rigenerazione mirata):** confermato che
il target è già completamente svincolato da ARLO AREA — le Tavole di
inquadramento puntano solo a Infrastrutture STATO='Nuovo' (escluse
TIPOLOGIA='Aerea'/NULL) + Pozzetto STATO='Nuovo', e il Keyplan copre solo
l'impronta di quelle tavole (fix già introdotto in v0.33).

## Novità versione 0.34

**Fix join ARMADI_FOTO (Shape di consegna):** la base del join era il
Punto di Ripresa invece dell'Armadio Ottico, quindi il risultato aveva una
riga per OGNI punto di ripresa (compresi quelli generati per
attraversamenti/tavole di inquadramento, non legati a un armadio) invece
di una per ogni Armadio Ottico. Confermato confrontando con uno shape
ARMADI_FOTO di riferimento: i campi dell'Armadio Ottico vengono per primi,
seguiti da quelli del Punto di Ripresa più vicino. Ora la base del join è
l'Armadio Ottico: ARMADI_FOTO.shp ha un solo elemento per ogni Armadio
Ottico, con gli attributi del Punto di Ripresa più vicino entro la
Distanza max join.

## Novità versione 0.33

**Fix copertura Keyplan/Tavole di inquadramento (rigenerazione mirata):**
1. Il Keyplan ottimizzato copriva l'intero ARLO AREA unito alle Tavole di
   inquadramento, invece delle sole Tavole di inquadramento: su un ARLO
   AREA molto più esteso della rete nuova, l'algoritmo sceglieva di
   coprire per prime zone lontane dalla rete, con il Keyplan che finiva
   piazzato spostato ("traslato") rispetto alle tavole invece che sopra
   di esse. Ora il target è solo l'unione delle Tavole di inquadramento
   già rigenerate.
2. Corretta la causa dei buchi rimasti su Infrastrutture/Pozzetto Nuovi:
   quando nessuna posizione libera da sovrapposizioni copriva un punto, la
   copertura scartava solo un'area minuscola attorno ad esso — su un
   target STRETTO (un corridoio attorno alla rete) questo poteva bruciare
   tutto il budget di tentativi su un'unica zona ostica (curve, incroci),
   interrompendo la generazione anche per il resto della rete, mai
   nemmeno provato. Ora: griglia di posizioni candidate più fitta (5×5),
   area scartata per fallimento proporzionata alla tavola (non più
   trascurabile) e budget di tentativi molto più alto.

**Regola 1b (Seleziona elementi):** aggiunta una terza condizione
indipendente di esclusione del Pozzetto: se toccato dal layer Cavo Ottico
(dorsale condivisa), oltre a TIPOLOGIA='No Dig' della tratta e sede-PTE
già presenti — basta una sola delle tre per escluderlo.

**Punti di ripresa — Coni per Tavola di Inquadramento:** il ripiego
quando mancano attraversamenti Provinciale/ANAS non punta più al PTE
dentro un Pozzetto, ma a un punto lungo la tratta Infrastruttura Nuova
stessa (l'attraversamento fisico da un Pozzetto a un ROE PTE, o tra due
Pozzetti). Rimosso il layer ROE PTE dalla sezione, non più necessario.

## Novità versione 0.32

**Regola 5 — sedime alternativo:** nella sezione "Possibile proprietà
privata" è ora possibile impostare un layer poligonale alternativo (es. da
un geoportale regionale/comunale più preciso di OSM per quel progetto): se
impostato viene usato al posto del Sedime Pubblico (OSM) generato al
punto 1, senza bisogno di integrazioni dedicate per ogni ente.

**Punti di ripresa — Coni per Tavola di Inquadramento:** nuova sezione
nella scheda "Punti di ripresa" che genera fino a 3 coni fotografici per
ogni Tavola di Inquadramento:
- 1 cono dedicato all'Armadio Ottico se ricade nella tavola (stessa
  logica di posizionamento — perpendicolare al muro più vicino — del
  pulsante Armadi già esistente);
- gli altri (fino a 3 se la tavola non contiene un Armadio) ai punti di
  attraversamento Infrastrutture×Provinciale e Infrastrutture×ANAS, e in
  mancanza ai Pozzetti sede di un ROE PTE (di qualsiasi tipologia) che
  ricadono nella tavola;
- priorità quando i candidati sono più del necessario: Provinciale, poi
  ANAS, poi Pozzetto-PTE; a parità di tipo vince il candidato più vicino
  al centro della tavola;
- layer Provinciale, ANAS e ROE PTE sono opzionali (se mancano, quel tipo
  di candidato è semplicemente assente dal conteggio).

## Novità versione 0.31

**Regola 5 (Seleziona elementi) — Possibile proprietà privata, automatica via OSM:**
1. "Scarica strade OSM e genera Sedime Pubblico": scarica da Overpass API
   (con mirror di riserva) le strade OpenStreetMap nell'area di
   Infrastrutture + Pozzetto, le bufferizza con la larghezza impostata
   (default 7 m) e crea il layer memory "Sedime Pubblico (OSM)".
2. "Seleziona tratte/pozzetti fuori dal Sedime": seleziona le tratte
   Infrastrutture e i Pozzetti che ricadono interamente FUORI da quel
   sedime — candidati a proprietà privata.

**Attenzione:** è una preselezione automatica, non una classificazione
legale — OSM può essere incompleto in alcune zone e il buffer è solo una
stima del sedime reale (piazze, cortili condominiali aperti su strada,
ecc. possono dare falsi positivi/negativi). Va sempre verificata a vista
prima di procedere con i permessi.

## Novità versione 0.30

1. **Regola 1b (Seleziona elementi):** il Pozzetto "subito dopo" la tratta
   non viene selezionato se è vera almeno una di due condizioni
   indipendenti: la tratta di provenienza ha TIPOLOGIA='No Dig', oppure il
   pozzetto è sede di un ROE PTE (di qualsiasi tipologia).
2. **Punti di ripresa:** rimossa la numerazione automatica dei punti di
   ripresa (campo "Campo numerazione" e relativa logica).
3. **Keyplan e tavole — rigenerazione mirata ("Rigenera solo sulla
   rete"):**
   - le Tavole di inquadramento si posizionano ora nel minor numero
     possibile sopra le Infrastrutture STATO='Nuovo' (escluse
     TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL) UNITE al Pozzetto
     STATO='Nuovo' — vanno generate per prime;
   - il Keyplan continua a tenere conto di ARLO AREA come prima, ma copre
     anche le Tavole di inquadramento già rigenerate: va quindi rigenerato
     DOPO di esse;
   - rimossa la numerazione automatica delle tavole/keyplan (campo "Numero
     Tav").
4. **Shape di consegna:**
   - i campi LUNGHEZZA e Lungh del layer "03 INFRASTRUTTURE" vengono creati
     solo se mancanti: se esistono già, vengono semplicemente aggiornati
     con l'espressione '$Length';
   - in ARMADI_FOTO, i valori '999' del campo CIVICO vengono sostituiti con
     'SNC';
   - il join Armadio Ottico + Punti di ripresa per generare ARMADI_FOTO
     tiene ora conto SOLO dei punti di ripresa effettivamente associati a
     un Armadio Ottico (entro la Distanza max join): i punti di ripresa
     senza un Armadio entro quella distanza vengono esclusi dallo shape,
     non più inclusi tutti indiscriminatamente.

## Novità versione 0.28 (base Infrastrutture garantita + pulizia campo 'n')

1. **Base Infrastrutture garantita.** L'aggiornamento di LUNGHEZZA/Lungh e
   la base del join per SCAVI_STRADE vengono ora presi sempre dal layer di
   progetto chiamato esattamente "03 INFRASTRUTTURE" (cercato per nome),
   non da quello selezionato al momento nel campo Infrastrutture della
   scheda — se trovato, il campo viene anche riallineato di conseguenza.
   Se il progetto non ha un layer con quel nome esatto, si usa comunque
   quello selezionato nel campo, come prima.
2. **Pulizia automatica del campo 'n'.** Prima di considerare pronti
   SCAVI_STRADE e POZZETTI_STRADE, vengono rimosse le eventuali righe con
   l'attributo 'n' diverso da 1 (o mancante): può capitare con un
   pareggio di distanza nel join, che produce più righe per lo stesso
   elemento di partenza — se ne tiene solo una. Il numero di righe rimosse
   (se maggiore di zero) compare nel messaggio finale.

## Novità versione 0.27 (schema attributi shape di consegna allineato ai file di riferimento)

Confrontata la tabella attributi generata con i file `.dbf` di riferimento
(SCAVI_STRADE, ARMADI_FOTO, POZZETTI_STRADE): i join non aggiungono più un
prefisso ai campi del layer unito (prima: `str_`/`armadio_`). I campi
vengono ora copiati con il loro nome originale; in caso di nomi già
presenti (es. `fid`), QGIS li rinomina da solo in `fid_2`, esattamente come
nei file di riferimento. Nome dei 3 shapefile e struttura dei join
(Foto+Armadio, Infra+Stradario[+Armadio], Pozzetto+Stradario[+Armadio])
restano invariati, erano già corretti.

## Novità versione 0.26 (regola 4: filtro opzionale STATO='Nuovo')

Nella regola "4) Tratte Infrastrutture + Pozzetti toccati da Edifici",
nuovo flag opzionale **"Tratte Infrastrutture: solo STATO='Nuovo'"**: se
spuntato, limita solo le tratte Infrastrutture a quelle con STATO='Nuovo';
i Pozzetti restano selezionati senza filtro, come prima.

## Novità versione 0.25 (fix blocco interfaccia sulla regola "toccati da Edifici")

Il layer Edifici può essere molto più grande di quelli usati dalle altre
regole (es. un WFS/basemap con fabbricati su tutto il territorio, non solo
sull'area di progetto): leggerlo e riproiettarlo TUTTO poteva richiedere
moltissimo tempo o restare in attesa dati dal server, con QGIS che sembrava
bloccato. Ora da Edifici si legge SOLO quello che ricade nel rettangolo che
contiene Infrastrutture + Pozzetto (più la tolleranza) — per un WFS il
filtro viene mandato al server invece di scaricare l'intero layer. In più,
cursore di attesa e interfaccia tenuta reattiva durante il calcolo.

## Novità versione 0.24 (nuova regola: tratte + pozzetti toccati da Edifici)

Nella scheda "Seleziona elementi", nuova regola **4) Tratte Infrastrutture +
Pozzetti toccati da Edifici**: imposti il layer Edifici/Fabbricati e il
pulsante seleziona, in un colpo solo, sia le tratte Infrastrutture sia i
Pozzetti che toccano/intersecano quello shape (qualsiasi TIPOLOGIA/STATO,
non solo 'Nuovo'), entro la Tolleranza già impostata nella scheda. Le due
selezioni sono indipendenti tra loro (una tratta viene selezionata anche
senza un pozzetto toccato, e viceversa) e funzionano con "Rimuovi elementi
selezionati" come le altre regole.

## Novità versione 0.23 (trovata la VERA causa di "UNIQUE constraint failed")

Il fix della v0.22 (chiudere/cancellare il file prima di riscrivere) non
bastava: l'errore tornava anche su file nuovi. La causa reale: i layer
modello (Keyplan_*.gpkg, Tavole_Inquadramento.gpkg) hanno un campo
attributo chiamato **'fid'** — la colonna chiave primaria del GeoPackage,
che QGIS espone anche come campo normale quando lo si legge come layer.
Ogni tavola generata copiava gli attributi dall'unica feature modello
selezionata, quindi **tutte** le tavole finivano con lo stesso valore in
quel campo 'fid'. Salvando su GeoPackage, GDAL riconosce un campo chiamato
proprio 'fid' come chiave primaria della tabella: con lo stesso valore
duplicato su ogni tavola, solo la prima veniva scritta e tutte le altre
fallivano con "UNIQUE constraint failed: <nome>.fid" — esattamente il
pattern "solo 1 di N scritte" visto negli errori. Ora il campo 'fid' (se
presente nel modello) viene escluso dallo schema delle tavole generate,
sia per il Keyplan che per i Poligoni di Inquadramento.

## Novità versione 0.22 (salvataggio separato Keyplan/Inquadramento + fix UNIQUE constraint)

1. **Salvataggio separato.** Il pulsante unico è diventato due pulsanti
   indipendenti — "Salva Keyplan su GeoPackage…" e "Salva Poligoni
   Inquadramento su GeoPackage…" — ciascuno con il proprio file scelto al
   momento (anche due GeoPackage o cartelle diverse), un solo layer per
   volta.
2. **Fix "UNIQUE constraint failed" nel salvataggio.** Capitava salvando
   di nuovo sullo stesso file: il layer caricato dal salvataggio
   precedente restava aperto nel progetto e teneva il GeoPackage occupato,
   così la sovrascrittura non ripartiva davvero da zero e la scrittura
   provava ad aggiungere le nuove tavole a quelle vecchie rimaste dentro,
   con lo stesso fid già usato. Ora chiude ogni altro layer che punta già
   a quel file e lo cancella prima di scrivere (o avvisa, invece di
   provarci, se si sta per salvare un layer esattamente sopra al file da
   cui è già stato caricato).

## Novità versione 0.21 (fix margine instabile + fix rigenerazione sulla rete)

1. **Tavole di inquadramento: mai più sovrapposte.** Il vecchio "Margine
   sovrapposizione" aveva un comportamento non prevedibile (numero di
   tavole non monotono al variare del margine, es. 0,01 m → 150 tavole,
   5 m → 60, 10 m → di nuovo 150): permettere overlap reale lascia sempre
   una fascia di bordo scoperta che va ritappata con altre tavole, in modo
   non lineare. Ora le Tavole di inquadramento seguono la stessa regola già
   in uso per il Keyplan: MAI sovrapposte, con un "Margine di sicurezza
   (gap)" opzionale al posto del vecchio margine.
2. **Rigenerazione "solo sulla rete" corretta.** Rimosso il campo Pozzetti
   (semplificazione). Corretto il bug per cui la rigenerazione falliva del
   tutto (Keyplan) o si fermava dopo 1-2 tavole (Tavole di inquadramento):
   la soglia di arresto, pensata per coprire un'area piena, era troppo alta
   per un corridoio stretto attorno alla sola infrastruttura nuova. Le
   dimensioni delle tavole ora si leggono direttamente dai layer modello
   (Keyplan/Inquadramento A e B), non dalle tavole già generate.

## Novità versione 0.20 (rigenerazione mirata sulla rete + salva con stile automatico)

1. **"Ottimizza" ora rigenera davvero la copertura, non sposta solo le
   tavole.** Butta via la copertura esistente e ne crea una nuova usando
   come area da coprire solo un intorno (raggio impostabile, default 0,5 m)
   delle **Infrastrutture Nuove** (STATO='Nuovo') ed eventualmente dei
   **Pozzetti** (nuovo campo opzionale nella stessa sezione), invece
   dell'intero poligono ARLO AREA. Le tavole si posizionano quasi a
   contatto tra loro solo dove c'è davvero rete da documentare — il Keyplan
   resta sempre senza sovrapposizioni — e il numero di tavole scende
   drasticamente, anche lasciando scoperte le parti di ARLO AREA senza
   infrastruttura nuova (voluto).
2. **Nuovo pulsante "Salva Keyplan / Poligoni Inquadramento su
   GeoPackage…".** Scrive i layer temporanei su un GeoPackage a scelta,
   ricarica i layer da disco al posto delle copie in RAM e applica in
   automatico lo stile allegato al plugin (uno per Keyplan, uno per
   Poligoni Inquadramento) — nessuno stile da reimpostare a mano ogni volta.

## Novità versione 0.19 (Keyplan senza sovrapposizioni + margine tavole editabile <0,1 m + potatura ridondanti)

1. **Il Keyplan non genera più tavole sovrapposte.** Ogni tavola candidata
   che si sovrapporrebbe (oltre una tolleranza numerica minima) a una già
   piazzata viene scartata; se non c'è spazio per una tavola intera senza
   sovrapporsi, resta un piccolo residuo scoperto invece di forzare la
   sovrapposizione. Il vecchio campo "Margine sovrapposizione" del Keyplan è
   diventato **"Margine di sicurezza (gap)"**: con 0 le tavole restano al
   massimo a contatto bordo a bordo, con un valore positivo restano pure
   staccate. Anche **"Ottimizza Keyplan sulle infrastrutture nuove"** ora
   verifica, tavola per tavola, che lo spostamento non ne crei una: se serve
   riduce lo spostamento o lascia la tavola ferma.
2. **Il margine di sovrapposizione delle Tavole di inquadramento è editabile
   con precisione al centimetro** (es. 0,02 m), non più solo a decimi di
   metro: un margine minimo ma non nullo evita micro-fessure di area
   scoperta dovute agli arrotondamenti, senza dover generare una tavola
   intera solo per coprirle.
3. **Potatura automatica delle tavole ridondanti.** Dopo ogni generazione
   (Keyplan e Tavole di inquadramento), le tavole il cui contributo di area
   non già coperta dalle vicine è trascurabile vengono rimosse in automatico,
   per ridurre il numero di tavole utili finali senza mai riaprire un buco
   che prima era coperto.

## Novità versione 0.18 (copertura a forma libera + Ottimizza per-tavola)

**Causa reale del problema "griglia limitata a un angolo dell'area":** il
layer ARLO AREA può contenere più feature separate e non adiacenti (aree
armadio sparse su un territorio esteso, non un'unica forma continua). Il
bounding box RETTANGOLARE dell'unione di quelle feature include anche tutto
il vuoto tra una zona e l'altra — ed era quel rettangolo, troppo grande e
per lo più vuoto, ad essere usato per pianificare la griglia.

1. **Le feature di ARLO AREA vengono ora FUSE** in un'unica geometria reale
   (anche multi-parte se non adiacenti), invece di usarne solo il bounding
   box.
2. **Le tavole (Keyplan e Tavole di inquadramento) non sono più su una
   griglia rettangolare rigida.** Vengono posizionate liberamente, una alla
   volta, sul "buco" scoperto più grande rimasto — come mettere delle toppe
   sui buchi di un tessuto — così seguono il contorno reale anche per forme
   strette e serpeggianti lungo le strade, invece di riempire un rettangolo
   pieno di spazio inutile.
3. **Il pulsante "Ottimizza" ora sposta OGNI tavola individualmente**, non
   più tutta la griglia in blocco: ciascuna tavola si centra sul tratto di
   Infrastruttura NUOVA (STATO='Nuovo') più vicino al proprio centro
   attuale. Rimossi dalla sezione "Ottimizza" i campi Armadio Ottico e
   Pozzetto (non più usati per questo scopo): resta solo Infrastrutture.
4. **"Diagnostica estensione" ora mostra anche**: l'area reale della forma
   fusa, quante parti separate ha, e di quanto il bounding box la
   sovrastima (utile per capire se conviene la copertura a forma libera).

## Novità versione 0.17 (fix selezione automatica layer ARLO AREA)

1. **Bug critico corretto: la griglia poteva essere calcolata sul layer
   sbagliato.** `refresh_layers()` (che gira ogni volta che apri il
   dialogo) assegnava il layer atteso per nome (es. "ARLO AREA") SOLO se
   il combo risultava vuoto (`currentLayer() is None`). Ma un
   `QgsMapLayerComboBox` obbligatorio (`allow_empty=False`, usato per ARLO
   AREA dal fix v0.16) seleziona DA SOLO un layer qualsiasi compatibile non
   appena il progetto lo contiene: il combo risultava quindi "valorizzato"
   con un layer diverso (es. un modello Keyplan) senza che la correzione
   automatica per nome scattasse più. Il risultato visibile: la griglia
   veniva generata sull'estensione minuscola del layer sbagliato invece che
   su tutta l'area ARLO AREA, con solo poche tavole in un angolo del
   progetto. Ora il layer con il nome atteso ha SEMPRE la precedenza (se
   esiste nel progetto), ad ogni apertura del dialogo — anche se il combo
   aveva già un valore diverso.
2. **Consiglio pratico:** dopo aver aggiornato il plugin, usa "Diagnostica
   estensione" prima di generare la griglia: il messaggio riporta il nome
   esatto del layer usato e quante feature contribuiscono all'estensione,
   così puoi verificare a colpo d'occhio che sia davvero ARLO AREA.

## Novità versione 0.16 (fix "Estensione vuota", nuovo pulsante Ottimizza)

1. **Estensione griglia Keyplan/Tavole basata SOLO su ARLO AREA.** Prima
   l'estensione era l'unione di ARLO AREA + Armadio Ottico + Infrastrutture
   + Pozzetto: bastava un filtro attivo, un layer senza feature valide o un
   problema di trasformazione CRS su UNO SOLO di questi ultimi tre per
   rompere l'unione e ottenere "Estensione vuota" (o un'estensione più
   piccola del reale) anche con ARLO AREA impostato e popolato
   correttamente. Ora l'estensione è semplicemente il bounding box di ARLO
   AREA (il poligono con tutte le aree armadio da coprire), allargato del
   margine impostato: un solo layer, un solo punto di fallimento, facile da
   verificare con "Diagnostica estensione".
2. **Popup "Estensione vuota" ora spiega subito la causa.** Prima del
   generico "Nessun elemento nei layer selezionati", ora dice se manca il
   layer ARLO AREA, se il layer non ha feature, o se le feature non hanno
   una geometria valida/trasformabile — senza dover aprire "Diagnostica
   estensione" a parte per scoprirlo.
3. **Corretta l'etichetta duplicata "margine estensione".** Il campo aveva
   sia l'etichetta di riga "Margine estensione:" sia un suffisso identico
   sullo spinbox ("… m margine estensione"), risultando in un valore tipo
   "100 m margine estensione" poco chiaro. Ora l'etichetta spiega cosa fa
   il campo (buffer in metri attorno al confine ARLO AREA) e il valore
   mostra solo "100 m".
4. **Nuova sezione "Ottimizza posizionamento griglia" (opzionale).**
   Armadio Ottico, Infrastrutture e Pozzetto non servono più a calcolare
   l'estensione, ma restano utili DOPO aver generato una griglia Keyplan o
   Tavole di inquadramento: i due nuovi pulsanti "Ottimizza griglia…"
   traslano in blocco la griglia già generata (stessa forma, dimensione e
   numero di tavole) per ridurre quanti elementi di quei tre layer
   risultano tagliati a metà tra una tavola e quella adiacente, provando
   una serie di piccoli spostamenti entro il passo della griglia e
   applicando quello che lascia il minor numero di elementi "a cavallo" di
   un bordo.

## Novità versione 0.11 (fix salvataggio GeoPackage Keyplan/Tavole, nuova Regola 1b)

1. **Corretto l'errore "Impossibile salvare... UNIQUE constraint failed:
   ...fid"** che si presentava rigenerando la griglia Keyplan o la griglia
   Tavole di inquadramento su layer GeoPackage. La causa: cancellare tutte
   le feature e aggiungerne di nuove nella STESSA sessione di editing fa sì
   che, su GeoPackage, il fid appena cancellato non sia ancora "libero" per
   il nuovo insert finché la cancellazione non viene commitata. Ora la
   cancellazione viene sempre commitata subito, e solo dopo si apre una
   nuova sessione di editing per gli inserimenti.
2. **Nuova Regola 1b — "Tratte a contatto diretto col Civico (qualsiasi
   tipologia/stato) + pozzetto successivo".** Regola separata e indipendente
   dalla Regola 1: seleziona OGNI tratta Infrastrutture, di qualunque
   TIPOLOGIA e STATO, che tocchi/intersechi direttamente un Civico su almeno
   un estremo, più il Pozzetto vicino all'estremo opposto della stessa
   tratta ("il pozzetto subito dopo"). Non segue la catena e non si ferma a
   un PTE come la Regola 1: serve a coprire i casi che la Regola 1 (limitata
   a STATO='Nuovo' e alla logica di catena/PTE) lascia fuori. Si AGGIUNGE
   alla selezione corrente (non la sostituisce), quindi si può usare insieme
   alla Regola 1 prima di passare a "Rimuovi elementi selezionati".

## Novità versione 0.10 (Regola 1 più permissiva, barriera PTE corretta, mix tavole Keyplan A/B, bugfix griglia/prestazioni/robustezza)

0. **Keyplan e Tavole di inquadramento — forma/dimensione non più impostabili
   a mano, e possibilità di mixare due modelli.** Rimossi i campi manuali
   Larghezza/Altezza/Forma per le Tavole di inquadramento: la forma e la
   dimensione dei riquadri derivano SEMPRE da una tavola modello reale
   (oggetto da posizionare sul progetto), esattamente come già avveniva per
   il Keyplan. È ora possibile impostare, oltre al modello A, anche un
   modello B opzionale (es. una tavola quadrata e una rettangolare da due
   GeoPackage diversi): quando è impostato anche B, il plugin valuta da solo
   se conviene usare solo A, solo B, oppure MIXARE le due forme (B usato solo
   per l'ultima fascia di colonna o riga, dove si adatta meglio allo spazio
   residuo) — sceglie sempre l'opzione che lascia meno area di tavole fuori
   dall'area di progetto, e riporta la scelta fatta nel log. La stessa
   coppia di modelli A/B e lo stesso automatismo valgono sia per "Genera
   griglia Keyplan" sia per "Genera griglia tavole" (Poligoni di
   Inquadramento), che restano quindi sempre coerenti fra loro.
1. **Regola 1 — selezionate anche le tratte che non hanno ancora raggiunto
   un PTE.** Prima, oltre alla tratta che tocca direttamente il Civico,
   tutte le altre tratte della catena venivano incluse SOLO se la catena
   arrivava effettivamente a un ROE PTE (altrimenti restava selezionata
   solo la prima tratta sul Civico). Ora l'intera catena collegata al
   Civico viene selezionata (pozzetti compresi), anche se non raggiunge
   ancora un PTE, con le stesse eccezioni di sempre: tratte che corrono
   lungo il Cavo Ottico restano escluse, e l'intera catena resta esclusa
   se arriva a un PTE Light Diramatore condiviso con un altro PTE tramite
   il Cavo Raccordo.
2. **Regola 1 — corretta la verifica di barriera al ROE PTE.** La catena si
   fermava a un PTE se ne veniva trovato uno entro tolleranza vicino a UNO
   dei due estremi che si toccano; con tolleranze elevate questo poteva
   generare falsi positivi (un PTE vicino ma non realmente al nodo
   condiviso). Ora viene verificato che il PTE sia entro tolleranza da
   ENTRAMBI gli estremi, cioè che sia davvero il punto di giunzione.
3. **Griglie Keyplan e Tavole di inquadramento — corretto il calcolo delle
   tavole in eccesso.** Il ciclo while precedente poteva generare una riga o
   colonna aggiuntiva quasi interamente fuori dall'area di progetto quando
   quest'ultima superava di poco la dimensione della tavola modello. Il
   numero di righe/colonne è ora calcolato in anticipo con `math.ceil()`
   (o con la stessa logica di valutazione usata per il mix A/B).
4. **Salvataggi falliti ora mostrano il motivo.** Tutti i punti in cui il
   plugin salva modifiche (rimozione elementi, griglia Keyplan, griglia
   tavole, coni fotografici, aggiornamento LUNGHEZZA) mostrano ora il
   dettaglio di `layer.commitErrors()` quando il commit fallisce, invece
   del solo esito booleano.
5. **Prestazioni.** `_unione_layer()` usa `QgsGeometry.unaryUnion()` invece
   di un ciclo di `combine()` (molto più veloce su layer con molte feature);
   `_trova_pozzetti()` non ricrea più due volte la stessa geometria punto
   per ogni pozzetto.
6. **Robustezza.** Le trasformazioni di CRS non interrompono più il plugin
   in caso di errore (vengono ignorate con un avviso in console); le
   geometrie non valide vengono "riparate" (`makeValid()`) prima di calcoli
   di intersezione; `_endpoints()` ignora esplicitamente geometrie non
   lineari invece di affidarsi implicitamente ad `asPolyline()`.

## Novità versione 0.9 (Aerea inclusa in Regola 1, Cavo Raccordo, Regola 3 su Aerea, griglie Keyplan/Inquadramento reali)

1. **Regola 1 — Aerea sempre inclusa.** Rimossa l'opzione "Escludi
   TIPOLOGIA='Aerea'": le tratte aeree con STATO='Nuovo' partecipano ora
   sempre alla ricerca delle catene Civico → PTE, come tutte le altre.
2. **Regola 1 — nuovo layer "Cavo Raccordo" e nuova esclusione sul PTE
   Light Diramatore.** Se la catena selezionata arriva a un ROE PTE di tipo
   "PTE Light Diramatore" e quel punto risulta collegato, tramite una tratta
   dello shape Cavo Raccordo (bretelle tra PTE), a un ALTRO ROE PTE di
   qualsiasi tipologia, si tratta di un raccordo condiviso con un altro
   permesso: l'intera catena e i pozzetti compresi NON vengono selezionati.
   Il log di Regola 1 riporta il numero di catene escluse per questo motivo.
3. **Regola 3 — le tratte Aerea 'Nuovo' non escludono più il pozzetto.**
   Un Pozzetto che tocca solo infrastruttura esistente più eventuali tratte
   Aerea con STATO='Nuovo' viene comunque selezionato: l'Aerea 'Nuovo' non è
   più trattata come "nuova interrata" ai fini di questa regola.
4. **Keyplan — griglia reale invece di una singola geometria stirata.**
   "Posiziona Keyplan" generava un'unica geometria stirata sull'intera
   estensione del progetto, deformando la tavola. Ora il pulsante ("Genera
   griglia Keyplan sull'area di progetto") prende la feature presente nel
   layer (selezionata, o la prima) come MODELLO — stessa forma e dimensione
   reale a scala fissa, es. da Keyplan_Quadrato.gpkg o
   Keyplan_Rettangolare.gpkg — e genera una griglia di copie traslate (mai
   deformate) che insieme coprono per intero Armadio Ottico, Pozzetti e
   Infrastrutture. Il layer viene sovrascritto con le tavole numerate (campo
   "Numero Tav" se presente).
5. **Tavole di inquadramento — coerenti con la griglia Keyplan.** Il nuovo
   checkbox "Usa le dimensioni reali del layer Keyplan modello" (attivo di
   default) fa sì che ogni riquadro della griglia di inquadramento abbia le
   stesse dimensioni reali della tavola Keyplan, invece dei soli valori
   manuali Larghezza/Altezza (che restano disponibili come alternativa/
   fallback se il layer Keyplan è vuoto o il checkbox è disattivato).

## Novità versione 0.8 (PTE Light come gli altri PTE, tab riorganizzati, Keyplan automatico)

1. **Regola 1 corretta sui PTE** — un ROE PTE, di QUALSIASI tipologia
   (incluso "PTE Light Diramatore"), ora funge sempre da **barriera** nella
   ricostruzione della catena Civico→PTE: la catena selezionata si ferma nel
   punto in cui incontra un PTE e non prosegue oltre, verso un eventuale PTE
   successivo condiviso. Il checkbox dedicato ("Ferma la catena a qualsiasi
   ROE PTE...") resta disponibile per disattivare la barriera se necessario,
   ma di default è attivo e il PTE Light è trattato esattamente come gli altri.
2. **Pozzetti esclusi anche se sul Cavo Ottico** — oltre al pozzetto sede di
   PTE, la Regola 1 torna a escludere anche i pozzetti che ricadono sul Cavo
   Ottico (dorsale condivisa), comportamento che si era perso in una versione
   precedente.
3. **Scheda "Shape di consegna" spostata per ultima.**
4. **Shape "ARLO AREA" sostituito con "Armadio Ottico"** come layer da unire
   nei 3 shape di consegna (ARMADI_FOTO, SCAVI_STRADE, POZZETTI_STRADE).
5. **Nuovi checkbox opzionali** per scegliere quali shape includere nel join
   di ogni shape di consegna (Armadio Ottico / Stradario): l'automatismo resta
   attivo di default, i checkbox servono solo per escludere volutamente un
   layer in caso di problemi.
6. **Scheda "Keyplan e tavole" riscritta come semplice posizionatore
   automatico**: nessun collegamento a layout di stampa (.qpt), nessun
   riferimento a elementi mappa nei layout. Il pulsante "Posiziona Keyplan"
   sposta/ridimensiona direttamente la geometria dello shape (o layer
   GeoPackage) Keyplan sopra l'area di progetto (Armadio Ottico, Pozzetti e
   Infrastrutture); "Genera griglia tavole" crea allo stesso modo i riquadri
   di inquadramento numerati.
7. **Scheda "Punti di ripresa" semplificata**: rimossa la funzione (non
   funzionante) di posizionamento coni accanto alle aree ARLO. Resta solo la
   generazione dei coni davanti agli Armadi Ottici (shape "Armadio Ottico"),
   perpendicolari al muro più vicino.

## Novità versione 0.5 (PTE Light: solo tratte sul civico + esclusioni pozzetto)

Due modifiche su richiesta, basate sul caso reale del cavo dorsale condiviso:

1. **Cambiato il comportamento sul PTE "Light Diramatore"** — prima, se una
   catena Civico↔PTE arrivava a un PTE di tipo "PTE Light Diramatore" (raccordo
   condiviso tra più civici), l'intera catena veniva scartata (nessuna
   selezione). Ora, in quel caso, si seleziona comunque qualcosa ma **solo le
   tratte del gruppo che toccano direttamente il Civico** — non l'intero
   percorso fino al PTE, che potrebbe essere condiviso con altri permessi.
   Il checkbox si chiama ora "Se il PTE è 'PTE Light Diramatore' ... seleziona
   SOLO le tratte toccate direttamente dal Civico" (attivo di default).
2. **Pozzetto sede di PTE escluso sempre** — un Pozzetto la cui posizione
   coincide con un punto ROE PTE (entro tolleranza) non viene più selezionato
   dalla Regola 1: è la sede fisica del PTE, non un pozzetto di passaggio da
   rimuovere.
3. **Pozzetto sul CAVO OTTICO escluso** — se il layer Cavo ottico è impostato
   (stesso layer/tolleranza già usati per escludere le tratte sulla dorsale),
   anche i Pozzetto che ricadono su di esso vengono esclusi dalla selezione,
   per lo stesso motivo: fanno parte della dorsale condivisa.

Il log della Regola 1 ora riporta separatamente: catene trovate, catene
ridotte per PTE light, tratte escluse per sovrapposizione al cavo ottico,
pozzetti esclusi perché sede-PTE e pozzetti esclusi perché sul cavo ottico.

## Novità versione 0.3 (fix basati sui tuoi shapefile reali)

Analizzando i tuoi shapefile ho trovato due problemi concreti sui tuoi dati:

1. **685 delle 1771 tratte INFRASTRUTTURE con STATO='Nuovo' sono TIPOLOGIA='Aerea'**
   (non interrate). Il tuo workflow riguarda esplicitamente le nuove interrate, quindi
   la Regola 1 ora esclude di default le tratte aeree dalla ricerca di catene
   Civico↔PTE (checkbox "Escludi tratte aeree", disattivabile se serve).
2. **I tuoi shapefile sono in CRS geografico (gradi, WGS84)**, non in un sistema
   metrico. La tolleranza è sempre nelle unità del CRS di **progetto**: se il
   progetto QGIS resta in gradi, 0.05 equivale a ~5 km e non 5 cm. Ho aggiunto un
   avviso diretto nella scheda Pulizia bozza; se i tuoi progetti sono in gradi,
   **imposta il CRS di progetto su un sistema metrico proiettato** (per l'area di
   Podenzano/Piacenza va bene UTM 32N — EPSG:32632) prima di usare le regole,
   altrimenti la tolleranza non ha senso in metri.

Ho anche sostituito il doppio ciclo O(n²) della Regola 1 con un indice spaziale
sugli estremi delle tratte: con ~1800 tratte "Nuovo" come nei tuoi dati, il doppio
ciclo naive sarebbe stato lento; ora la ricerca delle catene scala molto meglio.

## Novità versione 0.2 (fix Regola 1 + robustezza CRS)

**Problema risolto:** nel workflow reale il percorso tra CIVICO e ROE PTE non è
quasi mai una singola linea, ma è spezzato in più segmenti con vertici
intermedi. La vecchia Regola 1 cercava una tratta con **entrambi** gli estremi
che toccavano direttamente Civico e PTE, quindi le tratte intermedie non
venivano mai trovate e la selezione restava vuota.

**Come funziona ora:** la Regola 1 costruisce le **catene** di tratte
Infrastrutture con `STATO = 'Nuovo'` collegate tra loro vertice-a-vertice
(entro la tolleranza impostata), e seleziona l'intera catena se, nel
complesso, tocca un Civico da un lato e un ROE PTE dall'altro. I Pozzetto
lungo il tracciato vengono trovati con distanza punto-linea, non solo agli
estremi — invariato rispetto a prima.

**Robustezza CRS:** tutte le regole (1, 2, 3) e anche l'analisi spaziale
generica ora trasformano le geometrie nel CRS di progetto prima di calcolare
qualunque distanza. Se i layer coinvolti hanno CRS diversi, il confronto
funziona comunque invece di fallire silenziosamente restituendo zero
risultati (probabile causa del "seleziona pozzetti non funziona" segnalato).

**Nuovo pulsante "Diagnostica tolleranza"** nella scheda Pulizia bozza: calcola
le distanze minime reali tra Infrastrutture↔Civici, Infrastrutture↔PTE e
Pozzetto↔tratte. Usalo prima di lanciare le regole se sospetti che la
tolleranza di default (0.05 m) sia troppo bassa per il tuo dato.

---

Plugin per la gestione unificata dei permessi FTTH (scavi, occupazione suolo
pubblico, attraversamenti), con due strumenti principali:

1. **Analisi spaziale**
   - Intersezione (con buffer opzionale) tra il layer permessi e un layer di
     riferimento qualsiasi (confini comunali, aree di cantiere, vincoli, ecc.)
   - Rilevamento automatico delle sovrapposizioni tra permessi dello stesso
     layer (utile per individuare conflitti, es. scavi che si intersecano)
   - Gli elementi trovati vengono selezionati ed evidenziati in mappa

2. **Seleziona e rimuovi**
   - Selezione elementi tramite espressione QGIS (editor espressioni
     integrato, con suggerimento campi/funzioni)
   - Esempi di espressioni utilizzabili:
     - `stato = 'scaduto'`
     - `tipo_permesso = 'attraversamento' AND stato = 'respinto'`
     - `data_scadenza < now()`
   - Rimozione guidata degli elementi selezionati, con richiesta di conferma
     e gestione della modalità di editing (avvio/commit automatico se il
     layer non è già in editing)

## Installazione

1. Comprimi la cartella `ftth_permessi` in un file `.zip`
   (la cartella deve stare alla radice dello zip, es. `ftth_permessi/metadata.txt`)
2. In QGIS: **Plugin → Gestisci e installa plugin → Installa da ZIP**
3. Seleziona lo zip creato e conferma
4. Il plugin comparirà in toolbar e nel menu **Plugin → FTTH Permessi**

In alternativa, per lo sviluppo: copia la cartella `ftth_permessi` dentro la
cartella plugin di QGIS:

- Windows: `C:\Users\<utente>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
- Linux/Mac: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

Poi attivalo da **Plugin → Gestisci e installa plugin → Installati**.

## Struttura del layer permessi (suggerita)

Il plugin funziona con qualsiasi struttura di attributi, ma per sfruttare al
meglio gli esempi di espressione è utile avere campi tipo:

| Campo             | Tipo   | Esempio                          |
|--------------------|--------|-----------------------------------|
| tipo_permesso      | testo  | scavo / occupazione_suolo / attraversamento |
| stato              | testo  | richiesto / approvato / respinto / scaduto |
| comune              | testo  | Roma                              |
| data_presentazione  | data   | 2026-03-01                        |
| data_scadenza       | data   | 2026-09-01                        |
| ente_competente     | testo  | Comune di Roma – Dip. Mobilità   |

## Note tecniche

- Compatibile con QGIS 3.16+
- Il rilevamento sovrapposizioni usa un indice spaziale (`QgsSpatialIndex`)
  per restare performante anche su layer con molti elementi
- La rimozione elimina le feature dalla sorgente dati reale (shapefile,
  GeoPackage, PostGIS, ecc.): usa con attenzione e valuta di lavorare su una
  copia del layer per i test iniziali

## Prossimi sviluppi possibili

- Form dedicato per l'inserimento di un nuovo permesso con validazione campi
- Generazione automatica di lettere/report di richiesta permesso (docx/pdf)
- Notifiche/evidenziazione automatica dei permessi in scadenza all'apertura
  del progetto
- Storico stati con log delle modifiche
