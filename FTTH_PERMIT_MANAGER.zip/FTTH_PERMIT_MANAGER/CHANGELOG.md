# Changelog — FTTH Permessi Manager

## Versione 3.55

- Chilometriche: se negli shape c'è un altro campo km scritto da una versione precedente del plugin (es. «Km» con «dal km 0+964…»), si aggiorna con gli stessi km: le etichette che lo usano non restano indietro. I campi km dell'utente (altri formati) non si toccano.
- PL Strade: armadio con il simbolo FO (SVG) come nelle altre istanze; scritta «FASCIA DI RISPETTO 30 m» su tutti e due i lati della fascia (prima non compariva: QGIS non etichetta le linee che non disegna); in corografia la legenda non ha più punto di ripresa, sezione e fascia (lì non ci sono); in tavola il simbolo della sezione in legenda è disegnato apposta (prima era vuoto).
- Anteprima veloce: con «Ingrandisci» la pagina si sposta trascinandola col mouse.
- Istanze Strade: dopo «Trova le interferenze», se le «Etichette PL (spostabili)» ci sono già, si rifanno da sole con i km nuovi (quelle spostate restano dove sono se il testo non cambia); il registro lo dice.

## Versione 3.54

- Chilometriche Strade, discordanza tabella/stampa (grave): gli shape conservavano km di un calcolo vecchio (casella «Scrivi Chilometrica…» spenta) e alla generazione valevano più di quelli calcolati. Ora «Trova le interferenze» scrive SEMPRE km ed etichetta negli shape (e svuota i km che non ci sono più); casella e «Strumento: scrivi il campo Chilometrica sui layer» tolti. Le correzioni a mano fatte dopo il calcolo restano valide fino al calcolo successivo.
- Un solo gruppo di etichette in mappa: niente più «Etichette in stampa» (stessi testi delle «Etichette PL (spostabili)»), tolto anche dai progetti di prima.
- «Campo progressiva dei layer» rinominato «Campo dove scrivo il km negli shape della rete» (non è il campo dei cippi).
- Statali ANAS con un solo cippo: la linea ANAS (continua, nel verso dei km) fa da righello tarato sul cippo, anche dove la strada OSM è a pezzi. Verificato su Arenzano con 1 cippo OSM: 90 elementi con il km, istanze «centro abitato» (20) e «fuori centro abitato» (13), spostamento di una tratta dall'una all'altra con il campo IST_STRADE aggiornato.
- Se la strada statale non ha i dati del sito ANAS (scheda ripresa da un salvataggio), «Trova le interferenze» li scarica; il registro dice quante interferenze sono dentro e fuori dal centro abitato.
- PL Strade: in corografia niente voce «fascia di rispetto» in legenda (non è disegnata); nelle tavole di dettaglio la scritta «FASCIA DI RISPETTO 30 m» lungo il bordo della fascia.

## Versione 3.53

- Statali ANAS, dentro/fuori centro abitato: basta UN cippo (del layer o di OSM): il verso dei km lo dà la linea ANAS (disegnata nel verso dei km crescenti), così tutti gli elementi hanno il km e si confrontano con il centro abitato del sito ANAS. Il plugin propone già due istanze separate.
- Le due istanze hanno nomi diversi nel campo IST_STRADE («SS1 - centro abitato», «SS1 - fuori centro abitato») e due gruppi: con «Sposta in questa istanza» un elemento passa dall'una all'altra e il campo nello shape si aggiorna da solo.

- Gruppi per istanza come FILTRI sugli shape comunali, niente shape temporanei: alla conferma ogni istanza ha il suo gruppo (es. «Altri enti › Strade › SS1 — ANAS S.p.A.») con 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO, che sono gli stessi file degli shape comunali con un filtro sul campo IST_…. Una modifica fatta nel gruppo (es. trincea → minitrincea) è nello shape comunale; il gruppo si salva col progetto e alla riapertura c'è ancora; si aggiorna da solo quando cambia il campo (conferma, «Sposta», «Togli»). I progetti già confermati ricevono i gruppi all'apertura del plugin.
- Vista a occhio e «Solo questa» (passo 3): accendono e spengono i gruppi delle istanze e la rete comunale, senza più creare copie in memoria (che si perdevano alla chiusura e non si potevano modificare). La selezione fatta nei gruppi vale per «Sposta in questa istanza» e «Togli dall'istanza».

- Istanze Strade, verifica sul sito ANAS saltata: per alcuni Comuni (Arenzano) il servizio dei dati comunali non dava la regione e la verifica ANAS non partiva; ora la regione si ricava dalla provincia (e se manca il registro lo dice).
- Centri abitati: la classe ANAS (sotto/sopra 10.000 abitanti) vale più della popolazione del Comune. Arenzano ha 11.129 abitanti ma per ANAS il centro abitato è sotto i 10.000: la SS1 resta ANAS anche dentro, con istanze separate «dentro centro abitato» e «fuori centro abitato». La nota del passo 2 non parla più degli abitanti del Comune quando ANAS dà la classe. Con un perimetro del centro abitato senza popolazione vale la classe ANAS. Se gli elementi non hanno il km si prova a ricavarlo dalla geometria ANAS.
- «Usa i tracciati corretti»: tutti i pezzi con la stessa sigla insieme (prima valeva solo l'ultimo: se era un pezzetto, sede e fascia della strada si riducevano lì e le interferenze sparivano); avviso se il tracciato corretto è molto più corto della strada.

## Versione 3.52

- PL Strade: nelle tavole le etichette stampavano ancora il codice HTML (lo stile delle etichette Strade toglieva la lettura dell'HTML). Ora testo pulito, km in nero e lavorazioni in rosso. Verificato su una PL vera (SS1 Arenzano).
- PL Strade: in legenda anche «Punto di ripresa fotografico» e «Sezione», con lo stile dei loro layer.
- Conferma dell'istanza: entrano nel campo IST_… (filtro e vista dell'istanza) anche i pozzetti e gli armadi, nuovi o esistenti, che toccano gli scavi dell'istanza (entro 3 m); prima i pozzetti esistenti restavano fuori dal filtro e quindi dalla PL.
- Etichette in mappa: preparando le «Etichette PL (spostabili)» si spegne il gruppo «Etichette in stampa», che mostrava gli stessi testi e si sovrapponeva.

## Versione 3.51

- Istanze Strade, interferenze mancanti (es. SS1 ad Arenzano: 6 tratte nuove di scavo a 3-46 m dall'asse non trovate): la strada di OSM arriva a pezzi e sede e fascia avevano le estremità di ogni pezzo tagliate dritte, con buchi nelle curve e fra un pezzo e l'altro. Ora i pezzi si uniscono e le estremità sono arrotondate: conta la distanza vera dall'asse. Stesse zone anche per le fasce disegnate in mappa. (Le tratte con TIPOLOGIA vuota sono posa aerea e non sono interferenze di scavo.)

- Etichette in mappa (layer «Etichette PL (spostabili)»): si vedeva il codice HTML (`<div><span style=…>`) al posto del testo; ora km in nero e lavorazioni in rosso, riga per riga. Vale anche per i layer già nel progetto.
- Anteprima di stampa: «PL in PDF» diventa «Anteprima veloce», una finestra che mostra la PL come immagine, una pagina alla volta (la prima subito, le altre con le frecce, «Ingrandisci» per i dettagli), senza creare PDF. Dentro c'è «Salva PDF…» se serve il file: PDF a bassa risoluzione con la barra «pagina n di N» e Annulla.
- PL Strade: la colonnina PTE non va più nei particolari dell'inquadramento (solo istanze Soprintendenza); particolari costruttivi più grandi.
- PL Strade: legenda con le sole tecniche di scavo presenti nell'istanza (con lo stile del progetto) e solo i tipi di pozzetto e armadio usati.
- PL: senza foto niente cornice né titolo FOTO (come per le sezioni); il registro lo dice.
- Tavole numerate da sinistra a destra (tutte le schede, anche i riquadri del passo 5).
- Riquadri in mappa sovrapposti: ogni interferenza va al riquadro col centro più vicino; prima un riquadro tenuto poteva restare vuoto e la sua tavola spariva.
- Vista a occhio: «Aggiorna» e il cambio di vista tolgono tutte le copie (anche quelle rimaste fuori dal registro) e il gruppo vuoto «Vista incrociata».
- Gruppi del progetto: «RFI - basi per le tavole» diventa «Basi per le tavole (PL)» (vale per tutte le schede), in «Altri enti», spento e chiuso.
- «Modifica etichette in mappa»: riepilogo con le etichette create per ogni istanza e, se mancano, il perché (progetto mai salvato, nessuna istanza, avvisi del registro); prima di prepararle si salvano gli spostamenti in corso.

## Versione 3.50

- Pozzetti che a volte non si stampavano (tutte le schede): ora entrano in tavola tutti i pozzetti sugli scavi dell'istanza entro 3 m, nuovi ed esistenti (prima solo gli esistenti: un pozzetto nuovo non preso dall'analisi o non segnato con l'istanza negli shape restava fuori).
- Pozzetti e armadi in tavola sempre disegnati: se nello stile del progetto la loro voce è spenta si riaccende nella copia della tavola, se il tipo non ha una voce (scritto diverso, campo vuoto) si aggiunge «Altri». Prima c'erano ma non si vedevano.

## Versione 3.49

- Istanze Strade, chilometriche per strada: «Layer cippi» e «Campo km» sempre selezionabili (prima erano grigi finché la fonte non era «cippi di questa riga»); scegliere un layer di cippi imposta da solo quella fonte.

## Versione 3.48

- Passo 5 uguale in tutte le schede istanze (RFI, Strade, Acque, Soprintendenza, Parchi): riga «Tavole» con la scala delle tavole PL (spostata qui dal passo 6) e «Calcola numero di tavole (anteprima)», che disegna i riquadri delle tavole in mappa (layer «Tavole PL (riquadri) - <ente>», nel gruppo dell'ente).
- I riquadri delle tavole sono su file (restano nel progetto) e la stampa usa quelli: un poligono cancellato è una tavola in meno, uno spostato sposta la tavola; il registro avvisa se qualche interferenza resta fuori da tutti i riquadri. Senza riquadri la stampa divide da sola come prima.
- Istanze Strade: nella tabella delle strade la nota dice subito se valgono le regole di un ente (es. «REGOLE CITTÀ METROPOLITANA DI GENOVA …»).

## Versione 3.47

- Memoria del lavoro (Ferrovie, Strade, Acque, Soprintendenza, Parchi): se il lavoro delle schede non si salva o non si riprende, ora lo dice (barra gialla di QGIS e registro della scheda) con il motivo; prima l'errore era taciuto e riaprendo il progetto le schede erano vuote.
- Un dato non salvabile non fa più perdere tutta la lista (es. tutte le interferenze): si salvano le altre e l'avviso dice quante mancano. Un salvataggio non riuscito non cancella più quello precedente.
- «Lavoro ripreso dal progetto salvato» compare nel registro di ogni scheda ripresa (prima solo in quello RFI).
- Istanze Strade, regole degli enti: per le provinciali della Città Metropolitana di Genova l'istanza segue le direttive dell'ente: nulla osta dentro i centri abitati sotto 10.000 abitanti (da trasmettere al Comune) e autorizzazione fuori; inquadramento 1:5000 e tavole 1:200 (o 1:100); allegati dell'ente nell'elenco; 1.4 modulo dell'ente (quello per i centri abitati o quello per fuori); 1.5 piano di cantiere a tratte lavorate con superfici e durata; avvisi per minitrincea/microtrincea (profondità minima 1 m) e sopralluogo dei grandi scavi.
- «Carica regole ente…» (avanzate del passo 6 Strade): legge le direttive di un ente da un file .docx/.pdf/.txt, propone i valori riconosciuti da confermare e li salva come regole di quell'ente. «Modulo dell'ente…» allega il modulo Word dell'ente. Scala delle tavole Strade anche 1:100 e 1:200.
- Correzioni nelle tabelle e nei campi delle schede istanze (enti, PEC, spunte…) segnano il progetto come modificato: chiudendo QGIS ti chiede di salvare, prima no e le correzioni si perdevano.

## Versione 3.46

- Pozzetti esistenti (Ferrovie, Strade, Acque e vincoli): quelli sugli scavi dell'istanza (entro 3 m) entrano sempre da soli in tavola. Prima spesso si perdevano: non si aggiungevano con l'istanza confermata negli shape, quando l'istanza non aveva pozzetti nuovi, in Strade e Acque, o se il pozzetto era a più di 1,5 m dallo scavo. Il registro dice quanti ne ha aggiunti.
- Tavole delle istanze ferrovie: calcolo migliorato, meno tavole. Oltre alle colonne lungo la ferrovia il plugin prova a raggruppare le interferenze vicine (anche in diagonale) e sposta i riquadri finché non si toccano; tiene la divisione con meno tavole. Mai più tavole di prima, mai sovrapposte.
- Scala delle tavole RFI spostata al passo 5, accanto a «Calcola numero di tavole»: automatica (il plugin sceglie 1:500, 1:1000 o 1:2000 per tavola, anche miste) oppure 1:500, 1:1000, 1:2000 fissa per tutte.
- «Genera le istanze»: la finestra dei tubi dei particolari costruttivi si apre SEMPRE, con spuntati quelli dell'ultima volta, per ricordarti di controllarli (prima solo se non li avevi mai scelti). Annulla = niente generazione.
- «Anteprima di stampa»: nuovo pulsante «PL in PDF» accanto ad «Apri PL»: esporta la PL in un PDF di anteprima (cartella temporanea, non nel progetto) e lo apre.

## Versione 3.45

- Istanze Acque, canali consortili (bonifica): fascia di rispetto 4-12 m (R.D. 368/1904 dice 4-10 m; 12 per avere margine). Le interferenze si cercano entro 12 m (prima 10), in tavola e in mappa c'è anche il limite dei 4 m (linea a puntini) e la legenda dice «Fascia di rispetto consortile (4-12 m)». I progetti salvati con i vecchi 10 m passano da soli a 12. Fiumi e torrenti del demanio restano a 10 m.

- Tavole delle istanze ferrovie: la scala la sceglie il plugin tavola per tavola, 1:500, 1:1000 o 1:2000 secondo quanto c'è da inquadrare, sempre col minor numero di tavole possibile. Le tavole non si sovrappongono più: si affiancano lungo la ferrovia, e un'interferenza che starebbe intera in una tavola non viene tagliata a metà. Nelle Avanzate si può ancora fissare una scala unica.
- «Calcola numero di tavole (anteprima)»: apre una finestra con una scheda per ogni tavola (numero, scala, istanza, se ha già la sezione) e il riquadro disegnato sulla rete e sulla ferrovia; in mappa i riquadri sono dritti, come in stampa (prima sembravano storti), e riportano la scala.

## Versione 3.44

- Istanze ferrovie, nuove tavole: tavole di dettaglio a 1:1000 (scala «automatica»). Il plugin divide le interferenze di ogni istanza nel minor numero di tavole (un'interferenza più grande di una tavola si spezza) e ogni tavola usa la sezione disegnata dentro il suo riquadro: una sezione per tavola. Una sezione in più nello stesso riquadro ha una tavola sua; una tavola senza sezione lo dice il registro.
- Scheda RFI, passo 5: pulsante «Calcola numero di tavole»: quante tavole ha ogni istanza (quindi quante sezioni disegnare, e quante ne mancano) e i riquadri in mappa («Tavole PL (riquadri) - RFI», nel gruppo RFI, «TAV. n» = tavola n della stampa).
- Inquadramento delle istanze ferrovie: binari ben visibili (nero con tratteggio bianco e bordo bianco) su ortofoto e cartografia; prima si vedevano poco.

- Tavole RFI: con due sezioni vicine ne usciva una sola (le interferenze andavano tutte alla sezione più vicina e l'altra veniva scartata). Ora ogni sezione ha la sua tavola, con le interferenze entro mezza tavola.
- All'apertura del plugin tutti i menu a tendina (riquadri) sono chiusi, anche quelli lasciati aperti l'ultima volta.
- Ogni ente ha i suoi layer, nel suo gruppo di «Altri enti» (RFI, Strade, Acque, Soprintendenza, Parchi e Natura 2000): «Prepara layer Foto e Sezioni» di ogni scheda crea «Punto di Ripresa Fotografico - <ente>» e «Sezioni - <ente>» (la Soprintendenza solo le foto), in 01_File shp\<ente>, con i campi e lo stile dei layer che già usi, e ci sposta i punti e le sezioni che nel layer comune avevano ISTANZA di quell'ente. Le etichette spostabili vanno in «Etichette PL (spostabili) - <ente>» (quelle già spostate passano lì alla prima generazione). Anche i «Coni ruotabili» («Cono di Ripresa (istanze) - <ente>», dai punti dell'ente) e i layer di «Foto e sezioni per un'istanza» vanno nel gruppo del loro ente; quelli già finiti in «Rilievo» con le versioni precedenti si spostano da soli. Prima foto e sezioni finivano in «Comunale», etichette e coni in «Rilievo». Nei progetti dove non premi il pulsante le tavole usano i layer di prima.
- Particolari costruttivi: i tubi li scegli tu al passo 6 di ogni scheda istanze («Tubi nei particolari…»: Fender-4, Fender-5, PEHD Ø125, tritubo Ø50, tubo Ø16, anche più di uno; la scelta resta nel progetto). Prima usciva sempre il Fender-4. Se non li hai scelti, «Genera le istanze» apre l'avviso con la scelta.

## Versione 3.43

- Cono fotografico in tavola: scritta «FOTO n» più piccola (1,6 mm) e sempre di lato al cono, dalla parte opposta a dove punta (prima stava in alto a sinistra e, con il cono verso l'alto o verso sinistra, finiva sopra il cono).

## Versione 3.42

- Cono fotografico in tavola: scritta «FOTO n» in grassetto azzurro con alone bianco, alta 2,3 mm, dritta, in alto a sinistra del punto di ripresa.
- Sezioni sempre in ordine di nome (A-A' prima di B-B'), nelle tavole di tutte le istanze.
- «Modifica etichette in mappa» non fa più partire la barra di caricamento della stampa al passo 6.

## Versione 3.41

- Quote dalla rotaia: il numero sta accanto alla linea, parallelo alla quota (prima finiva sopra la linea), ed è più piccolo (4,5 pt).
- Etichette delle tavole ancora più piccole (5 pt).

## Versione 3.40

- PDF della relazione tecnica (comunale e istanze) con l'avviso «Microsoft Information Protection»: la pulizia della 3.39 rovinava i PDF che il Word dell'utente aveva cifrato (restava solo la pagina d'avviso). Ora i PDF cifrati non si toccano; se c'è LibreOffice il PDF si rifà con LibreOffice, senza etichetta; altrimenti il registro spiega cosa fare (in Word scegliere un'etichetta senza protezione). Se Word cifra anche il file Word, si rimette quello generato dal plugin, leggibile da tutti.
- «Modifica etichette in mappa» non fa più sembrare partita la stampa: niente finestra «Istanze generate» né righe «PDF non creato».
- Etichette delle tavole più piccole (6 pt) con il riquadro bianco più trasparente.
- Tavole RFI: la ferrovia della cartografia (DBSN Ferrovie) non si stampa più, si sovrapponeva al binario dell'istanza.
- Quote dalla rotaia: testo più piccolo (5,5 pt) e frecce più sottili; la linea disegnata si raddrizza da sola (perpendicolare al binario, punta sulla rotaia a metà scartamento dall'asse), anche quelle già disegnate, in stampa.
- Consegna pratiche (comunale): pulsante «Prepara Assegnazione Service»: copia la cartella shape creata (con lo ZIP) e 04_Foto, senza la cartella Autocad, in «Assegnazione Service».

## Versione 3.39

- PDF prodotti con Word (relazione tecnica comunale, relazioni e documenti delle istanze): il plugin toglie l'etichetta di riservatezza Microsoft Purview che Word aggiunge salvando sui PC con Purview attivo. Chi apriva il PDF fuori dall'organizzazione si vedeva chiedere l'accesso a «Microsoft Purview Information Protection». Se il PDF è anche protetto (cifrato) l'etichetta non si può togliere.
- Modelli Word delle istanze (art. 49, Bollo, Modello B): tolta l'etichetta di riservatezza Microsoft Purview rimasta dai file originali. Aprendo i documenti generati, chi non è nell'organizzazione di origine si vedeva chiedere l'accesso a «Microsoft Purview Information Protection».

## Versione 3.38

- PL: binario grigio e bianco più leggero e trasparente; fascia di rispetto più trasparente; cartografia di base della planimetria più trasparente (55%, ortofoto e catasto restano al 70%).
- Armadio FO: allineato allo scavo a cui si aggancia; in legenda il simbolo è centrato.
- Coni fotografici disegnati sotto scavi, pozzetti e armadi.
- Quote dalla rotaia: anche in QGIS, mentre le disegni, si vedono le frecce e la misura (al mezzo metro).

## Versione 3.37

- PL di tutte le istanze altri enti: l'armadio è disegnato con il simbolo FO (assets/simboli/armadio_FO.svg), ruotato con la base verso il pozzetto o lo scavo da cui arriva la rete e staccato dal punto, così non copre scavo né pozzetto.
- PL: con una sezione B-B' la foto è la FOTO 2 più vicina alla sezione (prima la prima trovata, anche in un'altra zona del progetto, e il cono non compariva in tavola).
- Tavole come le pratiche consegnate (tutte le istanze): sezione disegnata come nei disegni CAD, in versione leggera: linea sottile a tratto e punto, tratto finale sottile a ciascun capo, triangolino pieno che guarda nel verso della vista (uguale ai due capi), lettere piccole; nelle etichette il km in nero e le lavorazioni in rosso.
- PL Ferrovie: quote scritte «22,50 m» in rosso, piccole e orizzontali, linea sottile tratteggiata con una freccia piena a ciascun capo; la freccia si ferma sul bordo dell'elemento; fascia con la scritta «FASCIA DI RISPETTO ROTAIE 6-30 M».
- Correzione PL Ferrovie: con una sezione disegnata, tutte le interferenze dell'istanza finivano nella sua tavola anche a chilometri, e la tavola (centrata a metà strada) non mostrava niente. Ora una sezione prende solo le interferenze entro la sua tavola; le altre hanno la loro tavola.
- Tavole delle PL più delicate e leggibili, uguali in tutte le istanze: etichette piccole (7 pt, non grassetto) in un riquadro bianco con bordo grigio sottile e filo di richiamo grigio sottile.
- PL Ferrovie: fascia di rispetto con riempimento leggero in trasparenza, linee tratteggiate e la scritta «FASCIA DI RISPETTO»; quote dalla rotaia **disegnate a mano** (passo 5, «Disegna quote dalla rotaia»: clic sull'elemento, clic sulla rotaia), in tavola sottili in rosso scuro con la distanza al mezzo metro; cono fotografico e sezione più sottili; in tavola solo le etichette del plugin (non quelle del progetto, «MT. 6», «POSA ARMADIO»); etichette posizionate tutte insieme per tavola, senza sovrapporsi fra loro né sopra quote e sezione; armadio semitrasparente e disegnato sotto pozzetti e scavi, spostato di lato con un filo se copre un pozzetto.
- Legenda delle PL (tutte le istanze): niente più sottotitoli dei layer («INFRASTRUTTURE», «POZZETTO»), voci che dicono cosa si vede («Scavo in mini trincea», «Scavo tradizionale», «Pozzetto nuovo 40x76», «Pozzetto esistente», «Armadio ottico»); fascia di rispetto e distanze dalla rotaia nel blocco della ferrovia.
- «Correggi tracciato» / «Usa i tracciati corretti» anche in Istanze Ferrovie (linee ferroviarie) e Istanze Acque (corsi d'acqua), uguale a Strade: al passo 2 il riquadro «Avanzate: il tracciato di … in mappa è sbagliato». La linea corretta resta nel progetto anche dopo un nuovo scaricamento da OSM; in Ferrovie la fascia di rispetto si ricalcola sul tracciato corretto.

## Versione 3.36

- **Correzione importante**: le PL Soprintendenza con il riquadro delle sole foto si fermavano con un errore (dalla 3.34, colonnine PTE). Ora si generano.
- PL di tutte le schede (Ferrovie, Acque, Strade, Soprintendenza, Parchi): cartografia di sfondo, ortofoto ed estratto catastale in trasparenza (70%), così rete, fascia, quote ed etichette si leggono meglio.
- PL istanze Ferrovie, tavole più leggere: la fascia di rispetto è appena campita con il bordo tratteggiato più chiaro e si vede anche su ortofoto ed estratto catastale; la linea della sezione è in trasparenza (le lettere restano piene); pozzetti e armadi un po' più piccoli e gli armadi sopra i pozzetti; etichette a 7 pt invece di 8.
- PL istanze Ferrovie, quote: in planimetria la distanza di pozzetti e armadi (esistenti e di progetto) e del punto di ogni scavo più vicino alla ferrovia dalla rotaia più vicina, in proiezione orizzontale e ortogonale al binario (rotaia stimata a mezzo scartamento, 0,72 m, dall'asse del binario OSM). Linea con frecce e misura in metri al mezzo metro più vicino (14,2 m → 14 m, 14,3 m → 14,5 m), voce «Distanza dalla rotaia più vicina» in legenda; oltre 40 m nessuna quota.

## Versione 3.35

- Canaletta VTR nelle relazioni delle istanze (RFI, Acque, Strade, Soprintendenza, Parchi): prima la TIPOLOGIA «Canaletta» veniva scartata come la linea aerea. Ora conta: colonna «Canaletta VTR» in tabella scavi e cronoprogramma (solo quando c'è, le altre relazioni restano uguali), resa «Posa canaletta VTR» nelle rese, niente ripristino del manto, paragrafo «CANALA IN VTR/FeZn PER VIADOTTI, CUNICOLI E GALLERIE» solo se serve, particolare PC-13 in PL, etichetta «POSA CANALETTA VTR». In RFI una canaletta che attraversa la ferrovia resta da decidere a mano; in Acque è trattata come passaggio sul manufatto.
- Riconosciute anche le scritte col trattino o il trattino basso: «Micro-trincea», «Mini-trincea», «MINI_TRINCEA», «No  Dig» (prima «Micro-trincea» veniva scartata).
- Relazione comunale: il paragrafo «CANALA IN VTR/FeZn» resta solo se nella tabella scavi c'è la canaletta.
## Versione 3.34

- Istanze Soprintendenza, passo 6: «Colonnine PTE nuove come elementi fuori terra (insieme agli armadi)», facoltativo. Le colonnine nuove del layer ROE PTE (TIPO «Colonnina» con il flag NewColonnina) sono trovate nelle aree e, se spuntate, contano come gli armadi: autorizzazione, relazione paesaggistica, planimetria («AREA COLONNINA PTE», colonnina disegnata dal layer ROE PTE) e «Solo armadi». Non spuntate restano fuori dall'istanza. Nella relazione tecnica (RT) c'è il paragrafo «COLONNINE PTE» dopo quello dell'armadio, solo se l'istanza ha colonnine.
- Istanze Soprintendenza, passo 6: «Aggiungi particolare costruttivo colonnina» mette nella tavola PC il nuovo particolare PC-20 (colonnina PTE con zoccolo di ancoraggio quotato), anche con la cartella dei particolari dell'utente. Le due spunte si ricordano nel progetto.
- Leggimi e tutorial aggiornati.

## Versione 3.33

- Schede istanze (Strade, RFI, Acque, Soprintendenza, Parchi): 6 passi invece di 5. Passo 5 «Foto, sezioni ed etichette» (quello che si disegna in mappa: layer Foto e Sezioni, coni ruotabili, foto per un'istanza, «Modifica etichette in mappa»); passo 6 «Stampa: genera le istanze» (scelte dei documenti, avanzate, Anteprima, Genera, Apri cartella e registro).
- Istanze Strade, passo 2: il tracciato OSM sbagliato si corregge in mappa (riquadro «Avanzate: il tracciato di una strada in mappa è sbagliato»: «Correggi tracciato», strumento vertici, «Usa i tracciati corretti»). La correzione resta nel progetto anche dopo un nuovo «Trova».
- Particolari costruttivi: cartella vuota = particolari del plugin; cartella compilata = solo i file dell'utente (PARTICOLARE-1, «particolare costruttivo 2»…, in ordine di numero). Nessuna cartella si ricorda più fra progetti diversi.
- Vista istanze: l'occhio si clicca; la trasparenza vale davvero per la rete comunale, con le istanze piene sopra; messaggio chiaro quando non c'è ancora nessuna istanza confermata.
- Verifica interferenze: opere e fasce di rispetto in un gruppo solo «Verifica interferenze»; il pannello scorre invece di sovrapporre le scritte.
- Consegna pratiche: nuovo riquadro «Shape per istanza» (una cartella con gli shape e lo ZIP per ogni istanza spuntata).
- «Scala delle tavole PL» al passo 6 di tutte le schede istanze (prima solo RFI): «automatica (consigliata)» = come prima (Strade A1 1:500, Acque/Soprintendenza/Parchi/Strade A3 calcolata, RFI 1:2000) oppure 1:500, 1:1000, 1:2000, 1:5000 per tutte le tavole.
- Leggimi e tutorial aggiornati.

## Versione 3.32

- Schede istanze, passo 5: un solo pulsante «Modifica etichette in mappa» (acceso = etichette in mappa da spostare, spento = salvate); «Etichette accorpate» nelle Avanzate; riga «Stampa» con Anteprima, Genera e Apri cartella.
- Chilometriche (RFI e Strade): scelta esplicita «Da dove prendo il km» per linea/strada (automatico, cippi OSM, layer cippi, solo coordinate) e colonna «Risultato» che spiega a parole com'è andata.
- Foto e sezioni per una sola istanza: pulsante «Foto e sezioni per un'istanza» (layer «… - <istanza>», usati dalle sue PL).
- Foto nelle PL: riconosciute anche «FOTO_01», «Foto 2 via…», «3.jpg» (anche in sottocartelle); se nessuna foto è vicina alla sezione si usa la più vicina dell'istanza; le cartelle foto e sezioni si ricordano per progetto (prima restavano quelle di un altro progetto).
- Particolari costruttivi dalla cartella dell'utente riconosciuti dal nome del file (Trincea, PC-07, pozzetto 40x76…).
- PL: stessa scala per ortofoto, planimetria e catasto (1:2000, scelta nelle Avanzate), scavi e rete sull'estratto catastale.
- RT: niente più nota «*Particolari costruttivi…» ripetuta. Modello B RFI: tolta la riga «PROGETTO BANDA ULTRALARGA. PIANO ITALIA 1 GIGA – AREE GRIGIE» («Oggetto: …» su una riga).
- Vista istanze: pulsante «Dividi per gruppi» (progetto comunale nel gruppo «Comunale», istanze in «Altri enti»; cartografie comuni fuori); «Solo comunale» filtra i layer veri senza copie; trasparenza della rete comunale; il pannello Layer non si apre più a ogni clic.
- Verifica interferenze (Comune): fasce di rispetto disegnate subito; tratte escluse contate e visibili («Mostra le escluse»), TIPOLOGIA vuota non più esclusa di nascosto; pannello a tabella con filtri, esito su più righe insieme e contatori; esportazione Excel.
- Analisi armadi: esito «Spostato», «Sposta l'armadio», «Vedi dove era prima», «Rimetti dove era», nuovo indirizzo; Excel con vecchio/nuovo indirizzo e link al punto esatto.
- Suolo comunale: coni per tavola da 3 a 6 (anche la numerazione delle foto).
- Regola 1: presa la tratta nuova verso il PTE Light Diramatore anche quando la delivery arriva al nodo prima.

## Versione 3.31

- Schede istanze: pulsante «Coni ruotabili» accanto a «Prepara layer Foto». Crea i coni delle foto come poligoni (layer «Cono di Ripresa (istanze)», come nel Suolo comunale): si girano con «Ruota elementi» vedendo l'anteprima e, salvando il layer dei coni, la rotazione va nel campo Rotazione dei punti di ripresa.

## Versione 3.30

- PL (RFI, Acque, Soprintendenza, Parchi): sull'estratto catastale ora si vedono gli scavi, i pozzetti e gli armadi dell'istanza (e la ferrovia nelle RFI), disegnati sopra l'immagine del catasto come sull'ortofoto.

## Versione 3.29

- Chilometriche RFI con cippi radi: si usano il cippo più vicino e il più vicino coerente con lui (km in proporzione alla distanza), anche a qualche km; prima con cippi oltre 1,5 km l'uno dall'altro restava tutto «da compilare». Si prosegue oltre i cippi fino a 3 km.

## Versione 3.28

- Regola 1: presa anche la tratta nuova che va dal PTE Light Diramatore al nodo raggiunto dalla delivery (anche quando ci arrivano le tratte sul civico). Prima restava fuori se la catena si fermava al nodo prima del PTE.
- Etichette spostabili: lo stile aggiornato si applica anche all'apertura del progetto e del plugin, non solo con «Prepara etichette».

## Versione 3.27

- PL istanze RFI: ortofoto, planimetria ed estratto catastale alla STESSA scala e sullo stesso punto, uguale in tutte le tavole (1:2000; si cambia in «Scala delle tavole PL» nelle Avanzate del passo 5). Tolti i pallini rossi da ortofoto e catasto.

## Versione 3.26

- Istanze RFI: i binari OSM senza nome né numero (stazioni, scali, raccordi) non diventano più linee «fantasma» con le loro interferenze. Entro 60 m da una linea con nome ne prendono nome, numero e gestore; i raccordi industriali e i binari isolati si ignorano (il registro dice quanti). A Terni: 128 tratti senza nome, ora restano le 2 linee vere.

## Versione 3.25

- Istanze RFI: il gestore si cambia con un menu (o scrivendolo) nella tabella delle linee (vale per tutta la linea, resta nel layer «Ferrovia RFI») e nella tabella delle interferenze (vale per quella riga). Il nuovo gestore entra subito fra i destinatari.

## Versione 3.24

- PEC delle DOIT RFI di Napoli, Milano, Bari e Trieste allineate a quelle pubblicate da RFI.

## Versione 3.23

- Istanze RFI: l'indirizzo della DOIT competente si compila da solo (15 sedi, fonte rfi.it). Un indirizzo scritto a mano non viene cambiato; la PEC già nota resta quella.

## Versione 3.22

- Etichette in mappa: testo centrato sopra il punto senza coordinate calcolate (con il CRS del progetto diverso da quello del layer il testo finiva lontano dal filo).
- PL RFI: niente più etichette di solo km («KM 96+974» dove lo scavo entra in fascia): il km sta nell'etichetta dello scavo.
- «Anteprima di stampa» rifà prima le PL con le etichette dove le hai spostate.
- Tutorial: scheda «Vista istanze» e passo 5 delle schede istanze.

## Versione 3.21

- Istanze RFI, «Calcola le chilometriche»: il plugin non aggiunge più campi agli shape aperti (dava «Errore OGR nell'impostare l'elemento» su 02_POZZETTO e i pozzetti sparivano); scrive il km solo in un campo di testo Chilometrica (o KM_RFI) che c'è già.
- Passo 5 delle schede istanze: «Salva posizione etichette» e «Anteprima di stampa» (PL nel compositore di stampe di QGIS, RT nel programma predefinito).

## Versione 3.20

- PL (RFI e Acque): la foto della tavola segue la sezione: Sezione A-A' → FOTO 1, B-B' → FOTO 2, e così via (dell'istanza o senza istanza); se quel numero manca, la foto più vicina alla sezione.

## Versione 3.19

- Etichette spostabili: in mappa il testo è centrato sul punto come in stampa (prima stava con l'angolo sul punto e in stampa usciva spostato di mezza etichetta).

## Versione 3.18

- PL (RFI e Acque): una sola foto per tavola, quella più vicina alla sezione della tavola, cercata anche appena fuori dal riquadro (prima: due foto affiancate o nessuna).
- PL RFI: i pozzetti esistenti in tavola sono solo quelli dell'istanza; quelli tolti e messi sul suolo comunale non si stampano.

## Versione 3.17

- Esportazione: SCAVI_STRADE e POZZETTI_STRADE uscivano senza elementi quando la Distanza max join era piccola (es. 3 m): la pulizia dei doppioni cancellava anche gli elementi senza strada vicina. Ora si tolgono solo i doppioni; gli elementi senza strada restano con la via vuota e il registro li conta.

## Versione 3.16

- Esportazione (join dei 3 shape): ogni shape scritto si riapre e si controlla; se mancano elementi o valori si riscrive come testo semplice e il registro lo dice (segnalati shape con la tabella attributi vuota).

## Versione 3.15

- Etichette spostabili: niente più doppioni (a ogni preparazione o generazione restano solo le etichette di quel giro, comprese quelle spostate a mano); il testo è legato al punto: si sposta con «Sposta elemento» e testo e filo vanno sempre insieme.

## Versione 3.14

- Corretto: dopo «Prepara le etichette in mappa» le PL non si esportavano più in PDF fino al riavvio di QGIS («planimetria: NON esportata»).

## Versione 3.13

- Etichette in mappa: il testo è centrato sul punto (dove arriva il filo) ed è sempre visibile; prima QGIS lo spostava o lo nascondeva e i fili sembravano staccati.
- Interferenze: con «Escludi» l'interferenza sparisce subito anche dalla mappa (punto, scavi e pozzetti trovati) e non si ridisegna al ricalcolo.

## Versione 3.12

- Selezione, regola 3: si selezionano solo i pozzetti con STATO = Esistente toccati solo da infrastruttura esistente (prima entravano anche i pozzetti di nuova posa, spesso con un PTE).

## Versione 3.11

- Foto (tutte le schede istanze): il cono si gira con lo strumento di QGIS «Ruota simboli puntuali». «Prepara layer Foto e Sezioni» lega l'angolo al campo Rotazione; i valori già scritti crescono di 90° così i coni non cambiano direzione.

## Versione 3.10

- Etichette in mappa: ogni etichetta ha il filo di richiamo fino al suo elemento, per spostarle sapendo a cosa si riferiscono.
- Regola 1 (rete di delivery civico → PTE): il percorso segue anche le tratte che finiscono a metà di un'altra (incrocio a T, spesso dove cambia la tipologia); prima si interrompeva e le tratte verso il PTE si perdevano.
- Icona della scheda «Vista istanze».

## Versione 3.9

- Schede istanze, passo 5: «Prepara le etichette in mappa» calcola le tavole e mette le etichette nel layer «Etichette PL (spostabili)» senza creare documenti; le sposti, poi «Genera le istanze» le stampa lì.
- Casella «Etichette accorpate»: spuntata come finora (scavo e pozzetti insieme se manca spazio), senza spunta un'etichetta per elemento.
- Moduli: le etichette lunghe dei campi vanno sopra il campo invece di essere tagliate (es. Unisci tratte).

## Versione 3.8

- Istanze Strade: «*» sugli attraversamenti e nota sulla trincea tradizionale solo per le istanze ANAS; per gli altri enti con la nuova casella nelle Avanzate del passo 5.
- PL A1 Strade: niente cornici vuote con il nome dove la sezione non c'è.

## Versione 3.7

- RT: tabella «POSA ARMADI» con la stessa grafica della tabella pozzetti (ubicazione al km, ARLO, totale), dopo la nota dei pozzetti.
- Chilometrica negli shape: se il progetto ha già un campo Chilometrica numerico, il km RFI va nel campo di testo KM_RFI (prima: errori OGR su 02_POZZETTO).

## Versione 3.6

- Chilometriche RFI: i cippi con la linea scritta «Bari – Taranto» valgono per «Bari-Taranto» (prima, dopo l'unificazione dei nomi, non venivano più contati).
- DOIT, indirizzo e PEC di RFI: se la regione non è nota (progetto riaperto) si ricava dal comune.

## Versione 3.5

- RT (RFI e Acque): paragrafo «POSA ARMADI» con la tabella degli armadi in fascia, dopo i pozzetti.
- Destinatario RFI: DOIT, indirizzo e PEC proposti anche a progetto riaperto.
- PL RFI: con sezioni disegnate, una tavola per sezione con le interferenze vicine e la scala adattata perché entri tutto.
- PL RFI: pozzetti esistenti in planimetria e in legenda.
- Una sola linea anche se OSM scrive il nome con trattini diversi («Bari – Taranto» / «Bari-Taranto»).

## Versione 3.4

- Istanze doppie nella vista per istanza («Linea X - Tipo D» e «Linea X - Tipo D - Stazione»): confermando un'istanza, dagli shape e dal registro escono i nomi vecchi della stessa istanza.
- PL: ogni sezione va in una sola tavola (la più vicina); tavole in più solo se una stessa interferenza ha più sezioni dei posti in tavola.

## Versione 3.3

- Etichette delle PL spostabili in mappa (tutte le schede istanze): dopo la generazione ogni etichetta è un punto del layer «Etichette PL (spostabili)» (01_File shp/FTTH_etichette_PL.gpkg); spostato il punto, la PL successiva mette l'etichetta lì.
- Foto e Sezioni: numero (FOTO n) e lettera (A-A') ripartono per ogni istanza; l'istanza proposta è quella dell'ultimo elemento disegnato.
- Chilometriche RFI: oltre i due cippi più vicini il km prosegue (prima restava quello del cippo più vicino); campo Chilometrica scritto negli shape come in Istanze Strade.
- RFI: gli armadi in fascia entrano nella descrizione dei lavori (oggetto, Modello B, RT).
- PL: tavole in più solo per le sezioni con ISTANZA compilata (niente pagine in eccesso).

## Versione 3.2

- Occhi della vista per istanza: «Solo suolo comunale» non spegne più tutto (la vista si vede anche col gruppo Istanze spento); icona dell'occhio sempre visibile.
- Tabelle delle interferenze (tutte le schede): «Conferma» / «Escludi» su ogni riga.
- RFI: stazioni e cippi riletti dai layer se mancano nello stato (niente più istanze «TipoD_1», «TipoD_2» al posto della stazione).

## Versione 3.1

- Memoria del lavoro: layer del plugin in 01_File shp/FTTH_lavoro.gpkg e stato delle schede istanze in <progetto>_FTTH_lavoro.dat, ripresi alla riapertura del progetto.
- Nuova scheda Altri Enti > Vista istanze: occhi incrociati su suolo comunale, strade per famiglia (SS, SP…), linee, corsi d'acqua, aree.
- Nomi delle istanze senza «—» negli shape (diventava «?» e le tratte uscivano dall'istanza: scavi mancanti in tabella, rete comunale e legenda grezza in PL). La PL non stampa mai la rete intera.
- Chilometriche RFI: campo km dei cippi scelto da solo (non più «fid»).
- Testi delle istanze senza spazi inutili; barra di avanzamento su «Genera le istanze» in tutte le schede.

## Versione 3.0

### Schede istanze: stessi 5 passi e stessa grafica (18/11)

- Strade, RFI, Acque, Soprintendenza e Parchi hanno gli stessi passi, con gli
  stessi titoli: 1) Comune · 2) … toccati dal progetto · 3) Interferenze:
  controlla e conferma · 4) Enti e destinatari · 5) Foto, sezioni e
  generazione. Prima RFI ne aveva 6 e ogni scheda li chiamava a modo suo.
- Passo 2 uguale ovunque: pulsante «Trova … e gli enti», righe proposte in
  giallo e non spuntate con «Conferma» / «Escludi» (anche in Acque,
  Soprintendenza e Parchi, che prima spuntavano da sole; in Strade «Scarta»
  diventa «Escludi»). Le altre fonti (layer del progetto, disegno a mano,
  fasce) stanno nelle «Avanzate», chiuse, in fondo al passo.
- Passo 3: «Conferma e vista per istanza» è dentro il passo in tutte le schede;
  in Strade e RFI le chilometriche con i cippi sono un riquadro del passo 3.
- Passo 4: indirizzo e PEC del Comune in e.p.c. stanno qui in tutte le schede
  (prima erano al passo 1).
- Passo 5: «Prepara layer Foto e Sezioni» in alto, opzioni principali, poi le
  «Avanzate» (PDF, cartelle, rese, loghi) e infine «Genera le istanze» e «Apri
  la cartella», sempre con lo stesso pulsante evidenziato.
- Leggimi: i 5 passi sono descritti con lo stesso testo in ogni scheda.
- Accanto a «Trova …» (passi 2 e 3) in tutte le schede solo barra e
  «Interrompi». «Riscarica da OSM» (RFI) e «Salva i layer della scheda…» (RFI,
  Acque; prima «Salva layer RFI…» / «Salva nel progetto…») sono nelle
  Avanzate del passo 2. Tolto «Zoom sulla riga selezionata»: lo zoom è il
  doppio clic sulla riga, ovunque. Acque usa la stessa barra delle altre schede
  e ha un solo riquadro Avanzate al passo 2.
- Stesse intestazioni (Incl., N.) e stesse frasi di aiuto ai passi 3, 4 e 5 in
  tutte le schede; «Tratti nelle tabelle RT» anche in Strade.

### Foto e sezioni per istanza, sezioni per tavola, aerea (18/11)

- Layer «Punto di Ripresa Fotografico» e «Sezioni»: nuovo campo ISTANZA, con
  la tendina delle istanze confermate in tutte le schede (per RFI anche solo
  la linea). Vuoto = il punto vale per tutte le istanze. Nella PL di
  un'istanza entrano solo i suoi punti e le sue sezioni (e quelli senza
  istanza): nello stesso progetto ci possono essere due «FOTO 1» o due «A-A'».
  «Prepara layer Foto e Sezioni» aggiunge il campo anche ai layer già fatti.
- File di foto e sezioni: si cercano prima nella sottocartella con il nome
  dell'istanza (04_Foto/SP28/FOTO-1.jpg, 05_Sezioni/<linea>/SEZIONE A-A'.svg),
  poi nella cartella come prima. «Prepara layer Foto e Sezioni» crea le
  sottocartelle delle istanze confermate.
- La PL rispetta quante sezioni entrano in una tavola (1 in RFI, Acque,
  Soprintendenza e Parchi; 4 nella PL A1 Strade): con più sezioni nello stesso
  riquadro si aggiunge una tavola per ognuna, inquadrata sulla sezione, con
  solo quella in planimetria. Prima le altre si vedevano in planimetria senza
  il loro disegno.
- Istanze RFI: la posa aerea (TIPOLOGIA aerea/aereo) e le tratte nuove senza
  scavo non sono più interferenze (prima: «tipo ?»).

### Correzioni dalle prove RFI (18/11)

- «Genera istanze» non si ferma più con «Manca python-docx» sui PC dove non è
  installato: la libreria è dentro il plugin (cartella ext_libs; se sul PC
  c'è già, si usa quella).
- Istanze RFI, punto 2: le linee trovate sono solo proposte (in giallo, senza
  spunta) con «Conferma» ed «Escludi» come in Istanze Strade.
- Istanze RFI: cambiando la tipologia in tabella, in mappa si aggiornano
  subito punto e scavi/pozzetti dell'interferenza (attributo ed etichetta).
- Istanze RFI: barra di avanzamento su «Calcola le chilometriche».
- Vista per istanza (tutte le schede istanze): gli occhi non facevano niente
  (errore interno). Ora ogni istanza e il «Suolo comunale» hanno un pulsante a
  occhio (verde = visibile, grigio = nascosta), «Solo questa» e «Mostra tutto».

### Fasce di rispetto per ente, Leggimi normativi, ricerca vie più robusta

- Fasce di rispetto: enti organizzati per titolare (ANAS, Autostrade,
  Provincia/Regione, Comune, Muri di cinta, RFI, Acque, Altro) con un titolo
  per gruppo. La distanza dipende dal tipo CdS: ANAS ha B e C fuori c.a., zona
  edificabile e ora anche dentro il centro abitato (D/E/F, con la nota sulla
  competenza ANAS solo nei comuni sotto i 10.000 abitanti, art. 2 c.7 CdS).
  Riferimenti normativi rivisti (art. 26 e 28 DPR 495/92, DPR 753/80 art. 49,
  R.D. 523/1904 art. 96, R.D. 368/1904 art. 133, R.D. 1265/1934 art. 338).
- La distanza segue sempre l'ente scelto: prima la memoria delle impostazioni
  rimetteva l'ultima usata (es. 30 m con ANAS tipo B).
- Shape sorgente: viene proposto solo un layer coerente con l'ente e con
  elementi nella zona della rete (non più «DBSN Aree verdi» come strada, né lo
  stradario di un'altra regione). Se nel progetto non c'è, «Scarica da OSM»
  prende ferrovie, corsi d'acqua o strade classificate nella zona della rete.
- Nuovi «Leggimi» con norme e istruzioni nelle schede Soprintendenza, Parchi /
  Natura 2000, Acque, RFI e Fasce di rispetto. Accanto a «Soglia VIncA per
  via» c'è «Cosa significano?».
- Soprintendenza e Parchi: la ricerca non si ferma più al 97% («nomi delle
  vie»). La richiesta a OSM toccava l'interfaccia da un thread separato. Ora i
  nomi si prendono prima dallo stradario del progetto, poi da OSM con attesa
  massima di 60 s e cache di 30 giorni. Corretto lo stesso problema in Istanze
  Strade.
- Soprintendenza: nuova scelta «Cosa mettere nell'istanza».
  - «Tutto»: come finora.
  - «Proposta dal vincolo»: si decide area per area dal vincolo SITAP. Con
    l'art. 142 (tranne le lett. g e m) entrano solo armadi e mini/microtrincea,
    perché scavi, no-dig e pozzetti interrati sono esclusi dal DPR 31/2017,
    All. A, A.15. Con archeologia, art. 136, centri storici e boschi entra
    tutto.
  - «Scelta manuale»: caselle per trincea, no-dig, pozzetti, armadi e
    mini/microtrincea.
  - Gli interventi rimasti senza elementi escono dall'istanza; il registro dice
    quanti e perché.
- Leggimi: tabella «quale vincolo, quali elementi» con la colonna no-dig e, in
  tutte le schede, l'elenco delle fonti con i link a Normattiva. Nuovo Leggimi
  per Istanze Strade (enti, competenza nei centri abitati, CdS art. 21 e 25,
  art. 49 D.Lgs. 259/2003, microtrincea). In Parchi il Leggimi è solo in testa
  alla scheda, come nelle altre.
- Leggimi RFI: specchietto delle tipologie di interferenza A, B, C, D (quando,
  sopralluogo, allegati) e casi particolari. Leggimi Strade: cosa prende il
  plugin dal sito ANAS (tratte gestite, Struttura territoriale e PEC, centri
  abitati con classe di popolazione, km della statale).
- Soprintendenza, vincolo archeologico (aree archeologiche, art. 142 lett. m):
  oggetto, premessa e bollo parlano di «aree di interesse archeologico» (o di
  tutela paesaggistica e archeologica se ci sono entrambi i vincoli); con soli
  vincoli archeologici la Relazione paesaggistica (Allegato D) non si genera.
  Il LEGGIMI dell'istanza e un avviso finale ricordano che la relazione
  archeologica (VPIA) va firmata da un archeologo abilitato. Nel Leggimi della
  scheda: tabella «Relazione paesaggistica o archeologica?» con le fonti.
- Nuovo strumento «Un gruppo di layer per ogni istanza» in Strade, Acque,
  Ferrovia, Soprintendenza e Parchi: dopo aver confermato le interferenze crea
  nel progetto «Istanze > sezione > istanza» (es. «Istanze > Strade > SS45 —
  ANAS S.p.A.») con le sole tratte, pozzetti e armadi di ogni istanza, copiati
  con lo stesso stile nel file 01_File shp\Istanze.gpkg. I layer principali non
  si toccano: un solo progetto per tutte le istanze. «Aggiungi la selezione al
  gruppo» copia nel gruppo altri elementi selezionati nei layer principali. La
  PL disegna il contenuto del gruppo. Alla generazione gli elementi aggiunti si
  contano come quelli trovati dalla ricerca, in PL e RT: entra l'interferenza
  che la ricerca ha calcolato per loro (solo i metri dentro sede, fascia o area,
  con la progressiva km), anche se la riga non era spuntata; quelli tutto fuori
  contano 0 m e restano solo in tavola; un'interferenza già in un'altra istanza
  non si conta due volte. Il log della generazione dice cosa è entrato.
- Istanza comunale, parte export: nuovo riquadro «Cartella di consegna shape».
  Un pulsante crea una cartella (e lo ZIP) con gli shapefile di tutti i layer
  del gruppo «Ottico» e di INFRASTRUTTURE, POZZETTO e ARMADIO OTTICO, anche se
  nel progetto sono GeoPackage; codifica UTF-8, stesso sistema di riferimento,
  layer del progetto non toccati. Il log segnala i campi accorciati dallo
  shapefile (nomi oltre 10 caratteri).
- Istanze Strade, flusso uguale per tutte le schede (primo passo):
  - 2) sotto la tabella delle strade: «Seleziona tutte», «Nessuna», «Solo i
    proposti», «Mostra in mappa» (layer «Strade trovate» nel gruppo Istanze >
    Strade > Trovati, con sigla ed ente) e zoom col doppio clic; nuovo
    riquadro «Altre fonti» per aggiungere strade da un layer di linee del
    progetto (sigla e nome), letto solo attorno alla rete;
  - 3) Interferenze (prima era il 4): «Mostra in mappa» di scavi, pozzetti e
    armadi delle interferenze spuntate, zoom col doppio clic;
  - 4) Progressive chilometriche, dopo le interferenze: una riga per strada
    con fonte delle progressive (come tutte, cippi, campo Chilometrica, solo
    coordinate), layer e campo dei cippi per quella strada, riferimenti utili
    e stato; «Ricalcola le progressive» rifà la ricerca con quelle scelte e
    lascia le spunte delle interferenze. Lo strumento che scrive il campo
    Chilometrica sui layer è dentro questo passo.
- Istanze Ferrovia, stesso flusso di Strade:
  - 2) «Trova le ferrovie e gli enti» (era «Scarica ferrovie, cippi e
    stazioni»): tabella con una riga per linea (gestore, destinatario, metri di
    rete nella fascia, distanza minima, fonte), proposte le linee con rete in
    fascia; stessi pulsanti, «Mostra in mappa» (layer «Ferrovie trovate») e
    zoom col doppio clic; «Altre fonti» aggiunge le linee da un layer del
    progetto (nome e gestore), che sostituiscono quelle OSM con lo stesso nome.
    I destinatari del punto 5 si compilano già qui;
  - 3) Interferenze: si cercano solo le linee spuntate; «Mostra in mappa» di
    scavi, pozzetti e armadi, zoom col doppio clic (sulla colonna Foto resta la
    scelta della foto);
  - 4) Progressive chilometriche per linea (i cippi del progetto lasciano il
    punto 2): cippi OSM, layer di cippi per tutte le linee o per una sola, oppure
    nessuno; si usano i cippi sulla linea (entro 150 m) quando sono almeno due,
    così una linea vicina non sporca i km. «Ricalcola le progressive» tiene
    spunte, tipologie, proprietario e foto, e i destinatari corretti a mano.
- Quadro pratiche: «Aggiorna» rilegge lo screening dal progetto aperto; se il
  progetto non ne ha, il quadro si svuota. Prima restava quello del progetto
  precedente. Lo stesso succede da solo quando apri o chiudi un progetto con
  la finestra del plugin aperta.
- Istanze Ferrovia: tolto «Precompila dallo screening territorio», che faceva
  lo stesso di quando scrivi il comune (provincia, CAP, regione e DOIT RFI);
  ora il punto 1 è uguale alle altre schede.
- Altri Enti › Consegna pratiche › Altri strumenti: tolti il join dei 3 shape
  (ARMADI_FOTO, SCAVI_STRADE, POZZETTI_STRADE) e la «Cartella di consegna
  shape», che servono solo all'istanza comunale e restano in Comune ›
  Esportazione. Tolta anche l'evidenza delle strade interessate: restano
  «Esporta PDF (Atlante)» e «Unisci PDF».
- Istanze negli shape del progetto, al posto dei gruppi di copie (Istanze >
  sezione > istanza in Istanze.gpkg): «Scrivi le istanze negli shape» compila
  in 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO un campo per scheda
  (IST_STRADE, IST_ACQUE, IST_FERROV, IST_SOPR, IST_PARCHI) con il nome
  dell'istanza («SP28», «Canale San Marco»; due istanze separate da «; »).
  «Mostra solo questa» spegne i layer principali e mostra solo gli elementi
  dell'istanza (vista filtrata, i layer principali restano senza filtri);
  «Mostra tutto» torna alla vista normale. «Aggiungi la selezione» scrive
  l'istanza sugli elementi selezionati; alla generazione si contano come
  prima e la PL disegna gli elementi con quel nome.
- Istanze Strade, punto 2 più snello: le strade si leggono prima dallo
  stradario del progetto (trovato da solo, es. «Stradario Provincia Italia»:
  pochi secondi), OSM solo se nel progetto non c'è. Le strade proposte (rete
  entro 50 m) sono evidenziate in giallo e subito in mappa ma NON spuntate:
  per ognuna «Conferma» (chiede l'ente, poi riga verde e spuntata) o «Scarta».
  Se OSM non risponde il messaggio suggerisce lo stradario del progetto.
- Tutte le schede istanze, sotto le interferenze, riquadro «Conferma e vista
  per istanza»: «Conferma le interferenze spuntate» scrive il campo
  dell'istanza (IST_STRADE, IST_ACQUE, …) negli shape principali; sotto, un
  occhio per ogni istanza letta dal campo e uno per il «Suolo comunale» (il
  resto della rete): spento l'occhio, in mappa spariscono le sue tratte,
  pozzetti e armadi (vista con copie in memoria, i layer principali non si
  filtrano); «Mostra tutto» torna normale; la vista vale anche a progetto
  riaperto.
- «Crea il layer cippi» in Istanze Strade e in Istanze Ferrovia: crea accanto
  al progetto «Cippi_Chilometrici» (strada, km) o «Cippi_Ferrovia» (linea,
  km), lo mette in mappa in modifica con lo strumento «aggiungi punto», con
  l'etichetta «SP28 km 12+300», e lo sceglie già per il calcolo. Nel modulo
  la strada o la linea si sceglie da una tendina: strade confermate al punto
  2, linee delle interferenze; la tendina si aggiorna quando ne confermi
  altre. Nel calcolo ogni cippo vale solo per la sua strada o linea. In
  Ferrovia il pulsante si chiama ora «Calcola le chilometriche».
- Istanze Strade, chilometriche ed etichette:
  - «Calcola le chilometriche delle tratte» ha la sua barra di avanzamento;
  - scelti i cippi (progetto, OSM o entrambi) il calcolo li usa sempre: prima
    un «Dal campo Chilometrica» ricordato nelle avanzate li faceva ignorare;
  - dopo il calcolo negli shape vanno i campi Chilometrica ed ETICHETTA (il
    testo esatto della tavola, es. «KM 10+315 / POSA POZZETTO 40x76»); il
    nome del campo esistente si riusa, sugli shapefile si accorcia a 10
    caratteri;
  - in mappa il gruppo «Istanze > Strade > Etichette in stampa» mostra le
    etichette come in stampa (copie collegate agli shape);
  - correggi Chilometrica o ETICHETTA nello shape e alla generazione vale la
    correzione, in RT e in PL (le tratte con più scavi tengono il calcolo);
  - lo strumento Etichette sparisce: resta la grafica delle etichette
    (dimensione, riquadro) nelle avanzate del punto 4, uguale in mappa e in
    stampa;
  - i punti 5 e 6 diventano «5) Foto, sezioni e generazione», con «Prepara
    layer Foto e Sezioni» in vista (non più nelle avanzate). Il comando c'è
    in tutte le schede istanze.
- Correzioni in mappa, in tutte le schede istanze: selezioni scavi, pozzetti o
  armadi (sui layer principali o nella vista), scegli l'istanza (strada,
  linea, corso d'acqua, vincolo, parco) e «Sposta in questa istanza», oppure
  «Togli dall'istanza». Il campo negli shape si aggiorna subito (con la
  vista e i conteggi) e alla generazione l'interferenza segue: gli elementi
  tolti escono con i loro metri e pozzetti, un'interferenza senza più elementi
  esce dall'istanza, gli elementi spostati entrano nell'istanza nuova con i
  soli loro metri (prima un elemento di un'altra strada veniva scartato).
  Deruta: 5 m di trincea spostati da SP377 a SP419, un pozzetto tolto.
- Istanze Strade più snella:
  - titoli dei passi con lo stato («2) … — 1 da confermare, 2 confermate»,
    «3) … — 13 interferenze, 13 spuntate», «4) … — km ok su 1 di 2 strade»);
  - opzioni usate di rado in riquadri «Avanzate» chiusi (altro layer di
    strade, perimetri dei centri abitati, modo delle progressive e strumento
    Chilometrica, formato/PDF/loghi/foto e sezioni); testi più corti;
  - dopo «Trova le interferenze» interferenze e fasce di rispetto (sede e
    fascia di ogni strada) sono subito in mappa;
  - punto 4: «Crea il layer cippi» (Cippi_Chilometrici, campi strada e km,
    subito in modifica) e la progressiva calcolata scritta nel campo
    Chilometrica di tratte, pozzetti e armadi (casella, attiva).
- Istanze Ferrovia: senza ferrovie attorno al progetto la ricerca andava in
  errore («NaN», barra ferma su «non completato» e lo stesso errore a ogni
  rilancio per la cache): ora dice «Nessuna ferrovia». Gli errori finiscono
  nel registro con un avviso; nuovo «Riscarica da OSM» che ignora la cache.
- Seleziona elementi › Regola 1 (delivery Civico → PTE):
  - nuovo «Civico non agganciato: tratta considerata sul civico se entro»
    (2 unità CRS): la tratta d'utenza che finisce a qualche decimetro o metro
    dal civico ora entra nella selezione, in tutte le parti della regola
    (catene, percorso completo, tratte a contatto col civico). Deruta: 46
    tratte in più;
  - nuova opzione (attiva) «Seleziona anche la tratta nuova che porta al PTE
    Light Diramatore servito dalla delivery»: la minitrincea dal PTE al
    diramatore, prima esclusa perché la catena si ferma al diramatore, ora si
    prende (solo quella che lo tocca, STATO Nuovo; esclusa se lungo il Cavo
    Ottico).
- Screening del territorio molto più veloce (Deruta: da 365 s a 83 s, rifatto
  sulla stessa zona 6 s):
  - le fonti indipendenti (SITAP, EEA Natura 2000, ISPRA) si interrogano in
    parallelo invece che una dopo l'altra;
  - con il tracciato o l'area di progetto, strade, ferrovie, corsi d'acqua e
    boschi si chiedono a OpenStreetMap in una sola richiesta e solo attorno
    alla rete (~1,3 km di margine), non su tutto il comune: prima la richiesta
    delle strade andava in timeout (0 strade), ora le trova;
  - le risposte di OpenStreetMap restano in cache per 7 giorni.
- SITAP: i layer nazionali «aree boscate art. 142 lett. g», «zone umide» e
  UNESCO rispondevano HTTP 400 (il server non permette più la lettura a
  pagine su quelle viste) e i vincoli risultavano «non verificati». Ora si
  leggono in una richiesta sola (Deruta: 48 aree boscate).
- Screening del territorio: alla fine riempie da solo il punto 2 delle schede
  istanze con i dati già scaricati (strade, ferrovie con gestore, corsi
  d'acqua, aree vincolate e Soprintendenza competente). Per cippi km e
  stazioni RFI resta «Trova le ferrovie e gli enti».
- Barra laterale: le tre macro categorie (Comune, Altri Enti, Cartografia di
  base) sono menu a tendina, clic sul titolo per aprire o chiudere (la scelta
  si ricorda).
- Verifica armadi: oltre alla posizione da progetto, «Indica la nuova
  posizione sulla mappa» registra la posizione aggiornata (esito «Da
  spostare»); il menu «Coordinate» sceglie quale mostrare e aprire in Street
  View. L'elenco ora è in Excel (.xlsx, prima CSV) con le colonne «Posizione
  da progetto» e «Posizione aggiornata» scritte «lat, lon» (Excel non le
  stravolge più) e i collegamenti Street View di entrambe.
- Verifica interferenze e Verifica armadi: il pannello si apriva nella
  finestra di QGIS, che restava dietro la finestra del plugin, e sembrava non
  aprirsi. Ora QGIS viene portato davanti con il pannello a destra della
  mappa; il pulsante «Apri il pannello (ultima ricerca)» lo riapre senza
  rifare la ricerca.
- Comune controllato con gli shape: un comune scritto dal plugin (nome del
  file del progetto, altra scheda, lavoro salvato) e diverso da quello degli
  shape si corregge da solo, senza la domanda; la domanda resta solo quando il
  comune lo scrivi tu. Esportazione: il comune si prende prima dal campo
  COMUNE degli shape (non più «Nome Comune» dal nome del file) e non si
  ricorda fra un progetto e l'altro.
- Verifica interferenze (Comune): oltre a ferrovie, corsi d'acqua e strade
  ANAS anche strade provinciali e regionali (SP, SR: Provincia / Città
  metropolitana / Regione) e autostrade (concessionario, attenzione 60 m).
- Barre di avanzamento: riempimento più chiaro e testo scuro in grassetto, la
  percentuale e la fase si leggono anche sopra la parte già piena.
- Quadro pratiche: lo stato parte vuoto e lo scegli tu (i conteggi nei titoli
  seguono comunque lo screening); il pulsante «Apri la scheda» si può premere
  solo quando lo stato è «da fare».
- Leggimi Istanze Strade: tolta la sezione «Collegamento al sito ANAS» e la
  fonte ANAS; i passi 2 e 4 descrivono il nuovo flusso (Conferma/Scarta,
  stradario del progetto, scelta dei cippi).
- Istanze Strade, punto 4: la fonte dei cippi è una scelta esplicita — «Cippi
  creati nel progetto» (layer e campo km), «Cippi di OpenStreetMap» o tutti e
  due — al posto della casella «anche i cippi di OSM»; il pulsante ora si
  chiama «Calcola le chilometriche delle tratte».
- Consegna pratiche: lo stato «da convertire in PDF» ora si chiama «completa,
  ma con file solo in Word»; passando il mouse si vede quali documenti sono
  solo in Word, che non entrano nel PDF unico, e come sistemarli.
- Altri Enti › Consegna pratiche: sotto l'elenco delle istanze «Seleziona
  tutte» e «Nessuna» per «Prepara consegna (istanze spuntate)».
- Altri Enti › Consegna pratiche: nuovo riquadro «Crea shape». Spunti i
  layer del progetto (con filtro per nome, «Seleziona tutti» / «Nessuno»)
  e diventano shapefile UTF-8 in una cartella nuova, con lo ZIP; i layer del
  progetto non si toccano.
- Stessi nomi dei pulsanti in tutte le schede istanze: al punto 2 «Trova le
  strade / le ferrovie / i corsi d'acqua / le aree e gli enti» (senza «A)» e
  senza la fonte tra parentesi, che ora è nel suggerimento), al punto 3
  «Trova le interferenze» (prima «Trova interferenze nel tracciato» o «Trova
  gli interventi nelle aree»).
- Istanze Acque, Soprintendenza e Parchi, stesso flusso:
  - punto 2: «Trova i corsi d'acqua e gli enti» / «Trova le aree e gli enti»;
    sotto la tabella «Seleziona tutte», «Nessuna», «Solo i proposti» e «Mostra
    in mappa» (Acque: layer «Corsi d'acqua trovati» nel gruppo Istanze >
    Acque > Trovati; Soprintendenza e Parchi: il layer delle aree di prima);
    zoom col doppio clic. Il layer B («Altre fonti») c'era già;
  - Acque: tolto «C) Crea il layer corsi d'acqua», ora lo fa «Trova
    interferenze» con le righe spuntate, il layer B1 e i disegnati;
  - punto 3: «Mostra in mappa» di scavi, pozzetti e armadi spuntati (gruppo
    Istanze > sezione > Trovati) e zoom col doppio clic (in Soprintendenza e
    Parchi non sulla colonna Via, che resta modificabile).
- Barra di avanzamento su «Trova le strade e gli enti» (era nascosta) e su
  «Trova interferenze» di Strade, Acque, Ferrovia, Soprintendenza e Parchi: il
  calcolo gira in sottofondo, QGIS resta vivo e il pulsante si disattiva finché
  la ricerca non finisce. In Strade la barra dice su quale strada sta lavorando.
- Pulsanti «Seleziona tutte» / «Nessuna» sotto le tabelle delle strade e delle
  interferenze (Strade, Acque, Ferrovia).
- Tavole di inquadramento: «Layer Inquadramento modello A» (e B) accetta solo
  poligoni e propone «Poligoni di Inquadramento»; se nel progetto non c'è
  resta vuoto invece di prendere 01_ARMADIO OTTICO.
- Istanze Strade: tolto il «suolo comunale» (spostava e cancellava dai layer
  principali), sostituito dai gruppi. Nei progetti dove era stato usato resta
  il pulsante «Riporta nel livello principale».
- Alla fine della generazione (Soprintendenza, Parchi / Natura 2000) un avviso
  ricorda che la documentazione prodotta è una bozza da verificare sempre.
- Istanze Strade è ora una scheda unica a passi, come RFI, Acque,
  Soprintendenza e Parchi:
  1. Comune;
  2. Strade toccate ed enti;
  3. Progressive chilometriche (l'ex sottoscheda Chilometriche, chiusa perché
     di norma le progressive sono automatiche);
  4. Interferenze;
  5. Destinatari e documenti (nuovo: le opzioni dei documenti, con la nota che
     i destinatari stanno nella tabella del punto 2);
  6. Genera le istanze, con il registro.

  Subito dopo il passo 1 c'è «Prima di iniziare: togli il suolo comunale». Fra il passo 5
  e il passo 6 c'è lo strumento Etichette «KM … SCAVO …». Tutti e due sono chiusi, e la
  generazione resta l'ultimo passo.
- Suolo comunale: lo spostamento è ora vero, non più un filtro. Gli elementi
  fuori dagli stradari dell'ente vengono copiati nei layer «… — suolo
  comunale» (GeoPackage «Suolo comunale.gpkg» in 01_File shp, stesso stile, nel
  gruppo comunale) e cancellati dai layer principali. «Riporta nel livello
  principale» li ricopia: verificato che attributi e geometrie tornano
  identici. Lo spostamento è registrato nel progetto.
  Nessuna funzione tolta; il Quadro pratiche porta il comune anche qui.
- Riquadro «1) Comune» uguale in tutte le schede istanze: in RFI e Acque
  comune, Prov. e CAP sono ora su una riga, con «Indirizzo del Comune (e.p.c.)»
  e «PEC del Comune», come in Strade, Soprintendenza e Parchi.
- Soprintendenza: preavviso della comunicazione per mini e microtrincea di 15
  giorni, 8 se lo scavo è sotto i 200 m (art. 40 c.4 DL 77/2021). È indicato
  nel LEGGIMI.txt dell'istanza (con i metri e i giorni che valgono), nella
  colonna regime e in testa alla scheda.

### Finestra restringibile, comune controllato in tutte le schede

- La finestra del plugin si restringe senza tagliare le scritte. Le caselle
  di spunta con testo lungo vanno a capo, le etichette dei moduli scendono
  sopra il campo, le tendine si stringono (nel menu la voce resta intera) e
  alcune righe molto lunghe sono divise in due. La pagina più larga passa da
  ~970 a ~640 px.
- Descrizioni in testa alle schede: la prima riga non si interrompe più su
  un'abbreviazione (es. «(art.» in Soprintendenza). Se la frase è molto
  lunga si ferma a una pausa e continua nei «dettagli».
- Controllo del comune unico per tutte le schede (Screening, Istanze Strade,
  RFI, Acque, Soprintendenza, Parchi, relazione comunale). Il comune scritto
  viene confrontato con il campo COMUNE degli shape del progetto (armadi,
  pozzetti, civici, PTE). Se non corrisponde, il campo diventa rosso e una
  domanda propone il comune del progetto; accettando si aggiornano anche
  provincia e CAP. Il controllo scatta anche all'apertura della scheda.
- Verifica interferenze (Comune): dopo una ricerca con tratte da verificare,
  un suggerimento propone le Fasce di rispetto (una volta per sessione, con
  «Non mostrare più»). «Apri Fasce di rispetto» porta a Cartografia di base ›
  Fasce di rispetto già pronta per la categoria con più tratte: opere trovate
  come shape sorgente, solo quelle di quel tipo selezionate, ente e distanza
  impostati (ferrovia 30 m, corso d'acqua 10 m, ANAS). C'è anche il pulsante
  fisso «Fasce di rispetto…» accanto alla ricerca.
- Nuova icona «Verifica armadi»: armadio FiberCop stilizzato (alto, con fascia
  superiore, serratura e onda della fibra).

### Regola 1, tutorial e copertura Keyplan/Tavole

- Regola 1: fra i Cavi Raccordo, solo quelli che collegano due PTE contano
  come rete secondaria da escludere. Quelli PTE → civico sono la delivery: le
  tratte che ci corrono sotto (es. l'ultimo tratto verso il pozzetto sulla
  dorsale) ora vengono selezionate, insieme ai loro pozzetti.
- Regola 1: barra di caricamento con la fase in corso (aggancio PTE, catene,
  percorsi civico → PTE con il conteggio dei civici, pozzetti, tratte sul
  civico).
- Regola 1: la prima volta in ogni sessione un avviso ricorda di usare prima
  «Cartografia di base › Unisci tratte». Il pulsante «Vai a Unisci tratte»
  apre la scheda con il layer Infrastrutture già impostato; c'è anche
  «Non mostrare più».
- Unisci tratte: «Campo stato» propone sempre STATO. Prima la memoria delle
  impostazioni rimetteva la posizione salvata nella tendina e poteva
  comparire TIPOLOGIA.
- Verifica interferenze: barra di avanzamento con la fase e i secondi di
  attesa della risposta di OpenStreetMap. La finestra resta attiva mentre si
  aspetta.
- Tutorial: il fumetto si allunga quanto serve, e il testo sotto un titolo su
  due righe non viene più tagliato.
- Keyplan e Tavole: «Layer della rete nuova» e «Area da coprire» sono ora un
  unico riquadro, più sintetico. L'unica cosa da controllare è il layer
  Infrastrutture; le spiegazioni sono nei suggerimenti.

### Esportazione PDF dei layout: risoluzione e PL unita in un clic

- Nuovo campo «Risoluzione di esportazione» (dpi), come nella scheda Layout del
  Compositore. Con «come nel layout» resta il valore salvato in ogni layout,
  che viene mostrato accanto al campo per i layout selezionati.
- Nuovo pulsante «Esporta e unisci in un solo PDF»: esporta i layout
  selezionati e li unisce subito nell'ordine della PL, cioè prima l'ortofoto,
  poi la planimetria, poi le tavole. A parità di gruppo conta il numero
  iniziale del nome. Restano anche i PDF dei singoli layout.
- Se fra i layout selezionati ci sono delle alternative, il pulsante chiede
  quale tenere prima di esportare, così nella PL non c'è niente di doppio.
  Sono alternative il keyplan combinato (00 ORTO+INQUA) e i keyplan separati
  (01 ORTO + 02 INQUA), e i diversi layout di tavole (03 Inquadramento e
  04 Inquadramento 6Foto).
- I layout senza Atlante (pagina singola) ora si esportano come sono, invece
  di essere scartati.

### Comune › Esportazione: tabelle e relazione tecnica (ex macro Excel e Word)

- Nuovo riquadro «Tabelle e relazione tecnica (istanza comunale)»: dai file
  del join (SCAVI_STRADE, POZZETTI_STRADE, ARMADI_FOTO) crea le tabelle
  01 Scavi, 01b Pubblica Illuminazione, 02 Pozzetti e 03 Armadi in Excel e la
  relazione «COMUNE_RT» in Word e PDF, con le tabelle già inserite e l'indice
  aggiornato. Sono le stesse regole della macro di quantificazione: solo
  tratte nuove, metri per via arrotondati per eccesso, PI separata, pozzetti
  nuovi per misura. Nella relazione il capitolo della Pubblica Illuminazione
  sparisce se non c'è.
- Le tabelle hanno tutte lo stesso stile e occupano l'intera larghezza della
  pagina. Gli armadi sono ordinati per numero.
- Nei nomi delle vie e negli indirizzi vengono corretti i refusi di accenti
  (testi mal codificati, «Localitá», «GIOSUE'»). Il civico 9999 diventa SNC.
- Il logo in alto a sinistra segue la casella Milano Cortina, come nella PL e
  nelle relazioni delle altre istanze.
- Corretto: le intestazioni collegate delle relazioni Word non vengono più
  duplicate (prima la copertina poteva scivolare a pagina 2).

### Tutorial interattivo

- Pulsante «▶ Tutorial» nella testata: guida passo passo della sezione
  aperta. La finestra si scurisce e un elemento alla volta viene evidenziato
  con un fumetto (Indietro / Avanti / Chiudi, anche frecce, Invio ed Esc):
  introduzione della sezione, ogni riquadro nel suo ordine (aperto se chiuso,
  portato in vista) con la sua descrizione e i comandi che contiene, poi i
  pulsanti principali. Funziona in tutte le sezioni; per le più usate c'è
  un'introduzione scritta.

### Comune › Verifica interferenze (nuova scheda)

- Trova le tratte di infrastruttura vicine a ferrovie, corsi d'acqua e strade
  ANAS (OpenStreetMap) già nel permesso comunale, con distanza di attenzione
  regolabile per categoria (30 / 10 / 30 m) e la possibilità di escludere le
  tratte senza scavo (Aerea o TIPOLOGIA vuota) e quelle non nuove.
- Pannello accanto alla mappa come la Verifica armadi: scorre le tratte,
  evidenzia quella corrente, apre Street View / Google Maps sul punto più
  vicino all'opera, esito (Da verificare, OK si lascia, Da modificare,
  Modificata) con nota salvato nel progetto, elenco CSV. L'ultima ricerca si
  riapre senza interrogare di nuovo OpenStreetMap; ferrovie, acque e strade
  trovate vanno in un layer temporaneo.
- Avviso in scheda, nel pannello e nel CSV: l'attendibilità delle fonti è
  sempre da verificare sulle cartografie ufficiali e con l'ente.

### Comune › Seleziona elementi: regola 1 «Rete di delivery Civico → PTE»

- Le regole 1 e 1b sono una sola (un pulsante): seleziona la rete di
  delivery, dal civico al primo ROE PTE, mai la rete secondaria armadio → PTE.
- La catena parte anche da una tratta ESISTENTE sul civico (tubazione
  d'utenza già presente): prima partiva solo da tratte «Nuovo» e su Angri,
  dove la tratta sul civico è quasi sempre esistente, trovava 2 tratte.
- Le tratte che arrivano allo stesso pozzetto sono collegate anche se gli
  estremi non coincidono (0,5 m, regolabile).
- Percorso completo dal civico al primo PTE (più breve sulla rete, tratte
  esistenti comprese) con i suoi pozzetti.
- Rete secondaria esclusa: tratte e pozzetti lungo il Cavo Ottico e ora anche
  lungo il Cavo Raccordo (PTE → PTE Diramatore). Restano escluse, come prima,
  le catene verso un PTE Light raccordato a un altro PTE.
- Pozzetto sede di PTE: riconosciuto anche se il PTE è poco fuori dal
  pozzetto (0,5 m; PTE Light Diramatore 1,5 m, regolabile). Va lasciato: non
  viene mai selezionato.
- PTE disegnati a qualche metro dalla rete (es. a muro): ogni PTE è agganciato
  all'estremo di tratta più vicino (entro 3 m, regolabile) e lì catena e percorso
  si fermano; prima andavano oltre fino al primo PTE disegnato sulla rete.
- Su Angri: da 2 a 151 tratte e da 0 a 12 pozzetti.

### Suggerimento dei comuni

- Nei campi «Comune» di Screening, Istanze Strade, RFI, Acque,
  Soprintendenza e Parchi compare, mentre scrivi, l'elenco dei comuni
  italiani con la provincia («Castiglione del Lago (PG)»); scelta la voce
  resta solo il nome. Elenco ufficiale ISTAT incluso nel plugin
  (assets/comuni_italiani.txt), funziona senza internet.
- Istanze Strade, Soprintendenza e Parchi: scritto o scelto il comune,
  provincia (dall'elenco ISTAT) e CAP (da internet) si compilano subito,
  come già in RFI e Acque; prima arrivavano solo con «Scarica le aree» o
  la ricerca delle strade. Se il comune cambia vengono sostituiti.
- Screening territorio: scritto o scelto il comune, il campo Provincia
  prende da solo il nome della provincia (es. Salerno). Per i comuni con
  lo stesso nome in più province (es. Castro BG/LE) vale la voce scelta
  dalla tendina; scritto a mano resta da compilare.
- Soprintendenza e Parchi, «B) oppure da un layer del progetto»: si può
  scrivere una parte del nome per cercare il layer.
- Soprintendenza e Parchi: «Seleziona tutti» e «Nessuno» sotto le aree
  vincolate (punto 2) e sotto le interferenze (punto 3), come in Acque.
- Soprintendenza e Parchi, punto 2:
  - «Mostra le aree nel progetto»: le aree spuntate finiscono in un
    GeoPackage in 01_File shp\Soprintendenza (o \Parchi) e sulla mappa, nel
    gruppo «Soprintendenza - Aree vincolate» / «Parchi e Natura 2000»;
    ripremendolo il layer si aggiorna;
  - «Disegna un'area a mano…»: crea il layer delle aree disegnate, lo mette
    in modifica e lo imposta già nella riga B; disegnata l'area e salvate le
    modifiche, si sceglie il tipo di vincolo e si preme «Aggiungi».
- PL di Soprintendenza, Parchi e Acque, grafica più da tavola urbanistica:
  - vincoli con colori smorzati (bordeaux, blu acciaio, oliva, siena),
    velo appena accennato, tratteggio sottile e fitto, bordo continuo; la
    direzione del tratteggio cambia per famiglia (art. 136 a 45°, art. 142
    a 135°) così le sovrapposizioni si leggono come incrocio;
  - in corografia le tavole sono riquadri tratto-punto grigio antracite
    con «TAV. n» accanto («Inquadramento delle tavole» in legenda), al
    posto dei pallini blu.
- Istanze Soprintendenza, PL e scheda:
  - niente sezioni né fotoinserimento: il riquadro in basso a destra è
    tutto per le foto, 1 (tutto il riquadro), 2 o 4 a scelta («Foto per
    tavola», proposto 2);
  - «Solo armadi (elementi fuori terra)»: l'istanza conta solo gli armadi
    (relazione e documenti), una tavola per armadio «PLANIMETRIA - AREA
    ARMADIO» con lo scavo e il pozzetto dell'armadio visibili; propone 1
    foto per tavola;
  - Soprintendenza e Parchi parlano di «interventi» invece che di
    «interferenze» (punto 3 della scheda e legenda della PL);
  - legenda: «FOTO» invece di «FOTO E SEZIONI» se la tavola non ha sezioni.
- Soprintendenza e Parchi / Natura 2000, punto 5: «Link al geoportale
  consultato» ed «Estratto della mappa (immagine)», facoltativi e salvati nel
  progetto. Nella corografia della PL l'estratto sta a lato delle due mappe
  (riquadro «ESTRATTO DAL GEOPORTALE», alto quanto l'immagine) con sotto
  «Fonte: link — Consultato il mm/aaaa»; con il solo link, una riga in basso
  sull'ortofoto.
- Logo FiberCop «Milano Cortina 2026» (territori FOL che lo chiedono): una
  casella in tutte le schede delle istanze (Strade, RFI, Acque,
  Soprintendenza, Parchi) e in Esportazione, legate fra loro e salvate nel
  progetto. Con il flag il logo olimpico va nei cartigli delle PL, nei
  documenti Word dai modelli (art. 49, RT+CR, bollo, modello B) e nei layout del progetto esportati in PDF
  dalla scheda Esportazione (solo durante l'esportazione). Senza flag vale il
  logo classico ovunque. Il riquadro del logo resta quello del modello.
- Colonna «N. ARLO» nelle tabelle della relazione (casella in tutte le
  schede delle istanze, salvata nel progetto): ogni scavo e pozzetto prende il
  numero dell'armadio dell'area ARLO in cui cade (layer «Arlo Area» + AREA_AO
  dell'armadio dentro l'area; senza armadio l'etichetta dell'area). La
  colonna sta accanto all'indirizzo / chilometrica nelle tabelle scavi e
  pozzetti, con lo stesso stile delle altre, e le righe sono in ordine di
  numero (anche il cronoprogramma segue lo stesso ordine).
- Ferrovia, regola dei 6 m e margine dall'asse:
  - Istanze RFI: uno scavo, un pozzetto o un armadio entro 6 m dal limite
    della ferrovia (proprietà del gestore) non è più proposto come
    Tipologia D: la riga diventa «?» con la nota «scegliere A, B o C,
    attraversamento o concessione, con sopralluogo»;
  - nuovo «Margine asse binario → limite ferrovia» (1 m proposto) in
    Istanze RFI e in Fasce di rispetto: 6 e 30 m si misurano dal limite
    dell'occupazione, non dalla linea OSM del binario;
  - la fascia ferroviaria (scheda RFI e scheda Fasce di rispetto, ente
    «RFI - Ferrovia») è la striscia 6-30 m, con le due linee tratteggiate
    verdi e la scritta «FASCIA DI RISPETTO FERROVIARIA 6-30 m».
- Armadi: il numero si legge dal campo AREA_AO (numero ARLO) prima di
  ID_ARMADIO; etichetta in tavola «POSA ARMADIO ARLO 201» in tutte le PL
  (Acque, Strade, RFI, Soprintendenza, Parchi) e stesso numero nelle tabelle.
- Tendine: la voce sotto il mouse diventava una casella bianca vuota;
  ora resta leggibile ed evidenziata in azzurro.

### Comune › Keyplan e tavole

- Sezioni nell'ordine di lavoro: 1 Layer della rete nuova, con subito
  sotto «Area da coprire»; 2 Tavole di inquadramento; 3 Keyplan;
  4 Numerazione; 5 Salva su disco.
- «Layer Keyplan modello A» mostra solo poligoni e non prende più da
  solo il primo layer del progetto (01_ARMADIO OTTICO): propone
  «Keyplan Quadrato» o «Keyplan Rettangolare» se ci sono, altrimenti
  resta vuoto.

### Comune › Verifica armadi (nuova scheda)

- Apre accanto alla mappa di QGIS il pannello «Verifica armadi» sul layer
  01_ARMADIO OTTICO (o un altro layer di punti scelto).
- Navigazione:
  - gli armadi si scorrono con ◀ ▶, dall'elenco o con un clic sulla mappa;
  - la mappa si centra su ogni armadio e lo segna con un cerchio blu notte.
- Il numero dell'armadio si legge dal campo AREA_AO («Armadio 201»);
  l'esito è legato a quel numero.
- Street View e Google Maps si aprono nel browser sul punto
  esatto dell'armadio. In QGIS non c'è un motore web moderno, quindi non
  possono stare dentro la finestra.
- Esito:
  - per ogni armadio Da verificare, Fattibile, Non fattibile o Da spostare,
    più una nota;
  - sulla mappa gli armadi si colorano secondo l'esito (grigio, verde,
    rosso, arancio), con il riepilogo dei conteggi;
  - gli esiti si salvano nel PROGETTO, non nel layer, e restano col
    progetto quando lo salvi.
- «Esporta elenco CSV»: armadio, indirizzo, coordinate, esito, note e
  collegamento a Street View, con separatore «;» per Excel.

### Grafica del pannello

- Testata blu notte beexact: logo chiaro a sinistra, nome e versione del
  plugin a destra.
- Barra laterale con icone al posto delle linguette di primo e secondo
  livello (Comune, Altri Enti, Cartografia di base):
  - icone a linea disegnate per il plugin, tutte con lo stesso tratto:
    grigio ardesia, blu notte sulla voce attiva (bianco nel tema scuro);
  - la voce attiva ha un filo arancio a sinistra;
  - le sottoschede interne (per esempio Istanze Strade) restano linguette
    piatte, con la sottolineatura arancio sulla linguetta attiva.
- Foglio di stile unico, chiaro o scuro come il tema di QGIS:
  - pulsanti, campi e tabelle con angoli arrotondati;
  - riquadri con titolo blu notte;
  - log a spaziatura fissa;
  - barra di avanzamento sottile.
- I pulsanti principali di ogni scheda («Genera…», «Trova le strade…»,
  «Prepara consegna») sono pieni blu notte; gli altri restano chiari.
- Finestra iniziale più larga (940×720) per la barra laterale.
- Gli indici delle schede salvati e la navigazione dal Quadro pratiche
  funzionano come prima: le linguette sono nascoste, non tolte.

### Altri Enti › ordine delle schede

- «Screening territorio» è la prima scheda di Altri Enti, seguita da Quadro
  pratiche e dalle schede delle istanze.
- «Fasce di rispetto» passa in Cartografia di base: crea un buffer attorno
  a strade, ferrovie e fiumi, quindi lavora sul dato di base e non prepara
  un'istanza.

### Altri Enti › Consegna pratiche (nuova scheda, al posto di Esportazione)

- Cerca nella cartella delle pratiche le istanze generate dalle schede
  Strade, RFI, Acque, Soprintendenza e Parchi (cartelle con i file «1.0_…»,
  «1.1_…»).
- Per ogni istanza dice:
  - lo stato: completa, da convertire in PDF, incompleta;
  - cosa manca: istanza, relazione, PL;
  - cosa verificare: bollo, documento d'identità, procura.
- Il PDF (anche firmato .p7m) ha la precedenza sul Word con lo stesso nome.
  Un documento solo in Word è segnalato da salvare in PDF e firmare.
- «Prepara consegna» crea Consegna/<istanza>:
  - copia i file;
  - crea «<istanza>_COMPLETO.pdf» con istanza, relazione, PL, bollo e
    allegati, in quest'ordine;
  - avvisa se il PDF unico supera il limite della PEC (30 MB, modificabile).
- Documento d'identità e procura restano file separati: il plugin li
  riconosce dal nome e non li apre.
- Atlante PDF, «Unisci PDF» ed evidenza delle strade interessate restano in
  fondo alla scheda, nella sezione chiusa «Altri strumenti».

### Istanze Strade › grafica allineata alle pratiche consegnate (Castiglione)

- PL A1:
  - caratteri a grazie (Times New Roman) per titoli, scale, sezioni, foto e cartiglio;
  - colonna destra con le proporzioni degli esempi: particolari circa 34%,
    legenda circa 15%, cartiglio circa 50%;
  - cartiglio con strada, «ISTANZA DI AUTORIZZAZIONE SCAVI E POSA POZZETTI»,
    nome della pagina, committente, progettista e «TAV. k / N».
- Legenda: la legenda standard degli esempi, uguale in tutte le pagine.
- Particolari costruttivi:
  - nell'inquadramento generale ci sono tutti quelli della libreria;
  - in ogni tavola ci sono solo quelli degli elementi di quella tavola
    («PARTICOLARI COSTRUTTIVI DI PROGETTO»).
- Etichette:
  - riquadro bianco con bordo grigio, testo nero non grassetto e richiamo
    sottile;
  - testo «dal km X al km Y» / «SCAVO Tradizionale 11 m» oppure «KM X» /
    «POSA POZZETTO 40x76»;
  - tolti «Mt» e «IN FASCIA DI RISPETTO».
- Inquadramento:
  - le scritte «TAV. n» sono più grandi;
  - ogni pagina mostra solo i riquadri delle sue tavole e la rete che ci sta
    dentro, tagliata sul bordo dei riquadri; nessun pezzo di una tavola
    compare su un'altra pagina.
- Tavole:
  - coprono gli scavi veri (le tratte di 03 INFRASTRUTTURE vicino alla
    strada), i pozzetti e gli armadi col minor numero di riquadri: si
    scorre la strada, poi si uniscono i riquadri che stanno insieme;
  - sono numerate in fila lungo la strada;
  - se un pozzetto o un armadio resta fuori da tutte le tavole, il log lo
    segnala.
- Legenda:
  - pozzetti e armadio sono disegnati con lo stile vero dei layer
    02_POZZETTO e 01_ARMADIO OTTICO, tutti alla stessa scala;
  - c'è la voce «FASCIA DI RISPETTO STRADALE» quando la fascia è disegnata.
- Fascia di rispetto (ANAS):
  - bordo tratteggiato blu, non più rosso;
  - solo la linea esterna: niente bordo della sede, niente anelli dentro
    rotatorie e incroci;
  - linee morbide, ricavate dall'asse semplificato e arrotondato.
- Sezioni: sempre 4 riquadri (A-A'...D-D'), larghi e bassi, due per riga,
  come nelle tavole consegnate.
- Etichette:
  - ogni pozzetto ha la sua etichetta, non viene più unito allo scavo;
  - lo scavo trasversale (attraversamento) ha una sola progressiva «KM x».
- Particolari costruttivi: riempiono tutto il riquadro (scala più grande).
- Relazione: nel cronoprogramma i giorni sono interi (35 m = 1 gg).
- Relazione: tabelle con intestazione e totali blu (0070C0) e testo bianco in
  grassetto.
  - Provincia: TABELLA INTERVENTI e UBICAZIONE ARMADI a 5 colonne.
  - ANAS: tabelle separate per la fascia di rispetto.

### Altri Enti › Quadro pratiche (nuova scheda, la prima di Altri Enti)

Indice delle pratiche da presentare per il progetto aperto, costruito dallo
Screening territorio e aggiornato da solo alla fine di ogni screening.
- Gli enti sono raggruppati per categoria: strade e suolo pubblico, ferrovie,
  acque, beni culturali e paesaggio, parchi e Natura 2000, rischio
  idrogeologico, altri. Il titolo di ogni categoria riporta quante pratiche
  sono da presentare, da verificare o già generate.
- Per ogni ente:
  - il motivo («SP 30: attraversamento»…);
  - se la sua competenza è toccata dalla rete in progetto (Sì, da
    verificare, no, solo nel comune), con la classificazione dello
    screening;
  - lo stato della pratica (da fare, da verificare, in preparazione,
    generata, non necessaria);
  - le note;
  - il pulsante «Apri» verso la scheda che la prepara (Istanze Strade,
    RFI, Acque), con il comune già scritto.
- Gli enti solo presenti nel comune sono nascosti, con una casella per
  mostrarli.
- Sotto, il riepilogo delle verifiche fatte nelle schede: interferenze
  trovate in RFI e Acque.
- Quadro, stati e note si salvano nel progetto. Per Soprintendenza e Parchi
  la scheda è «in arrivo».

### Istanze Strade › Genera istanze (nuova sottoscheda)

Come nei pacchetti consegnati (ANAS SS71, Provincia SP306):
- **strade ed enti**: le strade classificate entro 50 m dalla rete nuova (OSM), con
  l'ente proposto: gestore regionale, Città metropolitana o Provincia, concessionario
  autostradale, ANAS con Struttura territoriale e PEC dal sito ANAS, e la nota di
  competenza (centri abitati e abitanti). Ente, ufficio, indirizzo, PEC, fascia e «e.p.c.
  Comune» si correggono in tabella;
- **interferenze** in sede stradale e in fascia di rispetto, con le progressive del campo
  Chilometrica (sottoscheda Chilometriche) e gli attraversamenti marcati;
- **documenti**:
  - istanza art. 49 nel formato strade (nuovo modello `modelli_strade`, ricavato dagli
    esempi senza dati personali);
  - RT+CR con una riga per scavo e per pozzetto in ordine di progressiva («*» =
    attraversamento, «(fascia di rispetto)»);
  - bollo;
  - PL con sede e fascia evidenziate ed etichette «KM ... SCAVO ...».
- **PL nel formato delle pratiche strade (A1)**, predefinito:
  - prima pagina «Inquadramento generale» con ortofoto e cartografia, i riquadri TAV. n e,
    a destra, particolari costruttivi, legenda e cartiglio (strada, «Istanza di
    autorizzazione scavi e posa pozzetti», committente, progettista, KEYPLAN);
  - tavole a 1:500 con la planimetria grande, le sezioni e due foto sotto, e il cartiglio
    «TAV. k / N».

  L'A3 a quattro riquadri delle altre schede resta come opzione.
- **Progressive automatiche**: ogni scavo è proiettato sull'asse della strada (inizio e
  fine), e così pozzetti e armadi. Il km si tara sui cippi, del layer del progetto e di OSM.
  Le tratte storte o a zig-zag non falsano più il calcolo. Se i cippi non bastano si usa il
  campo Chilometrica, poi le coordinate.
- **Centri abitati**:
  - fonti: il perimetro deliberato dal Comune (layer del progetto, con nome e abitanti) e,
    per le statali, i centri abitati del sito ANAS (km e classe di popolazione);
  - dentro il centro abitato le interferenze in fascia restano, come nella pratica ANAS
    SS71 (art. 18 CdS, art. 28 DPR 495/1992), con una nota;
- **Progressive dalla geometria ANAS** quando mancano i cippi. Sulla SS71 a Castiglione del
  Lago coincidono con quelle della relazione consegnata entro 1-7 m.
- **Relazione strade dal modello SS71**: tabelle nuovi scavi e fascia di rispetto separate,
  pozzetti e fascia, armadi, cronoprogramma, con le sole tecniche presenti.
- **PL A1 come gli esempi**:
  - nelle tavole nessuna sede o fascia evidenziata; solo per ANAS, se spuntata, la fascia
    col tratteggio senza riempimento;
  - fino a 4 sezioni affiancate e due foto;
  - inquadramento a 1:2000, su più pagine se serve.
  - oltre 10.000 abitanti i lavori in sede vanno in una istanza a parte intestata al Comune
    (art. 2 c. 7 CdS);
  - fino a 10.000 abitanti restano all'ente, con la nota sull'art. 26 c. 3;
  - quando l'ente è competente anche dentro il centro abitato e la strada ha lavori sia
    dentro sia fuori, escono **due istanze allo stesso ente**, «…_DENTRO_CA» e
    «…_FUORI_CA». Oggetto, relazione, LEGGIMI e cartiglio dicono «tratto interno al centro
    abitato di …» o «tratti esterni al centro abitato».

### Screening territorio: gestori delle strade verificati

- Tabella dei gestori per regione ricontrollata sulle fonti (rientro strade ANAS 2018-2021).
  Corretti: Campania (ACaMIR non è un gestore), Puglia (ASSET non lo è), Veneto (CAV è una
  concessionaria autostradale), Calabria, Piemonte, Lombardia, Emilia-Romagna, Sicilia e
  Sardegna (nessuna classe SR).
- Le SP vanno alla **Città metropolitana** nelle 14 città (più Sassari dal 2025), al Libero
  Consorzio in Sicilia, agli EDR in FVG, altrimenti alla Provincia.
- **Autostrade**: concessionario per sigla e tratta (A4 SATAP, ASPI, A4 Holding, CAV,
  Autostrade Alto Adriatico...).
- **Strade declassate**: una SS che non risulta sul sito ANAS è segnalata.

### Screening territorio: competenza sulle strade e verifica sul sito ANAS

- **Competenza per centro abitato e abitanti, con i riferimenti normativi**:
  - fuori dal centro abitato autorizza l'ente proprietario (art. 26 c. 2 CdS);
  - nei centri abitati oltre i 10.000 abitanti i tratti di strade statali, regionali e
    provinciali sono comunali (art. 2 c. 7 CdS);
  - fino a 10.000 abitanti autorizza il Comune previo nulla osta dell'ente proprietario
    (art. 26 c. 3), da rilasciare in 15 giorni per la banda ultralarga (art. 26 c. 3-bis,
    L. 12/2019);
  - autostrade: il concessionario.

  Ogni nota riporta i riferimenti (CdS artt. 2, 4, 26; CCE art. 49).
- **Verifica sul sito ANAS** («Anas per regione») per ogni strada statale del comune. Lo
  screening legge:
  - le tratte di competenza ANAS (dal km al km);
  - i centri abitati attraversati, con i km e la classe di popolazione indicata da ANAS;
  - la Struttura territoriale, con indirizzo e PEC.

  Esempio: a Castiglione del Lago il centro abitato sulla SS 71 (km 100+200 - 103+670) è
  sotto i 10.000 abitanti anche se il Comune ne ha di più, quindi la strada resta ANAS.

### Etichette degli scavi spezzate ai pozzetti (Acque, Soprintendenza, Parchi)

Lo «scavo continuo» unisce gli spezzoni attaccati della stessa tecnica solo se nel punto
di contatto non c'è un pozzetto. Dove c'è il pozzetto lo scavo si interrompe e ogni tratto
ha la sua etichetta e i suoi metri. Nelle istanze strade gli scavi sono una riga per tratta,
come nelle relazioni consegnate.

### Relazioni tecniche (tutte le istanze): niente tabella pozzetti se non ci sono pozzetti

Come già per la parte sugli armadi, se l'istanza non ha pozzetti nuovi dalla relazione
RT+CR sparisce tutto il paragrafo «POSA POZZETTI»: titolo, tabella vuota e nota dei
particolari. Vale per RFI, Acque, Soprintendenza e Parchi / Natura 2000.

### Altri Enti › Istanze Soprintendenza e Istanze Parchi / Natura 2000 (nuove schede)

Due schede accanto a Istanze Acque, con lo stesso percorso: comune → aree vincolate →
interferenze → destinatari → genera.
- **Aree**: si scaricano con le fonti dello Screening territorio (vincoli SITAP art. 136
  e 142, fasce regionali lett. a/c, SITR in Sicilia; parchi EUAP; siti Natura 2000 EEA)
  oppure si aggiungono da un layer di poligoni del progetto. Sono spuntate quelle in cui
  passa la rete, con i metri di rete dentro.
- **Interferenze**: scavi, pozzetti e armadi nuovi dentro le aree (motore delle Acque, con
  metri, coordinate «da/a» e vie). Un armadio dentro l'area conta anche senza scavo.
- **Soprintendenza**: una istanza per Soprintendenza (nome e PEC da SITAP). Per ogni
  interferenza la scheda dice se va **autorizzata** (trincea tradizionale, no-dig,
  pozzetti, armadi) o solo **comunicata** (mini e microtrincea, art. 40 c. 4 DL 77/2021,
  15 giorni). Documenti: istanza art. 49, PL, RT+CR, bollo, **Relazione paesaggistica
  semplificata** (Allegato D DPR 31/2017) con le lettere art. 136/142 toccate dai lavori, e
  a scelta la **dichiarazione di non parentela** (L. 190/2012).
- **Parchi**: una istanza per area protetta (nulla osta art. 13 L. 394/1991).
- **Natura 2000**: regola **per via** dell'art. 40 c. 3-bis DL 77/2021 (come modificato dal
  DL 19/2026): sotto i 200 m di scavo l'**autodichiarazione di esclusione dalla VIncA**
  (comunicazione con 30 giorni di preavviso, con RT e PL come descrizione e foto); da 200 m
  in su istanza con il **Format di screening VIncA** del proponente precompilato (codice e
  nome del sito, aree protette, distanza, lavori per via). Soglia e distanza dal sito
  sono modificabili.
- **PL**: stessa impaginazione delle Acque, con le aree vincolate tratteggiate (un colore
  e una voce di legenda per articolo, parco o sito) e il **FOTOINSERIMENTO** al posto
  della sezione (file FOTOINSERIMENTO n.jpg in 04_Foto).
- Il **Quadro pratiche** apre le due schede dalle categorie Paesaggio e Parchi / Natura 2000.

### Altri Enti › Istanze Acque (nuova scheda)

- **Canali disegnati a mano sempre considerati**: «Trova interferenze» rilegge ogni
  volta il layer «Corsi d'acqua disegnati» (anche con modifiche non ancora salvate).
  Prima un canale disegnato dopo «Crea il layer corsi d'acqua» veniva ignorato.
- **Link dei siti utili verificati**: corretti quelli non più raggiungibili (Campania,
  Friuli Venezia Giulia, Molise, Piemonte, Toscana, Trento, Umbria, SID Portale del mare).
- **Rete anche sull'ortofoto delle tavole (Acque e RFI)**: scavi, pozzetti e armadi
  dell'istanza sono disegnati anche nel riquadro ORTOFOTO, allineati alla foto (stesso
  sistema di riferimento della planimetria), con lo stile del progetto e un bordo bianco
  per leggerli sulla foto. Gli elementi che lo stile del progetto non disegna (es. tratte
  «Esistente») escono in rosso, così l'interferenza si vede sempre.
- **Nota di verifica** sotto i siti utili: i siti sono solo suggerimenti e i risultati
  di OpenStreetMap vanno controllati sulle fonti ufficiali.

Istanze per le interferenze con l'acqua, accanto a Istanze RFI: canali dei
Consorzi di bonifica, fiumi e torrenti del demanio idrico (Regione / Genio
Civile), reticolo minore comunale e demanio marittimo.

- Corsi d'acqua e linea di costa da OpenStreetMap e/o da un layer del progetto
  (reticolo regionale, dividente demaniale SITR), con il campo di competenza
  (RIP/RIB/RIM, nome del Consorzio...) che indica l'ente. Comprensori di
  bonifica facoltativi per il nome del Consorzio.
- Fasce modificabili: 10 m demanio idrico (R.D. 523/1904, dalla sponda se
  l'alveo è disegnato), 10 m bonifica (da adeguare al regolamento del
  Consorzio), 30 m demanio marittimo (art. 55 Cod. Nav.).
- Attraversamenti e parallelismi trovati da soli, con via, metri per tecnica,
  pozzetti, distanza dall'alveo e come si passa: tombino, ponte, no-dig, o
  scavo a cielo aperto segnalato. Infrastrutture esistenti e tratte senza
  scavo restano senza spunta.
- Una istanza per ente e corso d'acqua (o costa): art. 49, planimetria PL,
  relazione con cronoprogramma (Word e PDF), bollo e LEGGIMI, in
  Istanze Acque\<COMUNE> accanto al progetto. Procuratore e referenti restano
  XXXXX, senza timbro.
- PL pensata per l'acqua: corografia metà su cartografia e metà su ortofoto,
  con il corso d'acqua in evidenza e il suo nome, un pallino per tavola come
  RFI («TAV. n») e la rosa dei venti; tavole (tutte alla stessa scala) per zona (interferenze vicine insieme, planimetria fino a
  1:2000) a quattro riquadri come RFI: ortofoto e stralcio catastale con le
  interferenze numerate, planimetria con la rete (anche le tratte aeree) e
  un'etichetta per interferenza, sezione e foto solo quelle disegnate in QGIS
  (layer Sezioni e punti di ripresa), con il titolo preso dal nome del file.
  Nel catastale solo il nome del corso d'acqua. In legenda «CORSI D'ACQUA» (o
  «COSTA»). Relazione con una riga per tavola.
- Etichette della planimetria senza numero, più leggere (7 pt): una per ogni
  scavo continuo (tratte attaccate della stessa tecnica, metri sommati) e per
  ogni pozzetto; se non c'è spazio, lo scavo e i SUOI pozzetti in un'unica
  etichetta (mai scavi diversi insieme). Richiami corti, il più possibile
  orizzontali, che non tagliano scavi, canale e fascia. Misura dei pozzetti
  come nel progetto, uguale alla legenda (40X76).
- Etichette modificabili elemento per elemento: doppio clic sulla colonna
  «Etichette in tavola» apre una finestra con una riga per ogni scavo
  continuo e pozzetto (vuota = testo automatico); in alternativa un testo
  unico per tutta l'interferenza. I testi corretti restano dopo una nuova
  ricerca; se lo scavo o il pozzetto è cambiato nel progetto il registro lo
  segnala e torna il testo automatico.
- Screening acque del comune: tutti i corsi d'acqua del territorio comunale
  (più i fossi senza nome nell'area del progetto) con km, tombini, distanza
  dal progetto e fascia; proposti quelli entro 200 m, si spuntano e si
  trasferiscono al layer acque. Sotto, i siti per trovare l'ente (geoportale
  regionale, Consorzio, ANBI, Genio Civile, reticolo minore, Autorità di
  bacino, demanio marittimo).
- Un solo punto per i corsi d'acqua, «2) Corsi d'acqua da sottoporre a
  istanza», al posto di «Screening» e «Carica corsi d'acqua», che facevano la
  stessa cosa in due modi:
  A) cerca su OSM e spunta;
  B) se serve aggiungi un layer del progetto o disegna il canale;
  C) «Crea il layer corsi d'acqua».
  C funziona anche senza la ricerca OSM, solo con layer o disegnati.
- Barra di avanzamento accanto al pulsante di ricerca. Mostra le 5 fasi
  (comune, corsi d'acqua, costa, area del progetto, distanze) e alla fine
  quanti corsi d'acqua ha trovato. Anche la ricerca nell'area del progetto
  non blocca più QGIS.
- Pulsante «Interrompi» accanto alla barra: ferma la ricerca in qualsiasi
  fase, anche con i server OSM che non rispondono. L'elenco non cambia e i
  dati già scaricati restano in cache.
- Tabelle scavi e pozzetti della relazione: prima colonna «Indirizzo» con
  intestazione, più larga e centrata, come nelle pratiche presentate. La riga
  si sceglie al punto 5 con «Tratti nelle tabelle RT», ricordata fra le
  sessioni:
  - Indirizzo (predefinito): «Via Marco Polo (Tavola 1)». Se la via non è
    nota si usano le coordinate, non più un generico «Demanio marittimo».
  - Coordinate di inizio e fine: «Tavola 1», a capo «inizio lat, lon» e
    «fine lat, lon».
  - Indirizzo e coordinate di inizio e fine: le due cose insieme.
- Cronoprogramma: la riga dice solo «Tavola n».
- Le tavole senza lavori da autorizzare (solo posa aerea o in
  infrastruttura esistente) non hanno più una riga di trattini; la
  numerazione delle tavole resta quella della PL.
- Pulsante «Prepara layer Foto e Sezioni» anche nella scheda Acque, come in
  RFI: stessi layer «Punto di Ripresa Fotografico» e «Sezioni».
- Barra di avanzamento anche in Istanze RFI e in Screening territorio.
  - Istanze RFI, «Scarica ferrovie, cippi e stazioni (OSM)»: due fasi
    (scaricamento, creazione dei layer), alla fine il riepilogo. Accanto c'è
    il pulsante «Interrompi».
  - Screening territorio: una fase per ogni fonte interrogata (confine,
    strade, SITAP, Natura 2000, aree protette, siti contaminati, ferrovie e
    acque, fasce art. 142, IdroGEO…), poi caricamento di layer e report. Il
    pulsante Annulla c'era già.
- Pulsanti «Seleziona tutti», «Nessuno» e «Solo i proposti» sotto l'elenco
  dei corsi d'acqua.
- La colonna «In fascia» si chiama «Rete in fascia», con una spiegazione al
  passaggio del mouse: la rete del progetto entra nella fascia di rispetto
  di quel corso d'acqua.
- La ricerca controlla che il comune scritto sia quello del progetto aperto.
  Se le infrastrutture sono fuori dal suo confine (oltre 1 km), si ferma e
  dice in quale comune si trova il progetto, con la distanza. Propone di
  cercare lì, aggiornando anche provincia e CAP. Prima si mescolavano i
  corsi d'acqua del comune scritto con i fossi dell'area del progetto, e i
  siti consigliati erano quelli di un'altra regione.
  Il comune del progetto si ricava dalle tratte (punto a metà di ciascuna),
  non dal rettangolo dei layer: un elemento isolato spostava il centro in un
  comune vicino. Fonte:
  - prima un layer dei confini comunali del progetto (es. «Confini Comunali»
    ISTAT, campo COMUNE): vince il comune con più tratte;
  - altrimenti OSM su 5 punti delle tratte, a maggioranza.
  Il messaggio dice quale fonte ha usato.
- «4) Enti competenti e destinatari»: una riga per ogni corso d'acqua con
  categoria, numero di interferenze, ente, nome dell'ente e motivo della
  proposta (layer con la competenza, comprensorio di bonifica, oppure solo la
  categoria, da verificare). L'ente scelto vale per tutte le interferenze di
  quel corso d'acqua. Le eccezioni si correggono nella singola riga del
  punto 3. Cambiando ente il nome del precedente si svuota.
- Il punto B mostra due modi distinti:
  B1) un layer scaricato dai siti ufficiali (reticolo regionale, canali del
  Consorzio, reticolo minore, dividente demaniale) o un tuo layer, da
  aggiungere prima al progetto;
  B2) il disegno a mano.
  Fasce di rispetto e comprensori stanno in un riquadro a parte, con i
  riferimenti di legge nei suggerimenti:
  - R.D. 523/1904 art. 96 f): 10 m;
  - R.D. 368/1904 art. 133: da 4 a 10 m, oppure secondo il regolamento del
    Consorzio;
  - Codice della Navigazione art. 55: 30 m.
- Demanio marittimo, nella PL:
  - la dividente è disegnata in magenta, in corografia e nelle tavole;
  - la legenda dice «DIVIDENTE DEMANIALE» e «Fascia di rispetto 30 m dalla
    dividente demaniale (art. 55 Cod. Nav.)», senza indicare le fonti;
  - in corografia c'è anche la fascia.
- Se c'è solo la costa OSM, la legenda dice «LINEA DI COSTA» e il registro
  avvisa di caricare la dividente.
- Con una dividente caricata la costa OSM non viene usata.
- Fascia del demanio marittimo solo verso terra: i 30 m disegnati sul mare
  non avevano senso.
  - Con la linea di costa OSM (la terra è sempre a sinistra della linea) la
    fascia sta solo dal lato terra.
  - Con la dividente il lato del mare si ricava dalla costa OSM vicina. La
    zona è la spiaggia demaniale fra dividente e mare più i 30 m verso terra.
  - Senza costa per orientarla, la fascia resta sui due lati e il registro
    lo segnala.
  - Vale per la ricerca delle interferenze, per il layer in mappa e per la
    PL.
- Metri in fascia misurati sul disegno. Il campo LUNGHEZZA della tratta
  corregge la misura solo se coerente col disegno (entro il 10%). Prima uno
  spezzone di 11 m in fascia con LUNGHEZZA 60 diventava «Mt 60». Quando
  succede, la nota della riga lo segnala.
- Ogni linea del layer corsi d'acqua ricorda la sua fonte (OSM, layer o
  disegno).
- Istanze a scelta: una per corso d'acqua oppure una per ente con tutti i suoi
  corsi d'acqua. Nessuna distinzione per tipologia di interferenza: le tavole
  inquadrano per zona quello che cade vicino all'acqua e le etichette dicono
  solo le lavorazioni.
- Interferenze e tavole in blu nella PL; numeri disegnati dentro il cerchio
  (sempre centrati) e voce «INTERFERENZE» in testa alla legenda.
- Tavole: ortofoto, planimetria e stralcio catastale alla stessa scala e con
  lo stesso inquadramento; zone calcolate sui punti delle interferenze (le
  tavole non si ripetono); in planimetria solo le etichette del plugin, una
  per interferenza inquadrata, disposte in modo da non sovrapporsi mai, da non
  coprire scavi, pozzetti e corso d'acqua e con linee di richiamo che non si
  incrociano.
- Corsi d'acqua più sottili (0,8 mm) e nomi in corsivo più fini con alone
  leggero; pallini e scritte TAV. proporzionati. In corografia ogni canale ha
  sempre il suo nome, una volta sola, anche se è corto o passa sul pallino
  della tavola.
- Istanza unica per ente: in legenda una voce per ogni canale col suo nome (i
  tratti senza nome in un'unica voce) e la fascia di rispetto con la misura
  di ogni categoria quando sono diverse.
- Nella PL solo il corso d'acqua dell'istanza (gli altri canali e fiumi non
  compaiono); per i fossi senza nome solo quelli dove ci sono le interferenze.
- Salva layer acque (e Salva layer RFI): non falliva più in silenzio quando il
  GeoPackage esisteva già con layer aperti in QGIS.
- «Disegna corso d'acqua…»: se OSM non ha il canale o il fiume e non c'è un
  layer, si traccia a mano nel layer «Corsi d'acqua disegnati» (GeoPackage
  accanto al progetto, stile della scheda, categoria a tendina, ente
  facoltativo); il caricamento lo usa insieme a OSM.
- Layer nel gruppo «Acque - Demanio idrico e marittimo», salvabili in
  GeoPackage con gli stili.
- Lavoro salvato nel progetto. Due nuovi layer in mappa:
  «Tratte in fascia acque», con gli scavi continui in fascia;
  «Etichette acque», un punto per scavo e pozzetto con testo proposto e testo
  in tavola, correggibile anche dalla tabella attributi.
- «Salva nel progetto…» scrive tutti i layer acque in
  01_File shp\Acque\Layer_Acque_<COMUNE>.gpkg con gli stili, li rimette nel
  progetto e, con conferma, salva il progetto.
- Alla riapertura del progetto tornano comune, fasce e scelta delle istanze.
  «Trova interferenze» riprende i corsi d'acqua dal progetto, senza rifare il
  caricamento, e rimette testi corretti, enti, spunte e vie. Le ricerche
  successive aggiornano anche il GeoPackage.

## Versione 2.9.19

### Istanze RFI: provincia e CAP seguono il comune

Cambiando il comune, provincia e CAP vengono aggiornati con quelli del nuovo
comune (prima restavano quelli del comune precedente se già compilati).
Indirizzo e PEC del comune precedente vengono svuotati; se il comune non viene
trovato i campi si svuotano, da compilare a mano.

## Versione 2.9.18

### Comune › Seleziona elementi: regola 4, strade private carrabili

Nuova regola «4) Elementi nuovi su strade private carrabili (OSM)». Seleziona
gli elementi STATO='Nuovo' che ricadono su strade private (accessi, strade di
servizio, passi carrai da OpenStreetMap):
- pozzetti e armadi ottici entro la distanza dall'asse della strada
  (predefinita 3 m, circa mezza carreggiata);
- tratte di Infrastrutture che corrono sulla strada privata per almeno la
  quota indicata della loro lunghezza (predefinita 50%).

Tre caselle scelgono quali layer interrogare. «Carica dal GeoPackage…» legge
dal file delle strade private, anche quello nazionale da 400.000 tratti, solo
la zona attorno al progetto (+300 m), in un layer leggero «Strade private
carrabili (OSM)». Il file scelto viene ricordato. Il log elenca, layer per
layer, gli elementi selezionati e le strade interessate, insieme a quante
strade private OSM ha considerato nella zona: così uno 0 si distingue da
«qui OSM non ha strade private». I layer non leggibili o vuoti si saltano
con un avviso, invece di bloccare la regola. Dopo la selezione un
avviso ricorda di controllarla sulla mappa: i dati OSM possono essere
incompleti (passi carrai mancanti) o imprecisi.

«Rimuovi elementi selezionati» ora, quando l'ultima regola ha selezionato su
più layer, chiede con una casella per layer da quali cancellare. Vale anche
per le regole esistenti, per esempio la 1 su tratte e pozzetti.

### Altri Enti: nuovo gruppo «Istanze Strade»

Le schede Chilometriche, Etichette e Suolo comunale, che servono per le istanze
agli enti stradali, sono raccolte nella nuova scheda «Istanze Strade», come
«Istanze RFI» raccoglie quelle per le ferrovie. In Altri Enti l'ordine è:
Istanze Strade, Istanze RFI, Screening territorio, Fasce di rispetto,
Esportazione. Il plugin si riapre anche sulla scheda di Istanze Strade
lasciata aperta.

### Rifiniture planimetria e relazione

- **Rese del cronoprogramma modificabili.** Nella scheda RFI c'è il riquadro
  «Rese per il cronoprogramma», chiuso finché non si spunta. Contiene 13
  valori:
  - scavo per tecnica (m/giorno);
  - posa pozzetti per misura (pezzi/giorno);
  - ripristino del manto per tecnica (m/giorno);
  - buche no-dig (giorni per tratta);
  - chiusini (pezzi/giorno).

  I valori si ricordano fra le sessioni e «Valori predefiniti» li riporta a
  quelli di partenza. In `ftth_rfi.py`, `rese_complete()` unisce i valori
  della scheda ai predefiniti e ignora quelli nulli o non numerici.

- **Layer RFI in un gruppo e salvabili.**
  - Ferrovia, fascia, cippi, stazioni e interferenze finiscono da soli nel
    gruppo «RFI - Ferrovie».
  - Il pulsante «Salva layer RFI…» li scrive in un GeoPackage
    (`Layer_RFI_<comune>.gpkg`) nella cartella scelta, con gli stili
    incorporati.
  - Nel progetto, i layer temporanei sono sostituiti da quelli salvati nello
    stesso gruppo.
- **Relazione: indice e numeri allineati.** Nel modello «CRONOPROGRAMMA»
  stava nella lista di SCAVI / POSA POZZETTI e usciva «3.», così tutti i
  capitoli successivi scalavano di uno.
  - Ora i capitoli sono numerati fissi da 1 a 12, come nell'indice, e i
    sottoparagrafi sono «1.1 SCAVI» e «1.2 POSA POZZETTI».
  - Durante la conversione in PDF Word aggiorna i numeri di pagina
    dell'indice.
  - Le tabelle non sono più flottanti: il titolo dopo una tabella non le si
    affianca.
- **Relazione coerente con la PL.**
  - Nel capitolo TECNICHE DI SCAVO restano solo le tecniche usate.
  - Senza pozzetti nuovi spariscono anche le frasi generiche sui pozzetti.
  - Sotto il cronoprogramma, al posto del rimando ai particolari, c'è la nota
    «*I giorni indicati comprendono anche i ripristini stradali eseguiti, a
    regola d'arte, sulle superfici interessate dai lavori.». Il calcolo dei gg li conta
    davvero: scavo + posa pozzetti + ripristino del manto e dei chiusini.
- **Un'etichetta per ogni scavo** in planimetria, sul proprio tratto: scavi
  diversi hanno etichette diverse. I pozzetti hanno sempre il km («KM
  XXX+XXX» finché non ci sono i cippi).

- **Foto e sezioni piazzate sulla mappa, come in Altri Enti.** Si usano i
  layer «Punto di Ripresa Fotografico» (NumeroFoto, Rotazione) e «Sezioni»
  (sezione, sezione_f). In ogni tavola:
  - in planimetria compaiono quelli che cadono nel riquadro, con lo stile del
    progetto (il cono orientato dalla Rotazione, le sigle A-A') e a dimensione
    piena;
  - in legenda formano il blocco «FOTO E SEZIONI»;
  - il riquadro FOTO prende `04_Foto/FOTO-n.jpg` dei due punti di ripresa più
    vicini;
  - il riquadro SEZIONE prende `05_Sezioni/SEZIONE A-A'.svg` della sezione
    disegnata;
  - se `sezione_f` è vuoto vale «A'».

  Senza punti di ripresa o sezioni nel riquadro valgono le regole di prima
  (colonna Foto, sezione tipo). Il pulsante «Prepara layer Foto e Sezioni»
  della scheda RFI crea i due layer se mancano. Li crea in GeoPackage in
  `01_File shp`, con gli stili portati nel plugin
  (`styles/rfi_punto_ripresa.qml` e `styles/rfi_sezioni.qml`), insieme alle
  cartelle `04_Foto` e `05_Sezioni`.
- **Foto a riquadro pieno.** La foto si ritaglia al centro sulle proporzioni
  del riquadro, in `_immagini_tavole`. Non resta più la fascia vuota e la foto
  non si deforma; l'orientamento EXIF è rispettato.
- **Etichette PL senza sovrapposizioni e senza perdite.** Le posizioni le
  calcola il plugin tavola per tavola, conoscendo scala e riquadro della
  planimetria.
  - Per ogni etichetta, nell'ordine scavo > km di ingresso > pozzetti > NON
    DI COMPETENZA, prova 8 direzioni a distanze crescenti.
  - Prende la prima posizione che resta nel riquadro e non tocca le etichette
    già messe; la linea di richiamo la collega al punto.
  - Prima se ne occupava il motore di QGIS: le aree della cartografia di base
    facevano da ostacolo ovunque, e due etichette finivano una sull'altra o
    una spariva.
  - Scavo e pozzetto a meno di 10 m l'uno dall'altro formano un'unica
    etichetta.
  - Se i km di ingresso in fascia sono noti, l'etichetta dello scavo non li
    ripete.
- **Tre cartelle separate nella scheda RFI**: sezioni, foto e particolari.
  Se una cartella è vuota si usano `05_Sezioni` e `04_Foto` del progetto, e i
  particolari del plugin. Se nel vecchio campo unico c'era una cartella
  «…Sezioni», passa da sola nel campo sezioni.

- **Particolari costruttivi nel plugin.** Le 19 tavole PC-01…PC-19 sono in
  `assets/rfi_particolari` (SVG). Il plugin le porta con sé e funziona anche
  su un altro PC. Nella tavola PC finiscono solo quelle che servono, tutte alla
  stessa scala:
  - la sezione di ogni tecnica presente (minitrincea, microtrincea, trincea,
    no-dig);
  - i pozzetti per misura;
  - l'armadio, se in fascia;
  - il tubo Fender.

  Una cartella utente con file dello stesso nome ha la precedenza.
- **Etichette senza sovrapposizioni.** Ogni etichetta prende una delle otto
  posizioni attorno al punto, staccata e con una linea di richiamo.
  «NON DI COMPETENZA» è in nero. Il km compare solo se è noto («km da
  verificare» si scrive una volta sola, sull'etichetta dello scavo).
- **Legenda** con caratteri più grandi e senza i codici iniziali dei layer e
  delle categorie: «03 INFRASTRUTTURE» diventa «INFRASTRUTTURE». Le voci sono
  divise in due blocchi, «RETE FIBERCOP» ed «ELEMENTI FERROVIARI», senza il
  titolo «SIMBOLOGIA».
- **Metri di scavo a cifra tonda** in tavola e in relazione (computo e
  cronoprogramma). Il mezzo metro si arrotonda per eccesso: 104,5 diventa
  105. I totali sono somme di valori interi, quindi tornano.
- **Cronoprogramma coerente.** Ogni riga è in mezze giornate e i totali sono
  la somma delle righe. Prima la riga si arrotondava al giorno intero e il
  totale no, così 2 + 1 dava un totale di 2.
- **Cronoprogramma con posa pozzetti e ripristini.** Nuova colonna «Posa
  pozzetti (n)»; la colonna dei giorni si intitola «Giorni» (prima «gg»). I
  giorni di ogni riga comprendono scavo, posa dei pozzetti e
  ripristini. La riga «Totale» somma le quantità (metri per tecnica,
  pozzetti) e i giorni. Le rese sono stime, modificabili in `ftth_rfi.py`:
  - posa pozzetti, al giorno: 125x80 → 2, 90x70 → 3, 76x40 → 4, 45x15 → 6;
  - ripristino del manto, al giorno: minitrincea 250 m, microtrincea 300 m,
    trincea 120 m;
  - no-dig: mezza giornata per le buche;
  - ripristino attorno ai chiusini: 8 pozzetti al giorno.
- **Scale verificate.** Misurate sul terreno, le tavole di Eboli scostano
  meno dello 0,3% dalla scala dichiarata. Se il progetto è in Web Mercator
  (EPSG:3857) le tavole si fanno nel fuso UTM: altrimenti la scala sarebbe
  sbagliata di circa il 30%. Anche il riquadro ORTOFOTO ora riporta la sua
  scala (1:5000).
- **Cartiglio**: nel riquadro TAVOLA c'è solo il numero (1, 2, PC,
  COROGRAFIA); prima «TAVOLA» era ripetuto.
- **Copertina della relazione sempre in una pagina.** Prima, con oggetti
  lunghi, il riquadro PROGETTISTA finiva sulla pagina dopo. Ora le righe vuote
  nelle celle sono ridotte, le altezze minime sono più basse e le righe non si
  spezzano. Anche il nome del file non va più a capo.
- **Relazione con spaziature uniformi.** Dalla premessa in poi le righe vuote
  sono tolte. Il corpo ha interlinea 1,5 e 6 pt dopo ogni paragrafo. I titoli
  hanno 18/8 pt, i sottotitoli 12/4 pt.

### Istanze ferroviarie: tutte le tipologie, una istanza per gruppo, PDF e planimetria

La scheda «Istanze RFI» è stata rifatta. Copre ora le quattro tipologie del
documento «Elenco documenti per presentazione nuova istanza» e anche i gestori
in concessione (FS Ferrovie Sud Est, FER, …), non solo RFI.

- **Interferenze trovate dal plugin.** Si scaricano ferrovie, cippi km e
  stazioni da OSM, poi «Trova interferenze» incrocia 03 INFRASTRUTTURE con la
  linea e propone la tipologia:
  - A: tratta esistente che attraversa (riutilizzo; il proprietario si legge
    dal campo PROPRIETA o GESTORE, se c'è);
  - C: attraversamento No Dig;
  - B: attraversamento con scavo nuovo;
  - D: parallelismo in fascia 30 m. Sotto i 6 m dalla rotaia compare
    un'avvertenza sulla proprietà del gestore.

  Gli scavi di avvicinamento a un attraversamento B/C restano con quello.
  Per ogni interferenza: km dai cippi, metri per tecnica, pozzetti nuovi in
  fascia, stazione più vicina.
- **Tabella da confermare.** Tipologia, linea, stazione, km, proprietario e foto
  si correggono in tabella; «Includi» toglie una riga. Le interferenze compaiono
  anche in mappa nel layer «Interferenze ferroviarie».
- **Una istanza per tipologia, gestore, linea e stazione.** Ognuna ha la sua
  cartella in `Istanze RFI/<COMUNE>/` con:
  - 1.0 art. 49;
  - 1.1 PL in PDF;
  - 1.2 RT+CR in Word e PDF;
  - 1.3 Bollo;
  - 1.4 Modello B;
  - LEGGIMI con i promemoria (sopralluogo congiunto per B e C, Allegato J ed
    esito dell'ente terzo per A).

  Nella cartella del comune c'è anche un riepilogo Excel.
- **Destinatari.** RFI usa la DOIT della regione (con PEC); FSE e FER usano i
  dati delle pratiche Andrano e Poggio Rusco. Gli altri gestori si compilano in
  tabella; ciò che manca resta XXXXX.
- **Modelli Word parametrizzati.** Tolti i testi fissi delle pratiche
  precedenti (DOIT di MILANO, indirizzo di Chiavenna, «Milano-Venezia dal km
  100+120»). Oggetto, titolo della tipologia, allegati del Modello B, testi
  della relazione e nome dei file cambiano con la tipologia.
- **Campi nelle tabelle annidate.** La sostituzione ora raggiunge anche le
  tabelle annidate: prima nome file e data nel cartiglio della RT e l'oggetto
  del Bollo restavano `<<NOME_COMUNE>>`. A capo e formattazione si conservano.
- **Firmatari.** Procuratore e referenti restano XXXXX, come nelle pratiche
  inviate.
- **Timbro.** Rimossa dal modello RT l'immagine di un timbro professionale che
  restava allegata nel file.
- **PDF.** La conversione usa Microsoft Word, oppure LibreOffice se presente.
- **Planimetria 1.1 PL.** È un layout QGIS A3 per istanza, esportato in PDF.
  Pagine:
  - corografia su OpenStreetMap;
  - una tavola per interferenza: ortofoto, planimetria in scala con km e metri
    per tecnica, estratto catastale (WMS Agenzia delle Entrate), sezione tipo,
    foto;
  - tavola dei particolari costruttivi.

  Il cartiglio porta i loghi FiberCop e Beexact, senza timbro. Il riquadro
  della sezione accetta un'immagine in `assets/rfi_sezioni/sezione_tipo_X.png`.

**Dopo la prova sul progetto reale di Eboli** (linea RFI 124 Battipaglia–Potenza–
Metaponto: 8 interferenze, 5 istanze):
- **Base delle tavole.** Corografia e planimetria usano il gruppo «Cartografia»
  del progetto (CTR DBSN, lo stesso delle stampe di Altri Enti). Il catasto usa
  il gruppo «Mappa Catastale». OpenStreetMap e il WMS dell'Agenzia delle Entrate
  restano come riserva se i gruppi mancano.
- **Ortofoto.** Si sceglie per parole intere, con questa priorità: «Google
  Satellite», satellite, ortofoto, imagery, AGEA. Prima «orto» trovava anche
  «Trasp*orto*», cioè un WMS di etichette stradali, e la tavola restava vuota.
- **Etichette e legenda.**
  - Le etichette km/scavi delle interferenze si disegnano sempre, prima di
    quelle del progetto.
  - La legenda mostra solo le voci presenti nella planimetria e ha più spazio.
- **Cippi km da un layer del progetto** (scelta facoltativa nella scheda, con
  il campo del km). Serve dove OSM non ha i cippi ferroviari, come a Eboli.
- **Testi.**
  - Provincia in sigla dalla precompilazione («Salerno» → SA).
  - Niente più «della linea Linea …» nel Modello B.
  - Per la tipologia A la tabella degli scavi dichiara che non ci sono nuovi
    scavi.

**Dopo la revisione delle tavole e della relazione:**
- **Corografia.** Metà su ortofoto e metà sulla cartografia del progetto,
  stessa scala.
- **Cartiglio.**
  - Logo Beexact pulito (quello della relazione), non più il banner scuro.
  - Il blocco in basso arriva fino al bordo, senza spazio vuoto.
- **Estratto catastale.**
  - Scala 1:1000, con i numeri di particella (WMS AdE: `codice_plla`,
    `vestizioni`; il gruppo «Mappa Catastale» dei progetti non li contiene).
  - Il numero del foglio è nel titolo, letto dal WMS sul punto
    dell'interferenza.
- **Particolari costruttivi in SVG vettoriale**, estratti dalle tavole di
  Poggio Rusco e ripuliti di tutto ciò che stava fuori dal riquadro.
  - Nella tavola PC entrano solo quelli delle lavorazioni presenti: una
    sezione per tecnica, un pozzetto per dimensione, le tubazioni.
  - Quelli mancanti (minitrincea, No Dig, altre misure di pozzetto) sono
    segnalati nel riquadro e nel registro.
- **Cartella personale per sezioni, foto e particolari** (scheda RFI, punto
  5, ricordata da QGIS). Vi si cercano, prima dei file del plugin:
  - `sezione_tipo_A…D`;
  - `foto_<n>`;
  - `sezione_<tecnica>`, `pozzetto_<dim>`, `tubi`.

  Formati SVG, PNG o JPG; vanno bene anche le sottocartelle `sezioni/`,
  `foto/` e `particolari/`.
- **Etichette km** per ogni pozzetto e armadio nuovo in fascia, calcolate dai
  cippi.
- **Relazione.**
  - «Alla c.a. della Spettabile» al singolare.
  - La premessa è un unico paragrafo giustificato, senza a capo né righe
    vuote.
  - Nelle tabelle i valori sono centrati: tolti i paragrafi vuoti e
    l'interlinea 2,5 della colonna Tot.
- **Scheda RFI.**
  - Scritto il comune, provincia (sigla), CAP e DOIT si compilano da soli
    (Nominatim, circa 1 secondo).
  - Il download OSM interroga i server in parallelo e salva una cache di 30
    giorni. I server pubblici rispondono comunque in 30-60 secondi al primo
    scaricamento.
  - Spiegazione della DOIT nel suggerimento del campo e messaggio «Generata
    1 istanza» al singolare.

**Dettaglio più pulito e relazione:**
- **Cosa entra in tavola e nei conti.**
  - **In tavola** si vede lo scavo intero che tocca la fascia, anche la parte
    fuori fascia, con le etichette «KM …» dove entra o esce dalla fascia e
    «NON DI COMPETENZA» sul tratto esterno.
  - **Nel computo metrico e nel cronoprogramma** conta solo la parte dentro la
    fascia. Se c'è il campo LUNGHEZZA, quella parte è proporzionata a quel
    valore.
  - Gli scavi del tutto fuori fascia non compaiono né in planimetria né in
    relazione.
  - Pozzetti e armadi fuori fascia ma attaccati allo scavo si disegnano, ma
    non si contano e non hanno etichetta di posa.
  - In planimetria ci sono copie filtrate dei layer 03 INFRASTRUTTURE,
    02_POZZETTO e 01_ARMADIO OTTICO, con lo stesso stile e le stesse
    etichette; la legenda tiene i nomi originali.
- **Catasto più leggibile.** L'estratto è un'immagine a 110 dpi, perché il
  WMS scrive i numeri con una dimensione fissa in pixel e a 200 dpi uscivano
  minuscoli. Le immagini restano in `_immagini_tavole/` accanto al PDF.
- **Tavola dei particolari.**
  - Solo i particolari disponibili; quelli mancanti si segnalano nel
    registro.
  - Nel cartiglio c'è il titolo «PARTICOLARI COSTRUTTIVI» al posto della
    legenda vuota.
- **Logo Beexact nuovo** (arancio/blu, dal file SVG del plugin) nel cartiglio
  e nell'intestazione della relazione, al posto del vecchio nero/arancio.
- **Relazione.**
  - Interlinea 1,5 e testo giustificato anche per trincea tradizionale, No
    Dig e canala.
  - Riga vuota prima dei sottotitoli.
  - Titoli legati al testo che li segue: «4. TECNICHE DI SCAVO» non resta più
    da solo in fondo alla pagina.
  - Nuovi blocchi descrittivi presi dalla relazione di Battipaglia:
    - «POZZETTO CLS» (II-PMI-027) e «CHIUSINO GHISA», solo se l'istanza ha
      pozzetti nuovi in fascia;
    - «ARMADIO OTTICO», solo se c'è un armadio in fascia.
  - Tabella pozzetti con una riga per km di posa («Al km 74+813») e solo per
    i punti con pozzetti.

Test: `tests/test_rfi.py` (21 casi: tipologie, gestori, interferenze,
raggruppamento, km di pozzetti e armadi, testi, sigle delle province,
documenti Word di tutte le tipologie).

## Versione 2.9.17

### Screening: errore «too many values to unpack» nei comuni con un SIN

Lo screening di Manfredonia si fermava all'analisi sul tracciato con
`too many values to unpack (expected 2)`. Le geometrie dei vincoli sono coppie
(etichetta, geometria), ma quella dei **SIN** (Siti di Interesse Nazionale per
le bonifiche, banca dati ISPRA/MOSAICO) veniva salvata come geometria nuda:
l'analisi provava a dividerla in due e trovava tre parti. Succedeva solo nei
comuni che contengono un SIN, per questo non era mai emerso. Ora anche il SIN
è una coppia («SIN - Sito di Interesse Nazionale — nome»). Verificato con un
caso che riproduce l'errore: prima fallisce, ora passa e il tracciato che
attraversa il SIN risulta «attraversato».

### Registro: «Ferrovie: 0» anche quando Overpass non aveva risposto

Se l'interrogazione di ferrovie e corsi d'acqua falliva, il report riportava
correttamente «NON verificati», ma il registro scriveva comunque «Ferrovie: 0 ·
corsi d'acqua denominati: 0», come un controllo andato a buon fine senza
risultati. Ora il registro dice che non sono stati verificati. (Per
Manfredonia, interrogato di nuovo, Overpass restituisce la linea RFI
Foggia–Manfredonia e 8 corsi d'acqua con nome.)

## Versione 2.9.16

### Etichette delle tratte: richiamo dal centro e posizione stabile allo zoom

Due difetti segnalati sulle etichette create dalla scheda Etichette, entrambi
riprodotti in QGIS prima di correggerli.

**Il richiamo partiva da un estremo della tratta.** Le etichette delle tratte
usavano il posizionamento «posizioni ordinate attorno al punto», che per le
linee non esiste: QGIS ripiegava sul primo vertice della tratta e la linea di
richiamo si agganciava lì. Ora il richiamo ha come destinazione il **centro
della tratta**, calcolato con un'espressione.

**Le etichette saltavano a ogni zoom.** Un'etichetta non ancora spostata a mano
finiva sul primo vertice della *parte visibile* della tratta: zoomando o
spostando la mappa la parte visibile cambia, e l'etichetta con lei (misurato:
0,9 m a 1:1000, 0 m a 1:2000). Ora la posizione di partenza è un **punto fisso**:
a lato del centro della tratta, perpendicolare alla tratta, alla distanza dello
scostamento impostato (12 mm = 12 m, cioè come appare a 1:1000). Verificato:
stessa posizione a 1:500, 1:1000 e 1:2000.

- Le etichette già spostate a mano (campi LBLX/LBLY compilati) restano
  esattamente dove sono: l'allineamento non è stato toccato, quindi nessuna si
  sposta.
- Lo scostamento si calcola in metri reali con qualunque sistema di coordinate
  (shape in WGS84, progetto in EPSG:25832): durante l'etichettatura QGIS non
  fornisce il CRS della mappa, quindi il calcolo passa da Web Mercator con la
  correzione di latitudine.
- Se una versione di QGIS non riconoscesse l'espressione, il registro lo dice e
  si torna al comportamento precedente invece di fallire in silenzio.
- Comportamento normale di QGIS, non cambiato: un'etichetta è disegnata solo se
  la sua tratta è inquadrata.

Per le etichette già create va rilanciata la generazione delle etichette sul
layer, così l'etichettatura viene reimpostata con le nuove regole.

## Versione 2.9.15

### Pozzetti di Rete Pubblica

Le tratte di Rete Pubblica si riconoscono dai loro attributi (PROPRIETA,
note). I pozzetti no: sui dati reali PROPRIETA è sempre FCOP e le note sono
vuote. L'informazione si ricava dalla geometria.

La scheda **Shape → GeoPackage**, quando lo stile da applicare è
02_POZZETTO, marca come Rete Pubblica ogni pozzetto con STATO «Esistente»
che tocca una tratta di Rete Pubblica di 03 INFRASTRUTTURE. L'esito va nel
nuovo campo **RETE_PUBB** («SI»/«NO»), che lo stile 02_POZZETTO disegna in
arancione e la macro di quantificazione mette nella tabella 02b. Il nome
sta nei 10 caratteri del DBF, quindi sopravvive all'esportazione in
shapefile e al join.

- Le tratte di Rete Pubblica si riconoscono con la stessa espressione dello
  stile 03_INFRASTRUTTURE (modulo `ftth_rete_pubblica.py`), così stile,
  plugin e macro non possono divergere.
- Si leggono dalla sorgente **senza filtri**: con un filtro STATO='Nuovo'
  sul layer delle tratte (sono quasi sempre Esistenti) si sarebbero trovati
  zero pozzetti senza alcun errore.
- Tolleranza di contatto 10 cm. Su Deruta i 27 pozzetti trovati toccano le
  tratte a distanza esattamente zero, e il risultato non cambia fra 0 e 1 m.
- A ogni giro il campo viene riscritto per tutti («NO» compreso), così un
  «SI» rimasto da una conversione precedente non sopravvive.
- Se 03 INFRASTRUTTURE non è nel progetto, il messaggio finale lo dice
  invece di lasciare i pozzetti senza marcatura in silenzio.

## Versione 2.9.14

### Un server che non ha cercato non è un territorio senza ferrovie

A Rodi Garganico lo screening rispondeva «Ferrovie: 0», «Strade
classificate: 0» e «comune non costiero». Il tracciato invece attraversa
la San Severo–Peschici (tratta aerea) e corre a 16–27 m dai binari in
altri punti; le provinciali ci sono e il comune è sul mare.

La causa non era nel calcolo delle distanze, che era corretto, ma nei dati
in ingresso. Alcuni nodi dei server Overpass di riserva
(overpass.kumi.systems, overpass.private.coffee) hanno l'indice delle aree
vuoto o fermo a mesi fa: davanti a una query «dentro il confine comunale»
rispondono **200 OK, zero elementi, nessun avviso**. Il plugin scartava già
le risposte con `remark` di errore, ma questa non ne ha: sembrava un
«nessun risultato» legittimo ed era accettata. Misurato: nella stessa
mezz'ora lo stesso server ha restituito 0 elementi da un nodo e 15 da un
altro.

Le query per confine comunale ora chiedono al server di restituire anche
l'area del comune. Se l'area non c'è, il server non ha risolto il confine:
la risposta viene scartata e si passa all'endpoint successivo. Se nessuno la
risolve, lo screening lo dice («NON verificate»), invece di scrivere
«nessuna». Un comune davvero senza ferrovie continua a dare zero, perché lì
l'area torna e la lista è vuota.

È probabilmente lo stesso fenomeno annotato a suo tempo su Letojanni
(«map_to_area dava 0»), allora attribuito alla geometria della costa.

### Costa non verificata ≠ comune non costiero

Se Overpass non rispondeva, il controllo della linea di costa restituiva
«no»: la fascia costiera di 300 m spariva in silenzio. Ora l'esito è «non
verificato», con avviso nel report.

### Non tutte le ferrovie sono RFI

La linea di Rodi è delle **Ferrovie del Gargano**, non di RFI: lo screening
la intestava a «RFI – Struttura Territoriale di Bari». Ora il gestore letto
da OpenStreetMap decide l'ente: linee RFI alla struttura RFI come prima;
linee in concessione/regionali (Ferrovie del Gargano, FAL, FSE,
Ferrotramviaria…) al gestore della linea, con l'avvertenza che la fascia di
30 m dell'art. 49 DPR 753/1980 vale anche per loro. Se OSM non riporta il
gestore, resta RFI ma marcato «da confermare». I contatti DOIT RFI nel
report compaiono solo se c'è almeno una linea RFI, e la scheda RFI avvisa
quando la linea non è RFI.

### Il trigger dice cosa succede sul tracciato

In analisi sul tracciato l'ente ferroviario riportava sempre «linea
ferroviaria nel territorio comunale». Ora riporta «ATTRAVERSAMENTO del
tracciato» oppure «tracciato a N m (entro fascia 30 m)», come già avveniva
per i corsi d'acqua.

## Versione 2.9.13

### Chi gestisce davvero quella strada

Scrivere «alla Provincia» dove la competenza stradale è passata ad altri
significa mandare l'istanza a un ente che quella competenza non ce l'ha
più: il permesso non arriva, e il silenzio si scopre settimane dopo.

Lo screening ora nomina l'ente gestore reale, per classe di strada e per
territorio: **ASTRAL** nel Lazio, **FVG Strade** in Friuli-Venezia Giulia,
**Veneto Strade** in Veneto, **ASSET** in Puglia, i **Liberi Consorzi**
siciliani, le **Province autonome** di Trento e Bolzano, la Struttura
Viabilità valdostana.

Il caso più insidioso è il Friuli: dalla LR 14/2021 le ex provinciali sono
degli **Enti di Decentramento Regionale**, e l'EDR giusto dipende dalla
provincia del comune — Gorizia, Pordenone, Trieste o Udine sono enti
distinti. Se la provincia non è nota, il report scrive «(provincia da
indicare)» invece di tirare a indovinare.

L'ordine di precedenza conta: vale prima il tag `operator` letto da
OpenStreetMap, che è il dato della tratta; la tabella interviene solo
quando quel dato manca, e allora l'ente è marcato **«(da confermare)»**.
Quando l'ente dedotto diverge da quello atteso, il report spiega perché e
cita la norma, così «EDR di Udine» al posto della Provincia si legge come
una competenza, non come un errore del programma.

La tabella copre tutte e venti le regioni e ciascuna voce porta la nota che
la giustifica. Resta un suggerimento da verificare: gli assetti cambiano,
alcune regioni gestiscono in economia o per lotti.

## Versione 2.9.12

### QGIS non si blocca più durante lo screening

Lanciando lo screening territorio, QGIS si congelava e restava congelato:
finestra bianca, «Non risponde», log fermo sulla stessa riga, e l'unica via
d'uscita era ucciderlo da Gestione attività.

Lo screening girava **dentro il thread dell'interfaccia**, quindi mentre
interrogava i server pubblici la finestra era ferma ad aspettare. E
l'attesa poteva durare ore, perché ogni richiesta aveva la sua scadenza ma
non esisteva un tetto complessivo: i limiti si moltiplicavano.

- Una sola interrogazione a OpenStreetMap: 4 server × 2 giri = **868 s**
  (14,5 minuti) nel caso peggiore. Le interrogazioni per screening sono tre.
- Un solo layer SITAP: 40 pagine × 120 s = **4.800 s** (80 minuti). I layer
  SITAP interrogati sono nove.

Il caso che faceva danno non era il server morto — quello scade e si
recupera — ma il server **lento ma vivo**: risponde, quindi nessuna
scadenza scatta mai, e i minuti si sommano in silenzio.

Ora lo screening gira in un thread separato e la finestra resta viva e
usabile; l'avanzamento arriva al log via segnale, e ogni riga dichiara
quanto si è disposti ad aspettare («Overpass: rete stradale, 4 endpoint con
ritentativo (max 180 s)…»). Accanto ad Avvia c'è un pulsante **Annulla**,
che ferma il lavoro senza uccidere niente: misurato, si ferma in 0,03
secondi su una lavorazione da 120 e non produce né layer, né report, né
Excel. Chiudendo la finestra mentre lo screening gira, il lavoro viene
interrotto e atteso con una scadenza, invece di lasciare un thread vivo.

### Tetti di tempo: minuti, non ore

Budget complessivo di 15 minuti (lo screening reale su Coriano ne impiega
poco più di 6), più un tetto per ciascuna fonte, così che una sola fonte
lenta non si mangi il tempo di tutte le altre. Misurato su un server lento
ma vivo: l'interrogazione a OpenStreetMap passa da **52 s e 8 richieste** a
**19 s e 4 richieste**.

Il doppio giro su OpenStreetMap — quello che recuperava le strade mancanti
di Fabrica di Roma — **resta**, e dentro il budget il giro di ritentativo
ha sempre tempo garantito: la prova continua a riportare a casa i 73
elementi.

### Una fonte che non risponde non è una fonte senza vincoli

È la parte che conta di più. Quando una fonte viene abbandonata per tempo
scaduto, per annullamento o perché il servizio non risponde, il report lo
**dichiara**, fonte per fonte: «SITAP non ha risposto: i vincoli
paesaggistici (art. 136/142) NON sono stati verificati. L'assenza di
vincoli in questo report non significa assenza di vincoli». La fonte
risulta `NON VERIFICATA` nella tabella delle fonti.

Vale anche per gli stadi mai raggiunti: se si annulla all'inizio, vengono
dichiarati **tutti** quelli che non sono stati eseguiti, non solo quello in
corso. Un report con la tabella delle fonti vuota si legge come «nessun
vincolo», ed è il falso negativo da evitare su un dato cogente.

## Versione 2.9.11

### La fascia di rispetto si faceva sul layer sbagliato

Scegliendo l'ente «RFI - Ferrovia» e lasciando come sorgente il layer
`INFRASTRUTTURE`, il plugin disegnava diligentemente una fascia di 30 m
attorno alla **rete in progetto**. È il rovescio di quello che serve: il DPR
753/1980 art. 49 misura dalla rotaia più esterna, quindi la fascia nasce dal
binario e serve a capire se la rete ci finisce dentro. Il risultato era un
poligono ramificato che seguiva lo scavo — e, se finisce in un'istanza a
RFI, un errore che si paga.

La scheda non controllava nulla: bufferizzava qualunque layer fosse
selezionato nella tendina. Ora, se l'ente e il layer sorgente non c'entrano
niente fra loro (ente ferroviario con la rete del richiedente, ente stradale
con i pozzetti…), compare un avviso che spiega da dove si misura quella
fascia e chiede conferma, con «No» come risposta predefinita. Resta
possibile forzare — a volte serve — e la forzatura viene scritta nel log
della scheda.

In più, scegliendo l'ente viene proposto da sé il layer coerente già
presente nel progetto: per RFI e per i corsi d'acqua il layer «Ferrovie e
corsi acqua» dello screening territorio, per le strade «Strade
classificate». Se non c'è un candidato sensato, la scelta resta la tua.

### La classe della strada ora si legge dai dati, non si indovina

La distanza della fascia dipende dalla classe della strada, ma la classe
andava scelta a mano dalla tendina anche quando il dato era già nel
progetto: lo screening territorio classifica ogni strada (A, RA, SS, NSA,
SP, SR, SC, con i declassamenti già normalizzati).

Ora, selezionando un layer stradale, la classe viene letta dagli attributi e
la voce dell'ente si allinea (SP/SR → tipo C, SS → tipo B, A/RA → tipo A,
SC → tipo F). Se le classi presenti sono miste o il campo manca, non viene
dedotto niente: meglio una scelta a mano che una classificazione inventata.

**Limite dichiarato**: dagli attributi non si ricava se il tratto è dentro o
fuori il centro abitato — quella è la delimitazione ex art. 4 CdS, un atto
comunale che il plugin non possiede. La proposta è quindi sempre la voce
*fuori* centro abitato (art. 26 DPR 495/92), che è la distanza maggiore e
quindi il default prudente; spostarla su *dentro* resta una valutazione del
progettista. Una voce scelta a mano nella stessa classe non viene
sovrascritta.

### Excel dello screening: chi devi interpellare, e chi c'è e basta

Nel foglio «Enti da interpellare» finivano nello stesso elenco gli enti
toccati dal tracciato e quelli semplicemente presenti nel comune. Da fuori
sembravano la stessa cosa, e non lo sono: i primi sono lettere da scrivere,
i secondi sono contesto.

La distinzione esisteva già nei dati — l'analisi sul tracciato sa quali
strade sono entro fascia, quali fuori e quali non ha potuto misurare — ma
non arrivava al foglio. Ora ci sono tre sezioni, nell'ordine in cui servono:

1. **enti impattati dalla rete in progetto**, da interpellare, con il motivo
   concreto nella colonna Trigger (quale strada, quanti attraversamenti,
   quanti metri di affiancamento, quale vincolo);
2. **enti presenti nel territorio comunale**, contesto informativo;
3. **non verificabile con questo screening**, quando il dato non è stato
   ricalcolato sul tracciato.

Misurato su un cantiere reale (Coriano): SP41 con ~2.369 m di affiancamento
e 5 attraversamenti e SP49 con ~6.841 m e 23 attraversamenti restano in
cima; A14 a 337 m e SS72 a 300 m scendono nel contesto, perché il tracciato
non le tocca.

Se lo screening viene lanciato **senza tracciato**, sul solo nome del
comune, una banda rossa in testa al foglio dichiara che nessun ente può
essere detto impattato e che tutte le voci sono presenze nel territorio.

**Limite dichiarato**: Natura 2000, parchi e canali di bonifica non vengono
ricalcolati sul tracciato, restano dati comunali; per questo finiscono fra i
«non verificabili» e non fra gli impattati.

## Versione 2.9.10

### Lo screening non trovava le strade, e non diceva perché

Su alcuni comuni il report usciva senza strade classificate e sulla mappa
non compariva niente — succedeva a Fabrica di Roma, ma non sempre: lo
stesso comune, rilanciato più tardi, funzionava.

La causa non era il comune: erano i server pubblici di OpenStreetMap, che
quando sono carichi rifiutano le richieste a ondate di qualche minuto. Il
plugin faceva **un solo giro** sui quattro server disponibili; se capitavi
nell'ondata sbagliata tornava a mani vuote, e il risultato era
indistinguibile da «in questo comune non ci sono strade classificate». Che
è falso: a Fabrica di Roma ce ne sono nove (SP26, SP27, SP29, SP35, SP36,
SP65, SP66, SP71, SP74).

Ora i giri sono due, con una pausa in mezzo: il primo aspetta poco, per
agganciare al volo un server libero; il secondo è paziente. Nel caso
misurato bastava questo — primo giro a vuoto, secondo giro 73 elementi.

Se dopo due giri non risponde nessuno, compare un avviso che dice
chiaramente che la rete stradale **non è stata verificata**, invece di
lasciare una mappa vuota da interpretare.

### Etichette: metri che non corrispondevano alla linea disegnata

L'etichetta leggeva il campo `LUNGHEZZA` e non guardava la geometria. Ma il
campo resta indietro ogni volta che una tratta viene spostata, tagliata o
ricucita a mano in QGIS: su 30.844 tratte di cantieri reali, **9** avevano
il campo in disaccordo con il disegno, la peggiore con `17,50 m` scritti su
una tratta che ne misura `24,55`.

Ora l'etichetta misura la linea e la confronta con il campo: se vanno
d'accordo (entro 50 cm o il 2%) resta il valore ufficiale del campo; se
litigano viene riportata la misura vera **e lo scarto finisce nel
riepilogo**, con l'elenco delle tratte — perché il campo resta sbagliato
nei dati e finirà anche nel computo e negli export.

Secondo difetto, sullo stesso punto: quando l'etichetta ripiegava sulla
geometria, misurava nelle unità del CRS. Sui progetti di permesso non si
vedeva (sono tutti metrici), ma sugli export LLD, che arrivano in
coordinate geografiche, quelle unità sono GRADI: un'etichetta da 82 m
scriveva `0,0 m`. Ora, su dati in gradi, si misura sull'ellissoide.

Sui CRS proiettati la misura resta planimetrica, come il campo, il motore
di fusione, il CAD e il computo: misurare sull'ellissoide darebbe 99,7 m su
una tratta da 100,0 (fattore di scala UTM), più corretto in geodesia ma in
disaccordo con ogni altro numero della pratica.

### Lo stile si impuntava sulla prima scelta

Scegliendo una volta lo stile a mano nella conversione Shape → GeoPackage,
la scelta automatica restava spenta **per sempre**: da lì in avanti ogni
shape nuovo si portava dietro lo stile precedente, e convertendo
`ARMADIO.shp` dopo `POZZETTO.shp` usciva il disegno dei pozzetti. Bastava
anche solo riaprire il plugin, perché il ripristino delle impostazioni
accendeva da sé il blocco.

Ora la scelta a mano vale finché resti su quello shape; appena cambi file,
il plugin torna a proporre lo stile che corrisponde.

## Versione 2.9.9

### I coni di ripresa non comandavano più il punto, dopo aver riaperto il progetto

Ruotavi un cono, salvavi, e il campo `Rotazione` del punto di ripresa
restava com'era. Succedeva in un caso preciso: **dopo aver riaperto il
progetto**. Il riporto era agganciato al salvataggio dal momento in cui si
premeva "Genera coni", e quell'aggancio vive nella sessione, non nel file:
riaprendo, non c'era più nessuno in ascolto. Funzionava solo nella stessa
sessione in cui i coni erano stati generati.

Ora il riporto non dipende più dalla finestra del plugin: viene riagganciato
all'apertura del progetto, anche se il plugin non lo apri mai. Alla
generazione, il legame con il layer dei punti e i parametri del cono vengono
scritti nel progetto, così al riaggancio non c'è niente da indovinare.

Nei layer di coni generati prima di questa versione quel legame non c'è: il
plugin se la cava da solo se nel progetto c'è un solo layer di punti con il
campo `Rotazione`, altrimenti non prova a indovinare (scrivere le rotazioni
sul layer sbagliato è peggio che non scriverle). In quel caso basta
rigenerare i coni una volta.

### Il cono si rimpiccioliva da solo a ogni salvataggio

Quando la camera non segue il cono, il cono viene riancorato al punto e
ridisegnato. Il raggio usato per ridisegnarlo veniva però dedotto dal
rettangolo d'ingombro, che dipende da come il cono è orientato e sottostima
fino alla metà. L'errore si accumulava: misurato un cono da 6,00 m sceso a
0,41 m in cinque rotazioni. Adesso il raggio si misura sul cono stesso, e
resta quello.

### Un solo punto malformato azzerava il riporto di tutti gli altri

Un punto di ripresa senza posizione faceva fallire l'intero riporto: non
veniva scritta nessuna rotazione, nemmeno per i coni già letti
correttamente, e non compariva un messaggio da nessuna parte. Ora un dato
malformato viene scartato da solo, gli altri passano, e quanti ne sono stati
scartati è scritto nel log.

### Unisci tratte: fondeva attraverso le diramazioni

Due difetti nel riconoscimento dei nodi:

- il grafo veniva costruito solo sulle tratte che i filtri lasciavano
  passare, quindi una tratta esclusa (per stato o tipologia) non contava nel
  grado del nodo: dove c'era una diramazione a tre rami il plugin ne vedeva
  due e fondeva;
- i capi vicini venivano raggruppati confrontandoli con la media del nodo
  mentre la si costruiva. Con la digitalizzazione sporca (tre rami a 40 cm
  l'uno dall'altro, tolleranza 50 cm) l'esito **dipendeva dall'ordine in cui
  le geometrie venivano lette dal file**: a volte diramazione, a volte
  fusione.

Ora i capi si raggruppano per chiusura transitiva e il grafo si costruisce
su tutte le tratte. Misurato su 20 cantieri veri: 8.635 fusioni prima,
8.395 dopo — 240 fusioni arbitrarie in meno. Su un cantiere con il layer
pozzetti rotto si passa da 280 a 213.

### Unisci tratte: il dato non si perde più

Se la scrittura della geometria fusa fallisce, le tratte che la compongono
non vengono più cancellate (prima sparivano comunque). Se fallisce la
cancellazione delle tratte assorbite, l'operazione si ferma e avvisa, invece
di lasciare linee doppie sovrapposte e metri contati due volte.

Il layer dei pozzetti valido ma **vuoto** (sorgente sbagliata, filtro
attivo) ora avvisa come quando il layer manca del tutto: senza pozzetti
nessuna fusione viene bloccata, e il log diceva tranquillamente "bloccate da
pozzetto: 0".

### Lo stile nella conversione Shape → GeoPackage

Lo stile proposto si allinea da sé allo shape scelto (`POZZETTO.shp` →
`02_POZZETTO.qml`); se lo scegli tu, comanda il tuo. I file di backup
(`..._backup_20261006_091001.qml`) non compaiono più nell'elenco: non sono
stili, e in una cartella che ne conteneva diversi si presentavano come tali.

La scelta memorizzata viene ora ricordata **per nome** e non per posizione
nell'elenco: aggiungendo o togliendo file dalla cartella degli stili, la
posizione salvata finiva per indicare un file diverso.

### Screening territorio

Quando il report elenca le strade ma le geometrie non sono state scaricate,
il layer non veniva disegnato senza dire niente (visto su Pisogne: SP1,
SP55, SPBS510 nel report, niente sulla mappa). Ora avvisa.

### Dentro

- Il riporto delle rotazioni non vive più nella finestra: è una funzione a
  sé, verificabile senza interfaccia.
- Il motore di unione tratte è separato dall'interfaccia (`ftth_unisci.py`).
- `unload()` scollega i segnali che aveva collegato: dopo un "Ricarica
  plugin" la vecchia istanza non resta più agganciata al progetto.
- I guasti all'avvio finiscono nel registro messaggi di QGIS invece di
  sparire in silenzio.

## Versione 2.9.8

### Correzione: i simboli mancavano ancora sui PC dei colleghi

La versione 2.9.7 incorporava i disegni SVG nello stile al momento in cui
il plugin lo applicava. Era insufficiente, e in pratica non risolveva
niente: l'incorporamento riesce solo su una macchina che quei disegni li
ha sul disco. Su un altro PC non c'e' nulla da incorporare, il collegamento
resta rotto e compaiono i punti interrogativi al posto dei pozzetti.

La causa vera stava nei file di stile, non nel plugin. In particolare il
`POZZETTO.qml` del **MODELLO BASE** — quello da cui nasce ogni progetto
nuovo — puntava alla cartella OneDrive di un altro utente: un percorso che
non esiste su nessuna macchina, nemmeno su quella di chi lo aveva creato.
Ogni lavoro ripartiva quindi gia' difettoso.

Sono stati riparati 12 file di stile (pozzetti e armadi ottici), MODELLO
BASE compreso, incorporando i disegni una volta per tutte. Verificato
rendendoli con le cartelle dei simboli di QGIS svuotate, cioe' nella
condizione di chi non ha nessun file: tutti e 12 disegnano. Di ogni file
modificato resta un backup accanto all'originale.

Resta collegato solo `Arrow_06.svg`, che appartiene alla libreria standard
di QGIS ed e' presente su ogni installazione.

### Il plugin ora ritrova i simboli anche se il percorso e' di un altro

Quando applica uno stile, il plugin costruisce un indice dei disegni SVG
presenti sul disco e, se un percorso non esiste, ritrova il simbolo per
nome del file. Un nome viene accettato solo se tutte le copie trovate
hanno contenuto identico: se due file omonimi sono disegni diversi, la
corrispondenza sarebbe un'ipotesi, e un'ipotesi non va incollata dentro
uno stile. In quel caso il simbolo resta segnalato nel log.

## Versione 2.9.7

### I simboli degli stili ora si vedono anche sui PC dei colleghi

Lo stile dei pozzetti citava i file SVG con il percorso della cartella di
chi l'aveva creato (`C:/Users/<nome>/...`). Su un altro PC quel percorso
non esiste e il simbolo spariva: restava solo il contorno. Misurato su
`02_POZZETTO.qml`: 212 pixel di simbolo sulla macchina d'origine, 100 su
un'altra.

Non era un problema di un utente solo: nella cartella dei modelli
convivevano uno stile che puntava alla cartella di un utente e uno che
puntava al OneDrive di un altro. Ognuno vedeva solo il proprio.

Da questa versione il plugin **incorpora i disegni SVG dentro lo stile**
ogni volta che ne applica o ne salva uno — conversione shape in
GeoPackage, "ripara sorgente dati", salvataggio dei layer prodotti ed
esportazione delle tavole. Il simbolo viaggia dentro il GeoPackage insieme
ai dati: chi lo riceve vede le stesse cose, senza cartelle condivise, senza
configurare QGIS e senza premere nulla.

Da sapere: ogni stile porta ora la propria copia del disegno (il file
cresce dell'8 per cento circa, da 54 a 59 KB). Se un domani si cambia il
simbolo del pozzetto, va riapplicato agli stili, perche' non c'e' piu' un
file unico da aggiornare. E' il prezzo del non dipendere da collegamenti.
Se un SVG non viene trovato, il plugin lo segnala nel log e lascia il
collegamento com'era, invece di far finta di aver risolto.

### Screening: siti contaminati, bonifiche e ARPA

Lo screening del territorio non guardava l'ambiente. Ora interroga la banca
dati ISPRA (MOSAICO) e riporta, per il comune in esame, i Siti di Interesse
Nazionale e i procedimenti di bonifica, distinguendo quelli **aperti** da
quelli chiusi, con l'ARPA competente per l'area. Dentro un SIN autorizza il
Ministero, non il Comune; dove c'e' una bonifica aperta la movimentazione
del terreno ricade nel D.Lgs 152/2006 e lo scavo va concordato.

Si aggiunge ARPA fra i soggetti della Conferenza di Servizi dove e' prassi
convocarla. Il primo caso inserito e' l'**Emilia-Romagna**, dove Arpae viene
convocata sistematicamente e puo' chiedere integrazioni che sospendono
l'iter: il verbale riporta la struttura competente e la PEC provinciale
giusta. Attenzione, gli indirizzi PEC di Arpae sono **cambiati tutti il 1
aprile 2026**: le rubriche precedenti non valgono piu'.

Fuori dalle situazioni verificate il plugin scrive "non risulta verificato,
chiedere al Comune" invece di dichiarare che non serve nessuno. Allo stesso
modo, se il servizio ISPRA non risponde scrive "non verificati": un guasto
di rete non diventa mai un "nessun vincolo".

Due limiti dichiarati: il controllo lavora sul riquadro del comune, non sul
tracciato, quindi segnala che in zona ci sono bonifiche aperte, non che le
attraversi; e l'anagrafe ISPRA e' alimentata dalle Regioni, quindi dove una
Regione carica poco, risulta poco. Vale come allarme, non come certificato.

## Versione 2.9.6

### Punti di ripresa: coni ruotabili con anteprima
- Nuovo pulsante **«Genera coni ruotabili dai Punti di Ripresa»**: crea un
  layer poligonale `Cono di Ripresa` (GeoPackage accanto al progetto) con
  l'apice sulla camera, apertura 120° e raggio pari ai 6 mm del simbolo
  riportati alla scala di stampa (6 m a 1:1000). I coni si ruotano con
  **«Ruota elementi»**, che mostra l'anteprima mentre trascini — cosa che
  «Ruota simboli dei punti» non fa, perché scrive solo un numero.
- Al **salvataggio** del layer coni l'orientamento viene riletto dalla
  geometria e riscritto nel campo `Rotazione` dei punti, quello letto dal
  programma esterno delle foto: i valori non cambiano significato.
- L'azimut si legge dai **vertici** (primo = apice, centrale = metà arco),
  non dal baricentro: «Ruota elementi» ruota attorno a un centro qualunque,
  quindi dopo la rotazione il baricentro non dice più dove guarda la camera.
- Spunta **«Spostando il cono si sposta anche la camera»**, attiva di
  default: togliendola il cono torna sull'apice e cambia solo
  l'orientamento, utile per non spostare le camere per sbaglio.

### Keyplan e Poligoni di Inquadramento: copertura a reticolo
- Le tavole non vengono più piazzate una per una attorno agli elementi
  scoperti, con toppe centrate che finivano per accavallarsi (si arrivava a
  6 tavole sovrapposte nello stesso punto). Ora si costruisce un **reticolo
  di celle W×H allineate al modello**, e si tengono solo le celle che
  contengono qualcosa: adiacenti per costruzione, mai sovrapposte, nessun
  elemento fuori. Vale sia per il Keyplan sia per i Poligoni di
  Inquadramento.
- Sparisce tutta la **regolazione manuale della griglia**: passo, tentativi
  di ottimizzazione e relativi pulsanti non servono più, perché il reticolo
  non ha parametri da tarare. Meno campi da compilare e un risultato
  ripetibile a parità di rete.
- A fine generazione le tavole vengono **numerate da sole**, in ordine di
  lettura (alto→basso, sinistra→destra): non serve più passare dal pulsante
  di numerazione come passaggio separato.
- Nuovo pulsante **«Copia le tavole generate nel layer modello»** per
  Keyplan e Inquadramento, con spunta *«Sostituisci le tavole esistenti»*:
  elimina le vecchie e conserva la feature MODELLO, che serve da stampo. Se
  il modello non è identificabile l'operazione si blocca invece di
  cancellare tutto.
- Il pulsante **«Diagnostica estensione»** e la sua descrizione parlavano di
  ARLO AREA anche quando la copertura partiva dalla rete: ora compaiono solo
  quando servono davvero.

### Keyplan: il reticolo ora vale anche con le Tavole di Inquadramento
- Il campo «Tavole di Inquadramento» della scheda Keyplan **scavalcava il
  reticolo**: con quel campo valorizzato `_forma_da_coprire()` non veniva
  chiamata, gli elementi da coprire restavano vuoti e la generazione
  ricadeva sulla copertura libera, cioè quella che produce tavole
  sovrapposte. Ora anche quel ramo passa dal reticolo, usando le tavole
  stesse come oggetti da coprire.
- Lo stesso campo aveva un **preset** che lo riempiva da solo con «Poligoni
  di Inquadramento»: la copertura partiva dall'impronta delle tavole senza
  che nessuno l'avesse chiesto. Preset rimosso; il campo si riazzera a ogni
  refresh tranne quando lo scegli tu.

### Campi che si compilavano da soli
- I quattro campi opzionali dei Punti di ripresa (Stradario, Sedime
  Pubblico, Strade Provinciali, Strade ANAS) venivano riempiti da QGIS col
  primo layer compatibile: si osservavano «Strade ANAS = 03 INFRASTRUTTURE»
  e «Sedime Pubblico = Aree d'acqua». Non è un difetto estetico, perché i
  coni venivano generati trattando le infrastrutture come strade statali.
  Ora restano vuoti, e si azzerano solo quando il nome del layer non
  c'entra con il ruolo del campo.

### Copia nel modello
- La feature MODELLO conservata durante la sostituzione viene lasciata
  **senza numero**, così si individua a colpo d'occhio e si può cancellare.

### Pulizia
- Rimossi i tre metodi dell'ottimizzazione griglia (203 righe), orfani dopo
  il passaggio al reticolo: non li chiamava più nessuno e leggevano widget
  tolti dall'interfaccia, quindi sarebbero esplosi al primo utilizzo.

## Versione 2.9.5

### Keyplan e tavole: copertura sulla rete nuova
- L'area da coprire si costruisce dalla **rete nuova** (Infrastrutture con
  STATO=Nuovo escluse le Aeree, Pozzetti, Armadi Ottici) invece che da ARLO
  AREA, con raggio impostabile (30 m predefinito). ARLO AREA è l'area di
  competenza dell'armadio e comprende strade dove non si posa nulla: coprirla
  tutta produceva tavole vuote. Vale sia per il Keyplan sia per i Poligoni di
  Inquadramento. Se i layer non contengono rete nuova si ricade su ARLO AREA.

### Punti di ripresa: orientamento del cono
- Risolto il cono orientato a caso quando il punto di ripresa cade **sopra**
  l'elemento da fotografare (caso frequente: i punti stanno sulle infrastrutture
  o sugli armadi, non sulla strada). Con camera e soggetto coincidenti
  `atan2(0,0)` restituiva 0 e il cono puntava a Nord.
  Ora, sotto 1 m di distanza, la direzione si ricava dalla **perpendicolare
  all'asse stradale più vicino**, scegliendo fra le due perpendicolari quella
  rivolta verso gli elementi da documentare; in mancanza di strada si punta al
  baricentro degli elementi vicini.
- La camera viene **arretrata** (8 m predefiniti, impostabile) quando si trova
  addosso al soggetto, così il cono è leggibile e il soggetto ci cade dentro.
- Verificato su 8 casi geometrici controllati: 8/8 corretti.

### Shape → GeoPackage
- Il layer già presente nel progetto **non viene più sostituito**: si esegue un
  «ripara sorgente dati» (`setDataSource`) verso il GeoPackage creato, quindi
  restano stile, join, moduli, posizione nell'albero e i riferimenti dei layout.
- Il combo parte già puntato sullo **shape dei pozzetti** trovato nel progetto.

### Unisci tratte (nuova scheda, Comune)
- Fonde le tratte di Infrastrutture che si toccano, hanno la stessa tipologia e
  **non sono separate da un pozzetto**. Non tocca le diramazioni (nodi con 3+
  rami). Anteprima e backup su disco attivi di default.
- Misurato su dati reali (3445 tratte, 1400 pozzetti): 994 giunzioni fondibili,
  3445 → 2451 tratte, 715 nodi correttamente bloccati dai pozzetti.

### Chilometriche: rotonde
- Gli **anelli chiusi** (rotonde) venivano cuciti dentro il corridoio da
  `mergeLines` e gonfiavano le progressive di mezza circonferenza. Ora vengono
  scartati prima di ricucire. Misurato su rotonda r=15 m: progressiva di un punto
  a 800 m era 864 m, **errore 64,1 m → 0,0 m**. I circuiti stradali veri
  (anelli > 400 m) restano nel corridoio.

### Screening territorio
- Nuova sezione **«Vincoli da verificare a mano»**: elenca le fattispecie che
  nessun servizio nazionale espone, prime fra tutte le **strade a valenza
  paesaggistica** (PPR/PTCP regionali). Il check ha rilevato che mancavano anche
  art. 142 lett. b (laghi), d (montagne), f (parchi e riserve), h (usi civici),
  l (vulcani), m (zone archeologiche) e i tratturi. Non vengono dichiarate
  assenti: vengono dichiarate non verificate.

## Versione 2.9.4

Numerazione Foto robusta all'overlap fra tavole + nuova funzione Fasce di rispetto.

**NUOVO — Fasce di rispetto (Altri Enti).** Data una geometria (di norma lineare:
strada, ferrovia, fiume, canale) genera il poligono della fascia di rispetto
dell'ente scelto. Menu ente con distanza di default modificabile: RFI ferrovia 30 m,
ANAS statale 30 m, Provincia 20 m, Comune 10 m, Autostrada 60 m, Fiume 10 m
(R.D. 523/1904), Consorzio bonifica 10 m, Cimitero 200 m, oppure Personalizzato.
Buffer calcolato dal bordo dello shape, stile trasparente con bordo tratteggiato
ed etichetta ente/distanza, coerente con la fascia RFI. Verifica geometrica: linea
1000 m + fascia 30 m → poligono 1060×60 m (scarto area 0.01%).

**Numerazione Foto robusta all'overlap fra tavole.** Le foto nella zona di
sovrapposizione fra due tavole non restano più senza numero. Le foto vengono prima
raggruppate per ID_Tavola e ogni gruppo assegnato in blocco alla tavola che ne
contiene più punti — nessuna foto contata due volte, nessuna senza numero.
Verificato sui dati reali di Castiglione (17 tavole, 41 foto, 4 in zone di overlap):
tutte numerate, nessuna tavola oltre le 3 foto.

## Versione 2.9.3

Fix scelta del layer Tavole quando ce ne sono più versioni nel progetto.

**"0 foto su 1 tavola" risolto.** Quando nel progetto convivono più layer di
inquadramento (es. 'Poligoni di Inquadramento' con tutte le tavole e un
'Poligoni_di_Inquadramento_..._fit' con poche feature che non stanno sopra le
foto), il plugin poteva agganciarsi a quello sbagliato e trovare 0 foto. Ora il
layer Tavole viene scelto con un criterio infallibile: fra i candidati si prende
quello che CONTIENE geometricamente più foto. Se il layer indicato non contiene
nessuna foto, la ricerca scatta in automatico. Verificato sui dati reali di
Castiglione: sceglie il layer da 17 tavole (45 foto contenute) scartando il _fit.

## Versione 2.9.2

Fix definitivo della numerazione Foto: aggancio foto→tavola robusto.

**Le foto ora vengono numerate anche con ID_Tavola "orfano".** I coni generati su
un layer temporaneo e poi salvati conservano un ID_Tavola che punta a id interni
non più esistenti (spesso negativi): l'aggancio esplicito falliva e, poiché le
foto risultavano comunque "collegate", non rientravano nemmeno nel recupero
geometrico — risultato: zero foto numerate. Ora una foto è considerata collegata
solo se il suo ID_Tavola corrisponde a una tavola realmente presente; altrimenti
viene assegnata alla tavola che la contiene geometricamente. Testato sui dati
reali (17 tavole, 41 foto): tutte numerate correttamente.

Include anche i fix 2.9/2.9.1 (numerazione automatica delle tavole in ordine di
lettura se mancante; riconoscimento robusto del layer Tavole di Inquadramento
qualunque sia il nome, per non prendere per errore layer poligonali enormi).

## Versione 2.9.1

Correzione selezione automatica del layer Tavole di Inquadramento.

**Fix "Numera Foto": veniva usato il layer sbagliato.** All'apertura il combo
"Tavole di Inquadramento" non riconosceva il layer reale dei progetti (che si
chiama "Poligoni di Inquadramento", col "di") e ripiegava sul primo layer
poligonale disponibile — spesso un layer enorme (es. migliaia di feature), da cui
l'errore in numerazione foto con "13800 tavole" trovate. Ora la selezione
automatica riconosce sia "Poligoni di Inquadramento" (progetti reali) sia
"Poligoni Inquadramento" (generato dal plugin), preferendo il primo. Vale per i
combo Tavole delle schede Foto, Keyplan e Numerazione.

## Versione 2.9

Numerazione automatica delle Tavole di Inquadramento nella numerazione Foto.

**Numerazione Foto senza bloccarsi sulle Tavole.** La funzione "Numera Foto
automaticamente" (scheda Punti di ripresa) non richiede più che le Tavole di
Inquadramento siano già numerate a mano: se il campo "Numero Tav" manca, è
incompleto o ha duplicati, il plugin numera le Tavole da sé in ordine di lettura
(dall'alto in basso per righe, da sinistra a destra dentro ogni riga) e poi
procede con le Foto. Se invece le Tavole hanno già una numerazione completa e
univoca, viene rispettata e non toccata. Prima in questi casi compariva l'errore
"Le Tavole di Inquadramento non hanno il campo 'Numero Tav'" e la numerazione si
interrompeva.

## Versione 2.8

Snellimento della sezione Comune, default della conversione a GeoPackage e delle Tavole.

**Sezione Comune — rimosse le Regole 4 e 5.** Tolte dalla scheda "Seleziona elementi"
la Regola 4 (tratte/pozzetti toccati da Edifici) e la Regola 5 (possibile proprietà
privata via Sedime OSM/stradario locale), con i relativi controlli e la generazione del
Sedime Pubblico. La scheda resta con le regole 1, 1b, 2 e 3.

**GeoPackage del pozzetto sempre `02_POZZETTO`.** La conversione shape→GeoPackage ora
produce sempre un file `02_POZZETTO.gpkg` con layer interno `02_POZZETTO`, a prescindere
dal nome dello shapefile di partenza. Lo shapefile su disco non viene toccato.

**Default della scheda "Keyplan e tavole".** All'apertura del plugin i combo modello si
impostano automaticamente sui layer dei progetti reali: Keyplan modello A = `Keyplan
Quadrato`, Inquadramento modello A = `Poligoni di Inquadramento`, Infrastrutture =
`03 INFRASTRUTTURE`. Gap 0,00 m e Raggio target 2,00 m restano i valori predefiniti.
Prima questi combo modello non erano nel preset e andavano impostati a mano.

**Allineamento versione.** Il numero mostrato nel titolo della finestra e quello del
Gestore dei plugin di QGIS ora coincidono (2.8).

## Versione 2.7

Miglioramenti alle etichette e alla scheda Suolo comunale (Altri Enti).

**Etichette leggibili e spostabili.** Le etichette delle infrastrutture ora vanno a capo
in modo logico (riga 1 = km/posizione, riga 2 = descrizione dello scavo) senza più spezzare
numero e unità di misura ("13 m", "40x76" restano uniti). Il posizionamento è orizzontale e
ordinato attorno alla tratta, con richiamo e maggiore distanza per ridurre le
sovrapposizioni. Ogni etichetta è ora trascinabile a mano: il plugin collega le proprietà di
posizione (campi LBLX/LBLY/LBLR) così lo strumento "Sposta etichetta" di QGIS aggancia tutte
le feature e salva la posizione scelta.

**Chilometrica degli attraversamenti.** Le tratte di scavo ortogonali alla strada
(attraversamenti) mostrano un solo km invece dell'intervallo "dal km X al km Y", perché il
punto di attraversamento è unico. L'etichetta compare anche sulle tratte corte, che prima
sparivano per mancanza di spazio (placement rigido).

**Aggancio corridoio più robusto.** Il calcolo chilometriche individua il corridoio della
strada anche per le tratte ortogonali corte, testando entrambi i capi della tratta e non solo
il punto medio.

**Scheda Suolo comunale rinnovata.** I due elenchi a selezione multipla sostituiti da menu a
tendina con caselle di spunta, coerenti con le altre schede; preselezione aggiornata ai nomi
attuali degli stradari (Stradario_Italia_Join, Stradario_Italia).

## Versione 2.6

Proprietà del software e contatti RFI nello screening.

**Intestazione di proprietà.** Autore aggiornato in "Beexact - Luciano - AI" e nota di
copyright nella scheda del plugin: software di proprietà di Beexact S.r.l., uso interno
autorizzato, riproduzione e distribuzione non consentite senza autorizzazione. Header di
copyright aggiunto in testa ai file sorgente.

**Contatti RFI nello screening territoriale.** Quando lo screening rileva una linea
ferroviaria RFI nel territorio comunale, il report riporta ora — per la regione del comune —
le PEC delle DOIT competenti e i referenti RFI per l'invio dell'istanza (Modalità di invio
delle istanze RFI, fonte Open Fiber). Coperte: Lombardia, Veneto, Friuli-Venezia Giulia,
Emilia-Romagna, Toscana, Lazio, Campania, Puglia, Sicilia. Da verificare sempre la DOIT
territorialmente competente per la specifica linea.

## Versione 2.5

Nessuna modifica funzionale rispetto alla 2.4: solo avanzamento di versione per
ridistribuire il pacchetto tramite il repository.

## Versione 2.4

Screening a supporto dello stradario nazionale unico, export ordinati per comune e
conversione shapefile → GeoPackage.

**Scheda "Edifici in carreggiata" con stradario esterno.** Da quando lo stradario
nazionale unico (Stradario_Italia) ha sostituito i livelli strade DBSN dentro i gruppi
regione, la funzione "Cerca le regioni nel progetto" non trovava più le regioni: pretendeva
il livello strade dentro ciascun gruppo, ma nei progetti reali i gruppi regionali hanno
ormai solo gli edifici. Ora, se nel punto 1 è scelto uno stradario (es. Stradario_Italia),
le strade non devono più stare nel gruppo: basta che il gruppo abbia gli edifici. Il campo
"livello strade" diventa facoltativo e il combo strade si presenta già su Stradario_Italia.
Verificato: trova tutte le 20 regioni del progetto (prima nessuna). L'analisi legge lo
stradario ristretto all'estensione degli edifici della regione, senza scorrere l'intero
file nazionale.

**Export dello screening ordinati per comune.** Tutti i file prodotti dallo screening
territoriale (report Markdown, Excel, shapefile e GeoPackage dei vincoli) finiscono ora in
una cartella dedicata `Screening Territorio/<Comune>/` dentro la cartella del progetto,
invece di essere sparsi nella radice. La cartella viene creata automaticamente al primo
export.

**Nuova scheda "Shape → GeoPackage"** (in "Cartografia di base"). Crea il gemello
GeoPackage di uno shapefile — stesso percorso e stesso nome (`.gpkg` accanto al `.shp`) —
applica uno stile `.qml` (predefinito 02_POZZETTO, modificabile o scelto da file) e mette
il GeoPackage nel progetto al posto dello shape o accanto ad esso (a scelta). Lo shapefile
su disco non viene toccato. Sorgente selezionabile sia dai layer del progetto sia da file.

**Fix layer Cavo Raccordo.** Il valore predefinito del combo "Cavo Raccordo" (scheda
Allinea) puntava a un nome inesistente ("CAVO RACCORDO") e non si popolava mai: corretto in
"RACCORDI", il nome reale del layer.

**Export di consegna: 3 join separati e puliti.** Gli shape di consegna ora nascono da tre
join indipendenti, ciascuno con i soli due layer che gli competono: SCAVI_STRADE =
Infrastrutture × Stradario, POZZETTI_STRADE = Pozzetto × Stradario, ARMADI_FOTO = Armadio
Ottico × Punto di Ripresa. Prima SCAVI_STRADE e POZZETTI_STRADE ricevevano anche un doppio
join con l'Armadio, che infilava nei due file decine di campi armadio non pertinenti
(ID_ARMADIO, TIPO_ARMAD, OBJECTID_2, distance_2…). Resta possibile, come opzione avanzata
(spunta dedicata, disattivata di default), aggiungere anche l'Armadio ai join di scavi e
pozzetti quando serve. Etichette delle spunte rese esplicite.

**Join molto più veloce con stradario nazionale.** Quando il layer stradario del join è
enorme (oltre 50.000 tratti, es. lo stradario nazionale con milioni di geometrie), viene
prima ritagliato all'area di lavoro (estensione dell'input più un margine) prima del join
by-nearest. Misurato su progetto reale: un singolo join passa da 164 s a 0,3 s, con
risultato identico (stesse feature, stessi abbinamenti). L'export completo passa da diversi
minuti a pochi secondi.

**Stradario dedicato al join.** Il combo Stradario della scheda Esportazione si presenta di
default su `Stradario_Italia_Join`: una copia dello stradario nazionale con i soli tratti
nominati (name valorizzato, oppure ref copiato in name dove il name mancava — così SP/SS
senza nome restano identificate). Circa 2,3 milioni di tratti invece di 6,8: join più
pulito (niente abbinamenti a geometrie anonime) e più leggero.

## Versione 2.3

Riconoscimento strade provinciali in formato lombardo/veneto e pulizia dati armadi
(test su Capriolo, BS).

**Fix ref strade lombarde e numeri romani.** Il parser dei riferimenti stradali ora
riconosce i formati usati in Lombardia/Veneto: `SP BS 469` / `SPBS469` (sigla provincia
tra classe e numero) e `SP XII` / `SPXII` (numero romano, convertito in arabo). Prima
queste strade venivano scartate e non comparivano nello screening: a Capriolo mancavano
SPBS469, SPBS469D1 e la SP XII. Verificato che i formati standard (SP6, SS3bis, A4, SR71ter)
restano invariati e le sigle-provincia senza numero non generano falsi positivi.

**Pulizia indirizzi armadi ottici.** Gli indirizzi del layer '01_ARMADIO OTTICO' spesso
arrivano sporchi (VIAROMA senza spazio, civici placeholder 9999, testo duplicato tipo
VIAPALAZZOLO29VIAPALAZZOLO). Ora vengono normalizzati automaticamente: spazio dopo
VIA/VIALE/PIAZZA/ecc., civico 9999/999 → SNC, rimozione duplicazioni.

**Avvertenza fonte strade.** Report Markdown ed Excel riportano ora sempre che l'elenco
strade (SS/SP/SR) deriva da OpenStreetMap — che può essere incompleto o non aggiornato:
singole provinciali possono mancare (es. la SP96 di Capriolo, presente sul geoportale
della Provincia di Brescia ma non su OSM). Invito a verificare sul Catasto Strade /
geoportale provinciale competente e sullo stradario ANAS per le statali.

**Competenza ANAS su strade taggate SP (rientri statali).** Nuova tabella kb
`rientri_anas`: il caso opposto ai declassamenti. Alcune strade sono taggate come
provinciali in OSM (con denominazione provinciale storica) ma la loro asta principale è
in realtà STATALE, gestita da ANAS. Esempio: la SPBS469 Sebina Occidentale a Capriolo
(asta principale ANAS, solo la variante 469bis è Provincia — fonte Catasto Strade
Brescia). Lo screening ora lo segnala esplicitamente invece di attribuire la competenza
alla Provincia sulla sola base del numero. Estensibile aggiungendo righe alla tabella.

## Versione 2.0

Corsi d'acqua, fasce art.142, Riepilogo completo e shape (test su Bondeno e Letojanni).

**Analisi armadi ottici (manufatti fuori terra).** Nuovo: lo screening legge il layer
'01_ARMADIO OTTICO' del progetto e, per ogni armadio, verifica la sovrapposizione con i
vincoli paesaggistici — art.136/142 (parere Soprintendenza vincolante, art.146 D.Lgs
42/2004, valido su tutta Italia) e UCP regionali 'Città consolidata' del PPTR Puglia
(competenza Regione/Comune, NTA art.77). Distingue lo scavo interrato (di norma esente,
art.149) dal manufatto visibile che attiva l'autorizzazione paesaggistica. Nuovo foglio
Excel 'Armadi ottici', shape dedicato con stile per stato (rosso=Soprintendenza,
ambra=Regione/Comune, verde=libero), nota DPR 31/2017. Testato su San Vito dei Normanni
(2 armadi su 3 in Città consolidata). Se il layer armadi manca, l'analisi è saltata
senza errori (compatibile con progetti di altri service).

**Geoportale PPTR Puglia (SIT Puglia) agganciato.** 'Città consolidata' (UCP PPTR) come
poligoni veri, per la valutazione degli armadi.

**Strade fuori fascia escluse dalle tavole.** In modalità tracciato/ARLO lo shape
"Strade classificate" ora disegna solo le strade che generano obbligo (attraversamento
o entro fascia di rispetto). Le strade a distanza tale da non interferire — es. una SP
che passa a chilometri dal progetto (caso Siculiana SP75 a 2-8 km) — non vengono più
disegnate su tutta la loro lunghezza, ma restano elencate nell'Excel con la distanza.

**Geoportale Regione Siciliana (SITR) agganciato.** La Sicilia non è in SITAP: ora il
plugin interroga il geoportale regionale (ArcGIS REST, per provincia/ambito) e trova i
vincoli art.142/136 come POLIGONI VERI — fascia costiera 300 m (lett.a), fascia fiumi
150 m (lett.c), aree boscate (lett.g), art.136. Verificato su Letojanni (ME): costa 1,
fiumi 6, boschi 35, art.136 2 poligoni. Entrano nella tabella Excel E come shape.

**Foglio 'Vincoli e fonti' riorganizzato + colonna 'Riscontro shape'.** La sezione 1
ora elenca TUTTI i vincoli (art.136, fasce costa/fiumi, boschi, Natura 2000) con una
colonna che dice se hanno un poligono in mappa (SÌ verde / NO rosso). Prima le fasce
paesaggistiche finivano sepolte tra gli avvisi in fondo al foglio, non in tabella.

**Shape completi anche in modalità tracciato.** Prima, analizzando sul tracciato, gli
shape dei vincoli comunali non attraversati venivano scartati: ora si conservano tutte
le geometrie (marcando 'attraversato'/'nel comune') così il riscontro visivo copre tutto
ciò che è nell'Excel. Nuovo layer shape 'Fasce art.142 costa-fiumi'.

**Fasce paesaggistiche art.142 lett.a (costa 300 m) e lett.c (fiumi 150 m).**
- Prima il plugin usava il layer nazionale `vw_vasvia_aree_di_rispetto`, che è ROTTO
  (record vuoti col solo campo `inside`): le fasce costiera e fluviale non venivano
  mai trovate. Ora: dove SITAP ha i layer REGIONALI art.142 (14 regioni: Campania,
  Lazio, Toscana, Sardegna, Puglia, Calabria, Emilia-Romagna, Lombardia, Piemonte,
  Veneto, FVG, Basilicata, Umbria, Liguria) interroga il layer giusto e trova i
  poligoni reali (verificato su Agropoli: 1 fascia costa + 6 fiumi). Dove la regione
  NON è coperta (es. **Sicilia**) attiva un fallback: segnala lett.a come PROBABILE se
  il comune è costiero (da OSM coastline) e lett.c se ci sono corsi d'acqua, con
  rimando al geoportale/PPTR regionale. Verificato su Letojanni (ME).

**Riepilogo completo e shape.**
- **Riepilogo ora completo.** Il foglio Riepilogo ricostruiva la lista enti a mano e
  ometteva parchi, siti Natura 2000, aree boscate (art.142g), vincolo idrogeologico e
  ferrovie. Ora elenca TUTTI gli enti di `componi_enti` (rep["enti"]). Su Letojanni:
  da 5 a 10 righe. Risolve anche il Parco del Gargano mancante dal Riepilogo.
- **Shape delle aree boscate ora generato.** La geometria delle aree boscate (art.142
  lett.g, da OSM) non veniva raccolta in `_geometrie_vincoli`, quindi lo shape non
  usciva. Ora produce `<comune>_aree_boscate_art_142g.shp` con stile ed etichetta.

**Corsi d'acqua: fasce di rispetto corrette e canali di bonifica distinti dai fiumi.**
- **Le fasce dei corsi d'acqua ora sono quelle giuste.** Prima il plugin usava 150 m
  per tutto, ma i 150 m sono la fascia PAESAGGISTICA (art. 142 lett. c). Per lo scavo
  contano regimi diversi, ora distinti nel report: alveo demaniale (concessione se
  attraversato), fascia di polizia idraulica **10 m** dal piede argine (R.D. 523/1904
  art. 96), fascia paesaggistica **150 m** (art. 142). Enti e distanze diversi.
- **Canali di bonifica distinti dai fiumi.** Il reticolo artificiale (`waterway=canal/
  ditch/drain`) non è più trattato come corso d'acqua demaniale: viene riconosciuto
  come **reticolo di bonifica** con competenza del **Consorzio di bonifica** e fascia
  di rispetto stabilita dal **regolamento consortile** (tipicamente 4-10 m, NON i 150).
  Nuovo ente "Consorzio di bonifica" negli enti da interpellare, nuova scheda kb
  `bonifica`. Verificato su Bondeno (FE): Po/Panaro = demaniali; Canale Cittadino,
  Cavamento Reno Palata, ecc. = Consorzio.
- **Onestà sui limiti:** OSM non riporta QUALE Consorzio gestisce il canale; il report
  segnala la presenza del reticolo e rimanda all'identificazione (geoportale/elenco ANBI).

## Versione 1.9

Declassamenti stradali (OSM non aggiornato SS→SP):

- **Riconoscimento delle sigle "SP ex SS".** OSM taggata le ex statali passate alla
  Provincia con convenzioni non standard (`SP ex SS35`, `SPexSS35`, `SP ex SS 35`):
  prima il parser non le riconosceva e i tratti venivano persi o classificati SS.
  Ora `normalizza_ref` li porta a classe **SP** (competenza Provincia). Nel tratto
  misto `SS35;SPex SS35` vince il declassamento (informazione più aggiornata).
- **Avviso sistematico su ogni SS/SR**: "verificare l'eventuale declassamento a
  provinciale/comunale — OSM non rispecchia i declassamenti in tempo reale".
- **Tabella kb `declassamenti`** (memoria estensibile dei casi noti): quando una
  ex statale declassata compare nel comune indicato, lo screening avvisa con l'ente
  corretto ignorando la classe ANAS obsoleta di OSM. Primo caso: SS35 → SP35
  (Provincia di Como, Fino Mornasco). Verificato sui dati reali del comune.

## Versione 1.8

Aree naturali protette (parchi) + etichette nelle tavole:

- **Parchi nazionali e regionali ora trovati (fix).** I due layer SITAP dei parchi
  davano HTTP 400 con il filtro bbox (poligoni giurisdizionali enormi), quindi lo
  screening non li intercettava mai. Ora si usa la stessa strategia delle
  soprintendenze: `parchi_intercettati` scarica l'intero layer (21 parchi nazionali
  + 106 regionali) via `_wfs_tutte` (con cache disco 30 gg) e fa il match spaziale
  in locale. Verificato: Bagno di Romagna → "P N delle Foreste Casentinesi, Monte
  Falterona e Campigna" [EUAP0016]; Stornarella → nessun parco (corretto).
- **Nuovo ente "Ente gestore area protetta"** (nulla osta ex art. 13 L. 394/1991),
  livello 2, con la scheda kb `aree_protette` (norme, documentazione, criticità).
- **Nuovo layer shape/GeoPackage "Aree protette (parchi)"** nelle tavole, con stile
  dedicato (verde bosco tratteggiato) ed etichetta col nome del parco.
- **Etichette su ferrovie e corsi d'acqua** (nome della linea/corso, o il tipo se il
  nome manca) — prima erano anonimi. Etichette strade (SP/SS) e Natura 2000 (codice)
  ora seguono l'andamento della linea con alone bianco per leggibilità sull'ortofoto.

## Versione 1.7

- **Rete Natura 2000 (SIC/ZSC + ZPS)** da EEA + ente VIncA negli enti.
- **Shape + GeoPackage + stili QGIS automatici** per le tavole (confine, strade,
  vincoli, Natura 2000, ferrovie/acque), con spunta in "2) Cosa produce".

## Versione 1.6

Correzioni sull'attribuzione ARLO delle strade (emerse dal test su Stornarella):

- **Colonna ARLO compilata anche per le strade solo-OSM.** Nel foglio Riepilogo le
  SP/SS presenti solo in OSM (non nello stradario) comparivano con la colonna ARLO
  vuota. Ora `attribuisci_arlo` assegna le zone anche a `rete_stradale_solo_osm` e
  `rete_stradale_non_misurate` (prima solo `rete_stradale` e `_fuori`).
- **ARLO della strada = zone dove lo scavo è entro la fascia di rispetto.** L'ARLO
  di una strada non è più "dove passa la geometria OSM della strada" (che
  sovrastimava), ma le zone ARLO dove il TRACCIATO di progetto ricade entro la
  fascia di rispetto di quella strada (30 m SP, 40 m SS, ecc. da kb). Il tracciato
  WGS84 viene salvato in `analizza_su_tracciato` e riusato in `attribuisci_arlo`.
  Verificato su Stornarella: SP88 in 205/206/208 (scavo a 0 m dalla SP88 in tutte
  e tre le zone — attribuzione corretta), zona 204 esclusa; SP81 in 206.

## Versione 1.5

- **Cache su disco delle soprintendenze SITAP (velocizzazione).** Il download
  completo dei layer soprintendenze (~16 MB, ~31 s misurati) è il pezzo più lento
  dello screening e cambia una volta ogni anni. Ora il risultato viene salvato
  nella cache temporanea di sistema (`%TEMP%/ftth_screening_cache/`, scadenza 30
  giorni): dal secondo screening in poi quel dato si legge dal disco in ~0,2 s
  invece di riscaricarlo. Misurato: 31,4 s → 0,22 s (140× più veloce) a parità di
  dati (44 soprintendenze). La cache è per-macchina, condivisa tra tutti i
  progetti, fuori dalla cartella del plugin (non si perde agli aggiornamenti né
  entra nel pacchetto).

## Versione 1.4

Correzioni emerse dal test end-to-end sul progetto reale Comune_Verifica (Stornarella):

- **Layer con filtro/sorgente non valido — recupero automatico.** Diversi progetti
  hanno sui layer 03 INFRASTRUTTURE / 01_ARMADIO OTTICO un subset filter salvato
  che referenzia un campo inesistente (es. `"SUOLO" IS NULL OR "SUOLO" <> 'COMUNALE'`
  dove il campo SUOLO non c'è nello shapefile): OGR rende il layer INVALIDO, quindi
  `getFeatures()` non itera e il tracciato risultava vuoto → "servono i layer 03
  INFRASTRUTTURE..." e lo screening sul tracciato NON partiva affatto. Ora il plugin
  rileva il layer non leggibile e lo RICARICA dalla sorgente pulita (senza il subset
  rotto), con messaggio nel log. Verificato su Stornarella: tracciato di 347 elementi
  costruito, 194 tratte Esistenti escluse.
- **Filtro STATO=Nuovo — rete di sicurezza.** Se il campo STATO esiste ma non ha
  alcuna tratta 'Nuovo' (campo vuoto/non compilato), il plugin NON filtra (analizza
  tutte le tratte) invece di produrre un tracciato vuoto.

## Versione 1.3

Controllo attivo del vincolo paesaggistico ex lege art. 142 (D.Lgs 42/2004):

- **Aree boscate (art. 142 lett. g).** Oltre all'avvertenza testuale, lo screening
  ora RACCOGLIE attivamente i boschi/aree forestali da OSM (natural=wood,
  landuse=forest) e li segnala come vincolo paesaggistico. In modalità tracciato
  misura la distanza reale (attraversamento ≤0,5 m / entro 150 m); in modalità
  comune segnala la presenza. Compaiono come ente da interpellare (Soprintendenza,
  art. 142 lett. g, livello 2) e nel foglio Excel "Vincoli e fonti". Verificato:
  Coriano 1 area, Bagno di Romagna 2 (inclusa "Abetina di Brasco").
- **Corsi d'acqua entro 150 m (art. 142 lett. c).** La logica di prossimità
  paesaggistica (già presente) resta: distingue attraversamento demaniale
  (R.D. 523/1904) da semplice prossimità entro la fascia dei 150 m.

Resta valido il principio: SITAP è incompleto sui vincoli ex lege, che valgono
per legge anche se non cartografati. Ora il plugin li cerca attivamente in OSM
invece di limitarsi ad avvisare.

## Versione 1.2

Correzioni emerse dal test su Stornarella (FG):

- **Foglio Riepilogo — strade solo-OSM incluse.** Il foglio "Riepilogo"
  elencava solo il Comune e le strade presenti nello stradario di riferimento,
  saltando le SP/SS presenti solo in OSM (non nel DBSN). Ora unisce le tre reti
  (primaria + solo-OSM + non-misurate) come già fa `componi_enti`: le strade
  attraversate/in fascia compaiono tutte (Stornarella: SP81 e SP88 ora nel
  Riepilogo). Le strade "fuori fascia" restano escluse (solo informative).
- **Soprintendenza SITAP — retry su errori transitori.** Il download completo
  delle soprintendenze (~16 MB, 30-40 s) sotto carico risponde a intermittenza
  502/503/timeout. Aggiunti 3 tentativi con backoff (4 s, 8 s) prima di
  arrendersi: recupera la PEC quando il servizio è solo momentaneamente
  sovraccarico, invece di riportare subito "HTTP 400/502".

## Versione 1.1

Migliorie allo Screening territorio (5 punti):

1. **INFRASTRUTTURE — solo Stato=Nuovo.** Il tracciato di analisi ora esclude le
   tratte con `STATO=Esistente` in 03 INFRASTRUTTURE, considerando solo quelle
   nuove (oggetto del permesso). Pozzetti e armadi restano tutti. Prima venivano
   incluse anche le reti già posate, inquinando l'analisi (es. Coriano 363
   tratte Esistenti su 566 Nuove).
2. **Confine comunale — verifica e trasparenza.** Registrato l'`admin_level` del
   confine risolto (deve essere 8=comunale) con avviso se si cade su un'area
   vasta. Le geometrie dei vincoli salvate nello shapefile sono ora RITAGLIATE
   sul confine comunale (prima potevano sforare nei comuni confinanti perché il
   WFS interroga per bbox rettangolare). Confine OSM verificato accurato su dati
   reali (Coriano -0,2%, Montelabbate -6,7% vs superficie ISTAT).
3. **Analisi enti gerarchica.** Gli enti da interpellare sono ora ordinati dal
   nazionale al comunale (L1 Stato: ANAS/autostrade, RFI, MiC/Soprintendenza,
   UNESCO → L2 regionale: SR, vincoli paesaggistici/ambientali, corsi d'acqua,
   idrogeologico → L3 provinciale: SP, Province → L4 Comune). Ordinamento
   stabile: nessun ente viene perso.
4. **RFI — struttura territoriale competente.** Quando nel territorio c'è una
   linea ferroviaria RFI, il report associa la Struttura Territoriale RFI
   competente per regione con il range del Fascicolo Circolazione Linee (PGOS
   Art.2), dalla tabella ufficiale RFI (20 regioni mappate sulle 15 strutture).
5. **Soprintendenza — fix HTTP 400 + geoportali regionali.** La query SITAP delle
   soprintendenze paesaggio non usa più il filtro bbox (che dava HTTP 400 per via
   dei poligoni giurisdizionali enormi): scarica l'elenco completo e fa il match
   spaziale in locale sul confine comunale. Recupera denominazione + PEC corrette
   (Montelabbate → SABAP AN-PU, Coriano → SABAP RA). Aggiunta la kb dei
   geoportali regionali (20 regioni): quando SITAP è parziale, il report rimanda
   al geoportale della regione giusta per la verifica manuale dei vincoli
   (Vincoli in Rete del MiC non è agganciabile: richiede autenticazione, HTTP
   401). Estensibile: campo WFS popolabile per regione (Lazio già verificato).

## Versione 1.0

Prima release stabile pubblica. Consolida tutte le funzionalità sviluppate nelle
versioni 0.x: gestione completa dell'iter di permesso (Comune e Altri Enti),
screening territoriale con fonti nazionali (ISPRA IdroGEO, SITAP, OSM), analisi
sul tracciato con fasce di rispetto, export Excel multi-foglio e shapefile dei
vincoli. Vedi le voci sottostanti per il dettaglio delle singole funzioni.

## Novità versione 0.106

**Shapefile dei vincoli SITAP.** Insieme all'Excel, lo screening ora salva un
shapefile permanente dei vincoli paesaggistici intercettati (art.136, art.142,
boschi, fasce fluviali, ...) accanto al report: `<comune>_vincoli_SITAP.shp`, in
EPSG:4326, campo `vincolo`. Le geometrie GeometryCollection di SITAP vengono
normalizzate a MultiPolygon (compatibili shapefile). Serve per verificare i
vincoli in mappa senza dipendere dal servizio SITAP online.

## Novità versione 0.105

**Fix — enti stradali da strade solo-OSM.** Le strade classificate presenti solo
in OSM (non nel DBSN/stradario) ora generano correttamente l'ente da interpellare
(ANAS/Provincia). Prima una SP attraversata dal tracciato ma assente nel DBSN non
compariva tra gli enti (caso Montelabbate: SP423 con 3 attraversamenti).

**Fix — corso d'acqua: attraversamento demaniale vs prossimità paesaggistica.**
Un corso d'acqua entro la fascia 150 m ma NON attraversato non viene più
etichettato come attraversamento demaniale (che richiederebbe concessione R.D.
523/1904): viene segnalato come vincolo paesaggistico fascia fluviale (art.142
lett.c), senza concessione demaniale se non si tocca l'alveo. La distinzione usa
la distanza reale misurata sul tracciato.

**Robustezza — centroide vuoto.** `_metrico` ripiega sul centro del bounding box
se il centroide della geometria è vuoto (GeometryCollection con parti degeneri),
evitando un crash dell'analisi sul tracciato.

## Novità versione 0.104

**Foglio "Fonti e affidabilità" nel report di screening.** Ogni export Excel ora
include un foglio dedicato con la tabella delle fonti usate (ISPRA IdroGEO, SITAP,
Nominatim, Overpass, stradario, gestori regionali): endpoint, tipo, se autoritativa
e confidenza, colorati per lettura a colpo d'occhio.

## Novità versione 0.103

**Fix critico — strade "solo OSM" con affiancamento longitudinale ora visibili.**
Le strade classificate presenti in OSM ma non nello stradario di riferimento
venivano stampate nel foglio "Strade classificate" SENZA i dati del tracciato
(distanza, affiancamento, attraversamenti), anche quando erano state misurate.
Risultato: strade su cui il tracciato corre in affiancamento longitudinale per
km apparivano con celle vuote, indistinguibili da un "fuori fascia". Ora i dati
del tracciato vengono mostrati anche per queste strade. (Caso reale Coriano:
SP41 affiancamento ~1.928 m + 7 attraversamenti e SP49 ~5.416 m + 22
attraversamenti risultavano vuote; erano le due strade più interessate.)

**Strade classificate senza geometria non più scartate in silenzio.** Se una
strada è classificata in OSM ma manca la geometria in un dato run, ora finisce
in una sezione dedicata "NON misurate" con warning, invece di sparire: così un
possibile affiancamento non misurato resta una verifica aperta segnalata.

**Gestori stradali regionali (SR/SS).** Nuova knowledge base 'gestori_regionali':
quando OSM non porta il tag operator, per le strade regionali lo strumento
propone il gestore probabile in base alla regione (es. Lazio→ASTRAL,
Veneto→Veneto Strade, FVG→FVG Strade), marcato "~ … (da confermare)". È un
suggerimento da verificare, non una certificazione.

## Novità versione 0.102

**Logo beexact ufficiale (SVG) su sfondo bianco.** Il banner ora usa il logo
vettoriale ufficiale beexact (file SVG) su fascia bianca, al posto della versione
disegnata a mano. Essendo vettoriale e renderizzato alla densità reale dello
schermo, è perfettamente nitido a qualsiasi scaling di Windows.

## Novità versione 0.101

**Logo beexact leggermente più piccolo** nel banner (più margine bianco attorno).

## Novità versione 0.100

**Logo beexact nitido anche con scaling schermo (HiDPI).** La sgranatura residua
era causata dallo scaling di Windows (es. 125%): il logo veniva disegnato a pixel
logici e poi stirato dal sistema. Ora il pixmap è renderizzato alla densità reale
dello schermo (letta da devicePixelRatio/logicalDpi) e marcato con
setDevicePixelRatio, così viene mostrato 1:1 sui pixel fisici — testo e frecce
restano nitidi a qualsiasi livello di scaling.

## Novità versione 0.99

**Logo beexact nitido nel banner.** Rifatto il rendering del logo per eliminare
la pixellatura e il chevron impastato: la scritta 'beexact' viene ritagliata dal
logo e scalata con supersampling (bordi netti), mentre le due frecce chevron
sono ridisegnate nativamente come poligoni (una bianca e una arancione, sagome
distinte e pulite) invece di rimpicciolire il JPEG che le fondeva in un blocco.

## Novità versione 0.98

**Rifinitura banner beexact.** Su indicazione: ripristinata l'icona QGIS di
default nella barra del titolo (rimossa l'icona beexact dalla finestra); banner
reso più stretto (da 40 a 30 px); logo spostato più a sinistra (margine ridotto)
e ritagliato via software per eliminare il padding navy attorno, così il chevron
bianco appare pulito e il logo parte a filo del bordo sinistro.

## Novità versione 0.97

**Logo beexact nel pannello.** Aggiunto un banner con il logo beexact (su sfondo
navy) a tutta larghezza in cima al pannello del plugin, e impostata l'icona
beexact nella barra del titolo della finestra e nella taskbar. La barra del
titolo di Windows con l'icona di sistema non è ricolorabile, quindi
l'identità del brand è resa dal banner interno appena sotto.

## Novità versione 0.96

**Default dei layer aggiornati per le schede del ramo Comune.** All'apertura del
pannello, i menu a tendina delle schede Comune si preimpostano sui layer tipici
del progetto Fibercop:

- **Seleziona elementi:** Infrastrutture → 03 INFRASTRUTTURE, Civici → CIVICI,
  ROE PTE → ROE PTE, Pozzetto → 02_POZZETTO, Cavo ottico → CAVO OTTICO,
  Cavo Raccordo → RACCORDI (prima cercava "CAVO RACCORDO"), Edifici → Edifici
  (prima senza default);
- **Esportazione:** Foto → Punto di Ripresa Fotografico, Armadio →
  01_ARMADIO OTTICO, Infrastrutture → 03 INFRASTRUTTURE, Stradario →
  Stradario_Italia (nuovo default), Pozzetto → 02_POZZETTO.

I default scattano solo se il layer esiste nel progetto; altrimenti il combo
resta com'è e lo imposti a mano (con la barra di ricerca introdotta in 0.94).

## Novità versione 0.95

**Correzione barra di ricerca layer: ora si può lasciare il campo vuoto.** Nei
combo che ammettono l'opzione "nessun layer" (Stradario, Armadio, ecc.) svuotare
il campo di ricerca ora imposta correttamente "nessun layer", invece di
riproporre l'ultimo selezionato. Sui combo che richiedono un layer, un testo non
valido continua a ripristinare l'ultima scelta buona.

## Novità versione 0.94

**Barra di ricerca nei menu a tendina dei layer.** Tutti i combo di selezione
layer del plugin (in ogni scheda) sono ora ricercabili: basta iniziare a
digitare una parte del nome per filtrare la lista, senza distinzione tra
maiuscole/minuscole e cercando la parola ovunque nel nome (non solo all'inizio).
Comodo nei progetti con molti layer. Se digiti un testo che non corrisponde a
nessun layer e clicchi altrove, il combo torna automaticamente all'ultimo layer
valido, senza lasciare selezioni sospese.

Corretto anche un errore introdotto in 0.93 che poteva impedire l'apertura del
pannello dopo lo spostamento dell'evidenza strade.

## Novità versione 0.93

**"Evidenza delle strade interessate" spostata nel solo ramo Altri Enti.** Il
gruppo di controlli per evidenziare in tavola le strade classificate toccate dal
progetto serve solo per le pratiche verso gli altri enti (ANAS, Provincia…), non
per la pratica comunale. Ora compare esclusivamente nella scheda Esportazione
del ramo Altri Enti; nel ramo Comune la scheda è più snella. Le impostazioni
dell'evidenza restano indipendenti e vengono salvate solo dove la funzione esiste.

## Novità versione 0.92

**Correzione conteggio ARLO.** I poligoni del layer Arlo Area senza etichetta
(campo `Label` vuoto/NULL) non vengono più conteggiati come zona ARLO: erano
in genere artefatti sovrapposti a un'area già etichettata e gonfiavano il
numero (es. 7 invece di 6). Il numero di poligoni scartati è indicato nel log
dello screening. Il foglio "Riepilogo" e la colonna ARLO AREA riflettono ora
solo le zone realmente etichettate.

## Novità versione 0.91

**Foglio "Riepilogo" al posto di "ARLO Area".** Sostituito il foglio per-zona
(troppo articolato) con una tabella piatta di riepilogo, una riga per ente/
interferenza, sul modello richiesto:

| Comune | Provincia | Regione | Ente | AREA ARMADIO | n° ARLO |

- una riga per ciascun ente/vincolo coinvolto (Comune, strade classificate,
  Soprintendenza, ferrovie, corsi d'acqua);
- **AREA ARMADIO** ricavata dal suffisso della Label ARLO (es. 387-04 → 04),
  elencando tutte le aree armadio toccate da quell'ente;
- **n° ARLO** = numero di zone ARLO interessate.

Molto più compatto e leggibile, adatto a essere consultato o incollato in un
prospetto. Il foglio compare solo se il progetto ha il layer Arlo Area.

## Novità versione 0.90

**Nuovo foglio Excel "ARLO Area" — vista per zona di progetto.** Oltre alle
colonne ARLO nei fogli esistenti, ora c'è un foglio dedicato che, per ogni
ARLO AREA, riassume:

- le **infrastrutture di progetto** che vi ricadono: tratte (03 INFRASTRUTTURE)
  con numero e metri totali + le loro label, armadi ottici, pozzetti;
- le **strade interessate** con classe e stato (attraversamento/affiancamento);
- i **vincoli paesaggistici**, le **ferrovie** e i **corsi d'acqua** che toccano
  quella zona.

Così per ogni area di progetto vedi in un colpo d'occhio quanto scavo comporta e
quali enti/vincoli la riguardano. Il foglio compare solo se nel progetto c'è il
layer Arlo Area. Se due poligoni ARLO si sovrappongono, gli elementi in comune
compaiono in entrambe le zone (rispecchia la sovrapposizione reale).

## Novità versione 0.89

**Colonna "ARLO AREA" nell'Excel dello screening.** Ogni strada, vincolo e
interferenza lineare viene attribuito alla/e zona/e ARLO che tocca (dal campo
`Label` del layer Arlo Area), così sai subito quale area di progetto è
interessata da ciascun vincolo:

- foglio "Strade classificate": colonna ARLO AREA con l'etichetta della zona
  attraversata/affiancata (o "—" se la strada è nel comune ma fuori da ogni ARLO);
- foglio "Vincoli e fonti": colonna ARLO AREA su vincoli paesaggistici, ferrovie
  e corsi d'acqua. La pericolosità idrogeologica ISPRA è un dato per comune,
  quindi riporta "intero comune".

La colonna compare solo quando nel progetto è presente il layer Arlo Area.
I poligoni ARLO senza etichetta compilata (`Label` vuoto) prendono "ARLO n".

## Novità versione 0.88

**Excel dello screening più chiaro e mai muto:**

- **Grafica ripulita:** intestazioni verdi coerenti su tutti i fogli, righe con
  bordi e zebratura, titolo e disclaimer distinti, colonne ridimensionate. Il
  foglio "Vincoli e fonti" — prima tre tabelle appiccicate — ora ha 4 sezioni
  titolate: 1) vincoli paesaggistici, 2) interferenze e pericolosità, 3) fonti
  e affidabilità, 4) avvertenze.
- **Foglio "Strade classificate" mai vuoto/silenzioso:** in testa una riga
  spiega sempre la fonte (stradario o OSM). Se non risulta nessuna strada, una
  nota rossa dice il MOTIVO reale — Overpass non raggiungibile in quel run
  (≠ assenza di strade) vs nessuna strada classificata che interseca il
  tracciato — con l'indicazione di rilanciare o caricare uno stradario.
- **Strade fuori fascia a titolo informativo:** in modalità tracciato, le
  strade classificate del comune che NON ricadono in fascia sono elencate in
  una sezione dedicata (nessun obbligo), così il foglio resta utile anche
  quando il tracciato non tocca nulla.

## Novità versione 0.87

**Secondo giro di correzioni dall'audit indipendente** (robustezza e completezza
delle fonti):

- **Paginazione WFS SITAP (bug critico):** le richieste ai vincoli erano
  troncate a un tetto fisso (400/800 poligoni) senza paginazione. Su comuni
  densi di vincoli (coste, aree boschive) i poligoni oltre il tetto venivano
  ignorati e un vincolo cogente realmente presente poteva risultare ASSENTE.
  Ora si pagina con startIndex fino a esaurire il dataset.
- **Risoluzione comune (admin_level=8):** per i capoluoghi omonimi della
  provincia (Roma, Milano, Napoli...) c'era il rischio di analizzare la Città
  Metropolitana invece del Comune. Ora si filtra esplicitamente il confine
  comunale.
- **Overpass timeout mascherato:** una risposta HTTP 200 con "remark" di
  timeout e dati parziali/vuoti veniva presa per buona. Ora attiva il failover
  sull'endpoint successivo.
- **Sito UNESCO senza ente:** il vincolo UNESCO veniva rilevato ma non generava
  alcun ente da interpellare (scheda mancante). Aggiunta la scheda in kb +
  warning automatico per qualsiasi vincolo intercettato privo di scheda.
- **Assenza interferenze lineari:** anche quando la query va a buon fine ma non
  trova ferrovie/corsi d'acqua, il report ora avvisa che OSM non è esaustivo
  (prima il caveat compariva solo in caso di errore di rete).
- **Caveat centro abitato sulle fasce stradali:** nei comuni >10.000 ab, una
  strada in sola prossimità (non attraversata) è marcata "(se fuori centro
  abitato)" perché le fasce di rispetto non valgono dentro il perimetro urbano.

## Novità versione 0.86

**Revisione a 360° della logica di analisi (screening territorio).** Audit
completo del motore, con fix di correttezza geometrica e di dominio:

- **Percentuali vincoli oltre il 100% (bug):** le aree dei poligoni SITAP
  sovrapposti venivano sommate (es. "boschi 159,8% del territorio"). Ora le
  intersezioni col comune/area sono unite (unary_union) prima di misurare
  l'area: le percentuali sono corrette e limitate al 100%.
- **Ref stradali multipli OSM (bug):** una way con `ref="E45;SS3bis"` veniva
  scartata perché leggeva solo il primo ref (E45 = itinerario europeo, senza
  competenza) e perdeva la SS3bis (ANAS). Ora si valutano tutti i ref e si
  tiene quello con competenza (priorità A>SS>SR>SP).
- **Competenza nei centri abitati >10.000 ab (art. 2 c.7 CdS):** per i comuni
  con oltre 10.000 abitanti il report segnala che i TRATTI INTERNI al centro
  abitato di SS/SR/SP sono strade comunali ex lege (Cons. Stato 403/2014):
  competenza del Comune, non dell'ente proprietario. Fuori dal centro resta
  l'ente. Nota riportata su ogni strada interessata (report ed Excel).
- **Analisi sul tracciato — affiancamento vs attraversamento:** oltre alla
  distanza minima, ora si misurano i METRI DI AFFIANCAMENTO (posa longitudinale
  lungo la strada) e il numero di ATTRAVERSAMENTI puntuali. Sono ciò che conta
  per canone e regime autorizzativo. Nuove colonne nell'Excel.
- **Soglie vincoli per tipo:** in modalità tracciato i vincoli areali (art. 136,
  boschi, parchi) contano se il tracciato li ATTRAVERSA o ricade entro il
  margine scelto — non più una fascia fittizia di 150 m attorno a ogni vincolo
  (i 150 m valgono solo per la fascia fluviale, già nei poligoni SITAP).
- **Distanze dalla fonte primaria (bug):** con stradario DBSN attivo, le
  distanze non vengono più sovrascritte da quelle OSM (meno accurate).
- **Corsi d'acqua senza nome:** i rii demaniali minori privi di tag `name` non
  vengono più scartati (erano interferenze reali perse).
- **Match ISPRA IdroGEO robusto:** confronto ISTAT normalizzato che gestisce lo
  zero iniziale delle province 01-09 (es. Genova 010032).

Il tool ora funziona anche su progetti SENZA i tuoi layer (niente ARLO, niente
DBSN/stradario): basta 03 INFRASTRUTTURE + pozzetti per il tracciato, e le
strade arrivano da OSM, i vincoli da SITAP. Verificato su Masone (GE).

## Novità versione 0.85

**Screening territorio — analisi sul TRACCIATO con fasce di rispetto
ufficiali:** nuova modalità (ora di default) che misura la distanza reale in
metri tra il tracciato di progetto (03 INFRASTRUTTURE + 02_POZZETTO +
01_ARMADIO OTTICO uniti) e ogni strada/vincolo/interferenza, e la confronta con
la fascia di rispetto ufficiale di quell'ente:
- strade: 40 m (SS), 60 m (autostrade), 30 m (SP/SR) — art. 26 DPR 495/1992;
- ferrovie: 30 m dalla rotaia più esterna (DPR 753/1980);
- corsi d'acqua: 150 m fascia paesaggistica (art. 142 D.Lgs 42/2004).
Ogni ente riceve lo stato "ATTRAVERSAMENTO" o "entro fascia di rispetto (N m)";
ciò che è oltre la fascia viene escluso dagli enti (non genera obbligo). Le
distanze sono calcolate sulla geometria della fonte primaria (DBSN/stradario
regionale se attivo, altrimenti OSM). L'elenco enti diventa così esattamente le
istanze da protocollare per quello scavo. In alternativa resta l'analisi
sull'AREA di progetto (ARLO), più prudente. Margine attorno al tracciato
regolabile (default 20 m).

Il report Markdown e l'Excel guadagnano le colonne "Distanza dal tracciato",
"Stato" e "Fascia di rispetto". Nota: le distanze OSM/SITAP hanno accuratezza
posizionale variabile; per gli attraversamenti critici verificare in campo.

## Novità versione 0.84

**Screening territorio — vincolo idrogeologico e rischio alluvioni (ISPRA
IdroGEO):** nuovo stadio che interroga l'API nazionale ISPRA IdroGEO e riporta,
per il comune, le aree a pericolosità idraulica (PGRA: P1/P2/P3) e da frana
(PAI: P1-P4) come percentuale di territorio. Fonte autoritativa (ISPRA),
confidenza alta. Se la pericolosità supera l'1% del territorio il report genera
l'ente competente (Regione/ente delegato + Autorità di Bacino Distrettuale) con
titolo, documentazione e criticità. Nuova sezione "3-bis" nel Markdown e righe
dedicate nel foglio "Vincoli e fonti" dell'Excel. È un dato per COMUNE, non per
area di progetto: dice se il territorio ha aree vincolate; se il tracciato ci
ricade, la perimetrazione di dettaglio va letta sul PAI del distretto e sul
geoportale regionale (il report lo dichiara).

## Novità versione 0.83

**Screening territorio — lo stradario di riferimento si sceglie da solo:**
all'apertura del pannello il combo dello stradario viene preselezionato sul
miglior layer presente nel progetto, con la spunta già attiva. Priorità:
1) DBSN Strade (carreggiata reale, IGM — indipendente da OSM); 2) grafo
regionale (Stradario FVG/Veneto/…); 3) estratto OSM (ANAS_Italia, Stradario
Provincia Italia) solo come ultima scelta. Nei progetti che caricano più DBSN
regionali insieme, viene scelto quello la cui estensione copre davvero l'area
di progetto (ARLO), non il primo dell'elenco. Resta tutto modificabile a mano
e la spunta si può togliere. Il campo con la sigla è riconosciuto in
automatico (tr_str_nom per il DBSN, trim_str_c per FVG, ref per gli estratti
OSM).

## Novità versione 0.82

**Screening territorio — stradario di riferimento come fonte primaria delle
strade:** nuova spunta "Usa uno stradario del progetto come fonte primaria",
con combo del layer e del campo che contiene la sigla (SP/SS/…). Quando
attiva, la classificazione delle strade viene letta da QUEL layer (filtrato
sull'area di progetto) e OSM/Overpass resta come **controprova**: ogni strada
nel report è marcata "Confermata OSM sì/no", le strade presenti in OSM ma non
nello stradario finiscono in una riga a parte "solo OSM — da verificare", e
ogni discordanza genera un warning. Il tool **riconosce da solo** se il layer
scelto è un estratto OpenStreetMap (campo osm_id): in quel caso avverte che la
controprova NON è indipendente e tiene la confidenza "media"; con una fonte
vera (grafo regionale, DBSN) la confidenza sale ad "alta". Dove lo stradario
regionale ha il campo dell'ente gestore (es. Stradario FVG: "FVG Strade",
"Provincia di Udine"), quell'ente reale sostituisce il generico nel report e
nell'Excel. Il file .xlsx guadagna la colonna "Confermata OSM".

Nota tecnica utile: i layer "ANAS_Italia" e "Stradario Provincia Italia" del
progetto sono estratti OSM (Geofabrik), NON fonti indipendenti — usarli come
riferimento dà coerenza col dato in mappa ma non aggiunge autorevolezza. Per
una verifica davvero indipendente da OSM usare il DBSN (IGM) o un grafo
regionale (BDTRE, Stradario FVG/Veneto/Lazio). Non esiste ad oggi un servizio
ANAS ufficiale interrogabile a caldo: il grafo ANAS su dati.mit.gov.it è fermo
al 2015 e il sito stradeanas.it non espone la rete come geodato.

## Novità versione 0.81

**Screening territorio — restrizione all'area di progetto (ARLO):** nuova
spunta "Restringi all'area di progetto" (attiva per default, con il combo
preimpostato sul layer ARLO AREA/Arlo Area quando esiste nel progetto): lo
screening tiene solo le strade, i vincoli e le interferenze che intersecano
davvero l'area — l'elenco enti diventa la lista delle istanze da protocollare,
non l'inventario dell'intero comune. Le percentuali dei vincoli sono
ricalcolate sull'area e ogni strada dichiara i segmenti dentro l'area accanto
a quelli comunali. Il filtro avviene sulle geometrie vere (unione dei poligoni
ARLO riproiettata in WGS84), non sui conteggi.

**Screening territorio — report Excel:** nuova spunta per il file .xlsx
accanto al progetto, tre fogli: "Enti da interpellare" (riga per ente con
ruolo, trigger, titolo richiesto, norme, PEC, documentazione e criticità),
"Strade classificate" (ref, classe, ente, gestore OSM, segmenti
comune/area), "Vincoli e fonti" (vincoli, interferenze, provenienza e
confidenza, warning). Scritto con openpyxl, incluso in QGIS.

**Screening territorio — ex sedimi ferroviari:** la query delle interferenze
ora intercetta anche railway=abandoned/disused/razed. Il sedime delle linee
dismesse resta di norma di proprietà RFI anche dove riconvertito a greenway
(caso reale: la Voghera–Varzi a Rivanazzano Terme) e l'attraversamento
richiede comunque il nulla osta: nuova voce 'ferrovia_dismessa' nella kb, ente
dedicato nel report. In più: se lo stadio ferrovie/acque fallisce per rete, il
report ora lo dice con un warning esplicito invece di mostrare un elenco
vuoto; il registro della scheda mostra il perché di ogni ente (trigger).

## Novità versione 0.80

**Nuova scheda — "Screening territorio" (ramo Altri Enti):** scrivi il nome del
comune e il plugin interroga le fonti nazionali per la pre-istruttoria dello
scavo su suolo pubblico: rete stradale classificata (SS ANAS, SP, SR,
autostrade) con l'ente gestore da OSM, Soprintendenza ABAP competente con PEC
(SITAP/MiC, dato autoritativo), vincoli paesaggistici nazionali (art. 136,
art. 142, parchi, UNESCO), ferrovie (fascia 30 m ex DPR 753/1980) e corsi
d'acqua. Produce l'elenco degli enti da interpellare — titolo richiesto,
riferimenti normativi, documentazione tipica, criticità note — un report
Markdown salvato accanto al progetto e, a scelta, i layer in mappa nel gruppo
"Screening <comune>" (confine, strade, vincoli, interferenze) con zoom
automatico sul comune. Un secondo screening sullo stesso comune sostituisce il
gruppo invece di duplicarlo.

La logica vive in `ftth_screening.py` (nessun import qgis/PyQt, testabile
fuori da QGIS come ftth_core) e la mappa infrastruttura→ente→procedimento in
`procedimenti.yaml`, knowledge base curata a mano e versionata. La confidenza
di ogni fonte è propagata fino al report: è una ricognizione, non una
certificazione — OSM non è autoritativo per le strade, SITAP è ricognitivo e i
vincoli ex art. 142 operano anche se non cartografati. Failover automatico tra
4 endpoint Overpass; gli errori di rete finiscono nel registro della scheda,
mai in un crash del pannello.

## Novità versione 0.78.5

**Default — "Su una tratta misura" parte su "dal km … al km …":** è la
dicitura che va nelle tavole, e il valore salvato dalle versioni precedenti
("inizio della tratta") la scavalcava a ogni apertura — era il motivo per cui
il campo continuava a ricevere un valore solo. Migrazione una tantum come per
la scheda Edifici: il vecchio valore salvato viene dimenticato una volta sola,
poi le scelte dell'utente tornano a essere ricordate.

**Novità — aggancio dei capi delle tratte ai pozzetti:** i capi delle tratte
di Infrastruttura coincidono con i pozzetti della rete. Nuovo selettore
"Pozzetti (aggancia i capi delle tratte)" nel punto 3: quando un capo cade su
un pozzetto entro la tolleranza di aggancio (default 1 unità), la sua
chilometrica viene misurata ESATTAMENTE nel punto del pozzetto — così il
valore scritto sulla tratta e quello scritto sul pozzetto sono identici, e
tratte consecutive che condividono un pozzetto ricevono lo stesso km sul capo
comune. Dove il capo non tocca nessun pozzetto la chilometrica si calcola come
sempre sul corridoio. Il log dichiara quanti capi sono stati agganciati, tratta
per tratta.

**Interfaccia — i layer della scheda Chilometriche sono preimpostati
all'apertura:** cippi ('Cippi_Chilometrici'), target ('03 INFRASTRUTTURE'),
pozzetti ('02_POZZETTO') e linea di riferimento (il primo presente fra
'Stradario Provincia Italia', 'ANAS_Italia', 'Stradario', 'Rete stradale'),
con la solita regola: il nome atteso ha la precedenza quando il layer esiste
nel progetto.

## Novità versione 0.78.4

**Novità — misura "dal km … al km …" per le tratte (scheda Chilometriche):**
quarta voce nel menù "Su una tratta misura": scrive nell'attributo il testo
esteso con inizio e fine della tratta, es. "dal km 17+100 al km 17+145".
L'inizio è sempre il capo con la chilometrica minore — il verso di crescita
della strada — a prescindere dal verso in cui la polilinea è stata disegnata.
Pensata per le Infrastrutture, dove la dicitura entra così com'è nelle tavole
e nelle relazioni per l'ente.

**Fix — lunghezza del campo chilometrica:** il campo testo creato dal punto 0
passa da 20 a 40 caratteri, perché "dal km 999+999 al km 999+999" (30) non ci
stava e il provider avrebbe troncato in silenzio. Sui campi ESISTENTI creati
corti dalle versioni precedenti il calcolo ora avvisa nel log — con le misure
lunghe (intervallo e testo esteso) — indicando di ricreare il campo.

## Novità versione 0.78.3

**Novità — filtro sulla quota d'area in carreggiata (nuovo campo nel punto 2,
default 50%).** L'attraversamento dice che un bordo taglia l'edificio, ma non
quanto dell'edificio sta sulla strada: un edificio a filo carreggiata, tagliato
appena da un bordo, veniva selezionato come uno che ci sta in mezzo. Ora un
edificio preso dall'attraversamento o dal corridoio viene tenuto solo se almeno
la quota impostata della sua AREA sta fra i bordi.

Poiché coi bordi la carreggiata non esiste come poligono, la quota si stima
campionando una griglia di punti dentro l'edificio e verificando per ciascuno
se sta fra due bordi (versione puntuale del test del corridoio). Sui dati veri
della Valle d'Aosta la distribuzione delle quote è bimodale — 257 edifici sotto
il 25% (tagliati appena, i falsi positivi lamentati), 100 sopra il 75% (davvero
in mezzo alla strada) — quindi la soglia al 50% separa i due gruppi nella valle
naturale: dei 417 presi prima ne restano 127, e il log dichiara quanti sono
stati scartati dal filtro. Con 0 il filtro è spento e il comportamento torna
quello della 0.78.2. Il valore vale solo nel flusso coi bordi (test del
corridoio attivo): con gli assi la carreggiata fra i bordi non esiste e la
quota non sarebbe stimabile.

La diagnostica "Perché questo edificio?" riporta la quota stimata e il minimo
richiesto, così un verdetto "tenuto dal filtro area" è spiegato per intero.

## Novità versione 0.78.2

**La scheda "Edifici in carreggiata" ora funziona con i soli default: si
sceglie la regione e si preme Analizza.** Tre interventi:

**Default — criterio attraversamento + test del corridoio accesi di
fabbrica.** Il flusso di lavoro reale è il DBSN, dove il livello strade del
gruppo regione contiene i BORDI della carreggiata: con i vecchi default
(buffer + corridoio spento) l'analisi trovava 2 edifici su 20.871. Chi lavora
su un livello di assi può sempre tornare al buffer dal punto 2.

**Fix — rimosso il preset "Strade DBSN" del selettore "Usa invece questo
livello strade".** Introdotto nella 0.77, riempiva il selettore a ogni
apertura e così SCAVALCAVA il livello giusto riconosciuto dentro il gruppo
della regione ('DBSN Strade (carreggiata reale)'): l'analisi girava su un
layer sbagliato qualunque regione si scegliesse — era la causa dei "sempre 9
edifici" a prescindere dalle impostazioni. Vuoto è il default corretto:
significa "usa il livello del gruppo della regione selezionata".

**Novità — migrazione una tantum delle impostazioni memorizzate.** Il pannello
ricorda i valori fra le sessioni, quindi i nuovi default non basterebbero: chi
ha usato le versioni precedenti ha in memoria criterio=buffer e
corridoio=spento, che tornerebbero a ogni apertura. Alla prima apertura della
0.78.2 quei due valori vengono dimenticati (solo quelli, una volta sola); da
lì in poi le scelte dell'utente tornano a essere ricordate come sempre.

## Novità versione 0.78.1

**Fix — "Edifici in carreggiata" su 'DBSN Strade (carreggiata reale)' trovava
una manciata di edifici su migliaia (misurato: 2 su 20.871 in Valle d'Aosta).**
Tre cause concatenate, verificate sui dati veri:

1. **Il preset era il criterio sbagliato per quel livello.** Il buffer da 3 m
   col contenimento è tarato sugli ASSI stradali; su un livello che contiene i
   BORDI della carreggiata l'area del buffer copre solo una fascetta attorno a
   ciascun bordo e la parte centrale della strada resta scoperta: quasi nessun
   edificio risulta "contenuto". Ora, quando il nome del livello dichiara i
   bordi (contiene "carreggiata", "bordi" o "limiti"), l'analisi lo riconosce e
   propone di passare ad attraversamento + test del corridoio — la combinazione
   costruita apposta per quei livelli. Con essa gli edifici trovati passano da
   2 a 417.

2. **Il test del corridoio scartava il bordo opposto quando stava nella stessa
   feature del bordo vicino.** Le due parallele di una strada possono essere
   parti della stessa polilinea: il test escludeva per intero la feature del
   bordo più vicino, quindi non trovava mai il bordo opposto e l'edificio
   sfuggiva — è il caso dell'edificio grigio accanto a quello giallo segnalato
   nella verifica su mappa. Poiché il raggio parte dal centro dell'edificio e
   va dalla parte OPPOSTA al punto più vicino, un'intersezione con la stessa
   feature è per forza un altro tratto di linea: ora viene contata.

3. **Il test del corridoio non girava affatto se l'edificio non toccava
   nessun bordo col proprio rettangolo di ingombro:** un `continue` anticipato
   saltava tutto. Ma un edificio in mezzo a una carreggiata larga, lontano da
   entrambi i bordi, è esattamente il caso che il corridoio deve prendere. Ora
   col criterio dell'attraversamento il corridoio gira anche a candidati vuoti.

Il verdetto sul singolo edificio è stato estratto in un metodo statico
(`_verdetto_edificio`) senza stato del pannello: la stessa identica logica gira
nell'analisi, nella diagnostica e nei test fuori QGIS, quindi non può più
divergere fra i tre punti.

## Novità versione 0.78

**Struttura — la logica di puro calcolo vive ora in `ftth_core.py`:** parser e
formattatore delle chilometriche, fusione degli intervalli del retino,
trasformazione di similitudine dell'allineamento, arrotondamento all'italiana
delle misure e union-find della ricucitura corridoi. Il modulo non importa
niente da QGIS né da Qt: si esegue e si testa con un normale interprete
Python. Il dialogo delega a queste funzioni, quindi il comportamento è
identico; cambia solo dove il codice abita.

**Novità — test automatici in `tests/test_core.py`:** 32 casi che fissano i
comportamenti conquistati nelle versioni passate — i prefissi dei cippi che
mandavano in errore il parser (v0.54), la continuità del retino (v0.66),
l'arrotondamento 8,5 → 9 delle misure in tavola, i casi degeneri della
trasformazione. Girano senza QGIS: `python -m unittest discover tests`.
Ogni regressione futura su questa logica viene catturata prima del rilascio,
non sui dati veri.

**Fix — le eccezioni non fatali non spariscono più in silenzio:** nove punti
in cui un errore veniva ingoiato con `except: pass` (salvataggio impostazioni,
preset dei layer, personalizzazione del retino, rimozione layer) ora lasciano
una riga di avviso nel pannello "Log dei messaggi" di QGIS, scheda
"FTTH Permessi". Il comportamento non cambia — l'operazione prosegue come
prima — ma un malfunzionamento diventa diagnosticabile. Restano muti solo i
ripieghi per-feature deliberati, dove il fallback È il comportamento.

**Fix — guardia sul doppio contesto della scheda Esportazione:** le due copie
della scheda (Comune e Altri Enti) condividono la logica scambiando il set di
widget attivo. Se un widget nuovo viene aggiunto alla scheda ma dimenticato
nell'elenco `_ATTR_CONSEGNA`, le due copie lo condividerebbero in silenzio,
mescolando le impostazioni dei due rami: ora il caso viene rilevato e
segnalato con un errore esplicito al primo click, durante lo sviluppo.

**Documentazione — README e changelog separati:** il README è ora la pagina
di presentazione (cos'è, come si installa, come è organizzato), il changelog
completo — questa cronologia — sta in CHANGELOG.md.

## Novità versione 0.77

**Interfaccia — la scheda "Edifici in carreggiata" si apre già sulla
configurazione collaudata:** criterio del contenimento nella carreggiata
ricostruita col buffer, larghezza 3 m, attraversamento minimo 0 m, larghezza
massima di carreggiata 14 m, unione dei tronchi adiacenti attiva, test del
corridoio spento. Sono i valori con cui la scheda è stata messa a punto sui dati
veri, e trovarli già impostati evita di doverli ricostruire a mano ad ogni nuova
installazione. Restano tutti modificabili, e da quel momento il pannello ricorda
le impostazioni di chi lavora come per ogni altra scheda.

**Interfaccia — il livello strade viene preimpostato** cercando nel progetto,
nell'ordine, "Strade DBSN", "CTR_Strade_OSM" e "Strade". I combo dei layer non
si salvano fra le sessioni, perché puntano a un progetto specifico, quindi il
nome atteso va riproposto all'apertura. A differenza degli altri preset qui si
interviene solo se il combo è ancora vuoto: il campo ammette la scelta vuota,
quindi vuoto significa davvero "non ho scelto", e sovrascrivere una scelta fatta
a mano sarebbe peggio che non preimpostare nulla.

## Novità versione 0.76

**Fix — il test del corridoio ora è spento di partenza.** Serve solo quando il
livello strade contiene i limiti della carreggiata. Se le linee sono gli assi —
il caso normale — il test cerca "un'altra linea dalla parte opposta" e la trova
nella strada parallela vicina: in un centro abitato dichiarerebbe in carreggiata
gli edifici che stanno fra due strade, a decine.

L'equivoco è facile e vale la pena scriverlo: una simbologia a doppio tratto
(una linea scura spessa disegnata sotto e una chiara più sottile sopra, la
tecnica del *casing*) fa sembrare due bordi paralleli quella che è una sola
geometria. Si riconosce dal file di stile, dove ogni simbolo ha due strati
SimpleLine sullo stesso tracciato con `symbollevels` attivo, oppure cliccando su
una delle due linee con lo strumento Informazioni: se risponde una feature sola,
sono assi.

Quando il test è attivo il log ora lo dichiara e ricorda di controllare il
conteggio "racchiusi fra due bordi" prima di eliminare.

## Novità versione 0.75

**Novità — test del corridoio, per i livelli che contengono i BORDI della
carreggiata:** nel DBSN il livello delle strade non contiene gli assi ma i limiti
della carreggiata, due linee parallele per ogni strada con in mezzo la sede
stradale, che però non esiste come geometria. Il criterio dell'attraversamento
prende gli edifici che toccano un limite, ma lascerebbe lì un edificio minore
piccolo che sta tutto dentro la carreggiata senza arrivare a toccarne i bordi.

Il test guarda il bordo più vicino al centro dell'edificio e cerca un altro bordo
dalla parte opposta, lungo la perpendicolare, entro una larghezza massima di
carreggiata impostabile. Un edificio appena fuori strada ha un bordo da un lato e
niente dall'altro, quindi non scatta; uno in mezzo a due strade parallele lontane
non scatta perché il raggio non ci arriva. Su un banco di prova con sei casi —
compreso il centro dell'edificio esattamente sopra un bordo — il metodo estratto
dal sorgente dà sei verdetti corretti su sei. Il conteggio nel log distingue
quanti edifici sono stati riconosciuti solo grazie a questo test.

**Fix — il contenimento totale penalizzava gli edifici grandi:** a parità di
posizione sulla strada, un edificio sottile risultava contenuto nel buffer mentre
uno più grande, attraversato dalla stessa linea, ne sporgeva e veniva lasciato lì.
Non era una questione di distanza ma della forma del criterio, ed è la ragione
per cui l'attraversamento è ora il predefinito sui livelli lineari.

## Novità versione 0.74

**Novità — nuovo criterio "l'asse stradale attraversa l'edificio", predefinito
sui livelli lineari:** se l'asse della strada passa dentro un edificio, quello è
in mezzo alla strada, e non serve sapere quanto è larga la carreggiata. La
larghezza era il punto debole del buffer: sulla stessa regione convivono strade
da quattro metri e da dodici, mentre il buffer ne usa una sola. Su un banco di
prova con sei casi tipici, il buffer sbaglia due volte con qualunque valore —
troppo stretto perde gli edifici laterali delle strade larghe, troppo largo
prende quelli a bordo delle strade strette — mentre l'attraversamento sbaglia
una volta sola.

Soprattutto, l'attraversamento sbaglia **solo per difetto**: può lasciare lì un
edificio che sta in carreggiata di lato, ma non dichiara mai dentro qualcosa che
sta fuori. Trattandosi di una cancellazione è l'errore preferibile, perché ciò
che sfugge si prende al giro dopo mentre ciò che viene cancellato per sbaglio va
ripescato dal file. Il criterio del buffer resta disponibile nel punto 2 per chi
lo preferisce, e sui livelli poligonali il test è sempre il contenimento nel
poligono.

Il parametro "attraversamento minimo" evita che il criterio scatti quando l'asse
sfiora appena un angolo dell'edificio: con zero basterebbe un contatto puntuale.
Con questo criterio l'unione dei tronchi adiacenti non viene calcolata, perché un
asse che passa dentro l'edificio lo attraversa comunque, a prescindere da come i
tronchi sono spezzati.

**Interfaccia — il log e la diagnostica dichiarano il criterio in uso** e ne
adattano le colonne: con l'attraversamento la misura utile è la lunghezza del
tratto di asse interno all'edificio, non la percentuale di area sovrapposta.

## Novità versione 0.73

**Novità — il livello strade si può scegliere a mano:** nuovo selettore nel
punto 1 della scheda "Edifici in carreggiata". Lasciandolo vuoto vale il
riconoscimento per nome dentro il gruppo della regione, come prima;
impostandolo, quel livello viene usato per tutte le regioni. Serve quando le
strade stanno in un livello unico fuori dai gruppi regione, e quando nel gruppo
esiste più di un livello il cui nome contiene la chiave di ricerca: il primo che
il riconoscimento incontra non è per forza quello giusto, e il selettore è
l'unico modo per dirlo con certezza. Il log dichiara sempre quale livello è
stato usato e da dove viene.

**Fix — avviso sul buffer applicato a linee che non sono assi stradali:**
allargare una linea produce area sui due lati. Va bene se le linee sono gli assi;
se invece sono i limiti della carreggiata — due parallele per ogni strada, come
nel DBSN — il risultato è sbagliato in entrambe le direzioni: gli edifici a filo
strada finiscono dentro il buffer del limite pur stando fuori, e quelli davvero
in mezzo alla carreggiata cadono nella fascia scoperta fra i due buffer e
sfuggono. Su un banco di prova con quattro casi tipici, tre verdetti su quattro
risultano sbagliati. L'avviso ora compare nel log dell'analisi, nella
diagnostica e nel suggerimento del campo larghezza, con l'indicazione di usare
un livello poligonale.

**Novità — pulsante "Perché questo edificio?":** rifà il ragionamento su un solo
elemento selezionato in mappa e ne riporta i passaggi — quali tronchi di strada
ha considerato, quanto lo sovrappongono in percentuale, la distanza, l'esito
dell'unione e il verdetto con la sua ragione. Quando l'edificio viene tenuto
riporta anche la sovrapposizione massima raggiunta: se sfiora il cento per cento
il problema è il criterio del contenimento totale, se è bassa l'edificio è
davvero fuori. È lo strumento da usare quando il risultato non torna, al posto
di cambiare i parametri a tentativi — stesso ruolo del pulsante Diagnostica
delle chilometriche.

## Novità versione 0.72

**Novità — nuovo ramo "Cartografia di base":** raccoglie gli interventi sul dato
di partenza (CTR, DBSN, stradari), distinti da quelli sui dati di progetto.
"Allinea cartografia" si è spostata qui dal ramo Comune, dove stava per comodità
ma non c'entrava con la pratica comunale, e si chiama ora solo "Allinea". Il ramo
è in fondo, dopo Altri Enti, per non spostare l'ordine delle schede già note.

**Novità — scheda "Edifici in carreggiata":** nei dati DBSN capita che geometrie
di *Edifici minori* cadano dentro il poligono della carreggiata: sono errori del
dato di base, non edifici. La scheda percorre l'albero dei livelli, riconosce i
gruppi che contengono sia le strade sia gli edifici minori — una riga per
regione — e lavora una regione alla volta. L'analisi trova e seleziona in mappa
senza modificare niente; il secondo pulsante scrive gli elementi in un
GeoPackage e solo dopo aver verificato che il salvataggio sia completo li
cancella; il terzo li rimette dentro rileggendoli dal file.

L'abbinamento fra strade ed edifici avviene sui **figli diretti** dello stesso
gruppo e non sull'intera discendenza: i gruppi regione sono annidati dentro un
gruppo padre, e con una ricerca ricorsiva il padre sarebbe risultato lavorabile
a sua volta, facendo confrontare gli edifici di una regione con le strade di
un'altra.

Il criterio è il **contenimento totale**: un edificio che sporge anche di poco
dalla carreggiata non viene toccato, perché a bordo strada gli edifici veri
toccano quasi sempre il poligono. La carreggiata però è spezzata in tronchi, e
un edificio a cavallo di due tronchi adiacenti non è contenuto in nessuno dei
due preso singolarmente: per questo, quando nessun tronco singolo lo contiene,
i tronchi vicini vengono uniti e il test si ripete sull'unione. È lo stesso
motivo per cui le chilometriche misurano sui corridoi ricuciti e non sulle
singole tratte. L'unione si calcola solo per i casi dubbi, non a monte su tutta
la rete regionale. Il log dice quanti edifici sono stati riconosciuti soltanto
grazie a lei.

Se il livello delle strade è lineare non esiste un poligono in cui essere
contenuti: in quel caso la carreggiata viene ricostruita allargando l'asse della
larghezza indicata, e il log dichiara che il contenimento vale su una carreggiata
stimata. Poiché una larghezza in metri non ha senso in coordinate geografiche —
e il DBSN è distribuito così — in quel caso i confronti passano nel CRS di
progetto, se metrico; se non lo è, l'analisi si ferma con l'indicazione di cosa
cambiare.

**Novità — l'analisi non blocca l'interfaccia:** barra di avanzamento con il
conteggio degli elementi esaminati e pulsante Interrompi che ferma davvero. Il
tempo dipende dalla regione e non dalla dimensione del progetto: le strade
vengono lette ristrette all'estensione degli edifici di quel gruppo, così anche
indicando per sbaglio un livello stradale nazionale non si legge l'Italia intera
per confrontarla con una regione sola. Gli attributi non vengono letti affatto,
né sulle strade né sugli edifici: al confronto geometrico non servono e sono la
parte pesante della lettura. La cancellazione avviene con una sola chiamata per
tutti gli identificativi e un solo commit.

**Fix — la chiusura del pannello durante l'analisi non manda più in crash QGIS:**
il ciclo chiama processEvents() per tenere viva l'interfaccia, e durante quelle
chiamate Qt consegnava anche la richiesta di chiusura; il dialogo veniva
distrutto mentre il ciclo stava ancora scrivendo su barra e log, cioè su oggetti
C++ già liberati — un errore che nessun try/except Python intercetta. Ora la
chiusura viene rifiutata e tradotta in una richiesta di interruzione.

**Interfaccia — il file degli scarti è un GeoPackage e non uno Shapefile:**
conserva i nomi di campo per intero, mentre gli attributi DBSN superano i dieci
caratteri e su DBF verrebbero troncati, rendendo impreciso il ripristino. Un
livello per regione dentro lo stesso file: la cancellazione di una regione
riscrive solo il proprio livello e lascia intatti gli altri.

## Novità versione 0.71

**Interfaccia — all'apertura tutte le sezioni sono chiuse:** ogni scheda si
presenta come un elenco di titoli, si apre quello che serve e il resto resta
fuori dai piedi. Il salvataggio automatico dello stato di QgsCollapsibleGroupBox
è stato disattivato di proposito: quel widget memorizza in QgsSettings se il
riquadro era aperto e lo ripristina quando viene mostrato, sovrascrivendo la
chiusura impostata alla costruzione, quindi i riquadri lasciati aperti nella
sessione precedente si sarebbero riaperti da soli. Nuovo pulsante "Chiudi tutte
le sezioni" in fondo al pannello, per tornare alla vista d'insieme senza
chiudere e riaprire.

**Interfaccia — scheda di installazione riscritta** con il testo definitivo:
una riga di descrizione, tre righe sul flusso di lavoro e il rimando alla guida
contestuale e al README.

## Novità versione 0.70

**Novità — scheda "Suolo comunale" nel ramo Altri Enti:** individua gli elementi
di progetto che non ricadono sugli stradari di competenza dell'ente (SP, ANAS,
altro) e li separa in un gruppo di livelli a sé, che si spegne quando si stampa
la tavola per quell'ente. Lavora in due passi: prima li seleziona in mappa e
inquadra la zona, perché li si possa controllare a vista e ritoccare la
tolleranza; solo dopo la conferma li sposta. Lo spostamento non cancella e non
duplica geometrie: scrive un campo SUOLO che distingue i due casi, crea un
gruppo di livelli filtrati sul valore COMUNALE e applica agli originali il
filtro complementare. I livelli del gruppo nuovo sono cloni di quelli originali,
quindi conservano sorgente e simbologia — a vedersi sono identici. Un terzo
pulsante annulla tutto rimuovendo il gruppo e azzerando i filtri. Sui livelli
temporanei, dove il filtro non è applicabile, le feature vengono copiate e
l'originale resta intero: il log lo segnala.

**Interfaccia — i riquadri di log non occupano più spazio da vuoti:** erano
undici rettangoli bianchi che nelle schede più cariche allontanavano i controlli
fra loro. Ora sono richiudibili, partono chiusi e si aprono da sé quando c'è
qualcosa da leggere.

**Interfaccia — i riquadri di sola impostazione partono chiusi:** creazione del
campo chilometrica, filtri e grafica delle etichette, unione PDF. Le azioni di
ogni giorno restano aperte. Un primo tentativo chiudeva per posizione — primo
riquadro aperto, gli altri chiusi — ma nelle Chilometriche avrebbe chiuso proprio
il riquadro del calcolo.

**Interfaccia — scheda di installazione sintetizzata:** descrizione e testo
"about" in metadata.txt erano un paragrafo unico di circa 1100 caratteri; ora
sono una riga e cinque righe divise per ramo.

## Novità versione 0.69

**Interfaccia — impostazioni ricordate fra le sessioni:** il pannello memorizza
i valori dei campi alla chiusura e li rimette all'apertura, così non si
riparte ogni volta dai valori di fabbrica. I combo dei layer sono esclusi di
proposito, perché puntano a layer di un progetto specifico e ripristinarli su
un altro progetto darebbe riferimenti sbagliati: per quelli restano i preset
automatici. Le due copie della scheda Esportazione (Comune e Altri Enti) hanno
memorie separate, quindi puoi tenere impostazioni diverse nei due rami. Un
pulsante "Ripristina i valori iniziali" in fondo al pannello riporta tutto ai
predefiniti.

**Interfaccia — riquadri comprimibili:** ogni riquadro si chiude con un clic
sul titolo e QGIS ne ricorda lo stato. Con sette schede e ventisette riquadri
la finestra era diventata un muro di controlli.

**Interfaccia — pulsante Guida in ogni scheda:** apre una finestra non modale
con la spiegazione di quella parte del plugin, il flusso passo per passo e le
cause tipiche dei problemi. Si può lavorare con la guida aperta accanto.

**Interfaccia — versione nel titolo della finestra:** il pannello si intitola
ora "Gestione Permessi FTTH — v0.69". Serve a rispondere a colpo d'occhio alla
domanda "sto usando la versione nuova?", che durante lo sviluppo ha fatto
perdere tempo più di una volta.

**Aspetto — nuova icona nei colori beexact:** fondo blu #011e5a, chevron
arancione #ff7e01 e tre fibre bianche che convergono. Disegnata per essere
leggibile a 24 px, che è la dimensione con cui QGIS disegna la barra degli
strumenti: il primo tentativo aveva anche un punto luminoso nel mezzo, ma a
quella scala si impastava col chevron.

**Default — evidenza delle strade:** all'apertura sono ora preselezionati
tinta unita, tratte intere, corpo del nome strada a 16 pt.

## Novità versione 0.68

**Interfaccia — riquadro dell'evidenza riorganizzato:** era un elenco di
tredici controlli in fila, in fondo al quarto riquadro di una scheda lunga, e
la spunta del nome della strada risultava introvabile. Ora è diviso in due
sezioni, "Quali strade" e "Aspetto in stampa", con le opzioni di resa
raggruppate dove chi le cerca va a guardare.

## Novità versione 0.67

**Novità — nome della strada sull'evidenza, una volta per strada:** il layer di
evidenza contiene ora una feature per strada invece di una sola geometria
dissolta, ed è questo che permette di scrivere il nome una sola volta ciascuna.
Le tre impostazioni che evitano la ripetizione sono `labelPerPart = False` —
una scritta sola anche quando la fascia di una strada è spezzata in più parti —
nessuna distanza di ripetizione, che è ciò che nello stradario produce le sigle
minute ogni pochi centimetri di carta, e il piazzamento libero, che ruota il
testo per farlo stare dentro la fascia. Corpo regolabile, grassetto con alone
bianco, priorità alta perché la scritta non venga scartata per collisione con
le etichette dei pozzetti.

**Novità — spunta per spegnere le etichette dello stradario:** le sigle
ripetute lungo la strada vengono dall'etichettatura del layer stradario, non
dall'evidenza. Spenta per default, perché modifica un layer che l'utente non ha
chiesto di toccare; quando la si usa il log dice cosa è stato fatto e come
annullarlo.

**Fix — lunghezza nell'attributo:** era ricavata dall'area della fascia divisa
per la larghezza, ora è misurata direttamente sulla porzione di corridoio.

## Novità versione 0.66

**Fix — continuità del retino:** l'evidenza copriva le singole tratte toccate,
quindi dove una tratta intermedia non veniva sfiorata si apriva un buco. Ora lo
stradario viene ricucito in corridoi continui, su ciascuno si calcolano gli
intervalli di progressiva interessati e i vuoti sotto soglia vengono colmati.
Su scavi intervallati lungo due chilometri si passa da tre frammenti separati a
un tratto unico. Nuovi parametri "Colma i vuoti fino a" e "Salda le fasce che
si sfiorano", che con una chiusura morfologica chiude la fessura agli incroci —
dove due strade sono due corridoi distinti — con raggio limitato a metà
larghezza per non fondere strade parallele vicine.

**Fix — la causa vera dei buchi era la tolleranza:** "Distanza max elemento →
tratta" era a 2 m, ma lo stradario è l'asse e gli scavi corrono a bordo strada:
su una carreggiata di 8-10 m il bordo dista 4-5 m dall'asse, quindi quei tratti
venivano scartati in silenzio. Default portato a 8 m, e il log elenca ora
quanti elementi sono rimasti fuori e a che distanza stanno.

**Novità — stile dell'evidenza personalizzabile:** selettore di colore, quattro
stili (retino diagonale, retino incrociato, retino con bordo, tinta unita),
passo, spessore e angolo del retino. Passo e spessore sono in millimetri sul
foglio, quindi restano identici in stampa a qualunque scala.

## Novità versione 0.65

**Fix — crash di QGIS premendo "Evidenzia le strade interessate":** per mettere
il layer in fondo all'elenco era stato usato `insertLayer(-1, layer)`, con
l'idea che -1 significasse "in coda" come in Python. Quell'indice finisce in
`QList::insert()`, che pretende `0 <= indice <= numero di figli`: con -1 Qt
scrive prima dell'inizio dell'array e il processo muore di corruzione
dell'heap. È un crash nativo, quindi il try/except intorno non poteva
intercettarlo. Il metodo corretto è `addLayer()`, che accoda.

**Fix — secondo crash latente nel retino:** a `setSubSymbol()` veniva passato lo
stesso oggetto ottenuto da `subSymbol()`. Quel metodo distrugge il sotto-simbolo
corrente e prende possesso di quello nuovo, quindi rigirargli lo stesso
puntatore lo fa usare dopo la liberazione. Ora si passa un clone.

**Perf — lo stradario non viene più letto per intero:** l'evidenza scorreva
tutte le feature del layer di riferimento, che su un grafo provinciale sono
centinaia di migliaia, e se il layer è servito via WFS anche altrettante righe
dalla rete a ogni pressione del pulsante. Ora si legge solo l'intorno degli
elementi di progetto: su uno stradario di prova da 4200 tratte ne legge 17, con
risultato identico. Avviso nel log se il layer è remoto, tetto di sicurezza a
100.000 tratte, cursore di attesa durante l'unione delle fasce.

## Novità versione 0.64

**Fix — l'evidenza copriva gli elementi di progetto invece delle strade:** il
layer di riferimento veniva preso dal campo "Stradario" della scheda
Esportazione, che è opzionale e senza valore preimpostato; se lì c'era un layer
lineare qualsiasi — Infrastrutture è lineare — il retino veniva costruito su
quello, senza che nulla lo segnalasse. L'evidenza ha ora un proprio selettore
con preset, accetta layer lineari e poligonali, rifiuta con un messaggio
esplicito i layer di progetto e dichiara nel log quale stradario ha usato.

## Novità versione 0.63

**Novità — stile del testo delle etichette:** menù "Leggibilità sullo sfondo"
con quattro varianti — solo testo, alone bianco, riquadro bianco
semitrasparente, riquadro con ombra sottile. Su una CTR il testo nero cade su un
intreccio di linee nere e con il solo alone il tratteggio continua a leggersi
dentro le lettere: il riquadro semitrasparente stacca il testo da qualunque
sfondo restando discreto. Ombra tenuta breve — 0,7 mm a 135°, opacità 45%,
posizionata sotto il riquadro e non dietro le lettere. Selettore del carattere
di sistema e grassetto. La costruzione di riquadro e ombra è isolata con una
propria gestione degli errori: se una costante manca in quella versione di QGIS
si perde solo il riquadro, non tutta l'etichettatura.

## Novità versione 0.62

**Novità — chilometrica per singolo layer nelle etichette:** una spunta per
riga nella griglia, spenta per Infrastrutture, dove ripetere la chilometrica
era una duplicazione. Conseguenza utile: le tratte senza chilometrica calcolata
non vengono più saltate.

**Fix — l'etichettatura esistente non viene più cancellata:** QGIS ammette una
sola etichettatura per layer e `setLabeling()` sostituisce quella che c'era.
Con la nuova spunta "Conserva l'etichettatura già presente" quella esistente
viene convertita in regola e la nuova si aggiunge come seconda regola, che è
l'unico modo di averne due contemporaneamente.

## Novità versione 0.61

**Fix — punto interrogativo nelle etichette:** il separatore predefinito era un
trattino tipografico (U+2013), che uno shapefile senza file .cpg — quindi in
codepage ANSI — non sa scrivere e sostituisce con "?". Ora i separatori sono
ASCII e prima di scrivere il testo viene provato nella codifica del layer, con i
caratteri tipografici ricondotti all'equivalente ASCII.

**Novità — etichette in mappa con la grafica delle tavole:** testo nero
multiriga allineato a sinistra, scostato dall'elemento e collegato da una linea
di richiamo, con corpo e distanza regolabili. Spunta per mettere la chilometrica
in fondo all'etichetta, come nelle tavole.

**Novità — evidenza delle strade interessate:** nuovo riquadro nella scheda
Esportazione che copre con una fascia le tratte dello stradario su cui ricadono
gli elementi di progetto. Le fasce vengono dissolte, altrimenti con la
trasparenza le sovrapposizioni fra tratte adiacenti scurirebbero il colore.

## Novità versione 0.60

**Fix — errori di conteggio delle chilometriche fra elementi diversi:** tre
cause distinte, tutte a monte del calcolo. L'area entro cui veniva letto lo
stradario dipendeva dalla selezione, quindi il corridoio veniva ricucito
diverso a ogni lancio e lo stesso pozzetto elaborato con due selezioni diverse
otteneva due valori: ora l'area si calcola sull'estensione dei layer.
`mergeLines()` unisce solo le linee che condividono un vertice esatto, mentre
negli stradari i tronchi si chiudono a pochi centimetri e agli incroci la
strada viene tagliata: c'è ora una tolleranza di ricucitura che segue la
prosecuzione più diritta, con un limite di 75° oltre il quale non aggancia, per
non svoltare nella laterale. Sulle tratte veniva misurato il punto medio, per
cui due scavi consecutivi ricevevano valori distanti mentre il primo finiva
dove il secondo cominciava: ora si misura il capo con la chilometrica minore,
con la possibilità di scrivere l'intervallo completo.

**Novità — punto 0 dichiarato e controverifica:** il log apre indicando quale
cippo è il riferimento, avvisa se i corridoi in uso sono più di uno — caso in
cui gli elementi non sono confrontabili fra loro — e per ogni altro cippo
confronta il valore dichiarato con quello che la progressione prevede per la sua
posizione.

## Novità versione 0.59

**Fix — le chilometriche non erano progressive:** l'interpolazione fra i cippi
riscalava le distanze sui valori dichiarati, quindi un cippo mal posizionato
comprimeva o dilatava tutto il tratto. Ora il conteggio parte dal cippo con la
chilometrica più bassa e somma la distanza reale percorsa lungo la strada, un
metro per un metro, nel verso in cui i chilometri crescono: i valori sono
monotoni e confrontabili. Su tre cippi reali un pozzetto a 500 m dal primo dava
17+444 e ora dà 17+600. L'interpolazione resta disponibile come terza opzione.

## Novità versione 0.58

**Interfaccia — aiuto contestuale richiudibile:** ogni scheda si apriva con un
paragrafo giustificato di otto-dieci righe che spingeva i controlli sotto la
piega. Ora resta visibile la prima frase, con un "dettagli" che apre il resto.

**Interfaccia — esito inline invece dei popup di conferma:** nelle schede
Chilometriche ed Etichette il risultato è una riga in grassetto sopra il log.
Gli errori restano popup.

**Interfaccia — la finestra ricorda dimensione e scheda aperta**, i log usano un
carattere a larghezza fissa, la scheda Etichette è divisa in passi numerati.

## Novità versione 0.57

**Fix — dicitura dello scavo:** rimosso "IN" dalla dicitura predefinita, che con
valori aggettivali dava "SCAVO IN TRADIZIONALE". Nuova dicitura dedicata per le
tratte aeree, dove "SCAVO AEREA" non vuol dire niente, e filtro per i soli
elementi con STATO = 'Nuovo', dato che nei layer di progetto convivono le
tratte in progetto e quelle esistenti.

## Novità versione 0.56

**Novità — riconoscimento del campo per contenuto:** i campi di origine delle
etichette si scelgono ora da un elenco invece di digitarne il nome, e
l'auto-riconoscimento guarda i valori contenuti prima del nome del campo — una
corrispondenza sul contenuto vale tre punti, una sul nome uno. Serve perché in
questo modello dati 'TIPOLOGIA' esiste ma può contenere Aerea/Interrata invece
della tecnica di scavo. Nuovo pulsante "Ispeziona i campi", che elenca ogni
campo con alcuni valori di esempio.

## Novità versione 0.55

**Novità — scheda Etichette:** compila un campo di testo su Armadio, Pozzetto e
Infrastrutture con la dicitura di posa, componendola dalla chilometrica più la
lavorazione. Il campo viene creato se manca. Diciture e campi di origine sono
modificabili dall'interfaccia. La lunghezza ripiega sul campo alternativo del
modello dati e infine sulla lunghezza geometrica reale, così l'etichetta non
resta senza metri per un campo non ancora calcolato. Anteprima prima di
scrivere.

## Novità versione 0.54

**Novità — parser dei cippi più tollerante:** il prefisso descrittivo con cui i
cippi sono normalmente etichettati ("KM 17+100", "PK 17+100", "progr. 17+100")
mandava il parser in errore e i cippi venivano scartati in silenzio, quindi il
calcolo non partiva affatto. Ora il prefisso viene ignorato e il formato del
valore si dichiara da un menù, compresa la forma invertita metri+km.

**Novità — controllo di coerenza dei cippi:** se fra due cippi la chilometrica
non cresce di circa un metro per metro percorso, il log lo segnala invece di
scrivere valori plausibili all'apparenza e completamente sbagliati.

## Novità versione 0.53

**Fix — calcolo delle chilometriche su stradari spezzettati:** la progressiva
veniva misurata sulla singola feature del riferimento e si pretendeva che cippo
ed elemento ricadessero sulla stessa; in uno stradario, spezzato in centinaia
di tratte, due punti a cinquanta metri stanno quasi sempre su tratte diverse,
quindi veniva scartato tutto con "nessuna ancora sulla stessa linea". Ora le
tratte contigue vengono ricucite in corridoi continui e la misura avviene lungo
quelli. Un cippo vicino a un bivio serve tutti i corridoi che ha entro
tolleranza, non solo il più vicino. Nuovo pulsante Diagnostica, che dice quanti
cippi sono stati letti e quali scartati, quanti corridoi ricuciti, quanti
elementi si agganciano e di quanto sono fuori tolleranza gli altri.

**Novità — campo dei cippi selezionabile** invece di essere cablato su
'Chilometrica', con preselezione automatica, e scrittura su più layer target in
un colpo.

## Novità versione 0.52

**Fix — creazione del campo 'Chilometrica' sugli shapefile:** il formato DBF
limita i nomi campo a dieci caratteri, quindi QGIS chiedeva 'Chilometrica' e
OGR restituiva 'Chilometri': il commit falliva con "il campo con indice 14 non
è uguale!" e faceva rollback. Il nome viene ora adattato al provider prima di
aggiungere il campo, e la ricerca del campo tollera nomi troncati e differenze
di maiuscole. Su GeoPackage e PostGIS il nome resta intero.

**Novità — scheda Esportazione anche nel ramo Altri Enti,** come copia
indipendente: layer, layout e liste PDF possono essere diversi dai due lati.

## Novità versione 0.51

**Perf — Stradario/Provinciali/ANAS ritagliati su ARLO AREA:** su
richiesta, Stradario, Provinciali e ANAS non vengono più letti per
intero (comuni shape a scala nazionale, es. Stradario Italia) ma solo
entro ARLO AREA (fusa, dalla scheda "Keyplan e tavole") allargata di
un margine impostabile (nuovo campo "Ritaglia Stradario/Provinciali/
ANAS a: ARLO AREA + margine", default 500 unità progetto). Il filtro è
un bbox lato provider (rapido anche su shapefile grandi grazie
all'indice .qix). Se ARLO AREA non è impostata, il log finale avvisa
che i layer sono stati letti per intero.

## Novità versione 0.50

**Fix — Punti di ripresa lentissimi (fino a 3 min):** la ricerca del
piede sullo Stradario re-interrogava il layer via bbox, con raggio
raddoppiato fino a 9 volte, PER OGNI candidato di OGNI tavola — su uno
Stradario grande (es. Stradario Italia) era il vero collo di
bottiglia. Ora l'indice spaziale su Stradario si costruisce UNA sola
volta, prima del ciclo sulle tavole, e ogni ricerca costa una
`nearestNeighbor()` sull'indice in RAM invece di una nuova scansione
del layer.

**Fix — rotazione dei coni sugli attraversamenti:** i punti di
attraversamento (Infrastruttura×Strada) sono per costruzione già
posizionati SULLA strada — proiettarli di nuovo sulla strada più
vicina ritornava il punto stesso: distanza zero, camera "sopra"
l'oggetto, rotazione indefinita. Ora, quando il soggetto giace già
sulla strada, la camera viene spostata della Distanza di ripresa
lungo la strada (resta sulla sua stessa linea) e l'inquadratura è
forzata perpendicolare alla strada — una vera foto di attraversamento
invece di un cono piazzato sul soggetto.

**Interfaccia — scheda "Punti di ripresa" unificata:** i campi Armadio
Ottico, Punto di Ripresa, Stradario, Sedime Pubblico, raggio e
distanze — prima in un blocco separato dal box "Coni per Tavola di
Inquadramento" pur essendo usati solo da quest'ultimo — sono ora
dentro lo stesso box, un'unica scheda con un solo scopo.

**Rinominata la scheda "Shape di consegna" in "Esportazione".**

## Novità versione 0.49

**Nuovo — Unisci PDF (Shape di consegna):** nuova sezione "Unisci PDF in un
ordine stabilito" sotto l'esportazione Atlante: elenco riordinabile
(↑/↓, Aggiungi, Rimuovi) che si autopopola con i PDF appena esportati,
nello stesso ordine; unisce i file scelti in un unico PDF. Richiede il
pacchetto Python 'pypdf' (fallback 'PyPDF2'); se assente, avvisa con le
istruzioni di installazione invece di fallire in silenzio.

**Fix — attivazione Atlante verificata davvero:** `setEnabled(True)` da
solo non garantiva il refresh delle feature coperte se il layer/filtro
di copertura era cambiato dopo l'ultima apertura del layout. Aggiunta
una chiamata esplicita a `updateFeatures()` dopo l'attivazione, e un
controllo che blocca l'esportazione con un messaggio chiaro se
l'Atlante risulta comunque a 0 elementi — così l'attivazione è
verificata, non solo presunta dal risultato dell'export.

**Fix — Punti di ripresa, coni ravvicinati/fuori criterio:**
1. La ricerca del piede sullo Stradario ignorava la tavola: poteva
   agganciarsi alla strada più vicina in assoluto anche se fuori
   tavola, per poi essere spinta sul bordo — posizionamento arbitrario,
   senza legame con una strada reale della tavola. Ora un segmento
   realmente dentro la tavola ha sempre priorità su uno fuori, anche se
   più lontano in linea d'aria.
2. Le soglie anti-duplicato erano troppo strette (0,5 m sul soggetto
   inquadrato, 0,10 m sulla posizione camera): bastavano pochi metri di
   scarto tra pool diversi (es. stesso incrocio digitalizzato
   leggermente diverso su Provinciale e su Stradario) per sfuggire al
   controllo e produrre coni ravvicinati puntati, di fatto, allo stesso
   oggetto. Alzate rispettivamente a 3 m e 1 m.

**Testi dell'interfaccia sintetizzati:** tutte le descrizioni delle
sezioni (regole di selezione, allinea cartografia, coni, keyplan,
consegna, esporta PDF) sono state accorciate, mantenendo il contenuto
tecnico.

## Novità versione 0.48

**Rimozioni (Seleziona elementi):** eliminate la Regola 4b (Accorcia
tratte fino al bordo edificio) e la Regola 6 (Verifica Civici senza
Edificio / Recupera Edifici da riferimento).

**Regola 5 — Sedime Pubblico da shape locale:** nuovo pulsante "1b)
Genera Sedime Pubblico da Stradario locale": stessa bufferizzazione della
generazione OSM (linee bufferizzate, poligoni presi come superficie
piena), stesso layer temporaneo risultante, ma leggendo un layer già
caricato in locale (es. uno Stradario Italia) invece di scaricare da OSM
— nessuna chiamata di rete. Resta anche il campo "Sedime già pronto" per
un poligono di sedime già finito da usare direttamente.

**Punti di ripresa:**
1. Eliminato il pulsante standalone "Genera coni davanti agli Armadi
   Ottici": la stessa cosa (con priorità assoluta) la fa già "Coni per
   Tavola di Inquadramento", che riusa Stradario/Sedime Pubblico/raggio
   di ricerca/distanza di riserva impostati in cima alla scheda.
2. Nuovo livello di priorità "attraversamenti Infrastrutture×Stradario":
   prima venivano individuati solo gli attraversamenti su Provinciale/
   ANAS, perdendo la maggioranza degli attraversamenti reali (su strade
   comunali generiche, mai classificate Provinciale/ANAS).
3. Ogni punto di ripresa calcolato viene ora sempre riportato dentro il
   perimetro della tavola se lo Stradario lo avesse spostato fuori.
4. Nuovo controllo anti-duplicato sul SOGGETTO inquadrato (non solo
   sulla posizione della camera): evita che due coni diversi puntino
   allo stesso oggetto.

**Fix esportazione PDF (Shape di consegna):** il messaggio di errore
mostrato anche per esportazioni riuscite ("errore nell'esportazione
codice (0, '')") era un bug del plugin, non un vero errore: l'overload
statico per l'esportazione Atlante restituisce una coppia (risultato,
messaggio), non il solo codice come le esportazioni normali — il
confronto sbagliato segnalava sempre errore anche a PDF scritto
correttamente. Corretto.

## Novità versione 0.47

**Nuova funzione — Recupera Edifici mancanti da un layer di riferimento
(Regola 6, Seleziona elementi):** per ogni Civico senza Edificio, cerca
nel layer di riferimento impostato (fonte-agnostico: footprint
Microsoft/Google scaricati per l'area, CTR regionale, un altro shape già
pronto — non solo OSM) un elemento che lo copre entro la Tolleranza e lo
copia nello shape Edifici. Utile proprio quando lo shape Edifici del
progetto è già derivato da OSM: ripartire da OSM non aggiungerebbe nulla
di nuovo, serve una fonte diversa. I Civici rimasti scoperti anche dopo
vengono selezionati su Civici — solo quelli vanno tracciati a mano.
Modifica Edifici sul posto: chiede conferma prima di procedere.

## Novità versione 0.46

**Nuova sezione "Esporta PDF (Atlante)" (Shape di consegna):** esporta in
PDF, via Atlante, i layout di stampa già presenti nel progetto QGIS
(configurati con il loro layer di copertura Atlante nel Compositore — non
impostati da qui). Elenco a selezione multipla dei layout disponibili,
pulsante "Aggiorna elenco layout" se ne aggiungi di nuovi dopo aver
aperto il plugin, e un pulsante che sceglie la cartella ed esporta un PDF
per ciascun layout selezionato (nome del file = nome del layout);
l'Atlante viene attivato automaticamente se non lo è già, e riportato
allo stato originale al termine.

**Nuova Regola 6 (Seleziona elementi) — Verifica Civici senza Edificio:**
seleziona i Civici che non toccano/intersecano nessun elemento del layer
Edifici entro la Tolleranza — un edificio mancante da recuperare. Avviso
esplicito con il conteggio se ne trova; altrimenti conferma che tutti i
Civici hanno un Edificio associato.

## Novità versione 0.45

**Fix errore "Seleziona tratte da accorciare" (Regola 4b):**
"'QgsGeometry' object has no attribute 'boundary'" — il metodo
`QgsGeometry.boundary()` non è disponibile in tutte le versioni di
QGIS/PyQGIS. Il perimetro dell'edificio (usato per trovare il punto di
taglio) viene ora costruito a mano dagli anelli del poligono (esterno +
eventuali fori), senza dipendere da quel metodo.

## Novità versione 0.44

**Fix coni ancora appiccicati agli oggetti (Punti di ripresa):** il campo
Sedime Pubblico correggeva ANCHE i punti già trovati correttamente sullo
Stradario — se un Sedime Pubblico residuo di una sessione precedente
(o troppo stretto) risultava impostato, poteva risagomare/spostare un
punto già giusto verso l'oggetto fotografato. Ora il Sedime Pubblico
interviene SOLO sul ripiego "nessuna strada trovata", mai su un punto
già trovato correttamente sullo Stradario. Rimossa anche
l'autoselezione automatica del campo Sedime Pubblico (ora sempre
volontaria) per evitare che un layer residuo venga usato senza che te ne
accorga.

**Fix accorcia tratte (Regola 4b):** un PTE posizionato esattamente sul
bordo dell'edificio (il caso più comune, PTE a muro) non veniva
riconosciuto come "tocca l'edificio" — il controllo usava `contains()`,
che in senso stretto esclude i punti sul perimetro. Ora usa
`intersects()`, che riconosce anche il contatto sul bordo.

**Fix numerazione Keyplan (Keyplan e tavole):** il campo di default per
la numerazione del Keyplan ora è "Numero Tav" (lo stesso delle Tavole di
Inquadramento, come richiesto), non più "Numero KP". Il messaggio
finale ora riporta anche quanti elementi sono stati letti dal layer: se
il numero è molto più basso delle tavole/keyplan attese (es. sempre 1),
segnala di verificare che il layer impostato sia quello giusto (non un
filtro attivo, o il layer modello invece di quello generato).

## Novità versione 0.43

**Punti di ripresa:**
1. La ricerca dello Stradario ora parte dal raggio impostato e RADDOPPIA
   (fino a 256 volte il raggio iniziale) finché non trova una strada,
   invece di ricadere subito sul ripiego "a Nord" con un raggio troppo
   piccolo: era la causa più probabile dei coni che restavano appiccicati
   agli oggetti (Armadio/Pozzetto/Infrastruttura) invece di stare
   sull'asse della strada, e degli attraversamenti persi.
2. Nuovo campo opzionale "Sedime Pubblico": se impostato (es. quello
   generato dalla Regola 5), un punto di ripresa che cade fuori dal
   sedime pubblico viene spostato al punto più vicino dentro di esso —
   per evitare di piazzare il fotografo in un'area non accessibile (es.
   un cortile privato).
3. Rinforzato il controllo anti-duplicati già introdotto in v0.42 (ora
   coerente su tutte le chiamate, incluso il nuovo aggancio al Sedime).

**Keyplan e tavole — nuova numerazione:** pulsante separato "Numera
Keyplan e Tavole" che numera i due layer (indipendentemente) in ordine di
lettura: righe da nord a sud, e all'interno di ogni riga da ovest a est
(alto-sinistra → basso-destra). Campo creato se manca.

**Seleziona elementi:**
1. La selezione "Tratte + Pozzetti toccati da Edifici" ora esclude
   sempre le tratte TIPOLOGIA='Aerea', a prescindere dalla spunta
   STATO='Nuovo'.
2. "Accorcia tratte fino al bordo edificio" è ora in due passi: prima
   "Seleziona tratte da accorciare" (nessuna modifica, solo selezione da
   verificare sulla mappa), poi "Accorcia tratte selezionate" (agisce
   solo su quelle rimaste selezionate, con conferma).

## Novità versione 0.42

**Fix rotazione sempre a 180° (Punti di ripresa):** il filtro spaziale
per cercare lo Stradario vicino era costruito in CRS di progetto ma
inviato al layer Stradario senza convertirlo nel SUO CRS — su progetti
con Stradario in un CRS diverso da quello di progetto, il filtro non
trovava mai nessuna tratta, e la funzione ricadeva SEMPRE sul ripiego "a
Nord" (che dà, per costruzione, sempre rotazione 180°). Ora il
rettangolo di ricerca viene convertito nel CRS del layer Stradario prima
di interrogarlo.

**Fix coni duplicati sullo stesso punto (soprattutto sugli Armadi):**
"Coni Armadi" e "Coni per Tavola di Inquadramento" calcolano la STESSA
posizione (stessa proiezione sullo Stradario) per lo stesso Armadio:
eseguendo entrambi i pulsanti (o rieseguendo lo stesso più volte)
finivano due Foto diverse impilate sul punto identico. Ora entrambe le
funzioni tengono traccia dei punti già occupati (Foto già presenti nel
layer + quelle appena aggiunte in questa esecuzione): un Armadio il cui
punto coincide con un cono già esistente conta comunque come "coperto"
ma non viene duplicato; per attraversamenti/Pozzetto Nuovo/tratta un
candidato duplicato viene scartato e si prova il successivo, senza
sprecare uno dei 3 posti della tavola.

## Novità versione 0.41

**Fix errore "Regola 4b" (Accorcia tratte fino al bordo edificio):**
"MultiLineString geometry cannot be converted to a polyline" — molti
shapefile salvano anche le tratte logicamente singole come
MultiLineString con una sola parte, e la conversione usata non lo
gestiva. Ora la funzione riconosce questo caso e ricostruisce l'output
nello stesso formato (MultiLineString) atteso dal layer. Tratte con più
parti realmente disgiunte restano non toccate (nessun lato PTE/lato da
mantenere univoco in quel caso).

## Novità versione 0.40

**Allinea cartografia — spostamento esclusivo dei selezionati:** la
checkbox "Sposta SOLO gli elementi selezionati" ora è davvero esclusiva:
un layer impostato ma SENZA una selezione attiva viene saltato per
intero (nessun elemento spostato), invece di ricadere nello spostare
tutto il layer come accadeva prima.

**Seleziona elementi — Regola 4b, nuova (Accorcia tratte fino al bordo
edificio):** per ogni tratta Infrastrutture STATO='Nuovo' (esclusa
TIPOLOGIA='Aerea') che tocca un ROE PTE con TIPO diverso da "Interno
Edificio"/"Muro Interno" (quindi un PTE non interno a QUELL'edificio) e
che attraversa un elemento del layer Edifici, la tratta viene accorciata
fino al primo punto in cui tocca il bordo dell'edificio, eliminando il
tratto che prosegue dentro l'edificio verso quel PTE. Modifica le
geometrie sul posto: chiede sempre conferma prima di procedere. Richiede
un layer Edifici poligonale (non lineare).

## Novità versione 0.39

**Fix Keyplan che non contiene le Tavole di inquadramento:** aggiunto un
campo "Tavole di Inquadramento" condiviso nella sezione Keyplan — se
impostato, SIA il pulsante standard "Genera copertura Keyplan sull'area
di progetto" SIA "Rigenera Keyplan" (rigenerazione mirata) coprono
esclusivamente l'impronta di quelle tavole, ignorando del tutto ARLO
AREA. In precedenza il pulsante standard restava sempre legato ad ARLO
AREA (causa reale dei Keyplan che non contenevano le tavole vicine nello
screenshot), e la rigenerazione mirata dipendeva da un riferimento
interno valido solo nella stessa sessione in cui le tavole erano state
generate (fragile se il progetto veniva riaperto). Il campo si
autocompila cercando un layer chiamato "Poligoni Inquadramento".

**Punti di ripresa — numerazione che perdeva alcuni coni:** i coni
generati da "Coni per Tavola di Inquadramento" sono ora collegati alla
loro tavola con un campo interno esplicito ('ID_Tavola'), non più solo
per contenimento geometrico: un punto di ripresa spostato sullo Stradario
può finire fuori dal perimetro della tavola, e in quel caso il vecchio
test geometrico non lo trovava più — la Numerazione automatica Foto lo
lasciava senza numero. Le Foto senza questo collegamento (es. dal
pulsante Coni Armadi) continuano a usare il ripiego geometrico.

**Punti di ripresa — nuova priorità Pozzetto Nuovo:** aggiunto un livello
di priorità intermedio tra gli attraversamenti Provinciale/ANAS e la
tratta generica: i Pozzetti Nuovi che toccano un'Infrastruttura Nuova
sono ora un punto di interesse a sé, con priorità più bassa degli
attraversamenti ma più alta della tratta.

**Punti di ripresa — ancoraggio uniforme:** TUTTI i tipi di cono
(Armadio, attraversamenti, Pozzetto Nuovo, tratta) sono ora ancorati allo
stesso modo — proiezione perpendicolare sullo Stradario (o un altro
shape lineare a scelta) — non più solo l'Armadio.

## Novità versione 0.38

**Fix Keyplan che non contiene le Tavole di inquadramento vicine:** la
copertura adattiva valutava ogni posizione candidata solo contro la
singola componente connessa del 'buco' scoperto scelto come riferimento
— Tavole di inquadramento (o gruppi di Infrastrutture/Pozzetto Nuovi)
vicine ma non tecnicamente a contatto diretto sono componenti connesse
SEPARATE, quindi venivano ignorate anche quando cadevano comodamente
dentro la stessa tavola/keyplan. Ora ogni posizione viene valutata contro
TUTTO lo scoperto rimasto, non solo quella componente: un Keyplan (o una
Tavola di inquadramento) può quindi raccogliere più elementi vicini in
una volta sola, contenendoli davvero.

**Fix STATO='Nuovo'/TIPOLOGIA='Aerea' ancora aggirabile nella
rigenerazione mirata delle Tavole di inquadramento:** stesso bug di
confronto case/spazi-sensibile già corretto altrove in v0.37, ora esteso
anche a `_target_ottimizza_inquadramento` (il target usato dal pulsante
'Rigenera tavole di inquadramento solo sulla rete nuova').

**Punti di ripresa — priorità assoluta sugli Armadi:** ogni Armadio
Ottico presente in una Tavola di Inquadramento ha ora SEMPRE un cono
dedicato, anche se ce ne sono più di 3 nella stessa tavola (in quel caso
il tetto di 3 coni totali viene superato pur di non saltarne nessuno). Il
budget per attraversamenti/tratte si adatta di conseguenza.

**Punti di ripresa — logica parallela/perpendicolare sullo Stradario:**
il punto di ripresa via Stradario ora scompone esplicitamente ogni
segmento nella componente parallela (direzione della strada) e
perpendicolare (scarto laterale, cioè il punto di ripresa): un vero piede
perpendicolare (che cade dentro il segmento) è sempre preferito a un
punto d'estremo/incrocio, anche se quest'ultimo fosse leggermente più
vicino in linea d'aria — un estremo clampato non è una vera inquadratura
perpendicolare alla strada.

## Novità versione 0.37

**Fix coni su infrastruttura aerea (Punti di ripresa):** il confronto
TIPOLOGIA='Aerea' era case/spazi-sensibile: un dato scritto 'AEREA', '
Aerea ' ecc. non veniva riconosciuto come aereo e la tratta passava il
filtro. Ora il confronto (STATO e TIPOLOGIA) ignora maiuscole/minuscole e
spazi iniziali/finali.

**Numerazione automatica Foto (Punti di ripresa):** nuovo pulsante che
numera le Foto a blocchi fissi di 3 per Tavola di Inquadramento, ma SOLO
se le tavole sono già numerate in un campo esistente (letto, non generato
dal plugin) — altrimenti non fa nulla e spiega perché. Se una tavola ha
meno di 3 coni, il/i numero/i mancante/i del suo blocco vengono saltati,
non riassegnati alla tavola successiva.

**Allinea cartografia:** rimosso il calcolo automatico da shapefile di
riferimento; resta solo l'allineamento tramite punti di controllo
manuali (utile anche sopra un WMS).

**Keyplan/Tavole di inquadramento — fix centraggio:** la copertura
adattiva ora, oltre alla griglia di posizioni-angolo di sempre, prova
anche a centrare la tavola sul baricentro di tutto il contenuto che le
ricade attorno in una finestra grande quanto la tavola stessa; se quel
contenuto ci sta quasi per intero in una tavola sola, la posizione
centrata vince sempre. Le tavole risultano quindi centrate su quello che
devono inquadrare (Infrastrutture/Pozzetto Nuovi per le Tavole di
inquadramento, le Tavole di inquadramento stesse per il Keyplan) invece
di essere ancorate per un angolo/bordo.

## Novità versione 0.36

**Nuova scheda "Allinea cartografia":** sposta in blocco Armadio Ottico,
Infrastrutture, Pozzetto, ROE PTE, Cavo Ottico e Cavo Raccordo per
allinearli alla cartografia ufficiale del permesso (WMS o shapefile, a
seconda del territorio), preservando la topologia della rete — la
trasformazione (traslazione + rotazione + scala) è UNA sola, applicata
tutta insieme a tutti i layer scelti, non uno snap elemento per elemento
che romperebbe i collegamenti tra pozzetti e tratte.

Due modi per calcolarla:
- **A) Automatico da uno shapefile di riferimento**: abbina i vertici di
  un layer "àncora" (es. Infrastrutture) al punto più vicino su un layer
  di riferimento ufficiale entro una tolleranza, scarta gli abbinamenti
  anomali, calcola la trasformazione che minimizza lo scarto residuo
  complessivo (minimi quadrati).
- **B) Punti di controllo manuali**: utile sopra un WMS, che non ha
  geometrie proprie da agganciare automaticamente. Si clicca sulla mappa
  una coppia di punti alla volta (uno sulla rete, uno sul riferimento);
  con 2 o più coppie si calcola la stessa trasformazione.

In entrambi i casi viene mostrata un'anteprima (rotazione, scala,
traslazione, errore residuo) prima di applicare, e la conferma è
obbligatoria: l'operazione modifica le geometrie sul posto.

## Novità versione 0.35

**Ordine schede:** "Keyplan e tavole" spostata prima di "Punti di ripresa"
(le Tavole di inquadramento vanno generate prima, essendo ora un
riferimento per i punti di ripresa).

**Punti di ripresa:**
- Le Infrastrutture di interesse sono ora sempre solo STATO='Nuovo',
  escluse TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL (non più un filtro
  opzionale disattivabile).
- Il posizionamento del cono per l'Armadio Ottico non usa più gli
  Edifici come punto di ancoraggio: il punto di ripresa è ora la
  proiezione perpendicolare dell'Armadio sulla tratta di Stradario più
  vicina, con l'inquadratura rivolta verso l'Armadio dall'altro lato
  della strada. Rimosso il layer Edifici/Fabbricati, aggiunto Stradario
  (opzionale) sia nel pulsante Armadi singolo sia nei Coni per Tavola di
  Inquadramento.

**Seleziona elementi — Regola 5:** il Sedime Pubblico (OSM) ora include
anche marciapiedi e vie pedonali (già mappati come highway in OSM) e, dove
disponibili, tratta piazze e aree pedonali chiuse come superficie piena
invece che come una fascia bufferizzata attorno al solo perimetro — una
piazza larga non risultava quasi tutta scoperta (e quindi segnalata come
possibile privato) solo per un limite del buffer stradale.

**Keyplan/Tavole di inquadramento (rigenerazione mirata):** confermato che
il target è già completamente svincolato da ARLO AREA — le Tavole di
inquadramento puntano solo a Infrastrutture STATO='Nuovo' (escluse
TIPOLOGIA='Aerea'/NULL) + Pozzetto STATO='Nuovo', e il Keyplan copre solo
l'impronta di quelle tavole (fix già introdotto in v0.33).

## Novità versione 0.34

**Fix join ARMADI_FOTO (Shape di consegna):** la base del join era il
Punto di Ripresa invece dell'Armadio Ottico, quindi il risultato aveva una
riga per OGNI punto di ripresa (compresi quelli generati per
attraversamenti/tavole di inquadramento, non legati a un armadio) invece
di una per ogni Armadio Ottico. Confermato confrontando con uno shape
ARMADI_FOTO di riferimento: i campi dell'Armadio Ottico vengono per primi,
seguiti da quelli del Punto di Ripresa più vicino. Ora la base del join è
l'Armadio Ottico: ARMADI_FOTO.shp ha un solo elemento per ogni Armadio
Ottico, con gli attributi del Punto di Ripresa più vicino entro la
Distanza max join.

## Novità versione 0.33

**Fix copertura Keyplan/Tavole di inquadramento (rigenerazione mirata):**
1. Il Keyplan ottimizzato copriva l'intero ARLO AREA unito alle Tavole di
   inquadramento, invece delle sole Tavole di inquadramento: su un ARLO
   AREA molto più esteso della rete nuova, l'algoritmo sceglieva di
   coprire per prime zone lontane dalla rete, con il Keyplan che finiva
   piazzato spostato ("traslato") rispetto alle tavole invece che sopra
   di esse. Ora il target è solo l'unione delle Tavole di inquadramento
   già rigenerate.
2. Corretta la causa dei buchi rimasti su Infrastrutture/Pozzetto Nuovi:
   quando nessuna posizione libera da sovrapposizioni copriva un punto, la
   copertura scartava solo un'area minuscola attorno ad esso — su un
   target STRETTO (un corridoio attorno alla rete) questo poteva bruciare
   tutto il budget di tentativi su un'unica zona ostica (curve, incroci),
   interrompendo la generazione anche per il resto della rete, mai
   nemmeno provato. Ora: griglia di posizioni candidate più fitta (5×5),
   area scartata per fallimento proporzionata alla tavola (non più
   trascurabile) e budget di tentativi molto più alto.

**Regola 1b (Seleziona elementi):** aggiunta una terza condizione
indipendente di esclusione del Pozzetto: se toccato dal layer Cavo Ottico
(dorsale condivisa), oltre a TIPOLOGIA='No Dig' della tratta e sede-PTE
già presenti — basta una sola delle tre per escluderlo.

**Punti di ripresa — Coni per Tavola di Inquadramento:** il ripiego
quando mancano attraversamenti Provinciale/ANAS non punta più al PTE
dentro un Pozzetto, ma a un punto lungo la tratta Infrastruttura Nuova
stessa (l'attraversamento fisico da un Pozzetto a un ROE PTE, o tra due
Pozzetti). Rimosso il layer ROE PTE dalla sezione, non più necessario.

## Novità versione 0.32

**Regola 5 — sedime alternativo:** nella sezione "Possibile proprietà
privata" è ora possibile impostare un layer poligonale alternativo (es. da
un geoportale regionale/comunale più preciso di OSM per quel progetto): se
impostato viene usato al posto del Sedime Pubblico (OSM) generato al
punto 1, senza bisogno di integrazioni dedicate per ogni ente.

**Punti di ripresa — Coni per Tavola di Inquadramento:** nuova sezione
nella scheda "Punti di ripresa" che genera fino a 3 coni fotografici per
ogni Tavola di Inquadramento:
- 1 cono dedicato all'Armadio Ottico se ricade nella tavola (stessa
  logica di posizionamento — perpendicolare al muro più vicino — del
  pulsante Armadi già esistente);
- gli altri (fino a 3 se la tavola non contiene un Armadio) ai punti di
  attraversamento Infrastrutture×Provinciale e Infrastrutture×ANAS, e in
  mancanza ai Pozzetti sede di un ROE PTE (di qualsiasi tipologia) che
  ricadono nella tavola;
- priorità quando i candidati sono più del necessario: Provinciale, poi
  ANAS, poi Pozzetto-PTE; a parità di tipo vince il candidato più vicino
  al centro della tavola;
- layer Provinciale, ANAS e ROE PTE sono opzionali (se mancano, quel tipo
  di candidato è semplicemente assente dal conteggio).

## Novità versione 0.31

**Regola 5 (Seleziona elementi) — Possibile proprietà privata, automatica via OSM:**
1. "Scarica strade OSM e genera Sedime Pubblico": scarica da Overpass API
   (con mirror di riserva) le strade OpenStreetMap nell'area di
   Infrastrutture + Pozzetto, le bufferizza con la larghezza impostata
   (default 7 m) e crea il layer memory "Sedime Pubblico (OSM)".
2. "Seleziona tratte/pozzetti fuori dal Sedime": seleziona le tratte
   Infrastrutture e i Pozzetti che ricadono interamente FUORI da quel
   sedime — candidati a proprietà privata.

**Attenzione:** è una preselezione automatica, non una classificazione
legale — OSM può essere incompleto in alcune zone e il buffer è solo una
stima del sedime reale (piazze, cortili condominiali aperti su strada,
ecc. possono dare falsi positivi/negativi). Va sempre verificata a vista
prima di procedere con i permessi.

## Novità versione 0.30

1. **Regola 1b (Seleziona elementi):** il Pozzetto "subito dopo" la tratta
   non viene selezionato se è vera almeno una di due condizioni
   indipendenti: la tratta di provenienza ha TIPOLOGIA='No Dig', oppure il
   pozzetto è sede di un ROE PTE (di qualsiasi tipologia).
2. **Punti di ripresa:** rimossa la numerazione automatica dei punti di
   ripresa (campo "Campo numerazione" e relativa logica).
3. **Keyplan e tavole — rigenerazione mirata ("Rigenera solo sulla
   rete"):**
   - le Tavole di inquadramento si posizionano ora nel minor numero
     possibile sopra le Infrastrutture STATO='Nuovo' (escluse
     TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL) UNITE al Pozzetto
     STATO='Nuovo' — vanno generate per prime;
   - il Keyplan continua a tenere conto di ARLO AREA come prima, ma copre
     anche le Tavole di inquadramento già rigenerate: va quindi rigenerato
     DOPO di esse;
   - rimossa la numerazione automatica delle tavole/keyplan (campo "Numero
     Tav").
4. **Shape di consegna:**
   - i campi LUNGHEZZA e Lungh del layer "03 INFRASTRUTTURE" vengono creati
     solo se mancanti: se esistono già, vengono semplicemente aggiornati
     con l'espressione '$Length';
   - in ARMADI_FOTO, i valori '999' del campo CIVICO vengono sostituiti con
     'SNC';
   - il join Armadio Ottico + Punti di ripresa per generare ARMADI_FOTO
     tiene ora conto SOLO dei punti di ripresa effettivamente associati a
     un Armadio Ottico (entro la Distanza max join): i punti di ripresa
     senza un Armadio entro quella distanza vengono esclusi dallo shape,
     non più inclusi tutti indiscriminatamente.

## Novità versione 0.28 (base Infrastrutture garantita + pulizia campo 'n')

1. **Base Infrastrutture garantita.** L'aggiornamento di LUNGHEZZA/Lungh e
   la base del join per SCAVI_STRADE vengono ora presi sempre dal layer di
   progetto chiamato esattamente "03 INFRASTRUTTURE" (cercato per nome),
   non da quello selezionato al momento nel campo Infrastrutture della
   scheda — se trovato, il campo viene anche riallineato di conseguenza.
   Se il progetto non ha un layer con quel nome esatto, si usa comunque
   quello selezionato nel campo, come prima.
2. **Pulizia automatica del campo 'n'.** Prima di considerare pronti
   SCAVI_STRADE e POZZETTI_STRADE, vengono rimosse le eventuali righe con
   l'attributo 'n' diverso da 1 (o mancante): può capitare con un
   pareggio di distanza nel join, che produce più righe per lo stesso
   elemento di partenza — se ne tiene solo una. Il numero di righe rimosse
   (se maggiore di zero) compare nel messaggio finale.

## Novità versione 0.27 (schema attributi shape di consegna allineato ai file di riferimento)

Confrontata la tabella attributi generata con i file `.dbf` di riferimento
(SCAVI_STRADE, ARMADI_FOTO, POZZETTI_STRADE): i join non aggiungono più un
prefisso ai campi del layer unito (prima: `str_`/`armadio_`). I campi
vengono ora copiati con il loro nome originale; in caso di nomi già
presenti (es. `fid`), QGIS li rinomina da solo in `fid_2`, esattamente come
nei file di riferimento. Nome dei 3 shapefile e struttura dei join
(Foto+Armadio, Infra+Stradario[+Armadio], Pozzetto+Stradario[+Armadio])
restano invariati, erano già corretti.

## Novità versione 0.26 (regola 4: filtro opzionale STATO='Nuovo')

Nella regola "4) Tratte Infrastrutture + Pozzetti toccati da Edifici",
nuovo flag opzionale **"Tratte Infrastrutture: solo STATO='Nuovo'"**: se
spuntato, limita solo le tratte Infrastrutture a quelle con STATO='Nuovo';
i Pozzetti restano selezionati senza filtro, come prima.

## Novità versione 0.25 (fix blocco interfaccia sulla regola "toccati da Edifici")

Il layer Edifici può essere molto più grande di quelli usati dalle altre
regole (es. un WFS/basemap con fabbricati su tutto il territorio, non solo
sull'area di progetto): leggerlo e riproiettarlo TUTTO poteva richiedere
moltissimo tempo o restare in attesa dati dal server, con QGIS che sembrava
bloccato. Ora da Edifici si legge SOLO quello che ricade nel rettangolo che
contiene Infrastrutture + Pozzetto (più la tolleranza) — per un WFS il
filtro viene mandato al server invece di scaricare l'intero layer. In più,
cursore di attesa e interfaccia tenuta reattiva durante il calcolo.

## Novità versione 0.24 (nuova regola: tratte + pozzetti toccati da Edifici)

Nella scheda "Seleziona elementi", nuova regola **4) Tratte Infrastrutture +
Pozzetti toccati da Edifici**: imposti il layer Edifici/Fabbricati e il
pulsante seleziona, in un colpo solo, sia le tratte Infrastrutture sia i
Pozzetti che toccano/intersecano quello shape (qualsiasi TIPOLOGIA/STATO,
non solo 'Nuovo'), entro la Tolleranza già impostata nella scheda. Le due
selezioni sono indipendenti tra loro (una tratta viene selezionata anche
senza un pozzetto toccato, e viceversa) e funzionano con "Rimuovi elementi
selezionati" come le altre regole.

## Novità versione 0.23 (trovata la VERA causa di "UNIQUE constraint failed")

Il fix della v0.22 (chiudere/cancellare il file prima di riscrivere) non
bastava: l'errore tornava anche su file nuovi. La causa reale: i layer
modello (Keyplan_*.gpkg, Tavole_Inquadramento.gpkg) hanno un campo
attributo chiamato **'fid'** — la colonna chiave primaria del GeoPackage,
che QGIS espone anche come campo normale quando lo si legge come layer.
Ogni tavola generata copiava gli attributi dall'unica feature modello
selezionata, quindi **tutte** le tavole finivano con lo stesso valore in
quel campo 'fid'. Salvando su GeoPackage, GDAL riconosce un campo chiamato
proprio 'fid' come chiave primaria della tabella: con lo stesso valore
duplicato su ogni tavola, solo la prima veniva scritta e tutte le altre
fallivano con "UNIQUE constraint failed: <nome>.fid" — esattamente il
pattern "solo 1 di N scritte" visto negli errori. Ora il campo 'fid' (se
presente nel modello) viene escluso dallo schema delle tavole generate,
sia per il Keyplan che per i Poligoni di Inquadramento.

## Novità versione 0.22 (salvataggio separato Keyplan/Inquadramento + fix UNIQUE constraint)

1. **Salvataggio separato.** Il pulsante unico è diventato due pulsanti
   indipendenti — "Salva Keyplan su GeoPackage…" e "Salva Poligoni
   Inquadramento su GeoPackage…" — ciascuno con il proprio file scelto al
   momento (anche due GeoPackage o cartelle diverse), un solo layer per
   volta.
2. **Fix "UNIQUE constraint failed" nel salvataggio.** Capitava salvando
   di nuovo sullo stesso file: il layer caricato dal salvataggio
   precedente restava aperto nel progetto e teneva il GeoPackage occupato,
   così la sovrascrittura non ripartiva davvero da zero e la scrittura
   provava ad aggiungere le nuove tavole a quelle vecchie rimaste dentro,
   con lo stesso fid già usato. Ora chiude ogni altro layer che punta già
   a quel file e lo cancella prima di scrivere (o avvisa, invece di
   provarci, se si sta per salvare un layer esattamente sopra al file da
   cui è già stato caricato).

## Novità versione 0.21 (fix margine instabile + fix rigenerazione sulla rete)

1. **Tavole di inquadramento: mai più sovrapposte.** Il vecchio "Margine
   sovrapposizione" aveva un comportamento non prevedibile (numero di
   tavole non monotono al variare del margine, es. 0,01 m → 150 tavole,
   5 m → 60, 10 m → di nuovo 150): permettere overlap reale lascia sempre
   una fascia di bordo scoperta che va ritappata con altre tavole, in modo
   non lineare. Ora le Tavole di inquadramento seguono la stessa regola già
   in uso per il Keyplan: MAI sovrapposte, con un "Margine di sicurezza
   (gap)" opzionale al posto del vecchio margine.
2. **Rigenerazione "solo sulla rete" corretta.** Rimosso il campo Pozzetti
   (semplificazione). Corretto il bug per cui la rigenerazione falliva del
   tutto (Keyplan) o si fermava dopo 1-2 tavole (Tavole di inquadramento):
   la soglia di arresto, pensata per coprire un'area piena, era troppo alta
   per un corridoio stretto attorno alla sola infrastruttura nuova. Le
   dimensioni delle tavole ora si leggono direttamente dai layer modello
   (Keyplan/Inquadramento A e B), non dalle tavole già generate.

## Novità versione 0.20 (rigenerazione mirata sulla rete + salva con stile automatico)

1. **"Ottimizza" ora rigenera davvero la copertura, non sposta solo le
   tavole.** Butta via la copertura esistente e ne crea una nuova usando
   come area da coprire solo un intorno (raggio impostabile, default 0,5 m)
   delle **Infrastrutture Nuove** (STATO='Nuovo') ed eventualmente dei
   **Pozzetti** (nuovo campo opzionale nella stessa sezione), invece
   dell'intero poligono ARLO AREA. Le tavole si posizionano quasi a
   contatto tra loro solo dove c'è davvero rete da documentare — il Keyplan
   resta sempre senza sovrapposizioni — e il numero di tavole scende
   drasticamente, anche lasciando scoperte le parti di ARLO AREA senza
   infrastruttura nuova (voluto).
2. **Nuovo pulsante "Salva Keyplan / Poligoni Inquadramento su
   GeoPackage…".** Scrive i layer temporanei su un GeoPackage a scelta,
   ricarica i layer da disco al posto delle copie in RAM e applica in
   automatico lo stile allegato al plugin (uno per Keyplan, uno per
   Poligoni Inquadramento) — nessuno stile da reimpostare a mano ogni volta.

## Novità versione 0.19 (Keyplan senza sovrapposizioni + margine tavole editabile <0,1 m + potatura ridondanti)

1. **Il Keyplan non genera più tavole sovrapposte.** Ogni tavola candidata
   che si sovrapporrebbe (oltre una tolleranza numerica minima) a una già
   piazzata viene scartata; se non c'è spazio per una tavola intera senza
   sovrapporsi, resta un piccolo residuo scoperto invece di forzare la
   sovrapposizione. Il vecchio campo "Margine sovrapposizione" del Keyplan è
   diventato **"Margine di sicurezza (gap)"**: con 0 le tavole restano al
   massimo a contatto bordo a bordo, con un valore positivo restano pure
   staccate. Anche **"Ottimizza Keyplan sulle infrastrutture nuove"** ora
   verifica, tavola per tavola, che lo spostamento non ne crei una: se serve
   riduce lo spostamento o lascia la tavola ferma.
2. **Il margine di sovrapposizione delle Tavole di inquadramento è editabile
   con precisione al centimetro** (es. 0,02 m), non più solo a decimi di
   metro: un margine minimo ma non nullo evita micro-fessure di area
   scoperta dovute agli arrotondamenti, senza dover generare una tavola
   intera solo per coprirle.
3. **Potatura automatica delle tavole ridondanti.** Dopo ogni generazione
   (Keyplan e Tavole di inquadramento), le tavole il cui contributo di area
   non già coperta dalle vicine è trascurabile vengono rimosse in automatico,
   per ridurre il numero di tavole utili finali senza mai riaprire un buco
   che prima era coperto.

## Novità versione 0.18 (copertura a forma libera + Ottimizza per-tavola)

**Causa reale del problema "griglia limitata a un angolo dell'area":** il
layer ARLO AREA può contenere più feature separate e non adiacenti (aree
armadio sparse su un territorio esteso, non un'unica forma continua). Il
bounding box RETTANGOLARE dell'unione di quelle feature include anche tutto
il vuoto tra una zona e l'altra — ed era quel rettangolo, troppo grande e
per lo più vuoto, ad essere usato per pianificare la griglia.

1. **Le feature di ARLO AREA vengono ora FUSE** in un'unica geometria reale
   (anche multi-parte se non adiacenti), invece di usarne solo il bounding
   box.
2. **Le tavole (Keyplan e Tavole di inquadramento) non sono più su una
   griglia rettangolare rigida.** Vengono posizionate liberamente, una alla
   volta, sul "buco" scoperto più grande rimasto — come mettere delle toppe
   sui buchi di un tessuto — così seguono il contorno reale anche per forme
   strette e serpeggianti lungo le strade, invece di riempire un rettangolo
   pieno di spazio inutile.
3. **Il pulsante "Ottimizza" ora sposta OGNI tavola individualmente**, non
   più tutta la griglia in blocco: ciascuna tavola si centra sul tratto di
   Infrastruttura NUOVA (STATO='Nuovo') più vicino al proprio centro
   attuale. Rimossi dalla sezione "Ottimizza" i campi Armadio Ottico e
   Pozzetto (non più usati per questo scopo): resta solo Infrastrutture.
4. **"Diagnostica estensione" ora mostra anche**: l'area reale della forma
   fusa, quante parti separate ha, e di quanto il bounding box la
   sovrastima (utile per capire se conviene la copertura a forma libera).

## Novità versione 0.17 (fix selezione automatica layer ARLO AREA)

1. **Bug critico corretto: la griglia poteva essere calcolata sul layer
   sbagliato.** `refresh_layers()` (che gira ogni volta che apri il
   dialogo) assegnava il layer atteso per nome (es. "ARLO AREA") SOLO se
   il combo risultava vuoto (`currentLayer() is None`). Ma un
   `QgsMapLayerComboBox` obbligatorio (`allow_empty=False`, usato per ARLO
   AREA dal fix v0.16) seleziona DA SOLO un layer qualsiasi compatibile non
   appena il progetto lo contiene: il combo risultava quindi "valorizzato"
   con un layer diverso (es. un modello Keyplan) senza che la correzione
   automatica per nome scattasse più. Il risultato visibile: la griglia
   veniva generata sull'estensione minuscola del layer sbagliato invece che
   su tutta l'area ARLO AREA, con solo poche tavole in un angolo del
   progetto. Ora il layer con il nome atteso ha SEMPRE la precedenza (se
   esiste nel progetto), ad ogni apertura del dialogo — anche se il combo
   aveva già un valore diverso.
2. **Consiglio pratico:** dopo aver aggiornato il plugin, usa "Diagnostica
   estensione" prima di generare la griglia: il messaggio riporta il nome
   esatto del layer usato e quante feature contribuiscono all'estensione,
   così puoi verificare a colpo d'occhio che sia davvero ARLO AREA.

## Novità versione 0.16 (fix "Estensione vuota", nuovo pulsante Ottimizza)

1. **Estensione griglia Keyplan/Tavole basata SOLO su ARLO AREA.** Prima
   l'estensione era l'unione di ARLO AREA + Armadio Ottico + Infrastrutture
   + Pozzetto: bastava un filtro attivo, un layer senza feature valide o un
   problema di trasformazione CRS su UNO SOLO di questi ultimi tre per
   rompere l'unione e ottenere "Estensione vuota" (o un'estensione più
   piccola del reale) anche con ARLO AREA impostato e popolato
   correttamente. Ora l'estensione è semplicemente il bounding box di ARLO
   AREA (il poligono con tutte le aree armadio da coprire), allargato del
   margine impostato: un solo layer, un solo punto di fallimento, facile da
   verificare con "Diagnostica estensione".
2. **Popup "Estensione vuota" ora spiega subito la causa.** Prima del
   generico "Nessun elemento nei layer selezionati", ora dice se manca il
   layer ARLO AREA, se il layer non ha feature, o se le feature non hanno
   una geometria valida/trasformabile — senza dover aprire "Diagnostica
   estensione" a parte per scoprirlo.
3. **Corretta l'etichetta duplicata "margine estensione".** Il campo aveva
   sia l'etichetta di riga "Margine estensione:" sia un suffisso identico
   sullo spinbox ("… m margine estensione"), risultando in un valore tipo
   "100 m margine estensione" poco chiaro. Ora l'etichetta spiega cosa fa
   il campo (buffer in metri attorno al confine ARLO AREA) e il valore
   mostra solo "100 m".
4. **Nuova sezione "Ottimizza posizionamento griglia" (opzionale).**
   Armadio Ottico, Infrastrutture e Pozzetto non servono più a calcolare
   l'estensione, ma restano utili DOPO aver generato una griglia Keyplan o
   Tavole di inquadramento: i due nuovi pulsanti "Ottimizza griglia…"
   traslano in blocco la griglia già generata (stessa forma, dimensione e
   numero di tavole) per ridurre quanti elementi di quei tre layer
   risultano tagliati a metà tra una tavola e quella adiacente, provando
   una serie di piccoli spostamenti entro il passo della griglia e
   applicando quello che lascia il minor numero di elementi "a cavallo" di
   un bordo.

## Novità versione 0.11 (fix salvataggio GeoPackage Keyplan/Tavole, nuova Regola 1b)

1. **Corretto l'errore "Impossibile salvare... UNIQUE constraint failed:
   ...fid"** che si presentava rigenerando la griglia Keyplan o la griglia
   Tavole di inquadramento su layer GeoPackage. La causa: cancellare tutte
   le feature e aggiungerne di nuove nella STESSA sessione di editing fa sì
   che, su GeoPackage, il fid appena cancellato non sia ancora "libero" per
   il nuovo insert finché la cancellazione non viene commitata. Ora la
   cancellazione viene sempre commitata subito, e solo dopo si apre una
   nuova sessione di editing per gli inserimenti.
2. **Nuova Regola 1b — "Tratte a contatto diretto col Civico (qualsiasi
   tipologia/stato) + pozzetto successivo".** Regola separata e indipendente
   dalla Regola 1: seleziona OGNI tratta Infrastrutture, di qualunque
   TIPOLOGIA e STATO, che tocchi/intersechi direttamente un Civico su almeno
   un estremo, più il Pozzetto vicino all'estremo opposto della stessa
   tratta ("il pozzetto subito dopo"). Non segue la catena e non si ferma a
   un PTE come la Regola 1: serve a coprire i casi che la Regola 1 (limitata
   a STATO='Nuovo' e alla logica di catena/PTE) lascia fuori. Si AGGIUNGE
   alla selezione corrente (non la sostituisce), quindi si può usare insieme
   alla Regola 1 prima di passare a "Rimuovi elementi selezionati".

## Novità versione 0.10 (Regola 1 più permissiva, barriera PTE corretta, mix tavole Keyplan A/B, bugfix griglia/prestazioni/robustezza)

0. **Keyplan e Tavole di inquadramento — forma/dimensione non più impostabili
   a mano, e possibilità di mixare due modelli.** Rimossi i campi manuali
   Larghezza/Altezza/Forma per le Tavole di inquadramento: la forma e la
   dimensione dei riquadri derivano SEMPRE da una tavola modello reale
   (oggetto da posizionare sul progetto), esattamente come già avveniva per
   il Keyplan. È ora possibile impostare, oltre al modello A, anche un
   modello B opzionale (es. una tavola quadrata e una rettangolare da due
   GeoPackage diversi): quando è impostato anche B, il plugin valuta da solo
   se conviene usare solo A, solo B, oppure MIXARE le due forme (B usato solo
   per l'ultima fascia di colonna o riga, dove si adatta meglio allo spazio
   residuo) — sceglie sempre l'opzione che lascia meno area di tavole fuori
   dall'area di progetto, e riporta la scelta fatta nel log. La stessa
   coppia di modelli A/B e lo stesso automatismo valgono sia per "Genera
   griglia Keyplan" sia per "Genera griglia tavole" (Poligoni di
   Inquadramento), che restano quindi sempre coerenti fra loro.
1. **Regola 1 — selezionate anche le tratte che non hanno ancora raggiunto
   un PTE.** Prima, oltre alla tratta che tocca direttamente il Civico,
   tutte le altre tratte della catena venivano incluse SOLO se la catena
   arrivava effettivamente a un ROE PTE (altrimenti restava selezionata
   solo la prima tratta sul Civico). Ora l'intera catena collegata al
   Civico viene selezionata (pozzetti compresi), anche se non raggiunge
   ancora un PTE, con le stesse eccezioni di sempre: tratte che corrono
   lungo il Cavo Ottico restano escluse, e l'intera catena resta esclusa
   se arriva a un PTE Light Diramatore condiviso con un altro PTE tramite
   il Cavo Raccordo.
2. **Regola 1 — corretta la verifica di barriera al ROE PTE.** La catena si
   fermava a un PTE se ne veniva trovato uno entro tolleranza vicino a UNO
   dei due estremi che si toccano; con tolleranze elevate questo poteva
   generare falsi positivi (un PTE vicino ma non realmente al nodo
   condiviso). Ora viene verificato che il PTE sia entro tolleranza da
   ENTRAMBI gli estremi, cioè che sia davvero il punto di giunzione.
3. **Griglie Keyplan e Tavole di inquadramento — corretto il calcolo delle
   tavole in eccesso.** Il ciclo while precedente poteva generare una riga o
   colonna aggiuntiva quasi interamente fuori dall'area di progetto quando
   quest'ultima superava di poco la dimensione della tavola modello. Il
   numero di righe/colonne è ora calcolato in anticipo con `math.ceil()`
   (o con la stessa logica di valutazione usata per il mix A/B).
4. **Salvataggi falliti ora mostrano il motivo.** Tutti i punti in cui il
   plugin salva modifiche (rimozione elementi, griglia Keyplan, griglia
   tavole, coni fotografici, aggiornamento LUNGHEZZA) mostrano ora il
   dettaglio di `layer.commitErrors()` quando il commit fallisce, invece
   del solo esito booleano.
5. **Prestazioni.** `_unione_layer()` usa `QgsGeometry.unaryUnion()` invece
   di un ciclo di `combine()` (molto più veloce su layer con molte feature);
   `_trova_pozzetti()` non ricrea più due volte la stessa geometria punto
   per ogni pozzetto.
6. **Robustezza.** Le trasformazioni di CRS non interrompono più il plugin
   in caso di errore (vengono ignorate con un avviso in console); le
   geometrie non valide vengono "riparate" (`makeValid()`) prima di calcoli
   di intersezione; `_endpoints()` ignora esplicitamente geometrie non
   lineari invece di affidarsi implicitamente ad `asPolyline()`.

## Novità versione 0.9 (Aerea inclusa in Regola 1, Cavo Raccordo, Regola 3 su Aerea, griglie Keyplan/Inquadramento reali)

1. **Regola 1 — Aerea sempre inclusa.** Rimossa l'opzione "Escludi
   TIPOLOGIA='Aerea'": le tratte aeree con STATO='Nuovo' partecipano ora
   sempre alla ricerca delle catene Civico → PTE, come tutte le altre.
2. **Regola 1 — nuovo layer "Cavo Raccordo" e nuova esclusione sul PTE
   Light Diramatore.** Se la catena selezionata arriva a un ROE PTE di tipo
   "PTE Light Diramatore" e quel punto risulta collegato, tramite una tratta
   dello shape Cavo Raccordo (bretelle tra PTE), a un ALTRO ROE PTE di
   qualsiasi tipologia, si tratta di un raccordo condiviso con un altro
   permesso: l'intera catena e i pozzetti compresi NON vengono selezionati.
   Il log di Regola 1 riporta il numero di catene escluse per questo motivo.
3. **Regola 3 — le tratte Aerea 'Nuovo' non escludono più il pozzetto.**
   Un Pozzetto che tocca solo infrastruttura esistente più eventuali tratte
   Aerea con STATO='Nuovo' viene comunque selezionato: l'Aerea 'Nuovo' non è
   più trattata come "nuova interrata" ai fini di questa regola.
4. **Keyplan — griglia reale invece di una singola geometria stirata.**
   "Posiziona Keyplan" generava un'unica geometria stirata sull'intera
   estensione del progetto, deformando la tavola. Ora il pulsante ("Genera
   griglia Keyplan sull'area di progetto") prende la feature presente nel
   layer (selezionata, o la prima) come MODELLO — stessa forma e dimensione
   reale a scala fissa, es. da Keyplan_Quadrato.gpkg o
   Keyplan_Rettangolare.gpkg — e genera una griglia di copie traslate (mai
   deformate) che insieme coprono per intero Armadio Ottico, Pozzetti e
   Infrastrutture. Il layer viene sovrascritto con le tavole numerate (campo
   "Numero Tav" se presente).
5. **Tavole di inquadramento — coerenti con la griglia Keyplan.** Il nuovo
   checkbox "Usa le dimensioni reali del layer Keyplan modello" (attivo di
   default) fa sì che ogni riquadro della griglia di inquadramento abbia le
   stesse dimensioni reali della tavola Keyplan, invece dei soli valori
   manuali Larghezza/Altezza (che restano disponibili come alternativa/
   fallback se il layer Keyplan è vuoto o il checkbox è disattivato).

## Novità versione 0.8 (PTE Light come gli altri PTE, tab riorganizzati, Keyplan automatico)

1. **Regola 1 corretta sui PTE** — un ROE PTE, di QUALSIASI tipologia
   (incluso "PTE Light Diramatore"), ora funge sempre da **barriera** nella
   ricostruzione della catena Civico→PTE: la catena selezionata si ferma nel
   punto in cui incontra un PTE e non prosegue oltre, verso un eventuale PTE
   successivo condiviso. Il checkbox dedicato ("Ferma la catena a qualsiasi
   ROE PTE...") resta disponibile per disattivare la barriera se necessario,
   ma di default è attivo e il PTE Light è trattato esattamente come gli altri.
2. **Pozzetti esclusi anche se sul Cavo Ottico** — oltre al pozzetto sede di
   PTE, la Regola 1 torna a escludere anche i pozzetti che ricadono sul Cavo
   Ottico (dorsale condivisa), comportamento che si era perso in una versione
   precedente.
3. **Scheda "Shape di consegna" spostata per ultima.**
4. **Shape "ARLO AREA" sostituito con "Armadio Ottico"** come layer da unire
   nei 3 shape di consegna (ARMADI_FOTO, SCAVI_STRADE, POZZETTI_STRADE).
5. **Nuovi checkbox opzionali** per scegliere quali shape includere nel join
   di ogni shape di consegna (Armadio Ottico / Stradario): l'automatismo resta
   attivo di default, i checkbox servono solo per escludere volutamente un
   layer in caso di problemi.
6. **Scheda "Keyplan e tavole" riscritta come semplice posizionatore
   automatico**: nessun collegamento a layout di stampa (.qpt), nessun
   riferimento a elementi mappa nei layout. Il pulsante "Posiziona Keyplan"
   sposta/ridimensiona direttamente la geometria dello shape (o layer
   GeoPackage) Keyplan sopra l'area di progetto (Armadio Ottico, Pozzetti e
   Infrastrutture); "Genera griglia tavole" crea allo stesso modo i riquadri
   di inquadramento numerati.
7. **Scheda "Punti di ripresa" semplificata**: rimossa la funzione (non
   funzionante) di posizionamento coni accanto alle aree ARLO. Resta solo la
   generazione dei coni davanti agli Armadi Ottici (shape "Armadio Ottico"),
   perpendicolari al muro più vicino.

## Novità versione 0.5 (PTE Light: solo tratte sul civico + esclusioni pozzetto)

Due modifiche su richiesta, basate sul caso reale del cavo dorsale condiviso:

1. **Cambiato il comportamento sul PTE "Light Diramatore"** — prima, se una
   catena Civico↔PTE arrivava a un PTE di tipo "PTE Light Diramatore" (raccordo
   condiviso tra più civici), l'intera catena veniva scartata (nessuna
   selezione). Ora, in quel caso, si seleziona comunque qualcosa ma **solo le
   tratte del gruppo che toccano direttamente il Civico** — non l'intero
   percorso fino al PTE, che potrebbe essere condiviso con altri permessi.
   Il checkbox si chiama ora "Se il PTE è 'PTE Light Diramatore' ... seleziona
   SOLO le tratte toccate direttamente dal Civico" (attivo di default).
2. **Pozzetto sede di PTE escluso sempre** — un Pozzetto la cui posizione
   coincide con un punto ROE PTE (entro tolleranza) non viene più selezionato
   dalla Regola 1: è la sede fisica del PTE, non un pozzetto di passaggio da
   rimuovere.
3. **Pozzetto sul CAVO OTTICO escluso** — se il layer Cavo ottico è impostato
   (stesso layer/tolleranza già usati per escludere le tratte sulla dorsale),
   anche i Pozzetto che ricadono su di esso vengono esclusi dalla selezione,
   per lo stesso motivo: fanno parte della dorsale condivisa.

Il log della Regola 1 ora riporta separatamente: catene trovate, catene
ridotte per PTE light, tratte escluse per sovrapposizione al cavo ottico,
pozzetti esclusi perché sede-PTE e pozzetti esclusi perché sul cavo ottico.

## Novità versione 0.3 (fix basati sui tuoi shapefile reali)

Analizzando i tuoi shapefile ho trovato due problemi concreti sui tuoi dati:

1. **685 delle 1771 tratte INFRASTRUTTURE con STATO='Nuovo' sono TIPOLOGIA='Aerea'**
   (non interrate). Il tuo workflow riguarda esplicitamente le nuove interrate, quindi
   la Regola 1 ora esclude di default le tratte aeree dalla ricerca di catene
   Civico↔PTE (checkbox "Escludi tratte aeree", disattivabile se serve).
2. **I tuoi shapefile sono in CRS geografico (gradi, WGS84)**, non in un sistema
   metrico. La tolleranza è sempre nelle unità del CRS di **progetto**: se il
   progetto QGIS resta in gradi, 0.05 equivale a ~5 km e non 5 cm. Ho aggiunto un
   avviso diretto nella scheda Pulizia bozza; se i tuoi progetti sono in gradi,
   **imposta il CRS di progetto su un sistema metrico proiettato** (per l'area di
   Podenzano/Piacenza va bene UTM 32N — EPSG:32632) prima di usare le regole,
   altrimenti la tolleranza non ha senso in metri.

Ho anche sostituito il doppio ciclo O(n²) della Regola 1 con un indice spaziale
sugli estremi delle tratte: con ~1800 tratte "Nuovo" come nei tuoi dati, il doppio
ciclo naive sarebbe stato lento; ora la ricerca delle catene scala molto meglio.

## Novità versione 0.2 (fix Regola 1 + robustezza CRS)

**Problema risolto:** nel workflow reale il percorso tra CIVICO e ROE PTE non è
quasi mai una singola linea, ma è spezzato in più segmenti con vertici
intermedi. La vecchia Regola 1 cercava una tratta con **entrambi** gli estremi
che toccavano direttamente Civico e PTE, quindi le tratte intermedie non
venivano mai trovate e la selezione restava vuota.

**Come funziona ora:** la Regola 1 costruisce le **catene** di tratte
Infrastrutture con `STATO = 'Nuovo'` collegate tra loro vertice-a-vertice
(entro la tolleranza impostata), e seleziona l'intera catena se, nel
complesso, tocca un Civico da un lato e un ROE PTE dall'altro. I Pozzetto
lungo il tracciato vengono trovati con distanza punto-linea, non solo agli
estremi — invariato rispetto a prima.

**Robustezza CRS:** tutte le regole (1, 2, 3) e anche l'analisi spaziale
generica ora trasformano le geometrie nel CRS di progetto prima di calcolare
qualunque distanza. Se i layer coinvolti hanno CRS diversi, il confronto
funziona comunque invece di fallire silenziosamente restituendo zero
risultati (probabile causa del "seleziona pozzetti non funziona" segnalato).

**Nuovo pulsante "Diagnostica tolleranza"** nella scheda Pulizia bozza: calcola
le distanze minime reali tra Infrastrutture↔Civici, Infrastrutture↔PTE e
Pozzetto↔tratte. Usalo prima di lanciare le regole se sospetti che la
tolleranza di default (0.05 m) sia troppo bassa per il tuo dato.

---

Plugin per la gestione unificata dei permessi FTTH (scavi, occupazione suolo
pubblico, attraversamenti), con due strumenti principali:

1. **Analisi spaziale**
   - Intersezione (con buffer opzionale) tra il layer permessi e un layer di
     riferimento qualsiasi (confini comunali, aree di cantiere, vincoli, ecc.)
   - Rilevamento automatico delle sovrapposizioni tra permessi dello stesso
     layer (utile per individuare conflitti, es. scavi che si intersecano)
   - Gli elementi trovati vengono selezionati ed evidenziati in mappa

2. **Seleziona e rimuovi**
   - Selezione elementi tramite espressione QGIS (editor espressioni
     integrato, con suggerimento campi/funzioni)
   - Esempi di espressioni utilizzabili:
     - `stato = 'scaduto'`
     - `tipo_permesso = 'attraversamento' AND stato = 'respinto'`
     - `data_scadenza < now()`
   - Rimozione guidata degli elementi selezionati, con richiesta di conferma
     e gestione della modalità di editing (avvio/commit automatico se il
     layer non è già in editing)

## Installazione

1. Comprimi la cartella `ftth_permessi` in un file `.zip`
   (la cartella deve stare alla radice dello zip, es. `ftth_permessi/metadata.txt`)
2. In QGIS: **Plugin → Gestisci e installa plugin → Installa da ZIP**
3. Seleziona lo zip creato e conferma
4. Il plugin comparirà in toolbar e nel menu **Plugin → FTTH Permessi**

In alternativa, per lo sviluppo: copia la cartella `ftth_permessi` dentro la
cartella plugin di QGIS:

- Windows: `C:\Users\<utente>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
- Linux/Mac: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

Poi attivalo da **Plugin → Gestisci e installa plugin → Installati**.

## Struttura del layer permessi (suggerita)

Il plugin funziona con qualsiasi struttura di attributi, ma per sfruttare al
meglio gli esempi di espressione è utile avere campi tipo:

| Campo             | Tipo   | Esempio                          |
|--------------------|--------|-----------------------------------|
| tipo_permesso      | testo  | scavo / occupazione_suolo / attraversamento |
| stato              | testo  | richiesto / approvato / respinto / scaduto |
| comune              | testo  | Roma                              |
| data_presentazione  | data   | 2026-03-01                        |
| data_scadenza       | data   | 2026-09-01                        |
| ente_competente     | testo  | Comune di Roma – Dip. Mobilità   |

## Note tecniche

- Compatibile con QGIS 3.16+
- Il rilevamento sovrapposizioni usa un indice spaziale (`QgsSpatialIndex`)
  per restare performante anche su layer con molti elementi
- La rimozione elimina le feature dalla sorgente dati reale (shapefile,
  GeoPackage, PostGIS, ecc.): usa con attenzione e valuta di lavorare su una
  copia del layer per i test iniziali

## Prossimi sviluppi possibili

- Form dedicato per l'inserimento di un nuovo permesso con validazione campi
- Generazione automatica di lettere/report di richiesta permesso (docx/pdf)
- Notifiche/evidenziazione automatica dei permessi in scadenza all'apertura
  del progetto
- Storico stati con log delle modifiche
