# -*- coding: utf-8 -*-
"""Logica delle schede «Istanze Soprintendenza» e «Istanze Parchi / Natura 2000».

Le aree vincolate (SITAP art. 136/142, parchi EUAP, siti Natura 2000, o un layer
dell'utente) prendono il posto dei corsi d'acqua della scheda Acque: il motore
delle interferenze e' lo stesso (ftth_acque.trova_interferenze_acque con
`zone`), cosi' metri, coordinate «da/a», vie, etichette, tavole e modelli Word
sono quelli gia' collaudati. Qui c'e' solo cio' che cambia:

- da dove vengono le aree e come si chiamano in legenda;
- Soprintendenza: quali lavori si AUTORIZZANO e quali si COMUNICANO soltanto
  (art. 40 c. 4 DL 77/2021: mini e microtrincea, 15 giorni di preavviso);
- Natura 2000: la regola dei 200 m per via (art. 40 c. 3-bis DL 77/2021, come
  modificato dal DL 19/2026 conv. L. 50/2026): sotto i 200 m di scavo niente
  VIncA, basta l'autodichiarazione di esclusione con 30 giorni di preavviso;
  da 200 m in su serve lo screening di incidenza (Format proponente);
- i testi di oggetto e relazione e i documenti in piu' (Relazione
  paesaggistica semplificata, non parentela, autodichiarazione VIncA, Format).

Niente QGIS qui: geometrie shapely in WGS84, cosi' si prova con i test.
"""
import re
from dataclasses import dataclass, field

try:
    from . import ftth_acque as A
except ImportError:  # test fuori dal pacchetto
    import ftth_acque as A

SCHEDA_SOPR = "soprintendenza"
SCHEDA_PARCHI = "parchi"

LETTERE_142 = {
    "a": "territori costieri",
    "b": "territori contermini ai laghi",
    "c": "fiumi, torrenti, corsi d'acqua",
    "d": "montagne oltre i 1600/1200 m",
    "e": "ghiacciai e circhi glaciali",
    "f": "parchi e riserve",
    "g": "territori coperti da foreste e boschi",
    "h": "università agrarie e usi civici",
    "i": "zone umide",
    "l": "vulcani",
    "m": "zone di interesse archeologico",
}

# tipo di area -> (scheda, voce di legenda breve)
TIPI_AREA = {
    "art136": (SCHEDA_SOPR, "Art. 136 D.Lgs. 42/2004 - aree di notevole interesse pubblico"),
    "unesco": (SCHEDA_SOPR, "Sito UNESCO"),
    "centro_storico": (SCHEDA_SOPR, "Centro storico"),
    "bene_culturale": (SCHEDA_SOPR, "Bene culturale (art. 10 D.Lgs. 42/2004)"),
    "archeologia": (SCHEDA_SOPR, "Area di interesse archeologico"),
    "parco": (SCHEDA_PARCHI, "Area protetta (L. 394/1991)"),
    "natura2000": (SCHEDA_PARCHI, "Sito Rete Natura 2000"),
}
for _l, _d in LETTERE_142.items():
    TIPI_AREA["art142" + _l] = (SCHEDA_SOPR, "Art. 142 lett. %s) D.Lgs. 42/2004 - %s" % (_l, _d))

# colori in tavola (RGB) per tipo: tratteggio del vincolo
COLORI_AREA = {
    # toni smorzati da tavola urbanistica (bordeaux, blu acciaio, oliva, siena)
    "art136": (140, 45, 45), "art142a": (55, 100, 150), "art142b": (60, 120, 150),
    "art142c": (45, 95, 150), "art142g": (85, 110, 50), "art142i": (40, 120, 115),
    "art142f": (95, 120, 40), "art142m": (140, 95, 45), "unesco": (110, 60, 120),
    "centro_storico": (150, 80, 40), "bene_culturale": (125, 55, 85),
    "archeologia": (140, 95, 45), "parco": (55, 105, 55), "natura2000": (35, 115, 90),
    # scheda Istanze Strade: sede e fascia di rispetto nella PL
    "strada_sede": (240, 130, 0), "strada_fascia": (200, 0, 0),
}

# Soprintendenza: lavori che si autorizzano e lavori che si comunicano soltanto
TECNICHE_COMUNICAZIONE = ("minitrincea", "microtrincea")


def giorni_comunicazione(metri_scavo) -> int:
    """Preavviso della comunicazione alla Soprintendenza (art. 40 c. 4 DL
    77/2021): 15 giorni, 8 se lo scavo è inferiore a 200 m."""
    return 8 if (metri_scavo or 0) < 200 else 15
REGIMI = {
    "comunicazione": "Comunicazione (art. 40 c. 4 DL 77/2021, 15 giorni; 8 sotto i 200 m)",
    "autorizzazione": "Autorizzazione paesaggistica",
}

# Natura 2000: soglia della regola per via
SOGLIA_VINCA_M = 200
ESITI_VINCA = {
    "esonero": "Esclusione VIncA (< 200 m): autodichiarazione, 30 giorni",
    "vinca": "Screening VIncA (>= 200 m): Format proponente",
}
NORMA_ESONERO = ("art. 40, comma 3-bis, del D.L. 77/2021, convertito dalla L. 108/2021, come "
                 "modificato dal D.L. 19/2026 convertito con modificazioni dalla L. 50/2026")


@dataclass
class AreaVincolo:
    tipo: str                         # chiave di TIPI_AREA
    nome: str = ""                    # denominazione (parco, sito, decreto...)
    codice: str = ""                  # EUAP, IT3320038, codice vincolo
    geom: object = None               # shapely (Multi)Polygon WGS84
    fonte: str = ""
    ente_tipo: str = ""               # soprintendenza | parco | natura2000
    ente_nome: str = ""
    includi: bool = True
    sottotipo: str = ""               # Natura 2000: SIC/ZSC o ZPS

    def scheda(self) -> str:
        return TIPI_AREA.get(self.tipo, (SCHEDA_SOPR, ""))[0]

    def voce(self) -> str:
        """Voce di legenda e nome nell'elenco: per parchi e siti con il nome."""
        if self.tipo == "natura2000":
            return "Rete Natura 2000 %s %s %s" % (self.sottotipo or "", self.codice or "",
                                                  self.nome or "")
        if self.tipo == "parco":
            return "Area protetta %s%s" % (self.nome or "", (" (%s)" % self.codice)
                                           if self.codice else "")
        base = TIPI_AREA.get(self.tipo, (None, self.tipo))[1]
        if self.nome and self.tipo in ("art136", "unesco", "centro_storico", "bene_culturale"):
            return "%s - %s" % (base, self.nome)
        return base

    def chiave(self) -> tuple:
        return (self.tipo, self.codice or "", (self.nome or "").lower())


def voce_pulita(v: str) -> str:
    return " ".join((v or "").split())


# --------------------------------------------------------------------------- #
#  Aree dallo screening (geometrie [(etichetta, feature GeoJSON)])
# --------------------------------------------------------------------------- #
def tipo_da_etichetta(etichetta: str) -> str:
    """Tipo di area dall'etichetta che lo screening mette alle geometrie."""
    e = (etichetta or "").lower()
    if e.startswith("natura 2000"):
        return "natura2000"
    if e.startswith("parco"):
        return "parco"
    if "unesco" in e:
        return "unesco"
    if "art. 136" in e or "art.136" in e or "notevole interesse" in e:
        return "art136"
    m = re.search(r"lett\.?\s*([a-m])\b", e)
    if m and ("142" in e or "fascia" in e or "boscat" in e):
        return "art142" + m.group(1)
    if "costier" in e:
        return "art142a"
    if "fiumi" in e or "corsi d'acqua" in e:
        return "art142c"
    if "bosc" in e:
        return "art142g"
    if "umid" in e:
        return "art142i"
    return ""


def aree_da_geometrie(geometrie: list, fonte: str = "") -> list:
    """[(etichetta, feature)] dello screening -> [AreaVincolo], unendo i
    poligoni con stesso tipo, codice e nome (i vincoli arrivano a pezzi)."""
    from shapely.geometry import shape
    from shapely.ops import unary_union
    gruppi = {}
    for etichetta, feat in geometrie or []:
        tipo = tipo_da_etichetta(etichetta)
        if not tipo:
            continue
        try:
            g = shape(feat.get("geometry"))
            if not g.is_valid:
                g = g.buffer(0)
        except Exception:  # noqa: BLE001
            continue
        if g.is_empty or g.geom_type not in ("Polygon", "MultiPolygon", "GeometryCollection"):
            continue
        if g.geom_type == "GeometryCollection":
            g = unary_union([p for p in g.geoms if p.geom_type in ("Polygon", "MultiPolygon")])
            if g.is_empty:
                continue
        p = feat.get("properties") or {}
        codice = str(p.get("codice") or "").strip()
        nome = str(p.get("nome") or "").strip()
        sotto = ""
        if tipo == "natura2000":
            sotto = etichetta.split("—")[-1].strip() if "—" in etichetta else ""
        if tipo == "parco" and not nome and "—" in etichetta:
            nome = etichetta.split("—", 1)[1].strip()
        k = (tipo, codice, nome.lower())
        gr = gruppi.setdefault(k, {"tipo": tipo, "codice": codice, "nome": nome,
                                   "sotto": sotto, "geoms": []})
        gr["geoms"].append(g)
    out = []
    for gr in gruppi.values():
        u = unary_union(gr["geoms"])
        if not u.is_valid:
            u = u.buffer(0)
        ente_tipo = {"parco": "parco", "natura2000": "natura2000"}.get(gr["tipo"],
                                                                      "soprintendenza")
        out.append(AreaVincolo(tipo=gr["tipo"], nome=gr["nome"], codice=gr["codice"], geom=u,
                               fonte=fonte, ente_tipo=ente_tipo, sottotipo=gr["sotto"]))
    out.sort(key=lambda a: (list(TIPI_AREA).index(a.tipo) if a.tipo in TIPI_AREA else 99,
                            a.codice, a.nome))
    return out


def metri_rete_in_area(area, tratte_wgs: list) -> float:
    """Metri di rete di progetto dentro l'area (per l'elenco delle aree)."""
    from shapely.ops import unary_union
    if area.geom is None or not tratte_wgs:
        return 0.0
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    c = area.geom.centroid
    pr = rfi._Proiezione(c.x, c.y)
    zona = pr.avanti(area.geom)
    if not zona.is_valid:
        zona = zona.buffer(0)
    tot = 0.0
    for g in tratte_wgs:
        if g is None or g.is_empty:
            continue
        gm = pr.avanti(g)
        if gm.intersects(zona):
            tot += gm.intersection(zona).length
    return round(tot, 0)


# --------------------------------------------------------------------------- #
#  Zone per il motore delle interferenze
# --------------------------------------------------------------------------- #
NOME_ZONA_SOPR = "Aree sottoposte a tutela (D.Lgs. 42/2004)"


def zone_per_motore(aree: list, scheda: str, ente_nome: str = "",
                    distanza_natura: float = 0.0) -> list:
    """Aree incluse -> `zone` di ftth_acque.trova_interferenze_acque.
    Soprintendenza: UNA zona (unione dei vincoli): un ente solo, e uno scavo
    in due vincoli sovrapposti non va contato due volte. Parchi / Natura 2000:
    una zona per parco o sito (enti diversi)."""
    from shapely.ops import unary_union
    incl = [a for a in aree if a.includi and a.geom is not None and a.scheda() == scheda]
    if not incl:
        return []
    if scheda == SCHEDA_SOPR:
        return [{"nome": NOME_ZONA_SOPR, "categoria": "paesaggio",
                 "ente_tipo": "soprintendenza", "ente_nome": ente_nome,
                 "geom": unary_union([a.geom for a in incl])}]
    out = []
    for a in incl:
        out.append({"nome": a.voce(), "categoria": a.tipo, "ente_tipo": a.ente_tipo,
                    "ente_nome": a.ente_nome,
                    "geom": a.geom,
                    "distanza": distanza_natura if a.tipo == "natura2000" else 0.0})
    return out


def _geom_interferenza(i):
    """Geometria (WGS84) dei lavori dell'interferenza: scavi + punti."""
    from shapely import wkt as _wkt
    from shapely.geometry import Point
    from shapely.ops import unary_union
    parti = []
    for e in i.elementi:
        if e.get("_wkt"):
            try:
                parti.append(_wkt.loads(e["_wkt"]))
                continue
            except Exception:  # noqa: BLE001
                pass
        if e.get("tipo") in ("pozzetto", "armadio") and "lon" in e:
            parti.append(Point(e["lon"], e["lat"]))
    if not parti:
        parti = [Point(i.lon, i.lat)]
    return unary_union(parti)


def assegna_vincoli(interferenze: list, aree: list) -> None:
    """Soprintendenza: per ogni interferenza le voci dei vincoli che tocca
    (i.vincoli = [tipo]), per relazione paesaggistica e tabella."""
    for i in interferenze:
        g = _geom_interferenza(i)
        tipi = []
        for a in aree:
            if not a.includi or a.geom is None or a.scheda() != SCHEDA_SOPR:
                continue
            try:
                tocca = a.geom.buffer(0.00002).intersects(g)
            except Exception:  # noqa: BLE001
                tocca = False
            if tocca and a.tipo not in tipi:
                tipi.append(a.tipo)
        i.vincoli = tipi


# --------------------------------------------------------------------------- #
#  Soprintendenza: autorizzazione o comunicazione
# --------------------------------------------------------------------------- #
def regime_soprintendenza(i) -> str:
    """'comunicazione' se l'interferenza ha SOLO scavi in mini/microtrincea
    (art. 40 c. 4 DL 77/2021: niente autorizzazione D.Lgs. 42, comunicazione
    15 giorni prima); 'autorizzazione' se c'e' altro: trincea tradizionale,
    no-dig, pozzetti nuovi, armadi (manufatti)."""
    altri = [t for t, m in i.metri.items() if m and t not in TECNICHE_COMUNICAZIONE]
    armadi = any(e.get("tipo") == "armadio" for e in i.elementi)
    if altri or armadi or i.pozzetti:
        return "autorizzazione"
    return "comunicazione"


# --------------------------------------------------------------------------- #
#  Soprintendenza: cosa mettere nell'istanza (scelta dell'utente o proposta)
# --------------------------------------------------------------------------- #
ELEMENTI_SOPR = {
    "trincea": "Trincea tradizionale",
    "nodig": "No-dig",
    "pozzetti": "Pozzetti",
    "armadi": "Armadi (fuori terra)",
    "comunicazione": "Mini e microtrincea (si comunicano)",
}
TUTTI_ELEMENTI = frozenset(ELEMENTI_SOPR)
# vincoli in cui il punto A.15 dell'Allegato A del DPR 31/2017 (interventi nel
# sottosuolo esclusi dall'autorizzazione) NON basta: tutela archeologica
# (fatta salva dallo stesso A.15) e vincoli con decreto (prescrizioni proprie)
VINCOLI_COMBO = frozenset({"art136", "art142m", "archeologia", "bene_culturale",
                           "centro_storico", "unesco"})


def proposta_elementi(tipi) -> tuple:
    """(elementi da includere, motivo) proposti dal tipo di vincolo:
    - archeologia, art. 136, beni culturali, centri storici, UNESCO: tutto;
    - art. 142 lett. g (boschi): tutto, da togliere se gli scavi restano
      nella strada esistente (A.15 vale solo senza toccare la vegetazione);
    - altre lettere dell'art. 142: solo armadi e mini/microtrincea, perché
      scavi, no-dig e pozzetti interrati con ripristino sono esclusi (A.15);
    - nessun vincolo riconosciuto: tutto (prudenza)."""
    t = set(tipi or [])
    if t & VINCOLI_COMBO:
        return TUTTI_ELEMENTI, ("vincolo archeologico o con decreto: il punto A.15 del DPR "
                                "31/2017 non basta, si autorizzano anche scavi e pozzetti")
    if "art142g" in t:
        return TUTTI_ELEMENTI, ("boschi (art. 142 lett. g): togli scavi e pozzetti se restano "
                                "nella strada esistente senza toccare la vegetazione")
    if any(x.startswith("art142") for x in t):
        return frozenset({"armadi", "comunicazione"}), (
            "art. 142: scavi, no-dig e pozzetti interrati con ripristino sono esclusi "
            "dall'autorizzazione (DPR 31/2017, Allegato A, punto A.15)")
    return TUTTI_ELEMENTI, "vincolo non riconosciuto: si include tutto per prudenza"


def filtra_elementi(i, scelta):
    """Copia dell'interferenza con i soli elementi scelti (chiavi di
    ELEMENTI_SOPR), o None se non resta niente da presentare."""
    import dataclasses
    scelta = set(scelta)

    def _tecnica_ok(t):
        if t in TECNICHE_COMUNICAZIONE:
            return "comunicazione" in scelta
        if t in ("trincea", "nodig"):
            return t in scelta
        return True

    def _el_ok(e):
        tipo = (e.get("tipo") or "").replace("_fuori", "")
        if tipo == "scavo":
            return _tecnica_ok(e.get("tecnica"))
        if tipo == "pozzetto":
            return "pozzetti" in scelta
        if tipo == "armadio":
            return "armadi" in scelta
        return True
    metri = {t: m for t, m in i.metri.items() if _tecnica_ok(t)}
    pozz = dict(i.pozzetti) if "pozzetti" in scelta else {}
    elementi = [dict(e) for e in i.elementi if _el_ok(e)]
    resta = any(m for m in metri.values()) or any(pozz.values()) or \
        any(e.get("tipo") == "armadio" for e in elementi)
    if not resta:
        return None
    cambiata = (metri != i.metri or pozz != i.pozzetti or len(elementi) != len(i.elementi))
    j = dataclasses.replace(i, metri=metri, pozzetti=pozz, elementi=elementi,
                            note=list(i.note), etichetta="" if cambiata else i.etichetta)
    j.vincoli = list(getattr(i, "vincoli", []) or [])
    return j


def motivo_regime(i) -> str:
    parti = []
    for t, m in i.metri.items():
        if m:
            parti.append("%s %d m" % (A.TECNICA_ETICHETTA.get(t, t).lower(), m))
    if i.pozzetti:
        parti.append("%d pozzett%s" % (sum(i.pozzetti.values()),
                                       "o" if sum(i.pozzetti.values()) == 1 else "i"))
    if any(e.get("tipo") == "armadio" for e in i.elementi):
        parti.append("armadio")
    return ", ".join(parti) or "posa senza scavo"


# --------------------------------------------------------------------------- #
#  Natura 2000: regola dei 200 m per via
# --------------------------------------------------------------------------- #
def chiave_via(i) -> str:
    return (i.via or "").strip() or "Senza via (tavola %d)" % (i.tavola or i.id)


def esiti_vinca(interferenze: list, soglia: float = SOGLIA_VINCA_M) -> dict:
    """{via: (metri di scavo, 'esonero'|'vinca')} per le interferenze incluse.
    La soglia vale per via: si sommano gli scavi della stessa via."""
    metri = {}
    for i in interferenze:
        if not i.includi:
            continue
        k = chiave_via(i)
        metri[k] = metri.get(k, 0) + int(round(i.totale_metri()))
    return {k: (m, "vinca" if m >= soglia else "esonero") for k, m in metri.items()}


# --------------------------------------------------------------------------- #
#  Istanze
# --------------------------------------------------------------------------- #
def sigla_area(nome_zona: str, categoria: str, max_len: int = 26) -> str:
    """Nome breve per cartelle e file."""
    m = re.search(r"\bIT\d{7}\b", nome_zona or "")
    if categoria == "natura2000" and m:
        return "N2000 %s" % m.group(0)
    if categoria == "parco":
        n = re.sub(r"^Area protetta\s+", "", nome_zona or "")
        n = re.sub(r"\(.*?\)", "", n)
        return A._breve(n, max_len) or "PARCO"
    return "SOPRINTENDENZA"


def solo_armadi(ist, max_per: int = 2) -> bool:
    """Soprintendenza «solo elementi fuori terra»: l'istanza tiene un'interferenza
    per ARMADIO (scavi e pozzetti fuori dai conteggi di relazione e documenti) e
    le tavole hanno al massimo `max_per` armadi, uno per foto. Le interferenze
    originali restano in ist.interferenze_pl: la planimetria mostra comunque
    l'armadio con il suo scavo e il suo pozzetto. False se non ci sono armadi."""
    import dataclasses
    nuove = []
    for i in ist.interferenze:
        for e in i.elementi:
            if e.get("tipo") != "armadio":
                continue
            j = dataclasses.replace(
                i, metri={}, pozzetti={}, elementi=[dict(e)], note=list(i.note),
                lon=e.get("lon", i.lon), lat=e.get("lat", i.lat), etichetta="")
            j.vincoli = list(getattr(i, "vincoli", []) or [])
            j.originale = i
            nuove.append(j)
    if not nuove:
        return False
    for n, j in enumerate(nuove, 1):
        j.id = n
    # in planimetria la rete delle sole interferenze con un armadio
    ist.interferenze_pl = [i for i in ist.interferenze
                           if any(e.get("tipo") == "armadio" for e in i.elementi)]
    ist.solo_armadi = True
    ist.tavole = A.tavole_per_zona(nuove, max_per=max_per)
    ist.interferenze = [j for t in ist.tavole for j in t]
    return True


def raggruppa_istanze_vincoli(interferenze: list, comune: str, scheda: str,
                              soglia_vinca: float = SOGLIA_VINCA_M) -> list:
    """Istanze della scheda:
    - Soprintendenza: una per Soprintendenza (ente), con tutte le aree;
    - Parco: una per area protetta;
    - Natura 2000: per sito, le vie con >= 200 m di scavo in una istanza
      «VINCA» (screening) e quelle sotto in una «ESONERO» (autodichiarazione).
    Ogni istanza ha .scheda e .esito ('' | 'vinca' | 'esonero')."""
    gruppi = {}
    for i in interferenze:
        if not i.includi:
            continue
        if scheda == SCHEDA_SOPR:
            k = ("soprintendenza", (i.ente_nome or "").strip(), "")
        else:
            k = (i.categoria, (i.ente_nome or "").strip(), i.corso)
        gruppi.setdefault(k, []).append(i)
    istanze = []
    n = 0
    base_c = (comune or "COMUNE").upper()
    for k, lst in sorted(gruppi.items()):
        if k[0] == "natura2000":
            esiti = esiti_vinca(lst, soglia_vinca)
            parti = [("vinca", [i for i in lst if esiti[chiave_via(i)][1] == "vinca"]),
                     ("esonero", [i for i in lst if esiti[chiave_via(i)][1] == "esonero"])]
        else:
            parti = [("", lst)]
        for esito, sub in parti:
            if not sub:
                continue
            n += 1
            ist = A.IstanzaAcqua(numero=n, ente_tipo=k[0] if k[0] != "paesaggio"
                                 else "soprintendenza", ente_nome=k[1], interferenze=sub,
                                 corso=k[2] or NOME_ZONA_SOPR,
                                 corsi_chiavi=[k[2] or NOME_ZONA_SOPR])
            ist.scheda = scheda
            ist.esito = esito
            sigla = sigla_area(k[2], k[0])
            ist.nome_base = "%s_%s%s" % (base_c, sigla.strip(),
                                         {"vinca": "_VINCA", "esonero": "_ESONERO"}.get(esito,
                                                                                      ""))
            ist.tavole = A.tavole_per_zona(sub)
            ist.interferenze = [i for t in ist.tavole for i in t]
            istanze.append(ist)
    usati = {}
    for ist in istanze:
        if ist.nome_base in usati:
            usati[ist.nome_base] += 1
            ist.nome_base = "%s_%d" % (ist.nome_base, usati[ist.nome_base])
        else:
            usati[ist.nome_base] = 1
    return istanze


# --------------------------------------------------------------------------- #
#  Testi per i modelli Word (stesse chiavi di ftth_acque.testi_istanza)
# --------------------------------------------------------------------------- #
def descr_vincoli(tipi: list) -> str:
    """'art. 136 e art. 142 lett. c) del D.Lgs. 42/2004'."""
    art = []
    if "art136" in tipi:
        art.append("art. 136")
    lett = sorted(t[-1] for t in tipi if t.startswith("art142"))
    if lett:
        art.append("art. 142 lett. %s" % A._elenco(["%s)" % x for x in lett]))
    testo = A._elenco(art)
    altri = [TIPI_AREA[t][1] for t in tipi
             if t in TIPI_AREA and not t.startswith("art14") and t != "art136"]
    if testo:
        testo += " del D.Lgs. 42/2004"
    if altri:
        testo = A._elenco([x for x in [testo] + [a.lower() for a in altri] if x])
    return testo


# vincoli archeologici: la relazione e' quella archeologica (VPIA, archeologo
# abilitato), non la relazione paesaggistica dell'Allegato D del DPR 31/2017
VINCOLI_ARCHEO = frozenset({"archeologia", "art142m"})


def tipi_vincolo(ist) -> list:
    tipi = []
    for i in ist.interferenze:
        for t in getattr(i, "vincoli", []) or []:
            if t not in tipi:
                tipi.append(t)
    return tipi


def ha_archeologico(ist) -> bool:
    return any(t in VINCOLI_ARCHEO for t in tipi_vincolo(ist))


def solo_archeologico(ist) -> bool:
    """True se l'istanza ha solo vincoli archeologici (niente paesaggio)."""
    tipi = tipi_vincolo(ist)
    return bool(tipi) and all(t in VINCOLI_ARCHEO for t in tipi)


AVVISO_ARCHEO = (
    "Vincolo archeologico: la relazione paesaggistica (Allegato D) non basta e non è "
    "il documento giusto. La Soprintendenza (Area Archeologia) valuta il rischio "
    "archeologico dello scavo: può chiedere la relazione di verifica preventiva "
    "dell'interesse archeologico (VPIA), redatta e firmata da un ARCHEOLOGO abilitato, "
    "e prescrivere la sorveglianza archeologica durante gli scavi. Il plugin non "
    "produce la relazione archeologica: concordala con la Soprintendenza.")


def testi_istanza_vincoli(ist, dest_nome: str = "") -> dict:
    """Frasi di oggetto, premessa, bollo e tabelle per i modelli acque."""
    vie = ist.vie()
    vie_txt = A._elenco(vie) if vie else "le vie indicate negli elaborati grafici"
    scheda = getattr(ist, "scheda", SCHEDA_SOPR)
    ente = dest_nome or ist.ente_nome
    if scheda == SCHEDA_SOPR:
        tipi = tipi_vincolo(ist)
        ente = ente or "Soprintendenza Archeologia, Belle Arti e Paesaggio"
        if solo_archeologico(ist):
            rif = " (art. 142 lett. m) del D.Lgs. 42/2004)" if "art142m" in tipi else ""
            nucleo = "%s, in aree di interesse archeologico%s" % (vie_txt, rif)
            return {"oggetto": "lungo %s." % nucleo, "premessa": "lungo %s" % nucleo,
                    "bollo": "%s, per la propria competenza." % nucleo,
                    "titolo": "IN AREE DI INTERESSE ARCHEOLOGICO",
                    "descr": "Scavi e posa in aree di interesse archeologico",
                    "tabella": "IN AREA VINCOLATA", "ente": ente}
        vinc = descr_vincoli(tipi)
        if ha_archeologico(ist):
            nucleo = "%s, in aree sottoposte a tutela paesaggistica e archeologica%s" % (
                vie_txt, (" ai sensi dell'%s" % vinc) if vinc else "")
            return {"oggetto": "lungo %s." % nucleo, "premessa": "lungo %s" % nucleo,
                    "bollo": "%s, per la propria competenza." % nucleo,
                    "titolo": "IN AREE SOTTOPOSTE A TUTELA PAESAGGISTICA E ARCHEOLOGICA",
                    "descr": "Scavi e posa in aree sottoposte a tutela paesaggistica e "
                             "archeologica",
                    "tabella": "IN AREA VINCOLATA", "ente": ente}
        nucleo = "%s, in aree sottoposte a tutela paesaggistica%s" % (
            vie_txt, (" ai sensi dell'%s" % vinc) if vinc else "")
        return {"oggetto": "lungo %s." % nucleo, "premessa": "lungo %s" % nucleo,
                "bollo": "%s, per la propria competenza." % nucleo,
                "titolo": "IN AREE SOTTOPOSTE A TUTELA PAESAGGISTICA",
                "descr": "Scavi e posa in aree sottoposte a tutela paesaggistica",
                "tabella": "IN AREA VINCOLATA", "ente": ente}
    nome_area = ist.corso
    if ist.ente_tipo == "natura2000":
        m = re.search(r"Rete Natura 2000\s+(.*)$", nome_area)
        sito = (m.group(1) if m else nome_area).strip()
        nucleo = "%s, nel sito della Rete Natura 2000 %s" % (vie_txt, sito)
        titolo = "NEL SITO RETE NATURA 2000 %s" % sito.upper()
        tabella = "NEL SITO RETE NATURA 2000"
        ente = ente or "Autorità competente per la Valutazione di Incidenza"
    else:
        area = re.sub(r"^Area protetta\s+", "", nome_area)
        nucleo = "%s, nel territorio dell'area protetta %s" % (vie_txt, area)
        titolo = "NEL TERRITORIO DELL'AREA PROTETTA %s" % area.upper()
        tabella = "NELL'AREA PROTETTA"
        ente = ente or "Ente gestore dell'area protetta"
    return {"oggetto": "lungo %s." % nucleo, "premessa": "lungo %s" % nucleo,
            "bollo": "%s, per la propria competenza." % nucleo, "titolo": titolo,
            "descr": "Scavi e posa nell'area protetta", "tabella": tabella, "ente": ente}


# --------------------------------------------------------------------------- #
#  Promemoria (LEGGIMI)
# --------------------------------------------------------------------------- #
def promemoria_vincoli(ist, comune, dest: dict, documenti: list) -> str:
    dest = dest or {}
    righe = ["ISTANZA %d — %s" % (ist.numero, ist.nome_base), "",
             "Destinatario: %s — %s — PEC %s" % (dest.get("nome") or ist.ente_nome or "XXXXX",
                                                 dest.get("indirizzo") or "XXXXX",
                                                 dest.get("pec") or "XXXXX"),
             "Comune: %s (%s)" % (comune.nome, comune.prov_sigla or "XX"), ""]
    scheda = getattr(ist, "scheda", SCHEDA_SOPR)
    if scheda == SCHEDA_SOPR:
        com = [i for i in ist.interferenze if regime_soprintendenza(i) == "comunicazione"]
        aut = [i for i in ist.interferenze if regime_soprintendenza(i) == "autorizzazione"]
        righe += ["Lavori da AUTORIZZARE (trincea, no-dig, pozzetti, armadi): %d" % len(aut)]
        righe += ["  - n. %d %s: %s" % (i.id, i.via or "via da indicare", motivo_regime(i))
                  for i in aut]
        m_com = sum(int(round(m or 0)) for i in com for t, m in i.metri.items()
                    if t in TECNICHE_COMUNICAZIONE)
        gg = giorni_comunicazione(m_com)
        righe += ["Lavori solo da COMUNICARE (mini/microtrincea, art. 40 c. 4 DL 77/2021, "
                  "almeno %d giorni prima dell'inizio lavori — %d m di scavo; 8 giorni sotto "
                  "i 200 m, altrimenti 15): %d" % (gg, m_com, len(com))]
        righe += ["  - n. %d %s: %s" % (i.id, i.via or "via da indicare", motivo_regime(i))
                  for i in com]
        righe += ["", "Nei centri storici (spazi aperti) la comunicazione va accompagnata da un "
                       "elaborato tecnico sulla risistemazione degli spazi."]
        if ha_archeologico(ist):
            righe += ["", "ATTENZIONE — " + AVVISO_ARCHEO]
    elif getattr(ist, "esito", "") == "esonero":
        righe += ["Vie con meno di %d m di scavo: NIENTE VIncA (%s)." % (SOGLIA_VINCA_M,
                                                                      NORMA_ESONERO),
                  "Inviare all'autorità competente almeno 30 GIORNI PRIMA dell'inizio lavori "
                  "l'autodichiarazione di esclusione con descrizione sintetica e foto."]
    elif getattr(ist, "esito", "") == "vinca":
        righe += ["Vie con %d m di scavo o più: serve lo SCREENING VIncA (Format proponente). "
                  "Se la Regione ha un proprio modello di Format, usare quello: i dati "
                  "precompilati sono nel file del plugin." % SOGLIA_VINCA_M]
    righe += ["", "Documenti prodotti:"] + ["  - %s" % d for d in documenti]
    righe += ["", "Da completare: firmatari e dati del procuratore (XXXXX), procura e "
                  "documento d'identità, foto e fotoinserimenti, marche da bollo.",
              "Verificare sempre i perimetri dei vincoli sulle fonti ufficiali (SITAP, "
              "geoportale regionale, ente gestore): i dati scaricati sono ricognitivi.",
              "La documentazione prodotta dal plugin è una BOZZA: rileggerla e verificarla "
              "sempre (testi, norme, metri, destinatari, allegati) prima dell'invio."]
    return "\n".join(righe) + "\n"
