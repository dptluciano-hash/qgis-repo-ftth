# -*- coding: utf-8 -*-
"""Rete Pubblica: tratte e pozzetti.

Le TRATTE di Rete Pubblica si riconoscono dai loro attributi; la regola e' la
stessa dello stile 03_INFRASTRUTTURE ('Rete Pubblica') e della macro di
quantificazione. Basta una di queste condizioni:
  - PROPRIETA = 'IP' (maiuscole/minuscole e spazi indifferenti)
  - PROPRIETA vuoto (solo se il campo esiste)
  - nelle note (NOTES o NOTE) c'e' la parola 'IP'
  - nelle note c'e' '3rd party' / '3th party' / 'third party'

I POZZETTI invece non portano l'informazione negli attributi (sui dati di
Deruta: PROPRIETA sempre 'FCOP', NOTES sempre vuoto). Si deduce dalla
geometria: un pozzetto con STATO 'Esistente' che tocca una tratta di Rete
Pubblica e' anch'esso Rete Pubblica. L'esito viene scritto nel campo
RETE_PUBB ('SI'/'NO'), che lo stile 02_POZZETTO usa per l'arancione e la
macro per la tabella 02b. Il nome sta nei 10 caratteri del DBF, cosi'
sopravvive all'esportazione in shapefile.

(C) Beexact S.r.l. - Tutti i diritti riservati.
"""

from qgis.core import (QgsCoordinateTransform, QgsExpression, QgsExpressionContext,
                       QgsExpressionContextUtils, QgsFeatureRequest, QgsField,
                       QgsGeometry, QgsProject, QgsSpatialIndex, QgsVectorLayer,
                       QgsUnitTypes)
from qgis.PyQt.QtCore import QVariant

CAMPO_RETE_PUBBLICA = "RETE_PUBB"

# Stessa espressione della regola 'Rete Pubblica' dello stile 03_INFRASTRUTTURE.
# Se cambia la', va cambiata qui (e nella macro, funzione IsRetePubblica).
ESPR_TRATTA_RETE_PUBBLICA = r"""with_variable('nota',
  upper(coalesce(attribute(@feature, 'NOTES'), attribute(@feature, 'NOTE'), '')),
with_variable('prop',
  trim(coalesce(attribute(@feature, 'PROPRIETA'), '')),
  upper(@prop) = 'IP'
  OR (@prop = '' AND array_contains(map_akeys(attributes(@feature)), 'PROPRIETA'))
  OR regexp_match(@nota, '\\bIP\\b')
  OR regexp_match(@nota, '(3\\s*(RD|TH)|THIRD)[\\s_-]*PART')
))"""

# Un pozzetto "tocca" una tratta se dista al massimo questo. Sui dati reali
# il contatto e' esatto (distanza 0, vertici condivisi); i 10 cm assorbono
# solo gli arrotondamenti delle riproiezioni, non avvicinano pozzetti vicini.
TOLLERANZA_M = 0.10


def _layer_senza_filtro(layer):
    """Copia del layer letta dalla sorgente SENZA il filtro (subset).

    Le tratte di Rete Pubblica sono quasi sempre 'Esistente': se il layer
    del progetto ha un filtro tipo STATO='Nuovo', leggerle da li' darebbe
    zero tratte e zero pozzetti arancioni, senza alcun errore visibile.
    """
    try:
        if not layer.subsetString():
            return layer
        parti = [p for p in layer.source().split("|")
                 if not p.lower().startswith("subset=")]
        pulito = QgsVectorLayer("|".join(parti), layer.name(), layer.providerType())
        return pulito if pulito.isValid() else layer
    except Exception:  # noqa: BLE001
        return layer


def tratte_rete_pubblica(infra_layer):
    """Geometrie delle tratte di Rete Pubblica del layer infrastrutture."""
    lay = _layer_senza_filtro(infra_layer)
    espr = QgsExpression(ESPR_TRATTA_RETE_PUBBLICA)
    ctx = QgsExpressionContext(QgsExpressionContextUtils.globalProjectLayerScopes(lay))
    espr.prepare(ctx)
    out = []
    for f in lay.getFeatures():
        ctx.setFeature(f)
        if espr.evaluate(ctx) and f.hasGeometry():
            out.append(QgsGeometry(f.geometry()))
    return out, lay.crs()


def _tolleranza_in_unita(crs, metri):
    """Tolleranza nelle unita' del CRS dei pozzetti (gradi se geografico)."""
    if crs.isGeographic():
        return metri / 111320.0
    fatt = QgsUnitTypes.fromUnitToUnitFactor(QgsUnitTypes.DistanceMeters, crs.mapUnits())
    return metri * fatt


def marca_pozzetti_rete_pubblica(pozz_layer, infra_layer, tolleranza_m=TOLLERANZA_M):
    """Scrive RETE_PUBB = 'SI' sui pozzetti Esistenti che toccano una tratta di
    Rete Pubblica, 'NO' su tutti gli altri (cosi' un valore rimasto da un
    giro precedente non sopravvive). Modifica il layer pozzetti sul disco.

    Ritorna un dict: n_tratte, n_si, n_pozzetti, campo_creato, errore.
    """
    esito = {"n_tratte": 0, "n_si": 0, "n_pozzetti": 0,
             "campo_creato": False, "errore": None}
    try:
        tratte, crs_tratte = tratte_rete_pubblica(infra_layer)
        esito["n_tratte"] = len(tratte)

        prov = pozz_layer.dataProvider()
        idx = pozz_layer.fields().indexOf(CAMPO_RETE_PUBBLICA)
        if idx < 0:
            if not prov.addAttributes([QgsField(CAMPO_RETE_PUBBLICA, QVariant.String, len=2)]):
                esito["errore"] = "impossibile aggiungere il campo %s" % CAMPO_RETE_PUBBLICA
                return esito
            pozz_layer.updateFields()
            idx = pozz_layer.fields().indexOf(CAMPO_RETE_PUBBLICA)
            esito["campo_creato"] = True

        # tratte nel CRS dei pozzetti, con indice spaziale
        crs_p = pozz_layer.crs()
        if crs_tratte != crs_p:
            tr = QgsCoordinateTransform(crs_tratte, crs_p, QgsProject.instance())
            for g in tratte:
                g.transform(tr)
        indice = QgsSpatialIndex()
        for i, g in enumerate(tratte):
            indice.addFeature(i, g.boundingBox())
        tol = _tolleranza_in_unita(crs_p, tolleranza_m)

        i_stato = pozz_layer.fields().indexOf("STATO")
        modifiche = {}
        for f in pozz_layer.getFeatures(QgsFeatureRequest()):
            esito["n_pozzetti"] += 1
            valore = "NO"
            stato = str(f[i_stato]).strip().upper() if i_stato >= 0 and f[i_stato] is not None else ""
            if stato == "ESISTENTE" and f.hasGeometry() and tratte:
                g = f.geometry()
                bb = g.boundingBox()
                bb.grow(tol)
                for cand in indice.intersects(bb):
                    if tratte[cand].distance(g) <= tol:
                        valore = "SI"
                        break
            if valore == "SI":
                esito["n_si"] += 1
            modifiche[f.id()] = {idx: valore}
        if modifiche and not prov.changeAttributeValues(modifiche):
            esito["errore"] = "scrittura del campo %s non riuscita" % CAMPO_RETE_PUBBLICA
        pozz_layer.reload()
    except Exception as e:  # noqa: BLE001
        esito["errore"] = str(e)
    return esito
