# -*- coding: utf-8 -*-
"""«Leggimi» delle schede istanze: in poche righe quando serve l'istanza,
le norme di riferimento, l'ente, cosa si presenta e cosa fa il plugin.

Sono un promemoria per chi prepara le pratiche, non un parere: le norme
regionali e i regolamenti degli enti possono cambiare distanze e procedure,
e l'ultima parola è sempre dell'ente competente.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QDialogButtonBox, QHBoxLayout, QPushButton,
                                 QTextBrowser, QVBoxLayout, QWidget)

_AVVISO = ("<p style='color:#8a5300'><i>Promemoria, non parere legale: regioni, regolamenti "
           "degli enti e aggiornamenti normativi possono cambiare distanze e procedure. "
           "In caso di dubbio vale l'ente competente.</i></p>")

TESTI = {
    "fasce": ("Fasce di rispetto stradali, ferroviarie e idrauliche", """
<h3>Strade</h3>
<p><b>Chi decide la distanza.</b> La fascia dipende dal <b>tipo</b> della strada (art. 2 del
Codice della Strada: A autostrada, B extraurbana principale, C extraurbana secondaria,
D urbana di scorrimento, E urbana di quartiere, F locale), non dal proprietario: molte
statali ANAS sono di tipo C.</p>
<p><b>Dentro o fuori dal centro abitato.</b> Lo stabilisce la delimitazione del centro abitato
deliberata dal Comune (art. 3 e 4 CdS): va controllata sulla delibera, non si ricava dalla
cartografia.</p>
<ul>
<li><b>Fuori dal centro abitato</b> (art. 26 DPR 495/1992): A 60 m, B 40 m, C 30 m, F 20 m,
strade vicinali 10 m.</li>
<li><b>Zone edificabili fuori dal centro abitato</b> (art. 26 c.3): A 30 m, B 20 m, C 10 m.</li>
<li><b>Dentro il centro abitato</b> (art. 28): A 30 m, D 20 m. Per E e F, con strumento
urbanistico vigente la norma non fissa distanze (vale il PRG); senza PRG: E 20 m, F 10 m.</li>
<li><b>Muri di cinta</b>: fuori c.a. 5 m (A, B) e 3 m (C, F); dentro c.a. 3 m (A) e 2 m (D).</li>
</ul>
<p><b>Competenza dentro il centro abitato.</b> I tratti di strade statali, regionali e
provinciali che attraversano centri abitati con <b>più di 10.000 abitanti</b> sono del
Comune (art. 2 c.7 CdS); sotto questa soglia restano all'ente proprietario (ANAS,
Provincia, Regione).</p>
<p><b>Lavori sulla strada.</b> Scavi, attraversamenti e parallelismi nella sede o nelle
pertinenze stradali richiedono l'autorizzazione o la concessione dell'ente proprietario
(art. 21 e 25 CdS). Per la fibra l'istanza si presenta ai sensi dell'<b>art. 49 del
Codice delle comunicazioni elettroniche</b> (D.Lgs. 259/2003), con le procedure semplificate
per scavi e occupazioni.</p>
<h3>Ferrovia</h3>
<p>DPR 753/1980 art. 49: fascia di <b>30 m</b> dal limite della zona di occupazione della
rotaia più vicina. Nelle tavole per RFI si rappresenta la fascia 6-30 m: il plugin misura
6 e 30 m dall'asse del binario più il margine indicato.</p>
<h3>Corsi d'acqua</h3>
<p>R.D. 523/1904 art. 96 lett. f: <b>10 m</b> per fabbricati e scavi (4 m per piantagioni e
movimenti di terra) dal piede dell'argine o dal ciglio della sponda. Canali di bonifica:
R.D. 368/1904 art. 133, da 4 a 10 m secondo il regolamento del consorzio.</p>
<h3>Altro</h3>
<p>Cimitero: 200 m (R.D. 1265/1934 art. 338), riducibile fino a 50 m con delibera.</p>
<h3>Come lo usa il plugin</h3>
<p>La fascia si genera sempre dall'opera dell'ente (strada, binario, corso d'acqua), mai dalla
rete in progetto. Se nel progetto non c'è un layer adatto, «Scarica da OSM» lo prende da
OpenStreetMap nella zona della rete: è un dato da verificare.</p>
"""),
    "strade": ("Istanze agli enti delle strade", """
<h3>Quando serve</h3>
<p>Quando la rete occupa la <b>sede stradale</b> (carreggiata, banchina, marciapiede) o le
pertinenze di una strada che non è del Comune che rilascia il permesso, oppure quando corre
o attraversa nella <b>fascia di rispetto</b> fuori dal centro abitato.</p>
<h3>Chi è l'ente</h3>
<ul>
<li><b>ANAS</b>: strade statali (SS) e autostrade gestite direttamente; per le altre
autostrade il concessionario;</li>
<li><b>Provincia o Città metropolitana</b>: strade provinciali (SP);</li>
<li><b>Regione o ente regionale</b>: strade regionali (SR), dove esistono;</li>
<li><b>Comune</b>: strade comunali e, nei centri abitati con <b>più di 10.000 abitanti</b>, anche
i tratti interni di statali, regionali e provinciali (art. 2 c.7 CdS). Sotto quella soglia
il tratto interno resta all'ente proprietario.</li>
</ul>
<h3>Norme</h3>
<ul>
<li><b>Codice della Strada</b> (D.Lgs. 285/1992): art. 21 (opere e depositi sulle strade),
art. 25 (attraversamenti e uso della sede stradale: autorizzazione o concessione dell'ente
proprietario), art. 2, 3 e 4 (classificazione e delimitazione del centro abitato).</li>
<li><b>Regolamento</b> (DPR 495/1992): art. 26 e 28 per le fasce di rispetto (vedi il Leggimi
delle Fasce di rispetto), art. 65-67 per attraversamenti e occupazioni.</li>
<li><b>Codice delle comunicazioni elettroniche</b> (D.Lgs. 259/2003): l'istanza si presenta
ai sensi dell'<b>art. 49</b> (opere civili, scavi e occupazione di suolo), con le procedure
semplificate per le reti in fibra.</li>
<li><b>D.L. 77/2021, art. 40 c.4</b>: la posa in microtrincea (2-4 cm di larghezza, 10-35 cm di
profondità) è ammessa anche vicino al bordo della strada o sul marciapiede, senza scarifica
e ripristino dell'intera carreggiata; il gestore può concordare la posizione per ragioni di
sicurezza.</li>
</ul>
<h3>Cosa si presenta</h3>
<p>Istanza art. 49 all'ente con la relazione tecnica, le tabelle degli scavi per
<b>progressiva chilometrica</b> (in sede e in fascia di rispetto; gli attraversamenti sono
segnati con *), pozzetti e armadi, il cronoprogramma, il bollo e la planimetria con le
etichette «KM … SCAVO …». Molti enti chiedono anche una cauzione o fideiussione per i
ripristini e il canone per l'occupazione: segui il disciplinare dell'ente.</p>
<h3>Come lo usa il plugin</h3>
<ul>
<li><b>1) Comune</b>: comune, provincia e CAP, controllati con gli shape del progetto.</li>
<li><b>2) Strade toccate ed enti</b>: le strade classificate vicino alla rete, lette prima
dallo stradario del progetto (OpenStreetMap solo se nel progetto non c'è), con l'ente
proposto. Le strade proposte sono evidenziate in giallo e in mappa ma non spuntate: per
ognuna «Conferma» (chiede l'ente, poi la riga diventa verde e spuntata) o «Scarta». Sotto
la tabella «Seleziona tutte», «Nessuna», «Solo i proposti», «Mostra in mappa» e zoom col
doppio clic; in «Altre fonti» strade da un altro layer di linee con la sigla.</li>
<li><b>3) Interferenze</b>: lavori in sede stradale e in fascia di rispetto. Anche qui
«Mostra in mappa» e zoom col doppio clic.</li>
<li><b>4) Progressive chilometriche</b>: scegli i cippi — quelli creati nel progetto (layer
e campo km, oppure «Crea il layer cippi»: clicchi in mappa ogni cippo, scegli la strada
dalla tendina delle strade confermate e scrivi il km; ogni cippo vale solo per la sua
strada), quelli di OpenStreetMap o tutti e due — e premi «Calcola le chilometriche delle tratte» (con la barra di avanzamento). Negli
shape di tratte, pozzetti e armadi vanno il campo Chilometrica e il campo ETICHETTA, il testo
esatto della tavola («KM 11+756 / POSA POZZETTO 40x76»); in mappa il gruppo «Etichette in
stampa» le mostra come saranno stampate. Per correggere una chilometrica o un'etichetta
modifica il campo nello shape: alla generazione vale la tua correzione. Dimensione e
riquadro delle etichette sono nelle «Avanzate» del punto 4. C'è una riga per strada con la fonte, i cippi utili e lo stato; per una
strada puoi scegliere un altro layer di cippi o un'altra fonte e ricalcolare: le spunte
delle interferenze restano.</li>
<li><b>Conferma e vista per istanza</b> (sotto le interferenze, uguale in tutte le schede):
«Conferma le interferenze spuntate» scrive in 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO
OTTICO un campo per scheda (IST_STRADE, IST_ACQUE, IST_FERROV, IST_SOPR, IST_PARCHI) con il
nome dell'istanza, per esempio «SP28»: si lavora sempre sugli stessi shape. Sotto c'è un
occhio per ogni istanza e uno per il «Suolo comunale» (il resto della rete): spento
l'occhio, in mappa spariscono le sue tratte, i pozzetti e gli armadi; «Mostra tutto» torna
alla vista normale. Dopo «Trova le interferenze» interferenze e fasce di rispetto sono già
in mappa. <b>Correzioni in mappa</b>: seleziona scavi, pozzetti o armadi (anche nella
vista), scegli l'istanza e premi «Sposta in questa istanza», oppure «Togli dall'istanza»: il
campo negli shape si aggiorna e alla generazione l'interferenza segue (gli elementi tolti
escono con i loro metri; un'interferenza senza più elementi esce dall'istanza). Gli
elementi spostati in un'istanza: alla
generazione si contano esattamente come quelli trovati dalla ricerca, nella PL e nella RT
(tabelle, metri, computo, cronoprogramma): solo la parte dentro sede o fascia, con la
progressiva km. Un elemento tutto fuori conta 0 m e resta solo in tavola; se la sua
interferenza è già in un'altra istanza non viene contata due volte. Il log della
generazione dice cosa è entrato.</li>
<li><b>5) Foto, sezioni e generazione</b>: «Prepara layer Foto e Sezioni» (punti di
ripresa FOTO n e linee di sezione A-A' sulla mappa), le opzioni dei documenti e «Genera
istanze»: un'istanza per ente e strada, con relazione tecnica, cronoprogramma, bollo e
planimetria.</li>
</ul>
<p>Le progressive stimate e la classificazione delle strade da OSM vanno sempre
verificate.</p>
"""),
    "soprintendenza": ("Istanze alla Soprintendenza (paesaggio)", """
<h3>Quando serve</h3>
<p>Quando la rete passa in aree con <b>vincolo paesaggistico</b> (D.Lgs. 42/2004, Codice dei
beni culturali e del paesaggio):</p>
<ul>
<li><b>art. 136</b>: immobili e aree di notevole interesse pubblico, vincolati con decreto
(centri storici, bellezze panoramiche…);</li>
<li><b>art. 142</b>: aree tutelate per legge, tra cui costa e laghi (300 m), fiumi e torrenti
iscritti negli elenchi (150 m dalle sponde), montagne oltre 1.600/1.200 m, parchi, boschi,
usi civici, zone di interesse archeologico.</li>
</ul>
<h3>Che cosa si chiede: comunicazione o autorizzazione</h3>
<ul>
<li><b>Scavi in minitrincea e microtrincea</b>: per l'art. 40 c.4 del D.L. 77/2021 non
servono le autorizzazioni del D.Lgs. 42/2004. Vale per <b>tutte e due</b> le tutele: il
paesaggio (art. 146) e i beni culturali e l'archeologia, perché non si applicano alcune
verifiche archeologiche. Basta una <b>comunicazione</b> dell'avvio dei lavori alla
Soprintendenza almeno <b>15 giorni</b> prima (<b>8 giorni</b> se lo scavo è sotto i 200 m).
Alla comunicazione si allegano la cartografia del tracciato e, nei centri storici, un
elaborato sulla sistemazione degli spazi. La microtrincea prevista dalla norma è larga 2-4 cm
e profonda 10-35 cm.</li>
<li><b>Trincea tradizionale, no-dig, pozzetti e soprattutto armadi</b>: serve
l'<b>autorizzazione paesaggistica</b> (art. 146 D.Lgs. 42/2004), con la procedura
semplificata del <b>DPR 31/2017</b> e la <b>Relazione paesaggistica semplificata</b>
(Allegato D). Gli armadi sono il punto più delicato, perché si vedono.</li>
</ul>
<p>Nelle zone di interesse archeologico può servire anche il confronto con la Soprintendenza
per l'archeologia.</p>
<h3>Quale vincolo, quali elementi nell'istanza</h3>
<p>Il punto <b>A.15</b> dell'Allegato A del DPR 31/2017 esclude dall'autorizzazione
paesaggistica gli interventi nel sottosuolo che non cambiano in modo permanente la forma del
terreno e non toccano la vegetazione, tra cui i cavi interrati delle reti di servizi senza
parti che sporgono dal suolo. Il punto fa salve la tutela archeologica e le zone dell'art. 142
lett. m. La minitrincea e la microtrincea si comunicano soltanto, con qualunque vincolo
(art. 40 c.4 D.L. 77/2021).</p>
<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse">
<tr style="background:#e8edf5"><th>Vincolo (SITAP)</th><th>Mini/micro&shy;trincea</th>
<th>Trincea tradizionale</th><th>No-dig</th><th>Pozzetti</th><th>Armadi</th></tr>
<tr><td>Art. 142 lett. a, b, c, d, e, f, h, i, l (costa, laghi, fiumi 150 m, montagna,
ghiacciai, parchi, usi civici, zone umide, vulcani)</td><td>comunicazione</td>
<td>esclusa (A.15) se in strada con ripristino</td><td>esclusa (A.15): buche di partenza e
arrivo ripristinate</td><td>esclusi (A.15) se interrati, senza parti fuori terra</td>
<td><b>autorizzazione</b></td></tr>
<tr><td>Art. 142 lett. g (boschi)</td><td>comunicazione</td><td>esclusa solo se nella strada
esistente; altrimenti <b>autorizzazione</b></td><td>come la trincea</td><td>come la trincea</td>
<td><b>autorizzazione</b></td></tr>
<tr><td>Art. 142 lett. m (zone archeologiche), aree archeologiche, beni culturali</td>
<td>comunicazione</td><td><b>autorizzazione</b> e attenzione archeologica</td>
<td><b>autorizzazione</b> (anche le buche toccano il sottosuolo)</td><td><b>autorizzazione</b></td>
<td><b>autorizzazione</b></td></tr>
<tr><td>Art. 136 (vincolo con decreto), centri storici, siti UNESCO</td><td>comunicazione</td>
<td>dipende dalle prescrizioni del decreto: per prudenza <b>autorizzazione</b></td>
<td>per prudenza <b>autorizzazione</b></td><td>per prudenza <b>autorizzazione</b></td>
<td><b>autorizzazione</b></td></tr>
</table>
<p>Nella scheda, in «Cosa mettere nell'istanza», puoi scegliere fra:</p>
<ul>
<li><b>Tutto</b>: come finora;</li>
<li><b>Proposta dal vincolo</b>: la tabella qui sopra, applicata area per area;</li>
<li><b>Scelta manuale</b>: spunti tu trincea, no-dig, pozzetti, armadi e
mini/microtrincea.</li>
</ul>
<p>La tabella è un'interpretazione delle norme: le Soprintendenze hanno prassi diverse e la
scelta finale è tua. Per i boschi la proposta include tutto, perché da SITAP non si capisce se
lo scavo resta nella strada.</p>
<h3>Cosa si presenta</h3>
<p>Istanza ai sensi dell'<b>art. 49 del D.Lgs. 259/2003</b> con la relazione tecnica (RT), la planimetria (PL) delle aree con la rete, la
documentazione fotografica dei punti di intervento, la Relazione paesaggistica
semplificata, il bollo e, se serve, la dichiarazione di non parentela. Utile anche
l'estratto del vincolo dal geoportale regionale o da SITAP.</p>
<h3>Relazione paesaggistica o archeologica?</h3>
<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse">
<tr style="background:#e8edf5"><th></th><th>Relazione paesaggistica</th>
<th>Relazione archeologica (VPIA)</th></tr>
<tr><td><b>Quando</b></td><td>vincolo paesaggistico (art. 136, art. 142 tranne lett. m)</td>
<td>zone di interesse archeologico (art. 142 lett. m), aree e beni archeologici</td></tr>
<tr><td><b>Norma</b></td><td>DPCM 12/12/2005; semplificata: DPR 31/2017, Allegato D</td>
<td>D.Lgs. 36/2023 art. 41 c.4 e Allegato I.8 (verifica preventiva dell'interesse
archeologico); D.Lgs. 42/2004</td></tr>
<tr><td><b>Chi la firma</b></td><td>il tecnico progettista</td><td>un <b>archeologo
abilitato</b> (elenchi MiC)</td></tr>
<tr><td><b>Cosa valuta</b></td><td>l'aspetto: stato dei luoghi, contesto, compatibilità
dell'opera, mitigazioni e ripristini</td><td>il sottosuolo: ricerca d'archivio e
bibliografica, foto aeree, ricognizione sul terreno, carta del potenziale e del rischio
archeologico; contano profondità e tipo di scavo</td></tr>
<tr><td><b>Esito tipico</b></td><td>parere o autorizzazione</td><td>parere, spesso con
la prescrizione della <b>sorveglianza archeologica</b> durante gli scavi</td></tr>
<tr><td><b>Nel plugin</b></td><td>la produce (Allegato D)</td><td><b>non</b> la produce:
nelle aree solo archeologiche l'Allegato D non viene generato e l'istanza parla di «aree di
interesse archeologico»</td></tr>
</table>
<p>Se un'area ha entrambi i vincoli servono entrambe le valutazioni. La documentazione
prodotta dal plugin è sempre una bozza da rileggere e verificare prima dell'invio.</p>
<h3>Come lo usa il plugin</h3>
<p>Le aree si scaricano da SITAP/SITR o si prendono da un layer del progetto; si contano solo
gli scavi nuovi, perché gli esistenti non contano. La PL ha 1, 2 o 4 foto per tavola; con
«solo armadi» c'è una tavola per armadio. I perimetri scaricati sono ricognitivi: vanno
verificati sulle fonti ufficiali.</p>
<p>Stesso flusso delle altre schede istanze. Al punto 2, «Trova le aree e gli enti» e sotto
la tabella «Seleziona tutte / Nessuna / Solo i proposti» (le aree con rete dentro) e
«Mostra in mappa»; doppio clic su un'area per lo zoom. Al punto 3, dopo «Trova le
interferenze», «Mostra in mappa» mette scavi, pozzetti e armadi spuntati nel gruppo Istanze
&gt; Soprintendenza &gt; Trovati; doppio clic per lo zoom.</p>
"""),
    "parchi": ("Aree protette e Rete Natura 2000", """
<h3>Parchi e riserve (aree protette)</h3>
<p>Legge quadro 394/1991. Nei parchi e nelle riserve dell'elenco ufficiale (<b>EUAP</b>)
serve il <b>nulla osta dell'Ente Parco</b> (art. 13): l'ente verifica che l'intervento sia
compatibile con il piano e il regolamento del parco. Spesso le aree protette sono anche
vincolate per il paesaggio (art. 142 lett. f D.Lgs. 42/2004), e allora serve anche la
pratica paesaggistica.</p>
<h3>Rete Natura 2000 (SIC, ZSC, ZPS)</h3>
<p>Siti istituiti dalla Direttiva Habitat 92/43/CEE (SIC/ZSC) e dalla Direttiva Uccelli
2009/147/CE (ZPS). Per interventi che possono incidere su un sito serve la
<b>Valutazione di Incidenza (VIncA)</b>: DPR 357/1997 art. 5 e Linee guida nazionali VIncA
del 2019. La procedura è regionale: ogni Regione ha moduli e uffici propri.</p>
<ul>
<li><b>Livello I, screening</b>: si verifica se l'incidenza può essere significativa. Il
proponente presenta il «Format proponente».</li>
<li><b>Livello II, valutazione appropriata</b>: serve solo se lo screening non esclude
incidenze significative.</li>
</ul>
<h3>I due valori della scheda</h3>
<p><b>«Considera anche la rete entro … m dal sito»</b>: la VIncA può riguardare anche lavori
<i>fuori</i> dal perimetro che possono avere effetti sul sito. Con 0 il plugin conta solo la
rete dentro il perimetro; con un valore, per esempio 100 m, conta anche quella vicina.
Alcune Regioni indicano una distanza di attenzione: va controllata nella norma regionale.</p>
<p><b>«Soglia VIncA per via»</b>: il plugin somma i metri di scavo nuovo della stessa via
dentro il sito.</p>
<ul>
<li><b>Sotto la soglia</b> (200 m): niente VIncA (art. 40 c.3-bis D.L. 77/2021, come
modificato). Si comunica l'inizio dei lavori all'autorità competente almeno 30 giorni prima,
con l'autodichiarazione di esclusione, una descrizione sintetica e le foto;</li>
<li><b>da 200 m in su</b>: screening VIncA con il Format proponente.</li>
</ul>
<p>La soglia è quella delle pratiche di riferimento: verificala con l'ufficio regionale
competente.</p>
<h3>Come lo usa il plugin</h3>
<p>Le aree si scaricano da SITAP (parchi EUAP) ed EEA (Natura 2000) o si prendono da un layer
del progetto. Nell'elenco degli interventi c'è l'esito per ogni via (esclusione o screening),
e il plugin prepara un'istanza (art. 49 D.Lgs. 259/2003) per ogni area protetta o sito.</p>
<p>Stesso flusso delle altre schede istanze. Al punto 2, «Trova le aree e gli enti» e sotto
la tabella «Seleziona tutte / Nessuna / Solo i proposti» (le aree con rete dentro) e
«Mostra in mappa»; doppio clic su un'area per lo zoom. Al punto 3, dopo «Trova le
interferenze», «Mostra in mappa» mette scavi, pozzetti e armadi spuntati nel gruppo Istanze
&gt; Parchi e Natura 2000 &gt; Trovati; doppio clic per lo zoom.</p>
"""),
    "acque": ("Istanze per corsi d'acqua e canali", """
<h3>Quando serve</h3>
<p>Quando la rete attraversa un corso d'acqua o un canale (staffaggio su ponte, scavo,
perforazione sotto l'alveo) o corre vicino all'argine o alla sponda.</p>
<h3>Enti e norme</h3>
<ul>
<li><b>Demanio idrico, reticolo principale</b>: autorità idraulica regionale (Genio Civile,
uffici regionali; AIPo per il Po). R.D. 523/1904 (polizia idraulica), art. 93-96: fascia di
<b>10 m</b> per scavi e fabbricati (art. 96 lett. f). Serve la concessione o il nulla osta
idraulico.</li>
<li><b>Reticolo minore</b>: Regione o Comune, secondo la legge regionale (per esempio il
reticolo idrico minore in Lombardia).</li>
<li><b>Consorzi di bonifica</b>: R.D. 368/1904 art. 133 e seguenti e regolamento del
consorzio. Fascia da 4 a 10 m e concessione o nulla osta per attraversamenti e
parallelismi.</li>
<li><b>Demanio marittimo</b>: Codice della navigazione. Autorizzazione per i lavori entro 30 m
dal demanio (art. 55) e concessione per l'occupazione (art. 36).</li>
</ul>
<h3>Cosa si presenta</h3>
<p>Istanza ai sensi dell'<b>art. 49 del D.Lgs. 259/2003</b> (Codice delle comunicazioni elettroniche: opere civili, scavi e occupazione di suolo) all'ente, con la relazione tecnica, la planimetria (PL) con le interferenze
numerate, le sezioni o i dettagli dell'attraversamento (quota sotto il fondo alveo per il
no-dig, staffaggio sul ponte) e la documentazione fotografica.</p>
<h3>Come lo usa il plugin</h3>
<p>Lo screening trova i corsi d'acqua e gli enti competenti da OSM e dai layer del progetto,
e individua le interferenze con la rete nuova. Prepara un'istanza per ente o per canale.
Corsi d'acqua mancanti o tombinati vanno disegnati a mano: OSM non è una fonte
ufficiale.</p>
<p>Stesso flusso delle altre schede istanze. Al punto 2, «Trova i corsi d'acqua e gli
enti» e sotto la tabella «Seleziona tutte / Nessuna / Solo i proposti» (entro 200 m dalla
rete) e «Mostra in mappa»; doppio clic per lo zoom. Il layer dei corsi d'acqua non si crea
più a parte: «Trova le interferenze» lo rifà da solo con le righe spuntate, il layer B1 e i
corsi disegnati (B2). Al punto 3 «Mostra in mappa» mette scavi, pozzetti e armadi delle
interferenze spuntate nel gruppo Istanze &gt; Acque &gt; Trovati.</p>
"""),
    "rfi": ("Istanze a RFI (ferrovie)", """
<h3>Quando serve</h3>
<p>Quando la rete <b>attraversa</b> la ferrovia (sottopasso, cavalcavia, passaggio a livello)
o corre in <b>parallelismo</b> entro la fascia di rispetto.</p>
<h3>Norme</h3>
<p>DPR 753/1980 (polizia, sicurezza e regolarità dell'esercizio delle ferrovie):
<b>art. 49</b>, fascia di 30 m dal limite della zona di occupazione della rotaia più vicina,
dove le opere richiedono l'autorizzazione del gestore. Nelle tavole si rappresenta la fascia
6-30 m. Gli attraversamenti e i parallelismi sono regolati dalle procedure tecniche di RFI
(o del gestore della linea, se la linea non è RFI).</p>
<h3>Ente</h3>
<p>RFI, struttura territoriale (Direzione Operativa Infrastrutture) competente per la linea,
oppure il gestore della ferrovia regionale o in concessione.</p>
<h3>Cosa si presenta</h3>
<p>Istanza ai sensi dell'<b>art. 49 del D.Lgs. 259/2003</b> per tipologia (attraversamento, parallelismo, passaggio a livello), con il cronoprogramma, con la relazione
tecnica, la planimetria con la fascia 6-30 m e le progressive chilometriche della linea, le
sezioni e la documentazione fotografica.</p>
<h3>Tipologie di interferenza</h3>
<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse">
<tr style="background:#e8edf5"><th>Tipo</th><th>Interferenza</th><th>Quando</th>
<th>Sopralluogo preliminare</th><th>Allegati in più</th></tr>
<tr><td><b>A</b></td><td>Attraversamento con <b>riutilizzo</b> di infrastrutture
esistenti</td><td>si passa in tubi o canalizzazioni già esistenti (ENEL, TIM, ente
terzo)</td><td>no</td><td>Allegato J – Schema 1 di comunicazione interferenze tipo A;
esito dell'ente terzo proprietario, con la tratta evidenziata. Prima verificare che esista
la convenzione ente terzo/RFI</td></tr>
<tr><td><b>B</b></td><td>Attraversamento con <b>nuova infrastruttura in sottovia o sopra
galleria</b></td><td>scavo nuovo che attraversa la linea passando nel sottovia o sopra la
galleria</td><td><b>sì</b>, da concordare prima della PEC</td><td>verbale di sopralluogo
preliminare congiunto</td></tr>
<tr><td><b>C</b></td><td>Attraversamento in <b>No-Dig</b></td><td>attraversamento nuovo in
perforazione (TOC, spingitubo)</td><td><b>sì</b>, da concordare prima della PEC</td>
<td>verbale di sopralluogo preliminare congiunto</td></tr>
<tr><td><b>D</b></td><td><b>Parallelismo</b> con nuova infrastruttura interrata fuori
dalla proprietà RFI</td><td>scavo nuovo lungo la linea, tra <b>6 e 30 m</b></td><td>no</td>
<td>—</td></tr>
</table>
<p>Casi particolari: un riutilizzo esistente in parallelo non richiede istanza (verificare
che non sia in proprietà del gestore). Uno scavo a meno di 6 m è in proprietà
ferroviaria: non è un parallelismo D e va scelto a mano fra A, B o C. Una tratta aerea che
attraversa va decisa a mano.</p>
<h3>Come lo usa il plugin</h3>
<p>Il plugin riconosce da solo la tipologia, che poi confermi. Prepara un'istanza per ogni
tipo, gestore, linea e stazione. Calcola la fascia 6-30 m con il margine dall'asse del
binario. Gli elementi sotto i 6 m sono segnalati con «?» e vanno verificati.</p>
<h3>I passi della scheda</h3>
<ol>
<li><b>Comune</b>: scritto il nome, provincia, CAP e DOIT RFI si compilano da soli.</li>
<li><b>Trova le ferrovie e gli enti</b>: scarica da OSM ferrovie, cippi km e stazioni e
mostra una riga per linea con gestore, destinatario e metri di rete nella fascia. Sono
proposte le linee con rete in fascia; «Seleziona tutte / Nessuna / Solo i proposti»,
«Mostra in mappa» (gruppo Istanze &gt; Ferrovia &gt; Trovati) e doppio clic per lo zoom.
In «Altre fonti» aggiungi le linee da un layer del progetto: una linea con lo stesso nome
sostituisce quella di OSM.</li>
<li><b>Interferenze</b>: si cercano solo le linee spuntate. Confermi tipologia, km e
proprietario; «Mostra in mappa» mette scavi, pozzetti e armadi delle interferenze
spuntate; doppio clic per lo zoom.</li>
<li><b>Progressive chilometriche</b>, linea per linea: cippi OSM, un layer di cippi del
progetto (per tutte le linee o solo per quella riga) o nessuno (km da compilare). Dove OSM
non ha i cippi, «Crea il layer cippi»: clicchi in mappa i cippi del binario, scegli la linea
dalla tendina e scrivi il km; metti almeno due cippi vicino a ogni gruppo di interferenze
(il km si stima dai due cippi più vicini, entro 3 km). Dei cippi si usano quelli della
linea. «Calcola le chilometriche» rifà il calcolo e tiene spunte, tipologie, proprietario e
foto.</li>
<li><b>Destinatari</b> per gestore e DOIT RFI.</li>
<li><b>Genera le istanze</b>.</li>
</ol>
"""),
}


_NT = "https://www.normattiva.it/uri-res/N2Ls?urn:nir:"
_N = {
    "cbc": ("D.Lgs. 42/2004 — Codice dei beni culturali e del paesaggio",
            _NT + "stato:decreto.legislativo:2004-01-22;42"),
    "dpr31": ("DPR 31/2017 — Autorizzazione paesaggistica semplificata (Allegati A, B, D)",
              _NT + "presidente.repubblica:decreto:2017-02-13;31"),
    "dl77": ("D.L. 77/2021, art. 40 — Semplificazioni per le reti di comunicazione elettronica",
             _NT + "stato:decreto.legge:2021-05-31;77"),
    "cce": ("D.Lgs. 259/2003 — Codice delle comunicazioni elettroniche (art. 49)",
            _NT + "stato:decreto.legislativo:2003-08-01;259"),
    "cds": ("D.Lgs. 285/1992 — Codice della Strada (art. 2, 3, 4, 21, 25)",
            _NT + "stato:decreto.legislativo:1992-04-30;285"),
    "reg": ("DPR 495/1992 — Regolamento del Codice della Strada (art. 26, 28)",
            _NT + "presidente.repubblica:decreto:1992-12-16;495"),
    "fer": ("DPR 753/1980 — Polizia e sicurezza delle ferrovie (art. 49)",
            _NT + "presidente.repubblica:decreto:1980-07-11;753"),
    "rd523": ("R.D. 523/1904 — Opere idrauliche (art. 93-96)",
              _NT + "stato:regio.decreto:1904-07-25;523"),
    "rd368": ("R.D. 368/1904 — Bonificazioni (art. 133)",
              _NT + "stato:regio.decreto:1904-12-08;368"),
    "nav": ("Codice della navigazione (art. 36, 55)",
            _NT + "stato:regio.decreto:1942-03-30;327"),
    "rd1265": ("R.D. 1265/1934 — Testo unico leggi sanitarie (art. 338)",
               _NT + "stato:regio.decreto:1934-07-27;1265"),
    "l394": ("L. 394/1991 — Legge quadro sulle aree protette (art. 13)",
             _NT + "stato:legge:1991-12-06;394"),
    "dpr357": ("DPR 357/1997 — Direttiva Habitat, Valutazione di Incidenza (art. 5)",
               _NT + "presidente.repubblica:decreto:1997-09-08;357"),
    "anas": ("ANAS — Strade statali per regione (stradeanas.it, consultato dal plugin per "
             "sapere se una strada è ANAS)",
             "https://www.stradeanas.it/it/anas_roads_region/search_roads_region"),
    "sitap": ("SITAP — Sistema informativo territoriale ambientale e paesaggistico (MiC)",
              "http://www.sitap.beniculturali.it/"),
    "dlgs36": ("D.Lgs. 36/2023 — Codice dei contratti pubblici (art. 41 c.4, Allegato I.8: "
               "verifica preventiva dell'interesse archeologico)",
               _NT + "stato:decreto.legislativo:2023-03-31;36"),
    "dpcm05": ("DPCM 12/12/2005 — Relazione paesaggistica",
               "https://www.gazzettaufficiale.it/eli/id/2006/01/31/06A00852/sg"),
    "allA": ("Allegato A del DPR 31/2017 (testo del punto A.15)",
             "https://comune.sesto-fiorentino.fi.it/sites/default/files/dpr_31_2017_allegato_a.pdf"),
}
FONTI = {
    "fasce": ["cds", "reg", "fer", "rd523", "rd368", "rd1265", "cce"],
    "strade": ["cds", "reg", "cce", "dl77"],
    "soprintendenza": ["cbc", "dpr31", "allA", "dpcm05", "dlgs36", "dl77", "cce", "sitap"],
    "parchi": ["l394", "dpr357", "dl77", "cbc", "cce"],
    "acque": ["rd523", "rd368", "nav", "cce"],
    "rfi": ["fer", "cce"],
}
_NOTE_FONTI = {
    "parchi": "Linee guida nazionali per la Valutazione di Incidenza (VIncA), Intesa "
              "Stato-Regioni del 28/11/2019, G.U. n. 303 del 28/12/2019.",
}


def _fonti_html(chiave):
    voci = ["<li><a href='%s'>%s</a></li>" % (_N[k][1], _N[k][0]) for k in FONTI.get(chiave, [])]
    if chiave in _NOTE_FONTI:
        voci.append("<li>%s</li>" % _NOTE_FONTI[chiave])
    return "<h3>Fonti</h3><ul>%s</ul>" % "".join(voci) if voci else ""


def apri(parent, chiave):
    """Finestra del leggimi `chiave`."""
    titolo, corpo = TESTI[chiave]
    corpo = corpo + _fonti_html(chiave)
    dlg = QDialog(parent)
    dlg.setWindowTitle("Leggimi — " + titolo)
    dlg.resize(640, 560)
    v = QVBoxLayout(dlg)
    tb = QTextBrowser(dlg)
    tb.setOpenExternalLinks(True)
    # il foglio di stile del plugin dà ai riquadri di testo il carattere
    # a spaziatura fissa dei log: qui serve un testo da leggere
    tb.setStyleSheet("QTextBrowser { font-family: 'Segoe UI', Arial, sans-serif; "
                     "font-size: 10pt; }")
    tb.setHtml("<div style=\"font-family:'Segoe UI',Arial,sans-serif\"><h2>%s</h2>%s%s</div>"
               % (titolo, corpo, _AVVISO))
    v.addWidget(tb)
    bb = QDialogButtonBox(QDialogButtonBox.Close, parent=dlg)
    bb.button(QDialogButtonBox.Close).setText("Chiudi")
    bb.rejected.connect(dlg.reject)
    bb.accepted.connect(dlg.accept)
    v.addWidget(bb)
    dlg.exec_()


def pulsante(parent, chiave, testo="📖 Leggimi: norme e istruzioni"):
    """Pulsante che apre il leggimi."""
    b = QPushButton(testo)
    b.setToolTip("Quando serve l'istanza, norme di riferimento, ente, cosa si presenta e "
                 "cosa fa il plugin.")
    b.setCursor(Qt.PointingHandCursor)
    b.clicked.connect(lambda: apri(parent, chiave))
    return b


def riga(parent, chiave, testo="📖 Leggimi: norme e istruzioni"):
    """Riga con il pulsante a sinistra, da mettere in testa a una scheda."""
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    h.addWidget(pulsante(parent, chiave, testo))
    h.addStretch()
    return w
