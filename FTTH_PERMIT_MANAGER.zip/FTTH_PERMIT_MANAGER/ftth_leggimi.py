# -*- coding: utf-8 -*-
"""«Leggimi» delle schede istanze: in poche righe quando serve l'istanza,
le norme di riferimento, l'ente, cosa si presenta e cosa fa il plugin.

Sono un promemoria per chi prepara le pratiche, non un parere: le norme
regionali e i regolamenti degli enti possono cambiare distanze e procedure,
e l'ultima parola è sempre dell'ente competente.
"""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (QDialog, QDialogButtonBox, QHBoxLayout, QPushButton,
                                 QTextBrowser, QVBoxLayout, QWidget)

_AVVISO = ("<p style='color:#8a5300'><i>Promemoria, non parere legale: regioni, regolamenti "
           "degli enti e aggiornamenti normativi possono cambiare distanze e procedure. "
           "In caso di dubbio vale l'ente competente.</i></p>")

TESTI = {
    "fasce": ("Fasce di rispetto stradali, ferroviarie e idrauliche", """
<h3>Strade</h3>
<p><b>Chi decide la distanza.</b> La fascia dipende dal <b>tipo</b> della strada (art. 2 del
Codice della Strada: A autostrada, B extraurbana principale, C extraurbana secondaria,
D urbana di scorrimento, E urbana di quartiere, F locale), non dal proprietario: molte
statali ANAS sono di tipo C.</p>
<p><b>Dentro o fuori dal centro abitato.</b> Lo stabilisce la delimitazione del centro abitato
deliberata dal Comune (art. 3 e 4 CdS): va controllata sulla delibera, non si ricava dalla
cartografia.</p>
<ul>
<li><b>Fuori dal centro abitato</b> (art. 26 DPR 495/1992): A 60 m, B 40 m, C 30 m, F 20 m,
strade vicinali 10 m.</li>
<li><b>Zone edificabili fuori dal centro abitato</b> (art. 26 c.3): A 30 m, B 20 m, C 10 m.</li>
<li><b>Dentro il centro abitato</b> (art. 28): A 30 m, D 20 m. Per E e F, con strumento
urbanistico vigente la norma non fissa distanze (vale il PRG); senza PRG: E 20 m, F 10 m.</li>
<li><b>Muri di cinta</b>: fuori c.a. 5 m (A, B) e 3 m (C, F); dentro c.a. 3 m (A) e 2 m (D).</li>
</ul>
<p><b>Competenza dentro il centro abitato.</b> I tratti di strade statali, regionali e
provinciali che attraversano centri abitati con <b>più di 10.000 abitanti</b> sono del
Comune (art. 2 c.7 CdS); sotto questa soglia restano all'ente proprietario (ANAS,
Provincia, Regione).</p>
<p><b>Lavori sulla strada.</b> Scavi, attraversamenti e parallelismi nella sede o nelle
pertinenze stradali richiedono l'autorizzazione o la concessione dell'ente proprietario
(art. 21 e 25 CdS). Per la fibra l'istanza si presenta ai sensi dell'<b>art. 49 del
Codice delle comunicazioni elettroniche</b> (D.Lgs. 259/2003), con le procedure semplificate
per scavi e occupazioni.</p>
<h3>Ferrovia</h3>
<p>DPR 753/1980 art. 49: fascia di <b>30 m</b> dal limite della zona di occupazione della
rotaia più vicina. Nelle tavole per RFI si rappresenta la fascia 6-30 m: il plugin misura
6 e 30 m dall'asse del binario più il margine indicato.</p>
<h3>Corsi d'acqua</h3>
<p>R.D. 523/1904 art. 96 lett. f: <b>10 m</b> per fabbricati e scavi (4 m per piantagioni e
movimenti di terra) dal piede dell'argine o dal ciglio della sponda. Canali di bonifica:
R.D. 368/1904 art. 133, da 4 a 10 m secondo il regolamento del consorzio.</p>
<h3>Altro</h3>
<p>Cimitero: 200 m (R.D. 1265/1934 art. 338), riducibile fino a 50 m con delibera.</p>
<h3>Come lo usa il plugin</h3>
<p>La fascia si genera sempre dall'opera dell'ente (strada, binario, corso d'acqua), mai dalla
rete in progetto. Se nel progetto non c'è un layer adatto, «Scarica da OSM» lo prende da
OpenStreetMap nella zona della rete: è un dato da verificare.</p>
"""),
    "strade": ("Istanze agli enti delle strade", """
<h3>Quando serve</h3>
<p>Quando la rete occupa la <b>sede stradale</b> (carreggiata, banchina, marciapiede) o le
pertinenze di una strada che non è del Comune che rilascia il permesso, oppure quando corre
o attraversa nella <b>fascia di rispetto</b> fuori dal centro abitato.</p>
<h3>Chi è l'ente</h3>
<ul>
<li><b>ANAS</b>: strade statali (SS) e autostrade gestite direttamente; per le altre
autostrade il concessionario;</li>
<li><b>Provincia o Città metropolitana</b>: strade provinciali (SP);</li>
<li><b>Regione o ente regionale</b>: strade regionali (SR), dove esistono;</li>
<li><b>Comune</b>: strade comunali e, nei centri abitati con <b>più di 10.000 abitanti</b>, anche
i tratti interni di statali, regionali e provinciali (art. 2 c.7 CdS). Sotto quella soglia
il tratto interno resta all'ente proprietario.</li>
</ul>
<h3>Norme</h3>
<ul>
<li><b>Codice della Strada</b> (D.Lgs. 285/1992): art. 21 (opere e depositi sulle strade),
art. 25 (attraversamenti e uso della sede stradale: autorizzazione o concessione dell'ente
proprietario), art. 2, 3 e 4 (classificazione e delimitazione del centro abitato).</li>
<li><b>Regolamento</b> (DPR 495/1992): art. 26 e 28 per le fasce di rispetto (vedi il Leggimi
delle Fasce di rispetto), art. 65-67 per attraversamenti e occupazioni.</li>
<li><b>Codice delle comunicazioni elettroniche</b> (D.Lgs. 259/2003): l'istanza si presenta
ai sensi dell'<b>art. 49</b> (opere civili, scavi e occupazione di suolo), con le procedure
semplificate per le reti in fibra.</li>
<li><b>D.L. 77/2021, art. 40 c.4</b>: la posa in microtrincea (2-4 cm di larghezza, 10-35 cm di
profondità) è ammessa anche vicino al bordo della strada o sul marciapiede, senza scarifica
e ripristino dell'intera carreggiata; il gestore può concordare la posizione per ragioni di
sicurezza.</li>
</ul>
<h3>Cosa si presenta</h3>
<p>Istanza art. 49 all'ente con la relazione tecnica, le tabelle degli scavi per
<b>progressiva chilometrica</b> (in sede e in fascia di rispetto; gli attraversamenti sono
segnati con *), pozzetti e armadi, il cronoprogramma, il bollo e la planimetria con le
etichette «KM … SCAVO …». Molti enti chiedono anche una cauzione o fideiussione per i
ripristini e il canone per l'occupazione: segui il disciplinare dell'ente.</p>
<p>Le progressive stimate e la classificazione delle strade da OSM vanno sempre
verificate.</p>
"""),
    "soprintendenza": ("Istanze alla Soprintendenza (paesaggio)", """
<h3>Quando serve</h3>
<p>Quando la rete passa in aree con <b>vincolo paesaggistico</b> (D.Lgs. 42/2004, Codice dei
beni culturali e del paesaggio):</p>
<ul>
<li><b>art. 136</b>: immobili e aree di notevole interesse pubblico, vincolati con decreto
(centri storici, bellezze panoramiche…);</li>
<li><b>art. 142</b>: aree tutelate per legge, tra cui costa e laghi (300 m), fiumi e torrenti
iscritti negli elenchi (150 m dalle sponde), montagne oltre 1.600/1.200 m, parchi, boschi,
usi civici, zone di interesse archeologico.</li>
</ul>
<h3>Che cosa si chiede: comunicazione o autorizzazione</h3>
<ul>
<li><b>Scavi in minitrincea e microtrincea</b>: per l'art. 40 c.4 del D.L. 77/2021 non
servono le autorizzazioni del D.Lgs. 42/2004. Vale per <b>tutte e due</b> le tutele: il
paesaggio (art. 146) e i beni culturali e l'archeologia, perché non si applicano alcune
verifiche archeologiche. Basta una <b>comunicazione</b> dell'avvio dei lavori alla
Soprintendenza almeno <b>15 giorni</b> prima (<b>8 giorni</b> se lo scavo è sotto i 200 m).
Alla comunicazione si allegano la cartografia del tracciato e, nei centri storici, un
elaborato sulla sistemazione degli spazi. La microtrincea prevista dalla norma è larga 2-4 cm
e profonda 10-35 cm.</li>
<li><b>Trincea tradizionale, no-dig, pozzetti e soprattutto armadi</b>: serve
l'<b>autorizzazione paesaggistica</b> (art. 146 D.Lgs. 42/2004), con la procedura
semplificata del <b>DPR 31/2017</b> e la <b>Relazione paesaggistica semplificata</b>
(Allegato D). Gli armadi sono il punto più delicato, perché si vedono.</li>
</ul>
<p>Nelle zone di interesse archeologico può servire anche il confronto con la Soprintendenza
per l'archeologia.</p>
<h3>Quale vincolo, quali elementi nell'istanza</h3>
<p>Il punto <b>A.15</b> dell'Allegato A del DPR 31/2017 esclude dall'autorizzazione
paesaggistica gli interventi nel sottosuolo che non cambiano in modo permanente la forma del
terreno e non toccano la vegetazione, tra cui i cavi interrati delle reti di servizi senza
parti che sporgono dal suolo. Il punto fa salve la tutela archeologica e le zone dell'art. 142
lett. m. La minitrincea e la microtrincea si comunicano soltanto, con qualunque vincolo
(art. 40 c.4 D.L. 77/2021).</p>
<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse">
<tr style="background:#e8edf5"><th>Vincolo (SITAP)</th><th>Mini/micro&shy;trincea</th>
<th>Trincea tradizionale</th><th>No-dig</th><th>Pozzetti</th><th>Armadi</th></tr>
<tr><td>Art. 142 lett. a, b, c, d, e, f, h, i, l (costa, laghi, fiumi 150 m, montagna,
ghiacciai, parchi, usi civici, zone umide, vulcani)</td><td>comunicazione</td>
<td>esclusa (A.15) se in strada con ripristino</td><td>esclusa (A.15): buche di partenza e
arrivo ripristinate</td><td>esclusi (A.15) se interrati, senza parti fuori terra</td>
<td><b>autorizzazione</b></td></tr>
<tr><td>Art. 142 lett. g (boschi)</td><td>comunicazione</td><td>esclusa solo se nella strada
esistente; altrimenti <b>autorizzazione</b></td><td>come la trincea</td><td>come la trincea</td>
<td><b>autorizzazione</b></td></tr>
<tr><td>Art. 142 lett. m (zone archeologiche), aree archeologiche, beni culturali</td>
<td>comunicazione</td><td><b>autorizzazione</b> e attenzione archeologica</td>
<td><b>autorizzazione</b> (anche le buche toccano il sottosuolo)</td><td><b>autorizzazione</b></td>
<td><b>autorizzazione</b></td></tr>
<tr><td>Art. 136 (vincolo con decreto), centri storici, siti UNESCO</td><td>comunicazione</td>
<td>dipende dalle prescrizioni del decreto: per prudenza <b>autorizzazione</b></td>
<td>per prudenza <b>autorizzazione</b></td><td>per prudenza <b>autorizzazione</b></td>
<td><b>autorizzazione</b></td></tr>
</table>
<p>Nella scheda, in «Cosa mettere nell'istanza», puoi scegliere fra:</p>
<ul>
<li><b>Tutto</b>: come finora;</li>
<li><b>Proposta dal vincolo</b>: la tabella qui sopra, applicata area per area;</li>
<li><b>Scelta manuale</b>: spunti tu trincea, no-dig, pozzetti, armadi e
mini/microtrincea.</li>
</ul>
<p>La tabella è un'interpretazione delle norme: le Soprintendenze hanno prassi diverse e la
scelta finale è tua. Per i boschi la proposta include tutto, perché da SITAP non si capisce se
lo scavo resta nella strada.</p>
<h3>Colonnine PTE (facoltative)</h3>
<p>Le <b>colonnine PTE nuove</b> sono elementi fuori terra come gli armadi. Il plugin le legge
dal layer <b>ROE PTE</b>: TIPO «Colonnina» con il flag di colonnina nuova (NewColonnina =
Si/True); se il campo manca prende tutte le colonnine e lo scrive nel registro. «Trova» le
mostra fra gli interventi, ma nell'istanza entrano <b>solo</b> con la spunta «Colonnine PTE
nuove come elementi fuori terra» al punto 6. Spuntate contano come gli armadi:
autorizzazione, relazione tecnica (paragrafo «COLONNINE PTE» dopo quello dell'armadio),
relazione paesaggistica, planimetria («AREA COLONNINA PTE») e «Solo armadi» (una tavola per
elemento fuori terra).</p>
<p>«<b>Aggiungi particolare costruttivo colonnina</b>» (punto 6) mette nella tavola PC il
disegno della colonnina con lo zoccolo di ancoraggio quotato, anche quando usi la tua
cartella di particolari. Si spunta da sola quando scegli le colonnine e puoi toglierla.</p>
<h3>Cosa si presenta</h3>
<p>Istanza ai sensi dell'<b>art. 49 del D.Lgs. 259/2003</b> con la relazione tecnica (RT), la planimetria (PL) delle aree con la rete, la
documentazione fotografica dei punti di intervento, la Relazione paesaggistica
semplificata, il bollo e, se serve, la dichiarazione di non parentela. Utile anche
l'estratto del vincolo dal geoportale regionale o da SITAP.</p>
<h3>Relazione paesaggistica o archeologica?</h3>
<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse">
<tr style="background:#e8edf5"><th></th><th>Relazione paesaggistica</th>
<th>Relazione archeologica (VPIA)</th></tr>
<tr><td><b>Quando</b></td><td>vincolo paesaggistico (art. 136, art. 142 tranne lett. m)</td>
<td>zone di interesse archeologico (art. 142 lett. m), aree e beni archeologici</td></tr>
<tr><td><b>Norma</b></td><td>DPCM 12/12/2005; semplificata: DPR 31/2017, Allegato D</td>
<td>D.Lgs. 36/2023 art. 41 c.4 e Allegato I.8 (verifica preventiva dell'interesse
archeologico); D.Lgs. 42/2004</td></tr>
<tr><td><b>Chi la firma</b></td><td>il tecnico progettista</td><td>un <b>archeologo
abilitato</b> (elenchi MiC)</td></tr>
<tr><td><b>Cosa valuta</b></td><td>l'aspetto: stato dei luoghi, contesto, compatibilità
dell'opera, mitigazioni e ripristini</td><td>il sottosuolo: ricerca d'archivio e
bibliografica, foto aeree, ricognizione sul terreno, carta del potenziale e del rischio
archeologico; contano profondità e tipo di scavo</td></tr>
<tr><td><b>Esito tipico</b></td><td>parere o autorizzazione</td><td>parere, spesso con
la prescrizione della <b>sorveglianza archeologica</b> durante gli scavi</td></tr>
<tr><td><b>Nel plugin</b></td><td>la produce (Allegato D)</td><td><b>non</b> la produce:
nelle aree solo archeologiche l'Allegato D non viene generato e l'istanza parla di «aree di
interesse archeologico»</td></tr>
</table>
<p>Se un'area ha entrambi i vincoli servono entrambe le valutazioni. La documentazione
prodotta dal plugin è sempre una bozza da rileggere e verificare prima dell'invio.</p>
<h3>Come lo usa il plugin</h3>
<p>Le aree si scaricano da SITAP/SITR o si prendono da un layer del progetto; si contano solo
gli scavi nuovi, perché gli esistenti non contano. La PL ha 1, 2 o 4 foto per tavola; con
«solo armadi» c'è una tavola per armadio. I perimetri scaricati sono ricognitivi: vanno
verificati sulle fonti ufficiali.</p>
"""),
    "parchi": ("Aree protette e Rete Natura 2000", """
<h3>Parchi e riserve (aree protette)</h3>
<p>Legge quadro 394/1991. Nei parchi e nelle riserve dell'elenco ufficiale (<b>EUAP</b>)
serve il <b>nulla osta dell'Ente Parco</b> (art. 13): l'ente verifica che l'intervento sia
compatibile con il piano e il regolamento del parco. Spesso le aree protette sono anche
vincolate per il paesaggio (art. 142 lett. f D.Lgs. 42/2004), e allora serve anche la
pratica paesaggistica.</p>
<h3>Rete Natura 2000 (SIC, ZSC, ZPS)</h3>
<p>Siti istituiti dalla Direttiva Habitat 92/43/CEE (SIC/ZSC) e dalla Direttiva Uccelli
2009/147/CE (ZPS). Per interventi che possono incidere su un sito serve la
<b>Valutazione di Incidenza (VIncA)</b>: DPR 357/1997 art. 5 e Linee guida nazionali VIncA
del 2019. La procedura è regionale: ogni Regione ha moduli e uffici propri.</p>
<ul>
<li><b>Livello I, screening</b>: si verifica se l'incidenza può essere significativa. Il
proponente presenta il «Format proponente».</li>
<li><b>Livello II, valutazione appropriata</b>: serve solo se lo screening non esclude
incidenze significative.</li>
</ul>
<h3>I due valori della scheda</h3>
<p><b>«Considera anche la rete entro … m dal sito»</b>: la VIncA può riguardare anche lavori
<i>fuori</i> dal perimetro che possono avere effetti sul sito. Con 0 il plugin conta solo la
rete dentro il perimetro; con un valore, per esempio 100 m, conta anche quella vicina.
Alcune Regioni indicano una distanza di attenzione: va controllata nella norma regionale.</p>
<p><b>«Soglia VIncA per via»</b>: il plugin somma i metri di scavo nuovo della stessa via
dentro il sito.</p>
<ul>
<li><b>Sotto la soglia</b> (200 m): niente VIncA (art. 40 c.3-bis D.L. 77/2021, come
modificato). Si comunica l'inizio dei lavori all'autorità competente almeno 30 giorni prima,
con l'autodichiarazione di esclusione, una descrizione sintetica e le foto;</li>
<li><b>da 200 m in su</b>: screening VIncA con il Format proponente.</li>
</ul>
<p>La soglia è quella delle pratiche di riferimento: verificala con l'ufficio regionale
competente.</p>
<h3>Come lo usa il plugin</h3>
<p>Le aree si scaricano da SITAP (parchi EUAP) ed EEA (Natura 2000) o si prendono da un layer
del progetto. Nell'elenco degli interventi c'è l'esito per ogni via (esclusione o screening),
e il plugin prepara un'istanza (art. 49 D.Lgs. 259/2003) per ogni area protetta o sito.</p>
"""),
    "acque": ("Istanze per corsi d'acqua e canali", """
<h3>Quando serve</h3>
<p>Quando la rete attraversa un corso d'acqua o un canale (staffaggio su ponte, scavo,
perforazione sotto l'alveo) o corre vicino all'argine o alla sponda.</p>
<h3>Enti e norme</h3>
<ul>
<li><b>Demanio idrico, reticolo principale</b>: autorità idraulica regionale (Genio Civile,
uffici regionali; AIPo per il Po). R.D. 523/1904 (polizia idraulica), art. 93-96: fascia di
<b>10 m</b> per scavi e fabbricati (art. 96 lett. f). Serve la concessione o il nulla osta
idraulico.</li>
<li><b>Reticolo minore</b>: Regione o Comune, secondo la legge regionale (per esempio il
reticolo idrico minore in Lombardia).</li>
<li><b>Consorzi di bonifica</b>: R.D. 368/1904 art. 133 e seguenti e regolamento del
consorzio. Fascia da 4 a 10 m e concessione o nulla osta per attraversamenti e
parallelismi.</li>
<li><b>Demanio marittimo</b>: Codice della navigazione. Autorizzazione per i lavori entro 30 m
dal demanio (art. 55) e concessione per l'occupazione (art. 36).</li>
</ul>
<h3>Cosa si presenta</h3>
<p>Istanza ai sensi dell'<b>art. 49 del D.Lgs. 259/2003</b> (Codice delle comunicazioni elettroniche: opere civili, scavi e occupazione di suolo) all'ente, con la relazione tecnica, la planimetria (PL) con le interferenze
numerate, le sezioni o i dettagli dell'attraversamento (quota sotto il fondo alveo per il
no-dig, staffaggio sul ponte) e la documentazione fotografica.</p>
<h3>Come lo usa il plugin</h3>
<p>Lo screening trova i corsi d'acqua e gli enti competenti da OSM e dai layer del progetto,
e individua le interferenze con la rete nuova. Prepara un'istanza per ente o per canale.
Corsi d'acqua mancanti o tombinati vanno disegnati a mano: OSM non è una fonte
ufficiale.</p>
"""),
    "rfi": ("Istanze a RFI (ferrovie)", """
<h3>Quando serve</h3>
<p>Quando la rete <b>attraversa</b> la ferrovia (sottopasso, cavalcavia, passaggio a livello)
o corre in <b>parallelismo</b> entro la fascia di rispetto.</p>
<h3>Norme</h3>
<p>DPR 753/1980 (polizia, sicurezza e regolarità dell'esercizio delle ferrovie):
<b>art. 49</b>, fascia di 30 m dal limite della zona di occupazione della rotaia più vicina,
dove le opere richiedono l'autorizzazione del gestore. Nelle tavole si rappresenta la fascia
6-30 m. Gli attraversamenti e i parallelismi sono regolati dalle procedure tecniche di RFI
(o del gestore della linea, se la linea non è RFI).</p>
<h3>Ente</h3>
<p>RFI, struttura territoriale (Direzione Operativa Infrastrutture) competente per la linea,
oppure il gestore della ferrovia regionale o in concessione.</p>
<h3>Cosa si presenta</h3>
<p>Istanza ai sensi dell'<b>art. 49 del D.Lgs. 259/2003</b> per tipologia (attraversamento, parallelismo, passaggio a livello), con il cronoprogramma, con la relazione
tecnica, la planimetria con la fascia 6-30 m e le progressive chilometriche della linea, le
sezioni e la documentazione fotografica.</p>
<h3>Tipologie di interferenza</h3>
<table border="1" cellspacing="0" cellpadding="4" style="border-collapse:collapse">
<tr style="background:#e8edf5"><th>Tipo</th><th>Interferenza</th><th>Quando</th>
<th>Sopralluogo preliminare</th><th>Allegati in più</th></tr>
<tr><td><b>A</b></td><td>Attraversamento con <b>riutilizzo</b> di infrastrutture
esistenti</td><td>si passa in tubi o canalizzazioni già esistenti (ENEL, TIM, ente
terzo)</td><td>no</td><td>Allegato J – Schema 1 di comunicazione interferenze tipo A;
esito dell'ente terzo proprietario, con la tratta evidenziata. Prima verificare che esista
la convenzione ente terzo/RFI</td></tr>
<tr><td><b>B</b></td><td>Attraversamento con <b>nuova infrastruttura in sottovia o sopra
galleria</b></td><td>scavo nuovo che attraversa la linea passando nel sottovia o sopra la
galleria</td><td><b>sì</b>, da concordare prima della PEC</td><td>verbale di sopralluogo
preliminare congiunto</td></tr>
<tr><td><b>C</b></td><td>Attraversamento in <b>No-Dig</b></td><td>attraversamento nuovo in
perforazione (TOC, spingitubo)</td><td><b>sì</b>, da concordare prima della PEC</td>
<td>verbale di sopralluogo preliminare congiunto</td></tr>
<tr><td><b>D</b></td><td><b>Parallelismo</b> con nuova infrastruttura interrata fuori
dalla proprietà RFI</td><td>scavo nuovo lungo la linea, tra <b>6 e 30 m</b></td><td>no</td>
<td>—</td></tr>
</table>
<p>Casi particolari: un riutilizzo esistente in parallelo non richiede istanza (verificare
che non sia in proprietà del gestore). Uno scavo a meno di 6 m è in proprietà
ferroviaria: non è un parallelismo D e va scelto a mano fra A, B o C. La posa aerea (e le
tratte nuove senza scavo) non è un'interferenza: non entra nella ricerca.</p>
<h3>Come lo usa il plugin</h3>
<p>Il plugin riconosce da solo la tipologia, che poi confermi. Prepara un'istanza per ogni
tipo, gestore, linea e stazione. Calcola la fascia 6-30 m con il margine dall'asse del
binario. Gli elementi sotto i 6 m sono segnalati con «?» e vanno verificati.</p>
<p>Chilometriche: metti almeno due cippi della stessa linea vicino a ogni gruppo di interferenze. Il km si stima dai due cippi consecutivi più vicini (distanti fra loro al massimo 1,5 km, il più vicino entro 3 km dall'interferenza); altrimenti resta «km da verificare».</p>
"""),
}


_NT = "https://www.normattiva.it/uri-res/N2Ls?urn:nir:"
_N = {
    "cbc": ("D.Lgs. 42/2004 — Codice dei beni culturali e del paesaggio",
            _NT + "stato:decreto.legislativo:2004-01-22;42"),
    "dpr31": ("DPR 31/2017 — Autorizzazione paesaggistica semplificata (Allegati A, B, D)",
              _NT + "presidente.repubblica:decreto:2017-02-13;31"),
    "dl77": ("D.L. 77/2021, art. 40 — Semplificazioni per le reti di comunicazione elettronica",
             _NT + "stato:decreto.legge:2021-05-31;77"),
    "cce": ("D.Lgs. 259/2003 — Codice delle comunicazioni elettroniche (art. 49)",
            _NT + "stato:decreto.legislativo:2003-08-01;259"),
    "cds": ("D.Lgs. 285/1992 — Codice della Strada (art. 2, 3, 4, 21, 25)",
            _NT + "stato:decreto.legislativo:1992-04-30;285"),
    "reg": ("DPR 495/1992 — Regolamento del Codice della Strada (art. 26, 28)",
            _NT + "presidente.repubblica:decreto:1992-12-16;495"),
    "fer": ("DPR 753/1980 — Polizia e sicurezza delle ferrovie (art. 49)",
            _NT + "presidente.repubblica:decreto:1980-07-11;753"),
    "rd523": ("R.D. 523/1904 — Opere idrauliche (art. 93-96)",
              _NT + "stato:regio.decreto:1904-07-25;523"),
    "rd368": ("R.D. 368/1904 — Bonificazioni (art. 133)",
              _NT + "stato:regio.decreto:1904-12-08;368"),
    "nav": ("Codice della navigazione (art. 36, 55)",
            _NT + "stato:regio.decreto:1942-03-30;327"),
    "rd1265": ("R.D. 1265/1934 — Testo unico leggi sanitarie (art. 338)",
               _NT + "stato:regio.decreto:1934-07-27;1265"),
    "l394": ("L. 394/1991 — Legge quadro sulle aree protette (art. 13)",
             _NT + "stato:legge:1991-12-06;394"),
    "dpr357": ("DPR 357/1997 — Direttiva Habitat, Valutazione di Incidenza (art. 5)",
               _NT + "presidente.repubblica:decreto:1997-09-08;357"),
    "anas": ("ANAS — Strade statali per regione (stradeanas.it, consultato dal plugin per "
             "sapere se una strada è ANAS)",
             "https://www.stradeanas.it/it/anas_roads_region/search_roads_region"),
    "sitap": ("SITAP — Sistema informativo territoriale ambientale e paesaggistico (MiC)",
              "http://www.sitap.beniculturali.it/"),
    "dlgs36": ("D.Lgs. 36/2023 — Codice dei contratti pubblici (art. 41 c.4, Allegato I.8: "
               "verifica preventiva dell'interesse archeologico)",
               _NT + "stato:decreto.legislativo:2023-03-31;36"),
    "dpcm05": ("DPCM 12/12/2005 — Relazione paesaggistica",
               "https://www.gazzettaufficiale.it/eli/id/2006/01/31/06A00852/sg"),
    "allA": ("Allegato A del DPR 31/2017 (testo del punto A.15)",
             "https://comune.sesto-fiorentino.fi.it/sites/default/files/dpr_31_2017_allegato_a.pdf"),
}
FONTI = {
    "fasce": ["cds", "reg", "fer", "rd523", "rd368", "rd1265", "cce"],
    "strade": ["cds", "reg", "cce", "dl77"],
    "soprintendenza": ["cbc", "dpr31", "allA", "dpcm05", "dlgs36", "dl77", "cce", "sitap"],
    "parchi": ["l394", "dpr357", "dl77", "cbc", "cce"],
    "acque": ["rd523", "rd368", "nav", "cce"],
    "rfi": ["fer", "cce"],
}
_NOTE_FONTI = {
    "parchi": "Linee guida nazionali per la Valutazione di Incidenza (VIncA), Intesa "
              "Stato-Regioni del 28/11/2019, G.U. n. 303 del 28/12/2019.",
}


# I 6 passi, uguali in tutte le schede istanze (ftth_passi): testo comune +
# quello che cambia da una scheda all'altra
_PASSI_SEZ = {"strade": "strade", "rfi": "rfi", "acque": "acque",
              "soprintendenza": "sopr", "parchi": "parchi"}
_PASSI_EXTRA = {
    "strade": {
        2: "Strade classificate (A, SS, SR, SP) entro 50 m dalla rete, lette prima dallo "
           "stradario del progetto (OSM solo se manca), con l'ente proposto: «Conferma» ti "
           "chiede l'ente. Controlla la colonna Competenza (centri abitati, art. 2 c. 7 e "
           "26 CdS). Se in mappa il tracciato OSM di una strada è vecchio o sbagliato, apri "
           "<b>«Avanzate: il tracciato di una strada in mappa è sbagliato»</b>: seleziona la "
           "strada, «Correggi tracciato» (strumento vertici sulla linea viola), poi «Usa i "
           "tracciati corretti» e rifai «Trova le interferenze». La correzione resta nel "
           "progetto anche dopo un nuovo «Trova».",
        3: "Lavori in sede stradale e in fascia di rispetto. Sotto, <b>Chilometriche con i "
           "cippi</b>: cippi creati nel progetto («Crea il layer cippi»: clicchi in mappa il "
           "cippo, scegli la strada dalla tendina e scrivi il km), di OSM o tutti e due, poi "
           "«Calcola le chilometriche delle tratte». Nella tabella, una riga per strada: "
           "«Da dove prendo il km» (di solito «come scelto sopra») e «Risultato», che dice a "
           "parole com'è andata (cippi usati, coordinate se mancano). Negli shape vanno i campi Chilometrica ed "
           "ETICHETTA (il testo della tavola) e in mappa il gruppo «Etichette in stampa»: se "
           "correggi uno dei due campi, alla generazione vale la tua correzione.",
        4: "L'ente di ogni strada è quello confermato al punto 2 (colonne Ente, Ufficio, "
           "Indirizzo, PEC).",
        6: "Un'istanza per ente e strada: relazione tecnica, cronoprogramma, bollo e PL.",
    },
    "rfi": {
        2: "Ferrovie, cippi km e stazioni da OSM attorno al progetto, una riga per linea con "
           "gestore, destinatario e metri di rete in fascia. Nelle avanzate: fascia, margine "
           "dall'asse e linee da un layer del progetto. Se il tracciato OSM di una linea è "
           "sbagliato: «Avanzate: il tracciato di una ferrovia in mappa è sbagliato» "
           "(«Correggi tracciato», strumento vertici, «Usa i tracciati corretti»); la fascia "
           "si ricalcola e la correzione resta anche dopo un nuovo scaricamento.",
        3: "Si cercano solo le linee confermate. Tipologia A/B/C/D da confermare: cambiandola "
           "in tabella cambia subito anche in mappa. Sotto, <b>Chilometriche con i cippi</b>: "
           "cippi OSM o «Crea il layer cippi» (clicchi il cippo, scegli la linea, scrivi il "
           "km), poi «Calcola le chilometriche» (con la barra). Una riga per linea con «Da "
           "dove prendo il km» (automatico consigliato: OSM, se mancano i cippi del progetto, "
           "se no le coordinate) e «Risultato» che dice com'è andata.",
        4: "Destinatario per gestore e DOIT RFI.",
        6: "Un'istanza per tipologia, gestore, linea e stazione: art. 49, relazione e "
           "cronoprogramma, bollo, Modello B e PL. Nelle avanzate cartelle e rese. Nella "
           "planimetria le <b>quote dalla rotaia</b> le disegni tu: passo 5, «Disegna quote "
           "dalla rotaia» (clic sull'elemento, clic sulla rotaia più vicina perpendicolare al "
           "binario, tasto destro); in tavola escono con le frecce e la distanza al mezzo "
           "metro. La fascia di rispetto si vede anche su ortofoto e catasto. Una sezione "
           "prende solo le interferenze della sua tavola.",
    },
    "acque": {
        2: "Corsi d'acqua del comune da OSM con l'ente proposto e la distanza dal progetto. "
           "Nelle avanzate: un layer ufficiale o un canale disegnato a mano, fasce di "
           "rispetto e comprensori dei Consorzi. Se il tracciato OSM di un corso d'acqua è "
           "sbagliato: «Avanzate: il tracciato di un corso d'acqua in mappa è sbagliato», "
           "come in Strade e Ferrovie.",
        3: "Interferenze in fascia, con il modo di passare il corso d'acqua.",
        4: "L'ente di ogni corso d'acqua (vale per tutte le sue interferenze) e i "
           "destinatari per ente.",
        6: "Un'istanza per corso d'acqua o per ente: art. 49, relazione, bollo e PL.",
    },
    "soprintendenza": {
        2: "Aree vincolate da SITAP / SITR con la rete dentro. Nelle avanzate: aree da un "
           "layer del progetto o disegnate a mano.",
        3: "Interventi nelle aree (si contano solo gli scavi nuovi; le colonnine PTE nuove "
           "compaiono ma sono facoltative).",
        4: "Soprintendenza competente (nome, indirizzo, PEC).",
        6: "Relazione paesaggistica, non parentela, cosa mettere nell'istanza, foto per "
           "tavola, colonnine PTE come elementi fuori terra e «Aggiungi particolare "
           "costruttivo colonnina»; nelle avanzate geoportale consultato, PDF e loghi.",
    },
    "parchi": {
        2: "Parchi EUAP (SITAP) e siti Natura 2000 (EEA) con la rete dentro o vicino, con la "
           "soglia VIncA per via. Nelle avanzate: aree da un layer o disegnate.",
        3: "Interventi per via con l'esito: esclusione o screening VIncA.",
        4: "Un destinatario per area protetta o sito.",
        5: "Fotoinserimenti: FOTOINSERIMENTO n.jpg in 04_Foto.",
        6: "Contesto del Format VIncA; nelle avanzate geoportale, PDF e loghi.",
    },
}


def _passi_html(chiave):
    sez = _PASSI_SEZ.get(chiave)
    if sez is None:
        return ""
    try:
        from . import ftth_passi as _P
    except ImportError:
        import ftth_passi as _P
    ex = _PASSI_EXTRA.get(chiave, {})
    comuni = {
        1: "scritto il nome del comune, provincia e CAP si compilano da soli.",
        2: "«%s»: le righe con rete vicina sono <b>proposte in giallo, non spuntate</b>. Per "
           "ognuna «Conferma» (diventa verde) o «Escludi»; «Mostra in mappa» e doppio clic "
           "per lo zoom." % _P.TROVA[sez],
        3: "«Trova le interferenze» usa solo le righe confermate al punto 2. Controlla la "
           "tabella, poi <b>«Conferma le interferenze spuntate»</b>: il nome dell'istanza va "
           "nel campo %s di 03 INFRASTRUTTURE, 02_POZZETTO e 01_ARMADIO OTTICO. Sotto, un "
           "<b>occhio</b> per ogni istanza e per il «Suolo comunale» (il resto della rete; verde = in mappa, "
           "grigio = nascosta), «Solo questa», «Mostra tutto»; per correggere selezioni in "
           "mappa e premi «Sposta in questa istanza» o «Togli dall'istanza». Le tecniche si "
           "leggono dal campo TIPOLOGIA: tradizionale, minitrincea, microtrincea, no-dig e "
           "<b>canaletta VTR</b> (anche scritte con trattino o spazio, «Canaletta VTR»); "
           "l'aerea non conta. La canaletta ha la sua colonna in tabelle e cronoprogramma "
           "(senza ripristino del manto) e il paragrafo «CANALA IN VTR/FeZn» nella relazione "
           "solo quando c'è." % (
               {"strade": "IST_STRADE", "rfi": "IST_FERROV", "acque": "IST_ACQUE",
                "sopr": "IST_SOPR", "parchi": "IST_PARCHI"}[sez]),
        4: "Destinatari delle istanze e il Comune in e.p.c. (indirizzo e PEC).",
        5: "Quello che si disegna in mappa. <b>Foto e sezioni</b>: «Prepara layer Foto%s» crea "
           "i layer, «Coni ruotabili» i coni da girare con «Ruota elementi», «Foto e sezioni "
           "per un'istanza» layer solo per un'istanza. Nei layer Foto e Sezioni il campo "
           "<b>ISTANZA</b> (tendina con le istanze confermate; per RFI anche solo la linea; "
           "vuoto = per tutte) dice a quale istanza va il punto o la sezione: così due istanze "
           "possono avere ognuna la sua FOTO 1 o la sua A-A'. I file si cercano prima nella "
           "sottocartella dell'istanza (04_Foto\\SP28\\FOTO-1.jpg), poi nella cartella. "
           "<b>Etichette delle tavole</b> (facoltativo): «Modifica etichette in mappa» le mette "
           "nel layer «Etichette PL (spostabili)»; le trascini con «Sposta elemento» (testo e "
           "filo insieme) e ripremendo il pulsante si salvano. Nelle avanzate: etichette "
           "accorpate." % ("" if sez == "sopr" else " e Sezioni"),
        6: "<b>Stampa</b>: nelle tavole lo sfondo (cartografia, ortofoto, catasto) è leggermente "
           "in trasparenza, la rete resta piena. Le scelte dei documenti (tratti nelle tabelle RT, ortofoto, <b>scala "
           "delle tavole PL</b>: «automatica» o una scala fissa per tutte le tavole), «Genera "
           "la planimetria 1.1 PL», nelle avanzate PDF, cartelle, particolari e loghi. Poi "
           "«Anteprima di stampa» (PL e relazione con le etichette dove le hai messe), "
           "<b>«Genera le istanze»</b> e «Apri la cartella»; sotto, il registro. Se in una "
           "tavola cadono più sezioni di quante ne stanno (1 in RFI e Acque, 4 nella PL A1 "
           "Strade), si aggiunge una tavola inquadrata su ogni sezione in più. Cartella dei "
           "particolari vuota = particolari del plugin; compilata = solo i tuoi file "
           "(PARTICOLARE-1, «particolare costruttivo 2»…, in ordine di numero).",
    }
    voci = []
    for n in range(1, 7):
        voci.append("<li><b>%s</b>: %s%s</li>" % (
            _P.titolo(n, sez)[3:], comuni[n], (" " + ex[n]) if n in ex else ""))
    return ("<h3>I 6 passi della scheda (uguali in tutte le schede istanze)</h3><ol>%s</ol>"
            "<p>Le opzioni usate di rado sono sempre nei riquadri «Avanzate», chiusi, in fondo "
            "al passo.</p>" % "".join(voci))


def _fonti_html(chiave):
    voci = ["<li><a href='%s'>%s</a></li>" % (_N[k][1], _N[k][0]) for k in FONTI.get(chiave, [])]
    if chiave in _NOTE_FONTI:
        voci.append("<li>%s</li>" % _NOTE_FONTI[chiave])
    return "<h3>Fonti</h3><ul>%s</ul>" % "".join(voci) if voci else ""


def apri(parent, chiave):
    """Finestra del leggimi `chiave`."""
    titolo, corpo = TESTI[chiave]
    corpo = corpo + _passi_html(chiave) + _fonti_html(chiave)
    dlg = QDialog(parent)
    dlg.setWindowTitle("Leggimi — " + titolo)
    dlg.resize(640, 560)
    v = QVBoxLayout(dlg)
    tb = QTextBrowser(dlg)
    tb.setOpenExternalLinks(True)
    # il foglio di stile del plugin dà ai riquadri di testo il carattere
    # a spaziatura fissa dei log: qui serve un testo da leggere
    tb.setStyleSheet("QTextBrowser { font-family: 'Segoe UI', Arial, sans-serif; "
                     "font-size: 10pt; }")
    tb.setHtml("<div style=\"font-family:'Segoe UI',Arial,sans-serif\"><h2>%s</h2>%s%s</div>"
               % (titolo, corpo, _AVVISO))
    v.addWidget(tb)
    bb = QDialogButtonBox(QDialogButtonBox.Close, parent=dlg)
    bb.button(QDialogButtonBox.Close).setText("Chiudi")
    bb.rejected.connect(dlg.reject)
    bb.accepted.connect(dlg.accept)
    v.addWidget(bb)
    dlg.exec_()


def pulsante(parent, chiave, testo="📖 Leggimi: norme e istruzioni"):
    """Pulsante che apre il leggimi."""
    b = QPushButton(testo)
    b.setToolTip("Quando serve l'istanza, norme di riferimento, ente, cosa si presenta e "
                 "cosa fa il plugin.")
    b.setCursor(Qt.PointingHandCursor)
    b.clicked.connect(lambda: apri(parent, chiave))
    return b


def riga(parent, chiave, testo="📖 Leggimi: norme e istruzioni"):
    """Riga con il pulsante a sinistra, da mettere in testa a una scheda."""
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    h.addWidget(pulsante(parent, chiave, testo))
    h.addStretch()
    return w
