"""Parti comuni del «Trova … e gli enti» di tutte le schede istanze.

Stesso funzionamento in Strade, Ferrovia, Acque, Soprintendenza e Parchi:
pulsante con barra, tabella con spunta, «Seleziona tutte / Nessuna / Solo i
proposti», «Mostra in mappa» (layer nel gruppo Istanze > sezione > Trovati) e
zoom sulla riga con il doppio clic.
"""
import re

GRUPPO_TROVATI = "Trovati"
STILI = {   # colore e spessore per tipo di oggetto trovato
    "strade": ("230,120,0", 1.6),
    "interferenze": ("220,0,0", 1.0),
    "ferrovie": ("80,80,80", 1.4),
    "acque": ("0,110,220", 1.2),
    "aree": ("150,60,170", 0.6),
}


def _slug(t):
    return re.sub(r"[^0-9A-Za-z]+", "_", t or "").strip("_").lower() or "layer"


def _tipo_qgis(geoms):
    """Tipo di layer per le geometrie shapely: Point / MultiLineString /
    MultiPolygon (le linee e i poligoni sempre multi)."""
    tipi = {g.geom_type for g in geoms if g is not None and not g.is_empty}
    if tipi and tipi <= {"Point", "MultiPoint"}:
        return "Point" if tipi == {"Point"} else "MultiPoint"
    if tipi and tipi <= {"Polygon", "MultiPolygon"}:
        return "MultiPolygon"
    return "MultiLineString"


def mostra_in_mappa(project, sezione: str, nome: str, voci: list, etichetta: str = None,
                    stile: str = "strade"):
    """Scrive gli oggetti `voci` = [(geometria shapely WGS84, {campo: valore})]
    nel GeoPackage dei gruppi istanze (01_File shp/Istanze.gpkg) e li mette nel
    gruppo «Istanze > sezione > Trovati» come layer `nome` (sostituisce quello
    con lo stesso nome). Ritorna il layer."""
    from qgis.core import (QgsCoordinateReferenceSystem, QgsFeature, QgsField,
                           QgsGeometry, QgsPalLayerSettings, QgsTextFormat,
                           QgsVectorFileWriter, QgsVectorLayer,
                           QgsVectorLayerSimpleLabeling, QgsSymbol, QgsWkbTypes)
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtGui import QColor
    try:
        from . import ftth_gruppi_istanze as GR
    except ImportError:
        import ftth_gruppi_istanze as GR
    voci = [(g, a) for g, a in voci if g is not None and not g.is_empty]
    tipo = _tipo_qgis([g for g, _a in voci])
    campi = []
    for _g, a in voci:
        for k in a:
            if k not in campi:
                campi.append(k)
    mem = QgsVectorLayer("%s?crs=EPSG:4326" % tipo, nome, "memory")
    mem.dataProvider().addAttributes([QgsField(k, QVariant.String) for k in campi])
    mem.updateFields()
    feats = []
    for g, a in voci:
        f = QgsFeature(mem.fields())
        qg = QgsGeometry.fromWkt(g.wkt)
        if tipo.startswith("Multi"):
            qg.convertToMultiType()
        f.setGeometry(qg)
        for k in campi:
            v = a.get(k)
            f.setAttribute(k, "" if v is None else str(v))
        feats.append(f)
    mem.dataProvider().addFeatures(feats)
    percorso = GR.percorso_file(project)
    tab = "trovati_%s_%s" % (sezione, _slug(nome))
    opt = QgsVectorFileWriter.SaveVectorOptions()
    opt.driverName = "GPKG"
    opt.layerName = tab
    opt.fileEncoding = "UTF-8"
    import os
    opt.actionOnExistingFile = (QgsVectorFileWriter.CreateOrOverwriteLayer
                                if os.path.exists(percorso)
                                else QgsVectorFileWriter.CreateOrOverwriteFile)
    for vecchio in project.mapLayersByName(nome):
        if tab in (vecchio.source() or ""):
            project.removeMapLayer(vecchio.id())
    ris = QgsVectorFileWriter.writeAsVectorFormatV3(mem, percorso,
                                                    project.transformContext(), opt)
    if ris[0] != QgsVectorFileWriter.NoError:
        raise RuntimeError(ris[1] or "scrittura non riuscita")
    lyr = QgsVectorLayer("%s|layername=%s" % (percorso, tab), nome, "ogr")
    # stile semplice e riconoscibile
    colore, spessore = STILI.get(stile, STILI["strade"])
    sym = QgsSymbol.defaultSymbol(lyr.geometryType())
    if sym is not None:
        if lyr.geometryType() == QgsWkbTypes.PolygonGeometry:
            sym.setColor(QColor(*[int(x) for x in colore.split(",")], 50))
            try:
                sym.symbolLayer(0).setStrokeColor(QColor(*[int(x) for x in colore.split(",")]))
                sym.symbolLayer(0).setStrokeWidth(spessore)
            except Exception:  # noqa: BLE001
                pass
        else:
            sym.setColor(QColor(*[int(x) for x in colore.split(",")]))
            if lyr.geometryType() == QgsWkbTypes.LineGeometry:
                sym.setWidth(spessore)
            else:
                sym.setSize(3.0)
        lyr.renderer().setSymbol(sym)
    if etichetta and etichetta in campi:
        pal = QgsPalLayerSettings()
        pal.fieldName = etichetta
        fmt = QgsTextFormat()
        fmt.setSize(9)
        fmt.setColor(QColor(*[int(x) for x in colore.split(",")]))
        try:
            from qgis.core import QgsTextBufferSettings
            b = QgsTextBufferSettings()
            b.setEnabled(True)
            b.setSize(1.0)
            fmt.setBuffer(b)
        except Exception:  # noqa: BLE001
            pass
        pal.setFormat(fmt)
        if lyr.geometryType() == QgsWkbTypes.LineGeometry:
            pal.placement = QgsPalLayerSettings.Line
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        lyr.setLabelsEnabled(True)
    project.addMapLayer(lyr, False)
    radice = project.layerTreeRoot()
    g_sez = GR.gruppo_sezione(radice, sezione)
    g_tr = g_sez.findGroup(GRUPPO_TROVATI) or g_sez.insertGroup(0, GRUPPO_TROVATI)
    g_tr.insertLayer(0, lyr)
    g_tr.setItemVisibilityChecked(True)
    _ = QgsCoordinateReferenceSystem  # (import usato dai chiamanti per lo zoom)
    return lyr


def zoom(iface, project, geom_wgs84, margine=0.15):
    """Zoom della mappa sulla geometria shapely in WGS84."""
    from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                           QgsRectangle)
    if geom_wgs84 is None or geom_wgs84.is_empty or iface is None:
        return
    canvas = iface.mapCanvas()
    tr = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"),
                                canvas.mapSettings().destinationCrs(), project)
    x0, y0, x1, y1 = geom_wgs84.bounds
    r = tr.transformBoundingBox(QgsRectangle(x0, y0, x1, y1))
    if r.width() < 1 and r.height() < 1:
        r.grow(60)
    else:
        r.scale(1 + margine)
    canvas.setExtent(r)
    canvas.refresh()


def campo_km(layer):
    """Il campo con il km dei cippi: «km», «progressiva», «chilometrica»…
    (mai «fid», che la tendina proponeva per primo e non dava nessun km)."""
    if layer is None:
        return ""
    nomi = [f.name() for f in layer.fields()]
    for prova in (lambda n: n.lower() == "km",
                  lambda n: n.lower().startswith("chilom") or n.lower().startswith("progr"),
                  lambda n: "km" in n.lower()):
        for n in nomi:
            if prova(n):
                return n
    altri = [n for n in nomi if n.lower() not in ("fid", "id", "ogc_fid")]
    return altri[0] if len(altri) == 1 else ""


def scegli_campo_km(combo_campi, layer):
    """Collega il layer alla tendina dei campi e sceglie il campo km."""
    combo_campi.setLayer(layer)
    n = campo_km(layer)
    if n:
        combo_campi.setField(n)


def tendina_campo(layer, campo, valori):
    """Nel modulo del layer il campo `campo` diventa una tendina con
    `valori` (strade o linee confermate); senza valori resta testo libero."""
    from qgis.core import QgsEditorWidgetSetup
    k = layer.fields().indexOf(campo)
    if k < 0:
        return
    valori = [v for v in dict.fromkeys(valori or []) if v]
    if valori:
        layer.setEditorWidgetSetup(k, QgsEditorWidgetSetup(
            "ValueMap", {"map": [{v: v} for v in valori]}))
    else:
        layer.setEditorWidgetSetup(k, QgsEditorWidgetSetup("TextEdit", {}))


def crea_layer_cippi(project, iface, nome, campo_nome, valori, cartella_rel="01_File shp"):
    """Layer di punti dei cippi chilometrici (`campo_nome` + km) accanto al
    progetto: lo crea se manca, imposta la tendina di `campo_nome`, lo mette
    in modifica con lo strumento «aggiungi punto». Ritorna (layer, errore)."""
    import os
    from qgis.core import (QgsCoordinateReferenceSystem, QgsField, QgsFields,
                           QgsVectorFileWriter, QgsVectorLayer, QgsWkbTypes)
    from qgis.PyQt.QtCore import QVariant
    vl = next(iter(project.mapLayersByName(nome)), None)
    if vl is None:
        base = project.homePath()
        if not base:
            return None, "Salva prima il progetto: il layer va nella sua cartella."
        cart = os.path.join(base, cartella_rel)
        if not os.path.isdir(cart):
            cart = base
        gpkg = os.path.join(cart, nome + ".gpkg")
        if not os.path.isfile(gpkg):
            campi = QgsFields()
            campi.append(QgsField(campo_nome, QVariant.String, len=80))
            campi.append(QgsField("km", QVariant.String, len=20))
            opz = QgsVectorFileWriter.SaveVectorOptions()
            opz.driverName = "GPKG"
            opz.layerName = nome
            crs = project.crs() if project.crs().isValid() else \
                QgsCoordinateReferenceSystem("EPSG:4326")
            w = QgsVectorFileWriter.create(gpkg, campi, QgsWkbTypes.Point, crs,
                                           project.transformContext(), opz)
            del w
        vl = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
        if not vl.isValid():
            return None, "Impossibile creare %s" % gpkg
        project.addMapLayer(vl)
    if vl.fields().indexOf(campo_nome) < 0:
        vl.dataProvider().addAttributes([QgsField(campo_nome, QVariant.String, len=80)])
        vl.updateFields()
    tendina_campo(vl, campo_nome, valori)
    # etichetta «SP28 km 12+300» per vedere i cippi inseriti
    try:
        from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling
        pal = QgsPalLayerSettings()
        pal.isExpression = True
        pal.fieldName = "coalesce(\"%s\", '') || ' km ' || coalesce(\"km\", '')" % campo_nome
        tf = QgsTextFormat()
        tf.setSize(8)
        pal.setFormat(tf)
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
    except Exception:  # noqa: BLE001
        pass
    try:
        iface.setActiveLayer(vl)
        if not vl.isEditable():
            vl.startEditing()
        iface.actionAddFeature().trigger()
    except Exception:  # noqa: BLE001
        pass
    return vl, None


def riga_pulsanti(tabella, colonna, cosa, proposti=None, mostra=None):
    """«Seleziona tutte», «Nessuna», «Solo i proposti» (se `proposti(r)` dice
    quali righe sono proposte) e «Mostra in mappa» (se `mostra` c'e')."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHBoxLayout, QPushButton

    def spunta(funz):
        for r in range(tabella.rowCount()):
            it = tabella.item(r, colonna)
            if it is not None and (it.flags() & Qt.ItemIsUserCheckable):
                it.setCheckState(Qt.Checked if funz(r) else Qt.Unchecked)
    riga = QHBoxLayout()
    voci = [("Seleziona tutte", lambda r: True, "Spunta tutte %s dell'elenco." % cosa),
            ("Nessuna", lambda r: False, "Toglie tutte le spunte.")]
    if proposti is not None:
        voci.append(("Solo i proposti", proposti,
                     "Torna alla proposta: solo %s che toccano la rete." % cosa))
    for testo, funz, tip in voci:
        b = QPushButton(testo)
        b.setToolTip(tip)
        b.clicked.connect(lambda _=False, f=funz: spunta(f))
        riga.addWidget(b)
    riga.addStretch()
    if mostra is not None:
        b = QPushButton("Mostra in mappa")
        b.setToolTip("Mette %s spuntate nel progetto, nel gruppo «Istanze > … > Trovati», "
                     "per controllarle sopra la rete. Doppio clic su una riga: zoom." % cosa)
        b.clicked.connect(lambda _=False: mostra())
        riga.addWidget(b)
    return riga
