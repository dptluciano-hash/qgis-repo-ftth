"""Colonna «N. ARLO» nelle tabelle della relazione (join con ARLO AREA).

Con il flag attivo (uno per progetto, lo stesso in tutte le schede delle
istanze) ogni scavo e pozzetto prende il numero dell'armadio dell'area ARLO in
cui cade: AREA_AO dell'armadio che sta dentro quel poligono di «Arlo Area»
(se non c'è, l'etichetta del poligono). Nelle tabelle scavi e pozzetti della
relazione compare la colonna con il numero accanto, e le righe sono ordinate
dal numero più piccolo al più grande.
"""
import re

PRJ_SCOPE = "ftth_arlo"
PRJ_CHIAVE = "join"
TESTO_FLAG = "Colonna «N. ARLO» nelle tabelle della relazione (join con ARLO AREA, righe in ordine)"
INTESTAZIONE = "N. ARLO"


# --------------------------------------------------------------------- flag
def attivo(project) -> bool:
    if project is None:
        return False
    v, _ok = project.readEntry(PRJ_SCOPE, PRJ_CHIAVE, "0")
    return str(v) == "1"


def imposta(project, si: bool):
    if project is not None:
        project.writeEntry(PRJ_SCOPE, PRJ_CHIAVE, "1" if si else "0")


def crea_checkbox(dialog):
    """Casella del flag per una scheda, legata alle altre e al progetto."""
    from qgis.PyQt.QtWidgets import QCheckBox
    cb = QCheckBox(TESTO_FLAG)
    cb.setToolTip("Ogni scavo e pozzetto prende il numero dell'armadio della sua area ARLO "
                  "(layer «Arlo Area» + AREA_AO degli armadi). Nella relazione le tabelle "
                  "scavi e pozzetti hanno la colonna «N. ARLO» e le righe in ordine di "
                  "numero. Vale per tutto il progetto.")
    cb.setChecked(attivo(getattr(dialog, "project", None)))
    if not hasattr(dialog, "_caselle_arlo"):
        dialog._caselle_arlo = []
    dialog._caselle_arlo.append(cb)

    def _cambia(si):
        imposta(getattr(dialog, "project", None), si)
        for altra in dialog._caselle_arlo:
            if altra is not cb and altra.isChecked() != si:
                altra.blockSignals(True)
                altra.setChecked(si)
                altra.blockSignals(False)
    cb.toggled.connect(_cambia)
    return cb


# ------------------------------------------------------------ join spaziale
def _numero_pulito(v) -> str:
    try:
        from . import ftth_acque as A
    except ImportError:
        import ftth_acque as A
    return A.numero_armadio(v)


def indice_arlo(project) -> list:
    """[(poligono shapely WGS84, numero)] dalle aree ARLO del progetto."""
    from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsGeometry,
                           QgsWkbTypes)
    from shapely import wkt as _wkt
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    arlo = next((l for l in project.mapLayers().values()
                 if "arlo" in l.name().lower() and hasattr(l, "geometryType")
                 and l.geometryType() == QgsWkbTypes.PolygonGeometry), None)
    if arlo is None:
        return []
    tr = QgsCoordinateTransform(arlo.crs(), wgs, project)
    # armadi con il loro numero (AREA_AO, poi ID_ARMADIO)
    armadi = []
    arm = next(iter(project.mapLayersByName("01_ARMADIO OTTICO")), None)
    if arm is not None:
        nomi = {f.name().upper(): f.name() for f in arm.fields()}
        campo = next((nomi[c] for c in ("AREA_AO", "ID_ARMADIO") if c in nomi), None)
        tra = QgsCoordinateTransform(arm.crs(), wgs, project)
        for f in arm.getFeatures():
            if not f.hasGeometry() or not campo:
                continue
            n = _numero_pulito(f[campo])
            if n:
                g = QgsGeometry(f.geometry())
                g.transform(tra)
                armadi.append((_wkt.loads(g.asWkt()), n))
    campo_et = next((c.name() for c in arlo.fields()
                     if c.name().lower() in ("label", "nome", "name", "area_ao", "arlo")), None)
    out = []
    for f in arlo.getFeatures():
        if not f.hasGeometry():
            continue
        g = QgsGeometry(f.geometry())
        g.transform(tr)
        pol = _wkt.loads(g.asWkt())
        if not pol.is_valid:
            pol = pol.buffer(0)
        dentro = sorted({n for p, n in armadi if pol.contains(p)}, key=chiave_numero)
        if dentro:
            num = ", ".join(dentro)
        else:
            num = str(f[campo_et]).strip() if campo_et and f[campo_et] not in (None, "") else ""
            if num.upper() == "NULL":
                num = ""
        if num:
            out.append((pol, num))
    return out


def numero_punto(indice: list, lon, lat) -> str:
    from shapely.geometry import Point
    try:
        p = Point(float(lon), float(lat))
    except (TypeError, ValueError):
        return ""
    for pol, num in indice:
        if pol.contains(p):
            return num
    return ""


def annota(project, interferenze: list, attivo_join: bool) -> int:
    """Scrive e["arlo"] su ogni elemento con coordinate (o lo toglie se il
    flag è spento). Ritorna quanti elementi hanno un numero."""
    n = 0
    if not attivo_join:
        for i in interferenze or []:
            for e in i.elementi:
                e.pop("arlo", None)
        return 0
    idx = indice_arlo(project)
    for i in interferenze or []:
        for e in i.elementi:
            num = numero_punto(idx, e.get("lon"), e.get("lat")) if idx else ""
            e["arlo"] = num
            n += 1 if num else 0
    return n


def annota_progetto(interferenze: list) -> int:
    """annota() con il progetto corrente di QGIS e il suo flag (senza QGIS,
    come nei test, toglie solo eventuali numeri rimasti)."""
    try:
        from qgis.core import QgsProject
        prj = QgsProject.instance()
    except Exception:  # noqa: BLE001
        prj = None
    try:
        return annota(prj, interferenze, attivo(prj))
    except Exception:  # noqa: BLE001
        return annota(None, interferenze, False)


# ------------------------------------------------------- righe e tabelle
def chiave_numero(s):
    m = re.search(r"\d+", str(s or ""))
    return (int(m.group(0)) if m else 10 ** 9, str(s or ""))


def _fmt(numeri) -> str:
    vals = sorted({str(n) for n in numeri if n}, key=chiave_numero)
    return ", ".join(vals)


def assegna(tratte: list) -> bool:
    """tr.arlo e tr.arlo_pozzetti dai numeri degli elementi di ogni riga.
    False (e niente colonna) se gli elementi non sono stati annotati."""
    if not any("arlo" in e for tr in tratte for e in getattr(tr, "_elementi", []) or []):
        return False
    for tr in tratte:
        el = getattr(tr, "_elementi", []) or []
        tr.arlo = _fmt(e.get("arlo") for e in el)
        gruppi = getattr(tr, "_pozzetti_el", None)
        if gruppi:
            tr.arlo_pozzetti = [_fmt(e.get("arlo") for e in g) or tr.arlo for g in gruppi]
        else:
            tr.arlo_pozzetti = None
    return True


def ordina(tratte: list):
    """Righe in ordine di numero ARLO (dal più piccolo); a parità resta
    l'ordine di prima (progressiva, tavola)."""
    tratte.sort(key=lambda tr: chiave_numero((getattr(tr, "arlo", "") or "").split(",")[0]))


def _trova_tabella(doc, testo_totale):
    for tb in doc.tables:
        if tb.rows and tb.rows[-1].cells and \
                tb.rows[-1].cells[0].text.strip() == testo_totale:
            return tb
    return None


def colonne_rt(doc, tratte: list):
    """Colonna «N. ARLO» accanto alla prima nelle tabelle scavi e pozzetti
    della relazione (righe come le scrive rfi.riempi_tabelle_rt)."""
    tb = _trova_tabella(doc, "Totale complessivo")
    if tb is not None:
        _aggiungi_colonna(tb, [getattr(tr, "arlo", "") for tr in tratte])
    tb = _trova_tabella(doc, "Totale Complessivo")
    if tb is not None:
        vals = []
        for tr in tratte:
            righe = tr.righe_pozzetti or ([None] if tr.pozzetti else [])
            ap = getattr(tr, "arlo_pozzetti", None) or [getattr(tr, "arlo", "")] * len(righe)
            vals += list(ap[:len(righe)]) + [getattr(tr, "arlo", "")] * (len(righe) - len(ap))
        _aggiungi_colonna(tb, vals or [""])      # «Nessun nuovo pozzetto»


def _aggiungi_colonna(tb, valori: list):
    """Nuova colonna in posizione 1: le righe dati sono le ultime len(valori)
    prima del totale; sopra c'è l'intestazione."""
    import copy
    from docx.oxml.ns import qn
    from docx.table import _Cell
    try:
        from . import ftth_rfi as rfi
    except ImportError:
        import ftth_rfi as rfi
    righe = list(tb.rows)
    n_dati = len(valori)
    prima_dato = max(0, len(righe) - 1 - n_dati)
    grid = tb._tbl.tblGrid
    cols = grid.findall(qn("w:gridCol")) if grid is not None else []
    w_new = None
    if cols:
        try:
            w0 = int(cols[0].get(qn("w:w")))
            tot = sum(int(c.get(qn("w:w"))) for c in cols)
            w_new = max(700, int(tot * 0.10))
            cols[0].set(qn("w:w"), str(max(700, w0 - w_new)))
            nuovo = copy.deepcopy(cols[0])
            nuovo.set(qn("w:w"), str(w_new))
            cols[0].addnext(nuovo)
        except (TypeError, ValueError):
            w_new = None
    riga_intest = 0
    for k in range(prima_dato):
        tc = righe[k]._tr.findall(qn("w:tc"))
        if tc and "".join(tc[0].itertext()).strip():
            vm0 = tc[0].find(qn("w:tcPr") + "/" + qn("w:vMerge"))
            if vm0 is None or vm0.get(qn("w:val")) == "restart":
                riga_intest = k
                break
    for k, row in enumerate(righe):
        tcs = row._tr.findall(qn("w:tc"))
        if not tcs:
            continue
        tc0 = tcs[0]
        pr0 = tc0.get_or_add_tcPr()
        span = pr0.find(qn("w:gridSpan"))
        if span is not None and int(span.get(qn("w:val"), "1")) > 1:
            span.set(qn("w:val"), str(int(span.get(qn("w:val"))) + 1))
            continue
        # righe dati e totale: la cella nuova copia quella della colonna
        # accanto (stesso carattere, corpo e allineamento dei numeri);
        # intestazione: copia della prima colonna (stessa riga di titoli)
        sorgente = tcs[1] if (k >= prima_dato and len(tcs) > 1) else tc0
        tcn = copy.deepcopy(sorgente)
        if sorgente is not tc0:
            prs = tcn.get_or_add_tcPr()
            for tag in ("w:gridSpan", "w:vMerge", "w:hMerge"):
                el = prs.find(qn(tag))
                if el is not None:
                    prs.remove(el)
        tc0.addnext(tcn)
        prn = tcn.get_or_add_tcPr()
        tcw = prn.find(qn("w:tcW"))
        if tcw is not None and w_new:
            tcw.set(qn("w:w"), str(w_new))
            tcw.set(qn("w:type"), "dxa")
        vm = prn.find(qn("w:vMerge"))
        continua = vm is not None and vm.get(qn("w:val")) in (None, "continue")
        cella = _Cell(tcn, tb)
        if k < prima_dato:
            # intestazione nella riga dove la prima colonna ha il suo titolo
            # («Indirizzo», «Chilometrica»...), con lo stesso stile
            testo = INTESTAZIONE if k == riga_intest and not continua else ""
        elif k - prima_dato < n_dati:
            testo = valori[k - prima_dato] or "-"
        else:
            testo = ""                       # riga del totale
        if not continua:
            rfi._set_cella(cella, testo)
