# -*- coding: utf-8 -*-
"""Schede «Istanze Soprintendenza» e «Istanze Parchi / Natura 2000» (Altri Enti).

Due schede separate costruite dallo stesso codice (chiave "sopr" o "parchi"):
1) comune; 2) aree vincolate (scaricate come nello Screening territorio o da un
layer del progetto); 3) interferenze = rete dentro le aree; 4) destinatari e
opzioni dei documenti; 5) genera (istanza art. 49, PL, RT+CR, bollo e i
documenti propri di ogni pratica). Il motore e i modelli sono quelli della
scheda Istanze Acque. Mescolato in FTTHPermessiDialog.
"""
import json
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QDoubleSpinBox, QFormLayout, QHBoxLayout,
    QLabel, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSpinBox, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)


def _mod():
    try:
        from . import ftth_vincoli as V
        from . import ftth_vincoli_doc as D
        from . import ftth_acque as A
    except ImportError:
        import ftth_vincoli as V
        import ftth_vincoli_doc as D
        import ftth_acque as A
    return V, D, A


class _Interrotta(BaseException):
    """«Interrompi»: BaseException perche' nessun `except Exception` la fermi."""


TITOLI = {"sopr": "Istanze Soprintendenza", "parchi": "Istanze Parchi / Natura 2000"}
SCHEDA_LOGICA = {"sopr": "soprintendenza", "parchi": "parchi"}
PRJ_SCOPE = {"sopr": "ftth_vincoli_sopr", "parchi": "ftth_vincoli_parchi"}
# layer nel progetto: gruppo, aree scaricate, aree disegnate a mano, cartella
GRUPPO = {"sopr": "Soprintendenza - Aree vincolate", "parchi": "Parchi e Natura 2000"}
NOME_AREE = {"sopr": "Aree vincolate Soprintendenza", "parchi": "Aree protette Parchi"}
NOME_DISEGNATE = {"sopr": "Aree vincolate disegnate", "parchi": "Aree protette disegnate"}
CARTELLA = {"sopr": "Soprintendenza", "parchi": "Parchi"}
COLORE = {"sopr": (166, 97, 26), "parchi": (51, 160, 44)}

# colonne della tabella aree
CA_INCL, CA_VOCE, CA_CODICE, CA_METRI, CA_FONTE, CA_VALIDA = range(6)
# colonne della tabella interferenze
CI_INCL, CI_N, CI_AREA, CI_VIA, CI_LAVORI, CI_REGIME, CI_NOTE = range(7)


class VincoliMixin:
    """Metodi delle schede Soprintendenza e Parchi / Natura 2000."""

    # ------------------------------------------------------------- schede
    def _tab_vin_sopr(self):
        return self._vin_tab("sopr")

    def _tab_vin_parchi(self):
        return self._vin_tab("parchi")

    def _vin_tab(self, s):
        V, D, A = _mod()
        if not hasattr(self, "_vin_w"):
            self._vin_w, self._vin_st = {}, {}
        w_ = {}
        self._vin_w[s] = w_
        self._vin_st[s] = {"aree": [], "interferenze": [], "strade": [], "regione": "",
                           "provincia": "", "soprintendenze": []}
        w = QWidget()
        v = QVBoxLayout(w)
        from . import ftth_passi as _P
        sez = "sopr" if s == "sopr" else "parchi"
        if s == "sopr":
            v.addWidget(_P.intro(
                self, sez,
                "Istanze alla Soprintendenza per la rete in aree con vincolo paesaggistico "
                "(art. 136 e 142 D.Lgs. 42/2004); mini e microtrincea si comunicano soltanto "
                "(DL 77/2021 art. 40 c. 4, vedi il Leggimi)."))
        else:
            v.addWidget(_P.intro(
                self, sez,
                "Istanze per la rete nei parchi (nulla osta dell'Ente Parco) e nei siti Natura "
                "2000: sotto i 200 m di scavo per via autodichiarazione di esclusione VIncA, "
                "da 200 m screening VIncA (vedi il Leggimi)."))
        try:
            from . import ftth_leggimi as _LG
            v.addWidget(_LG.riga(self, "soprintendenza" if s == "sopr" else "parchi"))
        except Exception:  # noqa: BLE001
            pass

        # 1) comune
        gb1 = self._gruppo(_P.titolo(1, sez), compresso=False)
        f1 = QFormLayout(gb1)
        w_["comune"] = QLineEdit()
        w_["comune"].setPlaceholderText("es. Eboli")
        try:                                    # suggerimento comuni ISTAT
            from . import ftth_comuni as _COM
            _COM.aggiungi_suggerimenti(w_["comune"])
        except Exception:
            pass
        prec = ""
        for nome in ("txt_acq_comune", "txt_rfi_comune"):
            t = getattr(self, nome, None)
            if t is not None and t.text().strip():
                prec = t.text().strip().title()
                break
        w_["comune"].setText(prec)
        w_["prov"] = QLineEdit()
        w_["prov"].setMaximumWidth(60)
        w_["cap"] = QLineEdit()
        w_["cap"].setMaximumWidth(80)
        try:            # scritto il comune: provincia (ISTAT) e CAP da soli
            from . import ftth_comuni as _COM
            _COM.collega_prov_cap(w_["comune"], w_["prov"], w_["cap"],
                                  log=lambda m, s=s: self._vin_log(s, m))
            if prec:
                w_["prov"].setText(_COM.sigla_di(prec))
        except Exception:
            pass
        w_["pec_comune"] = QLineEdit()
        w_["ind_comune"] = QLineEdit()
        r1 = QHBoxLayout()
        r1.addWidget(w_["comune"])
        r1.addWidget(QLabel("Prov."))
        r1.addWidget(w_["prov"])
        r1.addWidget(QLabel("CAP"))
        r1.addWidget(w_["cap"])
        f1.addRow("Comune:", r1)
        # indirizzo e PEC del Comune in e.p.c.: al passo 4, come in tutte le schede
        v.addWidget(gb1)

        # 2) aree vincolate / protette
        gb2 = self._gruppo(_P.titolo(2, sez), compresso=False)
        v2 = QVBoxLayout(gb2)
        r2 = QHBoxLayout()
        b = _P.primario(_P.TROVA[sez])
        b.setToolTip("Aree %s, con le stesse fonti dello Screening territorio. Ci vogliono da "
                     "30 secondi a qualche minuto; QGIS resta utilizzabile."
                     % ("vincolate da SITAP / SITR" if s == "sopr"
                        else "protette (parchi EUAP) e siti Natura 2000"))
        b.clicked.connect(lambda _=False, k=s: self._vin_scarica(k))
        r2.addWidget(b)
        w_["bar"] = self._vin_barra()
        if w_["bar"] is not None:
            r2.addWidget(w_["bar"], 1)
        w_["stop"] = QPushButton("Interrompi")
        w_["stop"].setVisible(False)
        w_["stop"].clicked.connect(lambda _=False, k=s: self._vin_interrompi(k))
        r2.addWidget(w_["stop"])
        r2.addStretch()
        v2.addLayout(r2)
        # B) layer del progetto
        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox, QgsMapLayerComboBox
        # due righe invece di una: affiancati, layer + campo + tipo + pulsante
        # impedivano di restringere la finestra
        gb_b = self._gruppo("Avanzate: aree da un layer del progetto o disegnate a mano")
        vb = QVBoxLayout(gb_b)
        r3 = QHBoxLayout()
        r3b = QHBoxLayout()
        w_["layer"] = QgsMapLayerComboBox()
        w_["layer"].setFilters(QgsMapLayerProxyModel.PolygonLayer)
        w_["layer"].setAllowEmptyLayer(True)
        w_["layer"].setLayer(None)
        # si scrive una parte del nome per trovare il layer
        if hasattr(self, "_rendi_ricercabile"):
            self._rendi_ricercabile(w_["layer"])
        r3.addWidget(w_["layer"], 1)
        w_["campo"] = QgsFieldComboBox()
        w_["campo"].setAllowEmptyFieldName(True)
        w_["layer"].layerChanged.connect(w_["campo"].setLayer)
        r3.addWidget(QLabel("nome:"))
        r3.addWidget(w_["campo"])
        w_["tipo_layer"] = QComboBox()
        for k, (sch, voce) in V.TIPI_AREA.items():
            if sch == SCHEDA_LOGICA[s]:
                w_["tipo_layer"].addItem(voce, k)
        r3b.addWidget(QLabel("tipo:"))
        r3b.addWidget(w_["tipo_layer"], 1)
        b2 = QPushButton("Aggiungi")
        b2.setToolTip("Aggiunge i poligoni del layer (es. vincoli SITR, centri storici, piano "
                      "paesaggistico, perimetro del parco) all'elenco delle aree.")
        b2.clicked.connect(lambda _=False, k=s: self._vin_da_layer(k))
        r3b.addWidget(b2)
        vb.addLayout(r3)
        vb.addLayout(r3b)
        w_["tab_aree"] = QTableWidget(0, 6)
        w_["tab_aree"].setHorizontalHeaderLabels(
            ["Incl.", "Area / vincolo", "Codice", "Rete dentro (m)", "Fonte", "Valida"])
        w_["tab_aree"].setSelectionBehavior(QAbstractItemView.SelectRows)
        w_["tab_aree"].setMinimumHeight(150)
        w_["tab_aree"].horizontalHeader().setStretchLastSection(True)
        w_["tab_aree"].setToolTip("Doppio clic: zoom sull'area.")
        w_["tab_aree"].cellDoubleClicked.connect(lambda r, c, k=s: self._vin_zoom_area(k, r))
        _P.attiva_valida(w_["tab_aree"], CA_INCL, CA_VALIDA,
                         lambda r, k=s: self._vin_area_proposta(k, r))
        v2.addWidget(w_["tab_aree"])
        from . import ftth_trovati as _TR
        # «Mostra in mappa» scrive le aree spuntate nel GeoPackage accanto al
        # progetto (01_File shp) e le mette nel gruppo della scheda
        v2.addLayout(_TR.riga_pulsanti(
            w_["tab_aree"], CA_INCL, "le aree",
            proposti=lambda r, k=s: self._vin_area_proposta(k, r),
            mostra=lambda k=s: self._vin_azione(k, self._vin_mostra_aree)))
        v2.addWidget(_P.proposte(self))
        r_map = QHBoxLayout()
        b_dis = QPushButton("Disegna un'area a mano…")
        b_dis.setToolTip(
            "Crea (se manca) il layer «%s» accanto al progetto e ti mette subito a disegnare. "
            "Finito: salva le modifiche del layer, scegli il tipo di vincolo nella riga B e "
            "premi «Aggiungi»." % NOME_DISEGNATE[s])
        b_dis.clicked.connect(lambda _=False, k=s: self._vin_azione(k, self._vin_disegna))
        r_map.addWidget(b_dis)
        r_map.addStretch()
        vb.addLayout(r_map)
        if s == "parchi":
            r4 = QHBoxLayout()
            r4b = QHBoxLayout()
            r4.addWidget(QLabel("Natura 2000: considera anche la rete entro"))
            w_["dist"] = QSpinBox()
            w_["dist"].setRange(0, 5000)
            w_["dist"].setSingleStep(50)
            w_["dist"].setSuffix(" m")
            w_["dist"].setToolTip("La VIncA può riguardare anche lavori vicini al sito, non "
                                  "solo dentro: 0 = solo dentro il perimetro.")
            r4.addWidget(w_["dist"])
            r4.addWidget(QLabel("dal sito"))
            r4b.addWidget(QLabel("Soglia VIncA per via:"))
            w_["soglia"] = QSpinBox()
            w_["soglia"].setRange(1, 10000)
            w_["soglia"].setValue(V.SOGLIA_VINCA_M)
            w_["soglia"].setSuffix(" m")
            r4b.addWidget(w_["soglia"])
            # il significato dei due valori è nel Leggimi in testa alla scheda
            # (stessa posizione e stile delle altre schede istanze)
            w_["dist"].setToolTip(
                "La Valutazione di Incidenza può riguardare anche lavori FUORI dal sito che "
                "possono incidere su di esso. 0 = conta solo la rete dentro il perimetro; con un "
                "valore conta anche quella entro quella distanza (vedi la norma regionale).")
            w_["soglia"].setToolTip(
                "Si sommano i metri di scavo nuovo della stessa via dentro il sito: sotto la "
                "soglia esclusione VIncA (autodichiarazione, 30 giorni); da qui in su screening "
                "VIncA con il Format proponente.")
            r4.addStretch()
            r4b.addStretch()
            v2.addLayout(r4)
            v2.addLayout(r4b)
        v2.addWidget(self._vin_avviso())
        v2.addWidget(gb_b)              # avanzate: sempre in fondo al passo
        v.addWidget(gb2)

        # 3) interferenze
        gb3 = self._gruppo(_P.titolo(3, sez), compresso=False)
        v3 = QVBoxLayout(gb3)
        r5 = QHBoxLayout()
        b3 = _P.primario("Trova le interferenze", lambda _=False, k=s: self._vin_trova(k))
        r5.addWidget(b3)
        w_["btn_trova"] = b3
        from .ftth_barra import crea_barra
        w_["bar_trova"] = crea_barra(r5)
        v3.addLayout(r5)
        w_["tab"] = QTableWidget(0, 7)
        w_["tab"].setHorizontalHeaderLabels(
            ["Incl.", "N.", "Area", "Via (modificabile)", "Lavori",
             "Pratica" if s == "sopr" else "Esito", "Note"])
        w_["tab"].setMinimumHeight(170)
        w_["tab"].horizontalHeader().setStretchLastSection(True)
        w_["tab"].cellDoubleClicked.connect(lambda r, c, k=s: self._vin_zoom_intervento(k, r, c))
        v3.addWidget(w_["tab"])
        v3.addLayout(_TR.riga_pulsanti(
            w_["tab"], CI_INCL, "gli interventi",
            mostra=lambda k=s: self._vin_azione(k, self._vin_mostra_interventi)))
        v3.addWidget(_P.nota3(self, "La colonna Via si corregge con un clic."))
        # conferma e vista per istanza: dentro il passo 3, come in tutte le schede
        try:
            from . import ftth_gruppi_istanze as _GR
            v3.addWidget(_GR.riquadro(self, sez, lambda k=s: self._vin_istanze_per_gruppi(k)))
        except Exception:  # noqa: BLE001
            pass
        v.addWidget(gb3)

        # 4) enti e destinatari (+ Comune in e.p.c.)
        gb4 = self._gruppo(_P.titolo(4, sez), compresso=False)
        v4 = QVBoxLayout(gb4)
        f_doc = None
        if s == "sopr":
            v4.addWidget(_P.nota4(self, "La Soprintendenza competente per il comune."))
            f4 = QFormLayout()
            w_["dest_nome"] = QLineEdit()
            w_["dest_nome"].setPlaceholderText("Soprintendenza Archeologia, Belle Arti e "
                                               "Paesaggio per ...")
            w_["dest_ind"] = QLineEdit()
            w_["dest_pec"] = QLineEdit()
            f4.addRow("Soprintendenza:", w_["dest_nome"])
            f4.addRow("Indirizzo:", w_["dest_ind"])
            f4.addRow("PEC:", w_["dest_pec"])
            _P.comune_epc(f4, w_["ind_comune"], w_["pec_comune"])
            v4.addLayout(f4)
            # contenuto dei documenti: al passo 5, con la generazione
            f_doc = QFormLayout()
            w_["chk_rel"] = QCheckBox("Relazione paesaggistica semplificata (Allegato D)")
            w_["chk_rel"].setChecked(True)
            w_["chk_np"] = QCheckBox("Dichiarazione di non parentela (L. 190/2012)")
            w_["chk_np"].setToolTip("La chiedono alcune Soprintendenze (es. Viterbo, Trapani).")
            f_doc.addRow(w_["chk_rel"])
            f_doc.addRow(w_["chk_np"])
            w_["contesto"] = QComboBox()
            for c in D.CONTESTI:
                w_["contesto"].addItem(c)
            w_["contesto"].setCurrentText("area urbana")
            w_["morfologia"] = QComboBox()
            for m in D.MORFOLOGIE:
                w_["morfologia"].addItem(m)
            w_["piano"] = QLineEdit()
            w_["piano"].setPlaceholderText("es. Piano Territoriale Paesistico Regionale")
            f_doc.addRow("Contesto paesaggistico:", w_["contesto"])
            f_doc.addRow("Morfologia:", w_["morfologia"])
            f_doc.addRow("Piano paesaggistico:", w_["piano"])
        else:
            v4.addWidget(_P.nota4(self, "Un destinatario per area protetta o sito (si "
                                        "compila dopo «Trova le interferenze»)."))
            w_["tab_dest"] = QTableWidget(0, 4)
            w_["tab_dest"].setHorizontalHeaderLabels(["Area", "Ente", "Indirizzo", "PEC"])
            w_["tab_dest"].setMinimumHeight(110)
            w_["tab_dest"].horizontalHeader().setStretchLastSection(True)
            v4.addWidget(w_["tab_dest"])
            f4 = QFormLayout()
            _P.comune_epc(f4, w_["ind_comune"], w_["pec_comune"])
            v4.addLayout(f4)
            f_doc = QFormLayout()
            w_["contesto"] = QComboBox()
            for c in D.CONTESTI_VINCA:
                w_["contesto"].addItem(c)
            w_["contesto"].setCurrentText("Zona periurbana")
            f_doc.addRow("Contesto (Format VIncA):", w_["contesto"])
        v.addWidget(gb4)

        # 5) foto (e sezioni) ed etichette (quello che si disegna in mappa)
        gb_f = self._gruppo(_P.titolo(5, sez), compresso=False)
        v_f = QVBoxLayout(gb_f)
        v_f.addWidget(_P.nota5(
            self, sez,
            "In ogni tavola il riquadro in basso a destra è tutto per le foto (1, 2 o 4, "
            "come scelto al punto 6)." if s == "sopr" else
            "Il fotoinserimento della tavola n va in 04_Foto come FOTOINSERIMENTO n.jpg."))
        w_["scala"] = _P.combo_scala("%s_scala_tavole" % s, "la stessa per tutte, almeno 1:1000")
        r_t, w_["lbl_tavole"] = _P.riga_tavole(self, w_["scala"],
                                               lambda k=s: self._vin_calcola_tavole(k), s)
        v_f.addLayout(r_t)
        v_f.addLayout(_P.riga_fotosez(self, lambda *_a, k=s: self._rfi_prepara_foto_sezioni(k),
                                      solo_foto=(s == "sopr"), ente=s))
        v.addWidget(gb_f)
        # 6) stampa: opzioni dei documenti, Genera, registro
        gb5 = self._gruppo(_P.titolo(6, sez), compresso=False)
        v5 = QVBoxLayout(gb5)
        v5.addLayout(f_doc)
        f5 = QFormLayout()
        w_["righe"] = QComboBox()
        for k, d in A.RIGHE_TABELLE.items():
            w_["righe"].addItem(d, k)
        w_["righe"].setCurrentIndex(max(0, w_["righe"].findData("via_coordinate")))
        f5.addRow("Tratti nelle tabelle RT:", w_["righe"])
        w_["orto"] = QComboBox()
        self._vin_aggiorna_orto(s)
        f5.addRow("Ortofoto per le tavole:", w_["orto"])
        if s == "sopr":
            w_["foto_tav"] = QComboBox()
            w_["foto_tav"].addItem("1 foto (tutto il riquadro)", 1)
            w_["foto_tav"].addItem("2 foto (una sopra l'altra)", 2)
            w_["foto_tav"].addItem("4 foto (griglia 2x2)", 4)
            w_["foto_tav"].setCurrentIndex(1)
            f5.addRow("Foto per tavola:", w_["foto_tav"])
            w_["chk_armadi"] = QCheckBox(
                "Solo armadi (elementi fuori terra): una tavola per armadio")
            w_["chk_armadi"].setToolTip(
                "L'istanza riguarda solo gli elementi fuori terra (armadi e, se spuntate qui "
                "sotto, colonnine PTE): relazione e documenti contano solo loro, ogni tavola è "
                "la planimetria dell'area di un elemento. In planimetria si vedono comunque lo "
                "scavo e il pozzetto vicini.")
            # spuntato propone 1 foto a tutto riquadro (resta modificabile)
            w_["chk_armadi"].toggled.connect(
                lambda si, c=w_["foto_tav"]: c.setCurrentIndex(c.findData(1 if si else 2)))
            f5.addRow(w_["chk_armadi"])
            # colonnine PTE nuove (layer ROE PTE): elementi fuori terra come gli
            # armadi, ma solo se l'utente le vuole nell'istanza
            w_["chk_colonnine"] = QCheckBox(
                "Colonnine PTE nuove come elementi fuori terra (insieme agli armadi)")
            w_["chk_colonnine"].setToolTip(
                "Facoltativo. Le colonnine PTE nuove (layer ROE PTE, TIPO «Colonnina» con il "
                "flag NewColonnina) trovate nelle aree entrano nell'istanza come gli armadi: "
                "conteggi, relazione, planimetria e «Solo armadi». Non spuntato = le colonnine "
                "restano fuori dall'istanza.")
            w_["chk_colonnine"].setChecked(self._vin_voce(s, "colonnine") == "1")
            f5.addRow(w_["chk_colonnine"])
            w_["chk_pc_col"] = QCheckBox("Aggiungi particolare costruttivo colonnina")
            w_["chk_pc_col"].setToolTip(
                "Mette nella tavola PC (particolari costruttivi) il disegno della colonnina PTE "
                "con lo zoccolo di ancoraggio quotato, in aggiunta agli altri particolari.")
            w_["chk_pc_col"].setChecked(self._vin_voce(s, "pc_colonnina") == "1")
            # le colonnine nell'istanza propongono anche il loro particolare
            w_["chk_colonnine"].toggled.connect(
                lambda si, c=w_["chk_pc_col"]: c.setChecked(True) if si else None)
            f5.addRow(w_["chk_pc_col"])
            # cosa mettere nell'istanza: tutto, proposta dal tipo di vincolo
            # (DPR 31/2017 All. A, A.15) o scelta manuale dell'utente
            w_["incl_modo"] = QComboBox()
            w_["incl_modo"].addItem("Tutto (trincea, no-dig, pozzetti, armadi, mini/micro)",
                                    "tutto")
            w_["incl_modo"].addItem("Proposta dal vincolo, area per area (DPR 31/2017)",
                                    "proposta")
            w_["incl_modo"].addItem("Scelta manuale", "manuale")
            w_["incl_modo"].setToolTip(
                "Proposta dal vincolo: per ogni intervento guarda il vincolo dell'area. Con "
                "l'art. 142 (escluse lett. g e m) mette nell'istanza solo armadi e "
                "mini/microtrincea da comunicare; con archeologia, art. 136, centri storici "
                "anche scavi tradizionali, no-dig e pozzetti. Vedi il Leggimi.")
            r_incl = QHBoxLayout()
            r_incl.addWidget(w_["incl_modo"], 1)
            try:
                from . import ftth_leggimi as _LG
                r_incl.addWidget(_LG.pulsante(self, "soprintendenza", "📖 Quale vincolo?"))
            except Exception:  # noqa: BLE001
                pass
            f5.addRow("Cosa mettere nell'istanza:", r_incl)
            w_["incl"] = {}
            r_chk = QHBoxLayout()
            for k, nome in V.ELEMENTI_SOPR.items():
                c = QCheckBox(nome)
                c.setChecked(True)
                w_["incl"][k] = c
                r_chk.addWidget(c)
            r_chk.addStretch()
            w_["incl_box"] = QWidget()
            w_["incl_box"].setLayout(r_chk)
            f5.addRow("", w_["incl_box"])

            def _modo_incl(*_a, w_=w_):
                modo = w_["incl_modo"].currentData()
                w_["incl_box"].setEnabled(modo == "manuale")
                w_["incl_box"].setVisible(modo == "manuale")
            w_["incl_modo"].currentIndexChanged.connect(_modo_incl)
            _modo_incl()
        v5.addLayout(f5)
        # geoportale consultato: link e/o estratto della mappa dei vincoli, a
        # lato della corografia (prima tavola della PL). Facoltativi: avanzate
        gb5_av = self._gruppo("Avanzate: geoportale, PDF e loghi")
        v5_av = QVBoxLayout(gb5_av)
        f5 = QFormLayout()
        v5_av.addLayout(f5)
        w_["geo_link"] = QLineEdit()
        w_["geo_link"].setPlaceholderText(
            "facoltativo, es. http://www.sitap.beniculturali.it/" if s == "sopr" else
            "facoltativo, es. https://gn.mase.gov.it/ (Natura 2000) o il geoportale del parco")
        w_["geo_link"].setText(self._vin_voce(s, "geo_link"))
        f5.addRow("Link al geoportale consultato:", w_["geo_link"])
        r_geo = QHBoxLayout()
        w_["geo_img"] = QLineEdit()
        w_["geo_img"].setPlaceholderText("facoltativo: screenshot della mappa con i vincoli")
        w_["geo_img"].setText(self._vin_voce(s, "geo_img"))
        b_geo = QPushButton("Sfoglia…")
        b_geo.clicked.connect(lambda _=False, k=s: self._vin_scegli_estratto(k))
        r_geo.addWidget(w_["geo_img"], 1)
        r_geo.addWidget(b_geo)
        f5.addRow("Estratto della mappa (immagine):", r_geo)
        w_["chk_pl"] = QCheckBox("Genera la planimetria 1.1 PL (layout QGIS + PDF)")
        w_["chk_pl"].setChecked(True)
        w_["chk_pdf"] = QCheckBox("Converti in PDF anche gli altri documenti (la RT è sempre "
                                  "in PDF)")
        v5_av.addWidget(w_["chk_pdf"])
        try:    # logo FiberCop «Milano Cortina 2026» (stessa casella in tutte le schede)
            from . import ftth_logo as _LOGO
            v5_av.addWidget(_LOGO.crea_checkbox(self))
            pass  # N. ARLO: ora in vista sopra «Genera le istanze» (ftth_passi.riga_genera)
        except Exception:  # noqa: BLE001
            pass
        v5.addWidget(w_["chk_pl"])
        v5.addWidget(gb5_av)
        r6, _bg = _P.riga_genera(lambda _=False, k=s: self._vin_genera(k),
                                 lambda _=False, k=s: self._vin_apri_cartella(k),
                                 self, "_vin_log", etichette_in=v_f, ente=s)
        v5.addLayout(r6)
        w_["log"] = QPlainTextEdit()
        w_["log"].setReadOnly(True)
        w_["log"].setMinimumHeight(110)
        v5.addWidget(w_["log"])
        v.addWidget(gb5)
        v.addStretch()
        self._vin_ripristina(s)
        return w

    # ---------------------------------------------------------- utilità
    def _vin_barra(self):
        try:
            try:
                from .ftth_barra import BarraAvanzamento
            except ImportError:
                from ftth_barra import BarraAvanzamento
            b = BarraAvanzamento()
            b.setVisible(False)
            return b
        except Exception:  # noqa: BLE001
            return None

    def _vin_avviso(self):
        V, D, A = _mod()
        lbl = QLabel("⚠ I perimetri scaricati (SITAP, EEA, geoportali) sono ricognitivi: "
                     "vanno verificati sulle fonti ufficiali e con l'ente prima di presentare "
                     "l'istanza. Gli scavi esistenti non contano.")
        lbl.setWordWrap(True)
        lbl.setStyleSheet("color:#8a5a00; font-style:italic;")
        return lbl

    def _vin_log(self, s, msg):
        log = self._vin_w[s]["log"]
        log.appendPlainText(str(msg))
        log.repaint()

    def _vin_aggiorna_orto(self, s):
        cb = self._vin_w[s]["orto"]
        cb.clear()
        cb.addItem("automatico (ortofoto del progetto o Esri World Imagery)", None)
        try:
            from qgis.core import QgsRasterLayer
            for l in self.project.mapLayers().values():
                if isinstance(l, QgsRasterLayer):
                    cb.addItem(l.name(), l.id())
        except Exception:  # noqa: BLE001
            pass

    def _vin_interrompi(self, s):
        self._vin_st[s]["stop"] = True

    def _vin_controlla(self, s):
        if self._vin_st[s].get("stop"):
            raise _Interrotta()

    def _vin_fase(self, s, da, a, testo):
        self._vin_controlla(s)
        b = self._vin_w[s].get("bar")
        if b is not None:
            b.fase(da, a, testo)
        self._vin_log(s, testo + "…")
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

    def _vin_sottofondo(self, s, funzione, *args):
        import concurrent.futures as cf
        import time as _t
        from qgis.PyQt.QtWidgets import QApplication
        ex = cf.ThreadPoolExecutor(max_workers=1)
        fut = ex.submit(funzione, *args)
        try:
            while not fut.done():
                QApplication.processEvents()
                self._vin_controlla(s)
                b = self._vin_w[s].get("bar")
                if b is not None:
                    b.avanza()
                _t.sleep(0.1)
            return fut.result()
        finally:
            ex.shutdown(wait=False)

    def _vin_ripristina(self, s):
        prj = getattr(self, "project", None)
        if prj is None:
            return
        w_ = self._vin_w[s]
        for chiave in ("comune", "prov", "cap", "pec_comune", "ind_comune", "dest_nome",
                       "dest_ind", "dest_pec", "piano", "geo_link", "geo_img"):
            if chiave in w_:
                val, ok = prj.readEntry(PRJ_SCOPE[s], chiave, "")
                if ok and val:
                    w_[chiave].setText(val)
        for chiave, nome_w in (("colonnine", "chk_colonnine"), ("pc_colonnina", "chk_pc_col")):
            if nome_w in w_:
                val, ok = prj.readEntry(PRJ_SCOPE[s], chiave, "")
                if ok and val:
                    w_[nome_w].setChecked(val == "1")

    def _vin_voce(self, s, chiave):
        prj = getattr(self, "project", None)
        if prj is None:
            return ""
        v, _ok = prj.readEntry(PRJ_SCOPE[s], chiave, "")
        return v or ""

    def _vin_scegli_estratto(self, s):
        from qgis.PyQt.QtWidgets import QFileDialog
        w_ = self._vin_w[s]
        partenza = os.path.dirname(w_["geo_img"].text().strip()) or \
            (self.project.homePath() or os.path.expanduser("~"))
        f, _ = QFileDialog.getOpenFileName(self, "Estratto della mappa dei vincoli", partenza,
                                           "Immagini (*.png *.jpg *.jpeg)")
        if f:
            w_["geo_img"].setText(f)

    def _vin_salva_voci(self, s):
        prj = getattr(self, "project", None)
        if prj is None:
            return
        w_ = self._vin_w[s]
        for chiave in ("comune", "prov", "cap", "pec_comune", "ind_comune", "dest_nome",
                       "dest_ind", "dest_pec", "piano", "geo_link", "geo_img"):
            if chiave in w_:
                prj.writeEntry(PRJ_SCOPE[s], chiave, w_[chiave].text().strip())
        if s == "parchi":
            prj.writeEntry(PRJ_SCOPE[s], "dest", json.dumps(self._vin_destinatari(s)))
        for chiave, nome_w in (("colonnine", "chk_colonnine"), ("pc_colonnina", "chk_pc_col")):
            if nome_w in w_:
                prj.writeEntry(PRJ_SCOPE[s], chiave, "1" if w_[nome_w].isChecked() else "0")

    # ------------------------------------------------------ aree: scarica
    def _vin_scarica(self, s):
        w_ = self._vin_w[s]
        st = self._vin_st[s]
        st["stop"] = False
        w_["stop"].setVisible(True)
        try:
            self._vin_scarica_impl(s)
            if w_.get("bar") is not None:
                w_["bar"].fine("Aree caricate: %d" % len(st["aree"]))
        except _Interrotta:
            self._vin_log(s, "Interrotto.")
            if w_.get("bar") is not None:
                w_["bar"].interrotta("Interrotto")
        except Exception as e:  # noqa: BLE001
            import traceback
            self._vin_log(s, "ERRORE:\n" + traceback.format_exc())
            if w_.get("bar") is not None:
                w_["bar"].interrotta("Errore")
            QMessageBox.critical(self, "Errore", str(e))
        finally:
            w_["stop"].setVisible(False)

    def _vin_scarica_impl(self, s):
        V, D, A = _mod()
        try:
            from . import ftth_screening as scr
        except ImportError:
            import ftth_screening as scr
        w_ = self._vin_w[s]
        st = self._vin_st[s]
        nome = w_["comune"].text().strip()
        if not nome:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune al punto 1.")
            return
        w_["log"].clear()
        self._vin_fase(s, 0, 15, "1/4 confine e dati del comune")
        c = self._vin_sottofondo(s, scr.risolvi_comune, nome, None)
        if not c.data:
            QMessageBox.warning(self, "Comune non trovato", c.errore or "Comune non risolto.")
            return
        d = c.data
        geom, bbox = d.get("geometry"), d.get("bbox")
        st["regione"] = d.get("regione") or ""
        st["provincia"] = d.get("provincia") or ""
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        if not w_["prov"].text().strip() and d.get("provincia"):
            w_["prov"].setText(rfi.sigla_provincia(d.get("provincia")) or "")
        if not w_["cap"].text().strip() and d.get("cap"):
            w_["cap"].setText(str(d.get("cap")).split(";")[0].strip())
        self._vin_log(s, "Comune: %s (%s) — %s" % (d.get("nome") or nome, w_["prov"].text(),
                                                   st["regione"] or "?"))
        geometrie, fonti = [], []
        if s == "sopr":
            self._vin_fase(s, 15, 50, "2/4 vincoli art. 136 e 142 (SITAP)")
            vi = self._vin_sottofondo(s, scr.vincoli_paesaggistici, geom, bbox, True)
            geometrie += vi.geometrie or []
            fonti.append("SITAP")
            self._vin_fase(s, 50, 70, "3/4 fasce art. 142 lett. a e c (costa e fiumi)")
            tr, geo, coperta, err = self._vin_sottofondo(
                s, scr.fasce_142_regionali, geom, bbox, st["regione"], True)
            geometrie += geo or []
            if not coperta:
                tr, geo, coperta, err = self._vin_sottofondo(
                    s, scr.vincoli_142_sicilia, geom, bbox, st["provincia"], True)
                geometrie += geo or []
                if coperta:
                    fonti.append("SITR Sicilia")
            self._vin_fase(s, 70, 85, "4/4 Soprintendenza competente")
            so = self._vin_sottofondo(s, scr.soprintendenza_competente, geom, bbox)
            st["soprintendenze"] = so.data or []
            pae = [x for x in st["soprintendenze"] if "paesagg" in (x.get("ambito") or "").lower()
                   and not x.get("marginale")] or st["soprintendenze"]
            if pae and not w_["dest_nome"].text().strip():
                w_["dest_nome"].setText(pae[0].get("denominazione") or "")
                w_["dest_pec"].setText(pae[0].get("pec") or "")
                self._vin_log(s, "Soprintendenza competente (SITAP): %s" %
                              (pae[0].get("denominazione") or "?"))
        else:
            self._vin_fase(s, 15, 50, "2/4 aree protette (parchi EUAP, SITAP)")
            pa = self._vin_sottofondo(s, scr.parchi_intercettati, geom, True)
            geometrie += pa.geometrie or []
            self._vin_fase(s, 50, 85, "3/4 siti Rete Natura 2000 (EEA)")
            n2 = self._vin_sottofondo(s, scr.natura2000_intercettati, geom, bbox, True)
            geometrie += n2.geometrie or []
            fonti.append("SITAP/EEA")
        nuove = [a for a in V.aree_da_geometrie(geometrie, " + ".join(fonti))
                 if a.scheda() == SCHEDA_LOGICA[s]]
        # strade con nome intorno al progetto: servono per la colonna Via
        self._vin_fase(s, 85, 99, "nomi delle vie (OSM)")
        self._vin_strade(s)
        self._vin_aggiungi_aree(s, nuove)
        self._vin_log(s, "Aree trovate: %d. Spuntate quelle in cui passa la rete." % len(nuove))
        if not nuove:
            self._vin_log(s, "Nessuna area dalle fonti online: se il vincolo c'è, caricalo da "
                             "un layer (punto B).")
        self._vin_salva_voci(s)

    def _vin_tratte_wgs(self):
        rete = self._acq_rete() if hasattr(self, "_acq_rete") else None
        if not rete:
            return []
        return [t["geom"] for t in rete[0] if (t.get("stato") or "").strip().lower()
                != "esistente"]

    def _vin_layer_pte(self):
        """Layer dei PTE (ROE PTE) del progetto, o None."""
        for l in self.project.mapLayers().values():
            n = l.name().lower().replace("_", " ")
            if "roe" in n and "pte" in n and hasattr(l, "fields"):
                return l
        return None

    def _vin_colonnine(self):
        """Colonnine PTE NUOVE da posare (elementi fuori terra), in WGS84, nel
        formato di armadi: dal layer ROE PTE le righe con TIPO «Colonnina» e il
        flag di colonnina nuova (NewColoninn / NewColonin = Si/True). Senza il
        campo flag: tutte le colonnine (avviso nel registro)."""
        lyr = self._vin_layer_pte()
        if lyr is None or not lyr.isValid():
            return []
        c_tipo = self._rfi_campo(lyr, "TIPO")
        if not c_tipo:
            return []
        c_new = next((f.name() for f in lyr.fields()
                      if f.name().lower().startswith("newcolon")), None)
        c_sta = self._rfi_campo(lyr, "STATO")
        out = []
        for f in lyr.getFeatures():
            if not f.hasGeometry() or self._rfi_val(f, c_tipo).lower() != "colonnina":
                continue
            if c_new and self._rfi_val(f, c_new).lower() not in ("si", "sì", "true", "1",
                                                                  "yes", "s", "t"):
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            out.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                        "stato": "Nuovo" if c_new else self._rfi_val(f, c_sta),
                        "id": "", "fid": f.id()})
        if not c_new and out:
            self._vin_log("sopr", "ROE PTE senza campo NewColonnina: considerate tutte le %d "
                                  "colonnine (verifica quali sono nuove)." % len(out))
        return out

    def _vin_scelta_colonnine(self, s, interf):
        """Colonnine PTE nell'istanza solo se spuntate al punto 6."""
        V, D, A = _mod()
        w_ = self._vin_w[s]
        if s != "sopr" or ("chk_colonnine" in w_ and w_["chk_colonnine"].isChecked()):
            return interf
        return V.togli_colonnine(interf)

    def _vin_filtra_elementi(self, s, interf):
        """Soprintendenza: tiene nell'istanza solo gli elementi scelti (tutto,
        proposta dal vincolo area per area, o scelta manuale). Ritorna la
        lista filtrata, o None se non resta niente (con avviso)."""
        V, D, A = _mod()
        w_ = self._vin_w[s]
        if s != "sopr" or "incl_modo" not in w_:
            return interf
        if "chk_armadi" in w_ and w_["chk_armadi"].isChecked():
            return interf                     # «Solo armadi» decide da sé
        modo = w_["incl_modo"].currentData()
        if modo == "tutto":
            return interf
        manuale = {k for k, c in w_["incl"].items() if c.isChecked()}
        out, tolte, motivi = [], 0, {}
        for i in interf:
            if not i.includi:
                out.append(i)
                continue
            if modo == "proposta":
                scelta, motivo = V.proposta_elementi(getattr(i, "vincoli", []) or [])
            else:
                scelta, motivo = manuale, "scelta manuale"
            j = V.filtra_elementi(i, scelta)
            if j is None:
                tolte += 1
            else:
                out.append(j)
            motivi.setdefault(motivo, 0)
            motivi[motivo] += 1
        self._vin_log(s, "Cosa mettere nell'istanza: %s." % w_["incl_modo"].currentText())
        for m, n in motivi.items():
            self._vin_log(s, "  - %d interventi: %s" % (n, m))
        if tolte:
            self._vin_log(s, "  %d interventi esclusi del tutto: non avevano elementi da "
                             "presentare." % tolte)
        if not any(i.includi for i in out):
            QMessageBox.warning(self, "Niente da presentare",
                                "Con la scelta fatta non resta nessun elemento da presentare "
                                "alla Soprintendenza.")
            return None
        return out

    def _vin_strade_progetto(self, sud, ovest, nord, est):
        """[(LineString WGS84, nome)] da un layer di strade del progetto con il
        nome della via (DBSN Strade, stradario…), nell'area data. Vuoto se
        non c'è."""
        import re as _re
        from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                               QgsFeatureRequest, QgsRectangle, QgsVectorLayer, QgsWkbTypes)
        from shapely import wkt as _wkt
        campi_nome = ("name", "nome", "toponimo", "denominaz", "denominazione", "nome_strada",
                      "nome_via", "via", "odonimo")
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        prj = getattr(self, "project", None)
        if prj is None:
            return []
        for lyr in prj.mapLayers().values():
            try:
                if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid() or \
                        lyr.geometryType() != QgsWkbTypes.LineGeometry:
                    continue
                if not _re.search(r"strad|viabilit|odonim|toponom", lyr.name().lower()) or \
                        _re.search(r"infrastruttur|fasc|classificat", lyr.name().lower()):
                    continue
                nomi = {f.name().lower(): f.name() for f in lyr.fields()}
                campo = next((nomi[c] for c in campi_nome if c in nomi), None)
                if campo is None:
                    continue
                tr_in = QgsCoordinateTransform(wgs, lyr.crs(), prj)
                tr_out = QgsCoordinateTransform(lyr.crs(), wgs, prj)
                area = tr_in.transformBoundingBox(QgsRectangle(ovest, sud, est, nord))
                out = []
                for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(area)):
                    nome = f[campo]
                    if not f.hasGeometry() or nome in (None, "") or str(nome) == "NULL":
                        continue
                    g = f.geometry()
                    g.transform(tr_out)
                    try:
                        sg = _wkt.loads(g.asWkt())
                    except Exception:  # noqa: BLE001
                        continue
                    for parte in getattr(sg, "geoms", [sg]):
                        out.append((parte, str(nome).strip()))
                if len(out) >= 5:
                    self._vin_strade_fonte = lyr.name()
                    return out
            except Exception:  # noqa: BLE001
                continue
        return []

    def _vin_strade(self, s):
        """Strade con nome intorno alla rete (Overpass), per la colonna Via."""
        st = self._vin_st[s]
        tr = self._vin_tratte_wgs()
        if not tr or not hasattr(self, "_acq_overpass_parallelo"):
            return
        from shapely.ops import unary_union
        V, D, A = _mod()
        x0, y0, x1, y1 = unary_union(tr).bounds
        m = 0.002
        # prima uno stradario del progetto (istantaneo, non dipende da OSM)
        locali = self._vin_strade_progetto(y0 - m, x0 - m, y1 + m, x1 + m)
        if locali:
            st["strade"] = locali
            self._vin_log(s, "Nomi delle vie dal layer del progetto «%s» (%d tratti)."
                          % (self._vin_strade_fonte, len(locali)))
            return
        q = ('[out:json][timeout:60];way["highway"]["name"](%.5f,%.5f,%.5f,%.5f);out tags geom qt;'
             % (y0 - m, x0 - m, y1 + m, x1 + m))
        # cache di 30 giorni: rilanciando la ricerca i nomi non si riscaricano
        import hashlib
        import json as _json
        import time as _t
        cache = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache",
                             "overpass_vie_%s.json" % hashlib.md5(q.encode()).hexdigest())
        els = err = None
        if os.path.isfile(cache) and _t.time() - os.path.getmtime(cache) < 30 * 86400:
            try:
                with open(cache, encoding="utf-8") as fh:
                    els = _json.load(fh)
            except Exception:  # noqa: BLE001
                els = None
        if els is None:
            try:
                # gui=False: gira in un thread a parte, non deve toccare
                # l'interfaccia (prima la ricerca si piantava al 97%)
                els, err = self._vin_sottofondo(
                    s, lambda: self._acq_overpass_parallelo(q, 60, gui=False))
            except _Interrotta:
                raise
            except Exception as e:  # noqa: BLE001
                els, err = None, str(e)
            if els:
                try:
                    os.makedirs(os.path.dirname(cache), exist_ok=True)
                    with open(cache, "w", encoding="utf-8") as fh:
                        _json.dump(els, fh)
                except Exception:  # noqa: BLE001
                    pass
        if els:
            st["strade"] = A.da_osm(els)["strade"]
        elif err:
            self._vin_log(s, "Nomi delle vie non scaricati (%s): la via si scrive in tabella."
                          % err)

    # ----------------------------------------------------- aree: da layer
    def _vin_da_layer(self, s):
        V, D, A = _mod()
        w_ = self._vin_w[s]
        lyr = w_["layer"].currentLayer()
        if lyr is None or not lyr.isValid():
            QMessageBox.warning(self, "Layer", "Scegli un layer di poligoni.")
            return
        from shapely.ops import unary_union
        campo = w_["campo"].currentField()
        tipo = w_["tipo_layer"].currentData()
        per_nome = {}
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            if g.geom_type not in ("Polygon", "MultiPolygon"):
                continue
            if not g.is_valid:
                g = g.buffer(0)
            n = self._rfi_val(f, campo) if campo else ""
            per_nome.setdefault(n, []).append(g)
        nuove = []
        for n, gg in per_nome.items():
            nuove.append(V.AreaVincolo(
                tipo=tipo, nome=n, geom=unary_union(gg), fonte=lyr.name(),
                ente_tipo={"parco": "parco", "natura2000": "natura2000"}.get(tipo,
                                                                            "soprintendenza")))
        self._vin_aggiungi_aree(s, nuove)
        self._vin_log(s, "Dal layer «%s»: %d aree." % (lyr.name(), len(nuove)))

    def _vin_aggiungi_aree(self, s, nuove):
        V, D, A = _mod()
        st = self._vin_st[s]
        chiavi = {a.chiave() for a in st["aree"]}
        tratte = self._vin_tratte_wgs()
        dist = self._vin_w[s]["dist"].value() if "dist" in self._vin_w[s] else 0
        for a in nuove:
            if a.chiave() in chiavi:
                continue
            g0 = a.geom
            if a.tipo == "natura2000" and dist:
                # misura con la stessa distanza usata per le interferenze
                try:
                    from . import ftth_rfi as rfi
                except ImportError:
                    import ftth_rfi as rfi
                c = g0.centroid
                pr = rfi._Proiezione(c.x, c.y)
                a.geom = pr.indietro(pr.avanti(g0).buffer(dist))
            a.metri_rete = V.metri_rete_in_area(a, tratte)
            a.geom = g0
            # proposta (rete dentro) = solo evidenziata: si conferma al punto 2
            a.includi = False
            st["aree"].append(a)
        self._vin_riempi_aree(s)

    def _vin_riempi_aree(self, s):
        st = self._vin_st[s]
        t = self._vin_w[s]["tab_aree"]
        t.blockSignals(True)
        t.setRowCount(0)
        for a in st["aree"]:
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem("")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if a.includi else Qt.Unchecked)
            t.setItem(r, CA_INCL, it)
            for c, val in ((CA_VOCE, a.voce()), (CA_CODICE, a.codice),
                           (CA_METRI, "%d" % getattr(a, "metri_rete", 0)), (CA_FONTE, a.fonte)):
                x = QTableWidgetItem(str(val or ""))
                x.setFlags(x.flags() & ~Qt.ItemIsEditable)
                t.setItem(r, c, x)
        t.blockSignals(False)
        from . import ftth_passi as _P
        _P.valida_tutte(t, CA_INCL, CA_VALIDA, lambda r: self._vin_area_proposta(s, r))
        t.resizeColumnsToContents()

    # ------------------------------------------------- aree nel progetto
    def _vin_azione(self, s, fn):
        """Errori sempre a video e nel registro della scheda."""
        try:
            fn(s)
        except Exception as e:  # noqa: BLE001
            import traceback
            self._vin_log(s, "ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore", str(e))

    def _vin_gruppo(self, s):
        root = self.project.layerTreeRoot()
        g = root.findGroup(GRUPPO[s])
        if g is not None:
            return g
        from . import ftth_gruppi_istanze as _GRp
        return _GRp.gruppo_sezione(root, s).insertGroup(0, GRUPPO[s])

    def _vin_cartella(self, s):
        home = self.project.homePath()
        if not home:
            return None
        cart = os.path.join(home, "01_File shp", CARTELLA[s])
        os.makedirs(cart, exist_ok=True)
        return cart

    def _vin_stile(self, s, vl, tratteggio=False):
        from qgis.PyQt.QtGui import QColor
        from qgis.core import QgsFillSymbol
        r, g, b = COLORE[s]
        sym = QgsFillSymbol.createSimple({
            "color": "%d,%d,%d,60" % (r, g, b), "outline_color": "%d,%d,%d,255" % (r, g, b),
            "outline_width": "0.6", "outline_style": "dash" if tratteggio else "solid"})
        vl.renderer().setSymbol(sym)
        vl.triggerRepaint()

    def _vin_mostra_aree(self, s):
        """Aree spuntate al punto 2 -> layer di poligoni nel progetto (GeoPackage
        accanto al progetto se è salvato, altrimenti temporaneo)."""
        from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature,
                               QgsField, QgsGeometry, QgsVectorFileWriter, QgsVectorLayer)
        from qgis.PyQt.QtCore import QVariant
        aree = [a for a in self._vin_leggi_aree(s) if a.includi]
        if not aree:
            QMessageBox.information(self, "Nessuna area", "Scarica o aggiungi le aree e "
                                    "spunta quelle da mostrare.")
            return
        prj = self.project
        crs = prj.crs() if prj.crs().isValid() else QgsCoordinateReferenceSystem("EPSG:4326")
        tr = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"), crs, prj)
        mem = QgsVectorLayer("MultiPolygon?crs=%s" % crs.authid(), NOME_AREE[s], "memory")
        pr = mem.dataProvider()
        pr.addAttributes([QgsField("vincolo", QVariant.String), QgsField("nome", QVariant.String),
                          QgsField("codice", QVariant.String), QgsField("fonte", QVariant.String),
                          QgsField("rete_m", QVariant.Int)])
        mem.updateFields()
        feats = []
        for a in aree:
            g = QgsGeometry.fromWkt(a.geom.wkt)
            g.transform(tr)
            g.convertToMultiType()
            f = QgsFeature(mem.fields())
            f.setGeometry(g)
            f.setAttributes([a.voce(), a.nome or "", a.codice or "", a.fonte or "",
                             int(getattr(a, "metri_rete", 0) or 0)])
            feats.append(f)
        pr.addFeatures(feats)
        mem.updateExtents()
        vl = mem
        cart = self._vin_cartella(s)
        if cart:
            comune = (self._vin_w[s]["comune"].text().strip() or "progetto").replace(" ", "_")
            gpkg = os.path.join(cart, "%s_%s.gpkg" % (NOME_AREE[s].replace(" ", "_"), comune))
            # già nel progetto sullo stesso file: si rinnovano le aree dentro il
            # layer invece di riscrivere un file aperto
            gia = next((l for l in prj.mapLayersByName(NOME_AREE[s])
                        if l.providerType() == "ogr"
                        and os.path.normcase(l.source().split("|")[0]) == os.path.normcase(gpkg)),
                       None)
            if gia is not None:
                pg = gia.dataProvider()
                pg.truncate()
                pg.addFeatures(feats)
                gia.updateExtents()
                gia.triggerRepaint()
                self._vin_log(s, "Aree nel progetto aggiornate: %d nel layer «%s» — %s." % (
                    len(feats), NOME_AREE[s], gpkg))
                return
            for l in prj.mapLayersByName(NOME_AREE[s]):
                prj.removeMapLayer(l.id())
            opz = QgsVectorFileWriter.SaveVectorOptions()
            opz.driverName = "GPKG"
            opz.layerName = NOME_AREE[s].replace(" ", "_")
            opz.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
            ris = QgsVectorFileWriter.writeAsVectorFormatV3(mem, gpkg, prj.transformContext(), opz)
            if ris[0] == QgsVectorFileWriter.NoError:
                vl = QgsVectorLayer("%s|layername=%s" % (gpkg, opz.layerName), NOME_AREE[s], "ogr")
            else:
                self._vin_log(s, "GeoPackage non scritto (%s): layer temporaneo." % ris[1])
        else:
            self._vin_log(s, "Progetto non salvato: le aree restano in un layer temporaneo.")
        for l in prj.mapLayersByName(NOME_AREE[s]):
            prj.removeMapLayer(l.id())
        self._vin_stile(s, vl)
        if vl.providerType() == "ogr":
            try:
                vl.saveStyleToDatabase(NOME_AREE[s], "Stile FTTH Permessi Manager", True, "")
            except Exception:  # noqa: BLE001
                pass
        prj.addMapLayer(vl, False)
        self._vin_gruppo(s).insertLayer(0, vl)
        try:
            canvas = self.iface.mapCanvas()
            est = vl.extent()
            est.scale(1.1)
            canvas.setExtent(est)
            canvas.refresh()
        except Exception:  # noqa: BLE001
            pass
        self._vin_log(s, "Aree nel progetto: %d nel layer «%s»%s." % (
            len(feats), NOME_AREE[s], (" — " + vl.source().split("|")[0])
            if vl.providerType() == "ogr" else " (temporaneo)"))

    def _vin_disegna(self, s):
        """Layer di poligoni accanto al progetto per disegnare a mano le aree che
        SITAP/SITR non danno; poi si aggiungono con la riga B."""
        from qgis.core import (QgsCoordinateReferenceSystem, QgsField, QgsFields,
                               QgsVectorFileWriter, QgsVectorLayer, QgsWkbTypes)
        from qgis.PyQt.QtCore import QVariant
        prj = self.project
        nome = NOME_DISEGNATE[s]
        vl = next(iter(prj.mapLayersByName(nome)), None)
        if vl is None:
            cart = self._vin_cartella(s)
            if not cart:
                QMessageBox.warning(self, "Progetto non salvato",
                                    "Salva prima il progetto: il layer va nella sua cartella.")
                return
            gpkg = os.path.join(cart, nome.replace(" ", "_") + ".gpkg")
            if not os.path.isfile(gpkg):
                fields = QgsFields()
                fields.append(QgsField("nome", QVariant.String))
                opz = QgsVectorFileWriter.SaveVectorOptions()
                opz.driverName = "GPKG"
                opz.layerName = nome.replace(" ", "_")
                crs = prj.crs() if prj.crs().isValid() else QgsCoordinateReferenceSystem("EPSG:4326")
                w = QgsVectorFileWriter.create(gpkg, fields, QgsWkbTypes.MultiPolygon, crs,
                                               prj.transformContext(), opz)
                del w
            vl = QgsVectorLayer("%s|layername=%s" % (gpkg, nome.replace(" ", "_")), nome, "ogr")
            if not vl.isValid():
                QMessageBox.critical(self, "Layer non creato", "Impossibile creare %s" % gpkg)
                return
            self._vin_stile(s, vl, tratteggio=True)
            try:
                vl.saveStyleToDatabase(nome, "Stile FTTH Permessi Manager", True, "")
            except Exception:  # noqa: BLE001
                pass
            prj.addMapLayer(vl, False)
            self._vin_gruppo(s).insertLayer(0, vl)
        # la riga B punta già al layer disegnato, col nome dal campo «nome»
        w_ = self._vin_w[s]
        w_["layer"].setLayer(vl)
        try:
            w_["campo"].setLayer(vl)
            w_["campo"].setField("nome")
        except Exception:  # noqa: BLE001
            pass
        try:
            self.iface.setActiveLayer(vl)
            if not vl.isEditable():
                vl.startEditing()
            self.iface.actionAddFeature().trigger()
        except Exception:  # noqa: BLE001
            pass
        testo = ("Layer «%s» pronto e in modifica.\n\n"
                 "Disegna l'area sulla mappa (clic per i vertici, tasto destro per finire) e "
                 "scrivi il nome nella scheda che si apre.\n\n"
                 "Poi salva le modifiche del layer, scegli il tipo di vincolo nella riga B "
                 "(il layer è già selezionato) e premi «Aggiungi»." % nome)
        self._vin_log(s, testo)
        QMessageBox.information(self, "Disegna un'area", testo)

    def _vin_riga_spunte(self, s, chiave, colonna, cosa):
        """Pulsanti «Seleziona tutti» / «Nessuno» sotto una tabella, come in
        Istanze Acque e RFI."""
        r = QHBoxLayout()
        for testo, si, tip in (("Seleziona tutti", True, "Spunta tutti %s dell'elenco." % cosa if cosa.startswith("gli") else "Spunta tutte %s dell'elenco." % cosa),
                               ("Nessuno", False, "Toglie tutte le spunte.")):
            b = QPushButton(testo)
            b.setToolTip(tip)
            b.clicked.connect(lambda _=False, v=si: self._vin_spunta(s, chiave, colonna, v))
            r.addWidget(b)
        r.addStretch()
        return r

    def _vin_da_screening(self, rep):
        """Punto 2 di Soprintendenza e Parchi dalle aree scaricate dallo
        screening (SITAP, parchi, Natura 2000)."""
        V, D, A = _mod()
        d = rep.get("comune") or {}
        geometrie = rep.get("_geometrie_vincoli") or []
        parti = []
        for s in ("sopr", "parchi"):
            w_ = self._vin_w.get(s) if hasattr(self, "_vin_w") else None
            if not w_:
                continue
            if d.get("nome") and not w_["comune"].text().strip():
                w_["comune"].setText(d["nome"])
            st = self._vin_st[s]
            st["regione"] = d.get("regione") or st.get("regione") or ""
            st["provincia"] = d.get("provincia") or st.get("provincia") or ""
            if s == "sopr" and not w_["dest_nome"].text().strip():
                so = [x for x in rep.get("soprintendenze") or [] if isinstance(x, dict)]
                pae = [x for x in so if "paesagg" in (x.get("ambito") or "").lower()
                       and not x.get("marginale")] or so
                if pae:
                    w_["dest_nome"].setText(pae[0].get("denominazione") or "")
                    w_["dest_pec"].setText(pae[0].get("pec") or "")
            nuove = [a for a in V.aree_da_geometrie(geometrie, "Screening")
                     if a.scheda() == SCHEDA_LOGICA[s]]
            if nuove:
                self._vin_aggiungi_aree(s, nuove)
                self._vin_log(s, "Aree dallo screening: %d." % len(nuove))
            parti.append("%s %d aree" % ("Soprintendenza" if s == "sopr" else "Parchi",
                                         len(nuove)))
        return ", ".join(parti) if geometrie else ""

    def _vin_area_proposta(self, s, r):
        aree = self._vin_st[s].get("aree") or []
        return 0 <= r < len(aree) and (getattr(aree[r], "metri_rete", 0) or 0) > 0

    def _vin_zoom_area(self, s, r):
        from . import ftth_trovati as _TR
        aree = self._vin_st[s].get("aree") or []
        if 0 <= r < len(aree):
            _TR.zoom(getattr(self, "iface", None), self.project, aree[r].geom)

    def _vin_zoom_intervento(self, s, r, c=None):
        if c == CI_VIA:
            return          # doppio clic sulla via = modifica del testo
        lst = self._vin_st[s].get("interferenze") or []
        if 0 <= r < len(lst):
            self._zoom_interf(lst[r])

    def _vin_mostra_interventi(self, s):
        if not self._vin_st[s].get("interferenze"):
            QMessageBox.information(self, "Nessun intervento",
                                    "Prima premi «Trova le interferenze».")
            return
        incl = [i for i in self._vin_leggi_tabella(s) if i.includi]
        if not incl:
            QMessageBox.information(self, "Nessun intervento", "Nessun intervento spuntato.")
            return
        sez = "sopr" if s == "sopr" else "parchi"
        self._interf_in_mappa(incl, sez, "Interventi " + ("Soprintendenza" if s == "sopr"
                                                          else "Parchi"),
                              lambda m, k=s: self._vin_log(k, m))

    def _vin_spunta(self, s, chiave, colonna, si):
        t = self._vin_w[s][chiave]
        for r in range(t.rowCount()):
            it = t.item(r, colonna)
            if it is not None:
                it.setCheckState(Qt.Checked if si else Qt.Unchecked)

    def _vin_leggi_aree(self, s):
        st = self._vin_st[s]
        t = self._vin_w[s]["tab_aree"]
        for r, a in enumerate(st["aree"]):
            it = t.item(r, CA_INCL)
            if it is not None:
                a.includi = it.checkState() == Qt.Checked
        return st["aree"]

    # --------------------------------------------------------- interferenze
    def _vin_trova(self, s):
        w_ = self._vin_w[s]
        bar = w_.get("bar_trova")
        if w_.get("btn_trova") is not None:
            w_["btn_trova"].setEnabled(False)
        try:
            if bar is not None:
                bar.azzera()
                bar.fase(0, 15, "Lettura della rete e delle aree")
            self._vin_trova_impl(s)
            if bar is not None:
                bar.fine("Interventi trovati: %d" % len(
                    self._vin_st[s].get("interferenze") or []))
        except Exception as e:  # noqa: BLE001
            import traceback
            self._vin_log(s, "ERRORE:\n" + traceback.format_exc())
            if bar is not None:
                bar.interrotta("Errore: vedi il registro")
            QMessageBox.critical(self, "Errore", "Ricerca degli interventi non riuscita:\n%s" % e)
        finally:
            if w_.get("btn_trova") is not None:
                w_["btn_trova"].setEnabled(True)

    def _vin_trova_impl(self, s):
        V, D, A = _mod()
        st = self._vin_st[s]
        w_ = self._vin_w[s]
        aree = [a for a in self._vin_leggi_aree(s) if a.includi]
        if not aree:
            QMessageBox.warning(self, "Nessuna area", "Scarica o aggiungi le aree al punto 2 e "
                                                      "spunta quelle da considerare.")
            return
        rete = self._acq_rete()
        if rete is None:
            QMessageBox.warning(self, "Layer mancante", "Manca '03 INFRASTRUTTURE' nel progetto.")
            return
        tratte, pozzetti, armadi = rete
        if not st.get("strade"):
            self._vin_strade(s)
        dist = w_["dist"].value() if "dist" in w_ else 0
        zone = V.zone_per_motore(aree, SCHEDA_LOGICA[s],
                                 ente_nome=w_["dest_nome"].text().strip() if s == "sopr" else "",
                                 distanza_natura=dist)
        from .ftth_barra import in_sottofondo
        bar = w_.get("bar_trova")
        if bar is not None:
            bar.fase(15, 95, "Ricerca degli interventi nelle aree")
        colonnine = self._vin_colonnine() if s == "sopr" else []
        interf = in_sottofondo(bar, A.trova_interferenze_acque, [], tratte, pozzetti, armadi,
                               strade=st.get("strade"), zone=zone, colonnine=colonnine)
        if s == "sopr":
            V.assegna_vincoli(interf, aree)
            n_col = 0
            for i in interf:
                k = sum(1 for e in i.elementi if e.get("tipo") == "colonnina")
                if k:
                    n_col += k
                    i.note.append("colonnina PTE nuova: entra nell'istanza solo con «Colonnine "
                                  "PTE nuove» spuntato al punto 6")
            if colonnine:
                self._vin_log(s, "Colonnine PTE nuove nel progetto: %d, nelle aree: %d "
                                 "(opzionali, punto 6)." % (len(colonnine), n_col))
        st["interferenze"] = interf
        self._vin_riempi_tabella(s)
        if s == "parchi":
            self._vin_riempi_dest(s)
        self._vin_log(s, "Interventi trovati: %d." % len(interf))
        if not interf:
            QMessageBox.information(self, "Nessun intervento",
                                    "Nessun elemento nuovo della rete cade nelle aree spuntate.")

    def _vin_esiti(self, s):
        V, D, A = _mod()
        st = self._vin_st[s]
        soglia = self._vin_w[s]["soglia"].value() if "soglia" in self._vin_w[s] \
            else V.SOGLIA_VINCA_M
        out = {}
        for area in {i.corso for i in st["interferenze"] if i.categoria == "natura2000"}:
            lst = [i for i in st["interferenze"] if i.corso == area]
            out[area] = V.esiti_vinca(lst, soglia)
        return out

    def _vin_riempi_tabella(self, s):
        V, D, A = _mod()
        st = self._vin_st[s]
        t = self._vin_w[s]["tab"]
        t.setRowCount(0)
        esiti = self._vin_esiti(s) if s == "parchi" else {}
        for i in st["interferenze"]:
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem("")
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if i.includi else Qt.Unchecked)
            t.setItem(r, CI_INCL, it)
            if s == "sopr":
                area = V.descr_vincoli(getattr(i, "vincoli", []) or []) or i.corso
                reg = V.REGIMI[V.regime_soprintendenza(i)]
            elif i.categoria == "natura2000":
                area = i.corso
                m, e = esiti.get(i.corso, {}).get(V.chiave_via(i), (0, "esonero"))
                reg = "%s — %d m nella via" % (V.ESITI_VINCA[e], m)
            else:
                area = i.corso
                reg = "Nulla osta Ente Parco (art. 13 L. 394/1991)"
            vals = {CI_N: str(i.id), CI_AREA: area, CI_VIA: i.via, CI_LAVORI: V.motivo_regime(i),
                    CI_REGIME: reg, CI_NOTE: "; ".join(i.note)}
            for c, val in vals.items():
                x = QTableWidgetItem(val or "")
                if c != CI_VIA:
                    x.setFlags(x.flags() & ~Qt.ItemIsEditable)
                t.setItem(r, c, x)
        t.resizeColumnsToContents()

    def _vin_leggi_tabella(self, s):
        st = self._vin_st[s]
        t = self._vin_w[s]["tab"]
        for r, i in enumerate(st["interferenze"]):
            it = t.item(r, CI_INCL)
            if it is not None:
                i.includi = it.checkState() == Qt.Checked
            v = t.item(r, CI_VIA)
            if v is not None:
                i.via = v.text().strip()
        return st["interferenze"]

    # ------------------------------------------------------------ destinatari
    def _vin_riempi_dest(self, s):
        V, D, A = _mod()
        st = self._vin_st[s]
        t = self._vin_w[s]["tab_dest"]
        vecchi = self._vin_destinatari(s)
        try:
            salvati = json.loads(self.project.readEntry(PRJ_SCOPE[s], "dest", "{}")[0] or "{}")
        except (ValueError, AttributeError):
            salvati = {}
        t.setRowCount(0)
        visti = []
        for i in st["interferenze"]:
            if i.corso in visti:
                continue
            visti.append(i.corso)
            d = vecchi.get(i.corso) or salvati.get(i.corso) or {}
            if not d.get("nome"):
                if i.categoria == "natura2000":
                    d["nome"] = "Regione %s - Servizio Valutazione di Incidenza" % (
                        st.get("regione") or "XXXXX")
                else:
                    nome = i.corso.replace("Area protetta", "").split("(")[0].strip()
                    d["nome"] = "Ente %s" % nome if nome else "Ente Parco"
            r = t.rowCount()
            t.insertRow(r)
            x = QTableWidgetItem(i.corso)
            x.setFlags(x.flags() & ~Qt.ItemIsEditable)
            t.setItem(r, 0, x)
            t.setItem(r, 1, QTableWidgetItem(d.get("nome") or ""))
            t.setItem(r, 2, QTableWidgetItem(d.get("indirizzo") or ""))
            t.setItem(r, 3, QTableWidgetItem(d.get("pec") or ""))
        t.resizeColumnsToContents()

    def _vin_destinatari(self, s):
        out = {}
        if s == "sopr":
            w_ = self._vin_w[s]
            return {"": {"nome": w_["dest_nome"].text().strip(),
                         "indirizzo": w_["dest_ind"].text().strip(),
                         "pec": w_["dest_pec"].text().strip()}}
        t = self._vin_w[s].get("tab_dest")
        if t is None:
            return out
        for r in range(t.rowCount()):
            def _c(c):
                it = t.item(r, c)
                return it.text().strip() if it is not None else ""
            out[_c(0)] = {"nome": _c(1), "indirizzo": _c(2), "pec": _c(3)}
        return out

    # ----------------------------------------------------------------- genera
    def _vin_genera(self, s):
        try:
            self._vin_genera_impl(s)
        except Exception as e:  # noqa: BLE001
            import traceback
            self._vin_log(s, "ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore generazione", str(e))

    def _vin_calcola_tavole(self, s):
        """Riquadri delle tavole della PL di ogni istanza (passo 5)."""
        try:
            from . import ftth_acque_layout as AL
            from . import ftth_passi as _P
            istanze = self._vin_istanze_per_gruppi(s)
            if not istanze:
                return
            scelta = self._vin_w[s]["scala"].currentData() or None

            def _riq(ist):
                crs, s_pl, tav = AL.riquadri_tavole(self.project, ist, scelta, mappa=False)
                return crs, [(s_pl, r) for _t, _c, r in tav]
            # foto e fotoinserimento al posto della sezione: niente conteggio
            _P.calcola_tavole(self, s, istanze, _riq, self._vin_w[s]["lbl_tavole"], 0)
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Tavole", "Tavole non calcolate: %s" % e)

    def _vin_istanze_per_gruppi(self, s):
        """Istanze dalle righe confermate, per i gruppi di layer nel progetto."""
        V, D, A = _mod()
        w_ = self._vin_w[s]
        st = self._vin_st[s]
        comune = w_["comune"].text().strip()
        if not comune or not st.get("interferenze"):
            QMessageBox.warning(self, "Dati mancanti",
                                "Prima scrivi il comune e trova le interferenze.")
            return None
        interf = self._vin_filtra_elementi(
            s, self._vin_scelta_colonnine(s, self._vin_leggi_tabella(s)))
        if interf is None:
            return None
        soglia = w_["soglia"].value() if "soglia" in w_ else V.SOGLIA_VINCA_M
        istanze = V.raggruppa_istanze_vincoli(interf, comune, SCHEDA_LOGICA[s], soglia)
        if "chk_armadi" in w_ and w_["chk_armadi"].isChecked():
            istanze = [ist for ist in istanze if V.solo_armadi(ist, 1)]
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza", "Nessuna riga spuntata in tabella.")
        return istanze

    def _vin_genera_impl(self, s, cartella_out=None):
        V, D, A = _mod()
        try:
            from . import ftth_rfi as rfi
            from . import ftth_acque_layout as AL
        except ImportError:
            import ftth_rfi as rfi
            import ftth_acque_layout as AL
        try:
            import docx  # noqa: F401
        except ImportError:
            QMessageBox.critical(self, "Manca python-docx",
                                 "Serve il modulo 'python-docx' (vedi scheda Istanze Acque).")
            return
        w_ = self._vin_w[s]
        st = self._vin_st[s]
        comune = w_["comune"].text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune al punto 1.")
            return
        if not st.get("interferenze"):
            QMessageBox.warning(self, "Nessun intervento",
                                "Prima premi «Trova le interferenze».")
            return
        interf = self._vin_scelta_colonnine(s, self._vin_leggi_tabella(s))
        interf = self._vin_filtra_elementi(s, interf)
        if interf is None:
            return
        soglia = w_["soglia"].value() if "soglia" in w_ else V.SOGLIA_VINCA_M
        istanze = V.raggruppa_istanze_vincoli(interf, comune, SCHEDA_LOGICA[s], soglia)
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza", "Nessuna riga spuntata in tabella.")
            return
        from . import ftth_passi as _Pf
        istanze = _Pf.filtra_istanza(self, istanze)     # «Aggiorna le etichette di: …»
        foto_tav = w_["foto_tav"].currentData() if "foto_tav" in w_ else 2
        if "chk_armadi" in w_ and w_["chk_armadi"].isChecked():
            # solo elementi fuori terra: un'interferenza e una tavola per armadio
            istanze = [ist for ist in istanze if V.solo_armadi(ist, 1)]
            if not istanze:
                QMessageBox.warning(self, "Nessun armadio",
                                    "«Solo armadi» è spuntato ma nelle righe spuntate non ci "
                                    "sono armadi (né colonnine PTE scelte al punto 6).")
                return
            self._vin_log(s, "Solo armadi: %d elementi fuori terra, %d tavole." % (
                sum(len(i.interferenze) for i in istanze),
                sum(len(i.tavole) for i in istanze)))
        if s == "sopr":
            pc_col = "chk_pc_col" in w_ and w_["chk_pc_col"].isChecked()
            for ist in istanze:
                ist.particolare_colonnina = pc_col
            if pc_col:
                self._vin_log(s, "Particolare costruttivo colonnina PTE aggiunto alla tavola PC.")
        self._vin_salva_voci(s)
        try:    # elementi aggiunti a mano al gruppo dell'istanza
            from . import ftth_gruppi_istanze as _GR
            _GR.aggiungi_da_ricerca(
                self.project, istanze, interf,
                (lambda i, ist: (i.ente_nome or "").strip() == (ist.ente_nome or "").strip())
                if s == "sopr" else
                (lambda i, ist: i.corso in (ist.corsi_chiavi or []) and
                 (i.ente_nome or "").strip() == (ist.ente_nome or "").strip()),
                lambda m, k=s: self._vin_log(k, m))
        except Exception as e:  # noqa: BLE001
            self._vin_log(s, "Elementi aggiunti a mano non considerati: %s" % e)
        if cartella_out is None:
            cartella_out = os.path.join(self.project.homePath() or os.path.expanduser("~"),
                                        TITOLI[s].replace(" / ", " - "), comune.upper())
        os.makedirs(cartella_out, exist_ok=True)
        st["cartella"] = cartella_out
        dati_c = rfi.DatiComune(comune, w_["prov"].text().strip(), w_["cap"].text().strip(),
                                w_["ind_comune"].text().strip(), w_["pec_comune"].text().strip())
        tpl = os.path.join(os.path.dirname(os.path.abspath(__file__)), "modelli_acque")
        rese = self._rfi_rese() if hasattr(self, "_rfi_rese") else None
        dest_tutti = self._vin_destinatari(s)
        aree = [a for a in st["aree"] if a.includi and a.scheda() == SCHEDA_LOGICA[s]]
        righe = w_["righe"].currentData() or "via_coordinate"
        self._vin_log(s, "Istanze da generare: %d" % len(istanze))
        da_pdf = []
        archeo_ist = []
        for ist in istanze:
            dest = dest_tutti.get("" if s == "sopr" else ist.corso, {})
            out = os.path.join(cartella_out, ist.nome_base)
            os.makedirs(out, exist_ok=True)
            testi = V.testi_istanza_vincoli(ist, dest.get("nome", ""))
            esito = getattr(ist, "esito", "")
            # Natura 2000 sotto i 200 m: niente istanza art. 49 ne' bollo,
            # solo la comunicazione con autodichiarazione (+ RT e PL come
            # descrizione sintetica e foto)
            solo = ("rt",) if esito == "esonero" else None
            prod = A.genera_documenti_istanza(ist, dati_c, dest, tpl, out, rese, righe=righe,
                                              testi=testi, solo=solo)
            docs = [os.path.basename(p) for p in prod.values() if p]
            pl_file = rfi.NOMI_FILE["pl"].format(base=ist.nome_base)
            rt_file = rfi.NOMI_FILE["rt"].format(base=ist.nome_base).replace(".docx", ".pdf")
            extra = []
            if s == "sopr":
                if V.ha_archeologico(ist):
                    archeo_ist.append(ist.nome_base)
                if w_["chk_rel"].isChecked() and V.solo_archeologico(ist):
                    self._vin_log(s, "    Relazione paesaggistica (Allegato D) non prodotta: "
                                     "solo vincoli archeologici.")
                elif w_["chk_rel"].isChecked():
                    p = os.path.join(out, D.nome_file("relazione_paes", ist.nome_base))
                    extra.append(D.relazione_paesaggistica(
                        ist, dati_c, p, contesti=[w_["contesto"].currentText()],
                        morfologie=[w_["morfologia"].currentText()],
                        piano=w_["piano"].text().strip(), pl_file=pl_file))
                if w_["chk_np"].isChecked():
                    p = os.path.join(out, D.nome_file("non_parentela", ist.nome_base))
                    extra.append(D.non_parentela(ist, dati_c, dest.get("nome", ""), p))
            elif ist.ente_tipo == "natura2000":
                esiti = V.esiti_vinca(ist.interferenze, soglia)
                area = next((a for a in aree if V.voce_pulita(a.voce()) ==
                             V.voce_pulita(ist.corso)), None)
                if esito == "esonero":
                    p = os.path.join(out, D.nome_file("esonero_vinca", ist.nome_base))
                    sito = ("%s %s" % (area.codice, area.nome)).strip() if area else ist.corso
                    extra.append(D.autodichiarazione_esonero(
                        ist, dati_c, dest, sito, esiti, p, pl_file=pl_file, rt_file=rt_file))
                else:
                    p = os.path.join(out, D.nome_file("format_vinca", ist.nome_base))
                    parchi = [a.voce() for a in st["aree"] if a.tipo == "parco" and a.includi]
                    dist = None
                    if area is not None:
                        dist = self._vin_distanza_sito(area, ist)
                    extra.append(D.format_vinca(
                        ist, dati_c, st.get("regione"), st.get("provincia"),
                        area.codice if area else "", area.nome if area else ist.corso,
                        area.sottotipo if area else "", dist, parchi,
                        w_["contesto"].currentText(), esiti, p, pl_file=pl_file,
                        rt_file=rt_file))
            docs += [os.path.basename(p) for p in extra]
            da_pdf.append(prod.get("rt"))
            if w_["chk_pdf"].isChecked():
                da_pdf += [prod.get("art49"), prod.get("bollo")] + extra
            self._vin_log(s, "- %s: %d interventi -> %s" % (ist.nome_base,
                                                               len(ist.interferenze), out))
            if w_["chk_pl"].isChecked():
                aree_ist = aree if s == "sopr" else [
                    a for a in aree if V.voce_pulita(a.voce()) == V.voce_pulita(ist.corso)]
                pdf = os.path.join(out, pl_file)
                ok = AL.genera_pl_acque(
                    self.project, ist, dati_c, pdf, ente=testi["ente"],
                    orto_id=w_["orto"].currentData(),
                    log=lambda m, k=s: self._vin_log(k, "    " + m),
                    scala=w_["scala"].currentData() or None,
                    vincolo={"aree": aree_ist,
                             "prefisso": "SOPR" if s == "sopr" else (
                                 "N2000" if ist.ente_tipo == "natura2000" else "PARCO"),
                             "titolo_legenda": "VINCOLI" if s == "sopr" else "AREE PROTETTE",
                             # Soprintendenza: niente sezione, 2 o 4 foto
                             "riquadro": "solo_foto" if s == "sopr" else "fotoinserimento",
                             "foto_per_tavola": foto_tav,
                             "geoportale": {"link": w_["geo_link"].text().strip(),
                                            "immagine": w_["geo_img"].text().strip()},
                             "tipologia_cartiglio": testi["ente"].upper(),
                             "linea_cartiglio": testi["titolo"]})
                docs.append(pl_file if ok else pl_file + " (NON riuscita)")
                self._vin_log(s, "    PL: %d tavole — %s" % (len(ist.tavole),
                                                             "ok" if ok else "NON riuscita"))
            with open(os.path.join(out, "LEGGIMI.txt"), "w", encoding="utf-8") as fh:
                fh.write(V.promemoria_vincoli(ist, dati_c, dest, docs))
        try:    # logo FiberCop classico o «Milano Cortina 2026» (flag del progetto)
            from . import ftth_logo as _LOGO
            n_logo = _LOGO.applica_cartella(cartella_out, _LOGO.attivo(self.project))
            if n_logo:
                (lambda m: self._vin_log(s, m))("Logo FiberCop %s in %d documenti Word." % (
                    "Milano Cortina 2026" if _LOGO.attivo(self.project) else "classico", n_logo))
        except Exception as e_logo:  # noqa: BLE001
            (lambda m: self._vin_log(s, m))("Logo nei documenti non sostituito: %s" % e_logo)
        da_pdf = [p for p in da_pdf if p]
        if da_pdf:
            self._vin_log(s, "Conversione in PDF (Word)...")
            ris = rfi.converti_pdf(da_pdf)
            if rfi.avviso_pdf():
                self._vin_log(s, "  " + rfi.avviso_pdf())
            ko = [os.path.basename(p) for p, pdf in ris.items() if not pdf]
            if ko:
                self._vin_log(s, "  PDF non creati (manca Word/LibreOffice?): %s" % ", ".join(ko))
        self._vin_log(s, "Fatto. In ogni cartella il LEGGIMI dice cosa completare.")
        testo = ("Le istanze sono pronte, ma la documentazione prodotta dal plugin è una "
                 "bozza: rileggila e verificala sempre (testi, norme, metri, destinatari, "
                 "allegati) prima dell'invio. In ogni cartella il LEGGIMI dice cosa "
                 "completare.")
        if archeo_ist:
            self._vin_log(s, "ATTENZIONE vincolo archeologico in: %s" % ", ".join(archeo_ist))
            testo += ("\n\nATTENZIONE, vincolo archeologico in: %s.\n\n%s"
                      % (", ".join(archeo_ist), V.AVVISO_ARCHEO))
        QMessageBox.warning(self, "Verifica la documentazione", testo)

    def _vin_distanza_sito(self, area, ist):
        """Distanza (m) dei lavori dal sito; None se sono dentro."""
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        from shapely.geometry import Point
        c = area.geom.centroid
        pr = rfi._Proiezione(c.x, c.y)
        g = pr.avanti(area.geom)
        d = min(g.distance(pr.avanti(Point(i.lon, i.lat))) for i in ist.interferenze)
        return None if d < 1 else round(d)

    def _vin_apri_cartella(self, s):
        c = self._vin_st.get(s, {}).get("cartella")
        if c and os.path.isdir(c):
            os.startfile(c)  # noqa: S606
