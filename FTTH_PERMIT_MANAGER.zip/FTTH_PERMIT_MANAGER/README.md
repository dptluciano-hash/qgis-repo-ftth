# FTTH Permessi Manager – plugin QGIS

## Novità versione 0.71

**Interfaccia — all'apertura tutte le sezioni sono chiuse:** ogni scheda si
presenta come un elenco di titoli, si apre quello che serve e il resto resta
fuori dai piedi. Il salvataggio automatico dello stato di QgsCollapsibleGroupBox
è stato disattivato di proposito: quel widget memorizza in QgsSettings se il
riquadro era aperto e lo ripristina quando viene mostrato, sovrascrivendo la
chiusura impostata alla costruzione, quindi i riquadri lasciati aperti nella
sessione precedente si sarebbero riaperti da soli. Nuovo pulsante "Chiudi tutte
le sezioni" in fondo al pannello, per tornare alla vista d'insieme senza
chiudere e riaprire.

**Interfaccia — scheda di installazione riscritta** con il testo definitivo:
una riga di descrizione, tre righe sul flusso di lavoro e il rimando alla guida
contestuale e al README.

## Novità versione 0.70

**Novità — scheda "Suolo comunale" nel ramo Altri Enti:** individua gli elementi
di progetto che non ricadono sugli stradari di competenza dell'ente (SP, ANAS,
altro) e li separa in un gruppo di livelli a sé, che si spegne quando si stampa
la tavola per quell'ente. Lavora in due passi: prima li seleziona in mappa e
inquadra la zona, perché li si possa controllare a vista e ritoccare la
tolleranza; solo dopo la conferma li sposta. Lo spostamento non cancella e non
duplica geometrie: scrive un campo SUOLO che distingue i due casi, crea un
gruppo di livelli filtrati sul valore COMUNALE e applica agli originali il
filtro complementare. I livelli del gruppo nuovo sono cloni di quelli originali,
quindi conservano sorgente e simbologia — a vedersi sono identici. Un terzo
pulsante annulla tutto rimuovendo il gruppo e azzerando i filtri. Sui livelli
temporanei, dove il filtro non è applicabile, le feature vengono copiate e
l'originale resta intero: il log lo segnala.

**Interfaccia — i riquadri di log non occupano più spazio da vuoti:** erano
undici rettangoli bianchi che nelle schede più cariche allontanavano i controlli
fra loro. Ora sono richiudibili, partono chiusi e si aprono da sé quando c'è
qualcosa da leggere.

**Interfaccia — i riquadri di sola impostazione partono chiusi:** creazione del
campo chilometrica, filtri e grafica delle etichette, unione PDF. Le azioni di
ogni giorno restano aperte. Un primo tentativo chiudeva per posizione — primo
riquadro aperto, gli altri chiusi — ma nelle Chilometriche avrebbe chiuso proprio
il riquadro del calcolo.

**Interfaccia — scheda di installazione sintetizzata:** descrizione e testo
"about" in metadata.txt erano un paragrafo unico di circa 1100 caratteri; ora
sono una riga e cinque righe divise per ramo.

## Novità versione 0.69

**Interfaccia — impostazioni ricordate fra le sessioni:** il pannello memorizza
i valori dei campi alla chiusura e li rimette all'apertura, così non si
riparte ogni volta dai valori di fabbrica. I combo dei layer sono esclusi di
proposito, perché puntano a layer di un progetto specifico e ripristinarli su
un altro progetto darebbe riferimenti sbagliati: per quelli restano i preset
automatici. Le due copie della scheda Esportazione (Comune e Altri Enti) hanno
memorie separate, quindi puoi tenere impostazioni diverse nei due rami. Un
pulsante "Ripristina i valori iniziali" in fondo al pannello riporta tutto ai
predefiniti.

**Interfaccia — riquadri comprimibili:** ogni riquadro si chiude con un clic
sul titolo e QGIS ne ricorda lo stato. Con sette schede e ventisette riquadri
la finestra era diventata un muro di controlli.

**Interfaccia — pulsante Guida in ogni scheda:** apre una finestra non modale
con la spiegazione di quella parte del plugin, il flusso passo per passo e le
cause tipiche dei problemi. Si può lavorare con la guida aperta accanto.

**Interfaccia — versione nel titolo della finestra:** il pannello si intitola
ora "Gestione Permessi FTTH — v0.69". Serve a rispondere a colpo d'occhio alla
domanda "sto usando la versione nuova?", che durante lo sviluppo ha fatto
perdere tempo più di una volta.

**Aspetto — nuova icona nei colori beexact:** fondo blu #011e5a, chevron
arancione #ff7e01 e tre fibre bianche che convergono. Disegnata per essere
leggibile a 24 px, che è la dimensione con cui QGIS disegna la barra degli
strumenti: il primo tentativo aveva anche un punto luminoso nel mezzo, ma a
quella scala si impastava col chevron.

**Default — evidenza delle strade:** all'apertura sono ora preselezionati
tinta unita, tratte intere, corpo del nome strada a 16 pt.

## Novità versione 0.68

**Interfaccia — riquadro dell'evidenza riorganizzato:** era un elenco di
tredici controlli in fila, in fondo al quarto riquadro di una scheda lunga, e
la spunta del nome della strada risultava introvabile. Ora è diviso in due
sezioni, "Quali strade" e "Aspetto in stampa", con le opzioni di resa
raggruppate dove chi le cerca va a guardare.

## Novità versione 0.67

**Novità — nome della strada sull'evidenza, una volta per strada:** il layer di
evidenza contiene ora una feature per strada invece di una sola geometria
dissolta, ed è questo che permette di scrivere il nome una sola volta ciascuna.
Le tre impostazioni che evitano la ripetizione sono `labelPerPart = False` —
una scritta sola anche quando la fascia di una strada è spezzata in più parti —
nessuna distanza di ripetizione, che è ciò che nello stradario produce le sigle
minute ogni pochi centimetri di carta, e il piazzamento libero, che ruota il
testo per farlo stare dentro la fascia. Corpo regolabile, grassetto con alone
bianco, priorità alta perché la scritta non venga scartata per collisione con
le etichette dei pozzetti.

**Novità — spunta per spegnere le etichette dello stradario:** le sigle
ripetute lungo la strada vengono dall'etichettatura del layer stradario, non
dall'evidenza. Spenta per default, perché modifica un layer che l'utente non ha
chiesto di toccare; quando la si usa il log dice cosa è stato fatto e come
annullarlo.

**Fix — lunghezza nell'attributo:** era ricavata dall'area della fascia divisa
per la larghezza, ora è misurata direttamente sulla porzione di corridoio.

## Novità versione 0.66

**Fix — continuità del retino:** l'evidenza copriva le singole tratte toccate,
quindi dove una tratta intermedia non veniva sfiorata si apriva un buco. Ora lo
stradario viene ricucito in corridoi continui, su ciascuno si calcolano gli
intervalli di progressiva interessati e i vuoti sotto soglia vengono colmati.
Su scavi intervallati lungo due chilometri si passa da tre frammenti separati a
un tratto unico. Nuovi parametri "Colma i vuoti fino a" e "Salda le fasce che
si sfiorano", che con una chiusura morfologica chiude la fessura agli incroci —
dove due strade sono due corridoi distinti — con raggio limitato a metà
larghezza per non fondere strade parallele vicine.

**Fix — la causa vera dei buchi era la tolleranza:** "Distanza max elemento →
tratta" era a 2 m, ma lo stradario è l'asse e gli scavi corrono a bordo strada:
su una carreggiata di 8-10 m il bordo dista 4-5 m dall'asse, quindi quei tratti
venivano scartati in silenzio. Default portato a 8 m, e il log elenca ora
quanti elementi sono rimasti fuori e a che distanza stanno.

**Novità — stile dell'evidenza personalizzabile:** selettore di colore, quattro
stili (retino diagonale, retino incrociato, retino con bordo, tinta unita),
passo, spessore e angolo del retino. Passo e spessore sono in millimetri sul
foglio, quindi restano identici in stampa a qualunque scala.

## Novità versione 0.65

**Fix — crash di QGIS premendo "Evidenzia le strade interessate":** per mettere
il layer in fondo all'elenco era stato usato `insertLayer(-1, layer)`, con
l'idea che -1 significasse "in coda" come in Python. Quell'indice finisce in
`QList::insert()`, che pretende `0 <= indice <= numero di figli`: con -1 Qt
scrive prima dell'inizio dell'array e il processo muore di corruzione
dell'heap. È un crash nativo, quindi il try/except intorno non poteva
intercettarlo. Il metodo corretto è `addLayer()`, che accoda.

**Fix — secondo crash latente nel retino:** a `setSubSymbol()` veniva passato lo
stesso oggetto ottenuto da `subSymbol()`. Quel metodo distrugge il sotto-simbolo
corrente e prende possesso di quello nuovo, quindi rigirargli lo stesso
puntatore lo fa usare dopo la liberazione. Ora si passa un clone.

**Perf — lo stradario non viene più letto per intero:** l'evidenza scorreva
tutte le feature del layer di riferimento, che su un grafo provinciale sono
centinaia di migliaia, e se il layer è servito via WFS anche altrettante righe
dalla rete a ogni pressione del pulsante. Ora si legge solo l'intorno degli
elementi di progetto: su uno stradario di prova da 4200 tratte ne legge 17, con
risultato identico. Avviso nel log se il layer è remoto, tetto di sicurezza a
100.000 tratte, cursore di attesa durante l'unione delle fasce.

## Novità versione 0.64

**Fix — l'evidenza copriva gli elementi di progetto invece delle strade:** il
layer di riferimento veniva preso dal campo "Stradario" della scheda
Esportazione, che è opzionale e senza valore preimpostato; se lì c'era un layer
lineare qualsiasi — Infrastrutture è lineare — il retino veniva costruito su
quello, senza che nulla lo segnalasse. L'evidenza ha ora un proprio selettore
con preset, accetta layer lineari e poligonali, rifiuta con un messaggio
esplicito i layer di progetto e dichiara nel log quale stradario ha usato.

## Novità versione 0.63

**Novità — stile del testo delle etichette:** menù "Leggibilità sullo sfondo"
con quattro varianti — solo testo, alone bianco, riquadro bianco
semitrasparente, riquadro con ombra sottile. Su una CTR il testo nero cade su un
intreccio di linee nere e con il solo alone il tratteggio continua a leggersi
dentro le lettere: il riquadro semitrasparente stacca il testo da qualunque
sfondo restando discreto. Ombra tenuta breve — 0,7 mm a 135°, opacità 45%,
posizionata sotto il riquadro e non dietro le lettere. Selettore del carattere
di sistema e grassetto. La costruzione di riquadro e ombra è isolata con una
propria gestione degli errori: se una costante manca in quella versione di QGIS
si perde solo il riquadro, non tutta l'etichettatura.

## Novità versione 0.62

**Novità — chilometrica per singolo layer nelle etichette:** una spunta per
riga nella griglia, spenta per Infrastrutture, dove ripetere la chilometrica
era una duplicazione. Conseguenza utile: le tratte senza chilometrica calcolata
non vengono più saltate.

**Fix — l'etichettatura esistente non viene più cancellata:** QGIS ammette una
sola etichettatura per layer e `setLabeling()` sostituisce quella che c'era.
Con la nuova spunta "Conserva l'etichettatura già presente" quella esistente
viene convertita in regola e la nuova si aggiunge come seconda regola, che è
l'unico modo di averne due contemporaneamente.

## Novità versione 0.61

**Fix — punto interrogativo nelle etichette:** il separatore predefinito era un
trattino tipografico (U+2013), che uno shapefile senza file .cpg — quindi in
codepage ANSI — non sa scrivere e sostituisce con "?". Ora i separatori sono
ASCII e prima di scrivere il testo viene provato nella codifica del layer, con i
caratteri tipografici ricondotti all'equivalente ASCII.

**Novità — etichette in mappa con la grafica delle tavole:** testo nero
multiriga allineato a sinistra, scostato dall'elemento e collegato da una linea
di richiamo, con corpo e distanza regolabili. Spunta per mettere la chilometrica
in fondo all'etichetta, come nelle tavole.

**Novità — evidenza delle strade interessate:** nuovo riquadro nella scheda
Esportazione che copre con una fascia le tratte dello stradario su cui ricadono
gli elementi di progetto. Le fasce vengono dissolte, altrimenti con la
trasparenza le sovrapposizioni fra tratte adiacenti scurirebbero il colore.

## Novità versione 0.60

**Fix — errori di conteggio delle chilometriche fra elementi diversi:** tre
cause distinte, tutte a monte del calcolo. L'area entro cui veniva letto lo
stradario dipendeva dalla selezione, quindi il corridoio veniva ricucito
diverso a ogni lancio e lo stesso pozzetto elaborato con due selezioni diverse
otteneva due valori: ora l'area si calcola sull'estensione dei layer.
`mergeLines()` unisce solo le linee che condividono un vertice esatto, mentre
negli stradari i tronchi si chiudono a pochi centimetri e agli incroci la
strada viene tagliata: c'è ora una tolleranza di ricucitura che segue la
prosecuzione più diritta, con un limite di 75° oltre il quale non aggancia, per
non svoltare nella laterale. Sulle tratte veniva misurato il punto medio, per
cui due scavi consecutivi ricevevano valori distanti mentre il primo finiva
dove il secondo cominciava: ora si misura il capo con la chilometrica minore,
con la possibilità di scrivere l'intervallo completo.

**Novità — punto 0 dichiarato e controverifica:** il log apre indicando quale
cippo è il riferimento, avvisa se i corridoi in uso sono più di uno — caso in
cui gli elementi non sono confrontabili fra loro — e per ogni altro cippo
confronta il valore dichiarato con quello che la progressione prevede per la sua
posizione.

## Novità versione 0.59

**Fix — le chilometriche non erano progressive:** l'interpolazione fra i cippi
riscalava le distanze sui valori dichiarati, quindi un cippo mal posizionato
comprimeva o dilatava tutto il tratto. Ora il conteggio parte dal cippo con la
chilometrica più bassa e somma la distanza reale percorsa lungo la strada, un
metro per un metro, nel verso in cui i chilometri crescono: i valori sono
monotoni e confrontabili. Su tre cippi reali un pozzetto a 500 m dal primo dava
17+444 e ora dà 17+600. L'interpolazione resta disponibile come terza opzione.

## Novità versione 0.58

**Interfaccia — aiuto contestuale richiudibile:** ogni scheda si apriva con un
paragrafo giustificato di otto-dieci righe che spingeva i controlli sotto la
piega. Ora resta visibile la prima frase, con un "dettagli" che apre il resto.

**Interfaccia — esito inline invece dei popup di conferma:** nelle schede
Chilometriche ed Etichette il risultato è una riga in grassetto sopra il log.
Gli errori restano popup.

**Interfaccia — la finestra ricorda dimensione e scheda aperta**, i log usano un
carattere a larghezza fissa, la scheda Etichette è divisa in passi numerati.

## Novità versione 0.57

**Fix — dicitura dello scavo:** rimosso "IN" dalla dicitura predefinita, che con
valori aggettivali dava "SCAVO IN TRADIZIONALE". Nuova dicitura dedicata per le
tratte aeree, dove "SCAVO AEREA" non vuol dire niente, e filtro per i soli
elementi con STATO = 'Nuovo', dato che nei layer di progetto convivono le
tratte in progetto e quelle esistenti.

## Novità versione 0.56

**Novità — riconoscimento del campo per contenuto:** i campi di origine delle
etichette si scelgono ora da un elenco invece di digitarne il nome, e
l'auto-riconoscimento guarda i valori contenuti prima del nome del campo — una
corrispondenza sul contenuto vale tre punti, una sul nome uno. Serve perché in
questo modello dati 'TIPOLOGIA' esiste ma può contenere Aerea/Interrata invece
della tecnica di scavo. Nuovo pulsante "Ispeziona i campi", che elenca ogni
campo con alcuni valori di esempio.

## Novità versione 0.55

**Novità — scheda Etichette:** compila un campo di testo su Armadio, Pozzetto e
Infrastrutture con la dicitura di posa, componendola dalla chilometrica più la
lavorazione. Il campo viene creato se manca. Diciture e campi di origine sono
modificabili dall'interfaccia. La lunghezza ripiega sul campo alternativo del
modello dati e infine sulla lunghezza geometrica reale, così l'etichetta non
resta senza metri per un campo non ancora calcolato. Anteprima prima di
scrivere.

## Novità versione 0.54

**Novità — parser dei cippi più tollerante:** il prefisso descrittivo con cui i
cippi sono normalmente etichettati ("KM 17+100", "PK 17+100", "progr. 17+100")
mandava il parser in errore e i cippi venivano scartati in silenzio, quindi il
calcolo non partiva affatto. Ora il prefisso viene ignorato e il formato del
valore si dichiara da un menù, compresa la forma invertita metri+km.

**Novità — controllo di coerenza dei cippi:** se fra due cippi la chilometrica
non cresce di circa un metro per metro percorso, il log lo segnala invece di
scrivere valori plausibili all'apparenza e completamente sbagliati.

## Novità versione 0.53

**Fix — calcolo delle chilometriche su stradari spezzettati:** la progressiva
veniva misurata sulla singola feature del riferimento e si pretendeva che cippo
ed elemento ricadessero sulla stessa; in uno stradario, spezzato in centinaia
di tratte, due punti a cinquanta metri stanno quasi sempre su tratte diverse,
quindi veniva scartato tutto con "nessuna ancora sulla stessa linea". Ora le
tratte contigue vengono ricucite in corridoi continui e la misura avviene lungo
quelli. Un cippo vicino a un bivio serve tutti i corridoi che ha entro
tolleranza, non solo il più vicino. Nuovo pulsante Diagnostica, che dice quanti
cippi sono stati letti e quali scartati, quanti corridoi ricuciti, quanti
elementi si agganciano e di quanto sono fuori tolleranza gli altri.

**Novità — campo dei cippi selezionabile** invece di essere cablato su
'Chilometrica', con preselezione automatica, e scrittura su più layer target in
un colpo.

## Novità versione 0.52

**Fix — creazione del campo 'Chilometrica' sugli shapefile:** il formato DBF
limita i nomi campo a dieci caratteri, quindi QGIS chiedeva 'Chilometrica' e
OGR restituiva 'Chilometri': il commit falliva con "il campo con indice 14 non
è uguale!" e faceva rollback. Il nome viene ora adattato al provider prima di
aggiungere il campo, e la ricerca del campo tollera nomi troncati e differenze
di maiuscole. Su GeoPackage e PostGIS il nome resta intero.

**Novità — scheda Esportazione anche nel ramo Altri Enti,** come copia
indipendente: layer, layout e liste PDF possono essere diversi dai due lati.

## Novità versione 0.51

**Perf — Stradario/Provinciali/ANAS ritagliati su ARLO AREA:** su
richiesta, Stradario, Provinciali e ANAS non vengono più letti per
intero (comuni shape a scala nazionale, es. Stradario Italia) ma solo
entro ARLO AREA (fusa, dalla scheda "Keyplan e tavole") allargata di
un margine impostabile (nuovo campo "Ritaglia Stradario/Provinciali/
ANAS a: ARLO AREA + margine", default 500 unità progetto). Il filtro è
un bbox lato provider (rapido anche su shapefile grandi grazie
all'indice .qix). Se ARLO AREA non è impostata, il log finale avvisa
che i layer sono stati letti per intero.

## Novità versione 0.50

**Fix — Punti di ripresa lentissimi (fino a 3 min):** la ricerca del
piede sullo Stradario re-interrogava il layer via bbox, con raggio
raddoppiato fino a 9 volte, PER OGNI candidato di OGNI tavola — su uno
Stradario grande (es. Stradario Italia) era il vero collo di
bottiglia. Ora l'indice spaziale su Stradario si costruisce UNA sola
volta, prima del ciclo sulle tavole, e ogni ricerca costa una
`nearestNeighbor()` sull'indice in RAM invece di una nuova scansione
del layer.

**Fix — rotazione dei coni sugli attraversamenti:** i punti di
attraversamento (Infrastruttura×Strada) sono per costruzione già
posizionati SULLA strada — proiettarli di nuovo sulla strada più
vicina ritornava il punto stesso: distanza zero, camera "sopra"
l'oggetto, rotazione indefinita. Ora, quando il soggetto giace già
sulla strada, la camera viene spostata della Distanza di ripresa
lungo la strada (resta sulla sua stessa linea) e l'inquadratura è
forzata perpendicolare alla strada — una vera foto di attraversamento
invece di un cono piazzato sul soggetto.

**Interfaccia — scheda "Punti di ripresa" unificata:** i campi Armadio
Ottico, Punto di Ripresa, Stradario, Sedime Pubblico, raggio e
distanze — prima in un blocco separato dal box "Coni per Tavola di
Inquadramento" pur essendo usati solo da quest'ultimo — sono ora
dentro lo stesso box, un'unica scheda con un solo scopo.

**Rinominata la scheda "Shape di consegna" in "Esportazione".**

## Novità versione 0.49

**Nuovo — Unisci PDF (Shape di consegna):** nuova sezione "Unisci PDF in un
ordine stabilito" sotto l'esportazione Atlante: elenco riordinabile
(↑/↓, Aggiungi, Rimuovi) che si autopopola con i PDF appena esportati,
nello stesso ordine; unisce i file scelti in un unico PDF. Richiede il
pacchetto Python 'pypdf' (fallback 'PyPDF2'); se assente, avvisa con le
istruzioni di installazione invece di fallire in silenzio.

**Fix — attivazione Atlante verificata davvero:** `setEnabled(True)` da
solo non garantiva il refresh delle feature coperte se il layer/filtro
di copertura era cambiato dopo l'ultima apertura del layout. Aggiunta
una chiamata esplicita a `updateFeatures()` dopo l'attivazione, e un
controllo che blocca l'esportazione con un messaggio chiaro se
l'Atlante risulta comunque a 0 elementi — così l'attivazione è
verificata, non solo presunta dal risultato dell'export.

**Fix — Punti di ripresa, coni ravvicinati/fuori criterio:**
1. La ricerca del piede sullo Stradario ignorava la tavola: poteva
   agganciarsi alla strada più vicina in assoluto anche se fuori
   tavola, per poi essere spinta sul bordo — posizionamento arbitrario,
   senza legame con una strada reale della tavola. Ora un segmento
   realmente dentro la tavola ha sempre priorità su uno fuori, anche se
   più lontano in linea d'aria.
2. Le soglie anti-duplicato erano troppo strette (0,5 m sul soggetto
   inquadrato, 0,10 m sulla posizione camera): bastavano pochi metri di
   scarto tra pool diversi (es. stesso incrocio digitalizzato
   leggermente diverso su Provinciale e su Stradario) per sfuggire al
   controllo e produrre coni ravvicinati puntati, di fatto, allo stesso
   oggetto. Alzate rispettivamente a 3 m e 1 m.

**Testi dell'interfaccia sintetizzati:** tutte le descrizioni delle
sezioni (regole di selezione, allinea cartografia, coni, keyplan,
consegna, esporta PDF) sono state accorciate, mantenendo il contenuto
tecnico.

## Novità versione 0.48

**Rimozioni (Seleziona elementi):** eliminate la Regola 4b (Accorcia
tratte fino al bordo edificio) e la Regola 6 (Verifica Civici senza
Edificio / Recupera Edifici da riferimento).

**Regola 5 — Sedime Pubblico da shape locale:** nuovo pulsante "1b)
Genera Sedime Pubblico da Stradario locale": stessa bufferizzazione della
generazione OSM (linee bufferizzate, poligoni presi come superficie
piena), stesso layer temporaneo risultante, ma leggendo un layer già
caricato in locale (es. uno Stradario Italia) invece di scaricare da OSM
— nessuna chiamata di rete. Resta anche il campo "Sedime già pronto" per
un poligono di sedime già finito da usare direttamente.

**Punti di ripresa:**
1. Eliminato il pulsante standalone "Genera coni davanti agli Armadi
   Ottici": la stessa cosa (con priorità assoluta) la fa già "Coni per
   Tavola di Inquadramento", che riusa Stradario/Sedime Pubblico/raggio
   di ricerca/distanza di riserva impostati in cima alla scheda.
2. Nuovo livello di priorità "attraversamenti Infrastrutture×Stradario":
   prima venivano individuati solo gli attraversamenti su Provinciale/
   ANAS, perdendo la maggioranza degli attraversamenti reali (su strade
   comunali generiche, mai classificate Provinciale/ANAS).
3. Ogni punto di ripresa calcolato viene ora sempre riportato dentro il
   perimetro della tavola se lo Stradario lo avesse spostato fuori.
4. Nuovo controllo anti-duplicato sul SOGGETTO inquadrato (non solo
   sulla posizione della camera): evita che due coni diversi puntino
   allo stesso oggetto.

**Fix esportazione PDF (Shape di consegna):** il messaggio di errore
mostrato anche per esportazioni riuscite ("errore nell'esportazione
codice (0, '')") era un bug del plugin, non un vero errore: l'overload
statico per l'esportazione Atlante restituisce una coppia (risultato,
messaggio), non il solo codice come le esportazioni normali — il
confronto sbagliato segnalava sempre errore anche a PDF scritto
correttamente. Corretto.

## Novità versione 0.47

**Nuova funzione — Recupera Edifici mancanti da un layer di riferimento
(Regola 6, Seleziona elementi):** per ogni Civico senza Edificio, cerca
nel layer di riferimento impostato (fonte-agnostico: footprint
Microsoft/Google scaricati per l'area, CTR regionale, un altro shape già
pronto — non solo OSM) un elemento che lo copre entro la Tolleranza e lo
copia nello shape Edifici. Utile proprio quando lo shape Edifici del
progetto è già derivato da OSM: ripartire da OSM non aggiungerebbe nulla
di nuovo, serve una fonte diversa. I Civici rimasti scoperti anche dopo
vengono selezionati su Civici — solo quelli vanno tracciati a mano.
Modifica Edifici sul posto: chiede conferma prima di procedere.

## Novità versione 0.46

**Nuova sezione "Esporta PDF (Atlante)" (Shape di consegna):** esporta in
PDF, via Atlante, i layout di stampa già presenti nel progetto QGIS
(configurati con il loro layer di copertura Atlante nel Compositore — non
impostati da qui). Elenco a selezione multipla dei layout disponibili,
pulsante "Aggiorna elenco layout" se ne aggiungi di nuovi dopo aver
aperto il plugin, e un pulsante che sceglie la cartella ed esporta un PDF
per ciascun layout selezionato (nome del file = nome del layout);
l'Atlante viene attivato automaticamente se non lo è già, e riportato
allo stato originale al termine.

**Nuova Regola 6 (Seleziona elementi) — Verifica Civici senza Edificio:**
seleziona i Civici che non toccano/intersecano nessun elemento del layer
Edifici entro la Tolleranza — un edificio mancante da recuperare. Avviso
esplicito con il conteggio se ne trova; altrimenti conferma che tutti i
Civici hanno un Edificio associato.

## Novità versione 0.45

**Fix errore "Seleziona tratte da accorciare" (Regola 4b):**
"'QgsGeometry' object has no attribute 'boundary'" — il metodo
`QgsGeometry.boundary()` non è disponibile in tutte le versioni di
QGIS/PyQGIS. Il perimetro dell'edificio (usato per trovare il punto di
taglio) viene ora costruito a mano dagli anelli del poligono (esterno +
eventuali fori), senza dipendere da quel metodo.

## Novità versione 0.44

**Fix coni ancora appiccicati agli oggetti (Punti di ripresa):** il campo
Sedime Pubblico correggeva ANCHE i punti già trovati correttamente sullo
Stradario — se un Sedime Pubblico residuo di una sessione precedente
(o troppo stretto) risultava impostato, poteva risagomare/spostare un
punto già giusto verso l'oggetto fotografato. Ora il Sedime Pubblico
interviene SOLO sul ripiego "nessuna strada trovata", mai su un punto
già trovato correttamente sullo Stradario. Rimossa anche
l'autoselezione automatica del campo Sedime Pubblico (ora sempre
volontaria) per evitare che un layer residuo venga usato senza che te ne
accorga.

**Fix accorcia tratte (Regola 4b):** un PTE posizionato esattamente sul
bordo dell'edificio (il caso più comune, PTE a muro) non veniva
riconosciuto come "tocca l'edificio" — il controllo usava `contains()`,
che in senso stretto esclude i punti sul perimetro. Ora usa
`intersects()`, che riconosce anche il contatto sul bordo.

**Fix numerazione Keyplan (Keyplan e tavole):** il campo di default per
la numerazione del Keyplan ora è "Numero Tav" (lo stesso delle Tavole di
Inquadramento, come richiesto), non più "Numero KP". Il messaggio
finale ora riporta anche quanti elementi sono stati letti dal layer: se
il numero è molto più basso delle tavole/keyplan attese (es. sempre 1),
segnala di verificare che il layer impostato sia quello giusto (non un
filtro attivo, o il layer modello invece di quello generato).

## Novità versione 0.43

**Punti di ripresa:**
1. La ricerca dello Stradario ora parte dal raggio impostato e RADDOPPIA
   (fino a 256 volte il raggio iniziale) finché non trova una strada,
   invece di ricadere subito sul ripiego "a Nord" con un raggio troppo
   piccolo: era la causa più probabile dei coni che restavano appiccicati
   agli oggetti (Armadio/Pozzetto/Infrastruttura) invece di stare
   sull'asse della strada, e degli attraversamenti persi.
2. Nuovo campo opzionale "Sedime Pubblico": se impostato (es. quello
   generato dalla Regola 5), un punto di ripresa che cade fuori dal
   sedime pubblico viene spostato al punto più vicino dentro di esso —
   per evitare di piazzare il fotografo in un'area non accessibile (es.
   un cortile privato).
3. Rinforzato il controllo anti-duplicati già introdotto in v0.42 (ora
   coerente su tutte le chiamate, incluso il nuovo aggancio al Sedime).

**Keyplan e tavole — nuova numerazione:** pulsante separato "Numera
Keyplan e Tavole" che numera i due layer (indipendentemente) in ordine di
lettura: righe da nord a sud, e all'interno di ogni riga da ovest a est
(alto-sinistra → basso-destra). Campo creato se manca.

**Seleziona elementi:**
1. La selezione "Tratte + Pozzetti toccati da Edifici" ora esclude
   sempre le tratte TIPOLOGIA='Aerea', a prescindere dalla spunta
   STATO='Nuovo'.
2. "Accorcia tratte fino al bordo edificio" è ora in due passi: prima
   "Seleziona tratte da accorciare" (nessuna modifica, solo selezione da
   verificare sulla mappa), poi "Accorcia tratte selezionate" (agisce
   solo su quelle rimaste selezionate, con conferma).

## Novità versione 0.42

**Fix rotazione sempre a 180° (Punti di ripresa):** il filtro spaziale
per cercare lo Stradario vicino era costruito in CRS di progetto ma
inviato al layer Stradario senza convertirlo nel SUO CRS — su progetti
con Stradario in un CRS diverso da quello di progetto, il filtro non
trovava mai nessuna tratta, e la funzione ricadeva SEMPRE sul ripiego "a
Nord" (che dà, per costruzione, sempre rotazione 180°). Ora il
rettangolo di ricerca viene convertito nel CRS del layer Stradario prima
di interrogarlo.

**Fix coni duplicati sullo stesso punto (soprattutto sugli Armadi):**
"Coni Armadi" e "Coni per Tavola di Inquadramento" calcolano la STESSA
posizione (stessa proiezione sullo Stradario) per lo stesso Armadio:
eseguendo entrambi i pulsanti (o rieseguendo lo stesso più volte)
finivano due Foto diverse impilate sul punto identico. Ora entrambe le
funzioni tengono traccia dei punti già occupati (Foto già presenti nel
layer + quelle appena aggiunte in questa esecuzione): un Armadio il cui
punto coincide con un cono già esistente conta comunque come "coperto"
ma non viene duplicato; per attraversamenti/Pozzetto Nuovo/tratta un
candidato duplicato viene scartato e si prova il successivo, senza
sprecare uno dei 3 posti della tavola.

## Novità versione 0.41

**Fix errore "Regola 4b" (Accorcia tratte fino al bordo edificio):**
"MultiLineString geometry cannot be converted to a polyline" — molti
shapefile salvano anche le tratte logicamente singole come
MultiLineString con una sola parte, e la conversione usata non lo
gestiva. Ora la funzione riconosce questo caso e ricostruisce l'output
nello stesso formato (MultiLineString) atteso dal layer. Tratte con più
parti realmente disgiunte restano non toccate (nessun lato PTE/lato da
mantenere univoco in quel caso).

## Novità versione 0.40

**Allinea cartografia — spostamento esclusivo dei selezionati:** la
checkbox "Sposta SOLO gli elementi selezionati" ora è davvero esclusiva:
un layer impostato ma SENZA una selezione attiva viene saltato per
intero (nessun elemento spostato), invece di ricadere nello spostare
tutto il layer come accadeva prima.

**Seleziona elementi — Regola 4b, nuova (Accorcia tratte fino al bordo
edificio):** per ogni tratta Infrastrutture STATO='Nuovo' (esclusa
TIPOLOGIA='Aerea') che tocca un ROE PTE con TIPO diverso da "Interno
Edificio"/"Muro Interno" (quindi un PTE non interno a QUELL'edificio) e
che attraversa un elemento del layer Edifici, la tratta viene accorciata
fino al primo punto in cui tocca il bordo dell'edificio, eliminando il
tratto che prosegue dentro l'edificio verso quel PTE. Modifica le
geometrie sul posto: chiede sempre conferma prima di procedere. Richiede
un layer Edifici poligonale (non lineare).

## Novità versione 0.39

**Fix Keyplan che non contiene le Tavole di inquadramento:** aggiunto un
campo "Tavole di Inquadramento" condiviso nella sezione Keyplan — se
impostato, SIA il pulsante standard "Genera copertura Keyplan sull'area
di progetto" SIA "Rigenera Keyplan" (rigenerazione mirata) coprono
esclusivamente l'impronta di quelle tavole, ignorando del tutto ARLO
AREA. In precedenza il pulsante standard restava sempre legato ad ARLO
AREA (causa reale dei Keyplan che non contenevano le tavole vicine nello
screenshot), e la rigenerazione mirata dipendeva da un riferimento
interno valido solo nella stessa sessione in cui le tavole erano state
generate (fragile se il progetto veniva riaperto). Il campo si
autocompila cercando un layer chiamato "Poligoni Inquadramento".

**Punti di ripresa — numerazione che perdeva alcuni coni:** i coni
generati da "Coni per Tavola di Inquadramento" sono ora collegati alla
loro tavola con un campo interno esplicito ('ID_Tavola'), non più solo
per contenimento geometrico: un punto di ripresa spostato sullo Stradario
può finire fuori dal perimetro della tavola, e in quel caso il vecchio
test geometrico non lo trovava più — la Numerazione automatica Foto lo
lasciava senza numero. Le Foto senza questo collegamento (es. dal
pulsante Coni Armadi) continuano a usare il ripiego geometrico.

**Punti di ripresa — nuova priorità Pozzetto Nuovo:** aggiunto un livello
di priorità intermedio tra gli attraversamenti Provinciale/ANAS e la
tratta generica: i Pozzetti Nuovi che toccano un'Infrastruttura Nuova
sono ora un punto di interesse a sé, con priorità più bassa degli
attraversamenti ma più alta della tratta.

**Punti di ripresa — ancoraggio uniforme:** TUTTI i tipi di cono
(Armadio, attraversamenti, Pozzetto Nuovo, tratta) sono ora ancorati allo
stesso modo — proiezione perpendicolare sullo Stradario (o un altro
shape lineare a scelta) — non più solo l'Armadio.

## Novità versione 0.38

**Fix Keyplan che non contiene le Tavole di inquadramento vicine:** la
copertura adattiva valutava ogni posizione candidata solo contro la
singola componente connessa del 'buco' scoperto scelto come riferimento
— Tavole di inquadramento (o gruppi di Infrastrutture/Pozzetto Nuovi)
vicine ma non tecnicamente a contatto diretto sono componenti connesse
SEPARATE, quindi venivano ignorate anche quando cadevano comodamente
dentro la stessa tavola/keyplan. Ora ogni posizione viene valutata contro
TUTTO lo scoperto rimasto, non solo quella componente: un Keyplan (o una
Tavola di inquadramento) può quindi raccogliere più elementi vicini in
una volta sola, contenendoli davvero.

**Fix STATO='Nuovo'/TIPOLOGIA='Aerea' ancora aggirabile nella
rigenerazione mirata delle Tavole di inquadramento:** stesso bug di
confronto case/spazi-sensibile già corretto altrove in v0.37, ora esteso
anche a `_target_ottimizza_inquadramento` (il target usato dal pulsante
'Rigenera tavole di inquadramento solo sulla rete nuova').

**Punti di ripresa — priorità assoluta sugli Armadi:** ogni Armadio
Ottico presente in una Tavola di Inquadramento ha ora SEMPRE un cono
dedicato, anche se ce ne sono più di 3 nella stessa tavola (in quel caso
il tetto di 3 coni totali viene superato pur di non saltarne nessuno). Il
budget per attraversamenti/tratte si adatta di conseguenza.

**Punti di ripresa — logica parallela/perpendicolare sullo Stradario:**
il punto di ripresa via Stradario ora scompone esplicitamente ogni
segmento nella componente parallela (direzione della strada) e
perpendicolare (scarto laterale, cioè il punto di ripresa): un vero piede
perpendicolare (che cade dentro il segmento) è sempre preferito a un
punto d'estremo/incrocio, anche se quest'ultimo fosse leggermente più
vicino in linea d'aria — un estremo clampato non è una vera inquadratura
perpendicolare alla strada.

## Novità versione 0.37

**Fix coni su infrastruttura aerea (Punti di ripresa):** il confronto
TIPOLOGIA='Aerea' era case/spazi-sensibile: un dato scritto 'AEREA', '
Aerea ' ecc. non veniva riconosciuto come aereo e la tratta passava il
filtro. Ora il confronto (STATO e TIPOLOGIA) ignora maiuscole/minuscole e
spazi iniziali/finali.

**Numerazione automatica Foto (Punti di ripresa):** nuovo pulsante che
numera le Foto a blocchi fissi di 3 per Tavola di Inquadramento, ma SOLO
se le tavole sono già numerate in un campo esistente (letto, non generato
dal plugin) — altrimenti non fa nulla e spiega perché. Se una tavola ha
meno di 3 coni, il/i numero/i mancante/i del suo blocco vengono saltati,
non riassegnati alla tavola successiva.

**Allinea cartografia:** rimosso il calcolo automatico da shapefile di
riferimento; resta solo l'allineamento tramite punti di controllo
manuali (utile anche sopra un WMS).

**Keyplan/Tavole di inquadramento — fix centraggio:** la copertura
adattiva ora, oltre alla griglia di posizioni-angolo di sempre, prova
anche a centrare la tavola sul baricentro di tutto il contenuto che le
ricade attorno in una finestra grande quanto la tavola stessa; se quel
contenuto ci sta quasi per intero in una tavola sola, la posizione
centrata vince sempre. Le tavole risultano quindi centrate su quello che
devono inquadrare (Infrastrutture/Pozzetto Nuovi per le Tavole di
inquadramento, le Tavole di inquadramento stesse per il Keyplan) invece
di essere ancorate per un angolo/bordo.

## Novità versione 0.36

**Nuova scheda "Allinea cartografia":** sposta in blocco Armadio Ottico,
Infrastrutture, Pozzetto, ROE PTE, Cavo Ottico e Cavo Raccordo per
allinearli alla cartografia ufficiale del permesso (WMS o shapefile, a
seconda del territorio), preservando la topologia della rete — la
trasformazione (traslazione + rotazione + scala) è UNA sola, applicata
tutta insieme a tutti i layer scelti, non uno snap elemento per elemento
che romperebbe i collegamenti tra pozzetti e tratte.

Due modi per calcolarla:
- **A) Automatico da uno shapefile di riferimento**: abbina i vertici di
  un layer "àncora" (es. Infrastrutture) al punto più vicino su un layer
  di riferimento ufficiale entro una tolleranza, scarta gli abbinamenti
  anomali, calcola la trasformazione che minimizza lo scarto residuo
  complessivo (minimi quadrati).
- **B) Punti di controllo manuali**: utile sopra un WMS, che non ha
  geometrie proprie da agganciare automaticamente. Si clicca sulla mappa
  una coppia di punti alla volta (uno sulla rete, uno sul riferimento);
  con 2 o più coppie si calcola la stessa trasformazione.

In entrambi i casi viene mostrata un'anteprima (rotazione, scala,
traslazione, errore residuo) prima di applicare, e la conferma è
obbligatoria: l'operazione modifica le geometrie sul posto.

## Novità versione 0.35

**Ordine schede:** "Keyplan e tavole" spostata prima di "Punti di ripresa"
(le Tavole di inquadramento vanno generate prima, essendo ora un
riferimento per i punti di ripresa).

**Punti di ripresa:**
- Le Infrastrutture di interesse sono ora sempre solo STATO='Nuovo',
  escluse TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL (non più un filtro
  opzionale disattivabile).
- Il posizionamento del cono per l'Armadio Ottico non usa più gli
  Edifici come punto di ancoraggio: il punto di ripresa è ora la
  proiezione perpendicolare dell'Armadio sulla tratta di Stradario più
  vicina, con l'inquadratura rivolta verso l'Armadio dall'altro lato
  della strada. Rimosso il layer Edifici/Fabbricati, aggiunto Stradario
  (opzionale) sia nel pulsante Armadi singolo sia nei Coni per Tavola di
  Inquadramento.

**Seleziona elementi — Regola 5:** il Sedime Pubblico (OSM) ora include
anche marciapiedi e vie pedonali (già mappati come highway in OSM) e, dove
disponibili, tratta piazze e aree pedonali chiuse come superficie piena
invece che come una fascia bufferizzata attorno al solo perimetro — una
piazza larga non risultava quasi tutta scoperta (e quindi segnalata come
possibile privato) solo per un limite del buffer stradale.

**Keyplan/Tavole di inquadramento (rigenerazione mirata):** confermato che
il target è già completamente svincolato da ARLO AREA — le Tavole di
inquadramento puntano solo a Infrastrutture STATO='Nuovo' (escluse
TIPOLOGIA='Aerea'/NULL) + Pozzetto STATO='Nuovo', e il Keyplan copre solo
l'impronta di quelle tavole (fix già introdotto in v0.33).

## Novità versione 0.34

**Fix join ARMADI_FOTO (Shape di consegna):** la base del join era il
Punto di Ripresa invece dell'Armadio Ottico, quindi il risultato aveva una
riga per OGNI punto di ripresa (compresi quelli generati per
attraversamenti/tavole di inquadramento, non legati a un armadio) invece
di una per ogni Armadio Ottico. Confermato confrontando con uno shape
ARMADI_FOTO di riferimento: i campi dell'Armadio Ottico vengono per primi,
seguiti da quelli del Punto di Ripresa più vicino. Ora la base del join è
l'Armadio Ottico: ARMADI_FOTO.shp ha un solo elemento per ogni Armadio
Ottico, con gli attributi del Punto di Ripresa più vicino entro la
Distanza max join.

## Novità versione 0.33

**Fix copertura Keyplan/Tavole di inquadramento (rigenerazione mirata):**
1. Il Keyplan ottimizzato copriva l'intero ARLO AREA unito alle Tavole di
   inquadramento, invece delle sole Tavole di inquadramento: su un ARLO
   AREA molto più esteso della rete nuova, l'algoritmo sceglieva di
   coprire per prime zone lontane dalla rete, con il Keyplan che finiva
   piazzato spostato ("traslato") rispetto alle tavole invece che sopra
   di esse. Ora il target è solo l'unione delle Tavole di inquadramento
   già rigenerate.
2. Corretta la causa dei buchi rimasti su Infrastrutture/Pozzetto Nuovi:
   quando nessuna posizione libera da sovrapposizioni copriva un punto, la
   copertura scartava solo un'area minuscola attorno ad esso — su un
   target STRETTO (un corridoio attorno alla rete) questo poteva bruciare
   tutto il budget di tentativi su un'unica zona ostica (curve, incroci),
   interrompendo la generazione anche per il resto della rete, mai
   nemmeno provato. Ora: griglia di posizioni candidate più fitta (5×5),
   area scartata per fallimento proporzionata alla tavola (non più
   trascurabile) e budget di tentativi molto più alto.

**Regola 1b (Seleziona elementi):** aggiunta una terza condizione
indipendente di esclusione del Pozzetto: se toccato dal layer Cavo Ottico
(dorsale condivisa), oltre a TIPOLOGIA='No Dig' della tratta e sede-PTE
già presenti — basta una sola delle tre per escluderlo.

**Punti di ripresa — Coni per Tavola di Inquadramento:** il ripiego
quando mancano attraversamenti Provinciale/ANAS non punta più al PTE
dentro un Pozzetto, ma a un punto lungo la tratta Infrastruttura Nuova
stessa (l'attraversamento fisico da un Pozzetto a un ROE PTE, o tra due
Pozzetti). Rimosso il layer ROE PTE dalla sezione, non più necessario.

## Novità versione 0.32

**Regola 5 — sedime alternativo:** nella sezione "Possibile proprietà
privata" è ora possibile impostare un layer poligonale alternativo (es. da
un geoportale regionale/comunale più preciso di OSM per quel progetto): se
impostato viene usato al posto del Sedime Pubblico (OSM) generato al
punto 1, senza bisogno di integrazioni dedicate per ogni ente.

**Punti di ripresa — Coni per Tavola di Inquadramento:** nuova sezione
nella scheda "Punti di ripresa" che genera fino a 3 coni fotografici per
ogni Tavola di Inquadramento:
- 1 cono dedicato all'Armadio Ottico se ricade nella tavola (stessa
  logica di posizionamento — perpendicolare al muro più vicino — del
  pulsante Armadi già esistente);
- gli altri (fino a 3 se la tavola non contiene un Armadio) ai punti di
  attraversamento Infrastrutture×Provinciale e Infrastrutture×ANAS, e in
  mancanza ai Pozzetti sede di un ROE PTE (di qualsiasi tipologia) che
  ricadono nella tavola;
- priorità quando i candidati sono più del necessario: Provinciale, poi
  ANAS, poi Pozzetto-PTE; a parità di tipo vince il candidato più vicino
  al centro della tavola;
- layer Provinciale, ANAS e ROE PTE sono opzionali (se mancano, quel tipo
  di candidato è semplicemente assente dal conteggio).

## Novità versione 0.31

**Regola 5 (Seleziona elementi) — Possibile proprietà privata, automatica via OSM:**
1. "Scarica strade OSM e genera Sedime Pubblico": scarica da Overpass API
   (con mirror di riserva) le strade OpenStreetMap nell'area di
   Infrastrutture + Pozzetto, le bufferizza con la larghezza impostata
   (default 7 m) e crea il layer memory "Sedime Pubblico (OSM)".
2. "Seleziona tratte/pozzetti fuori dal Sedime": seleziona le tratte
   Infrastrutture e i Pozzetti che ricadono interamente FUORI da quel
   sedime — candidati a proprietà privata.

**Attenzione:** è una preselezione automatica, non una classificazione
legale — OSM può essere incompleto in alcune zone e il buffer è solo una
stima del sedime reale (piazze, cortili condominiali aperti su strada,
ecc. possono dare falsi positivi/negativi). Va sempre verificata a vista
prima di procedere con i permessi.

## Novità versione 0.30

1. **Regola 1b (Seleziona elementi):** il Pozzetto "subito dopo" la tratta
   non viene selezionato se è vera almeno una di due condizioni
   indipendenti: la tratta di provenienza ha TIPOLOGIA='No Dig', oppure il
   pozzetto è sede di un ROE PTE (di qualsiasi tipologia).
2. **Punti di ripresa:** rimossa la numerazione automatica dei punti di
   ripresa (campo "Campo numerazione" e relativa logica).
3. **Keyplan e tavole — rigenerazione mirata ("Rigenera solo sulla
   rete"):**
   - le Tavole di inquadramento si posizionano ora nel minor numero
     possibile sopra le Infrastrutture STATO='Nuovo' (escluse
     TIPOLOGIA='Aerea' e TIPOLOGIA vuota/NULL) UNITE al Pozzetto
     STATO='Nuovo' — vanno generate per prime;
   - il Keyplan continua a tenere conto di ARLO AREA come prima, ma copre
     anche le Tavole di inquadramento già rigenerate: va quindi rigenerato
     DOPO di esse;
   - rimossa la numerazione automatica delle tavole/keyplan (campo "Numero
     Tav").
4. **Shape di consegna:**
   - i campi LUNGHEZZA e Lungh del layer "03 INFRASTRUTTURE" vengono creati
     solo se mancanti: se esistono già, vengono semplicemente aggiornati
     con l'espressione '$Length';
   - in ARMADI_FOTO, i valori '999' del campo CIVICO vengono sostituiti con
     'SNC';
   - il join Armadio Ottico + Punti di ripresa per generare ARMADI_FOTO
     tiene ora conto SOLO dei punti di ripresa effettivamente associati a
     un Armadio Ottico (entro la Distanza max join): i punti di ripresa
     senza un Armadio entro quella distanza vengono esclusi dallo shape,
     non più inclusi tutti indiscriminatamente.

## Novità versione 0.28 (base Infrastrutture garantita + pulizia campo 'n')

1. **Base Infrastrutture garantita.** L'aggiornamento di LUNGHEZZA/Lungh e
   la base del join per SCAVI_STRADE vengono ora presi sempre dal layer di
   progetto chiamato esattamente "03 INFRASTRUTTURE" (cercato per nome),
   non da quello selezionato al momento nel campo Infrastrutture della
   scheda — se trovato, il campo viene anche riallineato di conseguenza.
   Se il progetto non ha un layer con quel nome esatto, si usa comunque
   quello selezionato nel campo, come prima.
2. **Pulizia automatica del campo 'n'.** Prima di considerare pronti
   SCAVI_STRADE e POZZETTI_STRADE, vengono rimosse le eventuali righe con
   l'attributo 'n' diverso da 1 (o mancante): può capitare con un
   pareggio di distanza nel join, che produce più righe per lo stesso
   elemento di partenza — se ne tiene solo una. Il numero di righe rimosse
   (se maggiore di zero) compare nel messaggio finale.

## Novità versione 0.27 (schema attributi shape di consegna allineato ai file di riferimento)

Confrontata la tabella attributi generata con i file `.dbf` di riferimento
(SCAVI_STRADE, ARMADI_FOTO, POZZETTI_STRADE): i join non aggiungono più un
prefisso ai campi del layer unito (prima: `str_`/`armadio_`). I campi
vengono ora copiati con il loro nome originale; in caso di nomi già
presenti (es. `fid`), QGIS li rinomina da solo in `fid_2`, esattamente come
nei file di riferimento. Nome dei 3 shapefile e struttura dei join
(Foto+Armadio, Infra+Stradario[+Armadio], Pozzetto+Stradario[+Armadio])
restano invariati, erano già corretti.

## Novità versione 0.26 (regola 4: filtro opzionale STATO='Nuovo')

Nella regola "4) Tratte Infrastrutture + Pozzetti toccati da Edifici",
nuovo flag opzionale **"Tratte Infrastrutture: solo STATO='Nuovo'"**: se
spuntato, limita solo le tratte Infrastrutture a quelle con STATO='Nuovo';
i Pozzetti restano selezionati senza filtro, come prima.

## Novità versione 0.25 (fix blocco interfaccia sulla regola "toccati da Edifici")

Il layer Edifici può essere molto più grande di quelli usati dalle altre
regole (es. un WFS/basemap con fabbricati su tutto il territorio, non solo
sull'area di progetto): leggerlo e riproiettarlo TUTTO poteva richiedere
moltissimo tempo o restare in attesa dati dal server, con QGIS che sembrava
bloccato. Ora da Edifici si legge SOLO quello che ricade nel rettangolo che
contiene Infrastrutture + Pozzetto (più la tolleranza) — per un WFS il
filtro viene mandato al server invece di scaricare l'intero layer. In più,
cursore di attesa e interfaccia tenuta reattiva durante il calcolo.

## Novità versione 0.24 (nuova regola: tratte + pozzetti toccati da Edifici)

Nella scheda "Seleziona elementi", nuova regola **4) Tratte Infrastrutture +
Pozzetti toccati da Edifici**: imposti il layer Edifici/Fabbricati e il
pulsante seleziona, in un colpo solo, sia le tratte Infrastrutture sia i
Pozzetti che toccano/intersecano quello shape (qualsiasi TIPOLOGIA/STATO,
non solo 'Nuovo'), entro la Tolleranza già impostata nella scheda. Le due
selezioni sono indipendenti tra loro (una tratta viene selezionata anche
senza un pozzetto toccato, e viceversa) e funzionano con "Rimuovi elementi
selezionati" come le altre regole.

## Novità versione 0.23 (trovata la VERA causa di "UNIQUE constraint failed")

Il fix della v0.22 (chiudere/cancellare il file prima di riscrivere) non
bastava: l'errore tornava anche su file nuovi. La causa reale: i layer
modello (Keyplan_*.gpkg, Tavole_Inquadramento.gpkg) hanno un campo
attributo chiamato **'fid'** — la colonna chiave primaria del GeoPackage,
che QGIS espone anche come campo normale quando lo si legge come layer.
Ogni tavola generata copiava gli attributi dall'unica feature modello
selezionata, quindi **tutte** le tavole finivano con lo stesso valore in
quel campo 'fid'. Salvando su GeoPackage, GDAL riconosce un campo chiamato
proprio 'fid' come chiave primaria della tabella: con lo stesso valore
duplicato su ogni tavola, solo la prima veniva scritta e tutte le altre
fallivano con "UNIQUE constraint failed: <nome>.fid" — esattamente il
pattern "solo 1 di N scritte" visto negli errori. Ora il campo 'fid' (se
presente nel modello) viene escluso dallo schema delle tavole generate,
sia per il Keyplan che per i Poligoni di Inquadramento.

## Novità versione 0.22 (salvataggio separato Keyplan/Inquadramento + fix UNIQUE constraint)

1. **Salvataggio separato.** Il pulsante unico è diventato due pulsanti
   indipendenti — "Salva Keyplan su GeoPackage…" e "Salva Poligoni
   Inquadramento su GeoPackage…" — ciascuno con il proprio file scelto al
   momento (anche due GeoPackage o cartelle diverse), un solo layer per
   volta.
2. **Fix "UNIQUE constraint failed" nel salvataggio.** Capitava salvando
   di nuovo sullo stesso file: il layer caricato dal salvataggio
   precedente restava aperto nel progetto e teneva il GeoPackage occupato,
   così la sovrascrittura non ripartiva davvero da zero e la scrittura
   provava ad aggiungere le nuove tavole a quelle vecchie rimaste dentro,
   con lo stesso fid già usato. Ora chiude ogni altro layer che punta già
   a quel file e lo cancella prima di scrivere (o avvisa, invece di
   provarci, se si sta per salvare un layer esattamente sopra al file da
   cui è già stato caricato).

## Novità versione 0.21 (fix margine instabile + fix rigenerazione sulla rete)

1. **Tavole di inquadramento: mai più sovrapposte.** Il vecchio "Margine
   sovrapposizione" aveva un comportamento non prevedibile (numero di
   tavole non monotono al variare del margine, es. 0,01 m → 150 tavole,
   5 m → 60, 10 m → di nuovo 150): permettere overlap reale lascia sempre
   una fascia di bordo scoperta che va ritappata con altre tavole, in modo
   non lineare. Ora le Tavole di inquadramento seguono la stessa regola già
   in uso per il Keyplan: MAI sovrapposte, con un "Margine di sicurezza
   (gap)" opzionale al posto del vecchio margine.
2. **Rigenerazione "solo sulla rete" corretta.** Rimosso il campo Pozzetti
   (semplificazione). Corretto il bug per cui la rigenerazione falliva del
   tutto (Keyplan) o si fermava dopo 1-2 tavole (Tavole di inquadramento):
   la soglia di arresto, pensata per coprire un'area piena, era troppo alta
   per un corridoio stretto attorno alla sola infrastruttura nuova. Le
   dimensioni delle tavole ora si leggono direttamente dai layer modello
   (Keyplan/Inquadramento A e B), non dalle tavole già generate.

## Novità versione 0.20 (rigenerazione mirata sulla rete + salva con stile automatico)

1. **"Ottimizza" ora rigenera davvero la copertura, non sposta solo le
   tavole.** Butta via la copertura esistente e ne crea una nuova usando
   come area da coprire solo un intorno (raggio impostabile, default 0,5 m)
   delle **Infrastrutture Nuove** (STATO='Nuovo') ed eventualmente dei
   **Pozzetti** (nuovo campo opzionale nella stessa sezione), invece
   dell'intero poligono ARLO AREA. Le tavole si posizionano quasi a
   contatto tra loro solo dove c'è davvero rete da documentare — il Keyplan
   resta sempre senza sovrapposizioni — e il numero di tavole scende
   drasticamente, anche lasciando scoperte le parti di ARLO AREA senza
   infrastruttura nuova (voluto).
2. **Nuovo pulsante "Salva Keyplan / Poligoni Inquadramento su
   GeoPackage…".** Scrive i layer temporanei su un GeoPackage a scelta,
   ricarica i layer da disco al posto delle copie in RAM e applica in
   automatico lo stile allegato al plugin (uno per Keyplan, uno per
   Poligoni Inquadramento) — nessuno stile da reimpostare a mano ogni volta.

## Novità versione 0.19 (Keyplan senza sovrapposizioni + margine tavole editabile <0,1 m + potatura ridondanti)

1. **Il Keyplan non genera più tavole sovrapposte.** Ogni tavola candidata
   che si sovrapporrebbe (oltre una tolleranza numerica minima) a una già
   piazzata viene scartata; se non c'è spazio per una tavola intera senza
   sovrapporsi, resta un piccolo residuo scoperto invece di forzare la
   sovrapposizione. Il vecchio campo "Margine sovrapposizione" del Keyplan è
   diventato **"Margine di sicurezza (gap)"**: con 0 le tavole restano al
   massimo a contatto bordo a bordo, con un valore positivo restano pure
   staccate. Anche **"Ottimizza Keyplan sulle infrastrutture nuove"** ora
   verifica, tavola per tavola, che lo spostamento non ne crei una: se serve
   riduce lo spostamento o lascia la tavola ferma.
2. **Il margine di sovrapposizione delle Tavole di inquadramento è editabile
   con precisione al centimetro** (es. 0,02 m), non più solo a decimi di
   metro: un margine minimo ma non nullo evita micro-fessure di area
   scoperta dovute agli arrotondamenti, senza dover generare una tavola
   intera solo per coprirle.
3. **Potatura automatica delle tavole ridondanti.** Dopo ogni generazione
   (Keyplan e Tavole di inquadramento), le tavole il cui contributo di area
   non già coperta dalle vicine è trascurabile vengono rimosse in automatico,
   per ridurre il numero di tavole utili finali senza mai riaprire un buco
   che prima era coperto.

## Novità versione 0.18 (copertura a forma libera + Ottimizza per-tavola)

**Causa reale del problema "griglia limitata a un angolo dell'area":** il
layer ARLO AREA può contenere più feature separate e non adiacenti (aree
armadio sparse su un territorio esteso, non un'unica forma continua). Il
bounding box RETTANGOLARE dell'unione di quelle feature include anche tutto
il vuoto tra una zona e l'altra — ed era quel rettangolo, troppo grande e
per lo più vuoto, ad essere usato per pianificare la griglia.

1. **Le feature di ARLO AREA vengono ora FUSE** in un'unica geometria reale
   (anche multi-parte se non adiacenti), invece di usarne solo il bounding
   box.
2. **Le tavole (Keyplan e Tavole di inquadramento) non sono più su una
   griglia rettangolare rigida.** Vengono posizionate liberamente, una alla
   volta, sul "buco" scoperto più grande rimasto — come mettere delle toppe
   sui buchi di un tessuto — così seguono il contorno reale anche per forme
   strette e serpeggianti lungo le strade, invece di riempire un rettangolo
   pieno di spazio inutile.
3. **Il pulsante "Ottimizza" ora sposta OGNI tavola individualmente**, non
   più tutta la griglia in blocco: ciascuna tavola si centra sul tratto di
   Infrastruttura NUOVA (STATO='Nuovo') più vicino al proprio centro
   attuale. Rimossi dalla sezione "Ottimizza" i campi Armadio Ottico e
   Pozzetto (non più usati per questo scopo): resta solo Infrastrutture.
4. **"Diagnostica estensione" ora mostra anche**: l'area reale della forma
   fusa, quante parti separate ha, e di quanto il bounding box la
   sovrastima (utile per capire se conviene la copertura a forma libera).

## Novità versione 0.17 (fix selezione automatica layer ARLO AREA)

1. **Bug critico corretto: la griglia poteva essere calcolata sul layer
   sbagliato.** `refresh_layers()` (che gira ogni volta che apri il
   dialogo) assegnava il layer atteso per nome (es. "ARLO AREA") SOLO se
   il combo risultava vuoto (`currentLayer() is None`). Ma un
   `QgsMapLayerComboBox` obbligatorio (`allow_empty=False`, usato per ARLO
   AREA dal fix v0.16) seleziona DA SOLO un layer qualsiasi compatibile non
   appena il progetto lo contiene: il combo risultava quindi "valorizzato"
   con un layer diverso (es. un modello Keyplan) senza che la correzione
   automatica per nome scattasse più. Il risultato visibile: la griglia
   veniva generata sull'estensione minuscola del layer sbagliato invece che
   su tutta l'area ARLO AREA, con solo poche tavole in un angolo del
   progetto. Ora il layer con il nome atteso ha SEMPRE la precedenza (se
   esiste nel progetto), ad ogni apertura del dialogo — anche se il combo
   aveva già un valore diverso.
2. **Consiglio pratico:** dopo aver aggiornato il plugin, usa "Diagnostica
   estensione" prima di generare la griglia: il messaggio riporta il nome
   esatto del layer usato e quante feature contribuiscono all'estensione,
   così puoi verificare a colpo d'occhio che sia davvero ARLO AREA.

## Novità versione 0.16 (fix "Estensione vuota", nuovo pulsante Ottimizza)

1. **Estensione griglia Keyplan/Tavole basata SOLO su ARLO AREA.** Prima
   l'estensione era l'unione di ARLO AREA + Armadio Ottico + Infrastrutture
   + Pozzetto: bastava un filtro attivo, un layer senza feature valide o un
   problema di trasformazione CRS su UNO SOLO di questi ultimi tre per
   rompere l'unione e ottenere "Estensione vuota" (o un'estensione più
   piccola del reale) anche con ARLO AREA impostato e popolato
   correttamente. Ora l'estensione è semplicemente il bounding box di ARLO
   AREA (il poligono con tutte le aree armadio da coprire), allargato del
   margine impostato: un solo layer, un solo punto di fallimento, facile da
   verificare con "Diagnostica estensione".
2. **Popup "Estensione vuota" ora spiega subito la causa.** Prima del
   generico "Nessun elemento nei layer selezionati", ora dice se manca il
   layer ARLO AREA, se il layer non ha feature, o se le feature non hanno
   una geometria valida/trasformabile — senza dover aprire "Diagnostica
   estensione" a parte per scoprirlo.
3. **Corretta l'etichetta duplicata "margine estensione".** Il campo aveva
   sia l'etichetta di riga "Margine estensione:" sia un suffisso identico
   sullo spinbox ("… m margine estensione"), risultando in un valore tipo
   "100 m margine estensione" poco chiaro. Ora l'etichetta spiega cosa fa
   il campo (buffer in metri attorno al confine ARLO AREA) e il valore
   mostra solo "100 m".
4. **Nuova sezione "Ottimizza posizionamento griglia" (opzionale).**
   Armadio Ottico, Infrastrutture e Pozzetto non servono più a calcolare
   l'estensione, ma restano utili DOPO aver generato una griglia Keyplan o
   Tavole di inquadramento: i due nuovi pulsanti "Ottimizza griglia…"
   traslano in blocco la griglia già generata (stessa forma, dimensione e
   numero di tavole) per ridurre quanti elementi di quei tre layer
   risultano tagliati a metà tra una tavola e quella adiacente, provando
   una serie di piccoli spostamenti entro il passo della griglia e
   applicando quello che lascia il minor numero di elementi "a cavallo" di
   un bordo.

## Novità versione 0.11 (fix salvataggio GeoPackage Keyplan/Tavole, nuova Regola 1b)

1. **Corretto l'errore "Impossibile salvare... UNIQUE constraint failed:
   ...fid"** che si presentava rigenerando la griglia Keyplan o la griglia
   Tavole di inquadramento su layer GeoPackage. La causa: cancellare tutte
   le feature e aggiungerne di nuove nella STESSA sessione di editing fa sì
   che, su GeoPackage, il fid appena cancellato non sia ancora "libero" per
   il nuovo insert finché la cancellazione non viene commitata. Ora la
   cancellazione viene sempre commitata subito, e solo dopo si apre una
   nuova sessione di editing per gli inserimenti.
2. **Nuova Regola 1b — "Tratte a contatto diretto col Civico (qualsiasi
   tipologia/stato) + pozzetto successivo".** Regola separata e indipendente
   dalla Regola 1: seleziona OGNI tratta Infrastrutture, di qualunque
   TIPOLOGIA e STATO, che tocchi/intersechi direttamente un Civico su almeno
   un estremo, più il Pozzetto vicino all'estremo opposto della stessa
   tratta ("il pozzetto subito dopo"). Non segue la catena e non si ferma a
   un PTE come la Regola 1: serve a coprire i casi che la Regola 1 (limitata
   a STATO='Nuovo' e alla logica di catena/PTE) lascia fuori. Si AGGIUNGE
   alla selezione corrente (non la sostituisce), quindi si può usare insieme
   alla Regola 1 prima di passare a "Rimuovi elementi selezionati".

## Novità versione 0.10 (Regola 1 più permissiva, barriera PTE corretta, mix tavole Keyplan A/B, bugfix griglia/prestazioni/robustezza)

0. **Keyplan e Tavole di inquadramento — forma/dimensione non più impostabili
   a mano, e possibilità di mixare due modelli.** Rimossi i campi manuali
   Larghezza/Altezza/Forma per le Tavole di inquadramento: la forma e la
   dimensione dei riquadri derivano SEMPRE da una tavola modello reale
   (oggetto da posizionare sul progetto), esattamente come già avveniva per
   il Keyplan. È ora possibile impostare, oltre al modello A, anche un
   modello B opzionale (es. una tavola quadrata e una rettangolare da due
   GeoPackage diversi): quando è impostato anche B, il plugin valuta da solo
   se conviene usare solo A, solo B, oppure MIXARE le due forme (B usato solo
   per l'ultima fascia di colonna o riga, dove si adatta meglio allo spazio
   residuo) — sceglie sempre l'opzione che lascia meno area di tavole fuori
   dall'area di progetto, e riporta la scelta fatta nel log. La stessa
   coppia di modelli A/B e lo stesso automatismo valgono sia per "Genera
   griglia Keyplan" sia per "Genera griglia tavole" (Poligoni di
   Inquadramento), che restano quindi sempre coerenti fra loro.
1. **Regola 1 — selezionate anche le tratte che non hanno ancora raggiunto
   un PTE.** Prima, oltre alla tratta che tocca direttamente il Civico,
   tutte le altre tratte della catena venivano incluse SOLO se la catena
   arrivava effettivamente a un ROE PTE (altrimenti restava selezionata
   solo la prima tratta sul Civico). Ora l'intera catena collegata al
   Civico viene selezionata (pozzetti compresi), anche se non raggiunge
   ancora un PTE, con le stesse eccezioni di sempre: tratte che corrono
   lungo il Cavo Ottico restano escluse, e l'intera catena resta esclusa
   se arriva a un PTE Light Diramatore condiviso con un altro PTE tramite
   il Cavo Raccordo.
2. **Regola 1 — corretta la verifica di barriera al ROE PTE.** La catena si
   fermava a un PTE se ne veniva trovato uno entro tolleranza vicino a UNO
   dei due estremi che si toccano; con tolleranze elevate questo poteva
   generare falsi positivi (un PTE vicino ma non realmente al nodo
   condiviso). Ora viene verificato che il PTE sia entro tolleranza da
   ENTRAMBI gli estremi, cioè che sia davvero il punto di giunzione.
3. **Griglie Keyplan e Tavole di inquadramento — corretto il calcolo delle
   tavole in eccesso.** Il ciclo while precedente poteva generare una riga o
   colonna aggiuntiva quasi interamente fuori dall'area di progetto quando
   quest'ultima superava di poco la dimensione della tavola modello. Il
   numero di righe/colonne è ora calcolato in anticipo con `math.ceil()`
   (o con la stessa logica di valutazione usata per il mix A/B).
4. **Salvataggi falliti ora mostrano il motivo.** Tutti i punti in cui il
   plugin salva modifiche (rimozione elementi, griglia Keyplan, griglia
   tavole, coni fotografici, aggiornamento LUNGHEZZA) mostrano ora il
   dettaglio di `layer.commitErrors()` quando il commit fallisce, invece
   del solo esito booleano.
5. **Prestazioni.** `_unione_layer()` usa `QgsGeometry.unaryUnion()` invece
   di un ciclo di `combine()` (molto più veloce su layer con molte feature);
   `_trova_pozzetti()` non ricrea più due volte la stessa geometria punto
   per ogni pozzetto.
6. **Robustezza.** Le trasformazioni di CRS non interrompono più il plugin
   in caso di errore (vengono ignorate con un avviso in console); le
   geometrie non valide vengono "riparate" (`makeValid()`) prima di calcoli
   di intersezione; `_endpoints()` ignora esplicitamente geometrie non
   lineari invece di affidarsi implicitamente ad `asPolyline()`.

## Novità versione 0.9 (Aerea inclusa in Regola 1, Cavo Raccordo, Regola 3 su Aerea, griglie Keyplan/Inquadramento reali)

1. **Regola 1 — Aerea sempre inclusa.** Rimossa l'opzione "Escludi
   TIPOLOGIA='Aerea'": le tratte aeree con STATO='Nuovo' partecipano ora
   sempre alla ricerca delle catene Civico → PTE, come tutte le altre.
2. **Regola 1 — nuovo layer "Cavo Raccordo" e nuova esclusione sul PTE
   Light Diramatore.** Se la catena selezionata arriva a un ROE PTE di tipo
   "PTE Light Diramatore" e quel punto risulta collegato, tramite una tratta
   dello shape Cavo Raccordo (bretelle tra PTE), a un ALTRO ROE PTE di
   qualsiasi tipologia, si tratta di un raccordo condiviso con un altro
   permesso: l'intera catena e i pozzetti compresi NON vengono selezionati.
   Il log di Regola 1 riporta il numero di catene escluse per questo motivo.
3. **Regola 3 — le tratte Aerea 'Nuovo' non escludono più il pozzetto.**
   Un Pozzetto che tocca solo infrastruttura esistente più eventuali tratte
   Aerea con STATO='Nuovo' viene comunque selezionato: l'Aerea 'Nuovo' non è
   più trattata come "nuova interrata" ai fini di questa regola.
4. **Keyplan — griglia reale invece di una singola geometria stirata.**
   "Posiziona Keyplan" generava un'unica geometria stirata sull'intera
   estensione del progetto, deformando la tavola. Ora il pulsante ("Genera
   griglia Keyplan sull'area di progetto") prende la feature presente nel
   layer (selezionata, o la prima) come MODELLO — stessa forma e dimensione
   reale a scala fissa, es. da Keyplan_Quadrato.gpkg o
   Keyplan_Rettangolare.gpkg — e genera una griglia di copie traslate (mai
   deformate) che insieme coprono per intero Armadio Ottico, Pozzetti e
   Infrastrutture. Il layer viene sovrascritto con le tavole numerate (campo
   "Numero Tav" se presente).
5. **Tavole di inquadramento — coerenti con la griglia Keyplan.** Il nuovo
   checkbox "Usa le dimensioni reali del layer Keyplan modello" (attivo di
   default) fa sì che ogni riquadro della griglia di inquadramento abbia le
   stesse dimensioni reali della tavola Keyplan, invece dei soli valori
   manuali Larghezza/Altezza (che restano disponibili come alternativa/
   fallback se il layer Keyplan è vuoto o il checkbox è disattivato).

## Novità versione 0.8 (PTE Light come gli altri PTE, tab riorganizzati, Keyplan automatico)

1. **Regola 1 corretta sui PTE** — un ROE PTE, di QUALSIASI tipologia
   (incluso "PTE Light Diramatore"), ora funge sempre da **barriera** nella
   ricostruzione della catena Civico→PTE: la catena selezionata si ferma nel
   punto in cui incontra un PTE e non prosegue oltre, verso un eventuale PTE
   successivo condiviso. Il checkbox dedicato ("Ferma la catena a qualsiasi
   ROE PTE...") resta disponibile per disattivare la barriera se necessario,
   ma di default è attivo e il PTE Light è trattato esattamente come gli altri.
2. **Pozzetti esclusi anche se sul Cavo Ottico** — oltre al pozzetto sede di
   PTE, la Regola 1 torna a escludere anche i pozzetti che ricadono sul Cavo
   Ottico (dorsale condivisa), comportamento che si era perso in una versione
   precedente.
3. **Scheda "Shape di consegna" spostata per ultima.**
4. **Shape "ARLO AREA" sostituito con "Armadio Ottico"** come layer da unire
   nei 3 shape di consegna (ARMADI_FOTO, SCAVI_STRADE, POZZETTI_STRADE).
5. **Nuovi checkbox opzionali** per scegliere quali shape includere nel join
   di ogni shape di consegna (Armadio Ottico / Stradario): l'automatismo resta
   attivo di default, i checkbox servono solo per escludere volutamente un
   layer in caso di problemi.
6. **Scheda "Keyplan e tavole" riscritta come semplice posizionatore
   automatico**: nessun collegamento a layout di stampa (.qpt), nessun
   riferimento a elementi mappa nei layout. Il pulsante "Posiziona Keyplan"
   sposta/ridimensiona direttamente la geometria dello shape (o layer
   GeoPackage) Keyplan sopra l'area di progetto (Armadio Ottico, Pozzetti e
   Infrastrutture); "Genera griglia tavole" crea allo stesso modo i riquadri
   di inquadramento numerati.
7. **Scheda "Punti di ripresa" semplificata**: rimossa la funzione (non
   funzionante) di posizionamento coni accanto alle aree ARLO. Resta solo la
   generazione dei coni davanti agli Armadi Ottici (shape "Armadio Ottico"),
   perpendicolari al muro più vicino.

## Novità versione 0.5 (PTE Light: solo tratte sul civico + esclusioni pozzetto)

Due modifiche su richiesta, basate sul caso reale del cavo dorsale condiviso:

1. **Cambiato il comportamento sul PTE "Light Diramatore"** — prima, se una
   catena Civico↔PTE arrivava a un PTE di tipo "PTE Light Diramatore" (raccordo
   condiviso tra più civici), l'intera catena veniva scartata (nessuna
   selezione). Ora, in quel caso, si seleziona comunque qualcosa ma **solo le
   tratte del gruppo che toccano direttamente il Civico** — non l'intero
   percorso fino al PTE, che potrebbe essere condiviso con altri permessi.
   Il checkbox si chiama ora "Se il PTE è 'PTE Light Diramatore' ... seleziona
   SOLO le tratte toccate direttamente dal Civico" (attivo di default).
2. **Pozzetto sede di PTE escluso sempre** — un Pozzetto la cui posizione
   coincide con un punto ROE PTE (entro tolleranza) non viene più selezionato
   dalla Regola 1: è la sede fisica del PTE, non un pozzetto di passaggio da
   rimuovere.
3. **Pozzetto sul CAVO OTTICO escluso** — se il layer Cavo ottico è impostato
   (stesso layer/tolleranza già usati per escludere le tratte sulla dorsale),
   anche i Pozzetto che ricadono su di esso vengono esclusi dalla selezione,
   per lo stesso motivo: fanno parte della dorsale condivisa.

Il log della Regola 1 ora riporta separatamente: catene trovate, catene
ridotte per PTE light, tratte escluse per sovrapposizione al cavo ottico,
pozzetti esclusi perché sede-PTE e pozzetti esclusi perché sul cavo ottico.

## Novità versione 0.3 (fix basati sui tuoi shapefile reali)

Analizzando i tuoi shapefile ho trovato due problemi concreti sui tuoi dati:

1. **685 delle 1771 tratte INFRASTRUTTURE con STATO='Nuovo' sono TIPOLOGIA='Aerea'**
   (non interrate). Il tuo workflow riguarda esplicitamente le nuove interrate, quindi
   la Regola 1 ora esclude di default le tratte aeree dalla ricerca di catene
   Civico↔PTE (checkbox "Escludi tratte aeree", disattivabile se serve).
2. **I tuoi shapefile sono in CRS geografico (gradi, WGS84)**, non in un sistema
   metrico. La tolleranza è sempre nelle unità del CRS di **progetto**: se il
   progetto QGIS resta in gradi, 0.05 equivale a ~5 km e non 5 cm. Ho aggiunto un
   avviso diretto nella scheda Pulizia bozza; se i tuoi progetti sono in gradi,
   **imposta il CRS di progetto su un sistema metrico proiettato** (per l'area di
   Podenzano/Piacenza va bene UTM 32N — EPSG:32632) prima di usare le regole,
   altrimenti la tolleranza non ha senso in metri.

Ho anche sostituito il doppio ciclo O(n²) della Regola 1 con un indice spaziale
sugli estremi delle tratte: con ~1800 tratte "Nuovo" come nei tuoi dati, il doppio
ciclo naive sarebbe stato lento; ora la ricerca delle catene scala molto meglio.

## Novità versione 0.2 (fix Regola 1 + robustezza CRS)

**Problema risolto:** nel workflow reale il percorso tra CIVICO e ROE PTE non è
quasi mai una singola linea, ma è spezzato in più segmenti con vertici
intermedi. La vecchia Regola 1 cercava una tratta con **entrambi** gli estremi
che toccavano direttamente Civico e PTE, quindi le tratte intermedie non
venivano mai trovate e la selezione restava vuota.

**Come funziona ora:** la Regola 1 costruisce le **catene** di tratte
Infrastrutture con `STATO = 'Nuovo'` collegate tra loro vertice-a-vertice
(entro la tolleranza impostata), e seleziona l'intera catena se, nel
complesso, tocca un Civico da un lato e un ROE PTE dall'altro. I Pozzetto
lungo il tracciato vengono trovati con distanza punto-linea, non solo agli
estremi — invariato rispetto a prima.

**Robustezza CRS:** tutte le regole (1, 2, 3) e anche l'analisi spaziale
generica ora trasformano le geometrie nel CRS di progetto prima di calcolare
qualunque distanza. Se i layer coinvolti hanno CRS diversi, il confronto
funziona comunque invece di fallire silenziosamente restituendo zero
risultati (probabile causa del "seleziona pozzetti non funziona" segnalato).

**Nuovo pulsante "Diagnostica tolleranza"** nella scheda Pulizia bozza: calcola
le distanze minime reali tra Infrastrutture↔Civici, Infrastrutture↔PTE e
Pozzetto↔tratte. Usalo prima di lanciare le regole se sospetti che la
tolleranza di default (0.05 m) sia troppo bassa per il tuo dato.

---

Plugin per la gestione unificata dei permessi FTTH (scavi, occupazione suolo
pubblico, attraversamenti), con due strumenti principali:

1. **Analisi spaziale**
   - Intersezione (con buffer opzionale) tra il layer permessi e un layer di
     riferimento qualsiasi (confini comunali, aree di cantiere, vincoli, ecc.)
   - Rilevamento automatico delle sovrapposizioni tra permessi dello stesso
     layer (utile per individuare conflitti, es. scavi che si intersecano)
   - Gli elementi trovati vengono selezionati ed evidenziati in mappa

2. **Seleziona e rimuovi**
   - Selezione elementi tramite espressione QGIS (editor espressioni
     integrato, con suggerimento campi/funzioni)
   - Esempi di espressioni utilizzabili:
     - `stato = 'scaduto'`
     - `tipo_permesso = 'attraversamento' AND stato = 'respinto'`
     - `data_scadenza < now()`
   - Rimozione guidata degli elementi selezionati, con richiesta di conferma
     e gestione della modalità di editing (avvio/commit automatico se il
     layer non è già in editing)

## Installazione

1. Comprimi la cartella `ftth_permessi` in un file `.zip`
   (la cartella deve stare alla radice dello zip, es. `ftth_permessi/metadata.txt`)
2. In QGIS: **Plugin → Gestisci e installa plugin → Installa da ZIP**
3. Seleziona lo zip creato e conferma
4. Il plugin comparirà in toolbar e nel menu **Plugin → FTTH Permessi**

In alternativa, per lo sviluppo: copia la cartella `ftth_permessi` dentro la
cartella plugin di QGIS:

- Windows: `C:\Users\<utente>\AppData\Roaming\QGIS\QGIS3\profiles\default\python\plugins\`
- Linux/Mac: `~/.local/share/QGIS/QGIS3/profiles/default/python/plugins/`

Poi attivalo da **Plugin → Gestisci e installa plugin → Installati**.

## Struttura del layer permessi (suggerita)

Il plugin funziona con qualsiasi struttura di attributi, ma per sfruttare al
meglio gli esempi di espressione è utile avere campi tipo:

| Campo             | Tipo   | Esempio                          |
|--------------------|--------|-----------------------------------|
| tipo_permesso      | testo  | scavo / occupazione_suolo / attraversamento |
| stato              | testo  | richiesto / approvato / respinto / scaduto |
| comune              | testo  | Roma                              |
| data_presentazione  | data   | 2026-03-01                        |
| data_scadenza       | data   | 2026-09-01                        |
| ente_competente     | testo  | Comune di Roma – Dip. Mobilità   |

## Note tecniche

- Compatibile con QGIS 3.16+
- Il rilevamento sovrapposizioni usa un indice spaziale (`QgsSpatialIndex`)
  per restare performante anche su layer con molti elementi
- La rimozione elimina le feature dalla sorgente dati reale (shapefile,
  GeoPackage, PostGIS, ecc.): usa con attenzione e valuta di lavorare su una
  copia del layer per i test iniziali

## Prossimi sviluppi possibili

- Form dedicato per l'inserimento di un nuovo permesso con validazione campi
- Generazione automatica di lettere/report di richiesta permesso (docx/pdf)
- Notifiche/evidenziazione automatica dei permessi in scadenza all'apertura
  del progetto
- Storico stati con log delle modifiche
