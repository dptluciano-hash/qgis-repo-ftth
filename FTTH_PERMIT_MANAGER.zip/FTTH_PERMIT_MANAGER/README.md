# FTTH Permessi Manager — plugin QGIS

Strumento per la gestione dell'iter di permesso FTTH: dalla selezione degli
elementi di rete fino alla produzione dei file da consegnare, sia per le
pratiche verso il Comune sia verso altri Enti (ANAS, Province).

Versione corrente: **0.78** — la cronologia completa delle modifiche, con le
motivazioni di ogni scelta, è in [CHANGELOG.md](CHANGELOG.md).

## Installazione

1. Copia la cartella `ftth_permessi` in
   `%AppData%/QGIS/QGIS3/profiles/default/python/plugins/`
   (oppure installa lo zip da *Plugin → Gestisci e installa plugin →
   Installa da ZIP*).
2. Riavvia QGIS e attiva "FTTH Permessi Manager" nel gestore plugin.
3. Il pulsante compare nella barra degli strumenti; il pannello si intitola
   "Gestione Permessi FTTH — v0.78" (la versione nel titolo dice a colpo
   d'occhio cosa sta girando).

Richiede QGIS ≥ 3.16.

## Come è organizzato

Il pannello ha tre rami; ogni scheda ha un pulsante **Guida** con la
spiegazione completa, il flusso passo per passo e le cause tipiche dei
problemi.

**Comune** — la pratica comunale:
- *Seleziona elementi*: regole di selezione della rete (catene Civico → PTE,
  tratte su PTE interno, pozzetti su esistente, contatto con edifici,
  possibile proprietà privata via sedime OSM o stradario locale).
- *Keyplan e tavole*: griglia di tavole a copertura adattiva e keyplan.
- *Punti di ripresa*: coni fotografici posizionati sullo stradario.
- *Esportazione*: shape di consegna (join "vettore più vicino"), atlante PDF,
  unione PDF, evidenza delle strade interessate.

**Altri Enti** — le pratiche verso ANAS e Province:
- *Chilometriche*: progressive chilometriche dai cippi, con corridoi ricuciti,
  controllo di coerenza e diagnostica.
- *Etichette*: diciture di posa componibili (chilometrica + lavorazione).
- *Suolo comunale*: separa gli elementi fuori dagli stradari di competenza.
- *Esportazione*: copia indipendente della scheda del ramo Comune, con
  impostazioni proprie.

**Cartografia di base** — interventi sul dato di partenza:
- *Allinea*: trasformazione di similitudine da punti di controllo, applicata
  in blocco per non rompere i collegamenti della rete.
- *Edifici in carreggiata*: trova e rimuove (con salvataggio reversibile su
  GeoPackage) le geometrie di edifici minori che il dato DBSN fa cadere nella
  sede stradale.

Le impostazioni dei campi vengono ricordate fra le sessioni; i combo dei layer
no, di proposito (puntano a un progetto specifico) — per quelli valgono i
preset automatici per nome.

## Struttura del codice

| File | Contenuto |
|---|---|
| `ftth_permessi_dialog.py` | Interfaccia e operazioni QGIS (il pannello) |
| `ftth_core.py` | Logica di puro calcolo, senza dipendenze QGIS/Qt |
| `tests/test_core.py` | Test automatici della logica pura |
| `ftth_permessi.py` / `__init__.py` | Registrazione del plugin in QGIS |

## Test

La logica di calcolo (parser dei cippi, fusione intervalli, trasformazione di
similitudine, formattazioni) è testata e gira senza QGIS:

```bash
cd ftth_permessi
python -m unittest discover tests -v
```

I casi di test fissano i comportamenti descritti nel changelog: se una
modifica futura rompe uno di quei comportamenti, i test lo dicono prima del
rilascio.
