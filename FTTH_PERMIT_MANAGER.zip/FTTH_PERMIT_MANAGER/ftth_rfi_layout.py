# -*- coding: utf-8 -*-
"""Generatore tavole di stampa per le istanze RFI (Corografia + Planimetria PL).

Costruisce due QgsPrintLayout dentro il progetto corrente, in stile coerente col
cartiglio gia' usato dal service (striscia verticale a destra):
  COMUNE - ISTANZA DI AUTORIZZAZIONE RFI - nome tavola - DATI INTERFERENZA -
  LEGENDA - COMMITTENTE (FiberCop) - PROGETTISTA (riquadro VUOTO per timbro/firma) -
  SCALA / DATA / TAV.

Il modulo importa solo qgis.core (nessuna dipendenza da PyQt UI o dal dialog),
quindi e' collaudabile headless con python-qgis-ltr.
"""
from qgis.core import (
    QgsPrintLayout, QgsLayoutItemMap, QgsLayoutItemLabel, QgsLayoutItemLegend,
    QgsLayoutItemShape, QgsLayoutSize, QgsLayoutPoint, QgsLayoutMeasurement,
    QgsUnitTypes, QgsRectangle, QgsCoordinateReferenceSystem,
    QgsCoordinateTransform, QgsProject, QgsLayoutExporter, QgsLayoutItemPage,
    QgsLegendStyle, QgsLayoutItemPicture,
)
from qgis.PyQt.QtGui import QFont, QColor
from qgis.PyQt.QtCore import QRectF, Qt

MM = QgsUnitTypes.LayoutMillimeters


# --------------------------------------------------------------------------- #
#  Helper geometria
# --------------------------------------------------------------------------- #
def _estensione(layers, crs_dest, margine_frazione=0.15, project=None):
    """Estensione combinata dei layer (trasformata in crs_dest) + margine."""
    rect = None
    for lyr in layers:
        if lyr is None:
            continue
        try:
            ext = lyr.extent()
            if ext.isEmpty():
                continue
            src = lyr.crs()
            if src.isValid() and crs_dest.isValid() and src != crs_dest:
                ctx = project.transformContext() if project else QgsProject.instance().transformContext()
                tr = QgsCoordinateTransform(src, crs_dest, ctx)
                ext = tr.transformBoundingBox(ext)
        except Exception:
            continue
        rect = QgsRectangle(ext) if rect is None else (rect.combineExtentWith(ext) or rect)
    if rect is None or rect.isEmpty():
        return None
    dx, dy = rect.width() * margine_frazione, rect.height() * margine_frazione
    d = max(dx, dy, 1.0)
    rect.grow(d)
    return rect


def _trova(project, *nomi):
    """Primo layer il cui nome contiene uno dei frammenti (case-insensitive)."""
    for frag in nomi:
        fl = frag.lower()
        for lyr in project.mapLayers().values():
            if fl in lyr.name().lower():
                return lyr
    return None


# --------------------------------------------------------------------------- #
#  Helper item
# --------------------------------------------------------------------------- #
def _lbl(layout, x, y, w, h, testo, size=9, bold=False, align=Qt.AlignLeft,
         valign=Qt.AlignTop, frame=False, bg=None, fontcol=None):
    it = QgsLayoutItemLabel(layout)
    it.setText(testo)
    f = QFont("Arial", int(size))
    f.setBold(bold)
    f.setPointSizeF(float(size))
    it.setFont(f)
    it.setHAlign(align)
    it.setVAlign(valign)
    it.setMarginX(1.2)
    it.setMarginY(1.0)
    if fontcol:
        it.setFontColor(fontcol)
    layout.addLayoutItem(it)
    it.attemptMove(QgsLayoutPoint(x, y, MM))
    it.attemptResize(QgsLayoutSize(w, h, MM))
    it.setFrameEnabled(frame)
    if frame:
        it.setFrameStrokeWidth(QgsLayoutMeasurement(0.3, MM))
    if bg is not None:
        it.setBackgroundEnabled(True)
        it.setBackgroundColor(bg)
    else:
        it.setBackgroundEnabled(False)
    return it


def _box(layout, x, y, w, h):
    """Rettangolo di cornice (senza testo)."""
    sh = QgsLayoutItemShape(layout)
    sh.setShapeType(QgsLayoutItemShape.Rectangle)
    layout.addLayoutItem(sh)
    sh.attemptMove(QgsLayoutPoint(x, y, MM))
    sh.attemptResize(QgsLayoutSize(w, h, MM))
    try:
        sym = sh.symbol()
        sym.setColor(QColor(255, 255, 255, 0))          # riempimento trasparente
        sl = sym.symbolLayer(0)
        sl.setStrokeColor(QColor(0, 0, 0))
        sl.setStrokeWidth(0.3)
    except Exception:
        pass
    return sh


# --------------------------------------------------------------------------- #
#  Cartiglio
# --------------------------------------------------------------------------- #
def _cartiglio(layout, mapp, dati, nome_tavola, scala_txt, cx, cy, cw, ch,
               logo_fibercop=None):
    """Striscia cartiglio a destra (cx,cy,cw,ch in mm)."""
    from datetime import date
    _box(layout, cx, cy, cw, ch)                       # cornice esterna
    pad = 2.0
    x = cx + pad
    w = cw - 2 * pad
    y = cy + pad

    # COMUNE (titolo grande)
    comune = (dati.get("comune") or "COMUNE").upper()
    _lbl(layout, x, y, w, 12, comune, size=15, bold=True, align=Qt.AlignHCenter)
    y += 13
    # sottotitolo istanza
    _lbl(layout, x, y, w, 12,
         "ISTANZA DI AUTORIZZAZIONE RFI\nSCAVI E POSA IN FASCIA DI RISPETTO FERROVIARIA",
         size=7.5, bold=True, align=Qt.AlignHCenter)
    y += 13
    # nome tavola
    _lbl(layout, x, y, w, 8, nome_tavola, size=11, bold=True,
         align=Qt.AlignHCenter, frame=True, bg=QColor(230, 230, 230))
    y += 9

    # ---- riquadro DATI INTERFERENZA ----
    linea = dati.get("linea") or "—"
    kmda = dati.get("km_da") or "—"
    kma = dati.get("km_a") or "—"
    doit = dati.get("doit_citta") or "—"
    fascia = dati.get("fascia") or "6–30"
    dati_txt = (
        f"Linea ferroviaria:\n  {linea}\n"
        f"Progressiva km:  da {kmda}  a {kma}\n"
        f"D.O.IT. competente:  {doit}\n"
        f"Fascia di rispetto:  {fascia} m\n"
        f"Rif. norm.:  art. 58 D.P.R. 753/1980"
    )
    dh = 34
    _lbl(layout, x, y, w, dh, dati_txt, size=7.5, align=Qt.AlignLeft, frame=True)
    y += dh + 2

    # ---- LEGENDA ----
    _lbl(layout, x, y, w, 6, "LEGENDA", size=9, bold=True, align=Qt.AlignHCenter,
         frame=True, bg=QColor(230, 230, 230))
    y += 6
    leg = QgsLayoutItemLegend(layout)
    leg.setLinkedMap(mapp)
    leg.setTitle("")
    try:
        leg.setAutoUpdateModel(True)
        leg.rstyle(QgsLegendStyle.Title).setMargin(QgsLegendStyle.Top, 0)
    except Exception:
        pass
    lh = 38
    layout.addLayoutItem(leg)
    leg.attemptMove(QgsLayoutPoint(x, y, MM))
    leg.attemptResize(QgsLayoutSize(w, lh, MM))
    leg.setFrameEnabled(True)
    leg.setFrameStrokeWidth(QgsLayoutMeasurement(0.3, MM))
    try:
        lf = QFont("Arial", 6)
        leg.setStyleFont(QgsLegendStyle.SymbolLabel, lf)
    except Exception:
        pass
    y += lh + 2

    # ---- COMMITTENTE ----
    _lbl(layout, x, y, w, 5, "COMMITTENTE", size=8, bold=True,
         align=Qt.AlignHCenter, frame=True, bg=QColor(230, 230, 230))
    y += 5
    comm_h = 14
    if logo_fibercop:
        pic = QgsLayoutItemPicture(layout)
        pic.setPicturePath(logo_fibercop)
        layout.addLayoutItem(pic)
        pic.attemptMove(QgsLayoutPoint(x + 1, y + 1, MM))
        pic.attemptResize(QgsLayoutSize(w - 2, comm_h - 2, MM))
        pic.setResizeMode(QgsLayoutItemPicture.Zoom)
        _box(layout, x, y, w, comm_h)
    else:
        _lbl(layout, x, y, w, comm_h, "FiberCop S.p.A.", size=9, bold=True,
             align=Qt.AlignHCenter, valign=Qt.AlignVCenter, frame=True)
    y += comm_h + 2

    # ---- PROGETTISTA (riquadro VUOTO per timbro/firma) ----
    _lbl(layout, x, y, w, 5, "IL PROGETTISTA  (timbro e firma)", size=7.5, bold=True,
         align=Qt.AlignHCenter, frame=True, bg=QColor(230, 230, 230))
    y += 5
    prog_h = ch - (y - cy) - 16
    if prog_h < 18:
        prog_h = 18
    _box(layout, x, y, w, prog_h)                       # spazio vuoto per il timbro
    y += prog_h + 2

    # ---- SCALA / DATA / TAV ----
    riga_h = 10
    ww = (w - 2) / 3.0
    _lbl(layout, x, y, ww, riga_h, f"SCALA\n{scala_txt}", size=7.5, bold=True,
         align=Qt.AlignHCenter, valign=Qt.AlignVCenter, frame=True)
    _lbl(layout, x + ww + 1, y, ww, riga_h,
         "DATA\n" + date.today().strftime("%d/%m/%Y"), size=7.5, bold=True,
         align=Qt.AlignHCenter, valign=Qt.AlignVCenter, frame=True)
    _lbl(layout, x + 2 * ww + 2, y, ww, riga_h, "TAV.\n1 / 1", size=7.5, bold=True,
         align=Qt.AlignHCenter, valign=Qt.AlignVCenter, frame=True)


# --------------------------------------------------------------------------- #
#  Costruzione di un layout (mappa + cartiglio)
# --------------------------------------------------------------------------- #
def _crea_layout(project, nome, nome_tavola, extent, crs, dati,
                 formato=(420, 297), logo_fibercop=None):
    mgr = project.layoutManager()
    esistente = mgr.layoutByName(nome)
    if esistente is not None:
        mgr.removeLayout(esistente)

    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName(nome)
    pw, ph = formato
    layout.pageCollection().pages()[0].setPageSize(QgsLayoutSize(pw, ph, MM))

    marg = 5.0
    cw = 92.0                                            # larghezza cartiglio
    cx = pw - marg - cw
    cy = marg
    ch = ph - 2 * marg
    # mappa a sinistra
    mx, my = marg, marg
    mw = cx - marg - 3.0
    mh = ph - 2 * marg

    mapp = QgsLayoutItemMap(layout)
    mapp.setCrs(crs)
    layout.addLayoutItem(mapp)
    mapp.attemptMove(QgsLayoutPoint(mx, my, MM))
    mapp.attemptResize(QgsLayoutSize(mw, mh, MM))
    if extent is not None:
        # adatta il rapporto d'aspetto della mappa al riquadro
        mapp.zoomToExtent(extent)
    mapp.setFrameEnabled(True)
    mapp.setFrameStrokeWidth(QgsLayoutMeasurement(0.4, MM))

    scala_txt = "1:%d" % round(mapp.scale()) if mapp.scale() else "—"
    _cartiglio(layout, mapp, dati, nome_tavola, scala_txt, cx, cy, cw, ch,
               logo_fibercop=logo_fibercop)

    mgr.addLayout(layout)
    return layout


# --------------------------------------------------------------------------- #
#  API pubblica
# --------------------------------------------------------------------------- #
def genera_tavole(project, dati, formato=(420, 297), logo_fibercop=None):
    """Crea (o rigenera) le due tavole RFI nel progetto.

    dati: dict con comune, linea, km_da, km_a, doit_citta, fascia.
    Ritorna la lista dei nomi dei layout creati.
    """
    crs = project.crs()
    if not crs.isValid():
        crs = QgsCoordinateReferenceSystem("EPSG:25832")

    ferrovia = _trova(project, "Ferrovia RFI", "ferrovia")
    fascia = _trova(project, "Fascia di rispetto RFI", "fascia")
    cippi = _trova(project, "Cippi km RFI", "cippi")
    infra = _trova(project, "03 INFRASTRUTTURE", "infrastrutture")

    creati = []

    # --- COROGRAFIA: inquadramento largo (linea + fascia) ---
    ext_coro = _estensione([fascia, ferrovia], crs, margine_frazione=3.0,
                           project=project)
    if ext_coro is None:
        ext_coro = _estensione([infra, ferrovia], crs, 3.0, project)
    lay1 = _crea_layout(project, "RFI - Corografia", "COROGRAFIA",
                        ext_coro, crs, dati, formato, logo_fibercop)
    creati.append(lay1.name())

    # --- PLANIMETRIA (PL): dettaglio interferenza ---
    ext_pl = _estensione([fascia, infra], crs, margine_frazione=0.10,
                         project=project)
    if ext_pl is None:
        ext_pl = ext_coro
    lay2 = _crea_layout(project, "RFI - Planimetria (PL)", "PLANIMETRIA DI PROGETTO",
                        ext_pl, crs, dati, formato, logo_fibercop)
    creati.append(lay2.name())

    return creati


def esporta_pdf(project, nomi, out_dir):
    """Esporta in PDF i layout indicati. Ritorna lista (nome, path, ok)."""
    import os
    mgr = project.layoutManager()
    res = []
    for nome in nomi:
        lay = mgr.layoutByName(nome)
        if lay is None:
            res.append((nome, None, False))
            continue
        safe = nome.replace(" ", "_").replace("(", "").replace(")", "")
        path = os.path.join(out_dir, safe + ".pdf")
        exp = QgsLayoutExporter(lay)
        settings = QgsLayoutExporter.PdfExportSettings()
        r = exp.exportToPdf(path, settings)
        ok = (r == QgsLayoutExporter.Success) and os.path.exists(path)
        res.append((nome, path, ok))
    return res
