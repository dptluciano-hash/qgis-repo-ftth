# -*- coding: utf-8 -*-
"""Planimetria 1.1 PL delle istanze ferroviarie come layout di stampa QGIS.

Un layout A3 orizzontale per istanza, sul modello delle tavole delle pratiche
Beexact (Andrano, Poggio Rusco):
  - COROGRAFIA: inquadramento con un cerchio rosso per interferenza;
  - TAVOLA n (una per interferenza): ORTOFOTO, PLANIMETRIA in scala con fascia
    e km, ESTRATTO CATASTALE (WMS Agenzia delle Entrate), SEZIONE, FOTO;
  - TAVOLA PC: particolari costruttivi.
Cartiglio a destra: legenda, logo FiberCop, dati della richiesta, logo
Beexact, data/scala/nome file/tavola. Nessun timbro.

Importa solo qgis.core: si collauda headless con python-qgis-ltr.
(c) Beexact S.r.l.
"""
import datetime
import os
import re

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsGeometry, QgsLayerTreeLayer, QgsLayoutExporter, QgsLayoutItemLabel,
    QgsLayoutItemLegend, QgsLayoutItemMap, QgsLayoutItemPage, QgsLayoutItemPicture,
    QgsLayoutItemShape, QgsLayoutMeasurement, QgsLayoutPoint, QgsLayoutSize,
    QgsLegendStyle, QgsMarkerSymbol, QgsPalLayerSettings, QgsPointXY, QgsPrintLayout,
    QgsProject, QgsRasterLayer, QgsRectangle, QgsSingleSymbolRenderer,
    QgsTextBufferSettings, QgsTextFormat, QgsUnitTypes, QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
)

MM = QgsUnitTypes.LayoutMillimeters
QUI = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(QUI, "assets")
GRUPPO_BASI = "RFI - basi per le tavole"

PAGINA = (420.0, 297.0)          # A3 orizzontale
MARGINE = 8.0
CART_W = 88.0                    # larghezza cartiglio
SCALE = [500, 1000, 2000, 5000, 10000, 25000, 50000]

# CARTO ora richiede una chiave API: base OpenStreetMap standard
URL_CHIARA = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
URL_ORTO = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
URL_CATASTO = "https://wms.cartografia.agenziaentrate.gov.it/inspire/wms/ows01.php"

TECNICA_TAVOLA = {
    "trincea": "SCAVO TRADIZIONALE",
    "minitrincea": "SCAVO MINITRINCEA",
    "microtrincea": "SCAVO MICROTRINCEA",
    "nodig": "PERFORAZIONE NO DIG",
}


# --------------------------------------------------------------------------- #
#  Layer di supporto
# --------------------------------------------------------------------------- #


def logo_fibercop():
    """Logo FiberCop del cartiglio: classico o «Milano Cortina 2026» secondo il
    flag del progetto (ftth_logo)."""
    try:
        from . import ftth_logo as _LOGO
    except ImportError:
        import ftth_logo as _LOGO
    try:
        return _LOGO.percorso_logo(QgsProject.instance())
    except Exception:  # noqa: BLE001
        return os.path.join(ASSETS, "fibercop_logo.png")
def _testo_armadio(e):
    """«POSA ARMADIO ARLO 201» (numero ARLO dal campo AREA_AO), come nelle
    altre schede."""
    try:
        from . import ftth_acque as _A
    except ImportError:
        import ftth_acque as _A
    return _A.testo_elemento_auto(e)
def _gruppo_basi(project):
    root = project.layerTreeRoot()
    g = root.findGroup(GRUPPO_BASI)
    if g is None:
        g = root.addGroup(GRUPPO_BASI)
        g.setItemVisibilityChecked(False)
        g.setExpanded(False)
    return g


def _aggiungi_base(project, layer):
    """Layer di servizio: nel progetto (serve al layout salvato) ma spento e in
    un gruppo a parte, cosi' non disturba la mappa di lavoro."""
    for l in project.mapLayersByName(layer.name()):
        project.removeMapLayer(l.id())
    project.addMapLayer(layer, False)
    _gruppo_basi(project).addLayer(layer)
    return layer


def _xyz(project, nome, url, zmax=19):
    esistenti = project.mapLayersByName(nome)
    if esistenti:
        return esistenti[0]
    l = QgsRasterLayer("type=xyz&url=%s&zmax=%d&zmin=0" % (url, zmax), nome, "wms")
    return _aggiungi_base(project, l) if l.isValid() else None


def _catasto(project):
    nome = "Catasto (Agenzia delle Entrate)"
    esistenti = project.mapLayersByName(nome)
    if esistenti:
        return esistenti[0]
    uri = ("contextualWMSLegend=0&crs=EPSG:6706&dpiMode=7&featureCount=10&format=image/png"
           "&layers=CP.CadastralParcel&layers=fabbricati&styles=&styles=&url=%s" % URL_CATASTO)
    l = QgsRasterLayer(uri, nome, "wms")
    return _aggiungi_base(project, l) if l.isValid() else None


def _ortofoto(project, orto_id=None):
    if orto_id:
        l = project.mapLayer(orto_id)
        if l is not None:
            return l
    # parole intere e in ordine di preferenza: "orto" da solo prendeva anche
    # "Trasp-orto" (un WMS di etichette stradali nei progetti reali)
    import re
    raster = [l for l in project.mapLayers().values() if isinstance(l, QgsRasterLayer)]
    for pat in (r"google satellite", r"\bsatellit", r"\bortofoto", r"\borto\b", r"\bimagery\b",
                r"\bagea\b", r"\bortho"):
        for l in raster:
            if re.search(pat, l.name(), re.I):
                return l
    return _xyz(project, "Ortofoto (Esri World Imagery)", URL_ORTO, 19)


def layers_del_gruppo(project, nome_gruppo, escludi=(), ignora_spunte=False):
    """Layer di un gruppo dell'albero (anche annidato), dall'alto in basso come
    li disegna QGIS. Si tengono solo quelli spuntati sotto il gruppo (la spunta
    del gruppo stesso non conta: nei progetti 'Cartografia' puo' essere spento
    mentre si lavora). Con ignora_spunte=True si prendono tutti."""
    from qgis.core import QgsLayerTreeGroup, QgsLayerTreeLayer
    root = project.layerTreeRoot()
    g = None
    for nodo in root.findGroups(True):
        if nodo.name().strip().lower() == nome_gruppo.lower():
            g = nodo
            break
    if g is None:
        return []
    out = []

    def giro(nodo):
        for c in nodo.children():
            if not ignora_spunte and not c.itemVisibilityChecked():
                continue
            if isinstance(c, QgsLayerTreeGroup):
                giro(c)
            elif isinstance(c, QgsLayerTreeLayer) and c.layer() is not None:
                l = c.layer()
                if l.isValid() and not any(e in l.name().lower() for e in escludi):
                    out.append(l)
    giro(g)
    return out


def _base_stampe(project):
    """Cartografia di base delle tavole: il gruppo 'Cartografia' usato per le
    stampe di Altri Enti (CTR DBSN); se manca, OpenStreetMap attenuata."""
    base = layers_del_gruppo(project, "Cartografia")
    if base:
        return base
    osm = _xyz(project, "Base cartografica (OpenStreetMap)", URL_CHIARA, 19)
    if osm is not None:
        osm.setOpacity(0.55)
    return [osm] if osm is not None else []


def _catasto_numeri(project):
    """Numeri di particella e scritte del foglio (WMS AdE: codice_plla, visibile
    fino a 1:2000, e vestizioni). Il gruppo 'Mappa Catastale' dei progetti non li
    contiene, per questo nell'estratto non si leggevano fogli e particelle."""
    nome = "Catasto - numeri di particella e foglio (AdE)"
    esistenti = project.mapLayersByName(nome)
    if esistenti:
        return esistenti[0]
    uri = ("contextualWMSLegend=0&crs=EPSG:6706&dpiMode=7&featureCount=10&format=image/png"
           "&layers=codice_plla&layers=vestizioni&styles=&styles=&url=%s" % URL_CATASTO)
    l = QgsRasterLayer(uri, nome, "wms")
    return _aggiungi_base(project, l) if l.isValid() else None


def foglio_catastale(lat, lon, timeout=20):
    """Numero del foglio catastale nel punto (GetFeatureInfo sul layer
    CP.CadastralZoning del WMS AdE: campo Label). None se il servizio non
    risponde: il titolo dell'estratto resta allora senza foglio."""
    import re
    import urllib.request
    d = 0.0005
    bbox = "%.6f,%.6f,%.6f,%.6f" % (lat - d, lon - d, lat + d, lon + d)   # EPSG:4258 = lat,lon
    url = ("%s?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetFeatureInfo&LAYERS=CP.CadastralZoning"
           "&QUERY_LAYERS=CP.CadastralZoning&CRS=EPSG:4258&BBOX=%s&WIDTH=101&HEIGHT=101"
           "&I=50&J=50&INFO_FORMAT=text/html&STYLES=&FORMAT=image/png" % (URL_CATASTO, bbox))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ftth-permessi/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            html = r.read().decode("latin-1", "replace")
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r">\s*Label\s*</th>\s*<td>\s*([^<]+?)\s*</td>", html)
    return m.group(1) if m else None


def _catasto_stampe(project):
    """Catasto: il gruppo 'Mappa Catastale' del progetto se c'e', altrimenti il
    WMS dell'Agenzia delle Entrate; sopra, sempre, i numeri di particella."""
    cat = layers_del_gruppo(project, "Mappa Catastale", escludi=("province",),
                            ignora_spunte=True)
    if not cat:
        l = _catasto(project)
        cat = [l] if l is not None else []
    num = _catasto_numeri(project)
    return ([num] if num is not None else []) + cat


def rete_su_ortofoto(project, lyr, prefisso, nome="scavi"):
    """Copie di un layer della rete (scavi, pozzetti o armadi, gia' filtrati
    sull'istanza) per il riquadro ORTOFOTO: stesso stile della planimetria,
    dimensioni fisse in mm, le linee con un bordo bianco sotto perche' si
    leggano sulla foto; senza etichette. Il riquadro usa lo stesso SR della
    planimetria: l'ortofoto (EPSG:3857) e' riproiettata al volo, quindi gli
    elementi cadono esattamente sulla strada.
    Gli elementi che lo stile del progetto non disegna (es. regola "Esistente"
    spenta) vanno in una seconda copia con uno stile unico rosso: sull'ortofoto
    la rete dell'istanza deve vedersi tutta. Ritorna [copia stile, copia rossa]
    (None dove non serve)."""
    if lyr is None or not lyr.isValid() or lyr.featureCount() == 0:
        return [None, None]
    from qgis.core import (QgsExpressionContextUtils, QgsFeatureRequest, QgsLineSymbol,
                           QgsRenderContext, QgsSimpleLineSymbolLayer, QgsWkbTypes)
    linea = QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.LineGeometry
    tipo = QgsWkbTypes.displayString(lyr.wkbType()) or ("LineString" if linea else "Point")
    feats = list(lyr.getFeatures(QgsFeatureRequest()))

    def _copia(etichetta, lista):
        m = QgsVectorLayer("%s?crs=%s" % (tipo, lyr.crs().authid()),
                           "%s - %s su ortofoto%s" % (prefisso, nome, etichetta), "memory")
        m.dataProvider().addAttributes(lyr.fields().toList())
        m.updateFields()
        m.dataProvider().addFeatures(lista)
        m.updateExtents()
        m.setLabelsEnabled(False)
        m.setCustomProperty("rfi/nome_legenda", nome.capitalize())
        return m

    r = lyr.renderer().clone() if lyr.renderer() is not None else None
    visibili, nascosti = [], list(feats)
    if r is not None:
        if linea:
            try:
                for item in r.legendSymbolItems():
                    sym = item.symbol()
                    if sym is None or sym.type() != 1:      # 1 = linea
                        continue
                    sym = sym.clone()
                    larg = max([sl.width() for sl in sym.symbolLayers()
                                if hasattr(sl, "width")] or [0.5])
                    bordo = QgsSimpleLineSymbolLayer(QColor(255, 255, 255, 230), larg + 0.8)
                    bordo.setPenCapStyle(Qt.RoundCap)
                    sym.insertSymbolLayer(0, bordo)
                    r.setLegendSymbolItem(item.ruleKey(), sym)
            except Exception:  # noqa: BLE001
                pass
        try:
            # dimensioni fisse in mm: con la scala di riferimento del progetto
            # (1:1000) a 1:5000 linee e simboli diventavano quasi invisibili
            r.setReferenceScale(-1)
        except Exception:  # noqa: BLE001
            pass
        try:
            ctx = QgsRenderContext()
            ctx.expressionContext().appendScopes(
                QgsExpressionContextUtils.globalProjectLayerScopes(lyr))
            r.startRender(ctx, lyr.fields())
            visibili, nascosti = [], []
            for f in feats:
                ctx.expressionContext().setFeature(f)
                (visibili if r.willRenderFeature(f, ctx) else nascosti).append(f)
            r.stopRender(ctx)
        except Exception:  # noqa: BLE001
            visibili, nascosti = [], list(feats)
    con_stile = None
    if visibili:
        con_stile = _copia("", visibili)
        con_stile.setRenderer(r)
        con_stile = _aggiungi_base(project, con_stile)
    rossa = None
    if nascosti:
        if linea:
            sym = QgsLineSymbol.createSimple({"line_color": "255,255,255,230",
                                              "line_width": "1.4", "capstyle": "round"})
            sopra = QgsSimpleLineSymbolLayer(QColor(230, 0, 0), 0.7)
            sopra.setPenCapStyle(Qt.RoundCap)
            sym.appendSymbolLayer(sopra)
        else:
            sym = QgsMarkerSymbol.createSimple({
                "name": "square" if nome == "pozzetti" else "diamond", "color": "230,0,0,255",
                "outline_color": "255,255,255,255", "outline_width": "0.4",
                "size": "2.6" if nome == "pozzetti" else "3.4"})
        rossa = _copia(" (altri)", nascosti)
        rossa.setRenderer(QgsSingleSymbolRenderer(sym))
        rossa = _aggiungi_base(project, rossa)
    return [con_stile, rossa]


def rete_ortofoto(project, prefisso, infra, pozz, arm):
    """Layer per il riquadro ORTOFOTO, nell'ordine di disegno (i punti sopra
    le linee): armadi, pozzetti, scavi."""
    return (rete_su_ortofoto(project, arm, prefisso, "armadi")
            + rete_su_ortofoto(project, pozz, prefisso, "pozzetti")
            + rete_su_ortofoto(project, infra, prefisso, "scavi"))


def copia_filtrata(project, lyr, fids, prefisso, nome_legenda=None, gruppo=None):
    """Copia in memoria di `lyr` con le sole feature `fids`, stesso stile ed
    etichette: in planimetria si vede solo cio' che riguarda l'istanza (gli
    scavi fuori fascia e non continui con quelli in fascia spariscono)."""
    if lyr is None or not lyr.isValid():
        return None
    from qgis.core import QgsFeatureRequest, QgsWkbTypes
    tipo = QgsWkbTypes.displayString(lyr.wkbType()) or "LineString"
    mem = QgsVectorLayer("%s?crs=%s" % (tipo, lyr.crs().authid()),
                         "%s - %s" % (prefisso, lyr.name()), "memory")
    mem.dataProvider().addAttributes(lyr.fields().toList())
    mem.updateFields()
    ids = [int(f) for f in fids if f is not None]
    if ids:
        feats = list(lyr.getFeatures(QgsFeatureRequest().setFilterFids(ids)))
        mem.dataProvider().addFeatures(feats)
    mem.updateExtents()
    try:
        if lyr.renderer() is not None:
            r = lyr.renderer().clone()
            # in legenda niente codici "03 ", "02_": solo la descrizione
            for metodo in ("categories", "ranges"):
                if hasattr(r, metodo):
                    for k, c in enumerate(getattr(r, metodo)()):
                        pulito = nome_pulito(c.label())
                        if pulito != c.label():
                            if metodo == "categories":
                                r.updateCategoryLabel(k, pulito)
                            else:
                                r.updateRangeLabel(k, pulito)
            mem.setRenderer(r)
        if lyr.labeling() is not None:
            mem.setLabeling(lyr.labeling().clone())
        mem.setLabelsEnabled(lyr.labelsEnabled())
        mem.setOpacity(lyr.opacity())
    except Exception:  # noqa: BLE001
        pass
    mem.setCustomProperty("rfi/nome_legenda", nome_legenda or nome_pulito(lyr.name()))
    if gruppo:
        mem.setCustomProperty("rfi/gruppo_legenda", gruppo)
    if gruppo == "rilievo":
        # lo stile di Altri Enti ha scala di riferimento 1:1000: a 1:2000 coni e
        # scritte FOTO n uscivano dimezzati. In tavola dimensione fissa in mm.
        try:
            if mem.renderer() is not None:
                mem.renderer().setReferenceScale(-1)
        except Exception:  # noqa: BLE001
            pass
    return _aggiungi_base(project, mem)


# --------------------------------------------------------------------------- #
#  Foto e sezioni disegnate nel progetto (come in Altri Enti)
# --------------------------------------------------------------------------- #
NOMI_LAYER_FOTO = ("Punto di Ripresa Fotografico", "Punti di Ripresa", "Punto di Ripresa")
NOMI_LAYER_SEZIONI = ("Sezioni",)


def _campo(lyr, *nomi):
    nomi_l = [n.lower() for n in nomi]
    for f in lyr.fields():
        if f.name().lower() in nomi_l:
            return f.name()
    return None


# Foto e sezioni per istanza: nei layer «Punto di Ripresa Fotografico» e
# «Sezioni» il campo ISTANZA dice a quale istanza appartiene il punto o la
# linea (vuoto = vale per tutte). Così nello stesso progetto ci possono essere
# due «FOTO 1» o due «A-A'» di istanze diverse; i file si cercano prima nella
# sottocartella con il nome dell'istanza (04_Foto/SP28/FOTO-1.jpg,
# 05_Sezioni/Linea 124 …/SEZIONE A-A'.svg), poi nella cartella.
CAMPO_ISTANZA = "ISTANZA"
SEP_NOMI = " - "          # come lo scrive ftth_gruppi_istanze.valore


def _gr():
    try:
        from . import ftth_gruppi_istanze as GR
    except ImportError:
        import ftth_gruppi_istanze as GR
    return GR


def nome_cartella(testo):
    """Nome di cartella valido in Windows per un nome di istanza (trattini
    lunghi come «-», come nel campo degli shape)."""
    t = re.sub(r'[\\/:*?"<>|]+', "_", _gr().pulisci(testo)).strip()
    return t.rstrip(". ")


def nomi_istanza(ist):
    """Nomi con cui l'istanza si indica nel campo ISTANZA e nelle
    sottocartelle, dal più preciso al più generale: per RFI «Linea — Tipo A —
    Stazione», «Linea — Tipo A», «Linea»; per le altre il nome scritto negli
    shape (SP28, Canale …) e il nome della pratica."""
    out = []
    try:
        try:
            from . import ftth_gruppi_istanze as GR
        except ImportError:
            import ftth_gruppi_istanze as GR
        if getattr(ist, "linea", None) and hasattr(ist, "tipologia"):
            v = GR.valore("rfi", ist)
            parti = v.split(SEP_NOMI)
            out += [SEP_NOMI.join(parti[:k]) for k in range(len(parti), 0, -1)]
        else:
            out.append(GR.valore("strade", ist))
            out.append(GR.etichetta("strade", ist))
    except Exception:  # noqa: BLE001
        pass
    for att in ("linea", "corso", "nome_base"):
        v = getattr(ist, att, None)
        if v:
            out.append(str(v))
    return [n for n in dict.fromkeys(_gr().pulisci(x) for x in out if x and x.strip())]


def istanza_corrisponde(valore, nomi):
    """True se il valore del campo ISTANZA (anche più nomi separati da «;»)
    indica questa istanza, o se è vuoto (punto valido per tutte)."""
    if valore is None or str(valore).strip() in ("", "NULL"):
        return True
    GR = _gr()
    nl = [GR.chiave_nome(n) for n in nomi]
    for p in str(valore).split(";"):
        p = GR.chiave_nome(p)
        if p and any(n == p or n.startswith(p + SEP_NOMI) for n in nl):
            return True
    return False


def cartelle_istanza(cartelle, nomi):
    """Per ogni cartella: prima le sue sottocartelle con il nome dell'istanza
    (dal più preciso), poi la cartella stessa."""
    out = []
    for c in cartelle:
        if c and nomi and os.path.isdir(c):
            try:
                sotto = {nome_cartella(d).lower(): d for d in os.listdir(c)
                         if os.path.isdir(os.path.join(c, d))}
            except OSError:
                sotto = {}
            for n in nomi:
                d = sotto.get(nome_cartella(n).lower())
                if d and os.path.join(c, d) not in out:
                    out.append(os.path.join(c, d))
        out.append(c)
    return out


# sezioni (disegni SEZIONE A-A') che entrano in una tavola della PL RFI/Acque
SEZIONI_PER_TAVOLA = 1


def feature_nel_riquadro(project, lyr, crs, rect, centro, istanza=None):
    """Feature di `lyr` dentro `rect` (CRS delle tavole), dalla piu' vicina a
    `centro`: [(feature, distanza_m)]. Con `istanza` (nomi_istanza) restano
    solo quelle con il campo ISTANZA vuoto o di questa istanza."""
    if lyr is None or not lyr.isValid():
        return []
    c_ist = _campo(lyr, CAMPO_ISTANZA) if istanza else None
    from qgis.core import QgsFeatureRequest
    a_layer = QgsCoordinateTransform(crs, lyr.crs(), project)
    da_layer = QgsCoordinateTransform(lyr.crs(), crs, project)
    try:
        r_l = a_layer.transformBoundingBox(rect)
    except Exception:  # noqa: BLE001
        return []
    out = []
    pc = QgsGeometry.fromPointXY(centro)
    for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(r_l)):
        g = QgsGeometry(f.geometry())
        if g.isEmpty():
            continue
        try:
            g.transform(da_layer)
        except Exception:  # noqa: BLE001
            continue
        if not g.intersects(QgsGeometry.fromRect(rect)):
            continue
        if c_ist and not istanza_corrisponde(f[c_ist], istanza):
            continue                # foto/sezione di un'altra istanza
        out.append((f, g.distance(pc)))
    out.sort(key=lambda t: t[1])
    return out


def numero_foto(lyr, f):
    c = _campo(lyr, "NumeroFoto", "numero_foto", "n_foto", "foto", "numero")
    if not c:
        return None
    v = f[c]
    if v is None or str(v).strip() in ("", "NULL"):
        return None
    try:
        return str(int(float(v)))
    except (TypeError, ValueError):
        return str(v).strip()


def sigla_sezione(lyr, f):
    """'A-A'' dai campi sezione / sezione_f (o etichetta)."""
    cs, cf, ce = (_campo(lyr, "sezione"), _campo(lyr, "sezione_f"),
                  _campo(lyr, "etichetta"))

    def _v(c):
        if not c:
            return ""
        v = f[c]
        return "" if v is None or str(v) == "NULL" else str(v).strip()
    s, sf = _v(cs), _v(cf)
    if s:
        return "%s-%s" % (s, sf or s + "'")
    e = _v(ce).upper().replace("SEZIONE", "").strip()
    return e or None


def foto_ritagliata(path, w_mm, h_mm, cartella_out):
    """Copia della foto ritagliata al centro con le proporzioni del riquadro
    (w_mm x h_mm): in tavola riempie tutto il riquadro senza fasce vuote e
    senza deformarsi. Le immagini vettoriali restano come sono."""
    if not path or path.lower().endswith(".svg") or w_mm <= 0 or h_mm <= 0:
        return path
    try:
        from qgis.PyQt.QtGui import QImage, QImageReader
        rd = QImageReader(path)
        rd.setAutoTransform(True)          # rispetta l'orientamento EXIF
        img = rd.read()
        if img.isNull():
            return path
        W, H = img.width(), img.height()
        rapporto = w_mm / float(h_mm)
        if W / float(H) > rapporto:        # troppo larga: si taglia ai lati
            nw = int(round(H * rapporto)); x, y, w, h = (W - nw) // 2, 0, nw, H
        else:                               # troppo alta: sopra e sotto
            nh = int(round(W / rapporto)); x, y, w, h = 0, (H - nh) // 2, W, nh
        # risoluzione sufficiente per la stampa (circa 200 dpi sul riquadro)
        px_w = int(w_mm / 25.4 * 200)
        out = img.copy(x, y, w, h)
        if out.width() > px_w:
            from qgis.PyQt.QtCore import Qt as _Qt
            out = out.scaledToWidth(px_w, _Qt.SmoothTransformation)
        os.makedirs(cartella_out, exist_ok=True)
        base = os.path.splitext(os.path.basename(path))[0]
        dest = os.path.join(cartella_out, "%s_%dx%d.jpg" % (base, int(w_mm), int(h_mm)))
        if out.save(dest, "JPG", 90):
            return dest
    except Exception:  # noqa: BLE001
        pass
    return path


def nomi_file_foto(n):
    return ["FOTO-%s" % n, "FOTO %s" % n, "FOTO_%s" % n, "foto_%s" % n, "foto%s" % n]


def nome_pulito(testo):
    """Toglie i codici di ordinamento iniziali: "03 INFRASTRUTTURE" ->
    "INFRASTRUTTURE", "02_POZZETTO" -> "POZZETTO", "01_ARMADIO OTTICO" ->
    "ARMADIO OTTICO". I numeri dentro il testo (76x40, Ø 14) restano."""
    if not testo:
        return testo
    t = re.sub(r"^\s*\d+(?:[._-]\d+)*\s*[-_.)]*\s*", "", str(testo))
    t = t.replace("_", " ").strip()
    return t or str(testo)


def render_png(project, layers, crs, centro, scala, w_mm, h_mm, path, dpi=110):
    """Disegna i layer in un PNG a `dpi` per un riquadro di w_mm x h_mm alla
    scala data. Serve al catasto: il WMS scrive i numeri di particella con una
    dimensione fissa in pixel, e a 200 dpi uscivano minuscoli."""
    from qgis.core import QgsMapRendererSequentialJob, QgsMapSettings
    from qgis.PyQt.QtCore import QSize
    px = int(round(w_mm / 25.4 * dpi))
    py = int(round(h_mm / 25.4 * dpi))
    dx = w_mm * scala / 1000.0 / 2.0
    dy = h_mm * scala / 1000.0 / 2.0
    ms = QgsMapSettings()
    ms.setLayers([l for l in layers if l is not None])
    ms.setDestinationCrs(crs)
    ms.setTransformContext(project.transformContext())
    ms.setOutputSize(QSize(px, py))
    ms.setOutputDpi(dpi)
    ms.setBackgroundColor(QColor(255, 255, 255))
    ms.setExtent(QgsRectangle(centro.x() - dx, centro.y() - dy, centro.x() + dx, centro.y() + dy))
    job = QgsMapRendererSequentialJob(ms)
    job.start()
    job.waitForFinished()
    img = job.renderedImage()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path if img.save(path) else None


def _trova(project, *nomi):
    for n in nomi:
        for l in project.mapLayersByName(n):
            return l
    for n in nomi:
        for l in project.mapLayers().values():
            if n.lower() in l.name().lower():
                return l
    return None


def _testo_interferenza(i):
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    km_ingresso = any(e.get("tipo") == "ingresso" and R.km_valore(e.get("km")) is not None
                      for e in i.elementi)
    if km_ingresso:
        # i km sono gia' scritti dove lo scavo entra in fascia: non si ripetono
        righe = []
    elif R.km_valore(i.km_da) is None:
        righe = ["km da verificare"]
    elif not i.km_a or i.km_a == i.km_da or R.km_valore(i.km_a) is None:
        righe = ["km %s" % i.km_da]
    else:
        righe = ["km %s - %s" % (i.km_da, i.km_a)]
    for t, m in i.metri.items():
        if m:
            righe.append("%s Mt %s" % (TECNICA_TAVOLA.get(t, t.upper()),
                                       int(float(m) + 0.5)))
    # i pozzetti hanno ora ciascuno la propria etichetta col km (vedi
    # _testo_elemento); qui solo se l'interferenza non porta gli elementi
    if not any(e.get("tipo") == "pozzetto" for e in i.elementi):
        for d, n in i.pozzetti.items():
            righe.append("POSA %s POZZETT%s %s" % ("NUOVO" if n == 1 else "%d NUOVI" % n,
                                                  "O" if n == 1 else "I", d.upper()))
    return "\n".join(righe)


def _testo_elemento(e, km_ingresso=False, con_km=True):
    """Etichetta di un pozzetto/armadio nuovo in fascia, con il suo km.
    con_km=False (istanze acque): niente progressive, solo la lavorazione."""
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    km = e.get("km")
    km_ok = R.km_valore(km) is not None
    if not con_km:
        if e.get("tipo") in ("ingresso",):
            return None
        if e.get("tipo") == "fuori":
            return "NON DI COMPETENZA"
        if e.get("tipo") == "scavo":
            return "%s Mt %s" % (TECNICA_TAVOLA.get(e.get("tecnica"),
                                                     "SCAVO " + str(e.get("tecnica")).upper()),
                                 e.get("metri"))
        if e.get("tipo") == "armadio":
            return _testo_armadio(e)
        return "NUOVO POZZETTO %s" % (e.get("dim") or "").upper()
    # km sempre su pozzetti e armadi: senza cippi il segnaposto XXX+XXX, come
    # nei documenti, da completare a mano
    km_txt = "KM %s" % (km if km_ok else R.KM_SEGNAPOSTO)
    if e.get("tipo") == "ingresso":
        return ("KM %s" % km) if km_ok else None   # dove lo scavo entra in fascia
    if e.get("tipo") == "fuori":
        return "NON DI COMPETENZA"             # tratto fuori fascia, non computato
    if e.get("tipo") == "scavo":
        testa = "%s Mt %s" % (TECNICA_TAVOLA.get(e.get("tecnica"),
                                                  "SCAVO " + str(e.get("tecnica")).upper()),
                              e.get("metri"))
        # il km dello scavo si legge gia' nelle etichette d'ingresso in fascia
        return testa if km_ingresso else "%s\n%s" % (km_txt, testa)
    if e.get("tipo") == "armadio":
        testa = _testo_armadio(e)
    else:
        testa = "NUOVO POZZETTO %s" % (e.get("dim") or "").upper()
    return "%s\n%s" % (km_txt, testa)


def unisci_etichette_vicine(voci, raggio_m=10.0):
    """Scavo, pozzetto e armadio praticamente nello stesso punto (entro
    `raggio_m`) diventano UNA etichetta: a 1:2000 due etichette li' non
    trovano posto e una spariva (es. il pozzetto in testa allo scavo
    tradizionale di 6 m). Le righe uguali (il km) restano una volta sola;
    l'etichetta sta sul punto dello scavo, se c'e'. km d'ingresso e NON DI
    COMPETENZA restano separati."""
    import math
    unibili = ("scavo", "pozzetto", "armadio")
    out = []
    for v in voci:
        if v["tipo"] not in unibili:
            out.append(dict(v))
            continue
        gruppo = None
        for g in out:
            if g["tipo"] not in unibili:
                continue
            dx = (v["lon"] - g["lon"]) * 111320.0 * math.cos(math.radians(g["lat"]))
            dy = (v["lat"] - g["lat"]) * 110540.0
            if math.hypot(dx, dy) <= raggio_m:
                gruppo = g
                break
        if gruppo is None:
            out.append(dict(v, righe=list(v["righe"])))
            continue
        # km in testa, poi scavi, poi pozzetti/armadi
        km = [r for r in gruppo["righe"] + v["righe"] if r.startswith("KM ")]
        resto = [r for r in gruppo["righe"] + v["righe"] if not r.startswith("KM ")]
        righe = []
        for r in km[:1] + sorted(resto, key=lambda r: 0 if r.startswith("SCAVO") else 1):
            if r not in righe:
                righe.append(r)
        gruppo["righe"] = righe
        if v["tipo"] == "scavo" and gruppo["tipo"] != "scavo":
            gruppo.update(lon=v["lon"], lat=v["lat"], tipo="scavo")
    return out


FONT_ETICH_MM = 8 * 25.4 / 72.0          # corpo 8 pt in mm


def _box_etichetta(testo):
    """Ingombro (larghezza, altezza) in mm di un'etichetta Arial bold 8 pt
    maiuscola con alone, per riga piu' lunga e numero di righe."""
    righe = (testo or "").split("\n")
    w = max(len(r) for r in righe) * FONT_ETICH_MM * 0.66 + 2.4
    h = len(righe) * FONT_ETICH_MM * 1.25 + 2.4
    return w, h


def posiziona_etichette(etich, interf_id, crs_mappa, a_mappa, da_mappa, centro, scala,
                        w_mm, h_mm, ostacoli=()):
    """Sceglie la posizione delle etichette di UNA tavola (planimetria in
    `scala`, riquadro w_mm x h_mm centrato su `centro`, coordinate di mappa).
    Per ogni etichetta, in ordine di importanza, prova 8 direzioni attorno al
    punto a distanze crescenti e prende la prima che resta nel riquadro e non
    tocca le etichette gia' messe ne' i punti etichettati. Scrive px/py
    (centro dell'etichetta, CRS del layer)."""
    k = 1000.0 / scala                      # mm di carta per metro

    def a_mm(pt):
        return ((pt.x() - centro.x()) * k + w_mm / 2.0,
                h_mm / 2.0 - (pt.y() - centro.y()) * k)

    def da_mm(x, y):
        return QgsPointXY(centro.x() + (x - w_mm / 2.0) / k,
                          centro.y() + (h_mm / 2.0 - y) / k)

    ordine = {"scavo": 0, "ingresso": 1, "pozzetto": 2, "armadio": 2, "fuori": 3}
    feats = [f for f in etich.getFeatures() if f["interf"] == interf_id]
    feats.sort(key=lambda f: ordine.get(f["tipo"], 2))
    punti = []
    for f in feats:
        punti.append(a_mm(a_mappa.transform(f.geometry().asPoint())))
    occupati = [(x - 1.5, y - 1.5, x + 1.5, y + 1.5) for x, y in punti]
    occupati += list(ostacoli)
    direzioni = [(1, -1), (-1, -1), (1, 1), (-1, 1), (0, -1), (0, 1), (1, 0), (-1, 0)]
    margine = 2.0
    agg = {}
    i_px, i_py = etich.fields().indexOf("px"), etich.fields().indexOf("py")

    def sovrapp(a, b):
        return max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * \
            max(0.0, min(a[3], b[3]) - max(a[1], b[1]))

    for f, (x0, y0) in zip(feats, punti):
        bw, bh = _box_etichetta(f["testo"])
        migliore, costo_min = None, None
        for dist in (6.0, 10.0, 15.0, 21.0, 28.0):
            for dx, dy in direzioni:
                cx = x0 + dx * (dist + bw / 2.0) if dx else x0
                cy = y0 + dy * (dist + bh / 2.0) if dy else y0
                if not dx:
                    cy = y0 + dy * (dist + bh / 2.0)
                box = (cx - bw / 2.0, cy - bh / 2.0, cx + bw / 2.0, cy + bh / 2.0)
                fuori = (box[0] < margine or box[1] < margine or
                         box[2] > w_mm - margine or box[3] > h_mm - margine)
                urto = sum(sovrapp(box, o) for o in occupati)
                costo = urto * 100 + (1000 if fuori else 0) + dist
                if costo_min is None or costo < costo_min:
                    migliore, costo_min = (cx, cy, box), costo
                if not fuori and urto == 0:
                    break
            if migliore is not None and costo_min is not None and costo_min < 100:
                break
        cx, cy, box = migliore
        occupati.append((box[0] - 1, box[1] - 1, box[2] + 1, box[3] + 1))
        p_lay = da_mappa.transform(da_mm(cx, cy))
        agg[f.id()] = {i_px: p_lay.x(), i_py: p_lay.y()}
    if agg:
        etich.dataProvider().changeAttributeValues(agg)


def _layer_istanza(project, ist, con_km=True, prefisso="RFI"):
    """Due layer temporanei dell'istanza: cerchi (corografia) ed etichette
    km/scavi (planimetria)."""
    cerchi = QgsVectorLayer("Point?crs=EPSG:4326", "%s tavole %s - interferenze"
                            % (prefisso, ist.nome_base), "memory")
    cerchi.dataProvider().addAttributes([QgsField("id", QVariant.Int)])
    cerchi.updateFields()
    etich = QgsVectorLayer("Point?crs=EPSG:4326", "%s tavole %s - etichette"
                           % (prefisso, ist.nome_base), "memory")
    etich.dataProvider().addAttributes([QgsField("testo", QVariant.String),
                                        QgsField("tipo", QVariant.String),
                                        QgsField("interf", QVariant.Int),
                                        QgsField("px", QVariant.Double),
                                        QgsField("py", QVariant.Double)])
    etich.updateFields()
    fc, fe = [], []
    for i in ist.interferenze:
        p = QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
        f = QgsFeature(cerchi.fields()); f.setGeometry(p); f["id"] = i.id; fc.append(f)
        try:
            from . import ftth_rfi as R
        except ImportError:
            import ftth_rfi as R
        km_ingr = any(e.get("tipo") == "ingresso" and R.km_valore(e.get("km")) is not None
                      for e in i.elementi)
        # con gli scavi etichettati uno per uno (tratta per tratta) l'etichetta
        # unica dell'interferenza non serve: puntava a un solo scavo
        if con_km and not any(e.get("tipo") == "scavo" for e in i.elementi):
            f = QgsFeature(etich.fields()); f.setGeometry(p)
            f["testo"] = _testo_interferenza(i); f["tipo"] = "scavo"; f["interf"] = i.id
            fe.append(f)
        voci = []
        for e in i.elementi:
            if e.get("tipo", "").endswith("_fuori"):
                continue          # pozzetti/armadi fuori fascia: disegnati, non etichettati
            testo = _testo_elemento(e, km_ingr, con_km)
            if testo:
                voci.append({"lon": e["lon"], "lat": e["lat"], "tipo": e.get("tipo"),
                             "righe": testo.split("\n")})
        for v in unisci_etichette_vicine(voci):
            f = QgsFeature(etich.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(v["lon"], v["lat"])))
            f["testo"] = "\n".join(v["righe"])
            f["tipo"] = v["tipo"]
            f["interf"] = i.id
            fe.append(f)
    cerchi.dataProvider().addFeatures(fc)
    etich.dataProvider().addFeatures(fe)
    cerchi.updateExtents(); etich.updateExtents()
    cerchi.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "255,70,70,150", "outline_color": "230,60,60,200",
         "size": "9"})))
    etich.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "0,0,0,0", "outline_color": "0,0,0,0", "size": "1"})))
    pal = QgsPalLayerSettings()
    pal.fieldName = "testo"
    # posizione scelta fra 8 attorno al punto, staccata e con linea di richiamo
    # (come nelle tavole di progetto): il motore prende la prima libera, cosi'
    # le etichette non si sovrappongono fra loro ne' a quelle del progetto
    try:
        pal.placement = QgsPalLayerSettings.OrderedPositionsAroundPoint
    except Exception:  # noqa: BLE001
        pass
    pal.dist = 7
    try:
        pal.distUnits = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        pass
    try:
        from qgis.core import QgsSimpleLineCallout, QgsLineSymbol
        c = QgsSimpleLineCallout()
        c.setEnabled(True)
        c.setLineSymbol(QgsLineSymbol.createSimple({"line_color": "200,0,0,255",
                                                    "line_width": "0.2"}))
        pal.setCallout(c)
    except Exception:  # noqa: BLE001
        pass
    # niente "disegna sempre": con displayAll le etichette si disegnavano anche
    # sopra le altre (a 1:2000 si accavallavano). Il motore sceglie fra le 8
    # posizioni una libera; queste hanno priorita' su quelle del progetto
    # (MT., FOTO n...), che cedono il posto. Fra le nostre: scavo > km di
    # ingresso > pozzetti/armadi > NON DI COMPETENZA.
    pal.displayAll = False
    pal.priority = 10
    try:
        # QGIS >= 3.26: prima una posizione libera; se non c'e', ammessa sopra
        # una linea (degradata) e solo come ultima risorsa sopra un'altra
        # etichetta. Cosi' nessuna etichetta si perde.
        from qgis.core import Qgis
        ps = pal.placementSettings()
        ps.setAllowDegradedPlacement(True)
        ps.setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapIfRequired)
        pal.setPlacementSettings(ps)
    except Exception:  # noqa: BLE001
        pass
    try:
        from qgis.core import QgsProperty
        dd = pal.dataDefinedProperties()
        dd.setProperty(
            QgsPalLayerSettings.Color,
            QgsProperty.fromExpression("CASE WHEN \"tipo\" = 'fuori' THEN '0,0,0,255' "
                                       "ELSE '200,0,0,255' END"))
        dd.setProperty(
            QgsPalLayerSettings.Priority,
            QgsProperty.fromExpression("CASE \"tipo\" WHEN 'scavo' THEN 10 WHEN 'ingresso' "
                                       "THEN 9 WHEN 'fuori' THEN 6 ELSE 8 END"))
        # posizione calcolata dal plugin tavola per tavola (posiziona_etichette):
        # centro dell'etichetta in px/py (CRS del layer); la linea di richiamo
        # la collega al punto. Col motore di QGIS le aree della cartografia di
        # base facevano da ostacolo ovunque e due etichette finivano nello
        # stesso posto (o una spariva).
        dd.setProperty(QgsPalLayerSettings.PositionX, QgsProperty.fromField("px"))
        dd.setProperty(QgsPalLayerSettings.PositionY, QgsProperty.fromField("py"))
        dd.setProperty(QgsPalLayerSettings.Hali, QgsProperty.fromValue("Center"))
        dd.setProperty(QgsPalLayerSettings.Vali, QgsProperty.fromValue("Half"))
        dd.setProperty(QgsPalLayerSettings.AlwaysShow,
                       QgsProperty.fromExpression("\"px\" IS NOT NULL"))
    except Exception:  # noqa: BLE001
        pass
    tf = QgsTextFormat()
    fnt = QFont("Arial", 8)
    fnt.setBold(True)
    tf.setFont(fnt)
    tf.setSize(8)
    tf.setColor(QColor(200, 0, 0))
    b = QgsTextBufferSettings()
    b.setEnabled(True)
    b.setSize(1.2)
    b.setColor(QColor(255, 255, 255))
    tf.setBuffer(b)
    pal.setFormat(tf)
    etich.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    etich.setLabelsEnabled(True)
    return _aggiungi_base(project, cerchi), _aggiungi_base(project, etich)


# --------------------------------------------------------------------------- #
#  Elementi del layout
# --------------------------------------------------------------------------- #
def _mv(it, x, y, w, h, pagina):
    it.attemptMove(QgsLayoutPoint(x, y, MM), True, False, pagina)
    it.attemptResize(QgsLayoutSize(w, h, MM))


def _lbl(layout, pagina, x, y, w, h, testo, size=8, bold=False, align=Qt.AlignHCenter,
         valign=Qt.AlignVCenter, frame=False, colore=None):
    it = QgsLayoutItemLabel(layout)
    it.setText(testo)
    f = QFont("Arial")
    f.setPointSizeF(float(size))
    f.setBold(bold)
    it.setFont(f)
    if colore is not None:
        it.setFontColor(colore)
    it.setHAlign(align)
    it.setVAlign(valign)
    it.setMarginX(1.0)
    it.setMarginY(0.6)
    layout.addLayoutItem(it)
    _mv(it, x, y, w, h, pagina)
    it.setFrameEnabled(frame)
    if frame:
        it.setFrameStrokeWidth(QgsLayoutMeasurement(0.25, MM))
    return it


def _box(layout, pagina, x, y, w, h, spessore=0.3, colore=QColor(0, 0, 0)):
    sh = QgsLayoutItemShape(layout)
    sh.setShapeType(QgsLayoutItemShape.Rectangle)
    layout.addLayoutItem(sh)
    _mv(sh, x, y, w, h, pagina)
    try:
        sym = sh.symbol()
        sym.setColor(QColor(255, 255, 255, 0))
        sl = sym.symbolLayer(0)
        sl.setStrokeColor(colore)
        sl.setStrokeWidth(spessore)
    except Exception:  # noqa: BLE001
        pass
    return sh


def _cerchio(layout, pagina, x, y, d):
    sh = QgsLayoutItemShape(layout)
    sh.setShapeType(QgsLayoutItemShape.Ellipse)
    layout.addLayoutItem(sh)
    _mv(sh, x, y, d, d, pagina)
    try:
        sym = sh.symbol()
        sym.setColor(QColor(255, 70, 70, 150))
        sym.symbolLayer(0).setStrokeColor(QColor(230, 60, 60, 200))
    except Exception:  # noqa: BLE001
        pass


def _immagine(layout, pagina, x, y, w, h, path):
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(QgsLayoutItemPicture.Zoom)
    layout.addLayoutItem(pic)
    _mv(pic, x, y, w, h, pagina)
    return pic


def _scala_che_contiene(rect, w_mm, h_mm, minima=1000):
    """Scala piu' piccola dell'elenco che fa stare `rect` (metri) nel riquadro."""
    for s in SCALE:
        if s < minima:
            continue
        if rect.width() <= w_mm * s / 1000.0 and rect.height() <= h_mm * s / 1000.0:
            return s
    return SCALE[-1]


def _mappa(layout, pagina, x, y, w, h, crs, layers, centro, scala):
    m = QgsLayoutItemMap(layout)
    m.setCrs(crs)
    layout.addLayoutItem(m)
    _mv(m, x, y, w, h, pagina)
    m.setLayers([l for l in layers if l is not None])
    m.setKeepLayerSet(True)
    dx = w * scala / 1000.0 / 2.0
    dy = h * scala / 1000.0 / 2.0
    m.setExtent(QgsRectangle(centro.x() - dx, centro.y() - dy, centro.x() + dx, centro.y() + dy))
    m.setScale(scala)
    m.setFrameEnabled(True)
    m.setFrameStrokeWidth(QgsLayoutMeasurement(0.3, MM))
    return m


def _cartiglio(layout, pagina, dati, nome_tavola, scala_txt, legenda_map=None,
               legenda_layers=None, legenda_testo=None):
    titolo_altri = dati.get("titolo_legenda_ente") or "ELEMENTI FERROVIARI"
    pw, ph = PAGINA
    cx = pw - MARGINE - CART_W
    cy = MARGINE
    ch = ph - 2 * MARGINE
    _box(layout, pagina, cx, cy, CART_W, ch, 0.4)
    x, w = cx + 3, CART_W - 6

    # blocco in basso alto H_BLOCCO, appoggiato al bordo inferiore (prima restava
    # uno spazio vuoto sotto il nome file); la legenda prende tutto il resto
    H_BLOCCO = 30 + 1 + 8 + 10 + 18 + 22 + 9
    yb0 = cy + ch - 3 - H_BLOCCO

    # tavola senza simbologia (particolari): niente riquadro LEGENDA vuoto
    if legenda_map is None and not legenda_testo:
        _lbl(layout, pagina, x, cy + 3, w, 16, "PARTICOLARI COSTRUTTIVI\nnon in scala", 11, True)
        legenda_layers = None
    else:
        _lbl(layout, pagina, x, cy + 3, w, 8, "LEGENDA", 12, True)
        lh = yb0 - 4 - (cy + 12)
        _box(layout, pagina, x, cy + 12, w, lh, 0.2, QColor(160, 160, 160))
    if legenda_map is not None and legenda_layers:
        leg = QgsLayoutItemLegend(layout)
        leg.setTitle("")          # il riquadro ha gia' il titolo LEGENDA
        leg.setLinkedMap(legenda_map)
        leg.setAutoUpdateModel(False)
        root = leg.model().rootGroup()
        root.clear()
        # due blocchi distinti: la rete in progetto (copie filtrate dei layer
        # di progetto, riconoscibili da rfi/nome_legenda) e gli elementi
        # ferroviari (linea, fascia, cippi, stazioni)
        validi = [l for l in legenda_layers if l is not None]
        rilievo = [l for l in validi if l.customProperty("rfi/gruppo_legenda") == "rilievo"]
        principali = ("03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO")
        rete = [l for l in validi if l not in rilievo
                and (l.customProperty("rfi/nome_legenda") or l.name() in principali)]
        ferro = [l for l in validi if l not in rete and l not in rilievo]
        for titolo_g, gruppo in (("RETE FIBERCOP", rete),
                                 ("FOTO E SEZIONI" if any(
                                     l.customProperty("rfi/nome_legenda") == "Sezione"
                                     for l in rilievo) else "FOTO", rilievo),
                                 (titolo_altri, ferro)):
            if not gruppo:
                continue
            g = root.addGroup(titolo_g)
            for l in gruppo:
                nodo = g.addLayer(l)
                nome_leg = l.customProperty("rfi/nome_legenda") or \
                    l.customProperty("rfi/titolo_legenda") or \
                    (nome_pulito(l.name()) if l in rete else None)
                if nodo is not None and l.customProperty("rfi/titolo_nascosto"):
                    # solo le voci (es. un canale per riga), senza il nome del layer
                    try:
                        from qgis.core import QgsLegendRenderer
                        QgsLegendRenderer.setNodeLegendStyle(nodo, QgsLegendStyle.Hidden)
                    except Exception:  # noqa: BLE001
                        pass
                if nodo is not None and nome_leg:
                    nodo.setCustomProperty("legend/title-label", nome_leg)
        # solo le voci davvero presenti nella planimetria: i progetti reali
        # hanno decine di categorie e la legenda usciva dal riquadro
        try:
            leg.setLegendFilterByMapEnabled(True)
        except Exception:  # noqa: BLE001
            pass
        def _stile(st, font=None, sopra=None, rientro=None):
            # style() restituisce una copia: si modifica e si reimposta
            try:
                s = leg.style(st)
                if font is not None:
                    try:
                        tf = s.textFormat()
                        tf.setFont(font)
                        tf.setSize(font.pointSizeF())
                        s.setTextFormat(tf)
                    except AttributeError:
                        s.setFont(font)
                if sopra is not None:
                    s.setMargin(QgsLegendStyle.Top, sopra)
                if rientro is not None and hasattr(s, "setIndent"):
                    s.setIndent(rientro)
                leg.setStyle(st, s)
            except Exception:  # noqa: BLE001
                pass
        _stile(QgsLegendStyle.Title, QFont("Arial", 10, QFont.Bold))
        # titolo di blocco (RETE FIBERCOP / ELEMENTI FERROVIARI), staccato
        _stile(QgsLegendStyle.Group, QFont("Arial", 9, QFont.Bold), sopra=6)
        # nome layer dentro il blocco (INFRASTRUTTURE, POZZETTO), rientrato
        _stile(QgsLegendStyle.Subgroup, QFont("Arial", 9), sopra=2.5, rientro=3)
        _stile(QgsLegendStyle.Symbol, sopra=1.8, rientro=3)
        _stile(QgsLegendStyle.SymbolLabel, QFont("Arial", 9))
        try:
            leg.setSymbolHeight(4.5)
            leg.setSymbolWidth(8)
            leg.setWrapString("|")
        except Exception:  # noqa: BLE001
            pass
        layout.addLayoutItem(leg)
        leg.setResizeToContents(False)
        _mv(leg, x + 1, cy + 13, w - 2, lh - 2, pagina)
    elif legenda_testo:
        _cerchio(layout, pagina, x + 3, cy + 22, 9)
        _lbl(layout, pagina, x + 15, cy + 16, w - 16, 22, legenda_testo, 7, True, Qt.AlignLeft)

    # blocco in basso: logo FiberCop, dati, logo Beexact, data/scala/file/tavola
    yb = yb0
    logo_fc = logo_fibercop()      # classico o «Milano Cortina 2026» (flag del progetto)
    _box(layout, pagina, x, yb, w, 30, 0.2, QColor(160, 160, 160))
    if os.path.isfile(logo_fc):
        _immagine(layout, pagina, x + 8, yb + 6, w - 16, 18, logo_fc)
    yb += 31
    _lbl(layout, pagina, x, yb, w, 8, "INQUADRAMENTO PLANIMETRICO COMUNE DI %s"
         % dati["comune"].upper(), 6.5, False, frame=True)
    yb += 8
    _lbl(layout, pagina, x, yb, w, 10, "PROGETTAZIONE DELLA RETE OTTICA DI\n"
         "DISTRIBUZIONE SECONDARIA FIBERCOP", 6.5, False, frame=True)
    yb += 10
    _lbl(layout, pagina, x, yb, w, 18, "RICHIESTA PERMESSO\n%s\n%s" % (
        dati["tipologia_cartiglio"], dati["linea_cartiglio"]), 6.3, False, frame=True)
    yb += 18
    # logo Beexact attuale (arancio/blu, vettoriale); quello nero/arancio e'
    # il vecchio, il banner scuro non va usato
    logo_be = os.path.join(ASSETS, "beexact_logo.svg")
    if not os.path.isfile(logo_be):
        logo_be = os.path.join(ASSETS, "beexact_logo_nuovo.png")
    _box(layout, pagina, x, yb, w * 0.5, 22, 0.2)
    if os.path.isfile(logo_be):
        _immagine(layout, pagina, x + 4, yb + 6, w * 0.5 - 8, 10, logo_be)
    # griglia data / scala / file / tavola (niente timbro)
    gx = x + w * 0.5
    gw = w * 0.25
    _lbl(layout, pagina, gx, yb, gw, 11, "DATA\n%s" % dati["data"], 5.5, True, frame=True)
    _lbl(layout, pagina, gx + gw, yb, gw, 11, "COMUNE\n%s" % dati["comune"].upper(), 5.5, True, frame=True)
    _lbl(layout, pagina, gx, yb + 11, gw, 11, "SCALA\n%s" % scala_txt, 5.5, True, frame=True)
    _lbl(layout, pagina, gx + gw, yb + 11, gw, 11, "TAVOLA\n%s" % nome_tavola, 6, True, frame=True)
    _lbl(layout, pagina, x, yb + 22, w, 9, "NOME FILE: %s" % dati["nome_file"], 5, False,
         frame=True)


# --------------------------------------------------------------------------- #
#  API
# --------------------------------------------------------------------------- #
def _crs_metrico(project, lon):
    """CRS metrico delle tavole. Quello del progetto se e' una proiezione
    conforme in metri (UTM, Gauss-Boaga...). Web Mercator no: a 40-45 gradi
    di latitudine i suoi "metri" sono gonfiati del 30-40% e la scala
    stampata (1:2000) non corrisponderebbe al terreno. In quel caso si usa
    il fuso UTM del sito."""
    crs = project.crs()
    mercatore = crs.authid() in ("EPSG:3857", "EPSG:900913", "EPSG:3395", "EPSG:102100") \
        or "pseudo-mercator" in crs.description().lower()
    try:
        in_metri = crs.mapUnits() == QgsUnitTypes.DistanceMeters
    except Exception:  # noqa: BLE001
        in_metri = True
    if crs.isValid() and not crs.isGeographic() and not mercatore and in_metri:
        return crs
    return QgsCoordinateReferenceSystem("EPSG:%d" % (32600 + int((lon + 180) / 6) + 1))


ESTENSIONI_IMG = (".svg", ".png", ".jpg", ".jpeg")


def cerca_file(nomi, cartelle):
    """Primo file esistente fra `nomi` (senza estensione) nelle `cartelle`, con
    le estensioni immagine ammesse (SVG per primo: resta vettoriale)."""
    for c in cartelle:
        if not c or not os.path.isdir(c):
            continue
        for n in nomi:
            for est in ESTENSIONI_IMG:
                p = os.path.join(c, n + est)
                if os.path.isfile(p):
                    return p
    return None


# libreria particolari del plugin (dal DXF Particolari_Costruttivi di Beexact,
# in assets/rfi_particolari): chiave -> file. La cartella dell'utente puo'
# sostituirli con file chiamati come la chiave.
LIBRERIA_PC = {
    "sezione_minitrincea": "PC-03_minitrincea-carreggiata-asfaltata",
    "sezione_microtrincea": "PC-05_microtrincea-carreggiata-asfaltata",
    "sezione_trincea": "PC-07_scavo-carreggiata-asfaltata-h110",
    "sezione_nodig": "PC-12_tecnica-no-dig",
    "pozzetto_76x40": "PC-01_pozzetto-modulare-40x76",
    "pozzetto_125x80": "PC-02_pozzetto-modulare-125x80",
    "pozzetto_45x15": "PC-04_pozzetto-modulare-40x15",
    "pozzetto_40x15": "PC-04_pozzetto-modulare-40x15",
    "armadio": "PC-06_armadio-ottico-onucab",
    "tubi": "PC-15_tubo-fender-4-d14",
}


def dimensioni_svg(path, default=(40.0, 40.0)):
    """Larghezza e altezza in mm dagli attributi width/height dell'SVG."""
    import re
    if not path.lower().endswith(".svg"):
        return default
    try:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            testa = fh.read(2000)
        w = re.search(r'\bwidth="([\d.]+)mm"', testa)
        h = re.search(r'\bheight="([\d.]+)mm"', testa)
        if w and h:
            return float(w.group(1)), float(h.group(1))
    except Exception:  # noqa: BLE001
        pass
    return default


def impagina_particolari(pezzi, area_w, area_h, gap=8.0, scala_max=3.0, scala_min=1.4):
    """Impaginazione a scaffali, tutti i pezzi alla STESSA scala (le scritte dei
    cartigli restano della stessa altezza). Cerca la scala piu' grande, fino a
    scala_max, che fa stare tutto in una pagina; se non basta usa scala_min su
    piu' pagine. pezzi = [(chiave, file, w_mm, h_mm)].
    Ritorna (scala, [[(chiave, file, x, y, w, h), ...] per pagina])."""
    def _prova(s):
        pagine, pag, x, y, rh = [], [], 0.0, 0.0, 0.0
        for k, f, w, h in pezzi:
            W, H = w * s, h * s
            if W > area_w or H > area_h:
                return None
            if x + W > area_w + 0.01:
                x, y, rh = 0.0, y + rh + gap, 0.0
            if y + H > area_h + 0.01:
                pagine.append(pag)
                pag, x, y, rh = [], 0.0, 0.0, 0.0
            pag.append((k, f, x, y, W, H))
            x += W + gap
            rh = max(rh, H)
        if pag:
            pagine.append(pag)
        return pagine
    s = scala_max
    while s >= scala_min:
        p = _prova(s)
        if p is not None and len(p) <= 1:
            return s, p
        s -= 0.1
    return scala_min, (_prova(scala_min) or [])


def particolari_necessari(ist):
    """Chiavi dei particolari costruttivi da mettere nella tavola PC, in base a
    cio' che l'istanza contiene davvero: una sezione per ogni tecnica di scavo
    usata, un pozzetto per ogni dimensione posata, l'armadio se ce n'e' uno in
    fascia, il tubo."""
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    chiavi = []
    tecniche = []
    for i in ist.interferenze:
        for t, m in i.metri.items():
            if m and t not in tecniche:
                tecniche.append(t)
    for t in ("minitrincea", "microtrincea", "trincea", "nodig"):
        if t in tecniche:
            chiavi.append("sezione_%s" % t)
    dims = []
    for i in ist.interferenze:
        for d in i.pozzetti:
            dn = R.norm_pozzetto(d)
            if dn not in dims:
                dims.append(dn)
    for d in sorted(dims):
        chiavi.append("pozzetto_%s" % d)
    if any(e.get("tipo") == "armadio" for i in ist.interferenze for e in i.elementi):
        chiavi.append("armadio")
    chiavi.append("tubi")
    return chiavi


TITOLI_PARTICOLARI = {
    "sezione_minitrincea": "SEZIONE TIPO SCAVO IN MINITRINCEA",
    "sezione_microtrincea": "SEZIONE TIPO SCAVO IN MICROTRINCEA",
    "sezione_trincea": "SEZIONE TIPO SCAVO TRADIZIONALE",
    "sezione_nodig": "SEZIONE TIPO PERFORAZIONE NO DIG",
    "tubi": "PARTICOLARI TUBAZIONI",
}


def genera_pl_istanza(project, ist, comune, out_pdf, orto_id=None, fascia_m=30.0,
                      esporta=True, cartella_utente=None, log=None,
                      cartella_sezioni=None, cartella_foto=None, profilo=None):
    """Crea (o rigenera) il layout 'RFI PL - <istanza>' e lo esporta in PDF.
    `ist` = ftth_rfi.Istanza, `comune` = ftth_rfi.DatiComune.
    `cartella_utente`: cartella dove cercare per prima sezioni
    (sezione_tipo_X), foto (foto_<n>) e particolari (sezione_<tecnica>,
    pozzetto_<dim>, tubi), in SVG/PNG/JPG; poi si usano quelli del plugin.
    `log(testo)` riceve gli avvisi (particolari mancanti, ...).
    `profilo` (dict) adatta la PL ad altri enti (istanze acque): layer della
    linea e della fascia, prefisso dei layer, testi del cartiglio, titolo del
    blocco di legenda, sezione tipo per interferenza, niente km. Senza
    profilo la PL e' quella RFI.
    Ritorna True se il PDF e' stato scritto (o se esporta=False)."""
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    if not ist.interferenze:
        return False
    avvisa = log or (lambda _t: None)
    # cartelle del progetto come in Altri Enti: 04_Foto/FOTO-n.jpg e
    # 05_Sezioni/SEZIONE A-A'.svg
    home = project.homePath() or os.path.dirname(project.fileName() or "")
    # ordine di ricerca: cartella scelta nella scheda, cartella del progetto,
    # (compatibilita') vecchia cartella unica con sottocartelle, plugin
    cart_sez = [cartella_sezioni,
                os.path.join(home, "05_Sezioni") if home else None,
                cartella_utente, os.path.join(cartella_utente or "", "sezioni"),
                os.path.join(ASSETS, "rfi_sezioni")]
    cart_foto = [cartella_foto,
                 os.path.join(home, "04_Foto") if home else None,
                 cartella_utente, os.path.join(cartella_utente or "", "foto")]
    cart_part = [cartella_utente, os.path.join(cartella_utente or "", "particolari"),
                 os.path.join(ASSETS, "rfi_particolari")]

    # foto e sezioni di questa istanza: prima la sua sottocartella (04_Foto/SP28,
    # 05_Sezioni/<linea>…), poi la cartella; i punti di altre istanze no
    nomi_ist = nomi_istanza(ist)
    etichette_inizio(ist.nome_base)
    cart_sez = cartelle_istanza(cart_sez, nomi_ist)
    cart_foto = cartelle_istanza(cart_foto, nomi_ist)
    lon0 = sum(i.lon for i in ist.interferenze) / len(ist.interferenze)
    crs = _crs_metrico(project, lon0)
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    tr = QgsCoordinateTransform(wgs, crs, project)

    # layer
    infra = _trova(project, "03 INFRASTRUTTURE")
    pozz = _trova(project, "02_POZZETTO")
    arm = _trova(project, "01_ARMADIO OTTICO")
    if profilo:
        ferr = _trova(project, profilo["layer_linea"])
        fascia = _trova(project, profilo["layer_fascia"])
        cippi = staz = None
        prefisso = profilo.get("prefisso", "ENTE")
    else:
        ferr = _trova(project, "Ferrovia RFI")
        fascia = _trova(project, "Fascia di rispetto RFI")
        cippi = _trova(project, "Cippi km RFI")
        staz = _trova(project, "Stazioni ferroviarie")
        prefisso = "RFI"
    base = _base_stampe(project)          # gruppo 'Cartografia' o OSM
    orto = _ortofoto(project, orto_id)
    cat = _catasto_stampe(project)        # gruppo 'Mappa Catastale' o WMS AdE
    cerchi, etich = _layer_istanza(project, ist, con_km=not profilo, prefisso=prefisso)
    foto_l = next((l for n in NOMI_LAYER_FOTO for l in project.mapLayersByName(n)), None)
    sez_l = next((l for n in NOMI_LAYER_SEZIONI for l in project.mapLayersByName(n)), None)
    # in planimetria solo cio' che riguarda l'istanza: tratte che toccano la
    # fascia (intere, se continuano fuori) e i loro pozzetti/armadi
    pref = "%s tavole %s" % (prefisso, ist.nome_base)
    fid_tratte = {f for i in ist.interferenze for f in i.tratte_fid}
    fid_pozz = {e.get("fid") for i in ist.interferenze for e in i.elementi
                if e.get("tipo") in ("pozzetto", "pozzetto_fuori")}
    fid_arm = {e.get("fid") for i in ist.interferenze for e in i.elementi
               if e.get("tipo") in ("armadio", "armadio_fuori")}
    da_gruppo = None
    try:    # gruppo dell'istanza nel progetto (Istanze > Ferrovia > ...)
        try:
            from . import ftth_gruppi_istanze as GR
        except ImportError:
            import ftth_gruppi_istanze as GR
        da_gruppo = GR.rete_per_pl(project, ist, copia_filtrata, pref)
        if da_gruppo and da_gruppo[0] is not None:
            extra = GR.elementi_in_piu(project, ist)
            avvisa("rete in tavola dagli elementi con il nome dell'istanza negli shape%s" % (
                " (%d aggiunti a mano)" % extra
                if extra else ""))
        else:
            da_gruppo = None
    except Exception as e:  # noqa: BLE001
        avvisa("gruppo dell'istanza non usato (%s): rete dai layer principali" % e)
        da_gruppo = None
    if da_gruppo:
        infra, pozz, arm = da_gruppo
        fid_tratte = fid_tratte or {"gruppo"}
    else:   # mai la rete intera: fuori dall'istanza (suolo comunale) non si stampa
        infra = copia_filtrata(project, infra, fid_tratte, pref) or infra
        pozz = copia_filtrata(project, pozz, fid_pozz, pref) if pozz is not None else None
        arm = copia_filtrata(project, arm, fid_arm, pref) if arm is not None else None
    # pozzetti esistenti: in planimetria e in legenda (prima mancavano)
    try:
        pz_o = _trova(project, "02_POZZETTO")
        c_st = _campo(pz_o, "STATO") if pz_o is not None else None
        # con l'istanza confermata negli shape (IST_*) valgono solo i suoi
        # pozzetti: quelli tolti e messi sul suolo comunale NON si stampano.
        # Senza conferma: solo gli esistenti attaccati alle tratte dell'istanza
        if pz_o is not None and c_st and pozz is not None and pozz is not pz_o \
                and not da_gruppo and infra is not None:
            gia = {tuple(f.attributes()) for f in pozz.getFeatures()}
            a_inf = QgsCoordinateTransform(pz_o.crs(), infra.crs(), project)
            linee = [f.geometry() for f in infra.getFeatures() if f.hasGeometry()]
            esist = []
            for f in pz_o.getFeatures():
                if str(f[c_st]).strip().lower() != "esistente" or \
                        tuple(f.attributes()) in gia or not f.hasGeometry():
                    continue
                gp = QgsGeometry(f.geometry())
                gp.transform(a_inf)
                if any(gp.distance(l_) <= 1.5 for l_ in linee):
                    esist.append(f)
            if esist:
                pozz.dataProvider().addFeatures(esist)
                pozz.updateExtents()
    except Exception:  # noqa: BLE001
        pass
    cart_img = os.path.join(os.path.dirname(out_pdf) or ".", "_immagini_tavole")
    # rete dell'istanza (scavi, pozzetti, armadi) anche sull'ortofoto
    rete_orto = rete_ortofoto(project, pref, infra, pozz, arm) if fid_tratte else []

    nome_file = os.path.basename(out_pdf)
    if profilo:
        linea_cart = profilo["linea_cartiglio"]
        dati = {"comune": comune.nome, "tipologia_cartiglio": profilo["tipologia_cartiglio"],
                "linea_cartiglio": linea_cart, "data": datetime.date.today().strftime("%m/%Y"),
                "nome_file": nome_file, "titolo_legenda_ente": profilo.get("titolo_legenda")}
    else:
        tip = R.TIPOLOGIE[ist.tipologia]
        g = ist.gestore
        linea_cart = ("%s - %s" % (g.sigla, ist.linea)).upper()
        dati = {"comune": comune.nome, "tipologia_cartiglio": tip["cartiglio"],
                "linea_cartiglio": linea_cart, "data": datetime.date.today().strftime("%m/%Y"),
                "nome_file": nome_file}
    scheda = profilo.get("scheda", "scheda") if profilo else "scheda RFI"

    nome_layout = "%s PL - %s" % (prefisso, ist.nome_base)
    mgr = project.layoutManager()
    vecchio = mgr.layoutByName(nome_layout)
    if vecchio is not None:
        mgr.removeLayout(vecchio)
    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName(nome_layout)
    pc = layout.pageCollection()
    pc.pages()[0].setPageSize(QgsLayoutSize(PAGINA[0], PAGINA[1], MM))
    # particolari: solo quelli disponibili; i mancanti vanno nel registro, non
    # in un riquadro vuoto
    disponibili = []
    for chiave in particolari_necessari(ist):
        nomi = [chiave] + ([LIBRERIA_PC[chiave]] if chiave in LIBRERIA_PC else [])
        f = cerca_file(nomi, cart_part)
        if f:
            w_, h_ = dimensioni_svg(f)
            disponibili.append((chiave, f, w_, h_))
        else:
            avvisa("particolare '%s' non disponibile: aggiungi %s.svg nella cartella "
                   "dei particolari" % (chiave, chiave))
    area_w0 = PAGINA[0] - 2 * MARGINE - CART_W - 4
    area_h0 = PAGINA[1] - 2 * MARGINE
    scala_pc, impag_pc = impagina_particolari(disponibili, area_w0 - 8, area_h0 - 8)
    pagine_pc = len(impag_pc)
    area_w = PAGINA[0] - 2 * MARGINE - CART_W - 4
    area_h = PAGINA[1] - 2 * MARGINE

    def _punto(i):
        return tr.transform(QgsPointXY(i.lon, i.lat))

    def _rect_metri(lista):
        r = None
        for i in lista:
            if i.bbox:
                g_ = QgsGeometry.fromRect(QgsRectangle(*i.bbox))
            else:
                g_ = QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
            g_.transform(tr)
            b = g_.boundingBox()
            r = QgsRectangle(b) if r is None else (r.combineExtentWith(b) or r)
        r.grow(60)
        return r

    base_vett = [etich, cippi, staz, pozz, arm, infra, ferr, fascia]

    # ---- tavole: una per interferenza; se nel suo riquadro ci sono più
    # sezioni disegnate (questa PL ne ha UNA per tavola), una tavola per
    # sezione, inquadrata sulla sezione, con solo quella in planimetria ----
    col_w = (area_w - 6) / 2.0
    tit_h = 6.0
    riga_h = (area_h - 2 * tit_h - 6) / 2.0

    def _vista(r):
        s_ = _scala_che_contiene(r, col_w, riga_h, 1000)
        c_ = r.center()
        dx_, dy_ = col_w * s_ / 2000.0, riga_h * s_ / 2000.0
        return c_, s_, QgsRectangle(c_.x() - dx_, c_.y() - dy_, c_.x() + dx_, c_.y() + dy_)

    # tavole: con sezioni disegnate, UNA tavola per sezione con tutte le
    # interferenze vicine (scala adattata perché entri tutto); senza sezioni
    # una tavola per interferenza, come prima
    tavole = []          # (interferenze, rettangolo, sezioni, centrata sul riquadro)
    r_tutte = _rect_metri(ist.interferenze)
    r_tutte.grow(250)
    secs_ist = [] if sez_l is None else [
        f for f, _d in feature_nel_riquadro(project, sez_l, crs, r_tutte, r_tutte.center(),
                                            istanza=nomi_ist) if sigla_sezione(sez_l, f)]
    if secs_ist:
        a_crs = QgsCoordinateTransform(sez_l.crs(), crs, project)
        geo = {}
        for f in secs_ist:
            g_ = QgsGeometry(f.geometry())
            g_.transform(a_crs)
            geo[f.id()] = g_
        gruppi = {f.id(): [] for f in secs_ist}
        for i in ist.interferenze:
            p_ = QgsGeometry.fromPointXY(_punto(i))
            gruppi[min(geo, key=lambda k_: geo[k_].distance(p_))].append(i)
        for f in secs_ist:
            # ogni sezione ha la sua tavola: se nessuna interferenza le e' piu'
            # vicina, prende quella piu' vicina a lei
            grp = gruppi[f.id()] or [min(ist.interferenze, key=lambda i_: geo[f.id()].distance(
                QgsGeometry.fromPointXY(_punto(i_))))]
            r_ = _rect_metri(grp)
            r_.combineExtentWith(geo[f.id()].boundingBox())
            r_.grow(15)
            tavole.append((grp, r_, [f], True))
    else:
        for i in ist.interferenze:
            tavole.append(([i], _rect_metri([i]), [], False))
    n_pagine = 1 + len(tavole) + pagine_pc
    for _ in range(n_pagine - 1):
        p = QgsLayoutItemPage(layout)
        p.setPageSize(QgsLayoutSize(PAGINA[0], PAGINA[1], MM))
        pc.addPage(p)

    # ---- pagina 1: COROGRAFIA, meta' su ortofoto e meta' su cartografia ----
    r_all = _rect_metri(ist.interferenze)
    tit_c = 6.0
    mezza_h = (area_h - 2 * tit_c - 4) / 2.0
    s_coro = max(5000, _scala_che_contiene(r_all, area_w, mezza_h, 5000))
    _lbl(layout, 0, MARGINE, MARGINE, area_w, tit_c, "INQUADRAMENTO SU ORTOFOTO", 9)
    _mappa(layout, 0, MARGINE, MARGINE + tit_c, area_w, mezza_h, crs,
           [cerchi, ferr, orto], r_all.center(), s_coro)
    y_sotto = MARGINE + tit_c + mezza_h + 4
    _lbl(layout, 0, MARGINE, y_sotto, area_w, tit_c, "INQUADRAMENTO SU CARTOGRAFIA", 9)
    _mappa(layout, 0, MARGINE, y_sotto + tit_c, area_w, mezza_h, crs,
           [cerchi, staz, ferr] + base, r_all.center(), s_coro)
    _cartiglio(layout, 0, dati, "COROGRAFIA", "1:%d" % s_coro,
               legenda_testo="LOCALIZZAZIONE INTERVENTO\n%s" % linea_cart)

    for k, (gruppo, r_i, sez_fisse, extra) in enumerate(tavole, 1):
        i = gruppo[0]
        pag = k
        # planimetria in scala: riquadro effettivamente visibile
        c_pl, s_pl, vis = _vista(r_i)
        centro = c_pl if extra else _punto(i)
        x1, x2 = MARGINE, MARGINE + col_w + 6
        y1 = MARGINE
        y2 = MARGINE + tit_h + riga_h + 6
        # ortofoto
        _lbl(layout, pag, x1, y1, col_w, tit_h, "ORTOFOTO - SCALA 1:5000", 9)
        _mappa(layout, pag, x1, y1 + tit_h, col_w, riga_h, crs, rete_orto + [cerchi, orto],
               centro, 5000)
        # etichette di questa tavola: posizioni calcolate, senza sovrapposizioni
        for ii in gruppo:
            posiziona_etichette(etich, ii.id, crs, tr,
                                QgsCoordinateTransform(crs, wgs, project),
                                c_pl, s_pl, col_w, riga_h)
        # etichette spostate a mano nel layer «Etichette PL (spostabili)»
        try:
            i_px, i_py = etich.fields().indexOf("px"), etich.fields().indexOf("py")
            ids_g = {ii.id for ii in gruppo}
            f_et = [f for f in etich.getFeatures() if f["interf"] in ids_g
                    and f["px"] is not None and str(f["px"]) != "NULL"]
            fin = posizioni_manuali(project, ist.nome_base, [
                (f["testo"], f.geometry().asPoint().x(), f.geometry().asPoint().y(),
                 float(f["px"]), float(f["py"])) for f in f_et])
            etich.dataProvider().changeAttributeValues(
                {f.id(): {i_px: x, i_py: y} for f, (x, y) in zip(f_et, fin)})
        except Exception as e:  # noqa: BLE001
            avvisa("etichette spostabili non applicate: %s" % e)
        # punti di ripresa (con cono) e sezioni disegnati nel progetto: in
        # planimetria quelli del riquadro, con lo stile del progetto
        foto_in = feature_nel_riquadro(project, foto_l, crs, vis, centro, istanza=nomi_ist)
        sez_in = [(f, 0.0) for f in sez_fisse]     # ogni sezione in una tavola
        # una sola foto, quella della sezione
        foto_in = foto_della_sezione(project, foto_l, sez_l, crs, sez_fisse, vis, centro, nomi_ist)
        foto_c = copia_filtrata(project, foto_l, [f.id() for f, _ in foto_in],
                                "%s %d" % (pref, k), "Punto di ripresa fotografica",
                                "rilievo") if foto_in else None
        sez_c = copia_filtrata(project, sez_l, [f.id() for f, _ in sez_in],
                               "%s %d" % (pref, k), "Sezione", "rilievo") if sez_in else None
        if sez_c is not None:
            # estremo con sezione_f vuoto: lo stile ripeteva "A" ai due capi
            cs, cf = _campo(sez_c, "sezione"), _campo(sez_c, "sezione_f")
            if cs and cf:
                agg = {}
                for f in sez_c.getFeatures():
                    s, sf = f[cs], f[cf]
                    if s not in (None, "") and str(s) != "NULL" and \
                            (sf in (None, "") or str(sf) == "NULL"):
                        agg[f.id()] = {sez_c.fields().indexOf(cf): "%s'" % s}
                if agg:
                    sez_c.dataProvider().changeAttributeValues(agg)
        _lbl(layout, pag, x2, y1, col_w, tit_h, "PLANIMETRIA - SCALA 1:%d" % s_pl, 9)
        m_pl = _mappa(layout, pag, x2, y1 + tit_h, col_w, riga_h, crs,
                      [foto_c, sez_c] + base_vett + base, c_pl, s_pl)
        # catasto a 1:1000: i numeri di particella del WMS si vedono solo fino a 1:2000
        foglio = foglio_catastale(i.lat, i.lon)
        _lbl(layout, pag, x1, y2, col_w, tit_h, "ESTRATTO CATASTALE%s - SCALA 1:1000"
             % (" - FOGLIO %s" % foglio if foglio else ""), 9)
        png = render_png(project, [cerchi] + cat, crs, centro, 1000, col_w, riga_h,
                         os.path.join(cart_img, "catasto_%s_%d_%d.png" % (ist.nome_base, i.id, k)))
        if png:
            _immagine(layout, pag, x1, y2 + tit_h, col_w, riga_h, png)
            _box(layout, pag, x1, y2 + tit_h, col_w, riga_h, 0.3)
        else:
            _mappa(layout, pag, x1, y2 + tit_h, col_w, riga_h, crs, [cerchi] + cat, centro, 1000)
        # sezione e foto: prima la cartella scelta dall'utente, poi il plugin
        mezza = (riga_h - tit_h - 3) / 2.0
        # SEZIONE: quella disegnata in planimetria (layer Sezioni, la piu'
        # vicina all'interferenza) -> 05_Sezioni/SEZIONE A-A'.svg; altrimenti
        # la sezione tipo della tipologia
        if profilo:
            nomi_tipo, tit_sez, desc_tipo = profilo["sezione_tipo"](i)
        else:
            nomi_tipo = ["sezione_tipo_%s" % ist.tipologia, "sezione_%s" % ist.tipologia]
            tit_sez, desc_tipo = "SEZIONE TIPO %s" % ist.tipologia, "sezione_tipo_%s" % ist.tipologia
        sez = None
        for f, _d in sez_in:
            sigla = sigla_sezione(sez_l, f)
            if not sigla:
                continue
            p = cerca_file(["SEZIONE %s" % sigla, "SEZIONE_%s" % sigla, sigla], cart_sez)
            if p:
                sez, tit_sez = p, "SEZIONE %s" % sigla
                break
            avvisa("sezione %s disegnata ma file 'SEZIONE %s' non trovato in 05_Sezioni"
                   % (sigla, sigla))
        if sez is None:
            sez = cerca_file(nomi_tipo, cart_sez)
        if sez is None and profilo:
            # ultima risorsa: il particolare della tecnica di scavo del plugin
            sez = cerca_file(nomi_tipo, cart_part)
        _lbl(layout, pag, x2, y2, col_w, tit_h, tit_sez, 9)
        _box(layout, pag, x2, y2 + tit_h, col_w, mezza)
        if sez:
            _immagine(layout, pag, x2 + 1, y2 + tit_h + 1, col_w - 2, mezza - 2, sez)
        else:
            _lbl(layout, pag, x2, y2 + tit_h, col_w, mezza,
                 "Sezione da inserire: disegna la sezione nel layer Sezioni e metti "
                 "SEZIONE A-A'.svg in 05_Sezioni, oppure il file %s "
                 "nella cartella delle sezioni della %s" % (desc_tipo, scheda),
                 7, colore=QColor(150, 150, 150))
            avvisa("%s non trovata (tavola %d)" % (desc_tipo, k))
        # FOTO: i punti di ripresa del riquadro (fino a 2, i piu' vicini) ->
        # 04_Foto/FOTO-n.jpg; poi la colonna Foto della scheda o foto_<id>
        foto = []
        for f, _d in foto_in:
            n = numero_foto(foto_l, f)
            p = cerca_file(nomi_file_foto(n), cart_foto) if n else None
            if p:
                foto.append(("FOTO %s" % n, p))
            elif n:
                avvisa("punto di ripresa FOTO %s senza file FOTO-%s.jpg in 04_Foto" % (n, n))
            if len(foto) == 1:
                break
        if not foto:
            p = i.foto if (i.foto and os.path.isfile(i.foto)) else cerca_file(
                ["foto_%d" % i.id, "foto%d" % i.id, "%d" % i.id], cart_foto)
            if p:
                foto = [("FOTO %d" % k, p)]
        yf = y2 + tit_h + mezza + 3
        _lbl(layout, pag, x2, yf, col_w, tit_h,
             " - ".join(t for t, _ in foto) if foto else "FOTO", 9)
        _box(layout, pag, x2, yf + tit_h, col_w, mezza)
        if foto:
            w_f = (col_w - 2 - 2 * (len(foto) - 1)) / len(foto)
            for n_f, (_t, p) in enumerate(foto):
                p = foto_ritagliata(p, w_f, mezza - 2, cart_img)
                _immagine(layout, pag, x2 + 1 + n_f * (w_f + 2), yf + tit_h + 1,
                          w_f, mezza - 2, p)
        else:
            _lbl(layout, pag, x2, yf + tit_h, col_w, mezza,
                 "Foto da inserire: punto di ripresa nel riquadro con FOTO-n.jpg in "
                 "04_Foto, oppure foto_%d nella cartella foto della %s" % (i.id, scheda), 7,
                 colore=QColor(150, 150, 150))
            avvisa("foto dell'interferenza #%d non trovata" % i.id)
        _cartiglio(layout, pag, dati, "%d" % k, "1:%d" % s_pl, legenda_map=m_pl,
                   legenda_layers=[infra, pozz, arm, foto_c, sez_c, ferr, fascia, cippi])

    # ---- particolari costruttivi: solo quelli delle lavorazioni presenti ----
    for n_pag, pezzi in enumerate(impag_pc):
        pag = 1 + len(tavole) + n_pag
        _box(layout, pag, MARGINE, MARGINE, area_w, area_h, 0.3)
        # blocco centrato nella pagina
        larg = max((x + w for _, _, x, _, w, _ in pezzi), default=0)
        alt = max((y + h for _, _, _, y, _, h in pezzi), default=0)
        ox = MARGINE + (area_w - larg) / 2.0
        oy = MARGINE + (area_h - alt) / 2.0
        for chiave, f, x, y, w, h in pezzi:
            _immagine(layout, pag, ox + x, oy + y, w, h, f)
        _cartiglio(layout, pag, dati, "PC" + (" %d" % (n_pag + 1) if pagine_pc > 1 else ""),
                   "NON IN SCALA")
    del scala_pc

    mgr.addLayout(layout)
    try:
        etichette_fine(project, ist.nome_base)
    except Exception:  # noqa: BLE001
        pass
    if not esporta or SOLO_ETICHETTE:
        return True
    os.makedirs(os.path.dirname(out_pdf) or ".", exist_ok=True)
    exp = QgsLayoutExporter(layout)
    s = QgsLayoutExporter.PdfExportSettings()
    s.dpi = 200
    # testo vero nel PDF (selezionabile, piu' leggero) invece che tracciati
    try:
        from qgis.core import Qgis
        s.textRenderFormat = Qgis.TextRenderFormat.AlwaysText
    except Exception:  # noqa: BLE001
        try:
            from qgis.core import QgsRenderContext
            s.textRenderFormat = QgsRenderContext.TextFormatAlwaysText
        except Exception:  # noqa: BLE001
            pass
    r = exp.exportToPdf(out_pdf, s)
    return r == QgsLayoutExporter.Success and os.path.isfile(out_pdf)


# --------------------------------------------------------------------------- #
#  Etichette della PL spostabili in mappa (tutte le schede istanze)
# --------------------------------------------------------------------------- #
NOME_ETICH_MAN = "Etichette PL (spostabili)"
# «Prepara le etichette in mappa»: le PL si calcolano ma non si esportano
SOLO_ETICHETTE = False


def _stile_etichette_spostabili(l):
    """Punto dell'etichetta + filo di richiamo fino all'elemento (ax, ay),
    così in mappa si vede a cosa si riferisce ogni etichetta."""
    sym = QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "255,255,255,200", "outline_color": "200,0,0,255",
         "size": "1.6"})
    try:
        from qgis.core import QgsGeometryGeneratorSymbolLayer, QgsLineSymbol
        gg = QgsGeometryGeneratorSymbolLayer.create(
            {"geometryModifier": 'make_line($geometry, make_point("ax", "ay"))'})
        try:
            from qgis.core import Qgis
            gg.setSymbolType(Qgis.SymbolType.Line)
        except Exception:  # noqa: BLE001
            from qgis.core import QgsSymbol
            gg.setSymbolType(QgsSymbol.Line)
        gg.setSubSymbol(QgsLineSymbol.createSimple({"color": "200,0,0,255", "width": "0.25"}))
        sym.insertSymbolLayer(0, gg)
    except Exception:  # noqa: BLE001
        pass
    l.setRenderer(QgsSingleSymbolRenderer(sym))
    # testo CENTRATO sul punto (il filo parte da lì) e sempre visibile, anche
    # sopra altre scritte: prima QGIS lo spostava o lo nascondeva
    from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, \
        QgsVectorLayerSimpleLabeling
    pal = QgsPalLayerSettings()
    pal.fieldName = "testo"
    tf = QgsTextFormat()
    tf.setFont(QFont("Arial", 7))
    tf.setSize(7)
    tf.setColor(QColor(200, 0, 0))
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(0.8)
    tf.setBuffer(buf)
    pal.setFormat(tf)
    try:
        from qgis.core import Qgis
        pal.placement = Qgis.LabelPlacement.OverPoint
    except Exception:  # noqa: BLE001
        pass
    try:
        from qgis.core import Qgis
        pal.placementSettings().setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapAtNoCost)
    except Exception:  # noqa: BLE001
        try:
            pal.displayAll = True
        except Exception:  # noqa: BLE001
            pass
    try:
        pal.obstacleSettings().setIsObstacle(False)
    except Exception:  # noqa: BLE001
        pass
    try:
        pal.zIndex = 50
    except Exception:  # noqa: BLE001
        pass
    # posizione del testo = il punto (non spostabile a parte con lo strumento
    # etichette: prima testo e filo si separavano)
    try:
        from qgis.core import QgsProperty
        try:
            px_, py_ = QgsPalLayerSettings.Property.PositionX, QgsPalLayerSettings.Property.PositionY
        except AttributeError:
            px_, py_ = QgsPalLayerSettings.PositionX, QgsPalLayerSettings.PositionY
        ddp = pal.dataDefinedProperties()
        ddp.setProperty(px_, QgsProperty.fromExpression("x($geometry)"))
        ddp.setProperty(py_, QgsProperty.fromExpression("y($geometry)"))
        # testo CENTRATO sul punto, come nelle PL (prima in mappa stava con
        # l'angolo in basso a sinistra sul punto: in stampa usciva spostato)
        try:
            ha_, va_ = QgsPalLayerSettings.Property.Hali, QgsPalLayerSettings.Property.Vali
        except AttributeError:
            ha_, va_ = QgsPalLayerSettings.Hali, QgsPalLayerSettings.Vali
        ddp.setProperty(ha_, QgsProperty.fromValue("Center"))
        ddp.setProperty(va_, QgsProperty.fromValue("Half"))
        pal.setDataDefinedProperties(ddp)
    except Exception:  # noqa: BLE001
        pass
    l.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    l.setLabelsEnabled(True)
    l.triggerRepaint()


# etichette usate nella generazione in corso, per istanza: alla fine si
# cancellano le altre di quell'istanza (vecchie: niente doppioni)
_IN_USO = {}


def etichette_inizio(istanza):
    _IN_USO[str(istanza)] = set()


def etichette_fine(project, istanza):
    """Toglie dal layer le etichette dell'istanza non usate in questa
    generazione (km cambiati, tavole rifatte): prima restavano e si
    vedevano doppie."""
    usate = _IN_USO.pop(str(istanza), None)
    if usate is None:
        return 0
    lyr = next(iter(project.mapLayersByName(NOME_ETICH_MAN)), None)
    if lyr is None:
        return 0
    from qgis.core import QgsFeatureRequest
    filtro = "\"istanza\" = '%s'" % str(istanza).replace("'", "''")
    via = [f.id() for f in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(filtro))
           if f.id() not in usate]
    if via:
        lyr.dataProvider().deleteFeatures(via)
        lyr.triggerRepaint()
    return len(via)


def _layer_etichette_spostabili(project):
    """Layer di punti con le etichette delle PL generate (uno per etichetta,
    alla posizione in tavola). Spostando un punto in mappa, alla prossima
    generazione l'etichetta va lì. Su file accanto al progetto."""
    for l in project.mapLayersByName(NOME_ETICH_MAN):
        _stile_etichette_spostabili(l)      # anche sui layer già creati: con i fili
        return l
    home = project.homePath()
    if not home or not project.fileName():
        return None
    from qgis.core import (QgsFields, QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorFileWriter, QgsVectorLayerSimpleLabeling, QgsWkbTypes)
    cart = os.path.join(home, "01_File shp")
    os.makedirs(cart, exist_ok=True)
    gpkg = os.path.join(cart, "FTTH_etichette_PL.gpkg")
    if not os.path.isfile(gpkg):
        campi = QgsFields()
        for n, t in (("istanza", QVariant.String), ("testo", QVariant.String),
                     ("ax", QVariant.Double), ("ay", QVariant.Double),
                     ("ox", QVariant.Double), ("oy", QVariant.Double)):
            campi.append(QgsField(n, t))
        opz = QgsVectorFileWriter.SaveVectorOptions()
        opz.driverName = "GPKG"
        opz.layerName = "etichette_pl"
        w = QgsVectorFileWriter.create(gpkg, campi, QgsWkbTypes.Point,
                                       QgsCoordinateReferenceSystem("EPSG:4326"),
                                       project.transformContext(), opz)
        del w
    l = QgsVectorLayer("%s|layername=etichette_pl" % gpkg, NOME_ETICH_MAN, "ogr")
    if not l.isValid():
        return None
    _stile_etichette_spostabili(l)
    project.addMapLayer(l, False)
    project.layerTreeRoot().insertLayer(0, l)
    return l


def posizioni_manuali(project, istanza, voci):
    """voci = [(testo, ax, ay, px, py)] in EPSG:4326 (ancora e posizione
    calcolata). Ritorna [(px, py)]: dove l'utente ha spostato il punto nel
    layer «Etichette PL (spostabili)» vale la sua posizione, altrimenti
    quella calcolata (che si scrive nel layer per la prossima volta)."""
    try:
        lyr = _layer_etichette_spostabili(project)
    except Exception:  # noqa: BLE001
        lyr = None
    if lyr is None or not voci:
        return [(px, py) for _t, _ax, _ay, px, py in voci]
    from qgis.core import QgsFeatureRequest
    esist = {}
    filtro = "\"istanza\" = '%s'" % str(istanza).replace("'", "''")
    for f in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(filtro)):
        try:
            esist[(f["testo"], round(float(f["ax"]), 6), round(float(f["ay"]), 6))] = f
        except (TypeError, ValueError):
            pass
    out, nuovi, geo, att = [], [], {}, {}
    i_ox, i_oy = lyr.fields().indexOf("ox"), lyr.fields().indexOf("oy")
    for testo, ax, ay, px, py in voci:
        f = esist.get((testo, round(ax, 6), round(ay, 6)))
        if f is not None and f.hasGeometry():
            p = f.geometry().asPoint()
            try:
                spostata = abs(p.x() - float(f["ox"])) > 1e-7 or abs(p.y() - float(f["oy"])) > 1e-7
            except (TypeError, ValueError):
                spostata = False
            _IN_USO.setdefault(str(istanza), set()).add(f.id())
            if spostata:
                out.append((p.x(), p.y()))
                continue
            geo[f.id()] = QgsGeometry.fromPointXY(QgsPointXY(px, py))
            att[f.id()] = {i_ox: px, i_oy: py}
            out.append((px, py))
            continue
        k_ = (testo, round(ax, 6), round(ay, 6))
        gia = next((x for x in nuovi if (x["testo"], round(x["ax"], 6), round(x["ay"], 6)) == k_),
                   None)
        if gia is not None:          # stessa etichetta in due tavole: un punto
            out.append((gia["ox"], gia["oy"]))
            continue
        g = QgsFeature(lyr.fields())
        g.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(px, py)))
        for n, v in (("istanza", istanza), ("testo", testo), ("ax", ax), ("ay", ay),
                     ("ox", px), ("oy", py)):
            g[n] = v
        nuovi.append(g)
        out.append((px, py))
    pr = lyr.dataProvider()
    if geo:
        pr.changeGeometryValues(geo)
        pr.changeAttributeValues(att)
    if nuovi:
        ok_, aggiunte = pr.addFeatures(nuovi)
        for g in aggiunte or []:
            _IN_USO.setdefault(str(istanza), set()).add(g.id())
    lyr.triggerRepaint()
    return out


def foto_della_sezione(project, foto_l, sez_l, crs, sez_fisse, vis, centro, nomi_ist):
    """UNA foto per tavola: Sezione A-A' -> FOTO 1, B-B' -> FOTO 2, ...; se
    quel numero non c'è, la foto più vicina alla sezione (entro 150 m);
    senza sezione la più vicina al centro della tavola."""
    if foto_l is None:
        return []
    # regola: Sezione A-A' -> FOTO 1, B-B' -> FOTO 2, ... (ovunque sia il punto)
    if sez_fisse and sez_l is not None:
        sig = (sigla_sezione(sez_l, sez_fisse[0]) or "").strip().upper()
        if sig[:1].isalpha():
            n_voluto = str(ord(sig[0]) - ord("A") + 1)
            c_ist = _campo(foto_l, CAMPO_ISTANZA)
            for f in foto_l.getFeatures():
                if numero_foto(foto_l, f) == n_voluto and \
                        (not c_ist or istanza_corrisponde(f[c_ist], nomi_ist)):
                    return [(f, 0.0)]
    if sez_fisse and sez_l is not None:
        g = QgsGeometry(sez_fisse[0].geometry())
        g.transform(QgsCoordinateTransform(sez_l.crs(), crs, project))
        c = g.centroid().asPoint()
        r = QgsRectangle(vis)
        r.combineExtentWith(g.boundingBox())
        r.grow(150)
        cand = feature_nel_riquadro(project, foto_l, crs, r, QgsPointXY(c), istanza=nomi_ist)
    else:
        cand = feature_nel_riquadro(project, foto_l, crs, vis, centro, istanza=nomi_ist)
    return [(f, d) for f, d in cand if numero_foto(foto_l, f)][:1]


def assegna_sezioni(project, sez_l, crs, riquadri, centri, nomi_ist):
    """Per ogni riquadro le sue sezioni: ognuna va in UNA sola tavola, quella
    col centro più vicino fra quelle che la inquadrano (prima una sezione
    fra due interferenze vicine finiva in due tavole e ne creava altre)."""
    out = [[] for _ in riquadri]
    if sez_l is None:
        return out
    scelta = {}
    for k, (q, c) in enumerate(zip(riquadri, centri)):
        for f, d in feature_nel_riquadro(project, sez_l, crs, q, c, istanza=nomi_ist):
            if not sigla_sezione(sez_l, f):
                continue
            if f.id() not in scelta or d < scelta[f.id()][1]:
                scelta[f.id()] = (k, d, f)
    for k, d, f in scelta.values():
        out[k].append((d, f))
    return [[f for _d, f in sorted(a, key=lambda x: x[0])] for a in out]


def ha_istanza(lyr, f):
    """La sezione / foto ha il campo ISTANZA compilato."""
    c = _campo(lyr, CAMPO_ISTANZA)
    if not c:
        return False
    v = f[c]
    return v is not None and str(v).strip() not in ("", "NULL")


def rotazione_con_strumento(lyr, campo="Rotazione"):
    """Coni delle foto ruotabili con lo strumento di QGIS «Ruota simboli
    puntuali»: lo strumento vuole l'angolo del simbolo legato al CAMPO, mentre
    lo stile usava espressioni («Rotazione + 90»). Si passa al campo
    semplice; i valori già scritti crescono di 90° così i coni non cambiano
    direzione. Una volta sola per layer (proprietà ftth/rotazione_v2)."""
    from qgis.core import QgsExpression, QgsProperty, QgsRenderContext, QgsSymbolLayer
    k = lyr.fields().indexOf(campo)
    if k < 0 or lyr.renderer() is None or lyr.customProperty("ftth/rotazione_v2"):
        return False
    simboli = [s for s in lyr.renderer().symbols(QgsRenderContext())
               if isinstance(s, QgsMarkerSymbol)]
    if not simboli:
        return False
    aggiungi = 0.0
    for s in simboli:
        for sl in s.symbolLayers():
            pr = sl.dataDefinedProperties().property(QgsSymbolLayer.PropertyAngle)
            if pr is None or not pr.isActive():
                continue
            testo = pr.expressionString() if pr.propertyType() == QgsProperty.ExpressionBasedProperty \
                else ('"%s"' % pr.field())
            if campo.lower() not in testo.lower():
                continue
            off = QgsExpression(testo.replace('"%s"' % campo, "0")).evaluate()
            try:
                off = float(off)
            except (TypeError, ValueError):
                off = 0.0
            if not aggiungi:
                aggiungi = off       # la base comune (era «+ 90»)
            sl.setAngle(off - aggiungi)
            sl.dataDefinedProperties().setProperty(QgsSymbolLayer.PropertyAngle, QgsProperty())
        s.setDataDefinedAngle(QgsProperty.fromField(campo))
    if aggiungi:
        cambi = {}
        for f in lyr.getFeatures():
            v = f[campo]
            if v is not None and str(v) != "NULL":
                try:
                    cambi[f.id()] = {k: (float(v) + aggiungi) % 360}
                except (TypeError, ValueError):
                    pass
        if cambi:
            if lyr.isEditable():
                for fid, a in cambi.items():
                    lyr.changeAttributeValue(fid, k, a[k])
            else:
                lyr.dataProvider().changeAttributeValues(cambi)
    lyr.setCustomProperty("ftth/rotazione_v2", True)
    lyr.triggerRepaint()
    return True


def numerazione_per_istanza(lyr):
    """Nuovi punti foto e linee di sezione: numero e lettera ripartono per ogni
    istanza (FOTO 1, A-A' anche nella seconda istanza). L'istanza proposta è
    quella dell'ultimo elemento disegnato."""
    from qgis.core import QgsDefaultValue
    k_ist = lyr.fields().indexOf(CAMPO_ISTANZA)
    if k_ist < 0:
        return
    ultima = ("attribute(get_feature_by_id(@layer, aggregate(@layer, 'max', $id)), '%s')"
              % CAMPO_ISTANZA)
    lyr.setDefaultValueDefinition(k_ist, QgsDefaultValue("coalesce(%s, '')" % ultima, False))
    stessa = "coalesce(\"%s\", '') = coalesce(%s, '')" % (CAMPO_ISTANZA, ultima)
    k_n = lyr.fields().indexOf("NumeroFoto")
    if k_n >= 0:
        lyr.setDefaultValueDefinition(k_n, QgsDefaultValue(
            "coalesce(aggregate(@layer, 'max', \"NumeroFoto\", filter:=%s), 0) + 1" % stessa,
            False))
    k_s = lyr.fields().indexOf("sezione")
    if k_s >= 0:
        lyr.setDefaultValueDefinition(k_s, QgsDefaultValue(
            "char(65 + coalesce(aggregate(@layer, 'count', $id, filter:=%s), 0))" % stessa,
            False))
