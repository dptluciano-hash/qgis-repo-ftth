# -*- coding: utf-8 -*-
"""Planimetria 1.1 PL delle istanze ferroviarie come layout di stampa QGIS.

Un layout A3 orizzontale per istanza, sul modello delle tavole delle pratiche
Beexact (Andrano, Poggio Rusco):
  - COROGRAFIA: inquadramento con un cerchio rosso per interferenza;
  - TAVOLA n (una per interferenza): ORTOFOTO, PLANIMETRIA in scala con fascia
    e km, ESTRATTO CATASTALE (WMS Agenzia delle Entrate), SEZIONE, FOTO;
  - TAVOLA PC: particolari costruttivi.
Cartiglio a destra: legenda, logo FiberCop, dati della richiesta, logo
Beexact, data/scala/nome file/tavola. Nessun timbro.

Importa solo qgis.core: si collauda headless con python-qgis-ltr.
(c) Beexact S.r.l.
"""
import datetime
import math
import os
import re

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsGeometry, QgsLayerTreeLayer, QgsLayoutExporter, QgsLayoutItemLabel,
    QgsLayoutItemLegend, QgsLayoutItemMap, QgsLayoutItemPage, QgsLayoutItemPicture,
    QgsLayoutItemShape, QgsLayoutMeasurement, QgsLayoutPoint, QgsLayoutSize,
    QgsLegendStyle, QgsMarkerSymbol, QgsPalLayerSettings, QgsPointXY, QgsPrintLayout,
    QgsProject, QgsRasterLayer, QgsRectangle, QgsSingleSymbolRenderer,
    QgsTextBufferSettings, QgsTextFormat, QgsUnitTypes, QgsVectorLayer,
    QgsVectorLayerSimpleLabeling,
)

MM = QgsUnitTypes.LayoutMillimeters
QUI = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(QUI, "assets")
GRUPPO_BASI = "Basi per le tavole (PL)"
# nome di prima: valeva per tutte le schede, ma diceva «RFI» (confondeva)
GRUPPO_BASI_VECCHIO = "RFI - basi per le tavole"

PAGINA = (420.0, 297.0)          # A3 orizzontale
MARGINE = 8.0
CART_W = 88.0                    # larghezza cartiglio
SCALE = [500, 1000, 2000, 5000, 10000, 25000, 50000]

# CARTO ora richiede una chiave API: base OpenStreetMap standard
URL_CHIARA = "https://tile.openstreetmap.org/{z}/{x}/{y}.png"
URL_ORTO = "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}"
URL_CATASTO = "https://wms.cartografia.agenziaentrate.gov.it/inspire/wms/ows01.php"

TECNICA_TAVOLA = {
    "trincea": "SCAVO TRADIZIONALE",
    "minitrincea": "SCAVO MINITRINCEA",
    "microtrincea": "SCAVO MICROTRINCEA",
    "nodig": "PERFORAZIONE NO DIG",
    "canaletta": "POSA CANALETTA VTR",
}


# --------------------------------------------------------------------------- #
#  Layer di supporto
# --------------------------------------------------------------------------- #


def logo_fibercop():
    """Logo FiberCop del cartiglio: classico o «Milano Cortina 2026» secondo il
    flag del progetto (ftth_logo)."""
    try:
        from . import ftth_logo as _LOGO
    except ImportError:
        import ftth_logo as _LOGO
    try:
        return _LOGO.percorso_logo(QgsProject.instance())
    except Exception:  # noqa: BLE001
        return os.path.join(ASSETS, "fibercop_logo.png")
def _testo_armadio(e):
    """«POSA ARMADIO ARLO 201» (numero ARLO dal campo AREA_AO), come nelle
    altre schede."""
    try:
        from . import ftth_acque as _A
    except ImportError:
        import ftth_acque as _A
    return _A.testo_elemento_auto(e)
def _gruppo_basi(project):
    """Gruppo dei layer di servizio delle PL (copie della rete, numeri,
    etichette, sfondi): in «Altri enti», spento e chiuso, con un nome che vale
    per tutte le schede. Quello di prima («RFI - basi per le tavole»,
    anche al primo livello) si rinomina e si sposta lì."""
    root = project.layerTreeRoot()
    g = root.findGroup(GRUPPO_BASI)
    vecchio = root.findGroup(GRUPPO_BASI_VECCHIO)
    if g is None and vecchio is not None:
        vecchio.setName(GRUPPO_BASI)
        g = vecchio
    if g is None:
        try:
            try:
                from . import ftth_pannello as PN
            except ImportError:
                import ftth_pannello as PN
            g = PN.gruppo(root, PN.ALTRI).addGroup(GRUPPO_BASI)
        except Exception:  # noqa: BLE001
            g = root.addGroup(GRUPPO_BASI)
        g.setItemVisibilityChecked(False)
        g.setExpanded(False)
    return g


def _aggiungi_base(project, layer):
    """Layer di servizio: nel progetto (serve al layout salvato) ma spento e in
    un gruppo a parte, cosi' non disturba la mappa di lavoro."""
    for l in project.mapLayersByName(layer.name()):
        project.removeMapLayer(l.id())
    project.addMapLayer(layer, False)
    _gruppo_basi(project).addLayer(layer)
    return layer


def _xyz(project, nome, url, zmax=19):
    esistenti = project.mapLayersByName(nome)
    if esistenti:
        return esistenti[0]
    l = QgsRasterLayer("type=xyz&url=%s&zmax=%d&zmin=0" % (url, zmax), nome, "wms")
    return _aggiungi_base(project, l) if l.isValid() else None


def _catasto(project):
    nome = "Catasto (Agenzia delle Entrate)"
    esistenti = project.mapLayersByName(nome)
    if esistenti:
        return esistenti[0]
    uri = ("contextualWMSLegend=0&crs=EPSG:6706&dpiMode=7&featureCount=10&format=image/png"
           "&layers=CP.CadastralParcel&layers=fabbricati&styles=&styles=&url=%s" % URL_CATASTO)
    l = QgsRasterLayer(uri, nome, "wms")
    return _aggiungi_base(project, l) if l.isValid() else None


def _ortofoto(project, orto_id=None):
    if orto_id:
        l = project.mapLayer(orto_id)
        if l is not None:
            return l
    # parole intere e in ordine di preferenza: "orto" da solo prendeva anche
    # "Trasp-orto" (un WMS di etichette stradali nei progetti reali)
    import re
    raster = [l for l in project.mapLayers().values() if isinstance(l, QgsRasterLayer)]
    for pat in (r"google satellite", r"\bsatellit", r"\bortofoto", r"\borto\b", r"\bimagery\b",
                r"\bagea\b", r"\bortho"):
        for l in raster:
            if re.search(pat, l.name(), re.I):
                return l
    return _xyz(project, "Ortofoto (Esri World Imagery)", URL_ORTO, 19)


def layers_del_gruppo(project, nome_gruppo, escludi=(), ignora_spunte=False):
    """Layer di un gruppo dell'albero (anche annidato), dall'alto in basso come
    li disegna QGIS. Si tengono solo quelli spuntati sotto il gruppo (la spunta
    del gruppo stesso non conta: nei progetti 'Cartografia' puo' essere spento
    mentre si lavora). Con ignora_spunte=True si prendono tutti."""
    from qgis.core import QgsLayerTreeGroup, QgsLayerTreeLayer
    root = project.layerTreeRoot()
    g = None
    for nodo in root.findGroups(True):
        if nodo.name().strip().lower() == nome_gruppo.lower():
            g = nodo
            break
    if g is None:
        return []
    out = []

    def giro(nodo):
        for c in nodo.children():
            if not ignora_spunte and not c.itemVisibilityChecked():
                continue
            if isinstance(c, QgsLayerTreeGroup):
                giro(c)
            elif isinstance(c, QgsLayerTreeLayer) and c.layer() is not None:
                l = c.layer()
                if l.isValid() and not any(e in l.name().lower() for e in escludi):
                    out.append(l)
    giro(g)
    return out


def _base_stampe(project, senza_ferrovie=False):
    """Cartografia di base delle tavole: il gruppo 'Cartografia' usato per le
    stampe di Altri Enti (CTR DBSN); se manca, OpenStreetMap attenuata.
    senza_ferrovie: senza la ferrovia della CTR («DBSN Ferrovie»), che nelle
    tavole RFI si sovrapponeva al binario dell'istanza."""
    base = layers_del_gruppo(project, "Cartografia",
                             escludi=("ferrovi",) if senza_ferrovie else ())
    if base:
        return base
    osm = _xyz(project, "Base cartografica (OpenStreetMap)", URL_CHIARA, 19)
    if osm is not None:
        osm.setOpacity(0.55)
    return [osm] if osm is not None else []


def _catasto_numeri(project):
    """Numeri di particella e scritte del foglio (WMS AdE: codice_plla, visibile
    fino a 1:2000, e vestizioni). Il gruppo 'Mappa Catastale' dei progetti non li
    contiene, per questo nell'estratto non si leggevano fogli e particelle."""
    nome = "Catasto - numeri di particella e foglio (AdE)"
    esistenti = project.mapLayersByName(nome)
    if esistenti:
        return esistenti[0]
    uri = ("contextualWMSLegend=0&crs=EPSG:6706&dpiMode=7&featureCount=10&format=image/png"
           "&layers=codice_plla&layers=vestizioni&styles=&styles=&url=%s" % URL_CATASTO)
    l = QgsRasterLayer(uri, nome, "wms")
    return _aggiungi_base(project, l) if l.isValid() else None


def foglio_catastale(lat, lon, timeout=20):
    """Numero del foglio catastale nel punto (GetFeatureInfo sul layer
    CP.CadastralZoning del WMS AdE: campo Label). None se il servizio non
    risponde: il titolo dell'estratto resta allora senza foglio."""
    import re
    import urllib.request
    d = 0.0005
    bbox = "%.6f,%.6f,%.6f,%.6f" % (lat - d, lon - d, lat + d, lon + d)   # EPSG:4258 = lat,lon
    url = ("%s?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetFeatureInfo&LAYERS=CP.CadastralZoning"
           "&QUERY_LAYERS=CP.CadastralZoning&CRS=EPSG:4258&BBOX=%s&WIDTH=101&HEIGHT=101"
           "&I=50&J=50&INFO_FORMAT=text/html&STYLES=&FORMAT=image/png" % (URL_CATASTO, bbox))
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "ftth-permessi/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            html = r.read().decode("latin-1", "replace")
    except Exception:  # noqa: BLE001
        return None
    m = re.search(r">\s*Label\s*</th>\s*<td>\s*([^<]+?)\s*</td>", html)
    return m.group(1) if m else None


def _catasto_stampe(project):
    """Catasto: il gruppo 'Mappa Catastale' del progetto se c'e', altrimenti il
    WMS dell'Agenzia delle Entrate; sopra, sempre, i numeri di particella."""
    cat = layers_del_gruppo(project, "Mappa Catastale", escludi=("province",),
                            ignora_spunte=True)
    if not cat:
        l = _catasto(project)
        cat = [l] if l is not None else []
    num = _catasto_numeri(project)
    return ([num] if num is not None else []) + cat


def rete_su_ortofoto(project, lyr, prefisso, nome="scavi"):
    """Copie di un layer della rete (scavi, pozzetti o armadi, gia' filtrati
    sull'istanza) per il riquadro ORTOFOTO: stesso stile della planimetria,
    dimensioni fisse in mm, le linee con un bordo bianco sotto perche' si
    leggano sulla foto; senza etichette. Il riquadro usa lo stesso SR della
    planimetria: l'ortofoto (EPSG:3857) e' riproiettata al volo, quindi gli
    elementi cadono esattamente sulla strada.
    Gli elementi che lo stile del progetto non disegna (es. regola "Esistente"
    spenta) vanno in una seconda copia con uno stile unico rosso: sull'ortofoto
    la rete dell'istanza deve vedersi tutta. Ritorna [copia stile, copia rossa]
    (None dove non serve)."""
    if lyr is None or not lyr.isValid() or lyr.featureCount() == 0:
        return [None, None]
    from qgis.core import (QgsExpressionContextUtils, QgsFeatureRequest, QgsLineSymbol,
                           QgsRenderContext, QgsSimpleLineSymbolLayer, QgsWkbTypes)
    linea = QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.LineGeometry
    tipo = QgsWkbTypes.displayString(lyr.wkbType()) or ("LineString" if linea else "Point")
    feats = list(lyr.getFeatures(QgsFeatureRequest()))

    def _copia(etichetta, lista):
        m = QgsVectorLayer("%s?crs=%s" % (tipo, lyr.crs().authid()),
                           "%s - %s su ortofoto%s" % (prefisso, nome, etichetta), "memory")
        m.dataProvider().addAttributes(lyr.fields().toList())
        m.updateFields()
        m.dataProvider().addFeatures(lista)
        m.updateExtents()
        m.setLabelsEnabled(False)
        m.setCustomProperty("rfi/nome_legenda", nome.capitalize())
        return m

    r = lyr.renderer().clone() if lyr.renderer() is not None else None
    visibili, nascosti = [], list(feats)
    if r is not None:
        if linea:
            try:
                for item in r.legendSymbolItems():
                    sym = item.symbol()
                    if sym is None or sym.type() != 1:      # 1 = linea
                        continue
                    sym = sym.clone()
                    larg = max([sl.width() for sl in sym.symbolLayers()
                                if hasattr(sl, "width")] or [0.5])
                    bordo = QgsSimpleLineSymbolLayer(QColor(255, 255, 255, 230), larg + 0.8)
                    bordo.setPenCapStyle(Qt.RoundCap)
                    sym.insertSymbolLayer(0, bordo)
                    r.setLegendSymbolItem(item.ruleKey(), sym)
            except Exception:  # noqa: BLE001
                pass
        try:
            # dimensioni fisse in mm: con la scala di riferimento del progetto
            # (1:1000) a 1:5000 linee e simboli diventavano quasi invisibili
            r.setReferenceScale(-1)
        except Exception:  # noqa: BLE001
            pass
        try:
            ctx = QgsRenderContext()
            ctx.expressionContext().appendScopes(
                QgsExpressionContextUtils.globalProjectLayerScopes(lyr))
            r.startRender(ctx, lyr.fields())
            visibili, nascosti = [], []
            for f in feats:
                ctx.expressionContext().setFeature(f)
                (visibili if r.willRenderFeature(f, ctx) else nascosti).append(f)
            r.stopRender(ctx)
        except Exception:  # noqa: BLE001
            visibili, nascosti = [], list(feats)
    con_stile = None
    if visibili:
        con_stile = _copia("", visibili)
        con_stile.setRenderer(r)
        con_stile = _aggiungi_base(project, con_stile)
    rossa = None
    if nascosti:
        if linea:
            sym = QgsLineSymbol.createSimple({"line_color": "255,255,255,230",
                                              "line_width": "1.4", "capstyle": "round"})
            sopra = QgsSimpleLineSymbolLayer(QColor(230, 0, 0), 0.7)
            sopra.setPenCapStyle(Qt.RoundCap)
            sym.appendSymbolLayer(sopra)
        else:
            sym = QgsMarkerSymbol.createSimple({
                "name": "square" if nome == "pozzetti" else "diamond", "color": "230,0,0,255",
                "outline_color": "255,255,255,255", "outline_width": "0.4",
                "size": "2.6" if nome == "pozzetti" else "3.4"})
        rossa = _copia(" (altri)", nascosti)
        rossa.setRenderer(QgsSingleSymbolRenderer(sym))
        rossa = _aggiungi_base(project, rossa)
    return [con_stile, rossa]


def rete_ortofoto(project, prefisso, infra, pozz, arm):
    """Layer per il riquadro ORTOFOTO, nell'ordine di disegno (i punti sopra
    le linee): armadi, pozzetti, scavi."""
    return (rete_su_ortofoto(project, arm, prefisso, "armadi")
            + rete_su_ortofoto(project, pozz, prefisso, "pozzetti")
            + rete_su_ortofoto(project, infra, prefisso, "scavi"))


TOLL_POZZETTO_ESISTENTE_M = 3.0   # distanza massima pozzetto esistente - scavo


def rendi_visibili(lyr):
    """Ogni elemento della copia per la tavola si disegna: le voci dello stile
    spente nel progetto che servono a questi elementi si accendono, e chi non
    ha una voce (tipo di pozzetto scritto diverso, campo vuoto) ne riceve una.
    Prima un pozzetto così c'era nella copia ma in tavola non si vedeva.
    Ritorna quante voci ha acceso o aggiunto."""
    if lyr is None or lyr.providerType() != "memory":
        return 0
    try:
        from qgis.core import (QgsCategorizedSymbolRenderer, QgsExpression,
                               QgsExpressionContext, QgsExpressionContextUtils,
                               QgsRendererCategory, QgsRuleBasedRenderer, QgsSymbol)
        r = lyr.renderer()
        feats = list(lyr.getFeatures())
        if r is None or not feats:
            return 0
        ctx = QgsExpressionContext()
        ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(lyr))
        n = 0
        if isinstance(r, QgsCategorizedSymbolRenderer):
            attr = r.classAttribute()
            k_campo = lyr.fields().indexOf(attr)
            ex = None if k_campo >= 0 else QgsExpression(attr)
            valori = set()
            for f in feats:
                if k_campo >= 0:
                    v = f.attribute(k_campo)
                else:
                    ctx.setFeature(f)
                    v = ex.evaluate(ctx)
                valori.add(None if v is None or str(v) == "NULL" else str(v))
            cats = r.categories()
            per_val = {}
            for k, c in enumerate(cats):
                v = c.value()
                per_val.setdefault(None if v in (None, "") or str(v) == "NULL" else str(v),
                                   []).append(k)
            altro = per_val.get(None) or [k for k, c in enumerate(cats) if c.value() == ""]
            for v in valori:
                ks = per_val.get(v)
                if ks:
                    for k in ks:
                        if not cats[k].renderState():
                            r.updateCategoryRenderState(k, True)
                            n += 1
                elif altro:
                    for k in altro:
                        if not cats[k].renderState():
                            r.updateCategoryRenderState(k, True)
                            n += 1
                else:
                    sym = QgsSymbol.defaultSymbol(lyr.geometryType())
                    r.addCategory(QgsRendererCategory("", sym, "Altri"))
                    altro = [len(r.categories()) - 1]
                    n += 1
        elif isinstance(r, QgsRuleBasedRenderer):
            regole = [ru for ru in r.rootRule().children() if ru.filterExpression()
                      and not ru.isElse()]
            senza = 0
            for f in feats:
                ctx.setFeature(f)
                ok = False
                for ru in regole:
                    if QgsExpression(ru.filterExpression()).evaluate(ctx):
                        if not ru.active():
                            ru.setActive(True)
                            n += 1
                        ok = True
                        break
                senza += 0 if ok else 1
            if senza and not any(ru.isElse() and ru.active()
                                 for ru in r.rootRule().children()):
                el = QgsRuleBasedRenderer.Rule(QgsSymbol.defaultSymbol(lyr.geometryType()),
                                               label="Altri", elseRule=True)
                r.rootRule().appendChild(el)
                n += 1
        if n:
            lyr.triggerRepaint()
        return n
    except Exception:  # noqa: BLE001
        return 0


def aggiungi_pozzetti_esistenti(project, pz_o, pozz, infra, toll=TOLL_POZZETTO_ESISTENTE_M):
    """Aggiunge alla copia `pozz` (pozzetti dell'istanza) i pozzetti del layer
    `pz_o` che stanno sugli scavi di `infra` (entro `toll` metri), esistenti
    E nuovi: prima solo gli esistenti, e un pozzetto nuovo sullo scavo ma non
    preso dall'analisi (o non segnato con l'istanza negli shape) non si
    stampava. Quelli già presenti (stesso punto) non si ripetono. Rende anche
    visibili tutti i pozzetti della copia (rendi_visibili). Ritorna quanti ne
    ha aggiunti."""
    if pz_o is None or pozz is None or infra is None or pozz is pz_o:
        return 0
    # solo sulle copie dell'istanza: mai sulla rete intera del progetto
    if infra.providerType() != "memory" or pozz.providerType() != "memory":
        return 0
    from qgis.core import QgsFeature, QgsSpatialIndex
    a_inf = QgsCoordinateTransform(pz_o.crs(), infra.crs(), project)
    linee = {f.id(): f.geometry() for f in infra.getFeatures() if f.hasGeometry()}
    if not linee:
        rendi_visibili(pozz)
        return 0
    idx = QgsSpatialIndex()
    for fid, g in linee.items():
        f_ = QgsFeature(fid)
        f_.setGeometry(g)
        idx.addFeature(f_)
    a_poz = QgsCoordinateTransform(pozz.crs(), infra.crs(), project)
    gia = []
    for f in pozz.getFeatures():
        if f.hasGeometry():
            g = QgsGeometry(f.geometry())
            g.transform(a_poz)
            gia.append(g)
    nomi = pozz.fields().names()
    nuovi = []
    for f in pz_o.getFeatures():
        if not f.hasGeometry():
            continue
        gp = QgsGeometry(f.geometry())
        gp.transform(a_inf)
        r = gp.boundingBox()
        r.grow(toll)
        if not any(linee[i].distance(gp) <= toll for i in idx.intersects(r)):
            continue
        if any(g.distance(gp) < 0.05 for g in gia):
            continue
        nf = QgsFeature(pozz.fields())
        g_out = QgsGeometry(f.geometry())
        if pozz.crs() != pz_o.crs():
            g_out.transform(QgsCoordinateTransform(pz_o.crs(), pozz.crs(), project))
        nf.setGeometry(g_out)
        for nome in pz_o.fields().names():
            if nome in nomi:
                nf[nome] = f[nome]
        nuovi.append(nf)
        gia.append(gp)
    if nuovi:
        pozz.dataProvider().addFeatures(nuovi)
        pozz.updateExtents()
    rendi_visibili(pozz)
    return len(nuovi)


def copia_filtrata(project, lyr, fids, prefisso, nome_legenda=None, gruppo=None):
    """Copia in memoria di `lyr` con le sole feature `fids`, stesso stile ed
    etichette: in planimetria si vede solo cio' che riguarda l'istanza (gli
    scavi fuori fascia e non continui con quelli in fascia spariscono)."""
    if lyr is None or not lyr.isValid():
        return None
    from qgis.core import QgsFeatureRequest, QgsWkbTypes
    tipo = QgsWkbTypes.displayString(lyr.wkbType()) or "LineString"
    mem = QgsVectorLayer("%s?crs=%s" % (tipo, lyr.crs().authid()),
                         "%s - %s" % (prefisso, lyr.name()), "memory")
    mem.dataProvider().addAttributes(lyr.fields().toList())
    mem.updateFields()
    ids = [int(f) for f in fids if f is not None]
    if ids:
        feats = list(lyr.getFeatures(QgsFeatureRequest().setFilterFids(ids)))
        mem.dataProvider().addFeatures(feats)
    mem.updateExtents()
    try:
        if lyr.renderer() is not None:
            r = lyr.renderer().clone()
            # in legenda niente codici "03 ", "02_": solo la descrizione
            for metodo in ("categories", "ranges"):
                if hasattr(r, metodo):
                    for k, c in enumerate(getattr(r, metodo)()):
                        pulito = nome_pulito(c.label())
                        if pulito != c.label():
                            if metodo == "categories":
                                r.updateCategoryLabel(k, pulito)
                            else:
                                r.updateRangeLabel(k, pulito)
            mem.setRenderer(r)
        if lyr.labeling() is not None:
            mem.setLabeling(lyr.labeling().clone())
        mem.setLabelsEnabled(lyr.labelsEnabled())
        mem.setOpacity(lyr.opacity())
    except Exception:  # noqa: BLE001
        pass
    mem.setCustomProperty("rfi/nome_legenda", nome_legenda or nome_pulito(lyr.name()))
    if gruppo:
        mem.setCustomProperty("rfi/gruppo_legenda", gruppo)
    if gruppo == "rilievo":
        # lo stile di Altri Enti ha scala di riferimento 1:1000: a 1:2000 coni e
        # scritte FOTO n uscivano dimezzati. In tavola dimensione fissa in mm.
        try:
            if mem.renderer() is not None:
                mem.renderer().setReferenceScale(-1)
        except Exception:  # noqa: BLE001
            pass
        # cono fotografico e sezione piu' sottili, scritte FOTO n / B-B' piu'
        # piccole e non in grassetto (stile delicato delle tavole)
        try:
            foto = "ripresa" in (nome_legenda or "").lower()
            if foto:
                alleggerisci_rilievo(mem, 7.5)
                etichetta_foto_tavola(mem)
            else:
                stile_sezione_tavola(mem)
        except Exception:  # noqa: BLE001
            pass
    return _aggiungi_base(project, mem)


ALTEZZA_FOTO_MM = 1.6        # scritta FOTO n del cono (2,3 mm era ancora grande)


def etichetta_foto_tavola(lyr, altezza_mm=ALTEZZA_FOTO_MM):
    """Scritta «FOTO n» del cono come la vuole l'utente: grassetto, azzurra con
    alone bianco, alta 1,6 mm, dritta, di lato al punto di ripresa (il vertice
    del cono) dalla parte opposta a dove punta il cono: mai sopra il cono."""
    from qgis.core import (QgsPalLayerSettings, QgsRuleBasedLabeling, QgsTextBufferSettings,
                           QgsTextFormat, QgsVectorLayerSimpleLabeling)
    lab = lyr.labeling()
    vecchia = None
    if isinstance(lab, QgsVectorLayerSimpleLabeling):
        vecchia = lab.settings()
    elif isinstance(lab, QgsRuleBasedLabeling):
        regole = [r for r in lab.rootRule().descendants() if r.settings() is not None]
        vecchia = regole[0].settings() if regole else None
    pal = QgsPalLayerSettings()
    colore = QColor(0, 176, 240)
    if vecchia is not None and vecchia.fieldName:
        pal.fieldName = vecchia.fieldName
        pal.isExpression = vecchia.isExpression
        try:
            colore = vecchia.format().color()
        except Exception:  # noqa: BLE001
            pass
    else:
        campo = _campo(lyr, "NumeroFoto", "numero", "foto")
        pal.fieldName = ("'FOTO ' || \"%s\"" % campo) if campo else "'FOTO'"
        pal.isExpression = True
    tf = QgsTextFormat()
    fnt = QFont("Arial")
    fnt.setBold(True)
    tf.setFont(fnt)
    tf.setSize(altezza_mm)
    tf.setSizeUnit(QgsUnitTypes.RenderMillimeters)
    tf.setColor(colore)
    b = QgsTextBufferSettings()
    b.setEnabled(True)
    b.setSize(0.45)
    b.setSizeUnit(QgsUnitTypes.RenderMillimeters)
    b.setColor(QColor(255, 255, 255))
    tf.setBuffer(b)
    pal.setFormat(tf)
    try:
        from qgis.core import Qgis
        pal.placement = Qgis.LabelPlacement.OverPoint
        pal.quadOffset = Qgis.LabelQuadrantPosition.AboveLeft
    except Exception:  # noqa: BLE001
        pal.placement = QgsPalLayerSettings.OverPoint
        pal.quadOffset = QgsPalLayerSettings.QuadrantAboveLeft
    pal.xOffset = -0.6
    pal.yOffset = 0
    pal.offsetUnits = QgsUnitTypes.RenderMillimeters
    pal.angleOffset = 0
    pal.priority = 8
    # di lato al cono, mai sopra: il lato dipende da dove punta il cono
    # (Rotazione 0 = in alto, 90 = destra, 180 = in basso, 270 = sinistra;
    # verificato in resa)
    rot = _campo(lyr, "Rotazione", "rotation", "rotazione_cono", "angolo")
    if rot:
        a = "((coalesce(\"%s\", 90) %% 360) + 360) %% 360" % rot
        quad = ("CASE WHEN {a} >= 45 AND {a} <= 135 THEN 3 "     # punta a destra -> scritta a sinistra
                "WHEN {a} >= 225 AND {a} <= 315 THEN 5 "         # punta a sinistra -> a destra
                "WHEN {a} > 135 AND {a} < 225 THEN 0 "           # punta in basso -> sopra a sinistra
                "ELSE 6 END").format(a=a)                        # punta in alto -> sotto a sinistra
        off = ("CASE WHEN {a} >= 45 AND {a} <= 135 THEN '-0.7,0' "
               "WHEN {a} >= 225 AND {a} <= 315 THEN '0.7,0' "
               "WHEN {a} > 135 AND {a} < 225 THEN '-0.4,-0.3' "
               "ELSE '-0.4,0.3' END").format(a=a)
        try:
            from qgis.core import QgsProperty
            ddp = pal.dataDefinedProperties()
            ddp.setProperty(QgsPalLayerSettings.OffsetQuad, QgsProperty.fromExpression(quad))
            ddp.setProperty(QgsPalLayerSettings.OffsetXY, QgsProperty.fromExpression(off))
            pal.setDataDefinedProperties(ddp)
        except Exception:  # noqa: BLE001
            pass
    else:
        pal.quadOffset = getattr(QgsPalLayerSettings, "QuadrantLeft", 3)
    try:
        from qgis.core import Qgis
        ps = pal.placementSettings()
        ps.setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapIfRequired)
        pal.setPlacementSettings(ps)
    except Exception:  # noqa: BLE001
        pass
    lyr.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    lyr.setLabelsEnabled(True)


def alleggerisci_rilievo(lyr, corpo):
    """Linee del simbolo a poco piu' di meta' spessore e scritte al massimo
    `corpo` pt, non in grassetto: il cono e la scritta FOTO n pesavano piu'
    della rete."""
    from qgis.core import QgsRuleBasedLabeling, QgsVectorLayerSimpleLabeling
    for s in _simboli(lyr):
        for sl in s.symbolLayers():
            for leggi, scrivi in (("strokeWidth", "setStrokeWidth"), ("width", "setWidth")):
                if hasattr(sl, leggi) and hasattr(sl, scrivi):
                    try:
                        v = getattr(sl, leggi)()
                        if v and v > 0:
                            getattr(sl, scrivi)(max(0.1, v * 0.55))
                    except Exception:  # noqa: BLE001
                        pass

    def _pal(pal):
        tf = pal.format()
        f = tf.font()
        f.setBold(False)
        tf.setFont(f)
        if tf.size() > corpo:
            tf.setSize(corpo)
        pal.setFormat(tf)
        return pal
    lab = lyr.labeling()
    if isinstance(lab, QgsVectorLayerSimpleLabeling):
        lyr.setLabeling(QgsVectorLayerSimpleLabeling(_pal(lab.settings())))
    elif isinstance(lab, QgsRuleBasedLabeling):
        lab = lab.clone()

        def _giro(r):
            if r.settings() is not None:
                r.setSettings(_pal(r.settings()))
            for c in r.children():
                _giro(c)
        _giro(lab.rootRule())
        lyr.setLabeling(lab)


# --------------------------------------------------------------------------- #
#  Foto e sezioni disegnate nel progetto (come in Altri Enti)
# --------------------------------------------------------------------------- #
NOMI_LAYER_FOTO = ("Punto di Ripresa Fotografico", "Punti di Ripresa", "Punto di Ripresa")
NOMI_LAYER_SEZIONI = ("Sezioni",)


def _campo(lyr, *nomi):
    nomi_l = [n.lower() for n in nomi]
    for f in lyr.fields():
        if f.name().lower() in nomi_l:
            return f.name()
    return None


# Foto e sezioni per istanza: nei layer «Punto di Ripresa Fotografico» e
# «Sezioni» il campo ISTANZA dice a quale istanza appartiene il punto o la
# linea (vuoto = vale per tutte). Così nello stesso progetto ci possono essere
# due «FOTO 1» o due «A-A'» di istanze diverse; i file si cercano prima nella
# sottocartella con il nome dell'istanza (04_Foto/SP28/FOTO-1.jpg,
# 05_Sezioni/Linea 124 …/SEZIONE A-A'.svg), poi nella cartella.
CAMPO_ISTANZA = "ISTANZA"
SEP_NOMI = " - "          # come lo scrive ftth_gruppi_istanze.valore


def _gr():
    try:
        from . import ftth_gruppi_istanze as GR
    except ImportError:
        import ftth_gruppi_istanze as GR
    return GR


def nome_cartella(testo):
    """Nome di cartella valido in Windows per un nome di istanza (trattini
    lunghi come «-», come nel campo degli shape)."""
    t = re.sub(r'[\\/:*?"<>|]+', "_", _gr().pulisci(testo)).strip()
    return t.rstrip(". ")


def nomi_istanza(ist):
    """Nomi con cui l'istanza si indica nel campo ISTANZA e nelle
    sottocartelle, dal più preciso al più generale: per RFI «Linea — Tipo A —
    Stazione», «Linea — Tipo A», «Linea»; per le altre il nome scritto negli
    shape (SP28, Canale …) e il nome della pratica."""
    out = []
    try:
        try:
            from . import ftth_gruppi_istanze as GR
        except ImportError:
            import ftth_gruppi_istanze as GR
        if getattr(ist, "linea", None) and hasattr(ist, "tipologia"):
            v = GR.valore("rfi", ist)
            parti = v.split(SEP_NOMI)
            out += [SEP_NOMI.join(parti[:k]) for k in range(len(parti), 0, -1)]
        else:
            out.append(GR.valore("strade", ist))
            out.append(GR.etichetta("strade", ist))
    except Exception:  # noqa: BLE001
        pass
    for att in ("linea", "corso", "nome_base"):
        v = getattr(ist, att, None)
        if v:
            out.append(str(v))
    return [n for n in dict.fromkeys(_gr().pulisci(x) for x in out if x and x.strip())]


# layer propri di un ente (foto, sezioni, etichette): «<nome> - RFI», nel
# gruppo «Altri enti > RFI». Richiesta dell'utente: dentro il gruppo dell'ente
# tutto ciò che è suo. Senza questi layer (progetti vecchi) si usano i comuni.
ENTI_LAYER = {"rfi": "RFI", "strade": "Strade", "acque": "Acque",
              "sopr": "Soprintendenza", "parchi": "Parchi"}


def nome_layer_ente(base, ente):
    return "%s - %s" % (base, ENTI_LAYER[ente]) if ente in ENTI_LAYER else base


def di_ente(ente, nome_istanza, project=None):
    """L'istanza (nome della pratica o valore ISTANZA) è di questo ente:
    confermata nella sua scheda (registro delle istanze) o, per RFI, con
    «Linea»/«_RFI» nel nome."""
    t = str(nome_istanza or "").strip()
    if not t or t.upper() == "NULL":
        return False
    if ente == "rfi" and ("_RFI" in t.upper() or t.upper().startswith("LINEA")
                          or "FERROVIA" in t.upper()):
        return True
    try:
        from qgis.core import QgsProject
        GR = _gr()
        k = GR.chiave_nome(t)
        for v in GR.registro(project or QgsProject.instance()).values():
            if not isinstance(v, dict) or v.get("sezione") != ente or not v.get("valore"):
                continue
            val = GR.pulisci(v["valore"])
            nomi = [val] + ([val.split(SEP_NOMI)[0]] if ente == "rfi" else [])
            if any(GR.chiave_nome(n) == k for n in nomi):
                return True
    except Exception:  # noqa: BLE001
        pass
    return False


def layer_rilievo(project, nomi_base, nomi_ist, ente=None):
    """Layer foto (o sezioni) da usare per l'istanza: prima quello fatto apposta
    per lei («Punto di Ripresa Fotografico - <istanza>», pulsante «Foto e
    sezioni per un'istanza»), dal nome più preciso al più generale; poi quello
    dell'ente («Punto di Ripresa Fotografico - RFI»); se non c'è, quello comune
    a tutte (filtrato poi con il campo ISTANZA)."""
    GR = _gr()
    if ente in ENTI_LAYER:
        proprio = next((l for b in nomi_base
                        for l in project.mapLayersByName(nome_layer_ente(b, ente))), None)
    else:
        proprio = None
    for n in nomi_ist or []:
        k = GR.chiave_nome(n)
        if not k:
            continue
        for l in project.mapLayers().values():
            for b in nomi_base:
                if l.name().startswith(b + " - ") and \
                        GR.chiave_nome(l.name()[len(b) + 3:]) == k:
                    return l
    if proprio is not None:
        return proprio
    return next((l for n in nomi_base for l in project.mapLayersByName(n)), None)


def istanza_corrisponde(valore, nomi):
    """True se il valore del campo ISTANZA (anche più nomi separati da «;»)
    indica questa istanza, o se è vuoto (punto valido per tutte)."""
    if valore is None or str(valore).strip() in ("", "NULL"):
        return True
    GR = _gr()
    nl = [GR.chiave_nome(n) for n in nomi]
    for p in str(valore).split(";"):
        p = GR.chiave_nome(p)
        if p and any(n == p or n.startswith(p + SEP_NOMI) for n in nl):
            return True
    return False


def cartelle_istanza(cartelle, nomi):
    """Per ogni cartella: prima le sue sottocartelle con il nome dell'istanza
    (dal più preciso), poi la cartella stessa."""
    out = []
    for c in cartelle:
        if c and nomi and os.path.isdir(c):
            try:
                sotto = {nome_cartella(d).lower(): d for d in os.listdir(c)
                         if os.path.isdir(os.path.join(c, d))}
            except OSError:
                sotto = {}
            for n in nomi:
                d = sotto.get(nome_cartella(n).lower())
                if d and os.path.join(c, d) not in out:
                    out.append(os.path.join(c, d))
        out.append(c)
    return out


# sezioni (disegni SEZIONE A-A') che entrano in una tavola della PL RFI/Acque
SEZIONI_PER_TAVOLA = 1


def feature_nel_riquadro(project, lyr, crs, rect, centro, istanza=None):
    """Feature di `lyr` dentro `rect` (CRS delle tavole), dalla piu' vicina a
    `centro`: [(feature, distanza_m)]. Con `istanza` (nomi_istanza) restano
    solo quelle con il campo ISTANZA vuoto o di questa istanza."""
    if lyr is None or not lyr.isValid():
        return []
    c_ist = _campo(lyr, CAMPO_ISTANZA) if istanza else None
    from qgis.core import QgsFeatureRequest
    a_layer = QgsCoordinateTransform(crs, lyr.crs(), project)
    da_layer = QgsCoordinateTransform(lyr.crs(), crs, project)
    try:
        r_l = a_layer.transformBoundingBox(rect)
    except Exception:  # noqa: BLE001
        return []
    out = []
    pc = QgsGeometry.fromPointXY(centro)
    for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(r_l)):
        g = QgsGeometry(f.geometry())
        if g.isEmpty():
            continue
        try:
            g.transform(da_layer)
        except Exception:  # noqa: BLE001
            continue
        if not g.intersects(QgsGeometry.fromRect(rect)):
            continue
        if c_ist and not istanza_corrisponde(f[c_ist], istanza):
            continue                # foto/sezione di un'altra istanza
        out.append((f, g.distance(pc)))
    out.sort(key=lambda t: t[1])
    return out


def numero_foto(lyr, f):
    c = _campo(lyr, "NumeroFoto", "numero_foto", "n_foto", "foto", "numero")
    if not c:
        return None
    v = f[c]
    if v is None or str(v).strip() in ("", "NULL"):
        return None
    try:
        return str(int(float(v)))
    except (TypeError, ValueError):
        return str(v).strip()


def sigla_sezione(lyr, f):
    """'A-A'' dai campi sezione / sezione_f (o etichetta)."""
    cs, cf, ce = (_campo(lyr, "sezione"), _campo(lyr, "sezione_f"),
                  _campo(lyr, "etichetta"))

    def _v(c):
        if not c:
            return ""
        v = f[c]
        return "" if v is None or str(v) == "NULL" else str(v).strip()
    s, sf = _v(cs), _v(cf)
    if s:
        return "%s-%s" % (s, sf or s + "'")
    e = _v(ce).upper().replace("SEZIONE", "").strip()
    return e or None


def foto_ritagliata(path, w_mm, h_mm, cartella_out):
    """Copia della foto ritagliata al centro con le proporzioni del riquadro
    (w_mm x h_mm): in tavola riempie tutto il riquadro senza fasce vuote e
    senza deformarsi. Le immagini vettoriali restano come sono."""
    if not path or path.lower().endswith(".svg") or w_mm <= 0 or h_mm <= 0:
        return path
    try:
        from qgis.PyQt.QtGui import QImage, QImageReader
        rd = QImageReader(path)
        rd.setAutoTransform(True)          # rispetta l'orientamento EXIF
        img = rd.read()
        if img.isNull():
            return path
        W, H = img.width(), img.height()
        rapporto = w_mm / float(h_mm)
        if W / float(H) > rapporto:        # troppo larga: si taglia ai lati
            nw = int(round(H * rapporto)); x, y, w, h = (W - nw) // 2, 0, nw, H
        else:                               # troppo alta: sopra e sotto
            nh = int(round(W / rapporto)); x, y, w, h = 0, (H - nh) // 2, W, nh
        # risoluzione sufficiente per la stampa (circa 200 dpi sul riquadro)
        px_w = int(w_mm / 25.4 * 200)
        out = img.copy(x, y, w, h)
        if out.width() > px_w:
            from qgis.PyQt.QtCore import Qt as _Qt
            out = out.scaledToWidth(px_w, _Qt.SmoothTransformation)
        os.makedirs(cartella_out, exist_ok=True)
        base = os.path.splitext(os.path.basename(path))[0]
        dest = os.path.join(cartella_out, "%s_%dx%d.jpg" % (base, int(w_mm), int(h_mm)))
        if out.save(dest, "JPG", 90):
            return dest
    except Exception:  # noqa: BLE001
        pass
    return path


def nomi_file_foto(n):
    return ["FOTO-%s" % n, "FOTO %s" % n, "FOTO_%s" % n, "foto_%s" % n, "foto%s" % n]


def nome_pulito(testo):
    """Toglie i codici di ordinamento iniziali: "03 INFRASTRUTTURE" ->
    "INFRASTRUTTURE", "02_POZZETTO" -> "POZZETTO", "01_ARMADIO OTTICO" ->
    "ARMADIO OTTICO". I numeri dentro il testo (76x40, Ø 14) restano."""
    if not testo:
        return testo
    t = re.sub(r"^\s*\d+(?:[._-]\d+)*\s*[-_.)]*\s*", "", str(testo))
    t = t.replace("_", " ").strip()
    return t or str(testo)


def render_png(project, layers, crs, centro, scala, w_mm, h_mm, path, dpi=110):
    """Disegna i layer in un PNG a `dpi` per un riquadro di w_mm x h_mm alla
    scala data. Serve al catasto: il WMS scrive i numeri di particella con una
    dimensione fissa in pixel, e a 200 dpi uscivano minuscoli."""
    from qgis.core import QgsMapRendererSequentialJob, QgsMapSettings
    from qgis.PyQt.QtCore import QSize
    px = int(round(w_mm / 25.4 * dpi))
    py = int(round(h_mm / 25.4 * dpi))
    dx = w_mm * scala / 1000.0 / 2.0
    dy = h_mm * scala / 1000.0 / 2.0
    ms = QgsMapSettings()
    ms.setLayers([l for l in layers if l is not None])
    ms.setDestinationCrs(crs)
    ms.setTransformContext(project.transformContext())
    ms.setOutputSize(QSize(px, py))
    ms.setOutputDpi(dpi)
    ms.setBackgroundColor(QColor(255, 255, 255))
    ms.setExtent(QgsRectangle(centro.x() - dx, centro.y() - dy, centro.x() + dx, centro.y() + dy))
    job = QgsMapRendererSequentialJob(ms)
    job.start()
    job.waitForFinished()
    img = job.renderedImage()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path if img.save(path) else None


def _trova(project, *nomi):
    for n in nomi:
        for l in project.mapLayersByName(n):
            return l
    for n in nomi:
        for l in project.mapLayers().values():
            if n.lower() in l.name().lower():
                return l
    return None


def _testo_interferenza(i):
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    km_ingresso = False     # niente etichetta di solo km: il km sta in quella dello scavo
    if km_ingresso:
        # i km sono gia' scritti dove lo scavo entra in fascia: non si ripetono
        righe = []
    elif R.km_valore(i.km_da) is None:
        righe = ["km da verificare"]
    elif not i.km_a or i.km_a == i.km_da or R.km_valore(i.km_a) is None:
        righe = ["km %s" % i.km_da]
    else:
        righe = ["km %s - %s" % (i.km_da, i.km_a)]
    for t, m in i.metri.items():
        if m:
            righe.append("%s Mt %s" % (TECNICA_TAVOLA.get(t, t.upper()),
                                       int(float(m) + 0.5)))
    # i pozzetti hanno ora ciascuno la propria etichetta col km (vedi
    # _testo_elemento); qui solo se l'interferenza non porta gli elementi
    if not any(e.get("tipo") == "pozzetto" for e in i.elementi):
        for d, n in i.pozzetti.items():
            righe.append("POSA %s POZZETT%s %s" % ("NUOVO" if n == 1 else "%d NUOVI" % n,
                                                  "O" if n == 1 else "I", d.upper()))
    return "\n".join(righe)


def _testo_elemento(e, km_ingresso=False, con_km=True):
    """Etichetta di un pozzetto/armadio nuovo in fascia, con il suo km.
    con_km=False (istanze acque): niente progressive, solo la lavorazione."""
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    km = e.get("km")
    km_ok = R.km_valore(km) is not None
    if not con_km:
        if e.get("tipo") in ("ingresso",):
            return None
        if e.get("tipo") == "fuori":
            return "NON DI COMPETENZA"
        if e.get("tipo") == "scavo":
            return "%s Mt %s" % (TECNICA_TAVOLA.get(e.get("tecnica"),
                                                     "SCAVO " + str(e.get("tecnica")).upper()),
                                 e.get("metri"))
        if e.get("tipo") == "armadio":
            return _testo_armadio(e)
        return "NUOVO POZZETTO %s" % (e.get("dim") or "").upper()
    # km sempre su pozzetti e armadi: senza cippi il segnaposto XXX+XXX, come
    # nei documenti, da completare a mano
    km_txt = "KM %s" % (km if km_ok else R.KM_SEGNAPOSTO)
    if e.get("tipo") == "ingresso":
        return None             # il km d'ingresso in fascia sta nell'etichetta dello scavo
    if e.get("tipo") == "fuori":
        return "NON DI COMPETENZA"             # tratto fuori fascia, non computato
    if e.get("tipo") == "scavo":
        testa = "%s Mt %s" % (TECNICA_TAVOLA.get(e.get("tecnica"),
                                                  "SCAVO " + str(e.get("tecnica")).upper()),
                              e.get("metri"))
        # il km dello scavo si legge gia' nelle etichette d'ingresso in fascia
        return testa if km_ingresso else "%s\n%s" % (km_txt, testa)
    if e.get("tipo") == "armadio":
        testa = _testo_armadio(e)
    else:
        testa = "NUOVO POZZETTO %s" % (e.get("dim") or "").upper()
    return "%s\n%s" % (km_txt, testa)


def unisci_etichette_vicine(voci, raggio_m=10.0):
    """Scavo, pozzetto e armadio praticamente nello stesso punto (entro
    `raggio_m`) diventano UNA etichetta: a 1:2000 due etichette li' non
    trovano posto e una spariva (es. il pozzetto in testa allo scavo
    tradizionale di 6 m). Le righe uguali (il km) restano una volta sola;
    l'etichetta sta sul punto dello scavo, se c'e'. km d'ingresso e NON DI
    COMPETENZA restano separati."""
    import math
    unibili = ("scavo", "pozzetto", "armadio")
    out = []
    for v in voci:
        if v["tipo"] not in unibili:
            out.append(dict(v))
            continue
        gruppo = None
        for g in out:
            if g["tipo"] not in unibili:
                continue
            dx = (v["lon"] - g["lon"]) * 111320.0 * math.cos(math.radians(g["lat"]))
            dy = (v["lat"] - g["lat"]) * 110540.0
            if math.hypot(dx, dy) <= raggio_m:
                gruppo = g
                break
        if gruppo is None:
            out.append(dict(v, righe=list(v["righe"])))
            continue
        # km in testa, poi scavi, poi pozzetti/armadi
        km = [r for r in gruppo["righe"] + v["righe"] if r.startswith("KM ")]
        resto = [r for r in gruppo["righe"] + v["righe"] if not r.startswith("KM ")]
        righe = []
        for r in km[:1] + sorted(resto, key=lambda r: 0 if r.startswith("SCAVO") else 1):
            if r not in righe:
                righe.append(r)
        gruppo["righe"] = righe
        if v["tipo"] == "scavo" and gruppo["tipo"] != "scavo":
            gruppo.update(lon=v["lon"], lat=v["lat"], tipo="scavo")
    return out


FONT_ETICH_MM = 5 * 25.4 / 72.0          # corpo 5 pt in mm (8, 7 e 6 pt erano troppo grossi)


def _box_etichetta(testo):
    """Ingombro (larghezza, altezza) in mm di un'etichetta Arial bold 8 pt
    maiuscola con alone, per riga piu' lunga e numero di righe."""
    righe = (testo or "").split("\n")
    w = max(len(r) for r in righe) * FONT_ETICH_MM * 0.66 + 2.4
    h = len(righe) * FONT_ETICH_MM * 1.25 + 2.4
    return w, h


def posiziona_etichette(etich, interf_id, crs_mappa, a_mappa, da_mappa, centro, scala,
                        w_mm, h_mm, ostacoli=(), condivisi=None):
    """Sceglie la posizione delle etichette di UNA tavola (planimetria in
    `scala`, riquadro w_mm x h_mm centrato su `centro`, coordinate di mappa).
    Per ogni etichetta, in ordine di importanza, prova 8 direzioni attorno al
    punto a distanze crescenti e prende la prima che resta nel riquadro e non
    tocca le etichette gia' messe ne' i punti etichettati. Scrive px/py
    (centro dell'etichetta, CRS del layer)."""
    k = 1000.0 / scala                      # mm di carta per metro

    def a_mm(pt):
        return ((pt.x() - centro.x()) * k + w_mm / 2.0,
                h_mm / 2.0 - (pt.y() - centro.y()) * k)

    def da_mm(x, y):
        return QgsPointXY(centro.x() + (x - w_mm / 2.0) / k,
                          centro.y() + (h_mm / 2.0 - y) / k)

    ordine = {"scavo": 0, "ingresso": 1, "pozzetto": 2, "armadio": 2, "fuori": 3}
    feats = [f for f in etich.getFeatures() if f["interf"] == interf_id]
    feats.sort(key=lambda f: ordine.get(f["tipo"], 2))
    punti = []
    for f in feats:
        punti.append(a_mm(a_mappa.transform(f.geometry().asPoint())))
    occupati = [(x - 1.5, y - 1.5, x + 1.5, y + 1.5) for x, y in punti]
    occupati += list(ostacoli)
    # etichette gia' messe nella stessa tavola da altre interferenze: prima
    # ogni interferenza non vedeva le altre e le etichette si sovrapponevano
    if condivisi is not None:
        occupati += list(condivisi)
        condivisi.extend((x - 1.5, y - 1.5, x + 1.5, y + 1.5) for x, y in punti)
    direzioni = [(1, -1), (-1, -1), (1, 1), (-1, 1), (0, -1), (0, 1), (1, 0), (-1, 0)]
    margine = 2.0
    agg = {}
    i_px, i_py = etich.fields().indexOf("px"), etich.fields().indexOf("py")

    def sovrapp(a, b):
        return max(0.0, min(a[2], b[2]) - max(a[0], b[0])) * \
            max(0.0, min(a[3], b[3]) - max(a[1], b[1]))

    for f, (x0, y0) in zip(feats, punti):
        bw, bh = _box_etichetta(f["testo"])
        migliore, costo_min = None, None
        for dist in (6.0, 10.0, 15.0, 21.0, 28.0):
            for dx, dy in direzioni:
                cx = x0 + dx * (dist + bw / 2.0) if dx else x0
                cy = y0 + dy * (dist + bh / 2.0) if dy else y0
                if not dx:
                    cy = y0 + dy * (dist + bh / 2.0)
                box = (cx - bw / 2.0, cy - bh / 2.0, cx + bw / 2.0, cy + bh / 2.0)
                fuori = (box[0] < margine or box[1] < margine or
                         box[2] > w_mm - margine or box[3] > h_mm - margine)
                urto = sum(sovrapp(box, o) for o in occupati)
                costo = urto * 100 + (1000 if fuori else 0) + dist
                if costo_min is None or costo < costo_min:
                    migliore, costo_min = (cx, cy, box), costo
                if not fuori and urto == 0:
                    break
            if migliore is not None and costo_min is not None and costo_min < 100:
                break
        cx, cy, box = migliore
        occupati.append((box[0] - 1, box[1] - 1, box[2] + 1, box[3] + 1))
        if condivisi is not None:
            condivisi.append((box[0] - 1, box[1] - 1, box[2] + 1, box[3] + 1))
        p_lay = da_mappa.transform(da_mm(cx, cy))
        agg[f.id()] = {i_px: p_lay.x(), i_py: p_lay.y()}
    if agg:
        etich.dataProvider().changeAttributeValues(agg)


def _layer_istanza(project, ist, con_km=True, prefisso="RFI"):
    """Due layer temporanei dell'istanza: cerchi (corografia) ed etichette
    km/scavi (planimetria)."""
    cerchi = QgsVectorLayer("Point?crs=EPSG:4326", "%s tavole %s - interferenze"
                            % (prefisso, ist.nome_base), "memory")
    cerchi.dataProvider().addAttributes([QgsField("id", QVariant.Int)])
    cerchi.updateFields()
    etich = QgsVectorLayer("Point?crs=EPSG:4326", "%s tavole %s - etichette"
                           % (prefisso, ist.nome_base), "memory")
    etich.dataProvider().addAttributes([QgsField("testo", QVariant.String),
                                        QgsField("tipo", QVariant.String),
                                        QgsField("interf", QVariant.Int),
                                        QgsField("px", QVariant.Double),
                                        QgsField("py", QVariant.Double),
                                        QgsField("html", QVariant.String)])
    etich.updateFields()
    fc, fe = [], []
    for i in ist.interferenze:
        p = QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
        f = QgsFeature(cerchi.fields()); f.setGeometry(p); f["id"] = i.id; fc.append(f)
        try:
            from . import ftth_rfi as R
        except ImportError:
            import ftth_rfi as R
        km_ingr = False         # niente etichetta di solo km (vedi _testo_elemento)
        # con gli scavi etichettati uno per uno (tratta per tratta) l'etichetta
        # unica dell'interferenza non serve: puntava a un solo scavo
        if con_km and not any(e.get("tipo") == "scavo" for e in i.elementi):
            f = QgsFeature(etich.fields()); f.setGeometry(p)
            f["testo"] = _testo_interferenza(i); f["tipo"] = "scavo"; f["interf"] = i.id
            fe.append(f)
        voci = []
        for e in i.elementi:
            if e.get("tipo", "").endswith("_fuori"):
                continue          # pozzetti/armadi fuori fascia: disegnati, non etichettati
            testo = _testo_elemento(e, km_ingr, con_km)
            if testo:
                voci.append({"lon": e["lon"], "lat": e["lat"], "tipo": e.get("tipo"),
                             "righe": testo.split("\n")})
        for v in unisci_etichette_vicine(voci):
            f = QgsFeature(etich.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(v["lon"], v["lat"])))
            f["testo"] = "\n".join(v["righe"])
            f["tipo"] = v["tipo"]
            f["interf"] = i.id
            fe.append(f)
    cerchi.dataProvider().addFeatures(fc)
    for f in fe:
        f["html"] = testo_html(f["testo"])
    etich.dataProvider().addFeatures(fe)
    cerchi.updateExtents(); etich.updateExtents()
    cerchi.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "255,70,70,150", "outline_color": "230,60,60,200",
         "size": "9"})))
    etich.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "0,0,0,0", "outline_color": "0,0,0,0", "size": "1"})))
    pal = QgsPalLayerSettings()
    pal.fieldName = "testo"
    # posizione scelta fra 8 attorno al punto, staccata e con linea di richiamo
    # (come nelle tavole di progetto): il motore prende la prima libera, cosi'
    # le etichette non si sovrappongono fra loro ne' a quelle del progetto
    try:
        pal.placement = QgsPalLayerSettings.OrderedPositionsAroundPoint
    except Exception:  # noqa: BLE001
        pass
    pal.dist = 7
    try:
        pal.distUnits = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        pass
    try:
        pal.setCallout(filo_etichetta())
    except Exception:  # noqa: BLE001
        pass
    # niente "disegna sempre": con displayAll le etichette si disegnavano anche
    # sopra le altre (a 1:2000 si accavallavano). Il motore sceglie fra le 8
    # posizioni una libera; queste hanno priorita' su quelle del progetto
    # (MT., FOTO n...), che cedono il posto. Fra le nostre: scavo > km di
    # ingresso > pozzetti/armadi > NON DI COMPETENZA.
    pal.displayAll = False
    pal.priority = 10
    try:
        # QGIS >= 3.26: prima una posizione libera; se non c'e', ammessa sopra
        # una linea (degradata) e solo come ultima risorsa sopra un'altra
        # etichetta. Cosi' nessuna etichetta si perde.
        from qgis.core import Qgis
        ps = pal.placementSettings()
        ps.setAllowDegradedPlacement(True)
        ps.setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapIfRequired)
        pal.setPlacementSettings(ps)
    except Exception:  # noqa: BLE001
        pass
    try:
        from qgis.core import QgsProperty
        dd = pal.dataDefinedProperties()
        dd.setProperty(
            QgsPalLayerSettings.Color,
            QgsProperty.fromExpression("CASE WHEN \"tipo\" = 'fuori' THEN '0,0,0,255' "
                                       "ELSE '200,0,0,255' END"))
        dd.setProperty(
            QgsPalLayerSettings.Priority,
            QgsProperty.fromExpression("CASE \"tipo\" WHEN 'scavo' THEN 10 WHEN 'ingresso' "
                                       "THEN 9 WHEN 'fuori' THEN 6 ELSE 8 END"))
        # posizione calcolata dal plugin tavola per tavola (posiziona_etichette):
        # centro dell'etichetta in px/py (CRS del layer); la linea di richiamo
        # la collega al punto. Col motore di QGIS le aree della cartografia di
        # base facevano da ostacolo ovunque e due etichette finivano nello
        # stesso posto (o una spariva).
        dd.setProperty(QgsPalLayerSettings.PositionX, QgsProperty.fromField("px"))
        dd.setProperty(QgsPalLayerSettings.PositionY, QgsProperty.fromField("py"))
        dd.setProperty(QgsPalLayerSettings.Hali, QgsProperty.fromValue("Center"))
        dd.setProperty(QgsPalLayerSettings.Vali, QgsProperty.fromValue("Half"))
        dd.setProperty(QgsPalLayerSettings.AlwaysShow,
                       QgsProperty.fromExpression("\"px\" IS NOT NULL"))
    except Exception:  # noqa: BLE001
        pass
    pal.setFormat(formato_etichetta())
    etichetta_km_nero(pal)
    etich.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    etich.setLabelsEnabled(True)
    return _aggiungi_base(project, cerchi), _aggiungi_base(project, etich)


# --------------------------------------------------------------------------- #
#  Stile delle tavole: fascia leggera, sezione trasparente, simboli e quote
# --------------------------------------------------------------------------- #
SCARTAMENTO_MEZZO_M = 0.7175      # meta' scartamento 1435 mm: asse binario -> rotaia
QUOTE_MAX_M = 40.0                # oltre questa distanza dalla rotaia niente quota


def ferrovia_tavola(project, ferr, prefisso):
    """Binario in tavola: grigio e bianco, leggero e un po' trasparente (il
    nero pieno pesava piu' della rete)."""
    if ferr is None or not ferr.isValid():
        return None
    from qgis.core import QgsLineSymbol, QgsSimpleLineSymbolLayer
    from qgis.core import QgsWkbTypes
    tipo = QgsWkbTypes.displayString(ferr.wkbType()) or "LineString"
    m = QgsVectorLayer("%s?crs=%s" % (tipo, ferr.crs().authid()),
                       "%s - ferrovia" % prefisso, "memory")
    m.dataProvider().addAttributes(ferr.fields().toList())
    m.updateFields()
    m.dataProvider().addFeatures([QgsFeature(f) for f in ferr.getFeatures()])
    m.updateExtents()
    sym = QgsLineSymbol()
    sym.deleteSymbolLayer(0)
    base = QgsSimpleLineSymbolLayer(QColor(120, 120, 120))
    base.setWidth(0.8)
    sym.appendSymbolLayer(base)
    trav = QgsSimpleLineSymbolLayer(QColor(255, 255, 255))
    trav.setWidth(0.55)
    trav.setPenStyle(Qt.CustomDashLine)
    trav.setCustomDashVector([3, 3])
    trav.setUseCustomDashPattern(True)
    sym.appendSymbolLayer(trav)
    sym.setOpacity(0.65)
    m.setRenderer(QgsSingleSymbolRenderer(sym))
    for c in ("rfi/nome_legenda", "rfi/gruppo_legenda", "rfi/titolo_legenda"):
        if ferr.customProperty(c):
            m.setCustomProperty(c, ferr.customProperty(c))
    if not m.customProperty("rfi/nome_legenda"):
        m.setCustomProperty("rfi/titolo_legenda", ferr.name())
    m.setCustomProperty("rfi/gruppo_legenda", "ferro")
    return _aggiungi_base(project, m)


def ferrovia_inquadramento(project, ferr, prefisso):
    """Binario per l'INQUADRAMENTO (corografia a 1:5000 e oltre): nero pieno con
    tratteggio bianco e bordo bianco, ben visibile anche sull'ortofoto. Lo
    stile delle tavole, leggero e trasparente, a quella scala quasi spariva
    (utente: «su inquadramento i binari si vedono poco»)."""
    if ferr is None or not ferr.isValid():
        return None
    from qgis.core import QgsLineSymbol, QgsSimpleLineSymbolLayer, QgsWkbTypes
    tipo = QgsWkbTypes.displayString(ferr.wkbType()) or "LineString"
    m = QgsVectorLayer("%s?crs=%s" % (tipo, ferr.crs().authid()),
                       "%s - ferrovia inquadramento" % prefisso, "memory")
    m.dataProvider().addAttributes(ferr.fields().toList())
    m.updateFields()
    m.dataProvider().addFeatures([QgsFeature(f) for f in ferr.getFeatures()])
    m.updateExtents()
    sym = QgsLineSymbol()
    sym.deleteSymbolLayer(0)
    for colore, larg, tratt in ((QColor(255, 255, 255), 2.0, False),
                                (QColor(25, 25, 25), 1.3, False),
                                (QColor(255, 255, 255), 0.7, True)):
        sl = QgsSimpleLineSymbolLayer(colore)
        sl.setWidth(larg)
        sl.setPenCapStyle(Qt.FlatCap)
        if tratt:
            sl.setPenStyle(Qt.CustomDashLine)
            sl.setCustomDashVector([4, 4])
            sl.setUseCustomDashPattern(True)
        sym.appendSymbolLayer(sl)
    m.setRenderer(QgsSingleSymbolRenderer(sym))
    return _aggiungi_base(project, m)


def fascia_tavola(project, fascia, prefisso, testo="FASCIA DI RISPETTO ROTAIE 6-30 M"):
    """Copia della fascia di rispetto per le tavole: riempimento appena
    accennato e bordo tratteggiato verde semitrasparente (in planimetria si
    leggeva come una campitura piena), usata anche su ortofoto e catasto."""
    if fascia is None or not fascia.isValid():
        return None
    from qgis.core import QgsFillSymbol
    m = QgsVectorLayer("MultiPolygon?crs=%s" % fascia.crs().authid(),
                       "%s - fascia di rispetto" % prefisso, "memory")
    m.dataProvider().addFeatures([QgsFeature(f) for f in fascia.getFeatures()])
    m.updateExtents()
    sym = QgsFillSymbol.createSimple({
        "color": "255,110,110,16", "outline_color": "0,130,60,120",   # riempimento leggero (utente)
        "outline_width": "0.25", "outline_style": "dash"})
    m.setRenderer(QgsSingleSymbolRenderer(sym))
    # la scritta lungo le linee, come nelle tavole consegnate
    try:
        from qgis.core import (QgsPalLayerSettings, QgsTextBufferSettings, QgsTextFormat,
                               QgsVectorLayerSimpleLabeling)
        pal = QgsPalLayerSettings()
        pal.isExpression = True
        pal.fieldName = "'%s'" % testo.replace("'", "''")
        try:
            from qgis.core import Qgis
            pal.placement = Qgis.LabelPlacement.Line
        except Exception:  # noqa: BLE001
            pal.placement = QgsPalLayerSettings.Line
        try:
            pal.repeatDistance = 90
            pal.repeatDistanceUnit = QgsUnitTypes.RenderMillimeters
        except Exception:  # noqa: BLE001
            pass
        tf = QgsTextFormat()
        f5 = QFont("Arial", 5)
        f5.setBold(True)
        tf.setFont(f5)
        tf.setSize(5)
        tf.setColor(QColor(40, 40, 40))
        b = QgsTextBufferSettings()
        b.setEnabled(True)
        b.setSize(0.6)
        tf.setBuffer(b)
        pal.setFormat(tf)
        pal.priority = 2
        m.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        m.setLabelsEnabled(True)
    except Exception:  # noqa: BLE001
        pass
    m.setCustomProperty("rfi/nome_legenda", "Fascia di rispetto")
    m.setCustomProperty("rfi/gruppo_legenda", "ferro")
    return _aggiungi_base(project, m)


def _simboli(lyr):
    from qgis.core import QgsRenderContext
    if lyr is None or lyr.renderer() is None:
        return []
    try:
        return list(lyr.renderer().symbols(QgsRenderContext()))
    except Exception:  # noqa: BLE001
        return []


def sezione_trasparente(lyr, opacita=0.45):
    """Linea della sezione in trasparenza: le lettere (etichette) restano piene."""
    for s in _simboli(lyr):
        try:
            s.setOpacity(opacita)
        except Exception:  # noqa: BLE001
            pass
    if lyr is not None:
        lyr.triggerRepaint()


def simboli_piu_piccoli(lyr, fattore=0.75):
    """Pozzetti e armadi un po' piu' piccoli in tavola: a 1:2000 i simboli
    vicini si accavallavano con gli scavi."""
    from qgis.core import QgsMarkerSymbol
    for s in _simboli(lyr):
        if isinstance(s, QgsMarkerSymbol):
            try:
                s.setSize(s.size() * fattore)
            except Exception:  # noqa: BLE001
                pass


def layer_quote(project, ferr, elementi, crs, rect, nome):
    """Quote di distanza dalla rotaia piu' vicina, in proiezione orizzontale e
    ortogonali al binario: per ogni pozzetto e armadio (esistenti e di
    progetto) e per il punto di ogni scavo piu' vicino alla ferrovia, una
    linea dall'elemento alla rotaia con la misura in metri. La rotaia e'
    stimata a meta' scartamento (0,72 m) dall'asse del binario di OSM.
    `elementi` = layer (punti o linee) gia' filtrati sull'istanza."""
    if ferr is None or not ferr.isValid():
        return None
    from qgis.core import (QgsArrowSymbolLayer, QgsFillSymbol, QgsLineSymbol,
                           QgsPalLayerSettings, QgsTextBufferSettings, QgsTextFormat,
                           QgsVectorLayerSimpleLabeling, QgsWkbTypes)
    r_ext = QgsRectangle(rect)
    r_ext.grow(150)
    a_crs = QgsCoordinateTransform(ferr.crs(), crs, project)
    binari = []
    for f in ferr.getFeatures():
        if not f.hasGeometry():
            continue
        g = QgsGeometry(f.geometry())
        g.transform(a_crs)
        if g.boundingBox().intersects(r_ext):
            binari.append(g)
    if not binari:
        return None
    asse = QgsGeometry.unaryUnion(binari)
    quote = []                                   # (da, a, metri)

    def _aggiungi(p):
        if not rect.contains(p):
            return
        gp = QgsGeometry.fromPointXY(p)
        piede = asse.nearestPoint(gp).asPoint()
        d_asse = gp.distance(QgsGeometry.fromPointXY(piede))
        d = d_asse - SCARTAMENTO_MEZZO_M
        if d <= 0.05 or d > QUOTE_MAX_M:
            return
        # estremo sulla rotaia: dall'asse verso l'elemento di meta' scartamento
        k = SCARTAMENTO_MEZZO_M / d_asse
        rot = QgsPointXY(piede.x() + (p.x() - piede.x()) * k,
                         piede.y() + (p.y() - piede.y()) * k)
        quote.append((p, rot, d))

    for lyr in elementi:
        if lyr is None or not lyr.isValid():
            continue
        a_l = QgsCoordinateTransform(lyr.crs(), crs, project)
        punti = QgsWkbTypes.geometryType(lyr.wkbType()) == QgsWkbTypes.PointGeometry
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = QgsGeometry(f.geometry())
            g.transform(a_l)
            if punti:
                for v in g.vertices():
                    _aggiungi(QgsPointXY(v.x(), v.y()))
            else:
                # scavo: il suo punto piu' vicino alla ferrovia
                _aggiungi(g.nearestPoint(asse).asPoint())
    if not quote:
        return None
    # una quota per gruppo: fra elementi a meno di 10 m resta la piu' vicina
    # alla rotaia (quella che conta); prima pozzetto e scavo vicini avevano
    # due quote una sopra l'altra
    tenute = []
    for q in sorted(quote, key=lambda x: x[2]):
        gq = QgsGeometry.fromPointXY(q[0])
        if all(QgsGeometry.fromPointXY(t[0]).distance(gq) >= 10.0 for t in tenute):
            tenute.append(q)
    quote = tenute
    return _layer_da_quote(project, quote, crs, nome)


# layer in cui l'utente disegna le quote (scheda Ferrovie, passo 5)
NOME_QUOTE_MAN = "Quote dalla rotaia"


def quota_ortogonale(project, geom, crs_geom, ferr=None):
    """Quota dalla rotaia raddrizzata: dal primo punto (l'elemento) alla rotaia
    piu' vicina, perpendicolare al binario, con la punta esattamente sulla
    rotaia. Il calcolo si fa in metri (EPSG:3857 conserva gli angoli).
    Ritorna la nuova geometria nel CRS di partenza, o None se non c'e' binario."""
    from qgis.core import QgsCoordinateReferenceSystem
    if ferr is None:
        ferr = next(iter(project.mapLayersByName("Ferrovia RFI")), None)
    if ferr is None or not ferr.isValid() or geom is None or geom.isEmpty():
        return None
    pts = [QgsPointXY(v.x(), v.y()) for v in geom.vertices()]
    if len(pts) < 2:
        return None
    m = QgsCoordinateReferenceSystem("EPSG:3857")
    a_m = QgsCoordinateTransform(crs_geom, m, project)
    f_m = QgsCoordinateTransform(ferr.crs(), m, project)
    p0 = QgsGeometry.fromPointXY(a_m.transform(pts[0]))
    meglio = None
    for f in ferr.getFeatures():
        if not f.hasGeometry():
            continue
        g = QgsGeometry(f.geometry())
        g.transform(f_m)
        d = g.distance(p0)
        if meglio is None or d < meglio[0]:
            meglio = (d, g)
    if meglio is None or meglio[0] <= 0:
        return None
    piede = meglio[1].nearestPoint(p0).asPoint()
    # la linea del layer e' l'asse del binario: la rotaia sta a meta'
    # scartamento verso l'elemento (in EPSG:3857 i metri valgono 1/cos(lat))
    try:
        lat = QgsCoordinateTransform(m, QgsCoordinateReferenceSystem("EPSG:4326"),
                                     project).transform(piede).y()
        semi = SCARTAMENTO_MEZZO_M / max(0.2, math.cos(math.radians(lat)))
    except Exception:  # noqa: BLE001
        semi = SCARTAMENTO_MEZZO_M
    q0 = p0.asPoint()
    if meglio[0] > semi * 1.5:
        k = semi / meglio[0]
        piede = QgsPointXY(piede.x() + (q0.x() - piede.x()) * k,
                           piede.y() + (q0.y() - piede.y()) * k)
    nuovo = QgsGeometry.fromPolylineXY([q0, piede])
    nuovo.transform(a_m, QgsCoordinateTransform.ReverseTransform)
    return nuovo


def layer_quote_manuali(project, crs, nome, scala=None):
    """Quote disegnate a mano nel layer «Quote dalla rotaia» (una linea
    dall'elemento alla rotaia): in tavola con le frecce e la lunghezza
    orizzontale, al mezzo metro piu' vicino. None se non ce ne sono."""
    lyr = next(iter(project.mapLayersByName(NOME_QUOTE_MAN)), None)
    if lyr is None or not lyr.isValid() or lyr.featureCount() == 0:
        return None
    a = QgsCoordinateTransform(lyr.crs(), crs, project)
    quote = []
    for f in lyr.getFeatures():
        if not f.hasGeometry():
            continue
        g = QgsGeometry(f.geometry())
        # perpendicolare al binario e con la punta sulla rotaia, anche se
        # tirata a mano un po' storta
        g = quota_ortogonale(project, g, lyr.crs()) or g
        g.transform(a)
        pts = [QgsPointXY(v.x(), v.y()) for v in g.vertices()]
        if len(pts) < 2:
            continue
        d = ((pts[0].x() - pts[-1].x()) ** 2 + (pts[0].y() - pts[-1].y()) ** 2) ** 0.5
        if d > 0.05:
            da = pts[0]
            # la freccia tocca il bordo del simbolo dell'elemento, non il suo
            # centro: si accorcia di ~1,3 mm in carta dal lato dell'elemento
            # (primo clic). La misura resta quella vera.
            if scala:
                taglio = min(d * 0.4, 0.9 * scala / 1000.0)
                k = taglio / d
                da = QgsPointXY(pts[0].x() + (pts[-1].x() - pts[0].x()) * k,
                                pts[0].y() + (pts[-1].y() - pts[0].y()) * k)
            quote.append((da, pts[-1], d))
    return _layer_da_quote(project, quote, crs, nome) if quote else None


def _layer_da_quote(project, quote, crs, nome):
    """Layer delle quote [(da, a, metri)] con frecce sottili e la misura."""
    from qgis.core import (QgsArrowSymbolLayer, QgsFillSymbol, QgsLineSymbol,
                           QgsPalLayerSettings, QgsTextBufferSettings, QgsTextFormat,
                           QgsVectorLayerSimpleLabeling)
    vl = QgsVectorLayer("LineString?crs=%s" % crs.authid(), nome, "memory")
    vl.dataProvider().addAttributes([QgsField("metri", QVariant.Double),
                                     QgsField("testo", QVariant.String)])
    vl.updateFields()
    feats = []
    for da, a, d in quote:
        f = QgsFeature(vl.fields())
        f.setGeometry(QgsGeometry.fromPolylineXY([da, a]))
        # al mezzo metro piu' vicino (14,2 -> 14; 14,3 -> 14,5)
        d05 = math.floor(d * 2 + 0.5) / 2.0
        f["metri"] = d05
        f["testo"] = ("%.2f m" % d05).replace(".", ",")         # «15,00 m» come nelle tavole
        feats.append(f)
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    # quota come nelle tavole consegnate: linea rossa sottile tratteggiata con
    # una freccia piena a ciascuna estremita' (sulla rotaia e sull'elemento)
    sym = QgsLineSymbol.createSimple({"line_color": "190,30,30,255", "line_width": "0.15",
                                      "line_style": "dash"})
    try:
        from qgis.core import QgsMarkerLineSymbolLayer, QgsMarkerSymbol
        for pos, ang in (("firstvertex", "180"), ("lastvertex", "0")):
            ml = QgsMarkerLineSymbolLayer.create({"placement": pos, "rotate": "1"})
            ml.setSubSymbol(QgsMarkerSymbol.createSimple({
                "name": "filled_arrowhead", "color": "190,30,30,255",
                "outline_color": "190,30,30,255", "outline_width": "0.1",
                "size": "1.5", "angle": ang}))
            sym.appendSymbolLayer(ml)
    except Exception:  # noqa: BLE001
        pass
    vl.setRenderer(QgsSingleSymbolRenderer(sym))
    pal = QgsPalLayerSettings()
    pal.fieldName = "testo"
    # scritta parallela alla quota e accanto alla linea, mai sopra (prima era
    # orizzontale e centrata sulla linea)
    try:
        from qgis.core import Qgis
        pal.placement = Qgis.LabelPlacement.Line
    except Exception:  # noqa: BLE001
        pal.placement = QgsPalLayerSettings.Line
    try:
        from qgis.core import QgsLabeling
        pal.lineSettings().setPlacementFlags(QgsLabeling.LinePlacementFlag.AboveLine
                                             | QgsLabeling.LinePlacementFlag.BelowLine
                                             | QgsLabeling.LinePlacementFlag.MapOrientation)
    except Exception:  # noqa: BLE001
        pass
    pal.upsidedownLabels = QgsPalLayerSettings.Upright
    tf = QgsTextFormat()
    fnt = QFont("Arial", 6)
    tf.setFont(fnt)
    tf.setSize(4.5)          # 8, 6,5 e 5,5 pt erano troppo grossi (utente)
    tf.setColor(QColor(190, 30, 30))
    b = QgsTextBufferSettings()
    b.setEnabled(True)
    b.setSize(0.5)
    b.setColor(QColor(255, 255, 255))
    tf.setBuffer(b)
    pal.setFormat(tf)
    pal.dist = 0.5            # mm di distacco dalla linea
    pal.priority = 9
    # quote corte (pochi metri = pochi mm in tavola): la scritta puo' uscire
    # dalla linea, altrimenti QGIS non la disegnava
    try:
        pal.overrunDistance = 12
        pal.overrunDistanceUnit = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        pass
    try:
        from qgis.core import Qgis
        ps = pal.placementSettings()
        ps.setAllowDegradedPlacement(True)
        ps.setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapIfRequired)
        pal.setPlacementSettings(ps)
    except Exception:  # noqa: BLE001
        pass
    vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    vl.setLabelsEnabled(True)
    vl.setCustomProperty("rfi/nome_legenda", "Distanza dalla rotaia più vicina")
    vl.setCustomProperty("rfi/gruppo_legenda", "ferro")
    return _aggiungi_base(project, vl)


# --------------------------------------------------------------------------- #
#  Stile «delicato» comune alle tavole di tutte le istanze
# --------------------------------------------------------------------------- #
GRIGIO_FILO = QColor(110, 110, 110)


def formato_etichetta(colore=QColor(200, 0, 0), corpo=5.0):
    """Etichetta delle tavole, uguale in tutte le istanze: corpo piccolo, non
    grassetto, riquadro bianco con bordo grigio sottile (come le tavole di
    progetto consegnate)."""
    from qgis.PyQt.QtCore import QSizeF
    from qgis.core import QgsTextBackgroundSettings
    tf = QgsTextFormat()
    fnt = QFont("Arial", int(corpo))
    fnt.setBold(False)
    tf.setFont(fnt)
    tf.setSize(corpo)
    tf.setColor(colore)
    bg = QgsTextBackgroundSettings()
    bg.setEnabled(True)
    bg.setFillColor(QColor(255, 255, 255, 165))     # si intravede la mappa
    bg.setStrokeColor(QColor(90, 90, 90, 200))
    bg.setStrokeWidth(0.12)
    bg.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
    bg.setSize(QSizeF(0.8, 0.4))
    tf.setBackground(bg)
    return tf


def filo_etichetta():
    """Filo di richiamo sottile e grigio (il rosso pesava sulla tavola)."""
    from qgis.core import QgsLineSymbol, QgsSimpleLineCallout
    c = QgsSimpleLineCallout()
    c.setEnabled(True)
    c.setLineSymbol(QgsLineSymbol.createSimple({"line_color": "110,110,110,255",
                                                "line_width": "0.13"}))
    return c


def ostacoli_mm(geoms, centro, scala, w_mm, h_mm, passo=1.5, lato=1.4):
    """Riquadri in mm della tavola lungo linee e punti (quote, sezioni):
    le etichette non ci vanno sopra."""
    k = 1000.0 / scala
    out = []
    for g in geoms:
        if g is None or g.isEmpty():
            continue
        lung = g.length()
        if lung <= 0:
            pts = [QgsPointXY(v.x(), v.y()) for v in g.vertices()]
        else:
            n = max(2, int(lung * k / passo) + 1)
            pts = [g.interpolate(lung * j / (n - 1)).asPoint() for j in range(n)]
        for p in pts:
            x = (p.x() - centro.x()) * k + w_mm / 2.0
            y = h_mm / 2.0 - (p.y() - centro.y()) * k
            out.append((x - lato / 2, y - lato / 2, x + lato / 2, y + lato / 2))
    return out


SIMBOLO_ARMADIO = os.path.join(ASSETS, "simboli", "armadio_FO.svg")
LARG_ARMADIO_MM = 4.6                      # larghezza del simbolo FO in tavola


def armadio_fo(project, arm, pozz, infra, larghezza=LARG_ARMADIO_MM):
    """Armadio delle tavole altri enti: simbolo FO (assets/simboli), ruotato
    in modo che la base guardi lo scavo o il pozzetto da cui arriva la rete,
    e spostato perche' la base parta dal punto dell'armadio: il corpo va
    dalla parte opposta e non copre scavo ne' pozzetto. Lavora sulla copia
    dell'istanza (campo _rot_fo con l'angolo)."""
    import math as _m
    from qgis.core import (QgsMarkerSymbol, QgsProperty, QgsSvgMarkerSymbolLayer,
                           QgsSymbolLayer)
    if arm is None or not arm.isValid() or not os.path.isfile(SIMBOLO_ARMADIO):
        return False
    geo = arm.crs().isGeographic()

    def _pts(lyr, linee=False):
        out = []
        if lyr is None or not lyr.isValid():
            return out
        a = QgsCoordinateTransform(lyr.crs(), arm.crs(), project)
        for f in lyr.getFeatures():
            if f.hasGeometry():
                g = QgsGeometry(f.geometry())
                g.transform(a)
                out.append(g)
        return out
    pz, sc = _pts(pozz), _pts(infra)
    if arm.fields().indexOf("_rot_fo") < 0:
        arm.dataProvider().addAttributes([QgsField("_rot_fo", QVariant.Double)])
        arm.updateFields()
    k = arm.fields().indexOf("_rot_fo")
    soglia_pz = 8.0 / 111320.0 if geo else 8.0
    agg = {}
    for f in arm.getFeatures():
        if not f.hasGeometry():
            continue
        ga = f.geometry()
        a = ga.asPoint() if not ga.isMultipart() else ga.asMultiPoint()[0]
        gpa = QgsGeometry.fromPointXY(a)
        # orientamento: allineato allo scavo a cui l'armadio si aggancia
        # (il tratto finale arriva perpendicolare alla base); senza scavo
        # vicino, dal pozzetto vicino
        rif = None
        ang = None
        soglia_sc = 15.0 / 111320.0 if geo else 15.0
        if sc:
            gs = min(sc, key=lambda g: g.distance(gpa))
            if gs.distance(gpa) <= soglia_sc and gs.length() > 0:
                lung = gs.length()
                d0 = gs.lineLocatePoint(gs.nearestPoint(gpa))
                passo = min(lung / 2.0, (2.0 / 111320.0) if geo else 2.0)
                # verso: dal tratto dello scavo verso l'estremo piu' vicino
                if d0 >= lung / 2.0:
                    p1, p2 = gs.interpolate(max(0.0, d0 - passo)).asPoint(), \
                        gs.interpolate(d0).asPoint()
                else:
                    p1, p2 = gs.interpolate(min(lung, d0 + passo)).asPoint(), \
                        gs.interpolate(d0).asPoint()
                dx, dy = p2.x() - p1.x(), p2.y() - p1.y()
                if geo:
                    dx *= _m.cos(_m.radians(a.y()))
                if abs(dx) + abs(dy) > 0:
                    ang = (_m.degrees(_m.atan2(dx, dy)) + 360.0) % 360.0
        if ang is None:
            vicini = sorted(((g.distance(gpa), g) for g in pz), key=lambda x: x[0])
            if vicini and vicini[0][0] <= soglia_pz:
                rif = vicini[0][1].asPoint() if not vicini[0][1].isMultipart() \
                    else vicini[0][1].asMultiPoint()[0]
        if ang is not None:
            agg[f.id()] = {k: ang}
            continue
        ang = 0.0
        if rif is not None:
            dx, dy = a.x() - rif.x(), a.y() - rif.y()
            if geo:
                dx *= _m.cos(_m.radians(a.y()))
            if abs(dx) + abs(dy) < 1e-12 and sc:
                # armadio sopra la rete: perpendicolare allo scavo
                gs = min(sc, key=lambda g: g.distance(gpa))
                d0 = gs.lineLocatePoint(gpa)
                p1 = gs.interpolate(max(0.0, d0 - 1e-6 if geo else d0 - 0.5)).asPoint()
                p2 = gs.interpolate(d0 + (1e-6 if geo else 0.5)).asPoint()
                dx, dy = -(p2.y() - p1.y()), (p2.x() - p1.x())
            ang = (_m.degrees(_m.atan2(dx, dy)) + 360.0) % 360.0
        agg[f.id()] = {k: ang}
    if agg:
        arm.dataProvider().changeAttributeValues(agg)
    svg = QgsSvgMarkerSymbolLayer(SIMBOLO_ARMADIO, larghezza, 0)
    alto = larghezza * 143.0 / 202.0            # proporzioni del disegno
    from qgis.PyQt.QtCore import QPointF
    # base staccata dal punto; l'offset vale solo sugli elementi (campo
    # presente): in legenda il simbolo resta centrato
    svg.setDataDefinedProperty(QgsSymbolLayer.PropertyOffset, QgsProperty.fromExpression(
        "CASE WHEN \"_rot_fo\" IS NOT NULL THEN '0,%s' ELSE '0,0' END"
        % ("%.2f" % -(alto / 2.0 + 0.9))))
    svg.setDataDefinedProperty(QgsSymbolLayer.PropertyAngle, QgsProperty.fromField("_rot_fo"))
    sym = QgsMarkerSymbol()
    sym.changeSymbolLayer(0, svg)
    try:
        r = QgsSingleSymbolRenderer(sym)
        r.setReferenceScale(-1)
    except Exception:  # noqa: BLE001
        r = QgsSingleSymbolRenderer(sym)
    arm.setRenderer(r)
    arm.setCustomProperty("rfi/nome_legenda", "Armadio ottico")
    arm.triggerRepaint()
    return True


def armadi_discreti(project, arm, pozz, scala, prefisso, vicino_m=3.0):
    """Armadi in tavola: simbolo semitrasparente (sotto si vede il pozzetto) e,
    se un pozzetto e' a meno di `vicino_m`, armadio spostato di lato di 4 mm
    in carta con un filo che lo lega al suo punto. Ritorna il layer dei fili
    (o None). Lavora sulla copia dell'istanza, mai sul layer del progetto."""
    if arm is None or not arm.isValid():
        return None
    for s in _simboli(arm):
        try:
            s.setOpacity(0.7)
        except Exception:  # noqa: BLE001
            pass
    if pozz is None or not pozz.isValid():
        return None
    a_p = QgsCoordinateTransform(pozz.crs(), arm.crs(), project)
    pz = []
    for f in pozz.getFeatures():
        if f.hasGeometry():
            g = QgsGeometry(f.geometry())
            g.transform(a_p)
            pz.append(g.asPoint() if not g.isMultipart() else g.asMultiPoint()[0])
    if not pz:
        return None
    # distanze in metri: CRS metrico del layer (il progetto e' in metri)
    metrico = not arm.crs().isGeographic()
    fatt = 1.0 if metrico else 1.0 / 111320.0
    sposta = 4.0 * scala / 1000.0 * fatt          # 4 mm in carta
    soglia = vicino_m * fatt
    fili, nuove = [], {}
    for f in arm.getFeatures():
        if not f.hasGeometry():
            continue
        g = f.geometry()
        p = g.asPoint() if not g.isMultipart() else g.asMultiPoint()[0]
        vic = [q for q in pz if ((q.x() - p.x()) ** 2 + (q.y() - p.y()) ** 2) ** 0.5 < soglia]
        if not vic:
            continue
        q = vic[0]
        dx, dy = p.x() - q.x(), p.y() - q.y()
        n = (dx * dx + dy * dy) ** 0.5
        if n < 1e-9:
            dx, dy, n = 0.0, 1.0, 1.0
        nuovo = QgsPointXY(p.x() + dx / n * sposta, p.y() + dy / n * sposta)
        nuove[f.id()] = QgsGeometry.fromPointXY(nuovo)
        fili.append(QgsGeometry.fromPolylineXY([QgsPointXY(p.x(), p.y()), nuovo]))
    if not nuove:
        return None
    arm.dataProvider().changeGeometryValues(nuove)
    arm.updateExtents()
    vl = QgsVectorLayer("LineString?crs=%s" % arm.crs().authid(),
                        "%s - richiami armadi" % prefisso, "memory")
    vl.dataProvider().addFeatures([QgsFeature() for _ in fili])
    feats = []
    for g in fili:
        f = QgsFeature()
        f.setGeometry(g)
        feats.append(f)
    vl.dataProvider().truncate()
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    from qgis.core import QgsLineSymbol
    vl.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
        {"line_color": "110,110,110,255", "line_width": "0.13"})))
    return _aggiungi_base(project, vl)


# km in nero, lavorazioni in rosso (come le tavole consegnate): testo HTML
ESPR_ETICHETTA_HTML = (
    "CASE WHEN left(\"testo\", 3) = 'KM ' THEN "
    "'<span style=\"color:#000000\">' || regexp_substr(\"testo\", '^[^\\n]*') || '</span>' || "
    "replace(substr(\"testo\", length(regexp_substr(\"testo\", '^[^\\n]*')) + 1), '\\n', '<br>') "
    "ELSE replace(\"testo\", '\\n', '<br>') END")


def testo_html(testo):
    """Testo dell'etichetta in HTML, riga per riga: il km in nero, le
    lavorazioni in rosso."""
    righe = []
    for r in (testo or "").split("\n"):
        esc = r.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        col = "#000000" if r.strip().upper().startswith("KM ") else "#c80000"
        # una <div> per riga: in QGIS il <br> nelle etichette non va a capo
        righe.append('<div><span style="color:%s">%s</span></div>' % (col, esc))
    return "".join(righe)


def etichetta_km_nero(pal):
    """Etichetta dal campo «html» (testo_html): km in nero, resto in rosso."""
    tf = pal.format()
    try:
        tf.setAllowHtmlFormatting(True)
    except Exception:  # noqa: BLE001
        return pal
    pal.isExpression = False
    pal.fieldName = "html"
    pal.setFormat(tf)
    return pal


def stile_sezione_tavola(lyr):
    """Sezione in tavola come nelle tavole consegnate: niente linea, solo due
    segni blu sottili alle estremita' (perpendicolari alla sezione) e la
    lettera piccola (B ... B')."""
    from qgis.core import (QgsLineSymbol, QgsMarkerLineSymbolLayer, QgsMarkerSymbol,
                           QgsPalLayerSettings, QgsRuleBasedLabeling, QgsTextBufferSettings,
                           QgsTextFormat)
    blu = "30,60,130,255"
    # traccia di sezione leggera (come nei disegni CAD): linea sottile a tratto
    # e punto, tratto finale sottile a ciascun capo, triangolino pieno vicino
    # ai capi che guarda nel verso della vista (perpendicolare, uguale ai due
    # capi), lettera fuori
    from qgis.core import QgsGeometryGeneratorSymbolLayer
    sym = QgsLineSymbol.createSimple({"line_color": blu, "line_width": "0.1",
                                      "line_style": "dash dot"})
    fatt = (1.0 / 111320.0) if lyr.crs().isGeographic() else 1.0
    capo = "(%f * @map_scale / 1000)" % (2.0 * fatt)          # 2 mm in carta
    sottile = lambda: QgsLineSymbol.createSimple({"line_color": blu, "line_width": "0.35"})  # noqa: E731
    for espr in ("line_substring($geometry, 0, min(%s, length($geometry) / 3))" % capo,
                 "line_substring($geometry, max(length($geometry) - %s, length($geometry) * 2 / 3), "
                 "length($geometry))" % capo):
        gg = QgsGeometryGeneratorSymbolLayer.create({"geometryModifier": espr})
        try:
            from qgis.core import Qgis
            gg.setSymbolType(Qgis.SymbolType.Line)
        except Exception:  # noqa: BLE001
            from qgis.core import QgsSymbol
            gg.setSymbolType(QgsSymbol.Line)
        gg.setSubSymbol(sottile())
        sym.appendSymbolLayer(gg)
    # triangolino: marker sulla linea ruotato con la linea; a 0° punta
    # perpendicolare (provato), spostato di lato e verso l'interno
    # sull'ultimo vertice QGIS gira il simbolo di 180°: si compensa, cosi' i
    # due triangoli stanno dalla stessa parte e guardano nello stesso verso
    for pos, ang in (("firstvertex", "0"), ("lastvertex", "180")):
        ml = QgsMarkerLineSymbolLayer.create({"placement": pos, "rotate": "1"})
        try:
            ml.setOffsetAlongLine(1.2)
            ml.setOffsetAlongLineUnit(QgsUnitTypes.RenderMillimeters)
        except Exception:  # noqa: BLE001
            pass
        ml.setSubSymbol(QgsMarkerSymbol.createSimple({
            "name": "triangle", "color": blu, "outline_color": blu, "outline_width": "0",
            "size": "1.4", "angle": ang, "offset": "0,-0.9"}))
        sym.appendSymbolLayer(ml)
    lyr.setRenderer(QgsSingleSymbolRenderer(sym))
    try:
        lyr.renderer().setReferenceScale(-1)
    except Exception:  # noqa: BLE001
        pass
    nomi = {f.name().lower(): f.name() for f in lyr.fields()}
    c_s = nomi.get("sezione")
    if not c_s:
        lyr.setLabelsEnabled(False)
        return
    c_f = nomi.get("sezione_f")
    apice = "''''"
    if c_f:
        fine = "coalesce(nullif(\"%s\", ''), \"%s\" || %s)" % (c_f, c_s, apice)
    else:
        fine = "\"%s\" || %s" % (c_s, apice)
    radice = QgsRuleBasedLabeling.Rule(None)
    for testo, geo in (("\"%s\"" % c_s, "start_point($geometry)"), (fine, "end_point($geometry)")):
        pal = QgsPalLayerSettings()
        pal.isExpression = True
        pal.fieldName = testo
        pal.geometryGeneratorEnabled = True
        pal.geometryGenerator = geo
        try:
            from qgis.core import Qgis
            pal.geometryGeneratorType = Qgis.GeometryType.Point
            pal.placement = Qgis.LabelPlacement.AroundPoint
        except Exception:  # noqa: BLE001
            pass
        pal.dist = 1.2
        tf = QgsTextFormat()
        _fl = QFont("Arial", 7)
        _fl.setBold(False)
        tf.setFont(_fl)
        tf.setSize(7)
        tf.setColor(QColor(30, 60, 130))
        b = QgsTextBufferSettings()
        b.setEnabled(True)
        b.setSize(0.6)
        tf.setBuffer(b)
        pal.setFormat(tf)
        pal.priority = 9
        radice.appendChild(QgsRuleBasedLabeling.Rule(pal))
    lyr.setLabeling(QgsRuleBasedLabeling(radice))
    lyr.setLabelsEnabled(True)


# --------------------------------------------------------------------------- #
#  Elementi del layout
# --------------------------------------------------------------------------- #
def _mv(it, x, y, w, h, pagina):
    it.attemptMove(QgsLayoutPoint(x, y, MM), True, False, pagina)
    it.attemptResize(QgsLayoutSize(w, h, MM))


def _lbl(layout, pagina, x, y, w, h, testo, size=8, bold=False, align=Qt.AlignHCenter,
         valign=Qt.AlignVCenter, frame=False, colore=None):
    it = QgsLayoutItemLabel(layout)
    it.setText(testo)
    f = QFont("Arial")
    f.setPointSizeF(float(size))
    f.setBold(bold)
    it.setFont(f)
    if colore is not None:
        it.setFontColor(colore)
    it.setHAlign(align)
    it.setVAlign(valign)
    it.setMarginX(1.0)
    it.setMarginY(0.6)
    layout.addLayoutItem(it)
    _mv(it, x, y, w, h, pagina)
    it.setFrameEnabled(frame)
    if frame:
        it.setFrameStrokeWidth(QgsLayoutMeasurement(0.25, MM))
    return it


def _box(layout, pagina, x, y, w, h, spessore=0.3, colore=QColor(0, 0, 0)):
    sh = QgsLayoutItemShape(layout)
    sh.setShapeType(QgsLayoutItemShape.Rectangle)
    layout.addLayoutItem(sh)
    _mv(sh, x, y, w, h, pagina)
    try:
        sym = sh.symbol()
        sym.setColor(QColor(255, 255, 255, 0))
        sl = sym.symbolLayer(0)
        sl.setStrokeColor(colore)
        sl.setStrokeWidth(spessore)
    except Exception:  # noqa: BLE001
        pass
    return sh


def _cerchio(layout, pagina, x, y, d):
    sh = QgsLayoutItemShape(layout)
    sh.setShapeType(QgsLayoutItemShape.Ellipse)
    layout.addLayoutItem(sh)
    _mv(sh, x, y, d, d, pagina)
    try:
        sym = sh.symbol()
        sym.setColor(QColor(255, 70, 70, 150))
        sym.symbolLayer(0).setStrokeColor(QColor(230, 60, 60, 200))
    except Exception:  # noqa: BLE001
        pass


def _immagine(layout, pagina, x, y, w, h, path):
    pic = QgsLayoutItemPicture(layout)
    pic.setPicturePath(path)
    pic.setResizeMode(QgsLayoutItemPicture.Zoom)
    layout.addLayoutItem(pic)
    _mv(pic, x, y, w, h, pagina)
    return pic


SCALE_TAVOLE = (500, 1000, 2000, 5000)


SCALA_TAVOLE_RFI = 1000      # tavole di dettaglio delle istanze ferrovie (utente)


def scala_tavole():
    """Scala UNICA delle tavole RFI (ortofoto, planimetria e catasto, uguale in
    tutte le tavole): 1:1000, o quella scelta nelle Avanzate della scheda."""
    try:
        from qgis.core import QgsSettings
        s = int(QgsSettings().value("ftth_permessi/rfi_scala_tavole", 0) or 0)
    except Exception:  # noqa: BLE001
        s = 0
    return s if s in SCALE_TAVOLE else SCALA_TAVOLE_RFI    # 0 = «automatica» = 1:1000


# scale che il plugin può scegliere da solo per le tavole RFI (utente): la
# più grande in cui il contenuto della tavola entra
SCALE_AUTO_RFI = (500, 1000, 2000)


def scala_fissa_rfi():
    """Scala scelta al passo 5 (tutte le tavole uguali), 0 = automatica."""
    try:
        from qgis.core import QgsSettings
        s = int(QgsSettings().value("ftth_permessi/rfi_scala_tavole", 0) or 0)
    except Exception:  # noqa: BLE001
        s = 0
    return s if s in SCALE_AUTO_RFI else 0


# margine dentro la tavola per etichette e quote (mm sulla carta)
MARGINE_TAVOLA_MM = 6.0      # piccolo: meno tavole possibile (utente)


def finestra_tavola_m(scala):
    """Larghezza e altezza in metri del riquadro di una tavola (ortofoto,
    planimetria e catasto hanno la stessa finestra) alla scala data."""
    area_w = PAGINA[0] - 2 * MARGINE - CART_W - 4
    area_h = PAGINA[1] - 2 * MARGINE
    col_w = (area_w - 6) / 2.0
    riga_h = (area_h - 2 * 6.0 - 6) / 2.0
    return col_w * scala / 1000.0, riga_h * scala / 1000.0


def dividi_in_tavole(voci, w, h, margine=0.0):
    """Divide le interferenze nel minor numero di tavole w x h metri (senza
    badare alle sovrapposizioni: per le tavole RFI c'è tavole_con_scala).
    voci = [(chiave, (xmin, ymin, xmax, ymax))] in metri. Un'interferenza più
    grande della tavola si spezza. Ritorna [((xmin, ymin, xmax, ymax), [chiavi])]."""
    import math
    W, H = max(1.0, w - 2 * margine), max(1.0, h - 2 * margine)
    pezzi = []
    for k, (x0, y0, x1, y1) in voci:
        nx = max(1, int(math.ceil((x1 - x0) / W - 1e-9)))
        ny = max(1, int(math.ceil((y1 - y0) / H - 1e-9)))
        dx, dy = (x1 - x0) / nx, (y1 - y0) / ny
        for a in range(nx):
            for b in range(ny):
                pezzi.append((k, (x0 + a * dx, y0 + b * dy, x0 + (a + 1) * dx,
                                  y0 + (b + 1) * dy)))
    if not pezzi:
        return []
    cx = [(r[0] + r[2]) / 2.0 for _k, r in pezzi]
    cy = [(r[1] + r[3]) / 2.0 for _k, r in pezzi]
    mx, my = sum(cx) / len(cx), sum(cy) / len(cy)
    sxx = sum((x - mx) ** 2 for x in cx)
    syy = sum((y - my) ** 2 for y in cy)
    sxy = sum((x - mx) * (y - my) for x, y in zip(cx, cy))
    ang = 0.5 * math.atan2(2 * sxy, sxx - syy)
    ux, uy = math.cos(ang), math.sin(ang)
    ordine = sorted(range(len(pezzi)), key=lambda i: (cx[i] - mx) * ux + (cy[i] - my) * uy)

    def _unione(a, b):
        return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))

    def _entra(r):
        return r[2] - r[0] <= W + 1e-6 and r[3] - r[1] <= H + 1e-6

    tavole = []
    for i in ordine:
        k, r = pezzi[i]
        for t in tavole:
            u = _unione(t[0], r)
            if _entra(u):
                t[0] = u
                if k not in t[1]:
                    t[1].append(k)
                break
        else:
            tavole.append([r, [k]])
    return [(tuple(t[0]), t[1]) for t in tavole]


def tavole_con_scala(voci, scale=SCALE_AUTO_RFI, margine_mm=MARGINE_TAVOLA_MM):
    """Tavole RFI senza sovrapposizioni e nel minor numero possibile: si
    provano due modi (colonne in fila, e gruppi di interferenze vicine con il
    riquadro spostato dove non tocca gli altri) e si tiene quello con meno
    tavole (a parità, quello con le scale più grandi = più dettaglio).
    voci = [(chiave, (xmin, ymin, xmax, ymax))] in metri.
    Ritorna [((xmin, ymin, xmax, ymax) del riquadro, scala, [chiavi])]."""
    if not voci:
        return []
    candidati = [_tavole_sweep(voci, scale, margine_mm)]
    for criterio in ("area", "distanza", "lato"):
        try:
            g = _tavole_gruppi(voci, scale, margine_mm, criterio)
        except Exception:  # noqa: BLE001
            g = None
        if g:
            candidati.append(g)
    return min(candidati, key=lambda t: (len(t), sum(s for _r, s, _k in t)))


def _tavole_gruppi(voci, scale, margine_mm, criterio="area"):
    """Interferenze unite a gruppi finché il gruppo entra in una tavola a
    1:2000 (si unisce prima la coppia che `criterio` dice più vicina); ogni
    gruppo prende la scala più grande in cui entra e il suo riquadro si sposta
    (il contenuto resta dentro) finché non tocca più gli altri riquadri.
    None se i riquadri non si riescono a separare."""
    import math
    scale = sorted(scale)
    fin = {}
    for s in scale:
        w, h = finestra_tavola_m(s)
        fin[s] = (w, h, margine_mm * s / 1000.0)
    W, H, M = fin[scale[-1]]
    cw, ch = W - 2 * M, H - 2 * M
    # pezzi: un'interferenza più grande della tavola si spezza
    pezzi = []
    for k, (x0, y0, x1, y1) in voci:
        nx = max(1, int(math.ceil((x1 - x0) / cw - 1e-9)))
        ny = max(1, int(math.ceil((y1 - y0) / ch - 1e-9)))
        dx, dy = (x1 - x0) / nx, (y1 - y0) / ny
        for a in range(nx):
            for b in range(ny):
                pezzi.append((k, (x0 + a * dx, y0 + b * dy, x0 + (a + 1) * dx,
                                  y0 + (b + 1) * dy)))
    gruppi = [[b, [n]] for n, (_k, b) in enumerate(pezzi)]

    def _u(a, b):
        return (min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]))

    def _entra(r):
        return r[2] - r[0] <= cw + 1e-6 and r[3] - r[1] <= ch + 1e-6

    def _costo(a, b):
        u = _u(a, b)
        if criterio == "distanza":
            return math.hypot((a[0] + a[2] - b[0] - b[2]) / 2.0, (a[1] + a[3] - b[1] - b[3]) / 2.0)
        if criterio == "lato":
            return max((u[2] - u[0]) / cw, (u[3] - u[1]) / ch)
        return (u[2] - u[0]) * (u[3] - u[1]) - (a[2] - a[0]) * (a[3] - a[1]) - \
            (b[2] - b[0]) * (b[3] - b[1])

    while True:
        best = None
        for i in range(len(gruppi)):
            for j in range(i + 1, len(gruppi)):
                if not _entra(_u(gruppi[i][0], gruppi[j][0])):
                    continue
                c = _costo(gruppi[i][0], gruppi[j][0])
                if best is None or c < best[0]:
                    best = (c, i, j)
        if best is None:
            break
        _c, i, j = best
        gruppi[i] = [_u(gruppi[i][0], gruppi[j][0]), gruppi[i][1] + gruppi[j][1]]
        del gruppi[j]

    def _bbox(idx):
        r = pezzi[idx[0]][1]
        for n_ in idx[1:]:
            r = _u(r, pezzi[n_][1])
        return r

    # si prova a sciogliere un gruppo nei vicini (ogni suo pezzo va in un
    # altro gruppo dove ci sta ancora): una tavola in meno
    migliorato = True
    while migliorato and len(gruppi) > 1:
        migliorato = False
        for g in sorted(range(len(gruppi)), key=lambda i: len(gruppi[i][1])):
            altri = {i: list(gruppi[i][1]) for i in range(len(gruppi)) if i != g}
            ok = True
            for n_ in sorted(gruppi[g][1], key=lambda n_: -(pezzi[n_][1][2] - pezzi[n_][1][0])
                             * (pezzi[n_][1][3] - pezzi[n_][1][1])):
                dove = [(i, _bbox(idx + [n_])) for i, idx in altri.items()]
                dove = [(i, r) for i, r in dove if _entra(r)]
                if not dove:
                    ok = False
                    break
                i_, _r = min(dove, key=lambda t: (t[1][2] - t[1][0]) * (t[1][3] - t[1][1]))
                altri[i_].append(n_)
            if ok:
                gruppi = [[_bbox(idx), idx] for idx in altri.values()]
                migliorato = True
                break
    gruppi = [[b, list(dict.fromkeys(pezzi[n_][0] for n_ in idx))] for b, idx in gruppi]

    # riquadri: scala più grande in cui il gruppo entra, centrato; poi si
    # spostano (senza far uscire il contenuto) finché non si toccano più
    pos, rng, dim, sc = [], [], [], []
    for cb, _k in gruppi:
        for s in scale:
            w, h, m = fin[s]
            if cb[2] - cb[0] <= w - 2 * m + 1e-6 and cb[3] - cb[1] <= h - 2 * m + 1e-6:
                break
        lo_x, hi_x = cb[2] + m - w, cb[0] - m
        lo_y, hi_y = cb[3] + m - h, cb[1] - m
        pos.append([(lo_x + hi_x) / 2.0, (lo_y + hi_y) / 2.0])
        rng.append(((lo_x, hi_x), (lo_y, hi_y)))
        dim.append((w, h))
        sc.append(s)
    n = len(gruppi)
    eps = 1e-3
    for _giro in range(400):
        tocca = False
        for a in range(n):
            for b in range(a + 1, n):
                ox = min(pos[a][0] + dim[a][0], pos[b][0] + dim[b][0]) - max(pos[a][0], pos[b][0])
                oy = min(pos[a][1] + dim[a][1], pos[b][1] + dim[b][1]) - max(pos[a][1], pos[b][1])
                if ox <= eps or oy <= eps:
                    continue
                tocca = True
                mosso = False
                for d_, ax in sorted(((ox, 0), (oy, 1))):
                    ca = pos[a][ax] + dim[a][ax] / 2.0
                    cb_ = pos[b][ax] + dim[b][ax] / 2.0
                    for basso, alto in ((a, b),) if ca <= cb_ else ((b, a),):
                        d = d_ + 2 * eps
                        giu = pos[basso][ax] - rng[basso][ax][0]
                        su = rng[alto][ax][1] - pos[alto][ax]
                        if giu + su < d - 1e-9:
                            continue
                        mg = min(giu, d / 2.0)
                        ms = d - mg
                        if ms > su:
                            ms = su
                            mg = d - ms
                        pos[basso][ax] -= mg
                        pos[alto][ax] += ms
                        mosso = True
                        break
                    if mosso:
                        break
                if not mosso:
                    return None
        if not tocca:
            return [((p[0], p[1], p[0] + d[0], p[1] + d[1]), s, g[1])
                    for p, d, s, g in zip(pos, dim, sc, gruppi)]
    return None


def _tavole_sweep(voci, scale=SCALE_AUTO_RFI, margine_mm=MARGINE_TAVOLA_MM):
    """Tavole RFI senza sovrapposizioni, a colonne.
    Si scorre lungo la direzione in cui le interferenze sono più distese:
    colonne larghe quanto la tavola a 1:2000, una dopo l'altra (si toccano, non
    si sovrappongono); in ogni colonna fasce alte quanto la tavola, una sopra
    l'altra. Un'interferenza che attraversa il bordo sta nelle due tavole.
    Poi ogni tavola prende la scala più grande in cui il suo contenuto entra
    (1:500, 1:1000, 1:2000): il riquadro più piccolo resta dentro il suo spazio.
    voci = [(chiave, (xmin, ymin, xmax, ymax))] in metri.
    Ritorna [((xmin, ymin, xmax, ymax) del riquadro, scala, [chiavi])]."""
    scale = sorted(scale)
    s_max = scale[-1]

    def _fin(s):
        w, h = finestra_tavola_m(s)
        return w, h, margine_mm * s / 1000.0

    if not voci:
        return []
    W, H, M = _fin(s_max)
    xs = [b[0] for _k, b in voci] + [b[2] for _k, b in voci]
    ys = [b[1] for _k, b in voci] + [b[3] for _k, b in voci]
    # lungo y se le interferenze sono più distese in altezza: si ragiona con
    # x e y scambiati e alla fine si rimettono a posto
    gira = (max(ys) - min(ys)) > (max(xs) - min(xs))
    if gira:
        voci = [(k, (b[1], b[0], b[3], b[2])) for k, b in voci]
        W, H = H, W
    out = []
    rest = sorted(voci, key=lambda v: v[1][0])
    cursore = None
    inf = float("inf")
    def _colonna(x0, x1, libero_x, items):
        """Tavole di una colonna [x0, x1]; None se un riquadro non entra nello
        spazio libero (colonna accorciata troppo)."""
        tav_c = []
        per_y = sorted(items, key=lambda v: v[1][1])
        cur_y = None
        resto_y = list(per_y)
        while resto_y:
            y0 = resto_y[0][1][1] - M
            if cur_y is not None:
                y0 = max(y0, cur_y)
            y1 = y0 + H
            dentro = [(k, b) for k, b in resto_y if b[1] < y1 - 1e-6]
            libero_y = (cur_y if cur_y is not None else -inf, y1)
            r = (x0, y0, x1, y1)
            cb = None
            for _k, b in dentro:
                c = (max(b[0], r[0]), max(b[1], r[1]), min(b[2], r[2]), min(b[3], r[3]))
                cb = c if cb is None else (min(cb[0], c[0]), min(cb[1], c[1]),
                                           max(cb[2], c[2]), max(cb[3], c[3]))
            scelto = None
            for s in scale:
                w, h, m = _fin(s)
                if gira:
                    w, h = h, w
                if cb[2] - cb[0] > w - 2 * m + 1e-6 or cb[3] - cb[1] > h - 2 * m + 1e-6:
                    continue
                if libero_x[1] - libero_x[0] < w - 1e-6 or libero_y[1] - libero_y[0] < h - 1e-6:
                    continue
                # riquadro centrato sul contenuto, dentro lo spazio libero
                # (fra la tavola precedente e la successiva)
                cx = min(max((cb[0] + cb[2]) / 2.0, libero_x[0] + w / 2.0), libero_x[1] - w / 2.0)
                cy = min(max((cb[1] + cb[3]) / 2.0, libero_y[0] + h / 2.0), libero_y[1] - h / 2.0)
                rr = (cx - w / 2.0, cy - h / 2.0, cx + w / 2.0, cy + h / 2.0)
                if rr[0] <= cb[0] + 1e-6 and rr[1] <= cb[1] + 1e-6 and \
                        rr[2] >= cb[2] - 1e-6 and rr[3] >= cb[3] - 1e-6:
                    scelto = (rr, s)
                    break
            if scelto is None:
                if x1 - x0 < W - 1e-6:
                    return None
                scelto = ((x0, y0, x1, y1), s_max)
            tav_c.append((scelto[0], scelto[1], list(dict.fromkeys(k for k, _b in dentro))))
            cur_y = y1
            # chi sporge sopra la fascia continua nella successiva
            resto_y = [(k, b) for k, b in resto_y if b[3] > y1 + 1e-6 or b[1] >= y1 - 1e-6]
        return tav_c

    fine_finestre = -inf
    while rest:
        x0 = rest[0][1][0] - M
        if cursore is not None:
            x0 = max(x0, cursore)
        x1 = x0 + W
        # spazio libero a sinistra: fin dove arrivano davvero i riquadri già fatti
        libero_sx = fine_finestre
        fatto = None
        # un'interferenza che entrerebbe intera in una tavola ma attraversa il
        # bordo della colonna: si chiude la colonna prima di lei, così sta
        # intera nella successiva (se le tavole di questa colonna ci stanno)
        a_cavallo = [b for _k, b in rest if b[0] < x1 - 1e-6 and b[2] > x1 + 1e-6 and
                     b[2] - b[0] <= W - 2 * M + 1e-6]
        if a_cavallo:
            x1c = min(b[0] for b in a_cavallo) - M
            prima = [(k, b) for k, b in rest if b[0] < x1c - 1e-6]
            if x1c > x0 + 1e-6 and prima:
                c_ = _colonna(x0, x1c, (libero_sx, x1c), prima)
                if c_ is not None:
                    fatto, x1 = c_, x1c
        if fatto is None:
            fatto = _colonna(x0, x1, (libero_sx, x1),
                             [(k, b) for k, b in rest if b[0] < x1 - 1e-6])
        out.extend(fatto)
        fine_finestre = max([fine_finestre] + [rr[2] for rr, _s, _k in fatto])
        cursore = x1
        # chi sporge oltre la colonna continua nella successiva
        rest = [(k, b) for k, b in rest if b[2] > x1 + 1e-6 or b[0] >= x1 - 1e-6]
        rest.sort(key=lambda v: max(v[1][0], x1))
    if gira:
        out = [((r[1], r[0], r[3], r[2]), s, k) for r, s, k in out]
    return out


def tavole_rfi(project, ist, crs, scala, sez_l, sezioni, avvisa, punto):
    """Tavole della PL RFI: [(interferenze, riquadro, [sezione], True)]. Una
    tavola per ogni riquadro di tavole_istanza; la sezione è quella disegnata
    dentro il riquadro (una per tavola). Una sezione in più nello stesso
    riquadro o fuori dai riquadri ha una tavola sua, centrata su di lei."""
    divise = tavole_istanza(project, ist, None, crs, mappa=True, avvisa=avvisa)
    w, h = finestra_tavola_m(SCALA_TAVOLE_RFI)
    assegnate = [None] * len(divise)
    in_piu = []
    if sez_l is not None and sezioni:
        a_crs = QgsCoordinateTransform(sez_l.crs(), crs, project)
        for f in ordina_sezioni(sez_l, sezioni):
            g_ = QgsGeometry(f.geometry())
            g_.transform(a_crs)
            c = g_.centroid().asPoint()
            dentro = [k for k, (r, _g, _s) in enumerate(divise) if r.contains(c)]
            dentro.sort(key=lambda k: divise[k][0].center().sqrDist(c))
            libera = next((k for k in dentro if assegnate[k] is None), None)
            if libera is not None:
                assegnate[libera] = f
            else:
                in_piu.append((f, c))
    out = []
    for k, (r, grp, s_k) in enumerate(divise):
        rr = QgsRectangle(r)
        rr.scale(0.98)      # sta nella tavola alla sua scala
        out.append((grp, rr, [assegnate[k]] if assegnate[k] is not None else [], True, s_k))
        if assegnate[k] is None:
            avvisa("tavola %d senza sezione: disegnane una dentro il suo riquadro (passo 5, "
                   "«Calcola numero di tavole»)" % (k + 1))
    for f, c in in_piu:
        rr = QgsRectangle(c.x() - w * 0.49, c.y() - h * 0.49, c.x() + w * 0.49, c.y() + h * 0.49)
        grp = [i for i in ist.interferenze if rr.contains(punto(i))] or [
            min(ist.interferenze, key=lambda i: punto(i).sqrDist(c))]
        out.append((grp, rr, [f], True, SCALA_TAVOLE_RFI))
        avvisa("sezione %s in più (un'altra sezione è già nella stessa tavola, o è fuori dai "
               "riquadri): tavola aggiunta" % (sigla_sezione(sez_l, f) or "?"))
    return out


def tavole_istanza(project, ist, scala=None, crs=None, mappa=False, avvisa=None):
    """Tavole di dettaglio di un'istanza RFI: [(QgsRectangle finestra,
    [interferenze], scala)] nel CRS metrico delle tavole (lo stesso di
    genera_pl_istanza), senza sovrapposizioni. Scala: quella data, o quella
    fissa delle Avanzate, o (automatica) 1:500 / 1:1000 / 1:2000 per tavola
    secondo quanto c'è da inquadrare. La stessa divisione serve a «Calcola
    numero di tavole» e alla stampa."""
    scala = scala or scala_fissa_rfi()
    scale = (scala,) if scala else SCALE_AUTO_RFI
    if crs is None:
        lon0 = sum(i.lon for i in ist.interferenze) / len(ist.interferenze)
        crs = _crs_metrico(project, lon0)
    tr = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"), crs, project)
    if mappa:
        # riquadri lasciati in mappa da «Calcola numero di tavole»: cancellato
        # = tavola in meno, spostato = tavola spostata
        try:
            from . import ftth_tavole_mappa as TM
        except ImportError:
            import ftth_tavole_mappa as TM
        da_mappa = TM.leggi(project, "rfi", ist.nome_base, crs)
        if da_mappa:
            fin = []
            for _n, s, c in da_mappa:
                s = s or (scala or 1000)
                fin.append((TM.finestra(c, *finestra_tavola_m(s)), s))
            gruppi, fuori = TM.dividi(ist.interferenze, [f for f, _s in fin],
                                      lambda i: tr.transform(QgsPointXY(i.lon, i.lat)))
            out = [(f, g, s) for g, (f, s) in zip(gruppi, fin) if g]
            if avvisa:
                avvisa("tavole dai riquadri in mappa (%s): %d" % (TM.nome_layer("rfi"), len(out)))
                if fuori:
                    avvisa("ATTENZIONE: %d interferenze fuori da tutti i riquadri in mappa: non "
                           "sono in nessuna tavola (ricalcola le tavole al passo 5)" % len(fuori))
            if out:
                return out
    voci = []
    per_id = {}
    for n, i in enumerate(ist.interferenze):
        if i.bbox:
            g_ = QgsGeometry.fromRect(QgsRectangle(*i.bbox))
        else:
            g_ = QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
        g_.transform(tr)
        b = g_.boundingBox()
        b.grow(5)          # un po' d'aria intorno a scavi e pozzetti
        voci.append((n, (b.xMinimum(), b.yMinimum(), b.xMaximum(), b.yMaximum())))
        per_id[n] = i
    out = []
    for (x0, y0, x1, y1), s, chiavi in tavole_con_scala(voci, scale):
        out.append((QgsRectangle(x0, y0, x1, y1), [per_id[k] for k in chiavi], s))
    # tavole numerate da sinistra a destra (utente)
    out.sort(key=lambda t: (t[0].center().x(), -t[0].center().y()))
    return out


def _scala_che_contiene(rect, w_mm, h_mm, minima=1000):
    """Scala piu' piccola dell'elenco che fa stare `rect` (metri) nel riquadro."""
    for s in SCALE:
        if s < minima:
            continue
        if rect.width() <= w_mm * s / 1000.0 and rect.height() <= h_mm * s / 1000.0:
            return s
    return SCALE[-1]


def _mappa(layout, pagina, x, y, w, h, crs, layers, centro, scala):
    m = QgsLayoutItemMap(layout)
    m.setCrs(crs)
    layout.addLayoutItem(m)
    _mv(m, x, y, w, h, pagina)
    m.setLayers([l for l in layers if l is not None])
    m.setKeepLayerSet(True)
    dx = w * scala / 1000.0 / 2.0
    dy = h * scala / 1000.0 / 2.0
    m.setExtent(QgsRectangle(centro.x() - dx, centro.y() - dy, centro.x() + dx, centro.y() + dy))
    m.setScale(scala)
    m.setFrameEnabled(True)
    m.setFrameStrokeWidth(QgsLayoutMeasurement(0.3, MM))
    return m


# sfondi delle tavole (cartografia, ortofoto, catasto) un po' in trasparenza:
# rete, fascia, quote ed etichette restano piene e si leggono meglio
OPACITA_CARTOGRAFIA = 0.55     # base cartografica (DBSN, OSM) in planimetria
OPACITA_SFONDO = 0.7          # 70% (scelta dell'utente: 0.6 troppo sbiadito, 0.8 si notava appena)


def _mappa_su_sfondo(layout, pagina, x, y, w, h, crs, sopra, sfondo, centro, scala,
                     opacita=None):
    """Due mappe sovrapposte: sotto lo sfondo con opacita' OPACITA_SFONDO,
    sopra (trasparente) i layer da leggere. Ritorna la mappa di sopra (quella
    che va in legenda)."""
    sfondo = [l for l in (sfondo or []) if l is not None]
    if sfondo:
        m_bg = _mappa(layout, pagina, x, y, w, h, crs, sfondo, centro, scala)
        m_bg.setFrameEnabled(False)
        try:
            m_bg.setItemOpacity(OPACITA_SFONDO if opacita is None else opacita)
        except Exception:  # noqa: BLE001
            pass
    m = _mappa(layout, pagina, x, y, w, h, crs, sopra, centro, scala)
    if sfondo:
        m.setBackgroundEnabled(False)
    return m


def _voce_rete(layer, etichetta):
    """Voce di legenda parlante: «Mini trincea» -> «Scavo in mini trincea»,
    «Esistente» (pozzetto) -> «Pozzetto esistente»."""
    e = (etichetta or "").strip()
    el = e.lower()
    nome = (layer.customProperty("rfi/nome_legenda") or layer.name() or "").upper()
    if "INFRASTRUTT" in nome or "SCAV" in nome:
        if "aere" in el:
            return "Linea aerea"
        if "canal" in el:
            return "Canaletta VTR"
        if "no" in el and "dig" in el:
            return "Perforazione no-dig"
        if el in ("tradizionale", "trincea", "trincea tradizionale"):
            return "Scavo tradizionale"
        return e if el.startswith("scavo") else "Scavo in " + el
    if "POZZETT" in nome:
        if "esist" in el:
            return "Pozzetto esistente"
        return e if "pozz" in el else "Pozzetto nuovo " + e
    return e


def voci_legenda_piatte(leg, nodo, layer):
    """Legenda senza i sottotitoli dei layer («INFRASTRUTTURE», «POZZETTO»):
    con piu' voci, solo le voci con un nome che dice cosa si vede; con una
    voce sola, il nome in minuscolo («Armadio ottico»)."""
    from qgis.core import QgsLegendRenderer, QgsMapLayerLegendUtils
    r = layer.renderer()
    voci = r.legendSymbolItems() if r is not None else []
    if len(voci) <= 1:
        t = nodo.customProperty("legend/title-label") or nome_pulito(layer.name())
        nodo.setCustomProperty("legend/title-label", str(t).capitalize())
        return
    QgsLegendRenderer.setNodeLegendStyle(nodo, QgsLegendStyle.Hidden)
    for k, it in enumerate(voci):
        QgsMapLayerLegendUtils.setLegendNodeUserLabel(nodo, k, _voce_rete(layer, it.label()))
    leg.model().refreshLayerLegend(nodo)


def _cartiglio(layout, pagina, dati, nome_tavola, scala_txt, legenda_map=None,
               legenda_layers=None, legenda_testo=None):
    titolo_altri = dati.get("titolo_legenda_ente") or "ELEMENTI FERROVIARI"
    pw, ph = PAGINA
    cx = pw - MARGINE - CART_W
    cy = MARGINE
    ch = ph - 2 * MARGINE
    _box(layout, pagina, cx, cy, CART_W, ch, 0.4)
    x, w = cx + 3, CART_W - 6

    # blocco in basso alto H_BLOCCO, appoggiato al bordo inferiore (prima restava
    # uno spazio vuoto sotto il nome file); la legenda prende tutto il resto
    H_BLOCCO = 30 + 1 + 8 + 10 + 18 + 22 + 9
    yb0 = cy + ch - 3 - H_BLOCCO

    # tavola senza simbologia (particolari): niente riquadro LEGENDA vuoto
    if legenda_map is None and not legenda_testo:
        _lbl(layout, pagina, x, cy + 3, w, 16, "PARTICOLARI COSTRUTTIVI\nnon in scala", 11, True)
        legenda_layers = None
    else:
        _lbl(layout, pagina, x, cy + 3, w, 8, "LEGENDA", 12, True)
        lh = yb0 - 4 - (cy + 12)
        _box(layout, pagina, x, cy + 12, w, lh, 0.2, QColor(160, 160, 160))
    if legenda_map is not None and legenda_layers:
        leg = QgsLayoutItemLegend(layout)
        leg.setTitle("")          # il riquadro ha gia' il titolo LEGENDA
        leg.setLinkedMap(legenda_map)
        leg.setAutoUpdateModel(False)
        root = leg.model().rootGroup()
        root.clear()
        # due blocchi distinti: la rete in progetto (copie filtrate dei layer
        # di progetto, riconoscibili da rfi/nome_legenda) e gli elementi
        # ferroviari (linea, fascia, cippi, stazioni)
        validi = [l for l in legenda_layers if l is not None]
        rilievo = [l for l in validi if l.customProperty("rfi/gruppo_legenda") == "rilievo"]
        principali = ("03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO")
        # fascia di rispetto e quote vanno con la ferrovia, non con la rete
        ferro_f = [l for l in validi if l.customProperty("rfi/gruppo_legenda") == "ferro"]
        rete = [l for l in validi if l not in rilievo and l not in ferro_f
                and (l.customProperty("rfi/nome_legenda") or l.name() in principali)]
        ferro = [l for l in validi if l not in rete and l not in rilievo]
        for titolo_g, gruppo in (("RETE FIBERCOP", rete),
                                 ("FOTO E SEZIONI" if any(
                                     l.customProperty("rfi/nome_legenda") == "Sezione"
                                     for l in rilievo) else "FOTO", rilievo),
                                 (titolo_altri, ferro)):
            if not gruppo:
                continue
            g = root.addGroup(titolo_g)
            for l in gruppo:
                nodo = g.addLayer(l)
                nome_leg = l.customProperty("rfi/nome_legenda") or \
                    l.customProperty("rfi/titolo_legenda") or \
                    (nome_pulito(l.name()) if l in rete else None)
                if nodo is not None and l.customProperty("rfi/titolo_nascosto"):
                    # solo le voci (es. un canale per riga), senza il nome del layer
                    try:
                        from qgis.core import QgsLegendRenderer
                        QgsLegendRenderer.setNodeLegendStyle(nodo, QgsLegendStyle.Hidden)
                    except Exception:  # noqa: BLE001
                        pass
                if nodo is not None and nome_leg:
                    nodo.setCustomProperty("legend/title-label", nome_leg)
                if nodo is not None and l in rete:
                    try:
                        voci_legenda_piatte(leg, nodo, l)
                    except Exception:  # noqa: BLE001
                        pass
        # solo le voci davvero presenti nella planimetria: i progetti reali
        # hanno decine di categorie e la legenda usciva dal riquadro
        try:
            leg.setLegendFilterByMapEnabled(True)
        except Exception:  # noqa: BLE001
            pass
        def _stile(st, font=None, sopra=None, rientro=None):
            # style() restituisce una copia: si modifica e si reimposta
            try:
                s = leg.style(st)
                if font is not None:
                    try:
                        tf = s.textFormat()
                        tf.setFont(font)
                        tf.setSize(font.pointSizeF())
                        s.setTextFormat(tf)
                    except AttributeError:
                        s.setFont(font)
                if sopra is not None:
                    s.setMargin(QgsLegendStyle.Top, sopra)
                if rientro is not None and hasattr(s, "setIndent"):
                    s.setIndent(rientro)
                leg.setStyle(st, s)
            except Exception:  # noqa: BLE001
                pass
        _stile(QgsLegendStyle.Title, QFont("Arial", 10, QFont.Bold))
        # titolo di blocco (RETE FIBERCOP / ELEMENTI FERROVIARI), staccato
        _stile(QgsLegendStyle.Group, QFont("Arial", 9, QFont.Bold), sopra=6)
        # nome layer dentro il blocco (INFRASTRUTTURE, POZZETTO), rientrato
        _stile(QgsLegendStyle.Subgroup, QFont("Arial", 9), sopra=2.5, rientro=3)
        _stile(QgsLegendStyle.Symbol, sopra=1.8, rientro=3)
        _stile(QgsLegendStyle.SymbolLabel, QFont("Arial", 9))
        try:
            leg.setSymbolHeight(4.5)
            leg.setSymbolWidth(8)
            leg.setWrapString("|")
        except Exception:  # noqa: BLE001
            pass
        layout.addLayoutItem(leg)
        leg.setResizeToContents(False)
        _mv(leg, x + 1, cy + 13, w - 2, lh - 2, pagina)
    elif legenda_testo:
        _cerchio(layout, pagina, x + 3, cy + 22, 9)
        _lbl(layout, pagina, x + 15, cy + 16, w - 16, 22, legenda_testo, 7, True, Qt.AlignLeft)

    # blocco in basso: logo FiberCop, dati, logo Beexact, data/scala/file/tavola
    yb = yb0
    logo_fc = logo_fibercop()      # classico o «Milano Cortina 2026» (flag del progetto)
    _box(layout, pagina, x, yb, w, 30, 0.2, QColor(160, 160, 160))
    if os.path.isfile(logo_fc):
        _immagine(layout, pagina, x + 8, yb + 6, w - 16, 18, logo_fc)
    yb += 31
    _lbl(layout, pagina, x, yb, w, 8, "INQUADRAMENTO PLANIMETRICO COMUNE DI %s"
         % dati["comune"].upper(), 6.5, False, frame=True)
    yb += 8
    _lbl(layout, pagina, x, yb, w, 10, "PROGETTAZIONE DELLA RETE OTTICA DI\n"
         "DISTRIBUZIONE SECONDARIA FIBERCOP", 6.5, False, frame=True)
    yb += 10
    _lbl(layout, pagina, x, yb, w, 18, "RICHIESTA PERMESSO\n%s\n%s" % (
        dati["tipologia_cartiglio"], dati["linea_cartiglio"]), 6.3, False, frame=True)
    yb += 18
    # logo Beexact attuale (arancio/blu, vettoriale); quello nero/arancio e'
    # il vecchio, il banner scuro non va usato
    logo_be = os.path.join(ASSETS, "beexact_logo.svg")
    if not os.path.isfile(logo_be):
        logo_be = os.path.join(ASSETS, "beexact_logo_nuovo.png")
    _box(layout, pagina, x, yb, w * 0.5, 22, 0.2)
    if os.path.isfile(logo_be):
        _immagine(layout, pagina, x + 4, yb + 6, w * 0.5 - 8, 10, logo_be)
    # griglia data / scala / file / tavola (niente timbro)
    gx = x + w * 0.5
    gw = w * 0.25
    _lbl(layout, pagina, gx, yb, gw, 11, "DATA\n%s" % dati["data"], 5.5, True, frame=True)
    _lbl(layout, pagina, gx + gw, yb, gw, 11, "COMUNE\n%s" % dati["comune"].upper(), 5.5, True, frame=True)
    _lbl(layout, pagina, gx, yb + 11, gw, 11, "SCALA\n%s" % scala_txt, 5.5, True, frame=True)
    _lbl(layout, pagina, gx + gw, yb + 11, gw, 11, "TAVOLA\n%s" % nome_tavola, 6, True, frame=True)
    _lbl(layout, pagina, x, yb + 22, w, 9, "NOME FILE: %s" % dati["nome_file"], 5, False,
         frame=True)


# --------------------------------------------------------------------------- #
#  API
# --------------------------------------------------------------------------- #
def _crs_metrico(project, lon):
    """CRS metrico delle tavole. Quello del progetto se e' una proiezione
    conforme in metri (UTM, Gauss-Boaga...). Web Mercator no: a 40-45 gradi
    di latitudine i suoi "metri" sono gonfiati del 30-40% e la scala
    stampata (1:2000) non corrisponderebbe al terreno. In quel caso si usa
    il fuso UTM del sito."""
    crs = project.crs()
    mercatore = crs.authid() in ("EPSG:3857", "EPSG:900913", "EPSG:3395", "EPSG:102100") \
        or "pseudo-mercator" in crs.description().lower()
    try:
        in_metri = crs.mapUnits() == QgsUnitTypes.DistanceMeters
    except Exception:  # noqa: BLE001
        in_metri = True
    if crs.isValid() and not crs.isGeographic() and not mercatore and in_metri:
        return crs
    return QgsCoordinateReferenceSystem("EPSG:%d" % (32600 + int((lon + 180) / 6) + 1))


ESTENSIONI_IMG = (".svg", ".png", ".jpg", ".jpeg")


def cerca_file(nomi, cartelle):
    """Primo file esistente fra `nomi` (senza estensione) nelle `cartelle`, con
    le estensioni immagine ammesse (SVG per primo: resta vettoriale)."""
    for c in cartelle:
        if not c or not os.path.isdir(c):
            continue
        for n in nomi:
            for est in ESTENSIONI_IMG:
                p = os.path.join(c, n + est)
                if os.path.isfile(p):
                    return p
    return None


def _immagini(cartella, profondita=2):
    """File immagine nella cartella e nelle sottocartelle (fino a 2 livelli)."""
    out = []
    if not cartella or not os.path.isdir(cartella):
        return out
    base = cartella.rstrip("\\/").count(os.sep)
    for radice, dirs, files in os.walk(cartella):
        if radice.count(os.sep) - base >= profondita:
            dirs[:] = []
        for f in files:
            if f.lower().endswith(ESTENSIONI_IMG):
                out.append(os.path.join(radice, f))
    return out


def _norm(testo):
    return re.sub(r"[^a-z0-9]+", "", (testo or "").lower())


def cerca_foto(n, cartelle):
    """File della FOTO n: prima i nomi soliti (FOTO-1, FOTO 1, foto_1…), poi
    qualunque immagine nelle cartelle (e sottocartelle) il cui nome inizia con
    il numero, anche con zeri o testo dopo: «FOTO_01.jpg», «Foto 1 via Roma.jpg»,
    «1.jpg». Prima si cercavano solo i nomi esatti: con un altro nome la foto
    restava fuori anche dando il percorso."""
    if not n:
        return None
    p = cerca_file(nomi_file_foto(n), cartelle)
    if p:
        return p
    voluto = str(n).lstrip("0") or "0"
    for c in cartelle:
        for f in _immagini(c):
            stem = os.path.splitext(os.path.basename(f))[0].lower()
            m = re.match(r"^\s*(?:foto|ft|f)?[\s_\-\.]*0*(\d+)(?!\d)", stem)
            if m and m.group(1) == voluto:
                return f
    return None


def _regole_pc(chiave):
    """(gruppi di parole: almeno una per gruppo, parole escluse) per
    riconoscere un particolare nella cartella dell'utente dal nome del file."""
    pc = re.match(r"PC-(\d+)", LIBRERIA_PC.get(chiave, "") or "")
    codici = ["pc%s" % pc.group(1), "pc%d" % int(pc.group(1))] if pc else []
    if chiave == "sezione_minitrincea":
        return [["minitrincea"] + codici], []
    if chiave == "sezione_microtrincea":
        return [["microtrincea"] + codici], []
    if chiave == "sezione_trincea":
        return [["trincea", "tradizional", "scavo"] + codici], ["minitrincea", "microtrincea"]
    if chiave == "sezione_nodig":
        return [["nodig", "teleguid", "perforaz", "toc"] + codici], []
    if chiave.startswith("pozzetto_"):
        a, _x, b = chiave.split("_", 1)[1].partition("x")
        return [["pozzett"] + codici, ["%sx%s" % (a, b), "%sx%s" % (b, a)] + codici], []
    if chiave == "sezione_canaletta":
        return [["canal", "vtr"] + codici], []
    if chiave == "armadio":
        return [["armadio"] + codici], []
    if chiave == "tubi":
        return [["tubo", "tubi"] + codici], []
    return [[_norm(chiave)] + codici], []


def _ordine_naturale(percorso):
    """Ordine per NUMERO, qualunque sia il nome: «PARTICOLARE-1»,
    «particolare costruttivo 2», «Particolare costruttivo 10»… (2 prima di 10);
    i file senza numero vanno in fondo, in ordine di nome."""
    nome = os.path.splitext(os.path.basename(percorso))[0].lower()
    m = re.search(r"(\d+)", nome)
    return (int(m.group(1)) if m else 10 ** 9, nome)


def dimensioni_particolare(path):
    """Larghezza e altezza in mm per impaginare: dall'SVG, o dalle proporzioni
    di un'immagine raster (lato lungo 80 mm)."""
    if path.lower().endswith(".svg"):
        return dimensioni_svg(path)
    try:
        from qgis.PyQt.QtGui import QImageReader
        s = QImageReader(path).size()
        if s.width() > 0 and s.height() > 0:
            k = 80.0 / max(s.width(), s.height())
            return s.width() * k, s.height() * k
    except Exception:  # noqa: BLE001
        pass
    return 60.0, 60.0


def particolari_cartella(cartella):
    """Particolari scelti dall'utente: se la cartella è compilata si prendono
    TUTTE le sue immagini (o quelle della sottocartella «particolari»), in
    ordine PARTICOLARE-1, PARTICOLARE-2, …; il nome non deve dire il tipo.
    Cartella vuota o senza immagini: [] (vanno i particolari del plugin).
    Ritorna [(nome, file, larghezza_mm, altezza_mm)]."""
    if not cartella or not os.path.isdir(cartella):
        return []
    for c in (cartella, os.path.join(cartella, "particolari")):
        if not os.path.isdir(c):
            continue
        files = [os.path.join(c, f) for f in os.listdir(c)
                 if f.lower().endswith(ESTENSIONI_IMG) and os.path.isfile(os.path.join(c, f))]
        if files:
            out = []
            for f in sorted(files, key=_ordine_naturale):
                w_, h_ = dimensioni_particolare(f)
                out.append((os.path.splitext(os.path.basename(f))[0], f, w_, h_))
            return out
    return []


def cerca_particolare(chiave, cartelle):
    """File del particolare `chiave`: nelle cartelle dell'utente prima con i
    nomi del plugin, poi riconoscendolo dal nome del file («Trincea.svg»,
    «PC-07 scavo.png», «pozzetto 40x76.jpg»…); per ultimi i particolari del
    plugin. Prima i file dell'utente con un altro nome non venivano presi."""
    nomi = [chiave] + ([LIBRERIA_PC[chiave]] if chiave in LIBRERIA_PC else [])
    assets = os.path.normcase(os.path.normpath(ASSETS))
    utente = [c for c in cartelle if c and not os.path.normcase(os.path.normpath(c))
              .startswith(assets)]
    p = cerca_file(nomi, utente)
    if p:
        return p
    gruppi, esclusi = _regole_pc(chiave)
    for c in utente:
        for f in sorted(_immagini(c), key=lambda x: (not x.lower().endswith(".svg"), x)):
            nome = _norm(os.path.splitext(os.path.basename(f))[0])
            if any(e in nome for e in esclusi):
                continue
            if all(any(w in nome for w in g) for g in gruppi):
                return f
    return cerca_file(nomi, [c for c in cartelle if c not in utente])


# libreria particolari del plugin (dal DXF Particolari_Costruttivi di Beexact,
# in assets/rfi_particolari): chiave -> file. La cartella dell'utente puo'
# sostituirli con file chiamati come la chiave.
LIBRERIA_PC = {
    "sezione_minitrincea": "PC-03_minitrincea-carreggiata-asfaltata",
    "sezione_microtrincea": "PC-05_microtrincea-carreggiata-asfaltata",
    "sezione_trincea": "PC-07_scavo-carreggiata-asfaltata-h110",
    "sezione_nodig": "PC-12_tecnica-no-dig",
    "sezione_canaletta": "PC-13_canala-vtr-fezn-175x70",
    "pozzetto_76x40": "PC-01_pozzetto-modulare-40x76",
    "pozzetto_125x80": "PC-02_pozzetto-modulare-125x80",
    "pozzetto_45x15": "PC-04_pozzetto-modulare-40x15",
    "pozzetto_40x15": "PC-04_pozzetto-modulare-40x15",
    "armadio": "PC-06_armadio-ottico-onucab",
    "colonnina": "PC-20_colonnina-pte",
    "tubi": "PC-15_tubo-fender-4-d14",
    "tubo_fender4": "PC-15_tubo-fender-4-d14",
    "tubo_fender5": "PC-18_tubo-fender-5-d14",
    "tubo_pehd125": "PC-16_tubo-pehd-d125",
    "tritubo_50": "PC-17_tritubo-d50",
    "tubo_16": "PC-19_tubo-d16",
}

# tubi del particolare costruttivo: li sceglie l'utente al passo 6 (gli shape
# non dicono che tubo si posa). Chiave -> testo nella scelta.
TUBI_PC = [
    ("tubo_fender4", "1 tubo Fender-4 Ø14"),
    ("tubo_fender5", "Tubo Fender-5 Ø14"),
    ("tubo_pehd125", "Tubo PEHD Ø125"),
    ("tritubo_50", "Tritubo Ø50"),
    ("tubo_16", "Tubo Ø16"),
]
TUBI_SCELTI = []        # impostati da «Genera le istanze» (ftth_passi)


def tubi_progetto(project):
    """Tubi scelti nel progetto (chiavi di TUBI_PC)."""
    try:
        v, _ok = project.readEntry("ftth_permessi", "tubi_pc", "")
    except Exception:  # noqa: BLE001
        v = ""
    validi = [k for k, _t in TUBI_PC]
    return [k for k in str(v or "").split(",") if k in validi]


def dimensioni_svg(path, default=(40.0, 40.0)):
    """Larghezza e altezza in mm dagli attributi width/height dell'SVG."""
    import re
    if not path.lower().endswith(".svg"):
        return default
    try:
        with open(path, encoding="utf-8", errors="ignore") as fh:
            testa = fh.read(2000)
        w = re.search(r'\bwidth="([\d.]+)mm"', testa)
        h = re.search(r'\bheight="([\d.]+)mm"', testa)
        if w and h:
            return float(w.group(1)), float(h.group(1))
    except Exception:  # noqa: BLE001
        pass
    return default


def impagina_particolari(pezzi, area_w, area_h, gap=8.0, scala_max=3.0, scala_min=1.4):
    """Impaginazione a scaffali, tutti i pezzi alla STESSA scala (le scritte dei
    cartigli restano della stessa altezza). Cerca la scala piu' grande, fino a
    scala_max, che fa stare tutto in una pagina; se non basta usa scala_min su
    piu' pagine. pezzi = [(chiave, file, w_mm, h_mm)].
    Ritorna (scala, [[(chiave, file, x, y, w, h), ...] per pagina])."""
    def _prova(s):
        pagine, pag, x, y, rh = [], [], 0.0, 0.0, 0.0
        for k, f, w, h in pezzi:
            W, H = w * s, h * s
            if W > area_w or H > area_h:
                return None
            if x + W > area_w + 0.01:
                x, y, rh = 0.0, y + rh + gap, 0.0
            if y + H > area_h + 0.01:
                pagine.append(pag)
                pag, x, y, rh = [], 0.0, 0.0, 0.0
            pag.append((k, f, x, y, W, H))
            x += W + gap
            rh = max(rh, H)
        if pag:
            pagine.append(pag)
        return pagine
    s = scala_max
    while s >= scala_min:
        p = _prova(s)
        if p is not None and len(p) <= 1:
            return s, p
        s -= 0.1
    return scala_min, (_prova(scala_min) or [])


def particolari_necessari(ist):
    """Chiavi dei particolari costruttivi da mettere nella tavola PC, in base a
    cio' che l'istanza contiene davvero: una sezione per ogni tecnica di scavo
    usata, un pozzetto per ogni dimensione posata, l'armadio se ce n'e' uno in
    fascia, il tubo."""
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    chiavi = []
    tecniche = []
    for i in ist.interferenze:
        for t, m in i.metri.items():
            if m and t not in tecniche:
                tecniche.append(t)
    for t in ("minitrincea", "microtrincea", "trincea", "nodig", "canaletta"):
        if t in tecniche:
            chiavi.append("sezione_%s" % t)
    dims = []
    for i in ist.interferenze:
        for d in i.pozzetti:
            dn = R.norm_pozzetto(d)
            if dn not in dims:
                dims.append(dn)
    for d in sorted(dims):
        chiavi.append("pozzetto_%s" % d)
    if any(e.get("tipo") == "armadio" for i in ist.interferenze for e in i.elementi):
        chiavi.append("armadio")
    # colonnina PTE: solo su richiesta (Soprintendenza, punto 6 «Aggiungi
    # particolare costruttivo colonnina»)
    if getattr(ist, "particolare_colonnina", False):
        chiavi.append("colonnina")
    # i tubi scelti al passo 6; senza scelta il Fender-4 di sempre
    chiavi += list(TUBI_SCELTI) or ["tubi"]
    return chiavi


TITOLI_PARTICOLARI = {
    "sezione_minitrincea": "SEZIONE TIPO SCAVO IN MINITRINCEA",
    "sezione_microtrincea": "SEZIONE TIPO SCAVO IN MICROTRINCEA",
    "sezione_trincea": "SEZIONE TIPO SCAVO TRADIZIONALE",
    "sezione_nodig": "SEZIONE TIPO PERFORAZIONE NO DIG",
    "sezione_canaletta": "CANALA IN VTR/FeZn PER VIADOTTI, CUNICOLI E GALLERIE",
    "tubi": "PARTICOLARI TUBAZIONI",
}


def genera_pl_istanza(project, ist, comune, out_pdf, orto_id=None, fascia_m=30.0,
                      esporta=True, cartella_utente=None, log=None,
                      cartella_sezioni=None, cartella_foto=None, profilo=None):
    """Crea (o rigenera) il layout 'RFI PL - <istanza>' e lo esporta in PDF.
    `ist` = ftth_rfi.Istanza, `comune` = ftth_rfi.DatiComune.
    `cartella_utente`: cartella dove cercare per prima sezioni
    (sezione_tipo_X), foto (foto_<n>) e particolari (sezione_<tecnica>,
    pozzetto_<dim>, tubi), in SVG/PNG/JPG; poi si usano quelli del plugin.
    `log(testo)` riceve gli avvisi (particolari mancanti, ...).
    `profilo` (dict) adatta la PL ad altri enti (istanze acque): layer della
    linea e della fascia, prefisso dei layer, testi del cartiglio, titolo del
    blocco di legenda, sezione tipo per interferenza, niente km. Senza
    profilo la PL e' quella RFI.
    Ritorna True se il PDF e' stato scritto (o se esporta=False)."""
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    if not ist.interferenze:
        return False
    avvisa = log or (lambda _t: None)
    # cartelle del progetto come in Altri Enti: 04_Foto/FOTO-n.jpg e
    # 05_Sezioni/SEZIONE A-A'.svg
    home = project.homePath() or os.path.dirname(project.fileName() or "")
    # ordine di ricerca: cartella scelta nella scheda, cartella del progetto,
    # (compatibilita') vecchia cartella unica con sottocartelle, plugin
    cart_sez = [cartella_sezioni,
                os.path.join(home, "05_Sezioni") if home else None,
                cartella_utente, os.path.join(cartella_utente or "", "sezioni"),
                os.path.join(ASSETS, "rfi_sezioni")]
    cart_foto = [cartella_foto,
                 os.path.join(home, "04_Foto") if home else None,
                 cartella_utente, os.path.join(cartella_utente or "", "foto")]
    cart_part = [cartella_utente, os.path.join(cartella_utente or "", "particolari"),
                 os.path.join(ASSETS, "rfi_particolari")]

    # foto e sezioni di questa istanza: prima la sua sottocartella (04_Foto/SP28,
    # 05_Sezioni/<linea>…), poi la cartella; i punti di altre istanze no
    nomi_ist = nomi_istanza(ist)
    etichette_inizio(ist.nome_base)
    cart_sez = cartelle_istanza(cart_sez, nomi_ist)
    cart_foto = cartelle_istanza(cart_foto, nomi_ist)
    lon0 = sum(i.lon for i in ist.interferenze) / len(ist.interferenze)
    crs = _crs_metrico(project, lon0)
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    tr = QgsCoordinateTransform(wgs, crs, project)

    # layer
    infra = _trova(project, "03 INFRASTRUTTURE")
    pozz = _trova(project, "02_POZZETTO")
    arm = _trova(project, "01_ARMADIO OTTICO")
    if profilo:
        ferr = _trova(project, profilo["layer_linea"])
        fascia = _trova(project, profilo["layer_fascia"])
        cippi = staz = None
        prefisso = profilo.get("prefisso", "ENTE")
    else:
        ferr = _trova(project, "Ferrovia RFI")
        fascia = _trova(project, "Fascia di rispetto RFI")
        cippi = _trova(project, "Cippi km RFI")
        staz = _trova(project, "Stazioni ferroviarie")
        prefisso = "RFI"
    base = _base_stampe(project, senza_ferrovie=True)   # 'Cartografia' (senza ferrovia CTR) o OSM
    orto = _ortofoto(project, orto_id)
    cat = _catasto_stampe(project)        # gruppo 'Mappa Catastale' o WMS AdE
    cerchi, etich = _layer_istanza(project, ist, con_km=not profilo, prefisso=prefisso)
    ente_l = None if profilo else "rfi"
    foto_l = layer_rilievo(project, NOMI_LAYER_FOTO, nomi_ist, ente_l)
    sez_l = layer_rilievo(project, NOMI_LAYER_SEZIONI, nomi_ist, ente_l)
    # in planimetria solo cio' che riguarda l'istanza: tratte che toccano la
    # fascia (intere, se continuano fuori) e i loro pozzetti/armadi
    pref = "%s tavole %s" % (prefisso, ist.nome_base)
    fid_tratte = {f for i in ist.interferenze for f in i.tratte_fid}
    fid_pozz = {e.get("fid") for i in ist.interferenze for e in i.elementi
                if e.get("tipo") in ("pozzetto", "pozzetto_fuori")}
    fid_arm = {e.get("fid") for i in ist.interferenze for e in i.elementi
               if e.get("tipo") in ("armadio", "armadio_fuori")}
    da_gruppo = None
    try:    # gruppo dell'istanza nel progetto (Istanze > Ferrovia > ...)
        try:
            from . import ftth_gruppi_istanze as GR
        except ImportError:
            import ftth_gruppi_istanze as GR
        da_gruppo = GR.rete_per_pl(project, ist, copia_filtrata, pref)
        if da_gruppo and da_gruppo[0] is not None:
            extra = GR.elementi_in_piu(project, ist)
            avvisa("rete in tavola dagli elementi con il nome dell'istanza negli shape%s" % (
                " (%d aggiunti a mano)" % extra
                if extra else ""))
        else:
            da_gruppo = None
    except Exception as e:  # noqa: BLE001
        avvisa("gruppo dell'istanza non usato (%s): rete dai layer principali" % e)
        da_gruppo = None
    if da_gruppo:
        infra, pozz, arm = da_gruppo
        fid_tratte = fid_tratte or {"gruppo"}
    else:   # mai la rete intera: fuori dall'istanza (suolo comunale) non si stampa
        infra = copia_filtrata(project, infra, fid_tratte, pref) or infra
        pozz = copia_filtrata(project, pozz, fid_pozz, pref) if pozz is not None else None
        arm = copia_filtrata(project, arm, fid_arm, pref) if arm is not None else None
    # pozzetti esistenti: entrano SEMPRE da soli nell'istanza quando stanno
    # sugli scavi dell'istanza (utente: spesso si perdevano). Anche con
    # l'istanza confermata negli shape e anche se l'istanza non ha pozzetti
    # nuovi (prima in quei casi non si aggiungevano)
    try:
        pz_o = _trova(project, "02_POZZETTO")
        if pozz is None and pz_o is not None:
            pozz = copia_filtrata(project, pz_o, [], pref)
        n_es = aggiungi_pozzetti_esistenti(project, pz_o, pozz, infra)
        if n_es:
            avvisa("%d pozzetti sugli scavi dell'istanza aggiunti in tavola (non presi dall'analisi)" % n_es)
        rendi_visibili(arm)       # armadi della copia sempre disegnati
    except Exception as e:  # noqa: BLE001
        avvisa("pozzetti esistenti non aggiunti: %s" % e)
    cart_img = os.path.join(os.path.dirname(out_pdf) or ".", "_immagini_tavole")
    # tavole piu' leggere: pozzetti e armadi un po' piu' piccoli (a 1:2000 si
    # accavallavano con gli scavi), fascia appena campita
    for l_ in (pozz, arm):
        if l_ is not None and l_ is not _trova(project, "02_POZZETTO") and \
                l_ is not _trova(project, "01_ARMADIO OTTICO"):
            simboli_piu_piccoli(l_)
    # in tavola solo le nostre etichette (riquadri): quelle del progetto («MT. 6»,
    # «POSA ARMADIO 205» in grassetto) si sommavano e facevano confusione
    for l_ in (infra, pozz, arm):
        if l_ is not None and l_ not in (_trova(project, "03 INFRASTRUTTURE"),
                                          _trova(project, "02_POZZETTO"),
                                          _trova(project, "01_ARMADIO OTTICO")):
            l_.setLabelsEnabled(False)
    try:
        _f6 = int(R.FASCIA_PROPRIETA_M)
    except Exception:  # noqa: BLE001
        _f6 = 6
    ferr_coro = ferrovia_inquadramento(project, ferr, pref) or ferr
    ferr = ferrovia_tavola(project, ferr, pref) or ferr
    fascia_t = fascia_tavola(project, fascia, pref, "FASCIA DI RISPETTO ROTAIE %d-%d M" % (
        _f6, int(round(fascia_m)))) or fascia
    # armadio col simbolo FO, ruotato verso la rete e staccato da scavo e
    # pozzetto (anche sull'ortofoto: si fa prima delle sue copie)
    fili_arm = None
    if arm is not None and arm is not _trova(project, "01_ARMADIO OTTICO"):
        try:
            armadio_fo(project, arm, pozz, infra)
        except Exception as e:  # noqa: BLE001
            avvisa("armadi: %s" % e)
    # rete dell'istanza (scavi, pozzetti, armadi) anche sull'ortofoto
    rete_orto = rete_ortofoto(project, pref, infra, pozz, arm) if fid_tratte else []

    nome_file = os.path.basename(out_pdf)
    if profilo:
        linea_cart = profilo["linea_cartiglio"]
        dati = {"comune": comune.nome, "tipologia_cartiglio": profilo["tipologia_cartiglio"],
                "linea_cartiglio": linea_cart, "data": datetime.date.today().strftime("%m/%Y"),
                "nome_file": nome_file, "titolo_legenda_ente": profilo.get("titolo_legenda")}
    else:
        tip = R.TIPOLOGIE[ist.tipologia]
        g = ist.gestore
        linea_cart = ("%s - %s" % (g.sigla, ist.linea)).upper()
        dati = {"comune": comune.nome, "tipologia_cartiglio": tip["cartiglio"],
                "linea_cartiglio": linea_cart, "data": datetime.date.today().strftime("%m/%Y"),
                "nome_file": nome_file}
    scheda = profilo.get("scheda", "scheda") if profilo else "scheda RFI"

    nome_layout = "%s PL - %s" % (prefisso, ist.nome_base)
    mgr = project.layoutManager()
    vecchio = mgr.layoutByName(nome_layout)
    if vecchio is not None:
        mgr.removeLayout(vecchio)
    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName(nome_layout)
    pc = layout.pageCollection()
    pc.pages()[0].setPageSize(QgsLayoutSize(PAGINA[0], PAGINA[1], MM))
    # particolari: solo quelli disponibili; i mancanti vanno nel registro, non
    # in un riquadro vuoto
    # cartella dei particolari compilata: SOLO i suoi file (PARTICOLARE-1, …),
    # quelli automatici del plugin non vanno in PL
    propri = particolari_cartella(cartella_utente)
    disponibili = []
    for chiave in ([] if propri else particolari_necessari(ist)):
        f = cerca_particolare(chiave, cart_part)
        if f:
            w_, h_ = dimensioni_svg(f)
            disponibili.append((chiave, f, w_, h_))
        else:
            avvisa("particolare '%s' non disponibile: aggiungi %s.svg nella cartella "
                   "dei particolari" % (chiave, chiave))
    if propri:
        disponibili = propri
        avvisa("particolari dalla cartella %s: %d file" % (cartella_utente, len(propri)))
    area_w0 = PAGINA[0] - 2 * MARGINE - CART_W - 4
    area_h0 = PAGINA[1] - 2 * MARGINE
    scala_pc, impag_pc = impagina_particolari(disponibili, area_w0 - 8, area_h0 - 8)
    pagine_pc = len(impag_pc)
    area_w = PAGINA[0] - 2 * MARGINE - CART_W - 4
    area_h = PAGINA[1] - 2 * MARGINE

    def _punto(i):
        return tr.transform(QgsPointXY(i.lon, i.lat))

    def _rect_metri(lista):
        r = None
        for i in lista:
            if i.bbox:
                g_ = QgsGeometry.fromRect(QgsRectangle(*i.bbox))
            else:
                g_ = QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
            g_.transform(tr)
            b = g_.boundingBox()
            r = QgsRectangle(b) if r is None else (r.combineExtentWith(b) or r)
        r.grow(60)
        return r

    # ordine di disegno: pozzetti e scavi SOPRA l'armadio (prima lo copriva)
    base_vett = [etich, cippi, staz, pozz, infra, arm, fili_arm, ferr, fascia_t]
    # quote dalla rotaia: quelle disegnate a mano nel layer «Quote dalla
    # rotaia» (scheda Ferrovie, passo 5), con la misura calcolata
    quote_l = None
    if not profilo:
        try:
            quote_l = layer_quote_manuali(project, crs, "%s - quote dalla rotaia" % pref,
                                          scala_tavole())
        except Exception as e:  # noqa: BLE001
            avvisa("quote dalla rotaia non disegnate: %s" % e)

    # ---- tavole: una per interferenza; se nel suo riquadro ci sono più
    # sezioni disegnate (questa PL ne ha UNA per tavola), una tavola per
    # sezione, inquadrata sulla sezione, con solo quella in planimetria ----
    col_w = (area_w - 6) / 2.0
    tit_h = 6.0
    riga_h = (area_h - 2 * tit_h - 6) / 2.0

    s_unica = scala_tavole()

    def _vista(r, s_=None):
        # stessa scala per ortofoto, planimetria e catasto della tavola (RFI:
        # 1:500, 1:1000 o 1:2000 secondo la tavola; altrimenti quella unica)
        s_ = s_ or s_unica
        if _scala_che_contiene(r, col_w, riga_h, 500) > s_:
            avvisa("a 1:%d una tavola non contiene tutto il gruppo di interferenze: "
                   "se serve scegli una scala più piccola nelle Avanzate" % s_)
        c_ = r.center()
        dx_, dy_ = col_w * s_ / 2000.0, riga_h * s_ / 2000.0
        return c_, s_, QgsRectangle(c_.x() - dx_, c_.y() - dy_, c_.x() + dx_, c_.y() + dy_)

    # tavole: con sezioni disegnate, UNA tavola per sezione con tutte le
    # interferenze vicine (scala adattata perché entri tutto); senza sezioni
    # una tavola per interferenza, come prima
    tavole = []          # (interferenze, rettangolo, sezioni, centrata sul riquadro)
    r_tutte = _rect_metri(ist.interferenze)
    r_tutte.grow(250)
    secs_ist = [] if sez_l is None else [
        f for f, _d in feature_nel_riquadro(project, sez_l, crs, r_tutte, r_tutte.center(),
                                            istanza=nomi_ist) if sigla_sezione(sez_l, f)]
    if secs_ist:
        a_crs = QgsCoordinateTransform(sez_l.crs(), crs, project)
        geo = {}
        for f in secs_ist:
            g_ = QgsGeometry(f.geometry())
            g_.transform(a_crs)
            geo[f.id()] = g_
        # una sezione prende solo le interferenze che stanno nella sua tavola
        # (entro mezza tavola): prima prendeva tutte quelle dell'istanza, anche
        # a chilometri, e la tavola centrata a meta' strada non mostrava niente
        raggio = min(col_w, riga_h) * s_unica / 1000.0 / 2.0
        gruppi = {f.id(): [] for f in secs_ist}
        sole = []
        for i in ist.interferenze:
            p_ = QgsGeometry.fromPointXY(_punto(i))
            k_v = min(geo, key=lambda k_: geo[k_].distance(p_))
            if geo[k_v].distance(p_) <= raggio:
                gruppi[k_v].append(i)
            else:
                sole.append(i)
        for f in ordina_sezioni(sez_l, secs_ist):     # A-A' prima di B-B'
            grp = gruppi[f.id()]
            if not grp:
                # sezione vicina a un'altra: le interferenze sono andate tutte
                # all'altra e questa spariva (due sezioni vicine -> una tavola
                # sola). Prende quelle entro mezza tavola; se non ce n'è
                # nessuna è davvero lontana e non è di questa istanza.
                grp = [i for i in ist.interferenze
                       if geo[f.id()].distance(QgsGeometry.fromPointXY(_punto(i))) <= raggio]
            if not grp:
                continue
            r_ = _rect_metri(grp)
            r_.combineExtentWith(geo[f.id()].boundingBox())
            r_.grow(15)
            tavole.append((grp, r_, [f], True))
        for i in sole:          # interferenze senza sezione vicina: tavola propria
            tavole.append(([i], _rect_metri([i]), [], False))
        if not tavole:
            for i in ist.interferenze:
                tavole.append(([i], _rect_metri([i]), [], False))
    else:
        for i in ist.interferenze:
            tavole.append(([i], _rect_metri([i]), [], False))
    if not profilo:
        # RFI (richiesta dell'utente): tavole a 1:1000, interferenze divise nel
        # minor numero di tavole («Calcola numero di tavole» fa la stessa
        # divisione) e UNA sezione per tavola, quella disegnata nel riquadro
        tavole = tavole_rfi(project, ist, crs, s_unica, sez_l, secs_ist, avvisa, _punto)
    n_pagine = 1 + len(tavole) + pagine_pc
    for _ in range(n_pagine - 1):
        p = QgsLayoutItemPage(layout)
        p.setPageSize(QgsLayoutSize(PAGINA[0], PAGINA[1], MM))
        pc.addPage(p)

    # ---- pagina 1: COROGRAFIA, meta' su ortofoto e meta' su cartografia ----
    r_all = _rect_metri(ist.interferenze)
    tit_c = 6.0
    mezza_h = (area_h - 2 * tit_c - 4) / 2.0
    s_coro = max(5000, _scala_che_contiene(r_all, area_w, mezza_h, 5000))
    _lbl(layout, 0, MARGINE, MARGINE, area_w, tit_c, "INQUADRAMENTO SU ORTOFOTO", 9)
    _mappa(layout, 0, MARGINE, MARGINE + tit_c, area_w, mezza_h, crs,
           [cerchi, ferr_coro, orto], r_all.center(), s_coro)
    y_sotto = MARGINE + tit_c + mezza_h + 4
    _lbl(layout, 0, MARGINE, y_sotto, area_w, tit_c, "INQUADRAMENTO SU CARTOGRAFIA", 9)
    _mappa(layout, 0, MARGINE, y_sotto + tit_c, area_w, mezza_h, crs,
           [cerchi, staz, ferr_coro] + base, r_all.center(), s_coro)
    _cartiglio(layout, 0, dati, "COROGRAFIA", "1:%d" % s_coro,
               legenda_testo="LOCALIZZAZIONE INTERVENTO\n%s" % linea_cart)

    for k, voce_t in enumerate(tavole, 1):
        gruppo, r_i, sez_fisse, extra = voce_t[:4]
        s_tav = voce_t[4] if len(voce_t) > 4 else None
        i = gruppo[0]
        pag = k
        # planimetria in scala: riquadro effettivamente visibile
        c_pl, s_pl, vis = _vista(r_i, s_tav)
        centro = c_pl if extra else _punto(i)
        x1, x2 = MARGINE, MARGINE + col_w + 6
        y1 = MARGINE
        y2 = MARGINE + tit_h + riga_h + 6
        # ortofoto
        # ortofoto: stessa scala e stesso centro della planimetria (senza
        # i pallini rossi, inutili a scala uguale)
        _lbl(layout, pag, x1, y1, col_w, tit_h, "ORTOFOTO - SCALA 1:%d" % s_pl, 9)
        _mappa_su_sfondo(layout, pag, x1, y1 + tit_h, col_w, riga_h, crs,
                         rete_orto + [fascia_t], [orto], c_pl, s_pl)
        # etichette di questa tavola: posizioni calcolate tutte insieme, senza
        # sovrapporsi fra loro ne' sopra quote e sezione
        ost_geo = []
        if quote_l is not None:
            ost_geo += [QgsGeometry(f.geometry()) for f in quote_l.getFeatures()]
        if sez_l is not None and sez_fisse:
            a_s = QgsCoordinateTransform(sez_l.crs(), crs, project)
            for f in sez_fisse:
                g_ = QgsGeometry(f.geometry())
                g_.transform(a_s)
                ost_geo.append(g_)
        ost = ostacoli_mm(ost_geo, c_pl, s_pl, col_w, riga_h)
        occ = []
        for ii in gruppo:
            posiziona_etichette(etich, ii.id, crs, tr,
                                QgsCoordinateTransform(crs, wgs, project),
                                c_pl, s_pl, col_w, riga_h, ostacoli=ost, condivisi=occ)
        # etichette spostate a mano nel layer «Etichette PL (spostabili)»
        try:
            i_px, i_py = etich.fields().indexOf("px"), etich.fields().indexOf("py")
            ids_g = {ii.id for ii in gruppo}
            f_et = [f for f in etich.getFeatures() if f["interf"] in ids_g
                    and f["px"] is not None and str(f["px"]) != "NULL"]
            fin = posizioni_manuali(project, ist.nome_base, [
                (f["testo"], f.geometry().asPoint().x(), f.geometry().asPoint().y(),
                 float(f["px"]), float(f["py"])) for f in f_et])
            etich.dataProvider().changeAttributeValues(
                {f.id(): {i_px: x, i_py: y} for f, (x, y) in zip(f_et, fin)})
        except Exception as e:  # noqa: BLE001
            avvisa("etichette spostabili non applicate: %s" % e)
        # punti di ripresa (con cono) e sezioni disegnati nel progetto: in
        # planimetria quelli del riquadro, con lo stile del progetto
        foto_in = feature_nel_riquadro(project, foto_l, crs, vis, centro, istanza=nomi_ist)
        sez_in = [(f, 0.0) for f in sez_fisse]     # ogni sezione in una tavola
        # una sola foto, quella della sezione
        foto_in = foto_della_sezione(project, foto_l, sez_l, crs, sez_fisse, vis, centro, nomi_ist)
        foto_c = copia_filtrata(project, foto_l, [f.id() for f, _ in foto_in],
                                "%s %d" % (pref, k), "Punto di ripresa fotografica",
                                "rilievo") if foto_in else None
        sez_c = copia_filtrata(project, sez_l, [f.id() for f, _ in sez_in],
                               "%s %d" % (pref, k), "Sezione", "rilievo") if sez_in else None
        if sez_c is not None:
            # estremo con sezione_f vuoto: lo stile ripeteva "A" ai due capi
            cs, cf = _campo(sez_c, "sezione"), _campo(sez_c, "sezione_f")
            if cs and cf:
                agg = {}
                for f in sez_c.getFeatures():
                    s, sf = f[cs], f[cf]
                    if s not in (None, "") and str(s) != "NULL" and \
                            (sf in (None, "") or str(sf) == "NULL"):
                        agg[f.id()] = {sez_c.fields().indexOf(cf): "%s'" % s}
                if agg:
                    sez_c.dataProvider().changeAttributeValues(agg)
            stile_sezione_tavola(sez_c)
        _lbl(layout, pag, x2, y1, col_w, tit_h, "PLANIMETRIA - SCALA 1:%d" % s_pl, 9)
        # il cono della foto sotto scavi, pozzetti e armadi (prima ci finiva sopra)
        m_pl = _mappa_su_sfondo(layout, pag, x2, y1 + tit_h, col_w, riga_h, crs,
                                [quote_l, sez_c] + base_vett[:7] + [foto_c] + base_vett[7:],
                                base, c_pl, s_pl, opacita=OPACITA_CARTOGRAFIA)
        # catasto alla stessa scala della planimetria (i numeri di particella
        # del WMS si vedono fino a 1:2000), senza pallini rossi
        foglio = foglio_catastale(i.lat, i.lon)
        _lbl(layout, pag, x1, y2, col_w, tit_h, "ESTRATTO CATASTALE%s - SCALA 1:%d"
             % (" - FOGLIO %s" % foglio if foglio else "", s_pl), 9)
        # sul catasto anche la rete dell'istanza (scavi, pozzetti, armadi) e la
        # ferrovia: prima il riquadro restava con le sole particelle
        sopra_cat = list(rete_orto) + ([ferr] if ferr is not None else []) + \
            ([fascia_t] if fascia_t is not None else [])
        png = render_png(project, list(cat), crs, c_pl, s_pl, col_w, riga_h,
                         os.path.join(cart_img, "catasto_%s_%d_%d.png" % (ist.nome_base, i.id, k)))
        if png:
            img = _immagine(layout, pag, x1, y2 + tit_h, col_w, riga_h, png)
            try:
                img.setItemOpacity(OPACITA_SFONDO)
            except Exception:  # noqa: BLE001
                pass
            # rete e ferrovia sopra l'immagine, in una mappa trasparente (dentro
            # l'immagine gli spessori delle linee uscivano enormi)
            m_cat = _mappa(layout, pag, x1, y2 + tit_h, col_w, riga_h, crs, sopra_cat,
                           c_pl, s_pl)
            m_cat.setBackgroundEnabled(False)
            _box(layout, pag, x1, y2 + tit_h, col_w, riga_h, 0.3)
        else:
            _mappa_su_sfondo(layout, pag, x1, y2 + tit_h, col_w, riga_h, crs, sopra_cat,
                             list(cat), c_pl, s_pl)
        # sezione e foto: prima la cartella scelta dall'utente, poi il plugin
        mezza = (riga_h - tit_h - 3) / 2.0
        # SEZIONE: quella disegnata in planimetria (layer Sezioni, la piu'
        # vicina all'interferenza) -> 05_Sezioni/SEZIONE A-A'.svg; altrimenti
        # la sezione tipo della tipologia
        if profilo:
            nomi_tipo, tit_sez, desc_tipo = profilo["sezione_tipo"](i)
        else:
            nomi_tipo = ["sezione_tipo_%s" % ist.tipologia, "sezione_%s" % ist.tipologia]
            tit_sez, desc_tipo = "SEZIONE TIPO %s" % ist.tipologia, "sezione_tipo_%s" % ist.tipologia
        sez = None
        for f, _d in sez_in:
            sigla = sigla_sezione(sez_l, f)
            if not sigla:
                continue
            p = cerca_file(["SEZIONE %s" % sigla, "SEZIONE_%s" % sigla, sigla], cart_sez)
            if p:
                sez, tit_sez = p, "SEZIONE %s" % sigla
                break
            avvisa("sezione %s disegnata ma file 'SEZIONE %s' non trovato in 05_Sezioni"
                   % (sigla, sigla))
        if sez is None:
            sez = cerca_file(nomi_tipo, cart_sez)
        if sez is None and profilo:
            # ultima risorsa: il particolare della tecnica di scavo del plugin
            sez = cerca_file(nomi_tipo, cart_part)
        _lbl(layout, pag, x2, y2, col_w, tit_h, tit_sez, 9)
        _box(layout, pag, x2, y2 + tit_h, col_w, mezza)
        if sez:
            _immagine(layout, pag, x2 + 1, y2 + tit_h + 1, col_w - 2, mezza - 2, sez)
        else:
            _lbl(layout, pag, x2, y2 + tit_h, col_w, mezza,
                 "Sezione da inserire: disegna la sezione nel layer Sezioni e metti "
                 "SEZIONE A-A'.svg in 05_Sezioni, oppure il file %s "
                 "nella cartella delle sezioni della %s" % (desc_tipo, scheda),
                 7, colore=QColor(150, 150, 150))
            avvisa("%s non trovata (tavola %d)" % (desc_tipo, k))
        # FOTO: i punti di ripresa del riquadro (fino a 2, i piu' vicini) ->
        # 04_Foto/FOTO-n.jpg; poi la colonna Foto della scheda o foto_<id>
        foto = []
        for f, _d in foto_in:
            n = numero_foto(foto_l, f)
            p = cerca_foto(n, cart_foto) if n else None
            if p:
                foto.append(("FOTO %s" % n, p))
            elif n:
                avvisa("punto di ripresa FOTO %s: nessun file FOTO-%s (o «%s.jpg», «FOTO_0%s»…) "
                       "in %s" % (n, n, n, n, ", ".join(c for c in cart_foto if c and
                                                        os.path.isdir(c)) or "04_Foto"))
            if len(foto) == 1:
                break
        if not foto:
            p = i.foto if (i.foto and os.path.isfile(i.foto)) else cerca_file(
                ["foto_%d" % i.id, "foto%d" % i.id, "%d" % i.id], cart_foto)
            if p:
                foto = [("FOTO %d" % k, p)]
        yf = y2 + tit_h + mezza + 3
        _lbl(layout, pag, x2, yf, col_w, tit_h,
             " - ".join(t for t, _ in foto) if foto else "FOTO", 9)
        _box(layout, pag, x2, yf + tit_h, col_w, mezza)
        if foto:
            w_f = (col_w - 2 - 2 * (len(foto) - 1)) / len(foto)
            for n_f, (_t, p) in enumerate(foto):
                p = foto_ritagliata(p, w_f, mezza - 2, cart_img)
                _immagine(layout, pag, x2 + 1 + n_f * (w_f + 2), yf + tit_h + 1,
                          w_f, mezza - 2, p)
        else:
            _lbl(layout, pag, x2, yf + tit_h, col_w, mezza,
                 "Foto da inserire: punto di ripresa nel riquadro con FOTO-n.jpg in "
                 "04_Foto, oppure foto_%d nella cartella foto della %s" % (i.id, scheda), 7,
                 colore=QColor(150, 150, 150))
            avvisa("foto dell'interferenza #%d non trovata" % i.id)
        _cartiglio(layout, pag, dati, "%d" % k, "1:%d" % s_pl, legenda_map=m_pl,
                   legenda_layers=[infra, pozz, arm, foto_c, sez_c, ferr, fascia_t, cippi,
                                   quote_l])

    # ---- particolari costruttivi: solo quelli delle lavorazioni presenti ----
    for n_pag, pezzi in enumerate(impag_pc):
        pag = 1 + len(tavole) + n_pag
        _box(layout, pag, MARGINE, MARGINE, area_w, area_h, 0.3)
        # blocco centrato nella pagina
        larg = max((x + w for _, _, x, _, w, _ in pezzi), default=0)
        alt = max((y + h for _, _, _, y, _, h in pezzi), default=0)
        ox = MARGINE + (area_w - larg) / 2.0
        oy = MARGINE + (area_h - alt) / 2.0
        for chiave, f, x, y, w, h in pezzi:
            _immagine(layout, pag, ox + x, oy + y, w, h, f)
        _cartiglio(layout, pag, dati, "PC" + (" %d" % (n_pag + 1) if pagine_pc > 1 else ""),
                   "NON IN SCALA")
    del scala_pc

    mgr.addLayout(layout)
    try:
        etichette_fine(project, ist.nome_base)
    except Exception:  # noqa: BLE001
        pass
    if not esporta or SOLO_ETICHETTE:
        return True
    os.makedirs(os.path.dirname(out_pdf) or ".", exist_ok=True)
    exp = QgsLayoutExporter(layout)
    s = QgsLayoutExporter.PdfExportSettings()
    s.dpi = 200
    # testo vero nel PDF (selezionabile, piu' leggero) invece che tracciati
    try:
        from qgis.core import Qgis
        s.textRenderFormat = Qgis.TextRenderFormat.AlwaysText
    except Exception:  # noqa: BLE001
        try:
            from qgis.core import QgsRenderContext
            s.textRenderFormat = QgsRenderContext.TextFormatAlwaysText
        except Exception:  # noqa: BLE001
            pass
    r = exp.exportToPdf(out_pdf, s)
    return r == QgsLayoutExporter.Success and os.path.isfile(out_pdf)


# --------------------------------------------------------------------------- #
#  Etichette della PL spostabili in mappa (tutte le schede istanze)
# --------------------------------------------------------------------------- #
NOME_ETICH_MAN = "Etichette PL (spostabili)"
# «Prepara le etichette in mappa»: le PL si calcolano ma non si esportano
SOLO_ETICHETTE = False
# ente della scheda che sta generando (riga_genera): le etichette di RFI
# vanno nel layer «Etichette PL (spostabili) - RFI», nel gruppo RFI
ENTE_CORRENTE = ""


def nome_etich(ente=None):
    return nome_layer_ente(NOME_ETICH_MAN, ENTE_CORRENTE if ente is None else ente)


def _stile_etichette_spostabili(l):
    """Punto dell'etichetta + filo di richiamo fino all'elemento (ax, ay),
    così in mappa si vede a cosa si riferisce ogni etichetta."""
    sym = QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "255,255,255,200", "outline_color": "200,0,0,255",
         "size": "1.6"})
    try:
        from qgis.core import QgsGeometryGeneratorSymbolLayer, QgsLineSymbol
        gg = QgsGeometryGeneratorSymbolLayer.create(
            {"geometryModifier": 'make_line($geometry, make_point("ax", "ay"))'})
        try:
            from qgis.core import Qgis
            gg.setSymbolType(Qgis.SymbolType.Line)
        except Exception:  # noqa: BLE001
            from qgis.core import QgsSymbol
            gg.setSymbolType(QgsSymbol.Line)
        gg.setSubSymbol(QgsLineSymbol.createSimple({"color": "200,0,0,255", "width": "0.25"}))
        sym.insertSymbolLayer(0, gg)
    except Exception:  # noqa: BLE001
        pass
    l.setRenderer(QgsSingleSymbolRenderer(sym))
    # testo CENTRATO sul punto (il filo parte da lì) e sempre visibile, anche
    # sopra altre scritte: prima QGIS lo spostava o lo nascondeva
    from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, \
        QgsVectorLayerSimpleLabeling
    pal = QgsPalLayerSettings()
    # il testo è salvato in HTML (km in nero, lavorazioni in rosso, una <div>
    # per riga): senza «formattazione HTML» in mappa si vedeva il codice
    # (<div><span style=…>). I testi semplici vanno a capo riga per riga.
    pal.isExpression = True
    pal.fieldName = ("CASE WHEN left(trim(\"testo\"), 4) = '<div' THEN \"testo\" ELSE "
                     "'<div>' || replace(replace(replace(replace(coalesce(\"testo\", ''), "
                     "'&', '&amp;'), '<', '&lt;'), '>', '&gt;'), '\\n', '</div><div>') || "
                     "'</div>' END")
    tf = QgsTextFormat()
    tf.setFont(QFont("Arial", 7))
    tf.setSize(7)
    tf.setColor(QColor(200, 0, 0))
    try:
        tf.setAllowHtmlFormatting(True)
    except Exception:  # noqa: BLE001
        pal.isExpression = False
        pal.fieldName = "testo"
    buf = QgsTextBufferSettings()
    buf.setEnabled(True)
    buf.setSize(0.8)
    tf.setBuffer(buf)
    pal.setFormat(tf)
    try:
        from qgis.core import Qgis
        pal.placement = Qgis.LabelPlacement.OverPoint
    except Exception:  # noqa: BLE001
        pass
    try:
        from qgis.core import Qgis
        pal.placementSettings().setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapAtNoCost)
    except Exception:  # noqa: BLE001
        try:
            pal.displayAll = True
        except Exception:  # noqa: BLE001
            pass
    try:
        pal.obstacleSettings().setIsObstacle(False)
    except Exception:  # noqa: BLE001
        pass
    try:
        pal.zIndex = 50
    except Exception:  # noqa: BLE001
        pass
    # il testo sta CENTRATO sopra il punto (posizione «sopra il punto», come
    # in stampa): niente coordinate calcolate, che con un CRS di progetto
    # diverso da quello del layer lo spostavano lontano dal filo
    l.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    l.setLabelsEnabled(True)
    l.triggerRepaint()


def aggiorna_stile_etichette(project=None):
    """Riapplica lo stile attuale al layer «Etichette PL (spostabili)» già nel
    progetto. Il progetto salvato con una versione precedente si portava dietro
    il vecchio stile (testo in una posizione calcolata): spostando il punto il
    filo si muoveva e il testo no. Ritorna quanti layer ha aggiornato."""
    from qgis.core import QgsProject
    project = project or QgsProject.instance()
    n = 0
    for l in [x for x in project.mapLayers().values()
              if x.name() == NOME_ETICH_MAN or x.name().startswith(NOME_ETICH_MAN + " - ")]:
        try:
            _stile_etichette_spostabili(l)
            n += 1
        except Exception:  # noqa: BLE001
            pass
    return n


_COLLEGATO = []


def collega_aggiornamento_stile():
    """Lo stile si aggiorna anche a ogni apertura di un progetto."""
    if _COLLEGATO:
        return
    from qgis.core import QgsProject
    try:
        QgsProject.instance().readProject.connect(lambda *_a: aggiorna_stile_etichette())
        _COLLEGATO.append(True)
    except Exception:  # noqa: BLE001
        pass


# etichette usate nella generazione in corso, per istanza: alla fine si
# cancellano le altre di quell'istanza (vecchie: niente doppioni)
_IN_USO = {}


def etichette_inizio(istanza):
    _IN_USO[str(istanza)] = set()


def etichette_fine(project, istanza):
    """Toglie dal layer le etichette dell'istanza non usate in questa
    generazione (km cambiati, tavole rifatte): prima restavano e si
    vedevano doppie."""
    usate = _IN_USO.pop(str(istanza), None)
    if usate is None:
        return 0
    lyr = next(iter(project.mapLayersByName(nome_etich())), None)
    if lyr is None:
        return 0
    from qgis.core import QgsFeatureRequest
    filtro = "\"istanza\" = '%s'" % str(istanza).replace("'", "''")
    via = [f.id() for f in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(filtro))
           if f.id() not in usate]
    if via:
        lyr.dataProvider().deleteFeatures(via)
        lyr.triggerRepaint()
    return len(via)


def _layer_etichette_spostabili(project):
    """Layer di punti con le etichette delle PL generate (uno per etichetta,
    alla posizione in tavola). Spostando un punto in mappa, alla prossima
    generazione l'etichetta va lì. Su file accanto al progetto."""
    nome = nome_etich()
    ente = ENTE_CORRENTE if ENTE_CORRENTE in ENTI_LAYER else ""
    for l in project.mapLayersByName(nome):
        _stile_etichette_spostabili(l)      # anche sui layer già creati: con i fili
        return l
    home = project.homePath()
    if not home or not project.fileName():
        return None
    from qgis.core import (QgsFields, QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings,
                           QgsVectorFileWriter, QgsVectorLayerSimpleLabeling, QgsWkbTypes)
    cart = os.path.join(home, "01_File shp")
    os.makedirs(cart, exist_ok=True)
    gpkg = os.path.join(cart, "FTTH_etichette_PL%s.gpkg" % (
        ("_" + ENTI_LAYER[ente]) if ente else ""))
    if not os.path.isfile(gpkg):
        campi = QgsFields()
        for n, t in (("istanza", QVariant.String), ("testo", QVariant.String),
                     ("ax", QVariant.Double), ("ay", QVariant.Double),
                     ("ox", QVariant.Double), ("oy", QVariant.Double)):
            campi.append(QgsField(n, t))
        opz = QgsVectorFileWriter.SaveVectorOptions()
        opz.driverName = "GPKG"
        opz.layerName = "etichette_pl"
        w = QgsVectorFileWriter.create(gpkg, campi, QgsWkbTypes.Point,
                                       QgsCoordinateReferenceSystem("EPSG:4326"),
                                       project.transformContext(), opz)
        del w
    l = QgsVectorLayer("%s|layername=etichette_pl" % gpkg, nome, "ogr")
    if not l.isValid():
        return None
    _stile_etichette_spostabili(l)
    project.addMapLayer(l, False)
    if ente:
        # le etichette già spostate nel layer comune passano qui istanza per
        # istanza (posizioni_manuali)
        _gr().gruppo_sezione(project.layerTreeRoot(), ente).insertLayer(0, l)
    else:
        project.layerTreeRoot().insertLayer(0, l)
    return l


def sposta_elementi(sorgenti, dest, scegli):
    """Sposta in `dest` gli elementi dei layer `sorgenti` per cui
    scegli(feature) è vero (stessi campi per nome, geometria riproiettata) e
    li toglie dalle sorgenti. Ritorna quanti ne ha spostati."""
    from qgis.core import QgsFeature, QgsProject
    n = 0
    for src in sorgenti or []:
        if src is None or src.id() == dest.id() or src.isEditable():
            continue
        tr = QgsCoordinateTransform(src.crs(), dest.crs(), QgsProject.instance())
        nuovi, via = [], []
        for f in src.getFeatures():
            try:
                if not scegli(f):
                    continue
            except Exception:  # noqa: BLE001
                continue
            nf = QgsFeature(dest.fields())
            g = QgsGeometry(f.geometry())
            if not g.isEmpty():
                g.transform(tr)
            nf.setGeometry(g)
            for c in dest.fields().names():
                k = src.fields().indexOf(c)
                if k >= 0 and c.lower() != "fid":      # la chiave del GeoPackage no
                    nf[c] = f[k]
            nuovi.append(nf)
            via.append(f.id())
        if nuovi and dest.dataProvider().addFeatures(nuovi)[0]:
            src.dataProvider().deleteFeatures(via)
            src.triggerRepaint()
            n += len(nuovi)
    dest.updateExtents()
    dest.triggerRepaint()
    return n


def posizioni_manuali(project, istanza, voci):
    """voci = [(testo, ax, ay, px, py)] in EPSG:4326 (ancora e posizione
    calcolata). Ritorna [(px, py)]: dove l'utente ha spostato il punto nel
    layer «Etichette PL (spostabili)» vale la sua posizione, altrimenti
    quella calcolata (che si scrive nel layer per la prossima volta)."""
    try:
        lyr = _layer_etichette_spostabili(project)
    except Exception:  # noqa: BLE001
        lyr = None
    if lyr is not None and lyr.name() != NOME_ETICH_MAN:
        # layer dell'ente: le etichette di questa istanza ancora nel layer
        # comune (progetti di prima) passano qui, con le posizioni spostate
        try:
            sposta_elementi(project.mapLayersByName(NOME_ETICH_MAN), lyr,
                            lambda f: str(f["istanza"]) == str(istanza))
        except Exception:  # noqa: BLE001
            pass
    if lyr is None or not voci:
        return [(px, py) for _t, _ax, _ay, px, py in voci]
    from qgis.core import QgsFeatureRequest
    esist = {}
    filtro = "\"istanza\" = '%s'" % str(istanza).replace("'", "''")
    for f in lyr.getFeatures(QgsFeatureRequest().setFilterExpression(filtro)):
        try:
            esist[(f["testo"], round(float(f["ax"]), 6), round(float(f["ay"]), 6))] = f
        except (TypeError, ValueError):
            pass
    out, nuovi, geo, att = [], [], {}, {}
    i_ox, i_oy = lyr.fields().indexOf("ox"), lyr.fields().indexOf("oy")
    for testo, ax, ay, px, py in voci:
        f = esist.get((testo, round(ax, 6), round(ay, 6)))
        if f is not None and f.hasGeometry():
            p = f.geometry().asPoint()
            try:
                spostata = abs(p.x() - float(f["ox"])) > 1e-7 or abs(p.y() - float(f["oy"])) > 1e-7
            except (TypeError, ValueError):
                spostata = False
            _IN_USO.setdefault(str(istanza), set()).add(f.id())
            if spostata:
                out.append((p.x(), p.y()))
                continue
            geo[f.id()] = QgsGeometry.fromPointXY(QgsPointXY(px, py))
            att[f.id()] = {i_ox: px, i_oy: py}
            out.append((px, py))
            continue
        k_ = (testo, round(ax, 6), round(ay, 6))
        gia = next((x for x in nuovi if (x["testo"], round(x["ax"], 6), round(x["ay"], 6)) == k_),
                   None)
        if gia is not None:          # stessa etichetta in due tavole: un punto
            out.append((gia["ox"], gia["oy"]))
            continue
        g = QgsFeature(lyr.fields())
        g.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(px, py)))
        for n, v in (("istanza", istanza), ("testo", testo), ("ax", ax), ("ay", ay),
                     ("ox", px), ("oy", py)):
            g[n] = v
        nuovi.append(g)
        out.append((px, py))
    pr = lyr.dataProvider()
    if geo:
        pr.changeGeometryValues(geo)
        pr.changeAttributeValues(att)
    if nuovi:
        ok_, aggiunte = pr.addFeatures(nuovi)
        for g in aggiunte or []:
            _IN_USO.setdefault(str(istanza), set()).add(g.id())
    lyr.triggerRepaint()
    return out


def foto_della_sezione(project, foto_l, sez_l, crs, sez_fisse, vis, centro, nomi_ist):
    """UNA foto per tavola: Sezione A-A' -> FOTO 1, B-B' -> FOTO 2, ...; se
    quel numero non c'è, la foto più vicina alla sezione (entro 150 m);
    senza sezione la più vicina al centro della tavola."""
    if foto_l is None:
        return []
    # regola: Sezione A-A' -> FOTO 1, B-B' -> FOTO 2, ... (ovunque sia il punto)
    if sez_fisse and sez_l is not None:
        sig = (sigla_sezione(sez_l, sez_fisse[0]) or "").strip().upper()
        if sig[:1].isalpha():
            n_voluto = str(ord(sig[0]) - ord("A") + 1)
            c_ist = _campo(foto_l, CAMPO_ISTANZA)
            # fra le foto con quel numero, la piu' vicina alla sezione (prima la
            # prima trovata, anche in un'altra zona del progetto)
            gs = QgsGeometry(sez_fisse[0].geometry())
            gs.transform(QgsCoordinateTransform(sez_l.crs(), crs, project))
            a_f = QgsCoordinateTransform(foto_l.crs(), crs, project)
            cand_n = []
            for f in foto_l.getFeatures():
                if f.hasGeometry() and numero_foto(foto_l, f) == n_voluto and \
                        (not c_ist or istanza_corrisponde(f[c_ist], nomi_ist)):
                    gf = QgsGeometry(f.geometry())
                    gf.transform(a_f)
                    cand_n.append((f, gf.distance(gs)))
            if cand_n:
                return [min(cand_n, key=lambda x: x[1])]
    if sez_fisse and sez_l is not None:
        g = QgsGeometry(sez_fisse[0].geometry())
        g.transform(QgsCoordinateTransform(sez_l.crs(), crs, project))
        c = g.centroid().asPoint()
        r = QgsRectangle(vis)
        r.combineExtentWith(g.boundingBox())
        r.grow(150)
        cand = feature_nel_riquadro(project, foto_l, crs, r, QgsPointXY(c), istanza=nomi_ist)
    else:
        cand = feature_nel_riquadro(project, foto_l, crs, vis, centro, istanza=nomi_ist)
    scelte = [(f, d) for f, d in cand if numero_foto(foto_l, f)][:1]
    if scelte:
        return scelte
    # nessun punto vicino: la foto dell'istanza più vicina alla tavola, ovunque
    # sia (prima la tavola restava senza foto)
    c_ist = _campo(foto_l, CAMPO_ISTANZA)
    a_crs = QgsCoordinateTransform(foto_l.crs(), crs, project)
    pc = QgsGeometry.fromPointXY(QgsPointXY(centro))
    tutte = []
    for f in foto_l.getFeatures():
        if not f.hasGeometry() or not numero_foto(foto_l, f):
            continue
        if c_ist and not istanza_corrisponde(f[c_ist], nomi_ist):
            continue
        g = QgsGeometry(f.geometry())
        g.transform(a_crs)
        tutte.append((f, g.distance(pc)))
    tutte.sort(key=lambda x: x[1])
    return tutte[:1]


def assegna_sezioni(project, sez_l, crs, riquadri, centri, nomi_ist):
    """Per ogni riquadro le sue sezioni: ognuna va in UNA sola tavola, quella
    col centro più vicino fra quelle che la inquadrano (prima una sezione
    fra due interferenze vicine finiva in due tavole e ne creava altre)."""
    out = [[] for _ in riquadri]
    if sez_l is None:
        return out
    scelta = {}
    for k, (q, c) in enumerate(zip(riquadri, centri)):
        for f, d in feature_nel_riquadro(project, sez_l, crs, q, c, istanza=nomi_ist):
            if not sigla_sezione(sez_l, f):
                continue
            if f.id() not in scelta or d < scelta[f.id()][1]:
                scelta[f.id()] = (k, d, f)
    for k, d, f in scelta.values():
        out[k].append((d, f))
    # in ordine di nome (A-A', B-B', ...): prima per distanza e B-B' poteva
    # uscire prima di A-A'
    return [ordina_sezioni(sez_l, [f for _d, f in a]) for a in out]


def chiave_sigla(sigla):
    """Ordine naturale delle sezioni: A-A' < B-B' < ... < Z-Z' < AA-AA', 2 < 10."""
    import re as _re
    s = (sigla or "").upper().split("-")[0].strip()
    parti = _re.findall(r"\d+|[A-Z]+", s)
    return (sigla is None or s == "", len(parti[0]) if parti and parti[0].isalpha() else 0,
            [(0, int(x), "") if x.isdigit() else (1, 0, x) for x in parti])


def ordina_sezioni(sez_l, feats):
    """Le sezioni ordinate per sigla (A-A' prima di B-B')."""
    return sorted(feats, key=lambda f: chiave_sigla(sigla_sezione(sez_l, f)))


def ha_istanza(lyr, f):
    """La sezione / foto ha il campo ISTANZA compilato."""
    c = _campo(lyr, CAMPO_ISTANZA)
    if not c:
        return False
    v = f[c]
    return v is not None and str(v).strip() not in ("", "NULL")


def rotazione_con_strumento(lyr, campo="Rotazione"):
    """Coni delle foto ruotabili con lo strumento di QGIS «Ruota simboli
    puntuali»: lo strumento vuole l'angolo del simbolo legato al CAMPO, mentre
    lo stile usava espressioni («Rotazione + 90»). Si passa al campo
    semplice; i valori già scritti crescono di 90° così i coni non cambiano
    direzione. Una volta sola per layer (proprietà ftth/rotazione_v2)."""
    from qgis.core import QgsExpression, QgsProperty, QgsRenderContext, QgsSymbolLayer
    k = lyr.fields().indexOf(campo)
    if k < 0 or lyr.renderer() is None or lyr.customProperty("ftth/rotazione_v2"):
        return False
    simboli = [s for s in lyr.renderer().symbols(QgsRenderContext())
               if isinstance(s, QgsMarkerSymbol)]
    if not simboli:
        return False
    aggiungi = 0.0
    for s in simboli:
        for sl in s.symbolLayers():
            pr = sl.dataDefinedProperties().property(QgsSymbolLayer.PropertyAngle)
            if pr is None or not pr.isActive():
                continue
            testo = pr.expressionString() if pr.propertyType() == QgsProperty.ExpressionBasedProperty \
                else ('"%s"' % pr.field())
            if campo.lower() not in testo.lower():
                continue
            off = QgsExpression(testo.replace('"%s"' % campo, "0")).evaluate()
            try:
                off = float(off)
            except (TypeError, ValueError):
                off = 0.0
            if not aggiungi:
                aggiungi = off       # la base comune (era «+ 90»)
            sl.setAngle(off - aggiungi)
            sl.dataDefinedProperties().setProperty(QgsSymbolLayer.PropertyAngle, QgsProperty())
        s.setDataDefinedAngle(QgsProperty.fromField(campo))
    if aggiungi:
        cambi = {}
        for f in lyr.getFeatures():
            v = f[campo]
            if v is not None and str(v) != "NULL":
                try:
                    cambi[f.id()] = {k: (float(v) + aggiungi) % 360}
                except (TypeError, ValueError):
                    pass
        if cambi:
            if lyr.isEditable():
                for fid, a in cambi.items():
                    lyr.changeAttributeValue(fid, k, a[k])
            else:
                lyr.dataProvider().changeAttributeValues(cambi)
    lyr.setCustomProperty("ftth/rotazione_v2", True)
    lyr.triggerRepaint()
    return True


def numerazione_per_istanza(lyr):
    """Nuovi punti foto e linee di sezione: numero e lettera ripartono per ogni
    istanza (FOTO 1, A-A' anche nella seconda istanza). L'istanza proposta è
    quella dell'ultimo elemento disegnato."""
    from qgis.core import QgsDefaultValue
    k_ist = lyr.fields().indexOf(CAMPO_ISTANZA)
    if k_ist < 0:
        return
    ultima = ("attribute(get_feature_by_id(@layer, aggregate(@layer, 'max', $id)), '%s')"
              % CAMPO_ISTANZA)
    lyr.setDefaultValueDefinition(k_ist, QgsDefaultValue("coalesce(%s, '')" % ultima, False))
    stessa = "coalesce(\"%s\", '') = coalesce(%s, '')" % (CAMPO_ISTANZA, ultima)
    k_n = lyr.fields().indexOf("NumeroFoto")
    if k_n >= 0:
        lyr.setDefaultValueDefinition(k_n, QgsDefaultValue(
            "coalesce(aggregate(@layer, 'max', \"NumeroFoto\", filter:=%s), 0) + 1" % stessa,
            False))
    k_s = lyr.fields().indexOf("sezione")
    if k_s >= 0:
        lyr.setDefaultValueDefinition(k_s, QgsDefaultValue(
            "char(65 + coalesce(aggregate(@layer, 'count', $id, filter:=%s), 0))" % stessa,
            False))
