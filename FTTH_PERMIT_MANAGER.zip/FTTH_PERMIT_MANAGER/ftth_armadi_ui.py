# -*- coding: utf-8 -*-
"""Verifica armadi: voce del plugin (Comune › Verifica armadi) e pannello
agganciato alla mappa di QGIS.

Il pannello scorre gli armadi del layer, centra la mappa su ognuno, apre
Street View / Google Maps nel browser sul punto esatto e
registra l'esito (Fattibile, Non fattibile, Da spostare) con una nota. Gli
esiti stanno nel PROGETTO (non nel layer): si salvano col progetto.
"""
import os

from qgis.PyQt.QtCore import Qt, QUrl
from qgis.PyQt.QtGui import QColor, QDesktopServices
from qgis.PyQt.QtWidgets import (
    QButtonGroup, QComboBox, QDockWidget, QFileDialog, QHBoxLayout, QLabel, QPlainTextEdit,
    QPushButton, QRadioButton, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsMapLayerProxyModel, QgsPointXY,
    QgsProject, QgsRectangle, QgsWkbTypes,
)
from qgis.gui import QgsMapLayerComboBox, QgsMapToolEmitPoint, QgsVertexMarker


def _ar():
    try:
        from . import ftth_armadi as AR
    except ImportError:
        import ftth_armadi as AR
    return AR


def _carica_esiti(project):
    AR = _ar()
    testo, _ok = project.readEntry(AR.PRJ_SCOPE, AR.PRJ_CHIAVE, "")
    return AR.esiti_da_testo(testo)


def _salva_esiti(project, esiti):
    AR = _ar()
    project.writeEntry(AR.PRJ_SCOPE, AR.PRJ_CHIAVE, AR.esiti_in_testo(esiti))


def leggi_armadi(project, lyr):
    """[{'chiave', 'nome', 'indirizzo', 'lat', 'lon', 'fid', 'punto'}] dal
    layer (punto nel CRS del progetto, per la mappa)."""
    AR = _ar()
    if lyr is None:
        return []
    nomi = [f.name() for f in lyr.fields()]
    c_id = AR.scegli_campo(nomi, AR.CAMPI_ID)
    c_ind = AR.scegli_campo(nomi, AR.CAMPI_INDIRIZZO)
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    tr = QgsCoordinateTransform(lyr.crs(), wgs, project)
    tr_p = QgsCoordinateTransform(lyr.crs(), project.crs(), project)
    out = []
    for f in lyr.getFeatures():
        g = f.geometry()
        if g is None or g.isEmpty():
            continue
        p = g.centroid().asPoint() if g.type() != QgsWkbTypes.PointGeometry or \
            g.isMultipart() else g.asPoint()
        w = tr.transform(QgsPointXY(p))
        nome_v = f[c_id] if c_id else None
        chiave = AR.chiave_armadio(nome_v, f.id())
        if chiave.startswith("fid:"):
            nome = "Armadio %s" % f.id()
        elif chiave.isdigit():
            # AREA_AO contiene solo il numero (201, 204...): «Armadio 201»
            nome = "Armadio %s" % chiave
        else:
            nome = chiave
        ind = f[c_ind] if c_ind else ""
        out.append({"chiave": chiave, "nome": nome,
                    "indirizzo": "" if ind in (None, "NULL") else str(ind),
                    "lat": w.y(), "lon": w.x(), "fid": f.id(),
                    "punto": tr_p.transform(QgsPointXY(p))})
    out.sort(key=lambda a: a["nome"].lower())
    return out


class PannelloArmadi(QDockWidget):
    """Pannello «Verifica armadi» agganciato alla mappa."""

    def __init__(self, iface, project, lyr, parent=None):
        super().__init__("Verifica armadi", parent)
        self.setObjectName("FTTHVerificaArmadi")
        self.iface, self.project, self.lyr = iface, project, lyr
        self.armadi = leggi_armadi(project, lyr)
        self.esiti = _carica_esiti(project)
        self.k = 0
        self._marker = None
        self._marker_tutti = []
        self._strumento = None
        AR = _ar()
        w = QWidget()
        v = QVBoxLayout(w)
        r = QHBoxLayout()
        self.b_prec = QPushButton("◀")
        self.b_prec.setFixedWidth(34)
        self.b_prec.clicked.connect(lambda: self.vai(self.k - 1))
        self.cb = QComboBox()
        for a in self.armadi:
            self.cb.addItem(a["nome"])
        self.cb.currentIndexChanged.connect(self.vai)
        self.b_succ = QPushButton("▶")
        self.b_succ.setFixedWidth(34)
        self.b_succ.clicked.connect(lambda: self.vai(self.k + 1))
        r.addWidget(self.b_prec)
        r.addWidget(self.cb, 1)
        r.addWidget(self.b_succ)
        v.addLayout(r)
        self.lbl = QLabel("")
        self.lbl.setWordWrap(True)
        self.lbl.setTextInteractionFlags(Qt.TextSelectableByMouse)
        v.addWidget(self.lbl)
        b = QPushButton("Scegli l'armadio sulla mappa")
        b.setCheckable(True)
        b.toggled.connect(self._strumento_mappa)
        self.b_mappa = b
        v.addWidget(b)

        # posizione: quella del progetto o quella aggiornata (armadio spostato)
        r = QHBoxLayout()
        r.addWidget(QLabel("Coordinate:"))
        self.cb_pos = QComboBox()
        self.cb_pos.addItem("posizione da progetto", "progetto")
        self.cb_pos.addItem("posizione aggiornata", "aggiornata")
        self.cb_pos.setToolTip("Quale posizione mostrare, centrare e aprire in Street View. "
                               "«aggiornata» c'è dopo «Indica la nuova posizione».")
        self.cb_pos.currentIndexChanged.connect(lambda *_: self.vai(self.k))
        r.addWidget(self.cb_pos, 1)
        v.addLayout(r)
        r = QHBoxLayout()
        self.b_nuova = QPushButton("Indica la nuova posizione sulla mappa")
        self.b_nuova.setCheckable(True)
        self.b_nuova.setToolTip("Se l'armadio va spostato: attiva e clicca sulla mappa il punto "
                                "nuovo. Le coordinate aggiornate vanno nell'elenco Excel accanto "
                                "a quelle del progetto.")
        self.b_nuova.toggled.connect(self._strumento_nuova)
        r.addWidget(self.b_nuova, 1)
        b_togli = QPushButton("Togli")
        b_togli.setToolTip("Toglie la posizione aggiornata di questo armadio.")
        b_togli.clicked.connect(self._togli_nuova)
        r.addWidget(b_togli)
        v.addLayout(r)

        r = QHBoxLayout()
        for testo, fn in (("Street View", AR.link_streetview), ("Google Maps", AR.link_mappa)):
            bb = QPushButton(testo)
            if testo == "Street View":
                bb.setProperty("primario", True)
            bb.clicked.connect(lambda _c=False, f=fn: self._apri(f))
            r.addWidget(bb)
        v.addLayout(r)

        v.addWidget(QLabel("<b>Esito della verifica</b>"))
        self.gruppo = QButtonGroup(self)
        for n, e in enumerate(AR.ESITI):
            rb = QRadioButton(e)
            rb.setStyleSheet("QRadioButton { color: %s; }" % AR.COLORI[e])
            self.gruppo.addButton(rb, n)
            v.addWidget(rb)
        self.gruppo.buttonClicked.connect(self._esito_cambiato)
        v.addWidget(QLabel("Note"))
        self.nota = QPlainTextEdit()
        self.nota.setMaximumHeight(90)
        self.nota.setPlaceholderText("Marciapiede stretto, passo carrabile, spostare di 5 m…")
        self.nota.textChanged.connect(self._nota_cambiata)
        v.addWidget(self.nota)
        self.lbl_riep = QLabel("")
        self.lbl_riep.setWordWrap(True)
        v.addWidget(self.lbl_riep)
        b = QPushButton("Esporta elenco Excel")
        b.setToolTip("File .xlsx: per ogni armadio posizione da progetto e posizione "
                     "aggiornata (lat, lon), esito, note e Street View.")
        b.clicked.connect(self.esporta_xlsx)
        v.addWidget(b)
        v.addStretch(1)
        try:
            try:
                from . import ftth_stile as _stile
            except ImportError:
                import ftth_stile as _stile
            w.setStyleSheet(_stile.foglio_di_stile())
            _stile.delegati_combo(w)
        except Exception:  # noqa: BLE001
            pass
        self.setWidget(w)
        self._disegna_tutti()
        if self.armadi:
            self.vai(0)
        else:
            self.lbl.setText("Nessun armadio nel layer scelto.")

    # ---------------------------------------------------------- navigazione
    def vai(self, k):
        if not self.armadi:
            return
        k = max(0, min(int(k), len(self.armadi) - 1))
        self.k = k
        if self.cb.currentIndex() != k:
            self.cb.blockSignals(True)
            self.cb.setCurrentIndex(k)
            self.cb.blockSignals(False)
        a = self.armadi[k]
        e = self.esiti.get(a["chiave"]) or {}
        AR = _ar()
        nuova = e.get("nuova")
        self.lbl.setText("<b>%s</b> (%d di %d)<br>%s<br>Da progetto: %s<br>Aggiornata: %s" % (
            a["nome"], k + 1, len(self.armadi), a["indirizzo"] or "indirizzo non indicato",
            AR.testo_coordinate(a["lat"], a["lon"]),
            AR.testo_coordinate(*nuova) if nuova else "—"))
        self.gruppo.button(AR.ESITI.index(e.get("esito", AR.ESITO_INIZIALE))).setChecked(True)
        self.nota.blockSignals(True)
        self.nota.setPlainText(e.get("nota", ""))
        self.nota.blockSignals(False)
        self._centra(a)
        self._aggiorna_riepilogo()

    def _pos_wgs(self, a):
        """(lat, lon) della posizione scelta nel menu (aggiornata se c'è)."""
        nuova = (self.esiti.get(a["chiave"]) or {}).get("nuova")
        if self.cb_pos.currentData() == "aggiornata" and nuova:
            return nuova[0], nuova[1]
        return a["lat"], a["lon"]

    def _centra(self, a):
        canvas = self.iface.mapCanvas() if self.iface else None
        if canvas is None:
            return
        p = a["punto"]
        lat, lon = self._pos_wgs(a)
        if (lat, lon) != (a["lat"], a["lon"]):
            p = QgsCoordinateTransform(QgsCoordinateReferenceSystem("EPSG:4326"),
                                       self.project.crs(), self.project).transform(
                QgsPointXY(lon, lat))
        lato = 40.0 if self.project.crs().isGeographic() is False else 0.0004
        canvas.setExtent(QgsRectangle(p.x() - lato, p.y() - lato, p.x() + lato, p.y() + lato))
        canvas.refresh()
        if self._marker is None:
            self._marker = QgsVertexMarker(canvas)
            self._marker.setIconType(QgsVertexMarker.ICON_CIRCLE)
            self._marker.setIconSize(26)
            self._marker.setPenWidth(3)
            self._marker.setColor(QColor("#031B52"))
        self._marker.setCenter(p)

    def _disegna_tutti(self):
        canvas = self.iface.mapCanvas() if self.iface else None
        if canvas is None:
            return
        AR = _ar()
        for m in self._marker_tutti:
            canvas.scene().removeItem(m)
        self._marker_tutti = []
        for a in self.armadi:
            m = QgsVertexMarker(canvas)
            m.setIconType(QgsVertexMarker.ICON_BOX)
            m.setIconSize(12)
            m.setPenWidth(3)
            e = (self.esiti.get(a["chiave"]) or {}).get("esito", AR.ESITO_INIZIALE)
            m.setColor(QColor(AR.COLORI[e]))
            m.setCenter(a["punto"])
            self._marker_tutti.append(m)

    # --------------------------------------------------------------- azioni
    def _apri(self, fn):
        if self.armadi:
            lat, lon = self._pos_wgs(self.armadi[self.k])
            QDesktopServices.openUrl(QUrl(fn(lat, lon)))

    def _registra(self, esito=None, nota=None):
        if not self.armadi:
            return
        AR = _ar()
        a = self.armadi[self.k]
        e = dict(self.esiti.get(a["chiave"]) or {"esito": AR.ESITO_INIZIALE, "nota": ""})
        if esito is not None:
            e["esito"] = esito
        if nota is not None:
            e["nota"] = nota
        self.esiti[a["chiave"]] = e
        _salva_esiti(self.project, self.esiti)
        if self.k < len(self._marker_tutti):
            self._marker_tutti[self.k].setColor(QColor(AR.COLORI[e["esito"]]))
        self._aggiorna_riepilogo()

    def _esito_cambiato(self, bottone):
        self._registra(esito=bottone.text())

    def _nota_cambiata(self):
        self._registra(nota=self.nota.toPlainText())

    def _aggiorna_riepilogo(self):
        AR = _ar()
        r = AR.riepilogo([a["chiave"] for a in self.armadi], self.esiti)
        self.lbl_riep.setText(" · ".join(
            "<span style='color:%s'>%s %d</span>" % (AR.COLORI[e], e, n) for e, n in r.items()))

    def _strumento_mappa(self, attivo):
        canvas = self.iface.mapCanvas() if self.iface else None
        if canvas is None:
            return
        if attivo:
            self._strumento = QgsMapToolEmitPoint(canvas)
            self._strumento.canvasClicked.connect(self._clic_mappa)
            canvas.setMapTool(self._strumento)
        elif self._strumento is not None:
            canvas.unsetMapTool(self._strumento)
            self._strumento = None

    def _clic_mappa(self, punto, _bottone):
        if not self.armadi:
            return
        k = min(range(len(self.armadi)),
                key=lambda j: self.armadi[j]["punto"].sqrDist(punto))
        self.vai(k)

    # ------------------------------------------------- posizione aggiornata
    def _strumento_nuova(self, attivo):
        canvas = self.iface.mapCanvas() if self.iface else None
        if canvas is None:
            return
        if attivo:
            if self.b_mappa.isChecked():
                self.b_mappa.setChecked(False)
            self._strumento_n = QgsMapToolEmitPoint(canvas)
            self._strumento_n.canvasClicked.connect(self._clic_nuova)
            canvas.setMapTool(self._strumento_n)
        elif getattr(self, "_strumento_n", None) is not None:
            canvas.unsetMapTool(self._strumento_n)
            self._strumento_n = None

    def _clic_nuova(self, punto, _bottone):
        """Il punto cliccato (CRS della mappa) diventa la posizione aggiornata."""
        if not self.armadi:
            return
        canvas = self.iface.mapCanvas()
        w = QgsCoordinateTransform(canvas.mapSettings().destinationCrs(),
                                   QgsCoordinateReferenceSystem("EPSG:4326"),
                                   self.project).transform(punto)
        self.imposta_nuova(w.y(), w.x())
        self.b_nuova.setChecked(False)

    def imposta_nuova(self, lat, lon):
        AR = _ar()
        a = self.armadi[self.k]
        e = dict(self.esiti.get(a["chiave"]) or {"esito": AR.ESITO_INIZIALE, "nota": ""})
        e["nuova"] = [round(lat, 7), round(lon, 7)]
        if e.get("esito") == AR.ESITO_INIZIALE:
            e["esito"] = "Da spostare"
        self.esiti[a["chiave"]] = e
        _salva_esiti(self.project, self.esiti)
        self._disegna_tutti()
        self.cb_pos.setCurrentIndex(self.cb_pos.findData("aggiornata"))
        self.vai(self.k)

    def _togli_nuova(self):
        if not self.armadi:
            return
        a = self.armadi[self.k]
        e = self.esiti.get(a["chiave"]) or {}
        if e.pop("nuova", None) is not None:
            _salva_esiti(self.project, self.esiti)
            self.cb_pos.setCurrentIndex(self.cb_pos.findData("progetto"))
            self.vai(self.k)

    def esporta_xlsx(self):
        AR = _ar()
        base = self.project.homePath() or os.path.expanduser("~")
        p, _f = QFileDialog.getSaveFileName(self, "Esporta verifica armadi",
                                            os.path.join(base, "verifica_armadi.xlsx"),
                                            "Excel (*.xlsx)")
        if p:
            if not p.lower().endswith(".xlsx"):
                p += ".xlsx"
            n = AR.scrivi_xlsx(p, self.armadi, self.esiti)
            self.lbl_riep.setText(self.lbl_riep.text() + "<br>Esportati %d armadi in %s"
                                  % (n, p))

    esporta_csv = esporta_xlsx      # nome di prima

    def closeEvent(self, ev):
        canvas = self.iface.mapCanvas() if self.iface else None
        if canvas is not None:
            for m in self._marker_tutti + ([self._marker] if self._marker else []):
                canvas.scene().removeItem(m)
            for s in (self._strumento, getattr(self, "_strumento_n", None)):
                if s is not None:
                    canvas.unsetMapTool(s)
        self._marker_tutti, self._marker, self._strumento = [], None, None
        super().closeEvent(ev)


class ArmadiMixin:
    """Voce Comune › Verifica armadi del pannello del plugin."""

    def _tab_verifica_armadi(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Apre accanto alla mappa di QGIS il pannello «Verifica armadi»: scorri gli "
            "armadi (o cliccali sulla mappa), la mappa si centra su ognuno e con un clic "
            "apri Street View o Google Maps nel browser sul punto esatto. "
            "Per ogni armadio segni l'esito (Fattibile, Non fattibile, Da spostare) e una "
            "nota: sulla mappa gli armadi si colorano secondo l'esito. Gli esiti si "
            "salvano nel progetto, il layer degli armadi non viene toccato."))
        r = QHBoxLayout()
        r.addWidget(QLabel("Layer armadi:"))
        self.cb_va_layer = QgsMapLayerComboBox()
        self.cb_va_layer.setFilters(QgsMapLayerProxyModel.PointLayer)
        for l in QgsProject.instance().mapLayersByName("01_ARMADIO OTTICO"):
            self.cb_va_layer.setLayer(l)
            break
        r.addWidget(self.cb_va_layer, 1)
        v.addLayout(r)
        b = QPushButton("Apri il pannello Verifica armadi")
        b.setProperty("primario", True)
        b.clicked.connect(self._va_apri)
        v.addWidget(b)
        self.lbl_va = QLabel("")
        self.lbl_va.setWordWrap(True)
        v.addWidget(self.lbl_va)
        v.addStretch(1)
        return w

    def _va_apri(self):
        lyr = self.cb_va_layer.currentLayer()
        if lyr is None:
            self.lbl_va.setText("Scegli il layer degli armadi.")
            return
        vecchio = getattr(self, "_dock_armadi", None)
        if vecchio is not None:
            try:
                vecchio.close()
                self.iface.removeDockWidget(vecchio)
            except Exception:  # noqa: BLE001
                pass
        prj = QgsProject.instance()
        dock = PannelloArmadi(self.iface, prj, lyr, self.iface.mainWindow()
                              if self.iface else None)
        self._dock_armadi = dock
        if self.iface is not None:
            self.iface.addDockWidget(Qt.RightDockWidgetArea, dock)
        dock.show()
        dock.raise_()
        try:            # QGIS davanti alla finestra del plugin, se no il pannello non si vede
            from .ftth_verifica_rete_ui import _porta_in_primo_piano
            _porta_in_primo_piano(self, dock)
        except Exception:  # noqa: BLE001
            pass
        self.lbl_va.setText("Pannello aperto a destra della mappa di QGIS: %d armadi in «%s»."
                            % (len(dock.armadi), lyr.name()))
