# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Schema comune delle schede istanze (Strade, RFI, Acque, Soprintendenza,
Parchi): stessi 5 passi, stessi titoli, stessi pulsanti, così passando da una
scheda all'altra si ritrova la stessa grafica e lo stesso modo di dire le cose.

1) Comune
2) <oggetti> toccati dal progetto   (proposti in giallo: Conferma / Escludi)
3) Interferenze: controlla e conferma (tabella, mappa, conferma e vista per
   istanza; in Strade e RFI anche le chilometriche con i cippi)
4) Enti e destinatari                (ente per istanza + Comune in e.p.c.)
5) Foto, sezioni e generazione

Le opzioni usate di rado stanno sempre in un riquadro «Avanzate: …» chiuso,
in fondo al passo."""

OGGETTI = {
    "strade": "Strade toccate dal progetto",
    "rfi": "Ferrovie toccate dal progetto",
    "acque": "Corsi d'acqua toccati dal progetto",
    "sopr": "Aree vincolate toccate dal progetto",
    "parchi": "Aree protette e siti Natura 2000 toccati dal progetto",
}
TROVA = {
    "strade": "Trova le strade e gli enti",
    "rfi": "Trova le ferrovie e gli enti",
    "acque": "Trova i corsi d'acqua e gli enti",
    "sopr": "Trova le aree e gli enti",
    "parchi": "Trova le aree e gli enti",
}


def titolo(n: int, sezione: str) -> str:
    if n == 1:
        return "1) Comune"
    if n == 2:
        return "2) " + OGGETTI[sezione]
    if n == 3:
        return "3) Interferenze: controlla e conferma"
    if n == 4:
        return "4) Enti e destinatari"
    return "5) Foto e generazione" if sezione == "sopr" else "5) Foto, sezioni e generazione"


def percorso(sezione: str) -> str:
    """Promemoria dei passi, uguale in tutte le schede."""
    return ("Segui i passi da 1 a 5: 1) Comune → 2) %s → 3) interferenze → 4) enti e "
            "destinatari → 5) %s. Le opzioni usate di rado sono nei riquadri «Avanzate», "
            "chiusi." % (OGGETTI[sezione].split(" toccat")[0].lower(),
                         titolo(5, sezione)[3:].lower()))


def intro(dlg, sezione: str, testo: str = ""):
    """Riga d'apertura della scheda: cosa fa (breve) + i 5 passi."""
    return dlg._desc((testo.strip() + " " if testo else "") + percorso(sezione))


def primario(testo: str, slot=None, tip: str = ""):
    from qgis.PyQt.QtWidgets import QPushButton
    b = QPushButton(testo)
    b.setProperty("primario", True)
    if tip:
        b.setToolTip(tip)
    if slot is not None:
        b.clicked.connect(slot)
    return b


def proposte(dlg, conferma: str = "Conferma", escludi: str = "Escludi"):
    """Frase comune sotto la tabella del passo 2."""
    return dlg._desc("Gialle = proposte (rete del progetto vicina): per ognuna «%s» o «%s». "
                     "Verdi = confermate. Solo le confermate vanno al punto 3."
                     % (conferma, escludi))


def valida_riga(t, r, col_incl, col_valida, proposto):
    """Riga del passo 2 come in Strade: gialla = proposta (non spuntata) con
    «Conferma» / «Escludi», verde = confermata con «Annulla». Escludi toglie
    la spunta e nasconde la riga."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QBrush, QColor
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget
    it = t.item(r, col_incl)
    if it is None:
        return
    conf = it.checkState() == Qt.Checked
    fondo = QColor(214, 240, 214) if conf else (QColor(255, 243, 190) if proposto else None)
    t.blockSignals(True)
    for c in range(t.columnCount()):
        if c in (col_incl, col_valida):
            continue
        x = t.item(r, c)
        if x is not None:
            x.setBackground(QBrush(fondo) if fondo is not None else QBrush())
    t.blockSignals(False)
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(2, 0, 2, 0)
    h.setSpacing(4)
    if conf:
        lab = QLabel("✔ confermata")
        lab.setStyleSheet("color:#1b7a2f; font-weight:bold")
        h.addWidget(lab)
        b = QPushButton("Annulla")
        b.clicked.connect(lambda _c=False, i=it: i.setCheckState(Qt.Unchecked))
        h.addWidget(b)
    else:
        b_ok = QPushButton("Conferma")
        b_ok.clicked.connect(lambda _c=False, i=it: i.setCheckState(Qt.Checked))
        h.addWidget(b_ok)
        b_ko = QPushButton("Escludi")

        def _escludi(_c=False, i=it):
            i.setCheckState(Qt.Unchecked)
            t.setRowHidden(t.row(i), True)
        b_ko.clicked.connect(_escludi)
        h.addWidget(b_ko)
    h.addStretch()
    t.setCellWidget(r, col_valida, w)


def attiva_valida(t, col_incl, col_valida, proposto_fn):
    """Colonna «Valida» subito dopo la spunta; ogni cambio di spunta
    ricolora la riga e cambia i pulsanti."""
    t.horizontalHeader().moveSection(col_valida, col_incl + 1)
    t.itemChanged.connect(
        lambda it: it.column() == col_incl and
        valida_riga(t, it.row(), col_incl, col_valida, proposto_fn(it.row())))


def valida_interferenze(t, col_incl):
    """Tabella delle interferenze (passo 3): colonna «Valida» con «Escludi»
    su ogni riga (toglie la spunta e nasconde la riga) e «Conferma» sulle
    righe senza spunta. Si chiama dopo aver riempito la tabella."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QTableWidgetItem, QWidget
    n = t.columnCount()
    if not t.property("con_valida"):
        t.setProperty("con_valida", True)
        t.setColumnCount(n + 1)
        t.setHorizontalHeaderItem(n, QTableWidgetItem("Valida"))
        t.horizontalHeader().moveSection(n, col_incl + 1)
        t.itemChanged.connect(lambda it: it.column() == col_incl and
                              _valida_interf(t, it.row(), col_incl))
    for r in range(t.rowCount()):
        _valida_interf(t, r, col_incl)


def _valida_interf(t, r, col_incl):
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget
    it = t.item(r, col_incl)
    if it is None:
        return
    col_v = t.columnCount() - 1
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(2, 0, 2, 0)
    h.setSpacing(4)
    if it.checkState() == Qt.Checked:
        lab = QLabel("✔")
        lab.setStyleSheet("color:#1b7a2f; font-weight:bold")
        h.addWidget(lab)
    else:
        b_ok = QPushButton("Conferma")
        b_ok.clicked.connect(lambda _c=False, i=it: i.setCheckState(Qt.Checked))
        h.addWidget(b_ok)
    b_ko = QPushButton("Escludi")
    b_ko.setToolTip("Questa interferenza non va: esce dall'istanza e sparisce dall'elenco.")

    def _escludi(_c=False, i=it):
        i.setCheckState(Qt.Unchecked)
        riga = t.row(i)
        t.setRowHidden(riga, True)
        togli_dalla_mappa(t, riga)
    b_ko.clicked.connect(_escludi)
    h.addWidget(b_ko)
    h.addStretch()
    t.setCellWidget(r, col_v, w)


def togli_dalla_mappa(t, riga):
    """Interferenza esclusa: sparisce dai layer delle interferenze in mappa
    (punto, scavi e pozzetti trovati), riconosciuta dal numero «N.»."""
    from qgis.core import QgsProject, QgsVectorLayer
    col_n = next((c for c in range(t.columnCount()) if t.horizontalHeaderItem(c) is not None
                  and t.horizontalHeaderItem(c).text().strip() in ("N.", "#")), None)
    if col_n is None or t.item(riga, col_n) is None:
        return
    try:
        iid = int(str(t.item(riga, col_n).text()).strip())
    except ValueError:
        return
    for lyr in QgsProject.instance().mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.name().startswith("Interferenz"):
            continue
        k = lyr.fields().indexOf("id")
        if k < 0:
            continue
        via = [f.id() for f in lyr.getFeatures() if str(f[k]).split(".")[0] == str(iid)]
        if via:
            lyr.dataProvider().deleteFeatures(via)
            lyr.triggerRepaint()


def collega_valida_interferenze(dlg):
    """Aggiunge «Conferma / Escludi» alle tabelle delle interferenze di tutte
    le schede istanze (dopo ogni riempimento della tabella)."""
    voci = []
    try:
        from . import ftth_rfi_ui as _R
        voci.append(("_rfi_riempi_tabella", lambda a: dlg.tab_rfi, _R.C_INCL))
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import ftth_acque_ui as _A
        voci.append(("_acq_riempi_tabella", lambda a: dlg.tab_acq, _A.C_INCL))
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import ftth_strade_ui as _S
        voci.append(("_sti_riempi", lambda a: dlg.tab_sti, _S.CI_INCL))
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import ftth_vincoli_ui as _V
        voci.append(("_vin_riempi_tabella", lambda a: dlg._vin_w[a[0]]["tab"], _V.CI_INCL))
    except Exception:  # noqa: BLE001
        pass
    for nome, tabella, col in voci:
        orig = getattr(dlg, nome, None)
        if orig is None:
            continue

        def nuovo(*a, _o=orig, _t=tabella, _c=col, **k):
            r = _o(*a, **k)
            try:
                valida_interferenze(_t(a), _c)
            except Exception:  # noqa: BLE001
                pass
            return r
        setattr(dlg, nome, nuovo)


def valida_tutte(t, col_incl, col_valida, proposto_fn):
    for r in range(t.rowCount()):
        valida_riga(t, r, col_incl, col_valida, proposto_fn(r))


def nota3(dlg, extra: str = ""):
    """Frase comune sotto la tabella delle interferenze (passo 3)."""
    return dlg._desc("Si usano solo le righe confermate al punto 2. Togli la spunta alle "
                     "interferenze che non vanno in istanza; doppio clic su una riga: zoom in "
                     "mappa." + ((" " + extra) if extra else ""))


def nota4(dlg, testo: str):
    """Frase in testa al passo 4 (chi riceve le istanze)."""
    return dlg._desc(testo + " Il Comune va sempre in e.p.c.")


def nota5(dlg, sezione: str, extra: str = ""):
    """Frase comune del passo 5, sotto «Prepara layer Foto…»."""
    if sezione == "sopr":
        base = ("Prima metti sulla mappa i punti di ripresa (FOTO-n.jpg in 04_Foto), poi "
                "«Genera le istanze».")
    else:
        base = ("Prima metti sulla mappa i punti di ripresa (FOTO-n.jpg in 04_Foto) e le linee "
                "di sezione (SEZIONE A-A'.svg in 05_Sezioni), poi «Genera le istanze».")
    return dlg._desc(base + ((" " + extra) if extra else ""))


def comune_epc(form, ind, pec):
    """Indirizzo e PEC del Comune in e.p.c.: sempre al passo 4."""
    form.addRow("Comune in e.p.c. — indirizzo:", ind)
    form.addRow("Comune in e.p.c. — PEC:", pec)


def riga_foto(dlg, slot, solo_foto: bool = False):
    from qgis.PyQt.QtWidgets import QHBoxLayout, QPushButton
    r = QHBoxLayout()
    b = QPushButton("Prepara layer Foto" if solo_foto else "Prepara layer Foto e Sezioni")
    b.setToolTip("Aggiunge al progetto, se mancano, «Punto di Ripresa Fotografico» (FOTO n)"
                 + ("" if solo_foto else " e «Sezioni» (A-A')")
                 + ": in tavola vanno le foto di 04_Foto"
                 + ("" if solo_foto else " e le sezioni di 05_Sezioni") + ".")
    b.clicked.connect(slot)
    r.addWidget(b)
    r.addStretch()
    return r


def riga_genera(genera, apri, dlg=None, log_attr=None):
    """«Genera le istanze» + «Apri la cartella» + barra di avanzamento, uguali
    in tutte le schede. La barra avanza a ogni riga del registro della scheda
    (`log_attr`, es. «_log_rfi») e ne mostra il testo: la generazione gira
    nell'interfaccia, così si vede a che punto è."""
    from qgis.PyQt.QtWidgets import QApplication, QHBoxLayout, QPushButton
    from .ftth_barra import BarraAvanzamento
    r = QHBoxLayout()
    bg = primario("Genera le istanze")
    r.addWidget(bg)
    ba = QPushButton("Apri la cartella")
    ba.clicked.connect(apri)
    r.addWidget(ba)
    bar = BarraAvanzamento()
    r.addWidget(bar, 1)

    def _genera(*_a):
        orig = getattr(dlg, log_attr, None) if (dlg is not None and log_attr) else None
        bar.azzera()
        bar.fase(2, 97, "Generazione delle istanze…")
        bg.setEnabled(False)
        if orig is not None:
            def _log(*args):
                orig(*args)
                testo = " ".join(str(args[-1]).split())[:90] if args else ""
                bar.avanza()
                bar.avanza()
                if testo:
                    bar.setFormat("%p%  —  " + testo)
                QApplication.processEvents()
            setattr(dlg, log_attr, _log)
        ok = False
        try:
            genera()
            ok = True
        finally:
            if orig is not None:
                try:
                    delattr(dlg, log_attr)      # torna il metodo della classe
                except AttributeError:
                    pass
            bg.setEnabled(True)
            if ok:
                bar.fine("Generazione finita: vedi il registro qui sotto")
            else:
                bar.interrotta("Generazione interrotta: vedi il registro")
    bg.clicked.connect(_genera)

    def _prepara(*_a):
        """Genera solo le PL (senza documenti né PDF) per mettere in mappa le
        etichette nel layer «Etichette PL (spostabili)»: si spostano, poi
        «Genera le istanze» le stampa dove sono."""
        from qgis.core import QgsLayoutExporter
        from qgis.PyQt.QtWidgets import QMessageBox
        import docx.document as _dd
        from . import ftth_rfi as _R
        orig = (_dd.Document.save, QgsLayoutExporter.exportToPdf, _R.converti_pdf)
        _dd.Document.save = lambda self, *a, **k: None
        QgsLayoutExporter.exportToPdf = lambda self, *a, **k: QgsLayoutExporter.Success
        _R.converti_pdf = lambda *a, **k: {}
        dlg._solo_etichette = True
        try:
            _genera()
        finally:
            _dd.Document.save, QgsLayoutExporter.exportToPdf, _R.converti_pdf = orig
            dlg._solo_etichette = False
        bar.fine("Etichette pronte nel layer «Etichette PL (spostabili)»")
        QMessageBox.information(
            dlg, "Etichette in mappa",
            "Le etichette delle tavole sono nel layer «Etichette PL (spostabili)».\n\n"
            "Sposta i punti dove vuoi le etichette (strumento «Sposta elemento» con il "
            "layer in modifica), salva, poi premi «Genera le istanze»: in stampa vanno "
            "dove le hai messe. Quelle che non sposti restano automatiche, senza "
            "sovrapporsi.")
    b_et = QPushButton("Prepara le etichette in mappa")
    b_et.setToolTip("Calcola le tavole e mette le etichette nel layer «Etichette PL "
                    "(spostabili)», senza creare documenti: le sposti in mappa prima di "
                    "generare le istanze.")
    b_et.clicked.connect(_prepara)
    from qgis.PyQt.QtWidgets import QCheckBox
    chk = QCheckBox("Etichette accorpate")
    chk.setToolTip("Spuntata: se non c'è spazio, lo scavo e i suoi pozzetti hanno un'etichetta "
                   "sola (come finora). Senza spunta: un'etichetta per ogni elemento.\n"
                   "(Nelle tavole RFI le etichette sono sempre una per elemento.)")
    chk.setProperty("non_memorizzare", True)
    try:
        from qgis.core import QgsSettings
        chk.setChecked(str(QgsSettings().value("ftth_permessi/etichette_accorpate", "true"))
                       .lower() not in ("false", "0"))
        chk.toggled.connect(lambda v: QgsSettings().setValue(
            "ftth_permessi/etichette_accorpate", "true" if v else "false"))
    except Exception:  # noqa: BLE001
        pass
    r.insertWidget(0, chk)
    r.insertWidget(0, b_et)
    r.addStretch()
    return r, bg
