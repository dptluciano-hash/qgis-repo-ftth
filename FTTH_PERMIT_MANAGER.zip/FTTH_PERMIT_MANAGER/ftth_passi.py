# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Schema comune delle schede istanze (Strade, RFI, Acque, Soprintendenza,
Parchi): stessi 6 passi, stessi titoli, stessi pulsanti, così passando da una
scheda all'altra si ritrova la stessa grafica e lo stesso modo di dire le cose.

1) Comune
2) <oggetti> toccati dal progetto   (proposti in giallo: Conferma / Escludi)
3) Interferenze: controlla e conferma (tabella, mappa, conferma e vista per
   istanza; in Strade e RFI anche le chilometriche con i cippi)
4) Enti e destinatari                (ente per istanza + Comune in e.p.c.)
5) Foto, sezioni ed etichette      (quello che si disegna in mappa)
6) Stampa: genera le istanze       (opzioni dei documenti, Genera, registro)

Le opzioni usate di rado stanno sempre in un riquadro «Avanzate: …» chiuso,
in fondo al passo."""

OGGETTI = {
    "strade": "Strade toccate dal progetto",
    "rfi": "Ferrovie toccate dal progetto",
    "acque": "Corsi d'acqua toccati dal progetto",
    "sopr": "Aree vincolate toccate dal progetto",
    "parchi": "Aree protette e siti Natura 2000 toccati dal progetto",
}
TROVA = {
    "strade": "Trova le strade e gli enti",
    "rfi": "Trova le ferrovie e gli enti",
    "acque": "Trova i corsi d'acqua e gli enti",
    "sopr": "Trova le aree e gli enti",
    "parchi": "Trova le aree e gli enti",
}


def titolo(n: int, sezione: str) -> str:
    if n == 1:
        return "1) Comune"
    if n == 2:
        return "2) " + OGGETTI[sezione]
    if n == 3:
        return "3) Interferenze: controlla e conferma"
    if n == 4:
        return "4) Enti e destinatari"
    if n == 5:
        return "5) Foto ed etichette" if sezione == "sopr" else "5) Foto, sezioni ed etichette"
    return "6) Stampa: genera le istanze"


def percorso(sezione: str) -> str:
    """Promemoria dei passi, uguale in tutte le schede."""
    return ("Segui i passi da 1 a 6: 1) Comune → 2) %s → 3) interferenze → 4) enti e "
            "destinatari → 5) %s → 6) stampa. Le opzioni usate di rado sono nei riquadri "
            "«Avanzate», chiusi." % (OGGETTI[sezione].split(" toccat")[0].lower(),
                                     titolo(5, sezione)[3:].lower()))


def intro(dlg, sezione: str, testo: str = ""):
    """Riga d'apertura della scheda: cosa fa (breve) + i 5 passi."""
    return dlg._desc((testo.strip() + " " if testo else "") + percorso(sezione))


def primario(testo: str, slot=None, tip: str = ""):
    from qgis.PyQt.QtWidgets import QPushButton
    b = QPushButton(testo)
    b.setProperty("primario", True)
    if tip:
        b.setToolTip(tip)
    if slot is not None:
        b.clicked.connect(slot)
    return b


def proposte(dlg, conferma: str = "Conferma", escludi: str = "Escludi"):
    """Frase comune sotto la tabella del passo 2."""
    return dlg._desc("Gialle = proposte (rete del progetto vicina): per ognuna «%s» o «%s». "
                     "Verdi = confermate. Solo le confermate vanno al punto 3."
                     % (conferma, escludi))


def valida_riga(t, r, col_incl, col_valida, proposto):
    """Riga del passo 2 come in Strade: gialla = proposta (non spuntata) con
    «Conferma» / «Escludi», verde = confermata con «Annulla». Escludi toglie
    la spunta e nasconde la riga."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QBrush, QColor
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget
    it = t.item(r, col_incl)
    if it is None:
        return
    conf = it.checkState() == Qt.Checked
    fondo = QColor(214, 240, 214) if conf else (QColor(255, 243, 190) if proposto else None)
    t.blockSignals(True)
    for c in range(t.columnCount()):
        if c in (col_incl, col_valida):
            continue
        x = t.item(r, c)
        if x is not None:
            x.setBackground(QBrush(fondo) if fondo is not None else QBrush())
    t.blockSignals(False)
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(2, 0, 2, 0)
    h.setSpacing(4)
    if conf:
        lab = QLabel("✔ confermata")
        lab.setStyleSheet("color:#1b7a2f; font-weight:bold")
        h.addWidget(lab)
        b = QPushButton("Annulla")
        b.clicked.connect(lambda _c=False, i=it: i.setCheckState(Qt.Unchecked))
        h.addWidget(b)
    else:
        b_ok = QPushButton("Conferma")
        b_ok.clicked.connect(lambda _c=False, i=it: i.setCheckState(Qt.Checked))
        h.addWidget(b_ok)
        b_ko = QPushButton("Escludi")

        def _escludi(_c=False, i=it):
            i.setCheckState(Qt.Unchecked)
            t.setRowHidden(t.row(i), True)
        b_ko.clicked.connect(_escludi)
        h.addWidget(b_ko)
    h.addStretch()
    t.setCellWidget(r, col_valida, w)


def attiva_valida(t, col_incl, col_valida, proposto_fn):
    """Colonna «Valida» subito dopo la spunta; ogni cambio di spunta
    ricolora la riga e cambia i pulsanti."""
    t.horizontalHeader().moveSection(col_valida, col_incl + 1)
    t.itemChanged.connect(
        lambda it: it.column() == col_incl and
        valida_riga(t, it.row(), col_incl, col_valida, proposto_fn(it.row())))


def valida_interferenze(t, col_incl):
    """Tabella delle interferenze (passo 3): colonna «Valida» con «Escludi»
    su ogni riga (toglie la spunta e nasconde la riga) e «Conferma» sulle
    righe senza spunta. Si chiama dopo aver riempito la tabella."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QTableWidgetItem, QWidget
    n = t.columnCount()
    if not t.property("con_valida"):
        t.setProperty("con_valida", True)
        t.setColumnCount(n + 1)
        t.setHorizontalHeaderItem(n, QTableWidgetItem("Valida"))
        t.horizontalHeader().moveSection(n, col_incl + 1)
        t.itemChanged.connect(lambda it: it.column() == col_incl and
                              _valida_interf(t, it.row(), col_incl))
    for r in range(t.rowCount()):
        _valida_interf(t, r, col_incl)


def _valida_interf(t, r, col_incl):
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QWidget
    it = t.item(r, col_incl)
    if it is None:
        return
    col_v = t.columnCount() - 1
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(2, 0, 2, 0)
    h.setSpacing(4)
    if it.checkState() == Qt.Checked:
        lab = QLabel("✔")
        lab.setStyleSheet("color:#1b7a2f; font-weight:bold")
        h.addWidget(lab)
    else:
        b_ok = QPushButton("Conferma")
        b_ok.clicked.connect(lambda _c=False, i=it: i.setCheckState(Qt.Checked))
        h.addWidget(b_ok)
    b_ko = QPushButton("Escludi")
    b_ko.setToolTip("Questa interferenza non va: esce dall'istanza e sparisce dall'elenco.")

    def _escludi(_c=False, i=it):
        i.setCheckState(Qt.Unchecked)
        riga = t.row(i)
        t.setRowHidden(riga, True)
        togli_dalla_mappa(t, riga)
    b_ko.clicked.connect(_escludi)
    h.addWidget(b_ko)
    h.addStretch()
    t.setCellWidget(r, col_v, w)


def togli_dalla_mappa(t, riga):
    """Interferenza esclusa: sparisce dai layer delle interferenze in mappa
    (punto, scavi e pozzetti trovati), riconosciuta dal numero «N.»."""
    from qgis.core import QgsProject, QgsVectorLayer
    col_n = next((c for c in range(t.columnCount()) if t.horizontalHeaderItem(c) is not None
                  and t.horizontalHeaderItem(c).text().strip() in ("N.", "#")), None)
    if col_n is None or t.item(riga, col_n) is None:
        return
    try:
        iid = int(str(t.item(riga, col_n).text()).strip())
    except ValueError:
        return
    for lyr in QgsProject.instance().mapLayers().values():
        if not isinstance(lyr, QgsVectorLayer) or not lyr.name().startswith("Interferenz"):
            continue
        k = lyr.fields().indexOf("id")
        if k < 0:
            continue
        via = [f.id() for f in lyr.getFeatures() if str(f[k]).split(".")[0] == str(iid)]
        if via:
            lyr.dataProvider().deleteFeatures(via)
            lyr.triggerRepaint()


def collega_valida_interferenze(dlg):
    """Aggiunge «Conferma / Escludi» alle tabelle delle interferenze di tutte
    le schede istanze (dopo ogni riempimento della tabella)."""
    voci = []
    try:
        from . import ftth_rfi_ui as _R
        voci.append(("_rfi_riempi_tabella", lambda a: dlg.tab_rfi, _R.C_INCL))
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import ftth_acque_ui as _A
        voci.append(("_acq_riempi_tabella", lambda a: dlg.tab_acq, _A.C_INCL))
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import ftth_strade_ui as _S
        voci.append(("_sti_riempi", lambda a: dlg.tab_sti, _S.CI_INCL))
    except Exception:  # noqa: BLE001
        pass
    try:
        from . import ftth_vincoli_ui as _V
        voci.append(("_vin_riempi_tabella", lambda a: dlg._vin_w[a[0]]["tab"], _V.CI_INCL))
    except Exception:  # noqa: BLE001
        pass
    for nome, tabella, col in voci:
        orig = getattr(dlg, nome, None)
        if orig is None:
            continue

        def nuovo(*a, _o=orig, _t=tabella, _c=col, **k):
            r = _o(*a, **k)
            try:
                valida_interferenze(_t(a), _c)
            except Exception:  # noqa: BLE001
                pass
            return r
        setattr(dlg, nome, nuovo)


def valida_tutte(t, col_incl, col_valida, proposto_fn):
    for r in range(t.rowCount()):
        valida_riga(t, r, col_incl, col_valida, proposto_fn(r))


def nota3(dlg, extra: str = ""):
    """Frase comune sotto la tabella delle interferenze (passo 3)."""
    return dlg._desc("Si usano solo le righe confermate al punto 2. Togli la spunta alle "
                     "interferenze che non vanno in istanza; doppio clic su una riga: zoom in "
                     "mappa." + ((" " + extra) if extra else ""))


def nota4(dlg, testo: str):
    """Frase in testa al passo 4 (chi riceve le istanze)."""
    return dlg._desc(testo + " Il Comune va sempre in e.p.c.")


def nota5(dlg, sezione: str, extra: str = ""):
    """Frase comune del passo 5, sotto «Prepara layer Foto…»."""
    if sezione == "sopr":
        base = ("Metti sulla mappa i punti di ripresa (le foto si chiamano FOTO-n.jpg, nella "
                "cartella 04_Foto). Se serve, sposta anche le etichette delle tavole. Poi passa al punto 6.")
    else:
        base = ("Metti sulla mappa i punti di ripresa (le foto si chiamano FOTO-n.jpg, nella "
                "cartella 04_Foto) e le linee di sezione (SEZIONE A-A'.svg, nella cartella "
                "05_Sezioni). Se serve, sposta anche le etichette delle tavole. Poi passa al punto 6.")
    return dlg._desc(base + ((" " + extra) if extra else ""))


def comune_epc(form, ind, pec):
    """Indirizzo e PEC del Comune in e.p.c.: sempre al passo 4."""
    form.addRow("Comune in e.p.c. — indirizzo:", ind)
    form.addRow("Comune in e.p.c. — PEC:", pec)


def _comune_a_tutti(chiave):
    """I particolari costruttivi sono una libreria comune: si ricordano per tutti
    i progetti. Foto e sezioni sono del progetto: si ricordano nel progetto."""
    # l'utente: «i particolari li metti tu in automatico; solo se compilo il
    # percorso li prendi dalla cartella» -> nessuna cartella vale per tutti i
    # progetti, la casella vuota resta vuota
    return False


def cartella_salvata(project, chiave):
    """Cartella scelta con «Sfoglia…»: prima quella salvata nel progetto, poi
    (solo per i particolari) quella ricordata per tutti. Una cartella che non
    esiste più non vale. Prima foto e sezioni restavano quelle di un ALTRO
    progetto e le foto «non venivano prese»."""
    import os
    try:
        v, _ok = project.readEntry("ftth_permessi", chiave, "")
    except Exception:  # noqa: BLE001
        v = ""
    if v and os.path.isdir(v):
        return v
    if _comune_a_tutti(chiave):
        try:
            from qgis.core import QgsSettings
            g = QgsSettings().value("ftth_permessi/%s" % chiave, "") or ""
            if g and os.path.isdir(g):
                return g
        except Exception:  # noqa: BLE001
            pass
    return ""


def salva_cartella(project, chiave, cartella):
    try:
        project.writeEntry("ftth_permessi", chiave, cartella or "")
    except Exception:  # noqa: BLE001
        pass
    if _comune_a_tutti(chiave):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/%s" % chiave, cartella or "")
        except Exception:  # noqa: BLE001
            pass


def collega_cartelle(dlg, voci):
    """voci = [(QLineEdit, chiave)]: le caselle si riempiono dal progetto
    aperto e si aggiornano quando se ne apre un altro; scritte a mano si
    salvano nel progetto."""
    def _carica(*_a):
        for txt, chiave in voci:
            txt.blockSignals(True)
            txt.setText(cartella_salvata(dlg.project, chiave))
            txt.blockSignals(False)
    for txt, chiave in voci:
        # fuori dalla memoria generale della finestra (valeva per tutti i progetti)
        txt.setProperty("non_memorizzare", True)
        txt.editingFinished.connect(
            lambda t=txt, k=chiave: salva_cartella(dlg.project, k, t.text().strip()))
    _carica()
    try:
        dlg.project.readProject.connect(_carica)
    except Exception:  # noqa: BLE001
        pass


def riga_foto(dlg, slot, solo_foto: bool = False, ente: str = ""):
    from qgis.PyQt.QtWidgets import QHBoxLayout, QPushButton
    r = QHBoxLayout()
    b = QPushButton("Prepara layer Foto" if solo_foto else "Prepara layer Foto e Sezioni")
    b.setToolTip("Aggiunge al progetto, se mancano, «Punto di Ripresa Fotografico» (FOTO n)"
                 + ("" if solo_foto else " e «Sezioni» (A-A')")
                 + ": in tavola vanno le foto di 04_Foto"
                 + ("" if solo_foto else " e le sezioni di 05_Sezioni") + ".")
    b.clicked.connect(slot)
    r.addWidget(b)
    bc = QPushButton("Coni ruotabili")
    bc.setToolTip("Crea i coni delle foto come poligoni (layer «Cono di Ripresa (istanze)»): "
                  "si girano con lo strumento «Ruota elementi» vedendo l'anteprima; al "
                  "salvataggio la rotazione torna nel campo Rotazione dei punti di ripresa.")
    bc.clicked.connect(lambda *_a: crea_coni_istanze(dlg, ente=ente))
    r.addWidget(bc)
    bi = QPushButton("Foto e sezioni per un'istanza")
    bi.setToolTip("Quando lavori più istanze nello stesso progetto: crea layer di foto"
                  + ("" if solo_foto else " e sezioni") + " solo per l'istanza che scegli "
                  "(«Punto di Ripresa Fotografico - <istanza>»). Le PL di quell'istanza usano "
                  "quei layer; le altre continuano a usare quelli comuni.")
    bi.clicked.connect(lambda *_a: crea_rilievo_istanza(dlg, slot, solo_foto, ente))
    r.addWidget(bi)
    r.addStretch()
    return r


def istanze_confermate(prj):
    """Nomi delle istanze confermate in tutte le schede (campi IST_*)."""
    out = []
    try:
        from . import ftth_gruppi_istanze as GR
        from . import ftth_rfi_layout as L
        for k, v in sorted(GR.registro(prj).items()):
            if k.startswith("_") or not isinstance(v, dict) or not v.get("valore"):
                continue
            val = GR.pulisci(v["valore"])
            out.append(val)
    except Exception:  # noqa: BLE001
        pass
    return list(dict.fromkeys(out))


def crea_rilievo_istanza(dlg, prepara_comuni, solo_foto=False, ente=""):
    """Layer foto (e sezioni) per una sola istanza: stessa struttura e stesso
    stile dei layer dell'ente (o comuni), nome «<layer> - <istanza>», file in
    01_File shp/Rilievo istanze, nel gruppo dell'ente in «Altri enti»."""
    import os
    import re
    from qgis.core import (QgsMapLayerStyle, QgsProject, QgsVectorFileWriter, QgsVectorLayer,
                           QgsWkbTypes)
    from qgis.PyQt.QtWidgets import QInputDialog, QMessageBox
    from . import ftth_rfi_layout as L
    prj = getattr(dlg, "project", None) or QgsProject.instance()
    if not prj.fileName():
        QMessageBox.information(dlg, "Foto e sezioni per un'istanza",
                                "Salva prima il progetto: i layer vanno accanto al progetto.")
        return []
    istanze = istanze_confermate(prj)
    if ente in L.ENTI_LAYER:        # solo le istanze di questa scheda
        istanze = [i for i in istanze if L.di_ente(ente, i, prj)] or istanze
    if not istanze:
        QMessageBox.information(dlg, "Foto e sezioni per un'istanza",
                                "Nessuna istanza confermata: prima «Conferma le interferenze "
                                "spuntate» al passo 3.")
        return []
    ist, ok = QInputDialog.getItem(dlg, "Foto e sezioni per un'istanza",
                                   "Istanza:", istanze, 0, False)
    if not ok or not ist:
        return []
    basi = [(L.NOMI_LAYER_FOTO, "Punto di Ripresa Fotografico")]
    if not solo_foto:
        basi.append((L.NOMI_LAYER_SEZIONI, "Sezioni"))
    # ente dell'istanza scelta: modello e gruppo
    if ente not in L.ENTI_LAYER:
        ente = next((e for e in L.ENTI_LAYER if L.di_ente(e, ist, prj)), "")

    def _modello(nomi, base):
        proprio = next(iter(prj.mapLayersByName(L.nome_layer_ente(base, ente))), None) \
            if ente else None
        return proprio or next((l for n in nomi for l in prj.mapLayersByName(n)), None)
    # servono i layer dell'ente (o comuni) come modello (struttura e stile)
    if any(_modello(nomi, b) is None for nomi, b in basi):
        try:
            prepara_comuni()
        except Exception:  # noqa: BLE001
            pass
    cart = os.path.join(prj.homePath(), "01_File shp", "Rilievo istanze")
    os.makedirs(cart, exist_ok=True)
    slug = re.sub(r"[^A-Za-z0-9]+", "_", ist).strip("_")[:60] or "istanza"
    fatti = []
    for nomi, base in basi:
        modello = _modello(nomi, base)
        if modello is None:
            continue
        nome = "%s - %s" % (base, ist)
        esistente = next(iter(prj.mapLayersByName(nome)), None)
        if esistente is not None:
            fatti.append(nome + " (c'era già)")
            continue
        gpkg = os.path.join(cart, "%s_%s.gpkg" % ("foto" if base.startswith("Punto") else
                                                    "sezioni", slug))
        opz = QgsVectorFileWriter.SaveVectorOptions()
        opz.driverName = "GPKG"
        opz.layerName = "rilievo"
        w = QgsVectorFileWriter.create(gpkg, modello.fields(), modello.wkbType(),
                                       modello.crs(), prj.transformContext(), opz)
        del w
        lyr = QgsVectorLayer("%s|layername=rilievo" % gpkg, nome, "ogr")
        if not lyr.isValid():
            continue
        st = QgsMapLayerStyle()
        st.readFromLayer(modello)
        st.writeToLayer(lyr)
        for k in modello.customPropertyKeys():
            if k.startswith("ftth/"):
                lyr.setCustomProperty(k, modello.customProperty(k))
        if ente:            # nel gruppo dell'ente, non in «Rilievo»
            from . import ftth_gruppi_istanze as _GRr
            prj.addMapLayer(lyr, False)
            _GRr.gruppo_sezione(prj.layerTreeRoot(), ente).insertLayer(0, lyr)
        else:
            prj.addMapLayer(lyr)
        k_i = lyr.fields().indexOf(L.CAMPO_ISTANZA)
        if k_i >= 0:   # ogni nuovo punto ha già il nome dell'istanza
            from qgis.core import QgsDefaultValue
            lyr.setDefaultValueDefinition(k_i, QgsDefaultValue("'%s'" % ist.replace("'", "''")))
        fatti.append(nome)
    QMessageBox.information(
        dlg, "Foto e sezioni per un'istanza",
        "Creati per «%s»:\n- %s\n\nDisegna lì i punti di ripresa%s di questa istanza: le "
        "sue PL useranno questi layer. Le foto vanno in 04_Foto\\%s." % (
            ist, "\n- ".join(fatti) or "nessun layer",
            "" if solo_foto else " e le sezioni", L.nome_cartella(ist)))
    return fatti


NOME_CONI_ISTANZE = "Cono di Ripresa (istanze)"


def crea_coni_istanze(dlg, raggio=12.0, ente=""):
    """Coni poligonali dai «Punto di Ripresa Fotografico» delle schede
    istanze (come nel Suolo comunale): «Ruota elementi» li gira con
    l'anteprima, e al salvataggio del layer coni la rotazione si riscrive nel
    campo Rotazione dei punti. Il layer coni serve solo a ruotare: nelle PL
    resta il simbolo del punto. Con `ente` i coni sono dei punti dell'ente
    («… - RFI») e il layer «Cono di Ripresa (istanze) - RFI» sta nel suo
    gruppo."""
    import os
    from qgis.core import (QgsFeature, QgsField, QgsFields, QgsProject, QgsVectorFileWriter,
                           QgsVectorLayer)
    from qgis.PyQt.QtCore import QVariant
    from qgis.PyQt.QtWidgets import QMessageBox
    from . import ftth_permessi_dialog as PD
    from . import ftth_rfi_layout as L
    prj = getattr(dlg, "project", None) or QgsProject.instance()
    ente = ente if ente in L.ENTI_LAYER else ""
    punti = next(iter(prj.mapLayersByName(
        L.nome_layer_ente("Punto di Ripresa Fotografico", ente))), None) if ente else None
    if punti is None:
        punti = next((l for n in L.NOMI_LAYER_FOTO for l in prj.mapLayersByName(n)), None)
    if punti is None:
        punti = next(iter(prj.mapLayersByName("Punto di Ripresa Fotografico")), None)
    # coni dell'ente solo se i punti sono quelli dell'ente
    ente = ente if (ente and punti is not None and punti.name() ==
                    L.nome_layer_ente("Punto di Ripresa Fotografico", ente)) else ""
    nome_coni = L.nome_layer_ente(NOME_CONI_ISTANZE, ente)
    if punti is None or punti.fields().indexOf(PD.CAMPO_ROT) < 0:
        QMessageBox.information(dlg, "Coni ruotabili",
                                "Manca il layer «Punto di Ripresa Fotografico»: premi prima "
                                "«Prepara layer Foto».")
        return None
    if punti.isEditable():
        QMessageBox.information(dlg, "Coni ruotabili",
                                "Chiudi prima la modifica del layer dei punti di ripresa "
                                "(salva o annulla), poi riprova.")
        return None
    L.rotazione_con_strumento(punti)
    scarto = 90.0 if punti.customProperty("ftth/rotazione_v2") else 0.0
    campi = QgsFields()
    campi.append(QgsField(PD.CAMPO_CONO_PUNTO, QVariant.LongLong))
    for nome_c in ("NumeroFoto", L.CAMPO_ISTANZA, PD.CAMPO_ROT):
        k = punti.fields().indexOf(nome_c)
        if k >= 0:
            campi.append(QgsField(nome_c, punti.fields().at(k).type()))
    feats = []
    for p in punti.getFeatures():
        g = p.geometry()
        if not g or g.isEmpty():
            continue
        try:
            rot = float(p[PD.CAMPO_ROT])
        except (TypeError, ValueError):
            rot = scarto            # senza rotazione: cono verso Nord
        nf = QgsFeature(campi)
        nf.setGeometry(PD.cono_poligono(g.asPoint(), (rot - scarto) % 360, raggio))
        nf[PD.CAMPO_CONO_PUNTO] = p.id()
        for nome_c in ("NumeroFoto", L.CAMPO_ISTANZA, PD.CAMPO_ROT):
            if campi.indexOf(nome_c) >= 0:
                nf[nome_c] = p[nome_c]
        feats.append(nf)
    if not feats:
        QMessageBox.information(dlg, "Coni ruotabili", "Nessun punto di ripresa nel layer.")
        return None
    home = prj.homePath() or os.path.expanduser("~")
    cart = os.path.join(home, "01_File shp")
    os.makedirs(cart, exist_ok=True)
    gpkg = os.path.join(cart, "Coni di Ripresa istanze%s.gpkg" % (
        (" " + L.ENTI_LAYER[ente]) if ente else ""))
    tmp = QgsVectorLayer("Polygon?crs=" + punti.crs().authid(), nome_coni, "memory")
    tmp.dataProvider().addAttributes(campi.toList())
    tmp.updateFields()
    tmp.dataProvider().addFeatures(feats)
    opz = QgsVectorFileWriter.SaveVectorOptions()
    opz.driverName = "GPKG"
    opz.layerName = "coni_istanze"
    opz.actionOnExistingFile = QgsVectorFileWriter.CreateOrOverwriteFile
    for l in prj.mapLayersByName(nome_coni):
        prj.removeMapLayer(l.id())
    err = QgsVectorFileWriter.writeAsVectorFormatV3(tmp, gpkg, prj.transformContext(), opz)
    if (err[0] if isinstance(err, tuple) else err) != QgsVectorFileWriter.NoError:
        QMessageBox.warning(dlg, "Coni ruotabili", "Scrittura non riuscita: %s" % (err,))
        return None
    lyr = QgsVectorLayer("%s|layername=coni_istanze" % gpkg, nome_coni, "ogr")
    if not lyr.isValid():
        return None
    try:
        from qgis.core import QgsFillSymbol, QgsSingleSymbolRenderer
        lyr.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"color": "0,150,255,60", "outline_color": "0,90,200,255", "outline_width": "0.4"})))
    except Exception:  # noqa: BLE001
        pass
    if ente:        # nel gruppo dell'ente, accanto ai suoi punti
        from . import ftth_gruppi_istanze as _GRc
        prj.addMapLayer(lyr, False)
        _GRc.gruppo_sezione(prj.layerTreeRoot(), ente).insertLayer(0, lyr)
    else:
        prj.addMapLayer(lyr)
    lyr.setCustomProperty(PD.CONO_PROP_PUNTI, punti.id())
    lyr.setCustomProperty(PD.CONO_PROP_RAGGIO, float(raggio))
    lyr.setCustomProperty(PD.CONO_PROP_APERT, float(PD.CONO_APERTURA_GRADI))
    lyr.setCustomProperty(PD.CONO_PROP_MUOVE, "0")      # la camera non si sposta
    lyr.setCustomProperty(PD.CONO_PROP_SCARTO, scarto)
    PD.aggancia_coni_progetto(prj, getattr(dlg, "iface", None))
    QMessageBox.information(
        dlg, "Coni ruotabili",
        "%d coni nel layer «%s».\n\nPer ruotarli: metti in modifica il layer dei coni, "
        "strumento «Ruota elementi» (barra Digitalizzazione avanzata), trascina e vedi "
        "l'anteprima. Quando SALVI le modifiche del layer coni, la rotazione va nel campo "
        "Rotazione dei punti di ripresa (che devono essere fuori modifica).\n\nPer le PL "
        "puoi poi spegnere o togliere il layer dei coni." % (len(feats), nome_coni))
    return lyr


def _progetto():
    from qgis.core import QgsProject
    return QgsProject.instance()


def scegli_tubi(dlg, promemoria=False):
    """Finestra con i tubi del particolare costruttivo (uno o più). Salva la
    scelta nel progetto e la ritorna; None se annullata o senza scelta."""
    from qgis.PyQt.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QLabel,
                                     QVBoxLayout)
    from . import ftth_rfi_layout as _RL
    prj = _progetto()
    attuali = _RL.tubi_progetto(prj)
    w = QDialog(dlg)
    w.setWindowTitle("Tubi nei particolari costruttivi")
    v = QVBoxLayout(w)
    testo = ("Quali tubi posi? Nella tavola dei particolari costruttivi va il disegno di "
             "ognuno di quelli che spunti. La scelta resta salvata nel progetto.")
    if promemoria and not attuali:
        testo = ("<b>Attenzione: non hai ancora scelto i tubi.</b><br>" + testo)
    elif promemoria:
        testo = ("<b>Controlla i tubi prima di generare</b>: sono spuntati quelli scelti "
                 "l'ultima volta.<br>" + testo)
    lab = QLabel(testo)
    lab.setWordWrap(True)
    v.addWidget(lab)
    caselle = []
    for k, t in _RL.TUBI_PC:
        c = QCheckBox(t)
        c.setChecked(k in attuali)
        v.addWidget(c)
        caselle.append((k, c))
    bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
    bb.button(QDialogButtonBox.Ok).setText("Conferma" + (" e genera" if promemoria else ""))
    bb.accepted.connect(w.accept)
    bb.rejected.connect(w.reject)
    v.addWidget(bb)
    if not w.exec_():
        return None
    scelti = [k for k, c in caselle if c.isChecked()]
    if not scelti:
        from qgis.PyQt.QtWidgets import QMessageBox
        QMessageBox.warning(dlg, "Tubi nei particolari",
                            "Nessun tubo spuntato: scegline almeno uno.")
        return None
    try:
        prj.writeEntry("ftth_permessi", "tubi_pc", ",".join(scelti))
    except Exception:  # noqa: BLE001
        pass
    return scelti


def riga_genera(genera, apri, dlg=None, log_attr=None, etichette_in=None, ente=None):
    """«Genera le istanze» + «Apri la cartella» + barra di avanzamento, uguali
    in tutte le schede. La barra avanza a ogni riga del registro della scheda
    (`log_attr`, es. «_log_rfi») e ne mostra il testo: la generazione gira
    nell'interfaccia, così si vede a che punto è."""
    from qgis.PyQt.QtWidgets import QApplication, QHBoxLayout, QPushButton
    from .ftth_barra import BarraAvanzamento
    # schede con layer propri (foto, sezioni, etichette nel gruppo dell'ente)
    if ente is None:
        ente = {"_log_rfi": "rfi", "_log_sti": "strade",
                "_log_a": "acque"}.get(log_attr or "", "")
    r = QHBoxLayout()
    bg = primario("Genera le istanze")
    r.addWidget(bg)
    ba = QPushButton("Apri la cartella")
    ba.clicked.connect(apri)
    r.addWidget(ba)
    bar = BarraAvanzamento()
    r.addWidget(bar, 1)

    def _genera(*_a, barra=True):
        # barra=False: solo etichette in mappa, la barra della stampa (passo 6)
        # resta ferma
        orig = getattr(dlg, log_attr, None) if (dlg is not None and log_attr and barra) \
            else None
        if barra:
            bar.azzera()
            bar.fase(2, 97, "Generazione delle istanze…")
            bg.setEnabled(False)
        if orig is not None:
            def _log(*args):
                orig(*args)
                testo = " ".join(str(args[-1]).split())[:90] if args else ""
                bar.avanza()
                bar.avanza()
                if testo:
                    bar.setFormat("%p%  —  " + testo)
                QApplication.processEvents()
            setattr(dlg, log_attr, _log)
        ok = False
        from . import ftth_rfi_layout as _RLt
        _RLt.TUBI_SCELTI = _RLt.tubi_progetto(_progetto())
        _RLt.ENTE_CORRENTE = ente
        try:
            genera()
            ok = True
        finally:
            _RLt.TUBI_SCELTI = []
            _RLt.ENTE_CORRENTE = ""
            if orig is not None:
                try:
                    delattr(dlg, log_attr)      # torna il metodo della classe
                except AttributeError:
                    pass
            bg.setEnabled(True)
            if not barra:
                pass
            elif ok:
                bar.fine("Generazione finita: vedi il registro qui sotto")
            else:
                bar.interrotta("Generazione interrotta: vedi il registro")
    bg.clicked.connect(_genera)

    def _prepara(*_a, avviso=True):
        """Genera solo le PL (senza documenti né PDF) per mettere in mappa le
        etichette nel layer «Etichette PL (spostabili)»: si spostano, poi
        «Genera le istanze» le stampa dove sono."""
        from qgis.PyQt.QtWidgets import QMessageBox
        import docx.document as _dd
        from . import ftth_rfi as _R
        from . import ftth_rfi_layout as _RL
        # niente funzioni di QGIS sostituite (rimesse a posto, l'esportazione
        # PDF di QGIS non funzionava più): un interruttore nelle PL del plugin
        # solo etichette: niente Word, PDF e finestra «Istanze generate» (prima
        # sembrava che partisse la stampa)
        orig = (_dd.Document.save, _R.converti_pdf, QMessageBox.information)
        _dd.Document.save = lambda self, *a, **k: None
        _R.converti_pdf = lambda paths=(), *a, **k: {p: p for p in (paths or [])}
        QMessageBox.information = staticmethod(lambda *a, **k: QMessageBox.Ok)
        _RL.SOLO_ETICHETTE = True
        dlg._solo_etichette = True
        # registro catturato: il riepilogo dice cosa è successo istanza per
        # istanza (prima, se le etichette non nascevano, non si capiva perché)
        righe = []
        log_orig = getattr(dlg, log_attr, None) if (dlg is not None and log_attr) else None
        if log_orig is not None:
            setattr(dlg, log_attr, lambda *a: (righe.append(str(a[-1]) if a else ""),
                                               log_orig(*a)))
        lyr_prima = _layer_et()
        if lyr_prima is not None and lyr_prima.isEditable():
            # in modifica il layer non si aggiorna: si salvano prima gli spostamenti
            lyr_prima.commitChanges()
        from qgis.PyQt.QtCore import Qt
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            _genera(barra=False)
        finally:
            QApplication.restoreOverrideCursor()
            _dd.Document.save, _R.converti_pdf, QMessageBox.information = orig
            _RL.SOLO_ETICHETTE = False
            dlg._solo_etichette = False
            if log_orig is not None:
                try:
                    delattr(dlg, log_attr)
                except AttributeError:
                    pass
        dlg._riepilogo_etichette = riepilogo_etichette(_layer_et(), righe)
        if not avviso:
            return
        QMessageBox.information(
            dlg, "Etichette in mappa",
            "Le etichette delle tavole sono nel layer «Etichette PL (spostabili)».\n\n"
            "Per spostare un'etichetta: layer in modifica, strumento «Sposta elemento», "
            "trascina il punto: testo e filo si muovono insieme (lo strumento delle "
            "etichette di QGIS qui non serve). Salva, poi premi «Genera le istanze»: in "
            "stampa vanno dove le hai messe. Quelle che non sposti restano automatiche, "
            "senza sovrapporsi. Le etichette vecchie (km cambiati, tavole rifatte) "
            "vengono tolte da sole.")
    from qgis.PyQt.QtWidgets import QCheckBox, QLabel, QVBoxLayout

    def _layer_et():
        from qgis.core import QgsProject
        from . import ftth_rfi_layout as _RL
        return next(iter(QgsProject.instance().mapLayersByName(_RL.nome_etich(ente))), None)

    def _salva_spostamenti(continua=True):
        """Salva gli spostamenti delle etichette (se ce ne sono)."""
        lyr = _layer_et()
        if lyr is not None and lyr.isEditable() and lyr.isModified():
            lyr.commitChanges()
            if continua:
                lyr.startEditing()

    # ---- riga 1: Etichette (facoltativo) — un solo pulsante acceso/spento
    b_mod = QPushButton("Modifica etichette in mappa")
    b_mod.setCheckable(True)
    b_mod.setToolTip("Facoltativo. Acceso: le etichette delle tavole compaiono in mappa (layer "
                     "«Etichette PL (spostabili)») già in modifica, con lo strumento «Sposta "
                     "elemento»: trascini il punto e testo e filo si muovono insieme.\n"
                     "Spento: le posizioni si salvano. Quelle che non sposti restano automatiche.")
    lab_mod = QLabel("")
    lab_mod.setStyleSheet("color:#555")

    def _modifica(acceso):
        from qgis.PyQt.QtWidgets import QMessageBox
        if acceso:
            b_mod.setText("Fine modifica etichette (salva)")
            lab_mod.setText("preparo le etichette…")
            QApplication.processEvents()
            try:
                _prepara(avviso=False)
            except Exception as e:  # noqa: BLE001
                b_mod.blockSignals(True)
                b_mod.setChecked(False)
                b_mod.blockSignals(False)
                b_mod.setText("Modifica etichette in mappa")
                lab_mod.setText("")
                QMessageBox.warning(dlg, "Etichette", "Etichette non preparate: %s" % e)
                return
            lyr = _layer_et()
            breve, dettaglio, n_tot = getattr(dlg, "_riepilogo_etichette", ("", "", 0))
            if lyr is None or lyr.featureCount() == 0 or not n_tot:
                # niente da modificare: il pulsante torna spento e si dice perché
                b_mod.blockSignals(True)
                b_mod.setChecked(False)
                b_mod.blockSignals(False)
                b_mod.setText("Modifica etichette in mappa")
                lab_mod.setText("nessuna etichetta: vedi il motivo nella finestra")
                QMessageBox.warning(dlg, "Etichette non create", dettaglio)
                return
            if "ATTENZIONE" in dettaglio:
                QMessageBox.information(dlg, "Etichette in mappa", dettaglio)
            # una sola serie di etichette in mappa: quelle spostabili (che vanno
            # in stampa). «Etichette in stampa» (dai campi degli shape) mostrava
            # gli stessi testi e si sovrapponeva
            try:
                from qgis.core import QgsProject
                for g in QgsProject.instance().layerTreeRoot().findGroups(True):
                    if g.name() == "Etichette in stampa":
                        g.setItemVisibilityChecked(False)
            except Exception:  # noqa: BLE001
                pass
            if not lyr.isEditable():
                lyr.startEditing()
            iface = getattr(dlg, "iface", None)
            try:
                iface.setActiveLayer(lyr)
                iface.actionMoveFeature().trigger()
            except Exception:  # noqa: BLE001
                pass
            lab_mod.setText(breve + " — trascina i punti in mappa, poi premi «Fine modifica»")
        else:
            lyr = _layer_et()
            if lyr is not None and lyr.isEditable():
                ok = lyr.commitChanges()
                lab_mod.setText("posizioni salvate" if ok else
                                "salvataggio non riuscito: %s" % "; ".join(lyr.commitErrors()))
            else:
                lab_mod.setText("")
            b_mod.setText("Modifica etichette in mappa")
    b_mod.toggled.connect(_modifica)

    # opzione usata di rado: in un riquadro «Avanzate» chiuso
    chk = QCheckBox("Etichette accorpate (scavo e pozzetti vicini in un'etichetta sola)")
    chk.setToolTip("Spuntata: se non c'è spazio, lo scavo e i suoi pozzetti hanno un'etichetta "
                   "sola. Senza spunta: un'etichetta per ogni elemento.\n"
                   "(Nelle tavole RFI le etichette sono sempre una per elemento.)")
    chk.setProperty("non_memorizzare", True)
    try:
        from qgis.core import QgsSettings
        chk.setChecked(str(QgsSettings().value("ftth_permessi/etichette_accorpate", "true"))
                       .lower() not in ("false", "0"))
        chk.toggled.connect(lambda v: QgsSettings().setValue(
            "ftth_permessi/etichette_accorpate", "true" if v else "false"))
    except Exception:  # noqa: BLE001
        pass

    def _anteprima(*_a):
        # le PL si rifanno con le etichette dove le hai spostate: l'anteprima
        # è quella che andrà in stampa
        _salva_spostamenti(continua=b_mod.isChecked())
        _prepara(avviso=False)
        anteprima_stampa(dlg)

    b_ant = QPushButton("Anteprima di stampa")
    b_ant.setToolTip("Rifà le PL con le etichette dove le hai messe e apre PL e relazioni.")
    b_ant.clicked.connect(_anteprima)

    # ---- tubi del particolare costruttivo: li sceglie l'utente
    b_tubi = QPushButton("Tubi nei particolari…")
    b_tubi.setToolTip("Quali tubi posi: nella tavola dei particolari costruttivi va il disegno "
                      "di ognuno. Gli shape non lo dicono, quindi lo scegli tu.")
    lab_tubi = QLabel("")

    def _aggiorna_tubi(*_a):
        from . import ftth_rfi_layout as _RL
        sc = _RL.tubi_progetto(_progetto())
        testi = dict(_RL.TUBI_PC)
        if sc:
            lab_tubi.setText(", ".join(testi[k] for k in sc))
            lab_tubi.setStyleSheet("color:#1b7a2f")
        else:
            lab_tubi.setText("non ancora scelti")
            lab_tubi.setStyleSheet("color:#c0392b; font-weight:bold")
    b_tubi.clicked.connect(lambda *_a: (scegli_tubi(dlg), _aggiorna_tubi()))
    _aggiorna_tubi()
    try:
        from qgis.core import QgsProject
        QgsProject.instance().readProject.connect(_aggiorna_tubi)
    except Exception:  # noqa: BLE001
        pass

    def _genera_click(*_a):
        # promemoria a OGNI «Genera» (utente): si controllano i tubi dei
        # particolari costruttivi, già spuntati quelli dell'ultima volta.
        # Annulla = niente generazione
        if scegli_tubi(dlg, promemoria=True) is None:
            return
        _aggiorna_tubi()
        _salva_spostamenti(continua=b_mod.isChecked())
        _genera()
    # «Genera» salva prima gli spostamenti delle etichette
    bg.clicked.disconnect()
    bg.clicked.connect(_genera_click)
    r.insertWidget(0, b_ant)

    out = QVBoxLayout()
    r_t = QHBoxLayout()
    r_t.addWidget(QLabel("<b>Tubi posati</b> (per i particolari costruttivi):"))
    r_t.addWidget(b_tubi)
    r_t.addWidget(lab_tubi, 1)
    out.addLayout(r_t)
    # etichette delle tavole: si spostano in mappa come foto e sezioni, quindi
    # stanno nel passo 5 (`etichette_in`); la stampa resta al passo 6
    dove = etichette_in if etichette_in is not None else out
    r1 = QHBoxLayout()
    t1 = QLabel("<b>Etichette delle tavole</b> (facoltativo):")
    r1.addWidget(t1)
    r1.addWidget(b_mod)
    r1.addWidget(lab_mod, 1)
    dove.addLayout(r1)
    try:
        from qgis.gui import QgsCollapsibleGroupBox
        av = QgsCollapsibleGroupBox("Avanzate: etichette")
        av.setCollapsed(True)
        va = QVBoxLayout(av)
        va.addWidget(chk)
        dove.addWidget(av)
    except Exception:  # noqa: BLE001
        dove.addWidget(chk)
    out.addLayout(r)
    return out, bg


SCALE_PL = (500, 1000, 2000, 5000)


def combo_scala(chiave: str, auto: str, scale=SCALE_PL):
    """«Scala delle tavole PL», uguale in tutte le schede (passo 6):
    «automatica» (dato 0 = come ha sempre fatto la scheda, `auto` lo dice)
    o una scala fissa per tutte le tavole. Ricordata per scheda."""
    from qgis.PyQt.QtWidgets import QComboBox
    cb = QComboBox()
    cb.addItem("automatica (consigliata) — %s" % auto, 0)
    for s in scale:
        cb.addItem("1:%d" % s, s)
    cb.setToolTip("Stessa scala per ortofoto, planimetria ed estratto catastale, in tutte le "
                  "tavole della PL. Con una scala grande (1:500) le zone con le interferenze "
                  "lontane fra loro possono uscire dalla tavola.")
    cb.setProperty("non_memorizzare", True)
    try:
        from qgis.core import QgsSettings
        v = int(QgsSettings().value("ftth_permessi/%s" % chiave, 0) or 0)
    except Exception:  # noqa: BLE001
        v = 0
    cb.setCurrentIndex(max(0, cb.findData(v)))

    def _salva(*_a):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/%s" % chiave, int(cb.currentData() or 0))
        except Exception:  # noqa: BLE001
            pass
    cb.currentIndexChanged.connect(_salva)
    return cb


def riga_fotosez(dlg, slot, solo_foto: bool = False, ente: str = ""):
    """Passo 5, prima riga: «Foto e sezioni:» + i pulsanti dei layer."""
    from qgis.PyQt.QtWidgets import QLabel
    r = riga_foto(dlg, slot, solo_foto, ente)
    r.insertWidget(0, QLabel("<b>%s</b>" % ("Foto:" if solo_foto else "Foto e sezioni:")))
    return r


def riepilogo_etichette(lyr, righe_registro):
    """(breve, dettaglio, totale) dopo «Modifica etichette in mappa»: quante
    etichette per istanza e, se mancano, perché (progetto mai salvato, nessuna
    istanza, errori o avvisi del registro)."""
    from qgis.core import QgsProject
    prj = QgsProject.instance()
    per = {}
    if lyr is not None and lyr.isValid():
        k = lyr.fields().indexOf("istanza")
        for f in lyr.getFeatures():
            v = str(f.attribute(k)) if k >= 0 else "?"
            per[v] = per.get(v, 0) + 1
    tot = sum(per.values())
    # istanze lavorate secondo il registro («- NOME: …» / «— NOME (…)»)
    import re
    lavorate = []
    for r in righe_registro:
        m = re.match(r"\s*[-—]\s+([A-Za-z0-9_'\-]+)[:\s(]", r)
        if m and m.group(1) not in lavorate:
            lavorate.append(m.group(1))
    righe = []
    if not prj.fileName():
        righe.append("ATTENZIONE: progetto mai salvato. Le etichette stanno in un file accanto "
                     "al progetto: salvalo (Progetto › Salva) e riprova.")
    if not lavorate and not per:
        righe.append("ATTENZIONE: nessuna istanza da preparare. Completa i passi 1-3 (comune, "
                     "interferenze trovate e spuntate) e riprova.")
    for nome in lavorate:
        n = per.get(nome, 0)
        righe.append("%s: %d etichette%s" % (nome, n, "" if n else
                                            "  ← ATTENZIONE: nessuna (vedi sotto)"))
    for nome, n in sorted(per.items()):
        if nome not in lavorate:
            righe.append("%s: %d etichette (di una preparazione precedente)" % (nome, n))
    problemi = [r.strip() for r in righe_registro
                if re.search(r"ERRORE|ATTENZIONE|non riuscit|non trovat|nessun|mancan", r, re.I)]
    if problemi:
        righe.append("")
        righe.append("Dal registro:")
        righe += ["  " + p[:220] for p in problemi[:15]]
    if lyr is None:
        righe.append("ATTENZIONE: layer «Etichette PL (spostabili)» non creato.")
    breve = "%d etichette in %d istanze" % (tot, len(per))
    dettaglio = (breve + ".\n\n" + "\n".join(righe)).strip()
    return breve, dettaglio, tot


def riga_tavole(dlg, combo, calcola, ente=""):
    """Passo 5, uguale in tutte le schede: «Tavole: Scala [..] [Calcola numero
    di tavole (anteprima)]» + esito. Ritorna (layout, etichetta esito)."""
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton
    r = QHBoxLayout()
    r.addWidget(QLabel("<b>Tavole:</b>"))
    r.addWidget(QLabel("Scala:"))
    r.addWidget(combo)
    b = QPushButton("Calcola numero di tavole (anteprima)")
    b.setToolTip("Divide le interferenze di ogni istanza nelle tavole della PL (stessa "
                 "divisione della stampa) e disegna i riquadri in mappa (layer «Tavole PL "
                 "(riquadri)%s»). La stampa usa quei riquadri: cancella un poligono per "
                 "togliere la tavola, spostalo per spostarla." %
                 ((" - " + {"rfi": "RFI", "strade": "Strade", "acque": "Acque",
                            "sopr": "Soprintendenza", "parchi": "Parchi"}.get(ente, ente))
                  if ente else ""))
    b.clicked.connect(lambda *_a: calcola())
    r.addWidget(b)
    lbl = QLabel("")
    lbl.setWordWrap(True)
    r.addWidget(lbl, 1)
    combo.currentIndexChanged.connect(
        lambda *_a: lbl.setText("Scala cambiata: premi «Calcola numero di tavole» per rifare "
                                "i riquadri."))
    return r, lbl


def calcola_tavole(dlg, ente, istanze, riquadri, lbl, sez_per_tavola=1, etichetta=None):
    """«Calcola numero di tavole» per una scheda: `riquadri(ist)` ->
    (crs, [(scala, QgsRectangle)]) con la stessa divisione della stampa (senza
    leggere i riquadri già in mappa). Disegna i riquadri e dà la sintesi."""
    from qgis.PyQt.QtWidgets import QMessageBox
    try:
        from . import ftth_tavole_mappa as TM
    except ImportError:
        import ftth_tavole_mappa as TM
    if not istanze:
        return
    risultati = []
    for ist in istanze:
        if not ist.interferenze:
            continue
        crs, tav = riquadri(ist)
        risultati.append((ist, crs, tav))
    sintesi, testo = TM.mostra(dlg, ente, risultati, etichetta, sez_per_tavola)
    lbl.setText(sintesi)
    QMessageBox.information(dlg, "Tavole della PL", testo)


def pdf_anteprima_percorso(nome_layout: str) -> str:
    """PDF di anteprima nella cartella temporanea (mai nella cartella del
    progetto): un nome per layout, con l'ora se il precedente è ancora aperto."""
    import os
    import re
    import tempfile
    import time
    cart = os.path.join(tempfile.gettempdir(), "FTTH_anteprima_PL")
    os.makedirs(cart, exist_ok=True)
    base = re.sub(r'[\\/:*?"<>|]+', "_", nome_layout).strip() or "PL"
    p = os.path.join(cart, base + ".pdf")
    if os.path.exists(p):
        try:
            os.remove(p)
        except OSError:          # aperto nel lettore PDF: nome nuovo
            p = os.path.join(cart, "%s_%s.pdf" % (base, time.strftime("%H%M%S")))
    return p


def pdf_pagina_per_pagina(layout, percorso, avanza=None, dpi=200):
    """PDF del layout una pagina alla volta (QPrinter + renderPage), così si
    può mostrare l'avanzamento: `avanza(n, totale)` dopo ogni pagina, ritorna
    False per annullare. Ritorna True se scritto, False se annullato."""
    from qgis.core import QgsLayoutExporter, QgsUnitTypes
    from qgis.PyQt.QtCore import QMarginsF, QSizeF
    from qgis.PyQt.QtGui import QPageLayout, QPageSize, QPainter
    from qgis.PyQt.QtPrintSupport import QPrinter
    pc = layout.pageCollection()
    n = pc.pageCount()
    conv = layout.renderContext().measurementConverter()

    def _pl(i):
        s = conv.convert(pc.page(i).pageSize(), QgsUnitTypes.LayoutMillimeters)
        w, h = s.width(), s.height()
        ori = QPageLayout.Landscape if w > h else QPageLayout.Portrait
        return QPageLayout(QPageSize(QSizeF(min(w, h), max(w, h)), QPageSize.Millimeter),
                           ori, QMarginsF(0, 0, 0, 0))
    pr = QPrinter(QPrinter.HighResolution)
    pr.setOutputFormat(QPrinter.PdfFormat)
    pr.setOutputFileName(percorso)
    pr.setResolution(dpi)
    pr.setFullPage(True)
    pr.setPageLayout(_pl(0))
    exp = QgsLayoutExporter(layout)
    painter = QPainter()
    if not painter.begin(pr):
        raise RuntimeError("PDF non apribile: %s" % percorso)
    try:
        for i in range(n):
            if i:
                pr.setPageLayout(_pl(i))
                pr.newPage()
            exp.renderPage(painter, i)
            if avanza is not None and avanza(i + 1, n) is False:
                return False
    finally:
        painter.end()
    return True


def immagine_pagina(layout, pagina, larghezza_px=1600):
    """Una pagina del layout come QImage, larga `larghezza_px` (anteprima:
    niente PDF, si disegna solo la pagina richiesta)."""
    from qgis.core import QgsLayoutExporter, QgsUnitTypes
    from qgis.PyQt.QtCore import QSize
    pc = layout.pageCollection()
    s = layout.renderContext().measurementConverter().convert(
        pc.page(pagina).pageSize(), QgsUnitTypes.LayoutMillimeters)
    h = max(1, int(larghezza_px * s.height() / max(s.width(), 1)))
    return QgsLayoutExporter(layout).renderPageToImage(pagina, QSize(larghezza_px, h))


def anteprima_veloce(parent, layout):
    """Finestra con la PL disegnata come immagine, una pagina alla volta (la
    prima subito, le altre quando ci arrivi): si apre in pochi secondi, senza
    creare nessun PDF. «Salva PDF» resta lì se serve."""
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtGui import QPixmap
    from qgis.PyQt.QtWidgets import (QApplication, QDialog, QHBoxLayout, QLabel, QPushButton,
                                     QScrollArea, QVBoxLayout)
    n = layout.pageCollection().pageCount()
    w = QDialog(parent)
    w.setWindowTitle("Anteprima — %s" % layout.name())
    w.resize(1200, 860)
    v = QVBoxLayout(w)
    area = QScrollArea()
    area.setAlignment(Qt.AlignCenter)
    img = QLabel("preparo la pagina…")
    img.setAlignment(Qt.AlignCenter)
    area.setWidget(img)
    area.setWidgetResizable(True)
    v.addWidget(area, 1)
    r = QHBoxLayout()
    b_prec, b_succ = QPushButton("◀ Pagina precedente"), QPushButton("Pagina successiva ▶")
    lbl = QLabel("")
    b_zoom = QPushButton("Ingrandisci")
    b_zoom.setCheckable(True)
    b_pdf = QPushButton("Salva PDF…")
    b_pdf.setToolTip("Se ti serve il file: PDF di anteprima a bassa risoluzione.")
    b_ch = QPushButton("Chiudi")
    for x in (b_prec, lbl, b_succ, b_zoom):
        r.addWidget(x)
    r.addStretch()
    r.addWidget(b_pdf)
    r.addWidget(b_ch)
    v.addLayout(r)
    cache = {}
    stato = {"p": 0}

    def _mostra():
        p = stato["p"]
        largo = 2600 if b_zoom.isChecked() else 1600
        lbl.setText("pagina %d di %d" % (p + 1, n))
        b_prec.setEnabled(p > 0)
        b_succ.setEnabled(p < n - 1)
        chiave = (p, largo)
        if chiave not in cache:
            img.setText("preparo la pagina %d di %d…" % (p + 1, n))
            QApplication.processEvents()
            QApplication.setOverrideCursor(Qt.WaitCursor)
            try:
                cache[chiave] = QPixmap.fromImage(immagine_pagina(layout, p, largo))
            except Exception as e:  # noqa: BLE001
                img.setText("pagina non disegnata: %s" % e)
                return
            finally:
                QApplication.restoreOverrideCursor()
        pm = cache[chiave]
        if not b_zoom.isChecked():
            pm = pm.scaled(max(200, area.viewport().width() - 10),
                           max(200, area.viewport().height() - 10),
                           Qt.KeepAspectRatio, Qt.SmoothTransformation)
        img.setPixmap(pm)

    def _vai(d):
        stato["p"] = min(max(0, stato["p"] + d), n - 1)
        _mostra()
    b_prec.clicked.connect(lambda *_a: _vai(-1))
    b_succ.clicked.connect(lambda *_a: _vai(1))
    b_zoom.toggled.connect(lambda *_a: (area.setWidgetResizable(not b_zoom.isChecked()),
                                        _mostra()))
    b_pdf.clicked.connect(lambda *_a: _pdf_anteprima(w, layout))
    b_ch.clicked.connect(w.close)
    w.show()
    QApplication.processEvents()
    _mostra()
    parent._finestra_anteprima_pl = w
    return w


def _pdf_anteprima(parent, layout):
    """Esporta il layout in PDF (anteprima) con la barra di avanzamento
    (pagina per pagina) e lo apre."""
    import os
    from qgis.core import QgsLayoutExporter
    from qgis.PyQt.QtCore import Qt
    from qgis.PyQt.QtWidgets import QApplication, QMessageBox, QProgressDialog
    p = pdf_anteprima_percorso(layout.name())
    n = layout.pageCollection().pageCount()
    barra = QProgressDialog("Anteprima PDF: preparazione della pagina 1 di %d…" % n,
                            "Annulla", 0, n, parent)
    barra.setWindowTitle("Anteprima PDF")
    barra.setWindowModality(Qt.WindowModal)
    barra.setMinimumDuration(0)
    barra.setValue(0)
    barra.show()
    QApplication.processEvents()

    def _avanza(k, tot):
        barra.setValue(k)
        if k < tot:
            barra.setLabelText("Anteprima PDF: pagina %d di %d (ortofoto e catasto possono "
                               "richiedere qualche secondo)…" % (k + 1, tot))
        QApplication.processEvents()
        return not barra.wasCanceled()
    errore = ""
    QApplication.setOverrideCursor(Qt.WaitCursor)
    try:
        try:
            # anteprima, non stampa: bassa risoluzione, così è rapida (il PDF
            # vero è quello di «Genera le istanze»)
            ok = pdf_pagina_per_pagina(layout, p, _avanza, dpi=96)
        except Exception as e:  # noqa: BLE001
            # pagina per pagina non riuscito: esportazione normale di QGIS
            errore = str(e)
            barra.setLabelText("Anteprima PDF: esportazione in corso…")
            QApplication.processEvents()
            exp = QgsLayoutExporter(layout)
            imp = QgsLayoutExporter.PdfExportSettings()
            imp.dpi = 96
            imp.rasterizeWholeImage = True
            esito = exp.exportToPdf(p, imp)
            ok = esito == QgsLayoutExporter.Success
            if not ok:
                errore = "%s (codice %s) %s" % (errore, esito, exp.errorMessage() or "")
    finally:
        QApplication.restoreOverrideCursor()
        barra.close()
    if ok is False and barra.wasCanceled():
        return None
    if not ok or not os.path.exists(p):
        QMessageBox.warning(parent, "Anteprima PDF", "PDF non creato: %s" % (errore or "errore"))
        return None
    try:
        os.startfile(p)
    except Exception:  # noqa: BLE001
        pass
    return p


def anteprima_stampa(dlg):
    """Finestra con le PL (layout del progetto) e le RT trovate nella cartella
    del progetto: «Apri» mostra la PL nel compositore di stampe di QGIS e la RT
    nel programma predefinito (PDF o Word)."""
    import os
    from qgis.core import QgsProject
    from qgis.PyQt.QtWidgets import (QDialog, QHBoxLayout, QLabel, QPushButton, QScrollArea,
                                     QVBoxLayout, QWidget, QMessageBox)
    prj = QgsProject.instance()
    layouts = [l for l in prj.layoutManager().layouts() if " PL - " in l.name()]
    if not layouts:
        QMessageBox.information(dlg, "Anteprima di stampa",
                                "Nessuna PL pronta: premi prima «Modifica etichette in mappa» "
                                "o «Genera le istanze».")
        return
    home = prj.homePath()
    rt = {}
    if home:
        for radice, _dirs, files in os.walk(home):
            if radice[len(home):].count(os.sep) > 5:
                continue
            for f in files:
                if "_RT+CR." in f and f.lower().endswith((".pdf", ".docx")):
                    p = os.path.join(radice, f)
                    base = f.split("_RT+CR.")[0].split("_", 1)[-1]
                    if base not in rt or p.lower().endswith(".pdf"):
                        rt[base] = p
    w = QDialog(dlg)
    w.setWindowTitle("Anteprima di stampa")
    w.resize(640, 420)
    v = QVBoxLayout(w)
    v.addWidget(QLabel("PL e relazioni delle istanze. «Apri PL» mostra la tavola nel compositore "
                       "di stampe di QGIS; «Anteprima veloce» la mostra in una finestra, una "
                       "pagina alla volta, senza creare PDF; «Apri RT» la relazione."))
    area = QScrollArea()
    area.setWidgetResizable(True)
    corpo = QWidget()
    vc = QVBoxLayout(corpo)
    iface = getattr(dlg, "iface", None)
    for lay in sorted(layouts, key=lambda x: x.name()):
        base = lay.name().split(" PL - ", 1)[-1]
        riga = QHBoxLayout()
        riga.addWidget(QLabel(base), 1)
        b1 = QPushButton("Apri PL")
        b1.clicked.connect(lambda _c=False, l_=lay: iface.openLayoutDesigner(l_) if iface else None)
        riga.addWidget(b1)
        b_pdf = QPushButton("Anteprima veloce")
        b_pdf.setToolTip("La PL in una finestra, una pagina alla volta (la prima subito): niente "
                         "PDF. Dentro c'è «Salva PDF…» se ti serve il file. Il PDF vero è "
                         "quello di «Genera le istanze».")
        b_pdf.clicked.connect(lambda _c=False, l_=lay: anteprima_veloce(w, l_))
        riga.addWidget(b_pdf)
        p_rt = rt.get(base) or next((p for k, p in rt.items() if k.endswith(base) or base.endswith(k)),
                                     None)
        b2 = QPushButton("Apri RT")
        b2.setEnabled(bool(p_rt))
        b2.setToolTip(p_rt or "RT non ancora generata: premi «Genera le istanze».")
        b2.clicked.connect(lambda _c=False, p_=p_rt: os.startfile(p_) if p_ else None)
        riga.addWidget(b2)
        vc.addLayout(riga)
    vc.addStretch()
    area.setWidget(corpo)
    v.addWidget(area)
    b_ch = QPushButton("Chiudi")
    b_ch.clicked.connect(w.close)
    v.addWidget(b_ch)
    w.show()
    dlg._finestra_anteprima = w
