# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Scheda 'Unisci tratte' (Comune): fonde le tratte di Infrastrutture che si
toccano, hanno la stessa TIPOLOGIA e NON sono separate da un pozzetto.

Regola di dominio (verificata sui dati reali): i capi delle tratte coincidono
coi pozzetti. Quindi un nodo è un punto di giunzione "vero" solo se lì non c'è
un pozzetto; dove c'è il pozzetto la tratta DEVE restare spezzata.

Condizioni perché due tratte si fondano in un nodo:
  1. nel nodo si incontrano ESATTAMENTE 2 tratte (grado 2). Con 3+ è una
     diramazione e fondere sarebbe arbitrario. Il grado si conta su TUTTE
     le tratte presenti, comprese quelle che i filtri escludono dalla
     fusione: una tratta esistente non è fondibile, ma il ramo c'è;
  2. le due tratte hanno la stessa TIPOLOGIA (e stesso STATO, se richiesto);
  3. nel nodo NON cade un pozzetto (entro la tolleranza);
  4. nel nodo non PASSA uno scavo di tipologia diversa. Uno scavo che
     attraversa il punto di contatto fa da pozzetto, anche se lì non
     termina: quelle due tratte non vanno unite.

Le decisioni stanno in ftth_unisci.py, che si può provare sui progetti
veri senza aprire QGIS.

Misurato su Cervia (3445 tratte, 1400 pozzetti): 994 nodi fondibili,
3445 → 2451 tratte, con 715 nodi correttamente bloccati dai pozzetti.
"""
import os

try:
    from . import ftth_unisci
except ImportError:
    import ftth_unisci

from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsField, QgsProject, QgsGeometry, QgsPointXY,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsWkbTypes,
    QgsMapLayerProxyModel, QgsVectorFileWriter,
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QPushButton, QMessageBox, QCheckBox,
    QComboBox, QApplication, QPlainTextEdit,
)
from qgis.PyQt.QtCore import Qt


class UnisciTratteMixin:

    def _tab_unisci(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Fonde le tratte di Infrastrutture che si toccano, hanno la stessa "
            "tipologia e NON sono separate da un pozzetto. Serve a togliere gli "
            "spezzoni inutili creati dall'editing, senza perdere le interruzioni "
            "che contano.\n\n"
            "Una giunzione viene fusa solo se: nel punto si incontrano esattamente "
            "due tratte (una diramazione a 3+ rami non si tocca), le due tratte "
            "hanno la stessa tipologia, e lì NON c'è un pozzetto. Gli attributi "
            "della tratta risultante sono quelli del tronco più lungo; la lunghezza "
            "viene ricalcolata se esiste il campo."
        ))

        gb = self._gruppo("Layer", compresso=False); f = QFormLayout(gb)
        self.cb_un_infra = self._lcombo(QgsMapLayerProxyModel.LineLayer)
        f.addRow("Infrastrutture (linee):", self.cb_un_infra)
        self.cb_un_poz = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        f.addRow("Pozzetti (punti, interrompono la fusione):", self.cb_un_poz)

        self.cb_un_campo_tip = QComboBox()
        f.addRow("Campo tipologia:", self.cb_un_campo_tip)
        self.cb_un_campo_stato = QComboBox()
        f.addRow("Campo stato (opzionale, deve coincidere):", self.cb_un_campo_stato)
        try:
            self.cb_un_infra.layerChanged.connect(self._un_popola_campi)
        except Exception:
            pass

        self.spin_un_tol = self._dspin(0.01, 50, 0.50, 2, " m", step=0.05)
        f.addRow("Tolleranza coincidenza capi:", self.spin_un_tol)
        self.spin_un_tol_poz = self._dspin(0.01, 50, 1.00, 2, " m", step=0.05)
        f.addRow("Raggio pozzetto (blocca la fusione):", self.spin_un_tol_poz)
        v.addWidget(gb)

        self.chk_un_solo_nuovo = QCheckBox(
            "Solo tratte con STATO = Nuovo (lascia stare l'esistente)")
        v.addWidget(self.chk_un_solo_nuovo)
        self.chk_un_anteprima = QCheckBox(
            "Anteprima: conta soltanto, non modifica nulla")
        self.chk_un_anteprima.setChecked(True)
        v.addWidget(self.chk_un_anteprima)
        self.chk_un_backup = QCheckBox(
            "Prima di modificare, salva una copia di sicurezza del layer su disco")
        self.chk_un_backup.setChecked(True)
        v.addWidget(self.chk_un_backup)

        b = QPushButton("Unisci tratte della stessa tipologia")
        b.setStyleSheet("font-weight:bold")
        b.clicked.connect(self._un_esegui)
        v.addWidget(b)

        self.log_un = QPlainTextEdit(); self.log_un.setReadOnly(True)
        self.log_un.setMinimumHeight(140)
        v.addWidget(self.log_un)
        v.addStretch()
        self._un_popola_campi()
        return w

    def _log_un(self, msg):
        try:
            self.log_un.appendPlainText(str(msg))
            QApplication.processEvents()
        except Exception:
            pass

    def _un_popola_campi(self, *args):
        """Riempie i combo dei campi leggendo il layer scelto, preselezionando
        TIPOLOGIA e STATO quando ci sono."""
        try:
            lay = self.cb_un_infra.currentLayer()
        except Exception:
            return
        for combo, attesi in ((self.cb_un_campo_tip, ("TIPOLOGIA", "Tipologia", "tipologia", "TIPO")),
                              (self.cb_un_campo_stato, ("STATO", "Stato", "stato"))):
            try:
                combo.clear()
                if combo is self.cb_un_campo_stato:
                    combo.addItem("(ignora)", "")
                if lay is None:
                    continue
                nomi = [fl.name() for fl in lay.fields()]
                for n in nomi:
                    combo.addItem(n, n)
                for a in attesi:
                    i = combo.findData(a)
                    if i >= 0:
                        combo.setCurrentIndex(i); break
            except Exception:
                pass

    # ---------- geometria ----------

    @staticmethod
    def _un_punti(geom):
        """Lista di vertici di una linea (anche multipart con una sola parte)."""
        try:
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
                if not parts:
                    return []
                if len(parts) > 1:
                    return None      # multipart vero: non lo tocco
                return list(parts[0])
            return list(geom.asPolyline())
        except Exception:
            return None

    def _un_esegui(self):
        lay = self.cb_un_infra.currentLayer()
        if lay is None:
            QMessageBox.warning(self, "Nessun layer",
                "Scegli il layer delle Infrastrutture."); return
        campo_tip = self.cb_un_campo_tip.currentData()
        if not campo_tip:
            QMessageBox.warning(self, "Nessun campo tipologia",
                "Scegli il campo che contiene la tipologia."); return
        campo_stato = self.cb_un_campo_stato.currentData() or ""
        poz_lyr = self.cb_un_poz.currentLayer()
        # Guardia: i POZZETTI interrompono la fusione, gli ARMADI no. Scambiarli
        # non è distruttivo ma produce un risultato sbagliato in silenzio (tratte
        # fuse attraverso un pozzetto, perché il layer dei blocchi era un altro).
        # Meglio chiedere conferma che fondere male.
        if poz_lyr is not None:
            _n = (poz_lyr.name() or "").lower()
            if "armadio" in _n or "arlo" in _n:
                if QMessageBox.question(
                        self, "Layer pozzetti sospetto",
                        "Come layer che interrompe la fusione hai scelto:\n\n    %s\n\n"
                        "Sembra il layer degli ARMADI, non dei pozzetti. Un armadio "
                        "non spezza una tratta: con questa scelta verrebbero fuse "
                        "anche tratte separate da un pozzetto.\n\n"
                        "Vuoi continuare lo stesso?" % poz_lyr.name(),
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.No) != QMessageBox.Yes:
                    return
        tol = float(self.spin_un_tol.value())
        tol_poz = float(self.spin_un_tol_poz.value())
        solo_nuovo = self.chk_un_solo_nuovo.isChecked()
        anteprima = self.chk_un_anteprima.isChecked()

        self.log_un.clear()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # CRS metrico di lavoro: le tolleranze sono in metri
            crs_lyr = lay.crs()
            if crs_lyr.isValid() and crs_lyr.mapUnits() == 0:
                crs_work = crs_lyr; tr = None
            else:
                crs_work = QgsCoordinateReferenceSystem("EPSG:25832")
                tr = QgsCoordinateTransform(crs_lyr, crs_work,
                                            self.project.transformContext())
                self._log_un("Layer in unità non metriche (%s): lavoro in %s."
                             % (crs_lyr.authid(), crs_work.authid()))

            def to_work(g):
                if tr is None:
                    return g
                g2 = QgsGeometry(g); g2.transform(tr); return g2

            # --- pozzetti: chiavi di cella per il blocco ---
            poz_pts = []
            if poz_lyr is not None:
                for f in poz_lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty():
                        continue
                    gg = g
                    if poz_lyr.crs() != crs_work:
                        try:
                            trp = QgsCoordinateTransform(poz_lyr.crs(), crs_work,
                                                         self.project.transformContext())
                            gg = QgsGeometry(g); gg.transform(trp)
                        except Exception:
                            continue
                    try:
                        poz_pts.append(gg.centroid().asPoint())
                    except Exception:
                        pass
            self._log_un("Pozzetti letti: %d" % len(poz_pts))
            # Senza pozzetti NIENTE blocca la fusione, e il danno è silenzioso:
            # il log direbbe tranquillamente "bloccate da pozzetto: 0".
            if poz_lyr is not None and not poz_lyr.isValid():
                if QMessageBox.question(
                        self, "Layer pozzetti non leggibile",
                        "Il layer dei pozzetti «%s» non è leggibile (sorgente dati "
                        "rotta).\n\nSenza pozzetti NESSUNA fusione viene bloccata: "
                        "le tratte verrebbero unite anche attraverso i pozzetti.\n\n"
                        "Ripara prima la sorgente dati. Vuoi continuare lo stesso?"
                        % poz_lyr.name(),
                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                    return
            elif poz_lyr is not None and not poz_pts:
                # Layer valido ma nessun pozzetto letto: sorgente sbagliata,
                # filtro attivo o subset string. Il danno è identico a non
                # avere il layer, quindi va detto con la stessa forza.
                if QMessageBox.question(
                        self, "Nessun pozzetto letto",
                        "Dal layer «%s» non è stato letto NESSUN pozzetto (il "
                        "layer è valido ma vuoto, oppure ha un filtro attivo)."
                        "\n\nSenza pozzetti NESSUNA fusione viene bloccata: le "
                        "tratte verrebbero unite anche attraverso i pozzetti."
                        "\n\nVuoi continuare lo stesso?" % poz_lyr.name(),
                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                    return
            elif poz_lyr is None:
                if QMessageBox.question(
                        self, "Nessun layer pozzetti",
                        "Non hai scelto il layer dei pozzetti.\n\nSenza pozzetti "
                        "nessuna fusione viene bloccata e le tratte verranno unite "
                        "anche dove c'è un pozzetto.\n\nVuoi continuare lo stesso?",
                        QMessageBox.Yes | QMessageBox.No, QMessageBox.No) != QMessageBox.Yes:
                    return

            # Il blocco sui pozzetti vive in ftth_unisci.Pozzetti: qui
            # restava una seconda copia mai chiamata, che faceva credere
            # a chi rilegge che il controllo avvenisse in questo punto.

            # --- leggi tratte ---
            # Si leggono TUTTE le tratte, anche quelle che i filtri escludono
            # dalla fusione. Una tratta esistente che arriva sul nodo non è
            # fondibile, ma il ramo c'è: ignorarla significa fondere attraverso
            # una diramazione vera, ed è il difetto che si vedeva più spesso
            # sui dati reali. Eleggibilità alla fusione e topologia della rete
            # sono due cose diverse.
            idx_stato = lay.fields().indexOf(campo_stato) if campo_stato else -1
            tratte = {}      # fid -> dict(pts, tip, stato, geom, len, eleggibile)
            saltate_mp = saltate_degeneri = n_elegg = 0
            for f in lay.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                gw = to_work(g)
                pts = self._un_punti(gw)
                if pts is None:
                    saltate_mp += 1; continue
                if len(pts) < 2:
                    saltate_degeneri += 1; continue
                st = str(f[campo_stato]) if idx_stato >= 0 and f[campo_stato] is not None else ""
                elegg = (not solo_nuovo) or st.strip().lower() in ("nuovo", "nuova")
                if elegg:
                    n_elegg += 1
                tip = f[campo_tip]
                tratte[f.id()] = {
                    "pts": pts,
                    "tip": "" if tip is None else str(tip).strip(),
                    "stato": st,
                    "geom": gw,
                    "len": gw.length(),
                    "eleggibile": elegg,
                }
            self._log_un("Tratte lette: %d (fondibili con i filtri scelti: %d)"
                         % (len(tratte), n_elegg))
            if saltate_mp:
                self._log_un("  saltate perché multipart: %d" % saltate_mp)
            if saltate_degeneri:
                self._log_un("  saltate perché curve o degeneri: %d" % saltate_degeneri)
            if not n_elegg:
                QMessageBox.information(self, "Niente da fare",
                    "Nessuna tratta valida da unire con i filtri scelti."); return

            # --- giunzioni fondibili (le regole stanno in ftth_unisci.py) ---
            giunzioni, motivi, esempi = ftth_unisci.analizza(
                tratte, poz_pts, tol, tol_poz, bool(campo_stato))

            self._log_un("")
            self._log_un("Giunzioni fondibili: %d" % len(giunzioni))
            self._log_un("  bloccate da un pozzetto      : %d" % motivi["pozzetto"])
            self._log_un("  bloccate da scavo che passa  : %d" % motivi["attraversato"])
            self._log_un("  diramazioni (3 o più rami)   : %d" % motivi["diramazione"])
            self._log_un("  bloccate da tipologia diversa: %d" % motivi["tipologia"])
            if campo_stato:
                self._log_un("  bloccate da stato diverso    : %d" % motivi["stato"])
            self._log_un("  un ramo escluso dai filtri   : %d" % motivi["non_eleggibile"])
            self._log_un("  capi liberi (fine rete)      : %d" % motivi["capo_libero"])
            if motivi["anello"]:
                self._log_un("  tratte ad anello             : %d" % motivi["anello"])
            for pt, fids in esempi.get("attraversato", [])[:3]:
                self._log_un("     scavo passante a %.1f, %.1f (tratte %s)"
                             % (pt.x(), pt.y(), ", ".join(str(x) for x in fids)))

            # --- catene da fondere ---
            gruppi = ftth_unisci.gruppi_da_giunzioni(tratte, giunzioni)
            n_membri = sum(len(v) for v in gruppi)
            n_dopo = len(tratte) - (n_membri - len(gruppi))
            self._log_un("")
            self._log_un("Gruppi da fondere: %d" % len(gruppi))
            self._log_un("Tratte: %d → %d" % (len(tratte), n_dopo))

            if anteprima:
                QMessageBox.information(self, "Anteprima",
                    "Fondibili %d giunzioni in %d gruppi.\nTratte: %d → %d.\n\n"
                    "Bloccate: %d da pozzetto, %d da scavo che passa, %d diramazioni.\n\n"
                    "Nessuna modifica fatta: togli la spunta «Anteprima» per "
                    "applicare." % (len(giunzioni), len(gruppi),
                                    len(tratte), n_dopo, motivi["pozzetto"],
                                    motivi["attraversato"], motivi["diramazione"]))
                return
            if not gruppi:
                QMessageBox.information(self, "Niente da unire",
                    "Nessuna tratta soddisfa le condizioni di fusione."); return

            # --- backup ---
            if self.chk_un_backup.isChecked():
                try:
                    src = (lay.source() or "").split("|")[0]
                    if src and os.path.isfile(src):
                        import datetime
                        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                        base, est = os.path.splitext(src)
                        dest = "%s_BACKUP_%s.gpkg" % (base, stamp)
                        opz = QgsVectorFileWriter.SaveVectorOptions()
                        opz.driverName = "GPKG"
                        opz.fileEncoding = "UTF-8"
                        QgsVectorFileWriter.writeAsVectorFormatV3(
                            lay, dest, self.project.transformContext(), opz)
                        self._log_un("Backup salvato: %s" % dest)
                except Exception as e:
                    self._log_un("ATTENZIONE: backup non riuscito (%s)" % e)

            # --- fusione ---
            if not self._start_edit(lay):
                QMessageBox.critical(self, "Errore",
                    "Impossibile avviare la modifica sul layer."); return

            tr_back = None
            if tr is not None:
                tr_back = QgsCoordinateTransform(crs_work, crs_lyr,
                                                 self.project.transformContext())
            idx_lung = -1
            for cand in ("LUNGHEZZA", "Lunghezza", "lunghezza", "LENGTH"):
                idx_lung = lay.fields().indexOf(cand)
                if idx_lung >= 0:
                    break

            fuse = 0; eliminate = []; rifiutati = 0; falliti = 0
            multi = QgsWkbTypes.isMultiType(lay.wkbType())
            for membri in gruppi:
                ordine = ftth_unisci.ordina_catena(membri, giunzioni)
                if ordine is None:
                    # non è una fila semplice (anello o diramazione sfuggita):
                    # meglio lasciarla stare che inventarsi un percorso
                    rifiutati += 1; continue
                pts = ftth_unisci.punti_catena(tratte, ordine, tol)
                if not pts:
                    rifiutati += 1; continue
                fusa = QgsGeometry.fromPolylineXY(pts)
                lung_m = fusa.length()          # misurata nel CRS metrico
                if tr_back is not None:
                    fusa = QgsGeometry(fusa); fusa.transform(tr_back)
                if multi:
                    fusa.convertToMultiType()
                principale = max(membri, key=lambda x: tratte[x]["len"])
                # La scrittura può fallire (tipo geometrico incompatibile, layer
                # di sola lettura). Prima si cancellavano i membri comunque, e
                # il dato spariva: adesso se non si scrive non si cancella.
                if not lay.changeGeometry(principale, fusa):
                    falliti += 1
                    self._log_un("ATTENZIONE: geometria non scritta su fid %s; "
                                 "le %d tratte del gruppo restano separate."
                                 % (principale, len(membri)))
                    continue
                if idx_lung >= 0:
                    try:
                        lay.changeAttributeValue(principale, idx_lung,
                                                 float(round(lung_m, 2)))
                    except Exception as e:
                        self._log_un("lunghezza non aggiornata su fid %s (%s)"
                                     % (principale, e))
                eliminate.extend([fid for fid in membri if fid != principale])
                fuse += 1

            if rifiutati:
                self._log_un("Gruppi lasciati stare (anelli o catene non "
                             "lineari): %d" % rifiutati)
            if falliti:
                self._log_un("Gruppi NON fusi per errore di scrittura: %d "
                             "(nessuna tratta è stata cancellata)" % falliti)

            if eliminate:
                # Meta' mancante della protezione fatta su changeGeometry: se la
                # cancellazione fallisce (layer di sola lettura, vincolo sul
                # GeoPackage) la geometria fusa resta scritta E le tratte membro
                # pure, cioe' linee sovrapposte e metri contati due volte.
                if not lay.deleteFeatures(eliminate):
                    self._log_un("ATTENZIONE: cancellazione delle %d tratte "
                                 "assorbite NON riuscita. Le geometrie fuse "
                                 "sono state scritte: annulla la modifica "
                                 "(Ctrl+Z) per non lasciare linee doppie."
                                 % len(eliminate))
                    QMessageBox.warning(self, "Unione tratte",
                        "Le tratte assorbite non sono state cancellate: il "
                        "layer conterrebbe linee doppie.\n\nAnnulla la "
                        "modifica (Ctrl+Z) e verifica che il layer sia "
                        "scrivibile.")
                    return
            if not self._commit(lay, "Errore nel salvataggio dell'unione tratte"):
                return
            lay.triggerRepaint()
            self._log_un("")
            self._log_un("FATTO: %d gruppi fusi, %d tratte eliminate."
                         % (fuse, len(eliminate)))
            msg = ("Fusi %d gruppi di tratte.\nTratte eliminate: %d.\n"
                   "Totale ora: %d." % (fuse, len(eliminate), lay.featureCount()))
            if rifiutati or falliti:
                msg += ("\n\nNon fusi: %d gruppi non lineari, %d per errore di "
                        "scrittura. Nessuna tratta di questi gruppi è stata "
                        "cancellata." % (rifiutati, falliti))
            QMessageBox.information(self, "Unione completata", msg)
        finally:
            QApplication.restoreOverrideCursor()
