# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Scheda 'Unisci tratte' (Comune): fonde le tratte di Infrastrutture che si
toccano, hanno la stessa TIPOLOGIA e NON sono separate da un pozzetto.

Regola di dominio (verificata sui dati reali): i capi delle tratte coincidono
coi pozzetti. Quindi un nodo è un punto di giunzione "vero" solo se lì non c'è
un pozzetto; dove c'è il pozzetto la tratta DEVE restare spezzata.

Condizioni perché due tratte si fondano in un nodo:
  1. nel nodo si incontrano ESATTAMENTE 2 tratte (grado 2). Con 3+ è una
     diramazione e fondere sarebbe arbitrario;
  2. le due tratte hanno la stessa TIPOLOGIA (e stesso STATO, se richiesto);
  3. nel nodo NON cade un pozzetto (entro la tolleranza).

Misurato su Cervia (3445 tratte, 1400 pozzetti): 994 nodi fondibili,
3445 → 2451 tratte, con 715 nodi correttamente bloccati dai pozzetti.
"""
import os

from qgis.core import (
    QgsVectorLayer, QgsFeature, QgsField, QgsProject, QgsGeometry, QgsPointXY,
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsWkbTypes,
    QgsMapLayerProxyModel, QgsVectorFileWriter,
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtWidgets import (
    QWidget, QVBoxLayout, QFormLayout, QPushButton, QMessageBox, QCheckBox,
    QComboBox, QApplication, QPlainTextEdit,
)
from qgis.PyQt.QtCore import Qt


class UnisciTratteMixin:

    def _tab_unisci(self):
        w = QWidget(); v = QVBoxLayout(w)
        v.addWidget(self._desc(
            "Fonde le tratte di Infrastrutture che si toccano, hanno la stessa "
            "tipologia e NON sono separate da un pozzetto. Serve a togliere gli "
            "spezzoni inutili creati dall'editing, senza perdere le interruzioni "
            "che contano.\n\n"
            "Una giunzione viene fusa solo se: nel punto si incontrano esattamente "
            "due tratte (una diramazione a 3+ rami non si tocca), le due tratte "
            "hanno la stessa tipologia, e lì NON c'è un pozzetto. Gli attributi "
            "della tratta risultante sono quelli del tronco più lungo; la lunghezza "
            "viene ricalcolata se esiste il campo."
        ))

        gb = self._gruppo("Layer", compresso=False); f = QFormLayout(gb)
        self.cb_un_infra = self._lcombo(QgsMapLayerProxyModel.LineLayer)
        f.addRow("Infrastrutture (linee):", self.cb_un_infra)
        self.cb_un_poz = self._lcombo(QgsMapLayerProxyModel.PointLayer, allow_empty=True)
        f.addRow("Pozzetti (punti, interrompono la fusione):", self.cb_un_poz)

        self.cb_un_campo_tip = QComboBox()
        f.addRow("Campo tipologia:", self.cb_un_campo_tip)
        self.cb_un_campo_stato = QComboBox()
        f.addRow("Campo stato (opzionale, deve coincidere):", self.cb_un_campo_stato)
        try:
            self.cb_un_infra.layerChanged.connect(self._un_popola_campi)
        except Exception:
            pass

        self.spin_un_tol = self._dspin(0.01, 50, 0.50, 2, " m", step=0.05)
        f.addRow("Tolleranza coincidenza capi:", self.spin_un_tol)
        self.spin_un_tol_poz = self._dspin(0.01, 50, 1.00, 2, " m", step=0.05)
        f.addRow("Raggio pozzetto (blocca la fusione):", self.spin_un_tol_poz)
        v.addWidget(gb)

        self.chk_un_solo_nuovo = QCheckBox(
            "Solo tratte con STATO = Nuovo (lascia stare l'esistente)")
        v.addWidget(self.chk_un_solo_nuovo)
        self.chk_un_anteprima = QCheckBox(
            "Anteprima: conta soltanto, non modifica nulla")
        self.chk_un_anteprima.setChecked(True)
        v.addWidget(self.chk_un_anteprima)
        self.chk_un_backup = QCheckBox(
            "Prima di modificare, salva una copia di sicurezza del layer su disco")
        self.chk_un_backup.setChecked(True)
        v.addWidget(self.chk_un_backup)

        b = QPushButton("Unisci tratte della stessa tipologia")
        b.setStyleSheet("font-weight:bold")
        b.clicked.connect(self._un_esegui)
        v.addWidget(b)

        self.log_un = QPlainTextEdit(); self.log_un.setReadOnly(True)
        self.log_un.setMinimumHeight(140)
        v.addWidget(self.log_un)
        v.addStretch()
        self._un_popola_campi()
        return w

    def _log_un(self, msg):
        try:
            self.log_un.appendPlainText(str(msg))
            QApplication.processEvents()
        except Exception:
            pass

    def _un_popola_campi(self, *args):
        """Riempie i combo dei campi leggendo il layer scelto, preselezionando
        TIPOLOGIA e STATO quando ci sono."""
        try:
            lay = self.cb_un_infra.currentLayer()
        except Exception:
            return
        for combo, attesi in ((self.cb_un_campo_tip, ("TIPOLOGIA", "Tipologia", "tipologia", "TIPO")),
                              (self.cb_un_campo_stato, ("STATO", "Stato", "stato"))):
            try:
                combo.clear()
                if combo is self.cb_un_campo_stato:
                    combo.addItem("(ignora)", "")
                if lay is None:
                    continue
                nomi = [fl.name() for fl in lay.fields()]
                for n in nomi:
                    combo.addItem(n, n)
                for a in attesi:
                    i = combo.findData(a)
                    if i >= 0:
                        combo.setCurrentIndex(i); break
            except Exception:
                pass

    # ---------- geometria ----------

    @staticmethod
    def _un_punti(geom):
        """Lista di vertici di una linea (anche multipart con una sola parte)."""
        try:
            if geom.isMultipart():
                parts = geom.asMultiPolyline()
                if not parts:
                    return []
                if len(parts) > 1:
                    return None      # multipart vero: non lo tocco
                return list(parts[0])
            return list(geom.asPolyline())
        except Exception:
            return None

    def _un_esegui(self):
        lay = self.cb_un_infra.currentLayer()
        if lay is None:
            QMessageBox.warning(self, "Nessun layer",
                "Scegli il layer delle Infrastrutture."); return
        campo_tip = self.cb_un_campo_tip.currentData()
        if not campo_tip:
            QMessageBox.warning(self, "Nessun campo tipologia",
                "Scegli il campo che contiene la tipologia."); return
        campo_stato = self.cb_un_campo_stato.currentData() or ""
        poz_lyr = self.cb_un_poz.currentLayer()
        # Guardia: i POZZETTI interrompono la fusione, gli ARMADI no. Scambiarli
        # non è distruttivo ma produce un risultato sbagliato in silenzio (tratte
        # fuse attraverso un pozzetto, perché il layer dei blocchi era un altro).
        # Meglio chiedere conferma che fondere male.
        if poz_lyr is not None:
            _n = (poz_lyr.name() or "").lower()
            if "armadio" in _n or "arlo" in _n:
                if QMessageBox.question(
                        self, "Layer pozzetti sospetto",
                        "Come layer che interrompe la fusione hai scelto:\n\n    %s\n\n"
                        "Sembra il layer degli ARMADI, non dei pozzetti. Un armadio "
                        "non spezza una tratta: con questa scelta verrebbero fuse "
                        "anche tratte separate da un pozzetto.\n\n"
                        "Vuoi continuare lo stesso?" % poz_lyr.name(),
                        QMessageBox.Yes | QMessageBox.No,
                        QMessageBox.No) != QMessageBox.Yes:
                    return
        tol = float(self.spin_un_tol.value())
        tol_poz = float(self.spin_un_tol_poz.value())
        solo_nuovo = self.chk_un_solo_nuovo.isChecked()
        anteprima = self.chk_un_anteprima.isChecked()

        self.log_un.clear()
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            # CRS metrico di lavoro: le tolleranze sono in metri
            crs_lyr = lay.crs()
            if crs_lyr.isValid() and crs_lyr.mapUnits() == 0:
                crs_work = crs_lyr; tr = None
            else:
                crs_work = QgsCoordinateReferenceSystem("EPSG:25832")
                tr = QgsCoordinateTransform(crs_lyr, crs_work,
                                            self.project.transformContext())
                self._log_un("Layer in unità non metriche (%s): lavoro in %s."
                             % (crs_lyr.authid(), crs_work.authid()))

            def to_work(g):
                if tr is None:
                    return g
                g2 = QgsGeometry(g); g2.transform(tr); return g2

            # --- pozzetti: chiavi di cella per il blocco ---
            poz_pts = []
            if poz_lyr is not None:
                for f in poz_lyr.getFeatures():
                    g = f.geometry()
                    if not g or g.isEmpty():
                        continue
                    gg = g
                    if poz_lyr.crs() != crs_work:
                        try:
                            trp = QgsCoordinateTransform(poz_lyr.crs(), crs_work,
                                                         self.project.transformContext())
                            gg = QgsGeometry(g); gg.transform(trp)
                        except Exception:
                            continue
                    try:
                        poz_pts.append(gg.centroid().asPoint())
                    except Exception:
                        pass
            self._log_un("Pozzetti letti: %d" % len(poz_pts))

            def ck(pt, t):
                return (int(round(pt.x() / t)), int(round(pt.y() / t)))

            # celle occupate da un pozzetto (3x3 per non perdere i bordi cella)
            poz_cells = set()
            for p in poz_pts:
                cx, cy = ck(p, tol_poz)
                for dx in (-1, 0, 1):
                    for dy in (-1, 0, 1):
                        poz_cells.add((cx + dx, cy + dy))

            def ha_pozzetto(pt):
                if not poz_pts:
                    return False
                if ck(pt, tol_poz) not in poz_cells:
                    return False
                for p in poz_pts:                       # conferma esatta
                    if (p.x() - pt.x()) ** 2 + (p.y() - pt.y()) ** 2 <= tol_poz ** 2:
                        return True
                return False

            # --- leggi tratte ---
            idx_stato = lay.fields().indexOf(campo_stato) if campo_stato else -1
            tratte = {}      # fid -> dict(punti, tip, stato, lung)
            saltate_mp = 0
            for f in lay.getFeatures():
                g = f.geometry()
                if not g or g.isEmpty():
                    continue
                gw = to_work(g)
                pts = self._un_punti(gw)
                if pts is None:
                    saltate_mp += 1; continue
                if len(pts) < 2:
                    continue
                st = str(f[campo_stato]) if idx_stato >= 0 and f[campo_stato] is not None else ""
                if solo_nuovo and st.strip().lower() not in ("nuovo", "nuova"):
                    continue
                tip = f[campo_tip]
                tratte[f.id()] = {
                    "pts": pts,
                    "tip": "" if tip is None else str(tip).strip(),
                    "stato": st,
                    "len": gw.length(),
                }
            self._log_un("Tratte considerate: %d%s"
                         % (len(tratte), (" (saltate %d multipart)" % saltate_mp) if saltate_mp else ""))
            if not tratte:
                QMessageBox.information(self, "Niente da fare",
                    "Nessuna tratta valida da unire con i filtri scelti."); return

            # --- nodi ---
            nodi = {}
            for fid, d in tratte.items():
                for pt in (d["pts"][0], d["pts"][-1]):
                    nodi.setdefault(ck(pt, tol), []).append((fid, pt))

            # --- giunzioni fondibili ---
            giunzioni = []
            bl_poz = bl_tip = bl_grado = bl_stato = 0
            for k, lst in nodi.items():
                if len(lst) != 2:
                    bl_grado += 1; continue
                (a, pa), (b, pb) = lst
                if a == b:
                    continue                      # anello su se stessa
                if ha_pozzetto(pa):
                    bl_poz += 1; continue
                if tratte[a]["tip"] != tratte[b]["tip"]:
                    bl_tip += 1; continue
                if campo_stato and tratte[a]["stato"] != tratte[b]["stato"]:
                    bl_stato += 1; continue
                giunzioni.append((a, b))

            self._log_un("")
            self._log_un("Giunzioni fondibili: %d" % len(giunzioni))
            self._log_un("  bloccate da pozzetto : %d" % bl_poz)
            self._log_un("  bloccate da tipologia: %d" % bl_tip)
            if campo_stato:
                self._log_un("  bloccate da stato    : %d" % bl_stato)
            self._log_un("  nodi non a 2 rami    : %d" % bl_grado)

            # --- catene (union-find sulle giunzioni) ---
            padre = {fid: fid for fid in tratte}
            def trova(x):
                while padre[x] != x:
                    padre[x] = padre[padre[x]]; x = padre[x]
                return x
            for a, b in giunzioni:
                ra, rb = trova(a), trova(b)
                if ra != rb:
                    padre[rb] = ra
            gruppi = {}
            for fid in tratte:
                gruppi.setdefault(trova(fid), []).append(fid)
            da_fondere = {r: v for r, v in gruppi.items() if len(v) > 1}

            n_dopo = len(tratte) - sum(len(v) - 1 for v in da_fondere.values())
            self._log_un("")
            self._log_un("Gruppi da fondere: %d" % len(da_fondere))
            self._log_un("Tratte: %d → %d" % (len(tratte), n_dopo))

            if anteprima:
                QMessageBox.information(self, "Anteprima",
                    "Fondibili %d giunzioni in %d gruppi.\nTratte: %d → %d.\n\n"
                    "Nessuna modifica fatta: togli la spunta «Anteprima» per "
                    "applicare." % (len(giunzioni), len(da_fondere),
                                    len(tratte), n_dopo))
                return
            if not da_fondere:
                QMessageBox.information(self, "Niente da unire",
                    "Nessuna tratta soddisfa le condizioni di fusione."); return

            # --- backup ---
            if self.chk_un_backup.isChecked():
                try:
                    src = (lay.source() or "").split("|")[0]
                    if src and os.path.isfile(src):
                        import datetime
                        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
                        base, est = os.path.splitext(src)
                        dest = "%s_BACKUP_%s.gpkg" % (base, stamp)
                        opz = QgsVectorFileWriter.SaveVectorOptions()
                        opz.driverName = "GPKG"
                        opz.fileEncoding = "UTF-8"
                        QgsVectorFileWriter.writeAsVectorFormatV3(
                            lay, dest, self.project.transformContext(), opz)
                        self._log_un("Backup salvato: %s" % dest)
                except Exception as e:
                    self._log_un("ATTENZIONE: backup non riuscito (%s)" % e)

            # --- fusione ---
            if not self._start_edit(lay):
                QMessageBox.critical(self, "Errore",
                    "Impossibile avviare la modifica sul layer."); return

            tr_back = None
            if tr is not None:
                tr_back = QgsCoordinateTransform(crs_work, crs_lyr,
                                                 self.project.transformContext())
            idx_lung = -1
            for cand in ("LUNGHEZZA", "Lunghezza", "lunghezza", "LENGTH"):
                idx_lung = lay.fields().indexOf(cand)
                if idx_lung >= 0:
                    break

            fuse = 0; eliminate = []
            for radice, membri in da_fondere.items():
                geoms = []
                for fid in membri:
                    g = lay.getFeature(fid).geometry()
                    geoms.append(to_work(g))
                unione = QgsGeometry.unaryUnion(geoms)
                if unione is None or unione.isEmpty():
                    continue
                # mergeLines ricuce i segmenti contigui in una polilinea unica
                try:
                    fusa = unione.mergeLines()
                    if fusa is None or fusa.isEmpty():
                        fusa = unione
                except Exception:
                    fusa = unione
                # tratta "principale" = la più lunga: tiene i suoi attributi
                principale = max(membri, key=lambda x: tratte[x]["len"])
                if tr_back is not None:
                    fusa = QgsGeometry(fusa); fusa.transform(tr_back)
                lay.changeGeometry(principale, fusa)
                if idx_lung >= 0:
                    try:
                        lung = fusa.length() if tr is None else unione.length()
                        lay.changeAttributeValue(principale, idx_lung, float(round(lung, 2)))
                    except Exception:
                        pass
                for fid in membri:
                    if fid != principale:
                        eliminate.append(fid)
                fuse += 1

            if eliminate:
                lay.deleteFeatures(eliminate)
            if not self._commit(lay, "Errore nel salvataggio dell'unione tratte"):
                return
            lay.triggerRepaint()
            self._log_un("")
            self._log_un("FATTO: %d gruppi fusi, %d tratte eliminate."
                         % (fuse, len(eliminate)))
            QMessageBox.information(self, "Unione completata",
                "Fusi %d gruppi di tratte.\nTratte eliminate: %d.\n"
                "Totale ora: %d." % (fuse, len(eliminate), lay.featureCount()))
        finally:
            QApplication.restoreOverrideCursor()
