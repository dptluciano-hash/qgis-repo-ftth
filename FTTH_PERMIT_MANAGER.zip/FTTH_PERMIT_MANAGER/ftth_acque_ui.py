# -*- coding: utf-8 -*-
"""
ftth_acque_ui.py — Scheda "Istanze Acque" del plugin FTTH Permessi Manager.

Mixin (AcqueMixin) agganciato a FTTHPermessiDialog, come la scheda RFI di cui
riusa i servizi (Overpass, conversione geometrie, etichette). La logica sta in
ftth_acque.py. (c) Beexact S.r.l.

Flusso:
  1) Comune
  2) Corsi d'acqua e costa: OSM (fiumi, torrenti, canali, fossi, linea di
     costa) e/o un layer del progetto (reticolo regionale, dividente demaniale
     SITR...), fasce per categoria, comprensori di bonifica facoltativi
  3) Interferenze: attraversamenti e parallelismi, tecnica e ente proposti
  4) Destinatari per ente
  (5) documenti: prossimo passo
"""
import json
import os

from qgis.PyQt.QtCore import QVariant, Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QFormLayout, QHBoxLayout,
    QHeaderView, QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QWidget,
)
from qgis.core import (
    QgsCategorizedSymbolRenderer, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsFeature, QgsField, QgsFillSymbol, QgsGeometry, QgsLineSymbol, QgsMarkerSymbol,
    QgsPointXY, QgsRectangle, QgsRendererCategory, QgsSingleSymbolRenderer, QgsVectorLayer,
)

GRUPPO_ACQUE = "Acque - Demanio idrico e marittimo"
NOME_LAYER_DISEGNATI = "Corsi d'acqua disegnati"
NOME_ETICHETTE = "Etichette acque"
NOME_TRATTE = "Tratte in fascia acque"
LAYER_ACQUE = [NOME_ETICHETTE, "Interferenze acque", NOME_TRATTE, "Corsi d'acqua e costa",
               "Fascia di rispetto acque"]
# voci del progetto QGIS (QgsProject.writeEntry) con il lavoro della scheda
PRJ_SCOPE = "ftth_acque"
COLORI = {"demanio": QColor(0, 90, 200), "bonifica": QColor(60, 170, 230),
          "marittimo": QColor(0, 50, 120)}

C_INCL, C_ID, C_TIPO, C_CORSO, C_CAT, C_ENTE, C_ENTE_NOME, C_TEC, C_VIA, C_METRI, \
    C_POZZ, C_DIST, C_ETICH, C_NOTE = range(14)
INTESTAZIONI = ["Incl.", "N.", "Tipo", "Corso d'acqua", "Categoria", "Ente", "Nome ente",
                "Come si passa", "Via", "Metri", "Pozzetti", "Dist. (m)",
                "Etichette in tavola (doppio clic)", "Note"]
SEP_RIGHE = " / "
ACQ_COL_VALIDA = 9      # colonna Conferma / Escludi dell'elenco del punto 2
TIP_SALVA = (
    "Scrive in un GeoPackage accanto al progetto (01_File shp\\Acque) i layer del gruppo "
    "«%s» — corsi d'acqua, fascia, interferenze, tratte in fascia ed etichette — con gli "
    "stili, li rimette nel progetto e poi salva il progetto (chiede conferma). Alla "
    "riapertura «Trova le interferenze» riprende testi delle etichette, enti e spunte. I testi si "
    "possono correggere anche dalla tabella attributi del layer «Etichette acque» (campo "
    "testo; vuoto = testo proposto).")


def _righe_da_testo(s) -> str:
    """Testo del layer/tabella (righe separate da ' / ' o a capo) -> righe con \\n."""
    s = str(s or "").replace(SEP_RIGHE, "\n")
    return "\n".join(p.strip() for p in s.split("\n") if p.strip())


class _RicercaInterrotta(BaseException):
    """Pulsante «Interrompi»: BaseException apposta, cosi' nessun
    `except Exception` lungo la strada la trasforma in un errore qualsiasi e la
    ricerca si ferma davvero."""


def _norm_comune(s) -> str:
    """Nome di comune confrontabile: minuscolo, senza accenti, apostrofi e spazi doppi."""
    import unicodedata
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode()
    return " ".join(s.lower().replace("'", " ").replace("-", " ").split())


def _comune_del_punto(lat, lon):
    """Nome del comune in cui cade il punto (Nominatim reverse, livello
    comunale), o None se non si riesce a saperlo."""
    try:
        try:
            from . import ftth_screening as scr
        except ImportError:
            import ftth_screening as scr
        import requests
        r = requests.get(scr.NOMINATIM.replace("/search", "/reverse"),
                         params={"lat": lat, "lon": lon, "format": "json", "zoom": 10,
                                 "addressdetails": 1, "accept-language": "it"},
                         headers={"User-Agent": scr.UA}, timeout=30)
        r.raise_for_status()
        a = r.json().get("address") or {}
        return (a.get("city") or a.get("town") or a.get("village") or a.get("municipality")
                or None)
    except Exception:  # noqa: BLE001
        return None


def _acq_mod():
    try:
        from . import ftth_acque as acq
    except ImportError:
        import ftth_acque as acq
    return acq


class AcqueMixin:
    """Metodi della scheda Istanze Acque. Mescolato in FTTHPermessiDialog."""

    # ------------------------------------------------------------------ UI
    def _tab_acque(self):
        acq = _acq_mod()
        w = QWidget()
        v = QVBoxLayout(w)
        from . import ftth_passi as _P
        v.addWidget(_P.intro(
            self, "acque",
            "Istanze art. 49 per canali dei Consorzi di bonifica, demanio idrico (Regione / "
            "Genio Civile), reticolo minore comunale e demanio marittimo."))
        try:
            from . import ftth_leggimi as _LG
            v.addWidget(_LG.riga(self, "acque"))
        except Exception:  # noqa: BLE001
            pass

        # 1) comune
        gb1 = self._gruppo(_P.titolo(1, "acque"), compresso=False)
        f1 = QFormLayout(gb1)
        self.txt_acq_comune = QLineEdit(); self.txt_acq_comune.setPlaceholderText("es. BESNATE")
        self.txt_acq_comune.setToolTip("Scritto il comune (Invio o cambio campo) provincia e "
                                       "CAP si compilano da soli.")
        self.txt_acq_comune.editingFinished.connect(self._acq_auto_comune)
        try:                                    # suggerimento comuni ISTAT
            from . import ftth_comuni as _COM
            _COM.aggiungi_suggerimenti(self.txt_acq_comune, maiuscolo=True)
        except Exception:
            pass
        # stesso riquadro di Soprintendenza, Parchi e Strade: comune, Prov. e
        # CAP su una riga, poi indirizzo e PEC del Comune
        self.txt_acq_prov = QLineEdit(); self.txt_acq_prov.setMaximumWidth(60)
        self.txt_acq_cap = QLineEdit(); self.txt_acq_cap.setMaximumWidth(80)
        # alias: più sotto nello stesso metodo c'è una funzione locale QLabel
        from qgis.PyQt.QtWidgets import QLabel as _Etich
        r1 = QHBoxLayout()
        r1.addWidget(self.txt_acq_comune)
        r1.addWidget(_Etich("Prov."))
        r1.addWidget(self.txt_acq_prov)
        r1.addWidget(_Etich("CAP"))
        r1.addWidget(self.txt_acq_cap)
        f1.addRow("Comune:", r1)
        # indirizzo e PEC del Comune in e.p.c.: al passo 4, come in tutte le schede
        self.txt_acq_indirizzo = QLineEdit()
        self.txt_acq_pec = QLineEdit()
        v.addWidget(gb1)

        # 2) corsi d'acqua: UN solo percorso che porta al layer «Corsi d'acqua e
        # costa» (prima c'erano «Screening» e «Carica corsi d'acqua», che
        # facevano la stessa cosa in due modi e si sovrascrivevano)
        gbs = self._gruppo(_P.titolo(2, "acque"), compresso=False)
        vs = QVBoxLayout(gbs)
        rs = QHBoxLayout()
        self.btn_acq_scr = _P.primario(_P.TROVA["acque"])
        self.btn_acq_scr.setToolTip(
            "Da OpenStreetMap: fiumi, torrenti, canali, fossi e costa del territorio comunale "
            "più i fossi senza "
            "nome nell'area del progetto. Sotto compaiono anche i siti per trovare l'ente.")
        self.btn_acq_scr.clicked.connect(self._acq_screening)
        rs.addWidget(self.btn_acq_scr)
        # stessa barra delle altre schede istanze
        from .ftth_barra import BarraAvanzamento
        self.bar_acq_scr = BarraAvanzamento()
        self.bar_acq_scr.setFormat("")
        self.bar_acq_scr.setValue(0)
        self.bar_acq_scr.setVisible(False)
        rs.addWidget(self.bar_acq_scr, 1)
        self.btn_acq_stop = QPushButton("Interrompi")
        self.btn_acq_stop.setToolTip("Ferma la ricerca se è bloccata o ci mette troppo "
                                     "(es. server OSM che non rispondono).")
        self.btn_acq_stop.clicked.connect(self._acq_interrompi)
        self.btn_acq_stop.setVisible(False)
        rs.addWidget(self.btn_acq_stop)
        rs.addStretch()
        vs.addLayout(rs)
        self.tab_acq_scr = QTableWidget(0, 10)
        self.tab_acq_scr.setHorizontalHeaderLabels(
            ["Incl.", "Corso d'acqua", "Categoria", "Ente proposto", "Km nel comune",
             "Tratti OSM", "Tombini", "Dist. dal progetto (m)", "Rete in fascia", "Valida"])
        intest = self.tab_acq_scr.horizontalHeaderItem(8)
        if intest is not None:
            intest.setToolTip(
                "«sì» = la rete del progetto entra nella fascia di rispetto di questo corso "
                "d'acqua (distanza minore della fascia impostata sotto: 10 m demanio idrico e "
                "bonifica, 30 m demanio marittimo). Sono quelli con interferenze sicure.")
        self.tab_acq_scr.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tab_acq_scr.setMinimumHeight(170)
        self.tab_acq_scr.horizontalHeader().setStretchLastSection(True)
        self.tab_acq_scr.cellDoubleClicked.connect(self._acq_zoom_corso)
        _P.attiva_valida(self.tab_acq_scr, 0, ACQ_COL_VALIDA, self._acq_proposto)
        vs.addWidget(self.tab_acq_scr)
        from . import ftth_trovati as _TR
        vs.addLayout(_TR.riga_pulsanti(self.tab_acq_scr, 0, "i corsi d'acqua",
                                       proposti=self._acq_proposto,
                                       mostra=self._acq_mostra_corsi))
        vs.addWidget(_P.proposte(self))
        # tracciato OSM sbagliato: stesso riquadro di Strade e Ferrovie
        from . import ftth_tracciati as _TRC
        vs.addWidget(_TRC.riquadro(self, "un corso d'acqua", self._acq_correggi_tracciato,
                                   self._acq_usa_tracciati))
        from qgis.PyQt.QtWidgets import QTextBrowser
        self.txt_acq_siti = QTextBrowser()
        self.txt_acq_siti.setOpenExternalLinks(True)
        self.txt_acq_siti.setMaximumHeight(150)
        self.txt_acq_siti.setPlaceholderText("Siti utili per l'ente competente: compaiono dopo "
                                             "la ricerca.")
        vs.addWidget(self.txt_acq_siti)
        from qgis.PyQt.QtWidgets import QLabel as _QLabelAvv
        lbl_avviso = _QLabelAvv("⚠ " + _acq_mod().AVVISO_VERIFICA)
        lbl_avviso.setWordWrap(True)
        lbl_avviso.setStyleSheet("color:#8a5a00; font-style:italic;")
        vs.addWidget(lbl_avviso)

        from qgis.core import QgsMapLayerProxyModel
        from qgis.gui import QgsFieldComboBox
        from qgis.PyQt.QtWidgets import QGroupBox, QLabel as _QL

        def QLabel(testo):  # noqa: N802 - etichetta a capo automatico
            lab = _QL(testo)
            lab.setWordWrap(True)
            return lab
        # B) due modi, ben distinti, per i corsi d'acqua che OSM non ha
        gb_av2 = self._gruppo("Avanzate: altre fonti, fasce di rispetto e salvataggio dei "
                              "layer")
        v_av2 = QVBoxLayout(gb_av2)
        gbb = QGroupBox("Corsi d'acqua che OSM non ha (layer ufficiale o disegno)")
        vb = QVBoxLayout(gbb)
        vb.addWidget(QLabel(
            "<b>B1 – Usa un layer scaricato dai siti ufficiali</b> (reticolo idrografico "
            "regionale, canali del Consorzio, reticolo minore del Comune, dividente demaniale…) "
            "o un tuo layer già fatto. Prima aggiungilo al progetto QGIS (trascina il file "
            "SHP/GPKG in mappa), poi sceglilo qui e indica i campi."))
        fb1 = QFormLayout()
        self.cb_acq_layer = self._lcombo(
            QgsMapLayerProxyModel.LineLayer | QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        self.cb_acq_layer.setLayer(None)
        self.cb_acq_layer.setToolTip(
            "Linee o poligoni (per i poligoni conta il bordo, es. l'alveo o il demanio). "
            "Si aggiunge alle righe spuntate in A.")
        fb1.addRow("Layer:", self.cb_acq_layer)
        self.cb_acq_campo_nome = QgsFieldComboBox()
        self.cb_acq_campo_nome.setAllowEmptyFieldName(True)
        self.cb_acq_layer.layerChanged.connect(self.cb_acq_campo_nome.setLayer)
        fb1.addRow("   campo con il nome:", self.cb_acq_campo_nome)
        self.cb_acq_campo_ente = QgsFieldComboBox()
        self.cb_acq_campo_ente.setAllowEmptyFieldName(True)
        self.cb_acq_campo_ente.setToolTip(
            "Campo con la competenza, se c'è: RIP / RIB / RIM (Lombardia), il nome del "
            "Consorzio, «Genio Civile»… Il plugin ne ricava l'ente.")
        self.cb_acq_layer.layerChanged.connect(self.cb_acq_campo_ente.setLayer)
        fb1.addRow("   campo con la competenza:", self.cb_acq_campo_ente)
        self.cb_acq_categoria = QComboBox()
        for k, d in acq.CATEGORIE.items():
            self.cb_acq_categoria.addItem(d, k)
        self.cb_acq_categoria.setToolTip("Categoria delle linee del layer quando la "
                                         "competenza non la dice.")
        fb1.addRow("   categoria (se il layer non la dice):", self.cb_acq_categoria)
        vb.addLayout(fb1)
        vb.addWidget(QLabel(
            "<b>B2 – Oppure disegnalo tu</b>: crea il layer «%s» con lo stile della scheda e "
            "ti mette subito a disegnare; per ogni linea scegli nome, categoria ed ente."
            % NOME_LAYER_DISEGNATI))
        b_dis = QPushButton("Disegna corso d'acqua…")
        b_dis.setToolTip(
            "Crea (se manca) il layer «%s» nel GeoPackage accanto al progetto, lo mette in "
            "modifica e attiva il disegno di linee. Finito, salva le modifiche del layer e "
            "premi «Trova le interferenze» al punto 3." % NOME_LAYER_DISEGNATI)
        b_dis.clicked.connect(self._acq_disegna)
        rdis = QHBoxLayout()
        rdis.addWidget(b_dis)
        rdis.addStretch()
        vb.addLayout(rdis)
        v_av2.addWidget(gbb)

        # impostazioni: fasce di rispetto e Consorzio competente
        gbf = QGroupBox("Fasce di rispetto, Consorzio competente e salvataggio dei layer")
        f2 = QFormLayout(gbf)
        self.spin_acq_fasce = {}
        for cat, etich, tip in (
                ("demanio", "Fascia demanio idrico:",
                 "R.D. 523/1904 art. 96 lett. f): scavi e fabbriche a meno di 10 m dal piede "
                 "dell'argine (o dal ciglio della sponda) sono vietati salvo diversa disciplina "
                 "locale; servono l'autorizzazione dell'ente (Regione/Genio Civile, o Comune "
                 "per il reticolo minore). Eccezioni: le norme regionali/comunali sul reticolo "
                 "minore possono fissare fasce diverse. Per i fiumi larghi la fascia parte "
                 "dall'alveo disegnato in OSM, non dall'asse."),
                ("bonifica", "Fascia canali consortili (da 4 m fino a):",
                 "Fascia di rispetto consortile 4-12 m: R.D. 368/1904 art. 133 dice da 4 a 10 m "
                 "secondo l'importanza del canale (scavi almeno a una distanza pari alla loro "
                 "profondità, mai sotto 2 m), salvo il regolamento del Consorzio. Il plugin usa "
                 "12 m per avere margine: le interferenze si cercano entro questa misura e in "
                 "tavola e in mappa c'è anche il limite dei 4 m. Se il regolamento del "
                 "Consorzio dice altro, correggi qui."),
                ("marittimo", "Fascia demanio marittimo:",
                 "Codice della Navigazione art. 55: nuove opere entro 30 m dal demanio "
                 "marittimo (o dal ciglio dei terreni elevati sul mare) richiedono "
                 "l'autorizzazione dell'Autorità marittima/Regione. I 30 m si misurano dalla "
                 "dividente demaniale: la costa OSM è solo un'approssimazione, meglio "
                 "caricare la dividente (es. SITR Sicilia) con B1.")):
            sp = self._dspin(1, 200, acq.FASCIA_PREDEFINITA[cat], 0, " m")
            sp.setToolTip(tip)
            self.spin_acq_fasce[cat] = sp
            f2.addRow(etich, sp)
        self.cb_acq_compr = self._lcombo(QgsMapLayerProxyModel.PolygonLayer, allow_empty=True)
        self.cb_acq_compr.setLayer(None)
        self.cb_acq_compr.setToolTip(
            "Poligoni dei comprensori di bonifica (dal geoportale regionale): danno il nome "
            "del Consorzio competente, che OSM non riporta.")
        f2.addRow("Comprensori di bonifica (facoltativo):", self.cb_acq_compr)
        self.cb_acq_compr_campo = QgsFieldComboBox()
        self.cb_acq_compr.layerChanged.connect(self.cb_acq_compr_campo.setLayer)
        f2.addRow("   campo con il nome del Consorzio:", self.cb_acq_compr_campo)
        # «Salva i layer della scheda…»: nelle avanzate, come in RFI
        r_salva = QHBoxLayout()
        b_salva = QPushButton("Salva i layer della scheda…")
        b_salva.setToolTip(TIP_SALVA % GRUPPO_ACQUE)
        b_salva.clicked.connect(self._acq_salva_layer)
        r_salva.addWidget(b_salva)
        r_salva.addStretch()
        f2.addRow(r_salva)
        v_av2.addWidget(gbf)
        vs.addWidget(gb_av2)
        v.addWidget(gbs)

        # 3) interferenze
        gb3 = self._gruppo(_P.titolo(3, "acque"), compresso=False)
        v3 = QVBoxLayout(gb3)
        riga3 = QHBoxLayout()
        self.btn_acq_trova = _P.primario("Trova le interferenze", self._acq_trova)
        riga3.addWidget(self.btn_acq_trova)
        # lo zoom è il doppio clic sulla riga, come in tutte le schede
        from .ftth_barra import crea_barra
        self.bar_acq_i = crea_barra(riga3)
        v3.addLayout(riga3)
        self.tab_acq = QTableWidget(0, len(INTESTAZIONI))
        self.tab_acq.setHorizontalHeaderLabels(INTESTAZIONI)
        self.tab_acq.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.tab_acq.setMinimumHeight(220)
        self.tab_acq.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        self.tab_acq.horizontalHeader().setStretchLastSection(True)
        self.tab_acq.cellDoubleClicked.connect(self._acq_doppio_clic)
        v3.addWidget(self.tab_acq)
        v3.addLayout(_TR.riga_pulsanti(self.tab_acq, C_INCL, "le interferenze",
                                       mostra=self._acq_mostra_interferenze))
        v3.addWidget(_P.nota3(
            self, "Indica come si passa il corso d'acqua; l'ente si assegna al punto 4 (qui "
            "solo per un'eccezione su una riga). Doppio clic sulla colonna etichette: testi "
            "in tavola."))
        # conferma e vista per istanza: dentro il passo 3, come in tutte le schede
        try:
            from . import ftth_gruppi_istanze as _GR
            v3.addWidget(_GR.riquadro(self, "acque", self._acq_istanze_per_gruppi))
        except Exception:  # noqa: BLE001
            pass
        v.addWidget(gb3)

        # 4) enti: prima a quale ente va ogni corso d'acqua, poi i destinatari
        gb4 = self._gruppo(_P.titolo(4, "acque"), compresso=False)
        v4 = QVBoxLayout(gb4)
        v4.addWidget(_P.nota4(
            self, "Scegli l'ente di ogni corso d'acqua (vale per tutte le sue interferenze; "
            "aiutati con i «Siti utili» del punto 2), sotto i destinatari di ogni ente."))
        self.tab_acq_enti = QTableWidget(0, 6)
        self.tab_acq_enti.setHorizontalHeaderLabels(
            ["Corso d'acqua", "Categoria", "Interferenze", "Ente", "Nome ente",
             "Proposto in base a"])
        self.tab_acq_enti.horizontalHeader().setStretchLastSection(True)
        self.tab_acq_enti.setMinimumHeight(110)
        self.tab_acq_enti.itemChanged.connect(self._acq_ente_nome_cambiato)
        v4.addWidget(self.tab_acq_enti)
        self.tab_acq_dest = QTableWidget(0, 4)
        self.tab_acq_dest.setHorizontalHeaderLabels(["Ente", "Destinatario (Spett.le)",
                                                     "Indirizzo", "PEC"])
        self.tab_acq_dest.horizontalHeader().setStretchLastSection(True)
        self.tab_acq_dest.setMinimumHeight(90)
        self.tab_acq_dest.itemChanged.connect(self._acq_ricorda_destinatari)
        v4.addWidget(self.tab_acq_dest)
        b_dest = QPushButton("Aggiorna dagli enti in tabella")
        b_dest.setToolTip("Rifà gli elenchi dopo aver cambiato ente o nome ente nelle righe "
                          "del punto 3. Indirizzi e PEC scritti qui si ricordano per le "
                          "prossime pratiche.")
        b_dest.clicked.connect(lambda *_: (self._acq_riempi_enti(),
                                           self._acq_aggiorna_destinatari()))
        rd = QHBoxLayout()
        rd.addWidget(b_dest)
        rd.addStretch()
        v4.addLayout(rd)
        f_epc = QFormLayout()
        _P.comune_epc(f_epc, self.txt_acq_indirizzo, self.txt_acq_pec)
        v4.addLayout(f_epc)
        v.addWidget(gb4)

        # 5) foto, sezioni ed etichette (quello che si disegna in mappa)
        gb_f = self._gruppo(_P.titolo(5, "acque"), compresso=False)
        v_f = QVBoxLayout(gb_f)
        v_f.addWidget(_P.nota5(self, "acque"))
        v_f.addLayout(_P.riga_fotosez(self, lambda *_a: self._rfi_prepara_foto_sezioni("acque"),
                                      ente="acque"))
        v.addWidget(gb_f)
        # 6) stampa: opzioni dei documenti, Genera, registro
        gb5 = self._gruppo(_P.titolo(6, "acque"), compresso=False)
        v5 = QVBoxLayout(gb5)
        gb5_av = self._gruppo("Avanzate: PDF, cartelle e loghi")
        v5_av = QVBoxLayout(gb5_av)
        self.chk_acq_pdf_tutti = QCheckBox("Converti in PDF anche art. 49 e Bollo "
                                           "(la relazione RT+CR è sempre in PDF)")
        v5_av.addWidget(self.chk_acq_pdf_tutti)
        try:    # logo FiberCop «Milano Cortina 2026» (stessa casella in tutte le schede)
            from . import ftth_logo as _LOGO
            v5_av.addWidget(_LOGO.crea_checkbox(self))
            from . import ftth_arlo as _ARLO
            v5_av.addWidget(_ARLO.crea_checkbox(self))
        except Exception:  # noqa: BLE001
            pass
        self.chk_acq_pl = QCheckBox("Genera la planimetria 1.1 PL (layout QGIS + PDF)")
        self.chk_acq_pl.setChecked(True)
        f5 = QFormLayout()
        self.cb_acq_raggruppa = QComboBox()
        self.cb_acq_raggruppa.addItem("Una istanza per ogni corso d'acqua (PL del singolo canale)",
                                      True)
        self.cb_acq_raggruppa.addItem("Una istanza per ente, con tutti i suoi corsi d'acqua",
                                      False)
        self.cb_acq_raggruppa.setToolTip(
            "Dipende dall'ente: c'è chi vuole una pratica per canale e chi una sola con tutti "
            "i canali di sua competenza. In entrambi i casi le tavole inquadrano per zona "
            "tutto ciò che cade vicino ai corsi d'acqua.")
        try:
            from qgis.core import QgsSettings
            if QgsSettings().value("ftth_permessi/acque_per_corso", "1") == "0":
                self.cb_acq_raggruppa.setCurrentIndex(1)
        except Exception:  # noqa: BLE001
            pass
        self.cb_acq_raggruppa.currentIndexChanged.connect(self._acq_ricorda_raggruppa)
        f5.addRow("Istanze:", self.cb_acq_raggruppa)
        self.cb_acq_righe = QComboBox()
        for k, d in acq.RIGHE_TABELLE.items():
            self.cb_acq_righe.addItem(d, k)
        self.cb_acq_righe.setToolTip(
            "Come si indica ogni tratto nelle tabelle della relazione (scavi, pozzetti, "
            "cronoprogramma), una riga per tavola della PL. Esempi:\n"
            "• Indirizzo: «Via Marco Polo (Tavola 1)»; se la via non è nota, le coordinate\n"
            "• Coordinate: «da 40.612345, 14.912345 a 40.612901, 14.913010 (Tavola 1)»\n"
            "• Indirizzo e coordinate: le due cose insieme.\n"
            "La via si corregge nella colonna Via del punto 3.")
        try:
            from qgis.core import QgsSettings
            i_r = self.cb_acq_righe.findData(
                QgsSettings().value("ftth_permessi/acque_righe_tabelle", "via"))
            self.cb_acq_righe.setCurrentIndex(max(0, i_r))
        except Exception:  # noqa: BLE001
            pass
        self.cb_acq_righe.currentIndexChanged.connect(
            lambda *_: self._acq_ricorda("acque_righe_tabelle", self.cb_acq_righe.currentData()))
        f5.addRow("Tratti nelle tabelle RT:", self.cb_acq_righe)
        self.cb_acq_orto = QComboBox()
        self.cb_acq_orto.setToolTip("Layer raster per il riquadro ORTOFOTO delle tavole.")
        f5.addRow("Ortofoto per le tavole:", self.cb_acq_orto)
        self.cb_acq_scala = _P.combo_scala("acque_scala_tavole",
                                           "la stessa per tutte, almeno 1:1000")
        f5.addRow("Scala delle tavole PL:", self.cb_acq_scala)
        def _riga_cartella(chiave, segnaposto, tip):
            riga = QHBoxLayout()
            txt = QLineEdit()
            txt.setPlaceholderText(segnaposto)
            txt.setToolTip(tip)
            self.__dict__.setdefault("_cartelle_acq", []).append((txt, chiave))
            riga.addWidget(txt)
            b = QPushButton("Sfoglia…")
            b.clicked.connect(lambda _=False, t=txt, k=chiave: self._rfi_scegli_cartella(t, k))
            riga.addWidget(b)
            return riga, txt
        r_sez, self.txt_acq_cart_sez = _riga_cartella(
            "acque_cartella_sezioni", "vuota = 05_Sezioni del progetto",
            "Disegni delle sezioni tracciate in QGIS nel layer Sezioni: per la sezione A "
            "il file SEZIONE A-A'.svg (anche PNG/JPG). Come per RFI, in tavola va solo la "
            "sezione disegnata.")
        r_foto, self.txt_acq_cart_foto = _riga_cartella(
            "acque_cartella_foto", "vuota = 04_Foto del progetto",
            "Foto: FOTO-n.jpg (n = NumeroFoto del punto di ripresa) oppure foto_<numero "
            "interferenza>.")
        r_part, self.txt_acq_cart_part = _riga_cartella(
            "acque_cartella_particolari", "vuota = particolari del plugin",
            "Particolari costruttivi che sostituiscono quelli del plugin.")
        _P.collega_cartelle(self, self.__dict__.get("_cartelle_acq", []))
        f5_av = QFormLayout()
        f5_av.addRow("Cartella sezioni:", r_sez)
        f5_av.addRow("Cartella foto:", r_foto)
        f5_av.addRow("Cartella particolari:", r_part)
        v5_av.addLayout(f5_av)
        v5_av.addWidget(self._desc(
            "Cronoprogramma: si usano le rese della scheda Istanze RFI (stessa squadra)."))
        v5.addLayout(f5)
        v5.addWidget(self.chk_acq_pl)
        v5.addWidget(gb5_av)
        riga5, self.btn_acq_genera = _P.riga_genera(self._acq_genera, self._acq_apri_cartella,
                                                    self, "_log_a", etichette_in=v_f)
        v5.addLayout(riga5)
        self.log_acq = QPlainTextEdit(); self.log_acq.setReadOnly(True)
        self.log_acq.setMinimumHeight(110)
        v5.addWidget(self.log_acq)
        v.addWidget(gb5)
        v.addStretch()
        self._acq_aggiorna_orto()
        return w

    def _acq_ricorda(self, chiave, valore):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/%s" % chiave, valore)
        except Exception:  # noqa: BLE001
            pass

    def _acq_ricorda_raggruppa(self, *_):
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/acque_per_corso",
                                   "1" if self.cb_acq_raggruppa.currentData() else "0")
        except Exception:  # noqa: BLE001
            pass

    def _acq_al_cambio_progetto(self):
        """Il dialogo resta vivo fra un progetto e l'altro: con un progetto
        diverso si buttano interferenze e testi del precedente e si riprende
        il lavoro salvato nel nuovo."""
        prj = getattr(self, "project", None)
        if prj is None or getattr(self, "_acq_progetto_letto", None) == prj.fileName():
            return
        if hasattr(self, "_acq_dati"):
            del self._acq_dati
        self.tab_acq.setRowCount(0)
        self.tab_acq_enti.setRowCount(0)
        self.tab_acq_dest.setRowCount(0)
        self.log_acq.clear()
        self._acq_ripristina_progetto()
        if prj.readEntry(PRJ_SCOPE, "gpkg", "")[0]:
            self._log_a("Progetto con lavoro Istanze Acque salvato: premi «Trova le interferenze» "
                        "per riprendere tabella, etichette corrette ed enti.")

    def _acq_ripristina_progetto(self):
        """Riapertura di un progetto salvato con «Salva nel progetto»: comune e
        scelta delle istanze tornano come erano (il resto lo riprende «Trova»)."""
        prj = getattr(self, "project", None)
        if prj is None:
            return
        self._acq_progetto_letto = prj.fileName()
        comune, ok = prj.readEntry(PRJ_SCOPE, "comune", "")
        if ok and comune:
            # vale il comune del lavoro salvato, non quello precompilato
            self.txt_acq_comune.setText(comune)
        per, ok = prj.readEntry(PRJ_SCOPE, "per_corso", "")
        if ok and per in ("0", "1"):
            self.cb_acq_raggruppa.blockSignals(True)
            self.cb_acq_raggruppa.setCurrentIndex(0 if per == "1" else 1)
            self.cb_acq_raggruppa.blockSignals(False)
        fasce, ok = prj.readEntry(PRJ_SCOPE, "fasce", "")
        if ok and fasce:
            try:
                for k, m in json.loads(fasce).items():
                    if k == "bonifica" and float(m) == 10.0:
                        # 10 m era la vecchia misura predefinita: ora 4-12 m
                        m = 12.0
                    if k in self.spin_acq_fasce:
                        self.spin_acq_fasce[k].setValue(m)
            except (ValueError, AttributeError):
                pass

    def _acq_aggiorna_orto(self):
        self.cb_acq_orto.clear()
        self.cb_acq_orto.addItem("automatico (ortofoto del progetto o Esri World Imagery)", None)
        try:
            from qgis.core import QgsRasterLayer
            for l in self.project.mapLayers().values():
                if isinstance(l, QgsRasterLayer):
                    self.cb_acq_orto.addItem(l.name(), l.id())
        except Exception:  # noqa: BLE001
            pass

    # ------------------------------------------------------------ genera
    def _acq_genera(self):
        try:
            self._acq_genera_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_a("ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore generazione", str(e))

    def _acq_destinatari(self):
        """{'tipo|nome': {nome, indirizzo, pec}} dalla tabella destinatari."""
        out = {}
        t = self.tab_acq_dest
        for r in range(t.rowCount()):
            k = t.item(r, 0).data(Qt.UserRole) if t.item(r, 0) else None
            if not k:
                continue
            txt = lambda c: (t.item(r, c).text().strip() if t.item(r, c) else "")  # noqa: E731
            out[k] = {"nome": txt(1), "indirizzo": txt(2), "pec": txt(3)}
        return out

    def _acq_istanze_per_gruppi(self):
        """Istanze dalle righe confermate, per i gruppi di layer nel progetto."""
        acq = _acq_mod()
        comune = self.txt_acq_comune.text().strip()
        if not comune or not self._acq_state().get("interferenze"):
            QMessageBox.warning(self, "Dati mancanti",
                                "Prima scrivi il comune e trova le interferenze.")
            return None
        istanze = acq.raggruppa_istanze_acque(
            self._acq_leggi_tabella(), comune,
            per_corso=bool(self.cb_acq_raggruppa.currentData()))
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza", "Nessuna riga spuntata in tabella.")
        return istanze

    def _acq_genera_impl(self, cartella_out=None):
        acq = _acq_mod()
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        try:
            import docx  # noqa: F401
        except ImportError:
            QMessageBox.critical(self, "Manca python-docx",
                                 "Serve il modulo 'python-docx'. Dalla console Python di QGIS:\n"
                                 "  import pip; pip.main(['install','python-docx'])")
            return
        comune = self.txt_acq_comune.text().strip()
        if not comune:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune al punto 1.")
            return
        if not self._acq_state().get("interferenze"):
            QMessageBox.warning(self, "Nessuna interferenza",
                                "Prima premi «Trova le interferenze».")
            return
        interf = self._acq_leggi_tabella()
        n = self._acq_sincronizza_da_layer()
        if n:
            self._log_a("Testi presi dalla tabella attributi di «%s»: %d." % (NOME_ETICHETTE, n))
        self._acq_aggiorna_destinatari()
        dest = self._acq_destinatari()
        per_corso = bool(self.cb_acq_raggruppa.currentData())
        istanze = acq.raggruppa_istanze_acque(interf, comune, per_corso=per_corso)
        if not istanze:
            QMessageBox.warning(self, "Nessuna istanza", "Nessuna riga spuntata in tabella.")
            return
        try:    # elementi aggiunti a mano al gruppo dell'istanza
            from . import ftth_gruppi_istanze as _GR
            _GR.aggiungi_da_ricerca(
                self.project, istanze, interf,
                lambda i, ist: i.ente_tipo == ist.ente_tipo and
                (i.ente_nome or "").strip() == (ist.ente_nome or "").strip() and
                (not per_corso or acq.nome_corso_istanza(i.corso, i.categoria)
                 in (ist.corsi_chiavi or [])),
                self._log_a)
        except Exception as e:  # noqa: BLE001
            self._log_a("Elementi aggiunti a mano non considerati: %s" % e)
        if cartella_out is None:
            # come la scheda RFI: accanto al progetto, Istanze Acque\<COMUNE>
            cartella_out = os.path.join(self.project.homePath() or os.path.expanduser("~"),
                                        "Istanze Acque", comune.upper())
        os.makedirs(cartella_out, exist_ok=True)
        self._acq_state()["cartella"] = cartella_out
        dati_c = rfi.DatiComune(comune, self.txt_acq_prov.text().strip(),
                                self.txt_acq_cap.text().strip(),
                                self.txt_acq_indirizzo.text().strip(),
                                self.txt_acq_pec.text().strip())
        qui = os.path.dirname(os.path.abspath(__file__))
        tpl = os.path.join(qui, "modelli_acque")
        rese = self._rfi_rese() if hasattr(self, "_rfi_rese") else None
        try:
            from . import ftth_acque_layout as AL
        except ImportError:
            import ftth_acque_layout as AL
        self._log_a("Istanze da generare: %d (%s)" % (
            len(istanze), "una per ente e corso d'acqua" if per_corso
            else "una per ente con tutti i corsi d'acqua"))
        da_pdf = []
        for ist in istanze:
            k = "%s|%s" % (ist.ente_tipo, ist.ente_nome)
            d = dest.get(k, {})
            out = os.path.join(cartella_out, ist.nome_base)
            lung = len(os.path.abspath(os.path.join(
                out, rfi.NOMI_FILE["rt"].format(base=ist.nome_base))))
            if lung > 250:
                self._log_a("  ATTENZIONE: percorso lungo %d caratteri (limite di Windows 260): "
                            "sposta il progetto in una cartella con un percorso più corto." % lung)
            prod = acq.genera_documenti_istanza(ist, dati_c, d, tpl, out, rese,
                                                righe=self.cb_acq_righe.currentData() or "via")
            mancanti = [c for c, p in prod.items() if p is None]
            if mancanti:
                self._log_a("  modelli mancanti: %s" % ", ".join(mancanti))
            da_pdf.append(prod.get("rt"))
            if self.chk_acq_pdf_tutti.isChecked():
                da_pdf += [prod.get("art49"), prod.get("bollo")]
            with open(os.path.join(out, "LEGGIMI.txt"), "w", encoding="utf-8") as fh:
                fh.write(acq.promemoria(ist, dati_c, d))
            self._log_a("- %s: %d interferenze -> %s" % (ist.nome_base, len(ist.interferenze), out))
            if self.chk_acq_pl.isChecked():
                t = acq.testi_istanza(ist, d.get("nome", ""))
                pdf = os.path.join(out, rfi.NOMI_FILE["pl"].format(base=ist.nome_base))
                st = self._acq_state()
                ok = AL.genera_pl_acque(
                    self.project, ist, dati_c, pdf, corsi=st.get("corsi"),
                    alvei=st.get("alvei"), costa=st.get("costa_osm"),
                    fasce={k: sp.value() for k, sp in self.spin_acq_fasce.items()},
                    ente=t["ente"], orto_id=self.cb_acq_orto.currentData(),
                    cartella_utente=self.txt_acq_cart_part.text().strip() or None,
                    cartella_sezioni=self.txt_acq_cart_sez.text().strip() or None,
                    cartella_foto=self.txt_acq_cart_foto.text().strip() or None,
                    log=lambda m: self._log_a("    " + m),
                    scala=self.cb_acq_scala.currentData() or None)
                self._log_a("    PL: %d tavole — %s" % (len(ist.tavole), "ok" if ok else
                                                         "NON riuscita"))
        try:    # logo FiberCop classico o «Milano Cortina 2026» (flag del progetto)
            from . import ftth_logo as _LOGO
            n_logo = _LOGO.applica_cartella(cartella_out, _LOGO.attivo(self.project))
            if n_logo:
                self._log_a("Logo FiberCop %s in %d documenti Word." % (
                    "Milano Cortina 2026" if _LOGO.attivo(self.project) else "classico", n_logo))
        except Exception as e_logo:  # noqa: BLE001
            self._log_a("Logo nei documenti non sostituito: %s" % e_logo)
        da_pdf = [p for p in da_pdf if p]
        if da_pdf:
            self._log_a("Conversione in PDF (Word)...")
            ris = rfi.converti_pdf(da_pdf)
            if rfi.avviso_pdf():
                self._log_a("  " + rfi.avviso_pdf())
            ko = [os.path.basename(p) for p, pdf in ris.items() if not pdf]
            if ko:
                self._log_a("  PDF non creati (manca Word/LibreOffice?): %s" % ", ".join(ko))
        self._log_a("Fatto. In ogni cartella il LEGGIMI dice cosa completare.")

    def _acq_apri_cartella(self):
        c = self._acq_state().get("cartella")
        if c and os.path.isdir(c):
            os.startfile(c)  # noqa: S606

    def _log_a(self, msg):
        self.log_acq.appendPlainText(str(msg))
        self.log_acq.repaint()

    def _acq_state(self):
        if not hasattr(self, "_acq_dati"):
            self._acq_dati = {"corsi": [], "alvei": [], "ponti": [], "strade": [],
                              "interferenze": [], "regione": None}
        return self._acq_dati

    # ------------------------------------------------------------ comune
    def _acq_auto_comune(self):
        nome = self.txt_acq_comune.text().strip()
        st = self._acq_state()
        if not nome or st.get("_ultimo_comune") == nome.lower():
            return
        precedente = st.get("_ultimo_comune")
        st["_ultimo_comune"] = nome.lower()
        if precedente:
            for wdg in (self.txt_acq_indirizzo, self.txt_acq_pec):
                wdg.clear()
        try:
            try:
                from . import ftth_screening as scr
            except ImportError:
                import ftth_screening as scr
            from qgis.PyQt.QtWidgets import QApplication
            QApplication.setOverrideCursor(Qt.BusyCursor)
            try:
                c = scr.risolvi_comune(nome, None)
            finally:
                QApplication.restoreOverrideCursor()
        except Exception as e:  # noqa: BLE001
            self._log_a("Comune non risolto automaticamente: %s" % e)
            return
        if not c.data:
            self.txt_acq_prov.clear()
            self.txt_acq_cap.clear()
            self._log_a("Comune «%s» non trovato: compila provincia e CAP a mano." % nome)
            return
        d = c.data
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        prov = d.get("provincia")
        self.txt_acq_prov.setText((rfi.sigla_provincia(prov) if prov else "") or prov or "")
        cap = d.get("cap")
        self.txt_acq_cap.setText(str(cap).split(";")[0].strip() if cap else "")
        st["regione"] = d.get("regione")
        self._log_a("Comune: %s (%s) — %s, CAP %s" % (
            d.get("nome"), self.txt_acq_prov.text(), d.get("regione") or "?",
            self.txt_acq_cap.text() or "da compilare"))

    # ---------------------------------------------------- corsi d'acqua
    def _acq_overpass_cache(self, query, avvisa=True):
        import hashlib
        import time as _time
        cache_dir = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache")
        chiave = hashlib.md5(query.encode("utf-8")).hexdigest()
        cache_p = os.path.join(cache_dir, "overpass_acque_%s.json" % chiave)
        if os.path.isfile(cache_p) and _time.time() - os.path.getmtime(cache_p) < 30 * 86400:
            try:
                with open(cache_p, encoding="utf-8") as fh:
                    res = json.load(fh)
                self._log_a("Dati OSM dalla cache (scaricati il %s)." % _time.strftime(
                    "%d/%m/%Y", _time.localtime(os.path.getmtime(cache_p))))
                return res
            except Exception:  # noqa: BLE001
                pass
        self._log_a("Scarico i dati da OSM (30-90 secondi, QGIS resta utilizzabile)...")
        try:
            # tutti i server insieme e finestra viva (la barra avanza): prima
            # la richiesta bloccava QGIS fino alla risposta
            els, err = self._acq_overpass_parallelo(query, 200)
            if err:
                raise RuntimeError(err)
            res = {"elements": els}
        except Exception as e:  # noqa: BLE001
            self._log_a("OSM: %s" % e)
            if avvisa:
                QMessageBox.critical(self, "OSM non raggiungibile",
                                     "Impossibile scaricare i dati OSM:\n%s" % e)
            return None
        try:
            os.makedirs(cache_dir, exist_ok=True)
            with open(cache_p, "w", encoding="utf-8") as fh:
                json.dump(res, fh)
        except Exception:  # noqa: BLE001
            pass
        return res

    # ------------------------------------------------ screening acque
    def _acq_screening(self, *_):
        ok = False
        self._acq_stop = False
        self.btn_acq_stop.setText("Interrompi")
        self.btn_acq_stop.setEnabled(True)
        self.btn_acq_stop.setVisible(True)
        try:
            self._acq_screening_impl()
            ok = self.bar_acq_scr.value() >= 100
        except _RicercaInterrotta:
            self._log_a("Ricerca interrotta dall'utente: l'elenco dei corsi d'acqua non è stato "
                        "cambiato. Puoi rilanciarla (i dati già scaricati restano in cache).")
            self.bar_acq_scr.setFormat("Ricerca interrotta dall'utente")
            ok = True
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_a("ERRORE screening:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Screening non riuscito", str(e))
        finally:
            self.btn_acq_scr.setEnabled(True)
            self.btn_acq_stop.setVisible(False)
            self._acq_stop = False
            if not ok:
                self.bar_acq_scr.setFormat("Ricerca interrotta — vedi il registro in fondo")
            self._acq_bar_fine = None

    def _acq_interrompi(self, *_):
        self._acq_stop = True
        self.btn_acq_stop.setEnabled(False)
        self.btn_acq_stop.setText("Interrompo…")

    def _acq_controlla_stop(self):
        if getattr(self, "_acq_stop", False):
            raise _RicercaInterrotta()

    # ------------------------------------- comune scritto = comune del progetto
    def _acq_controlla_comune(self, nome, d):
        """None = va bene (o non verificabile); False = fermati; una stringa =
        rifai la ricerca con quel comune (quello dove sta il progetto)."""
        geom = d.get("geometry")
        # le TRATTE vere, non il rettangolo dei layer: un elemento isolato
        # allungava il rettangolo e il suo centro cadeva in un altro comune
        punti = self._acq_punti_progetto()
        if not punti or geom is None:
            return None
        from shapely.geometry import MultiPoint, Point
        from shapely.prepared import prep
        dentro = prep(geom.buffer(0.005))              # ~500 m di tolleranza
        if any(dentro.contains(Point(p)) for p in punti):
            return None
        import math
        mp = MultiPoint(punti)
        dist_km = geom.distance(mp) * 111.0 * math.cos(math.radians(mp.centroid.y))
        self._acq_fase(5, 10, "verifico il comune del progetto")
        vero, fonte = self._acq_comune_del_progetto(punti)
        testo = ("Il progetto aperto non è nel comune di %s: le infrastrutture distano circa "
                 "%d km dal suo confine." % (d.get("nome") or nome, max(1, int(dist_km))))
        self._log_a(testo)
        if vero and _norm_comune(vero) != _norm_comune(d.get("nome") or nome):
            self._log_a("Comune del progetto secondo %s: %s." % (fonte, vero))
            r = QMessageBox.question(
                self, "Comune diverso dal progetto",
                testo + "\n\nLe infrastrutture del progetto sono nel comune di %s (secondo "
                "%s).\n\nCerco i corsi d'acqua di %s?" % (vero, fonte, vero),
                QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
            if r == QMessageBox.Yes:
                self._log_a("Ricerca spostata sul comune del progetto: %s." % vero)
                return vero
        else:
            QMessageBox.warning(self, "Comune diverso dal progetto",
                                testo + "\n\nControlla il comune al punto 1 o apri il progetto "
                                "giusto.")
        self._log_a("Ricerca annullata: scrivi al punto 1 il comune del progetto aperto.")
        return False

    def _acq_punti_progetto(self, massimo=300):
        """Punti (lon, lat) WGS84 a meta' delle tratte del progetto (al massimo
        `massimo`, presi a intervalli regolari); senza tratte, pozzetti e armadi."""
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        for nome in ("03 INFRASTRUTTURE", "02_POZZETTO", "01_ARMADIO OTTICO"):
            lyr = self._find_layer(nome)
            if lyr is None or not lyr.isValid():
                continue
            tr = QgsCoordinateTransform(lyr.crs(), wgs, self.project)
            feats = [f for f in lyr.getFeatures() if f.hasGeometry()]
            if not feats:
                continue
            passo = max(1, len(feats) // massimo)
            out = []
            for f in feats[::passo]:
                g = QgsGeometry(f.geometry())
                if g.type() == 1:      # linea: il punto a meta'
                    p = g.interpolate(g.length() / 2.0)
                    g = p if p is not None and not p.isEmpty() else g.pointOnSurface()
                else:
                    g = g.pointOnSurface()
                g.transform(tr)
                pt = g.asPoint()
                out.append((pt.x(), pt.y()))
            if out:
                return out
        return []

    def _acq_comune_del_progetto(self, punti):
        """(comune, fonte) in cui cade la maggior parte del progetto. Prima un
        layer dei confini comunali del progetto (es. ISTAT, campo COMUNE), poi
        OSM interrogato su alcuni punti delle tratte (a maggioranza)."""
        from collections import Counter
        from qgis.core import QgsFeatureRequest, QgsWkbTypes
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        campi_ok = ("comune", "nome_comune", "comune_nome", "den_comune", "denominazione_comune",
                    "nome_com", "comune_den")
        for lyr in self.project.mapLayers().values():
            if not isinstance(lyr, QgsVectorLayer) or not lyr.isValid() or \
                    lyr.geometryType() != QgsWkbTypes.PolygonGeometry:
                continue
            nomi = {f.name().lower(): f.name() for f in lyr.fields()}
            campo = next((nomi[c] for c in campi_ok if c in nomi), None)
            if campo is None and "comun" in lyr.name().lower() and "nome" in nomi:
                campo = nomi["nome"]
            if campo is None:
                continue
            tr = QgsCoordinateTransform(wgs, lyr.crs(), self.project)
            pts = [QgsGeometry.fromPointXY(tr.transform(QgsPointXY(x, y))) for x, y in punti]
            area = QgsRectangle()
            area.setMinimal()
            for g in pts:
                area.combineExtentWith(g.boundingBox())
            area.grow(1.0)
            conta = Counter()
            for f in lyr.getFeatures(QgsFeatureRequest().setFilterRect(area)):
                fg = f.geometry()
                n = sum(1 for g in pts if fg.contains(g))
                if n:
                    conta[str(f[campo]).strip()] += n
            if conta:
                return conta.most_common(1)[0][0], "il layer «%s»" % lyr.name()
        # OSM: al massimo 5 punti distribuiti sulle tratte (1 richiesta al secondo)
        scelti = punti[::max(1, len(punti) // 5)][:5]

        def _osm():
            import time as _t
            conta = Counter()
            for k, (x, y) in enumerate(scelti):
                if k:
                    _t.sleep(1.1)
                c = _comune_del_punto(y, x)
                if c:
                    conta[c] += 1
            return conta.most_common(1)[0][0] if conta else None
        return self._acq_in_sottofondo(_osm), "OpenStreetMap"

    # ------------------------------------------- barra di avanzamento
    def _acq_fase(self, da, a, testo):
        """Nuova fase della ricerca: la barra parte da `da` e, mentre si aspetta
        OSM (tempo non prevedibile), avanza piano verso `a` senza raggiungerlo."""
        self._acq_controlla_stop()
        b = self.bar_acq_scr
        b.setVisible(True)
        b.setValue(int(da))
        b.setFormat("%p%  —  " + testo)
        self._acq_bar_pos = float(da)
        self._acq_bar_fine = float(a)
        from qgis.PyQt.QtWidgets import QApplication
        QApplication.processEvents()

    def _acq_avanza(self):
        """Chiamata nei cicli di attesa: un passo verso la fine della fase (e
        controllo del pulsante «Interrompi»)."""
        self._acq_controlla_stop()
        fine = getattr(self, "_acq_bar_fine", None)
        if fine is None or not hasattr(self, "bar_acq_scr"):
            return
        self._acq_bar_pos += (fine - 1 - self._acq_bar_pos) * 0.02
        self.bar_acq_scr.setValue(int(self._acq_bar_pos))

    def _acq_in_sottofondo(self, funzione, *args):
        """Esegue `funzione` in un thread tenendo viva la finestra di QGIS."""
        import concurrent.futures as cf
        import time as _t
        from qgis.PyQt.QtWidgets import QApplication
        ex = cf.ThreadPoolExecutor(max_workers=1)
        fut = ex.submit(funzione, *args)
        try:
            while not fut.done():
                QApplication.processEvents()
                self._acq_avanza()
                _t.sleep(0.1)
            return fut.result()
        finally:
            ex.shutdown(wait=False)

    def _acq_screening_impl(self):
        acq = _acq_mod()
        nome = self.txt_acq_comune.text().strip()
        if not nome:
            QMessageBox.warning(self, "Comune mancante", "Scrivi il comune al punto 1.")
            return
        try:
            from . import ftth_screening as scr
        except ImportError:
            import ftth_screening as scr
        self.btn_acq_scr.setEnabled(False)
        self.log_acq.clear()
        self._log_a("Screening acque di %s: confine comunale e corsi d'acqua da OSM "
                    "(30-120 secondi, QGIS resta utilizzabile)..." % nome)
        self._acq_fase(0, 10, "1/5 confine e dati del comune")
        c = self._acq_in_sottofondo(scr.risolvi_comune, nome, None)
        if not c.data:
            QMessageBox.warning(self, "Comune non trovato", c.errore or "Comune non risolto.")
            return
        d = c.data
        # il comune scritto deve essere quello del progetto: altrimenti si
        # mescolano i corsi d'acqua di un comune con i fossi dell'area del
        # progetto e i siti consigliati sono di un'altra regione
        altro = self._acq_controlla_comune(nome, d)
        if altro is False:
            return
        if altro:
            self.txt_acq_comune.setText(altro)
            self._acq_auto_comune()
            self.bar_acq_scr.setVisible(False)
            self.btn_acq_scr.setEnabled(True)
            return self._acq_screening_impl()
        st = self._acq_state()
        st["regione"] = d.get("regione") or st.get("regione")
        self._acq_fase(10, 45, "2/5 corsi d'acqua del comune (OSM)")
        q = acq.query_overpass_comune(d["osm_relation_id"])
        els = self._acq_cache_leggi(q)
        if els is None:
            els, err = self._acq_overpass_parallelo(q)
            if err:
                QMessageBox.warning(self, "OSM non raggiungibile",
                                    "Corsi d'acqua del comune non scaricati:\n%s" % err)
                return
            self._acq_cache_scrivi(q, els)
        self._acq_fase(45, 60, "3/5 linea di costa")
        q2 = acq.query_costa_bbox(d["bbox"])
        costa = self._acq_cache_leggi(q2)
        if costa is None:
            costa, err2 = self._acq_overpass_parallelo(q2, 90)
            if not err2:
                self._acq_cache_scrivi(q2, costa)
            costa = costa or []
        corsi = acq.da_osm(list(els) + list(costa))["corsi"]
        # area del progetto: anche i fossi senza nome (quelli che contano per
        # le interferenze), con ponti, strade e alvei per dopo
        self._acq_fase(60, 88, "4/5 fossi, ponti e strade nell'area del progetto")
        bbox = self._rfi_bbox_progetto()
        if bbox is not None:
            res = self._acq_overpass_cache(acq.query_overpass(bbox), avvisa=False)
            if res is None:
                res = self._acq_overpass_cache(acq.query_overpass(bbox, solo_acque=True),
                                               avvisa=False)
            if res:
                vicino = acq.da_osm(res.get("elements", []))
                corsi = acq.unisci_corsi(corsi, vicino["corsi"])
                st["screening_area"] = vicino
        self._acq_fase(88, 100, "5/5 distanze dal progetto e siti utili")
        rete = self._acq_rete()
        geoms = [t["geom"] for t in (rete[0] if rete else [])
                 if (t.get("stato") or "").strip().lower() != "esistente"]
        fasce = {k: sp.value() for k, sp in self.spin_acq_fasce.items()}
        righe = acq.riepilogo_screening(corsi, geoms, fasce)
        st["screening"] = {"corsi": corsi, "righe": righe}
        self._acq_riempi_screening(righe)
        portale, _wfs = scr.geoportale_regionale(st.get("regione"))
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        prov = self.txt_acq_prov.text().strip() or (rfi.sigla_provincia(d.get("provincia"))
                                                    if d.get("provincia") else "")
        siti = acq.siti_utili(d.get("nome") or nome, prov, st.get("regione") or "", portale or "")
        self.txt_acq_siti.setHtml(
            "<b>Siti utili per l'ente competente</b><br>" + "<br>".join(
                "• <a href=\"%s\">%s</a> — %s" % (u, t, s) for t, u, s in siti))
        self._log_a(acq.AVVISO_VERIFICA)
        prop = [r for r in righe if r["proposto"]]
        self._acq_bar_fine = None
        self.bar_acq_scr.setValue(100)
        self.bar_acq_scr.setFormat("Ricerca completata: %d corsi d'acqua, %d proposti"
                                   % (len(righe), len(prop)))
        self._log_a("Corsi d'acqua nel comune: %d (%s). Proposti per l'istanza (entro 200 m "
                    "dal progetto): %d%s" % (
                        len(righe), ", ".join("%s: %d" % (acq.CATEGORIE[k], sum(
                            1 for r in righe if r["categoria"] == k)) for k in acq.CATEGORIE
                            if any(r["categoria"] == k for r in righe)),
                        len(prop), (" — " + ", ".join(r["nome"] for r in prop)) if prop else ""))
        if not rete:
            self._log_a("Nessun layer di progetto (03 INFRASTRUTTURE): distanze non calcolate, "
                        "spunta a mano i corsi d'acqua da tenere.")
        if not righe:
            self._log_a("OSM non riporta corsi d'acqua nel comune: se ce ne sono, usa "
                        "«Disegna corso d'acqua…».")

    MIRROR_OVERPASS = [
        "https://overpass-api.de/api/interpreter",
        "https://overpass.kumi.systems/api/interpreter",
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
    ]

    def _acq_overpass_parallelo(self, query, timeout=150, gui=True):
        """Stessa richiesta a tutti i server insieme, vale la prima risposta
        VALIDA: con map_to_area deve esserci l'area (sentinella), altrimenti
        il server non ha risolto il confine e '0 risultati' non vuol dire
        niente. Provandoli uno alla volta, un server lento faceva scadere
        tutto (misurato su Eboli: overpass-api.de risponde in 32 s, gli altri
        504 o 2 minuti). Ritorna (elementi, errore)."""
        import concurrent.futures as cf
        import time as _t
        import urllib.parse
        import urllib.request
        from qgis.PyQt.QtWidgets import QApplication
        data = urllib.parse.urlencode({"data": query}).encode()
        area = "map_to_area" in query

        def _una(url):
            req = urllib.request.Request(url, data=data, headers={"User-Agent": "ftth-permessi/1.0"})
            with urllib.request.urlopen(req, timeout=timeout) as r:
                j = json.load(r)
            els = j.get("elements")
            if els is None:
                raise ValueError("risposta senza dati")
            rem = (j.get("remark") or "").lower()
            if "timed out" in rem or "runtime error" in rem:
                raise ValueError("server sovraccarico: %s" % rem[:80])
            if area:
                if not any(e.get("type") == "area" for e in els):
                    raise ValueError("confine comunale non risolto dal server")
                els = [e for e in els if e.get("type") != "area"]
            return els
        ex = cf.ThreadPoolExecutor(max_workers=len(self.MIRROR_OVERPASS))
        futuri = {ex.submit(_una, m): m for m in self.MIRROR_OVERPASS}
        errori = []
        try:
            in_corso = set(futuri)
            while in_corso:
                fatti, in_corso = cf.wait(in_corso, timeout=0.2, return_when=cf.FIRST_COMPLETED)
                # gui=False quando gira già in un thread a parte (es. le
                # schede Soprintendenza e Parchi): toccare l'interfaccia da
                # lì blocca QGIS
                if gui:
                    QApplication.processEvents()
                    self._acq_avanza()
                for f in fatti:
                    try:
                        return f.result(), None
                    except Exception as e:  # noqa: BLE001
                        errori.append("%s: %s" % (futuri[f].split("/")[2], e))
                _t.sleep(0.05)
            return None, "; ".join(errori) or "nessun server ha risposto"
        finally:
            ex.shutdown(wait=False, cancel_futures=True)

    def _acq_cache_leggi(self, query):
        import hashlib
        import time as _t
        p = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache",
                         "overpass_acque_%s.json" % hashlib.md5(query.encode()).hexdigest())
        if os.path.isfile(p) and _t.time() - os.path.getmtime(p) < 30 * 86400:
            try:
                with open(p, encoding="utf-8") as fh:
                    self._log_a("  (dati OSM dalla cache del %s)" % _t.strftime(
                        "%d/%m/%Y", _t.localtime(os.path.getmtime(p))))
                    return json.load(fh)
            except Exception:  # noqa: BLE001
                return None
        return None

    def _acq_cache_scrivi(self, query, els):
        import hashlib
        try:
            cart = os.path.join(os.path.expanduser("~"), ".ftth_permessi_cache")
            os.makedirs(cart, exist_ok=True)
            p = os.path.join(cart, "overpass_acque_%s.json" % hashlib.md5(query.encode()).hexdigest())
            with open(p, "w", encoding="utf-8") as fh:
                json.dump(els, fh)
        except Exception:  # noqa: BLE001
            pass

    def _acq_riempi_screening(self, righe):
        acq = _acq_mod()
        t = self.tab_acq_scr
        prima = {tuple(t.item(r, 0).data(Qt.UserRole) or ()) for r in range(t.rowCount())
                 if t.item(r, 0) is not None and t.item(r, 0).checkState() == Qt.Checked}
        t.blockSignals(True)
        t.setRowCount(0)
        for g in righe:
            r = t.rowCount()
            t.insertRow(r)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            # proposto = solo evidenziato (giallo): si conferma con «Conferma»,
            # come in tutte le schede istanze; resta la spunta già data
            chk.setCheckState(Qt.Checked if tuple(g["chiave"]) in prima else Qt.Unchecked)
            chk.setData(Qt.UserRole, list(g["chiave"]))
            t.setItem(r, 0, chk)
            valori = [g["nome"], acq.CATEGORIE.get(g["categoria"], g["categoria"]),
                      acq.ENTI_TIPO.get(g["ente_tipo"], g["ente_tipo"]),
                      ("%.2f" % g["km"]).replace(".", ","), str(g["tratti"]),
                      str(g["tombini"]) if g["tombini"] else "",
                      "" if g["dist_m"] is None else "%d" % g["dist_m"],
                      "sì" if g["in_fascia"] else ""]
            fascia_m = self.spin_acq_fasce[g["categoria"]].value() \
                if g["categoria"] in self.spin_acq_fasce else 10
            for col, v in enumerate(valori, 1):
                it = QTableWidgetItem(v)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if g["in_fascia"]:
                    it.setForeground(QColor(0, 90, 190))
                    it.setToolTip("La rete del progetto passa a %s m da questo corso d'acqua, "
                                  "dentro la sua fascia di rispetto di %g m: ci sono "
                                  "interferenze." % (valori[6], fascia_m))
                t.setItem(r, col, it)
        t.blockSignals(False)
        from . import ftth_passi as _P
        _P.valida_tutte(t, 0, ACQ_COL_VALIDA, self._acq_proposto)
        t.resizeColumnsToContents()

    def _acq_spunta_screening(self, modo):
        """Spunte dell'elenco in un colpo: 'tutti', 'nessuno' o 'proposti'."""
        acq = _acq_mod()
        righe = (self._acq_state().get("screening") or {}).get("righe") or []
        prop = {tuple(g["chiave"]) for g in righe if g["proposto"]}
        t = self.tab_acq_scr
        for r in range(t.rowCount()):
            it = t.item(r, 0)
            if it is None:
                continue
            si = modo == "tutti" or (modo == "proposti" and
                                    tuple(it.data(Qt.UserRole) or ()) in prop)
            it.setCheckState(Qt.Checked if si else Qt.Unchecked)

    def _acq_da_screening(self, rep):
        """Punto 2 dai corsi d'acqua scaricati dallo screening (niente nuova
        richiesta a OSM)."""
        acq = _acq_mod()
        d = rep.get("comune") or {}
        if d.get("nome") and not self.txt_acq_comune.text().strip():
            self.txt_acq_comune.setText(d["nome"].upper())
        els = rep.get("_elementi_lineari") or []
        if not els:
            return ""
        st = self._acq_state()
        st["regione"] = d.get("regione") or st.get("regione")
        corsi = acq.da_osm(list(els))["corsi"]
        if not corsi:
            return "nessun corso d'acqua"
        rete = self._acq_rete()
        geoms = [t["geom"] for t in (rete[0] if rete else [])
                 if (t.get("stato") or "").strip().lower() != "esistente"]
        fasce = {k: sp.value() for k, sp in self.spin_acq_fasce.items()}
        righe = acq.riepilogo_screening(corsi, geoms, fasce)
        st["screening"] = {"corsi": corsi, "righe": righe}
        self._acq_riempi_screening(righe)
        prop = [r for r in righe if r["proposto"]]
        self._log_a("Corsi d'acqua dallo screening: %d, proposti %d%s." % (
            len(righe), len(prop), (" — " + ", ".join(r["nome"] for r in prop)) if prop else ""))
        return "%d corsi d'acqua, %d proposti" % (len(righe), len(prop))

    # ------------------------------ punto 2: proposti, zoom, mostra in mappa
    def _acq_proposto(self, r):
        righe = (self._acq_state().get("screening") or {}).get("righe") or []
        prop = {tuple(g["chiave"]) for g in righe if g["proposto"]}
        it = self.tab_acq_scr.item(r, 0)
        return it is not None and tuple(it.data(Qt.UserRole) or ()) in prop

    # ------------------------------------- tracciati corretti a mano
    NOME_TRACCIATI_ACQ = "Tracciati corsi d'acqua (correzione)"

    @staticmethod
    def _acq_chiave_tracciato(k):
        return "|".join(str(x) for x in k)

    def _acq_correggi_tracciato(self, *_a):
        from . import ftth_tracciati as _TRC
        t = self.tab_acq_scr
        righe = sorted({i.row() for i in t.selectedIndexes()})
        r = righe[0] if righe else t.currentRow()
        it = t.item(r, 0) if r >= 0 else None
        k = tuple(it.data(Qt.UserRole) or ()) if it is not None else ()
        g = self._acq_corsi_riga(r) if k else None
        if _TRC.inizia(self, self.NOME_TRACCIATI_ACQ, "tracciati_acque", "acque",
                       self._acq_chiave_tracciato(k), g):
            self._log_a("Correggi il tracciato di %s nel layer «%s» (strumento vertici), poi "
                        "premi «Usa i tracciati corretti»." % (k[0], self.NOME_TRACCIATI_ACQ))

    def _acq_usa_tracciati(self, *_a):
        from . import ftth_tracciati as _TRC
        corr = _TRC.leggi(self, self.NOME_TRACCIATI_ACQ)
        if corr is None:
            return
        st = self._acq_state()
        st["tracciati"] = corr
        n = self._acq_applica_tracciati(st, ridisegna=True)
        self._log_a("Tracciati dei corsi d'acqua corretti a mano: %d (%d nella ricerca). Rifai "
                    "«Trova le interferenze»." % (len(corr), n))
        QMessageBox.information(self, "Tracciati corretti",
                                "%d corsi d'acqua con il tracciato corretto. Ora rifai «Trova "
                                "le interferenze» al passo 3." % len(corr))

    def _acq_applica_tracciati(self, st, ridisegna=False):
        """I corsi d'acqua corretti a mano (stato 'tracciati' = {chiave: WKT})
        prendono il tracciato corretto, nella ricerca e nel layer dei corsi.
        Ritorna quanti corsi ha cambiato."""
        import copy
        from . import ftth_tracciati as _TRC
        acq = _acq_mod()
        corr = st.get("tracciati") or {}
        if not corr or not st.get("corsi"):
            return 0
        tenuti, modello = [], {}
        for c in st["corsi"]:
            k = self._acq_chiave_tracciato(acq.chiave_screening(c))
            if k in corr:
                modello.setdefault(k, c)
                continue
            tenuti.append(c)
        for k, c0 in modello.items():
            for parte in _TRC.parti(corr[k]):
                c = copy.copy(c0)
                c.geom = parte
                c.fonte = "corretto a mano"
                tenuti.append(c)
        st["corsi"] = tenuti
        if modello and ridisegna:
            try:
                self._acq_layer_corsi(tenuti)
                self._acq_layer_fascia(tenuti, st.get("alvei") or [])
            except Exception:  # noqa: BLE001
                pass
        return len(modello)

    def _acq_corsi_riga(self, r):
        """Geometria (unione dei tratti) del corso d'acqua della riga r."""
        from shapely.ops import unary_union
        acq = _acq_mod()
        it = self.tab_acq_scr.item(r, 0)
        if it is None:
            return None
        k = tuple(it.data(Qt.UserRole) or ())
        gg = [c.geom for c in (self._acq_state().get("screening") or {}).get("corsi", [])
              if acq.chiave_screening(c) == k and c.geom is not None]
        return unary_union(gg) if gg else None

    def _acq_zoom_corso(self, r, _c=None):
        from . import ftth_trovati as _TR
        _TR.zoom(getattr(self, "iface", None), self.project, self._acq_corsi_riga(r))

    def _acq_mostra_corsi(self):
        from . import ftth_trovati as _TR
        t = self.tab_acq_scr
        if not t.rowCount():
            QMessageBox.information(self, "Nessun corso d'acqua",
                                    "Prima premi «Trova i corsi d'acqua e gli enti».")
            return
        voci = []
        for r in range(t.rowCount()):
            if t.item(r, 0).checkState() != Qt.Checked:
                continue
            g = self._acq_corsi_riga(r)
            nome, ente = t.item(r, 1).text(), t.item(r, 3).text()
            voci.append((g, {"corso": nome, "categoria": t.item(r, 2).text(), "ente": ente,
                             "etichetta": "%s — %s" % (nome, ente) if ente else nome}))
        if not voci:
            QMessageBox.information(self, "Nessun corso d'acqua", "Nessuna riga spuntata.")
            return
        try:
            _TR.mostra_in_mappa(self.project, "acque", "Corsi d'acqua trovati", voci,
                                "etichetta", "acque")
            self._log_a("In mappa: %d corsi d'acqua nel gruppo «Istanze > Acque > Trovati»."
                        % len(voci))
            self.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Mostra in mappa", "Non riuscito: %s" % e)

    def _acq_mostra_interferenze(self):
        if not self._acq_state().get("interferenze"):
            QMessageBox.information(self, "Nessuna interferenza",
                                    "Prima premi «Trova le interferenze».")
            return
        incl = [i for i in self._acq_leggi_tabella() if i.includi]
        if not incl:
            QMessageBox.information(self, "Nessuna interferenza", "Nessuna interferenza spuntata.")
            return
        self._interf_in_mappa(incl, "acque", "Interferenze acque", self._log_a)

    def _zoom_interf(self, i):
        """Zoom sull'ingombro dell'interferenza (Acque, Soprintendenza, Parchi)."""
        from . import ftth_trovati as _TR
        from shapely.geometry import Point, box
        g = box(*i.bbox) if getattr(i, "bbox", None) and len(i.bbox) == 4 \
            else Point(i.lon, i.lat)
        _TR.zoom(getattr(self, "iface", None), self.project, g)

    def _interf_in_mappa(self, incl, sezione, prefisso, log):
        """Scavi (tratte intere) e pozzetti/armadi delle interferenze `incl` nel
        gruppo «Istanze > sezione > Trovati». Comune ad Acque, Soprintendenza e
        Parchi (le interferenze hanno la stessa forma)."""
        from . import ftth_trovati as _TR
        from shapely.geometry import Point
        lyr = self._find_layer("03 INFRASTRUTTURE")
        geom_fid = {}
        if lyr is not None:
            from qgis.core import QgsFeatureRequest
            fids = [f for i in incl for f in i.tratte_fid if isinstance(f, int)]
            for f in lyr.getFeatures(QgsFeatureRequest().setFilterFids(fids)):
                if f.hasGeometry():
                    geom_fid[f.id()] = self._rfi_wkt(f.geometry(), lyr)
        scavi, punti = [], []
        for i in incl:
            base = {"id": i.id, "corso": i.corso, "tipo": i.tipo, "etichetta": "n. %d" % i.id}
            for fid in i.tratte_fid:
                if fid in geom_fid:
                    scavi.append((geom_fid[fid], base))
            for e in i.elementi:
                if e.get("tipo") in ("pozzetto", "armadio", "colonnina") and "lon" in e:
                    punti.append((Point(e["lon"], e["lat"]), dict(base, elemento=e["tipo"])))
            if not i.tratte_fid and not i.elementi:
                punti.append((Point(i.lon, i.lat), base))
        try:
            if scavi:
                _TR.mostra_in_mappa(self.project, sezione, prefisso + " - scavi", scavi,
                                    "etichetta", "interferenze")
            if punti:
                _TR.mostra_in_mappa(self.project, sezione, prefisso + " - pozzetti e armadi",
                                    punti, "etichetta", "interferenze")
            log("In mappa: %d interferenze (%d scavi, %d pozzetti/armadi)."
                % (len(incl), len(scavi), len(punti)))
            self.iface.mapCanvas().refresh()
        except Exception as e:  # noqa: BLE001
            QMessageBox.warning(self, "Mostra in mappa", "Non riuscito: %s" % e)

    def _acq_trasferisci(self, *_):
        try:
            self._acq_trasferisci_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_a("ERRORE:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Errore", str(e))

    def _acq_trasferisci_impl(self):
        """I corsi d'acqua spuntati nello screening diventano il layer acque
        (con disegnati a mano e layer di progetto); ponti, nomi delle strade e
        alvei si prendono dall'area del progetto."""
        acq = _acq_mod()
        st = self._acq_state()
        scr_d = st.get("screening") or {}
        scelte = set()
        for r in range(self.tab_acq_scr.rowCount()):
            it = self.tab_acq_scr.item(r, 0)
            if it.checkState() == Qt.Checked:
                scelte.add(tuple(it.data(Qt.UserRole)))
        corsi = [c for c in scr_d.get("corsi", []) if acq.chiave_screening(c) in scelte]
        n_osm = len(corsi)
        dal_layer = self._acq_corsi_da_layer()
        alvei = list((dal_layer or {}).get("alvei") or [])
        n_layer = len(dal_layer["corsi"]) if dal_layer else 0
        if dal_layer:
            corsi += dal_layer["corsi"]
        disegnati = self._acq_corsi_disegnati()
        corsi += disegnati
        # con la dividente (layer ufficiale o tracciata) la costa OSM non serve:
        # la fascia dei 30 m deve partire solo dalla dividente
        # la costa OSM del comune serve comunque a capire da che parte e' il mare
        st["costa_osm"] = [c for c in scr_d.get("corsi", [])
                           if c.categoria == "marittimo" and c.fonte == acq.FONTE_OSM]
        if any(c.categoria == "marittimo" and c.fonte != acq.FONTE_OSM for c in corsi):
            prima = len(corsi)
            corsi = [c for c in corsi
                     if not (c.categoria == "marittimo" and c.fonte == acq.FONTE_OSM)]
            if len(corsi) < prima:
                self._log_a("Dividente demaniale presente: la linea di costa OSM non è usata "
                            "(%d tratti tolti), la fascia parte dalla dividente."
                            % (prima - len(corsi)))
        ponti, strade = [], []
        dd = st.get("screening_area")
        if dd:
            ponti, strade = dd["ponti"], dd["strade"]
            alvei += dd["alvei"]
        if not corsi:
            QMessageBox.warning(
                self, "Nessun corso d'acqua",
                "Non hai spuntato nessuna riga e non c'è un layer o un corso disegnato."
                if scr_d else "Non c'è ancora nessun corso d'acqua: cerca su OSM (A) e spunta "
                "le righe, oppure scegli un layer del progetto o disegna il canale (B).")
            return
        st.update(corsi=corsi, alvei=alvei, ponti=ponti, strade=strade)
        self._acq_layer_corsi(corsi)
        self._acq_layer_fascia(corsi, alvei)
        self._acq_ordina_layer()
        parti = []
        if n_osm:
            parti.append("%d corsi spuntati da OSM (%d tratti)" % (len(scelte), n_osm))
        if n_layer:
            parti.append("%d linee dal layer «%s»" % (n_layer,
                                                      self.cb_acq_layer.currentLayer().name()))
        if disegnati:
            parti.append("%d disegnati a mano" % len(disegnati))
        self._log_a("Layer corsi d'acqua creato: %s. Ora «Trova le interferenze»."
                    % ", ".join(parti))
        if not dd:
            self._log_a("Senza la ricerca su OSM non ci sono ponti e nomi delle vie: la via va "
                        "scritta a mano in tabella.")

    # ------------------------------------------- corsi d'acqua disegnati
    def _acq_stile_corsi(self, vl, campo_categoria="categoria"):
        """Stile dei corsi d'acqua della scheda (per categoria, con il nome)."""
        acq = _acq_mod()
        cats = []
        for k, col in COLORI.items():
            sym = QgsLineSymbol.createSimple({"line_color": "%d,%d,%d,255" % col.getRgb()[:3],
                                              "line_width": {"demanio": "1.0", "bonifica": "0.7",
                                                             "marittimo": "1.2"}[k]})
            cats.append(QgsRendererCategory(k, sym, acq.CATEGORIE[k]))
        vl.setRenderer(QgsCategorizedSymbolRenderer(campo_categoria, cats))
        self._rfi_etichetta(vl, "if(\"nome\" LIKE '%senza nome%', '', \"nome\")", 8,
                            espressione=True, colore=QColor(0, 60, 150))

    def _acq_disegna(self):
        """Layer GeoPackage accanto al progetto per tracciare a mano i corsi
        d'acqua che OSM non ha: stile della scheda, categoria a tendina,
        subito in modifica con lo strumento linea attivo."""
        from qgis.core import (QgsEditorWidgetSetup, QgsFields, QgsVectorFileWriter, QgsWkbTypes,
                               QgsDefaultValue)
        acq = _acq_mod()
        prj = self.project
        esistenti = prj.mapLayersByName(NOME_LAYER_DISEGNATI)
        if esistenti:
            vl = esistenti[0]
        else:
            home = prj.homePath()
            if not home:
                QMessageBox.warning(self, "Progetto non salvato",
                                    "Salva prima il progetto: il layer va nella sua cartella.")
                return
            cart = os.path.join(home, "01_File shp", "Corsi d'acqua")
            os.makedirs(cart, exist_ok=True)
            gpkg = os.path.join(cart, NOME_LAYER_DISEGNATI + ".gpkg")
            if not os.path.isfile(gpkg):
                fields = QgsFields()
                for c in ("nome", "categoria", "competenza"):
                    fields.append(QgsField(c, QVariant.String))
                opz = QgsVectorFileWriter.SaveVectorOptions()
                opz.driverName = "GPKG"
                opz.layerName = NOME_LAYER_DISEGNATI
                crs = prj.crs() if prj.crs().isValid() else QgsCoordinateReferenceSystem("EPSG:4326")
                w = QgsVectorFileWriter.create(gpkg, fields, QgsWkbTypes.LineString, crs,
                                               prj.transformContext(), opz)
                del w
            vl = QgsVectorLayer("%s|layername=%s" % (gpkg, NOME_LAYER_DISEGNATI),
                                NOME_LAYER_DISEGNATI, "ogr")
            if not vl.isValid():
                QMessageBox.critical(self, "Layer non creato", "Impossibile creare %s" % gpkg)
                return
            # categoria a tendina, bonifica come valore proposto
            idx = vl.fields().indexOf("categoria")
            vl.setEditorWidgetSetup(idx, QgsEditorWidgetSetup(
                "ValueMap", {"map": [{d: k} for k, d in acq.CATEGORIE.items()]}))
            vl.setDefaultValueDefinition(idx, QgsDefaultValue("'bonifica'"))
            vl.setFieldAlias(vl.fields().indexOf("competenza"),
                             "Ente competente (facoltativo)")
            self._acq_stile_corsi(vl)
            try:
                vl.saveStyleToDatabase(NOME_LAYER_DISEGNATI, "Stile FTTH Permessi Manager",
                                       True, "")
            except Exception:  # noqa: BLE001
                pass
            prj.addMapLayer(vl, False)
            self._acq_gruppo().insertLayer(0, vl)
        try:
            self.iface.setActiveLayer(vl)
            if not vl.isEditable():
                vl.startEditing()
            self.iface.actionAddFeature().trigger()
        except Exception:  # noqa: BLE001
            pass
        testo = ("Layer «%s» pronto e in modifica.\n\n"
                 "Traccia il canale o il fiume sulla mappa (clic per i vertici, tasto destro "
                 "per finire). Nella scheda che si apre scrivi:\n"
                 "• nome (es. Fontanile Vecchio)\n"
                 "• categoria: demanio idrico, canale di bonifica o demanio marittimo\n"
                 "• ente competente se lo sai (es. Consorzio Est Ticino Villoresi)\n\n"
                 "Poi salva le modifiche e premi «Trova le interferenze» al punto 3."
                 % NOME_LAYER_DISEGNATI)
        self._log_a(testo)
        QMessageBox.information(self, "Disegna corso d'acqua", testo)

    def _acq_corsi_disegnati(self):
        """Linee del layer «Corsi d'acqua disegnati», come CorsoAcqua."""
        acq = _acq_mod()
        lyr = next(iter(self.project.mapLayersByName(NOME_LAYER_DISEGNATI)), None)
        if lyr is None or not lyr.isValid():
            return []
        out = []
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            nome = self._rfi_val(f, "nome")
            cat = self._rfi_val(f, "categoria") or "bonifica"
            if cat not in acq.CATEGORIE:
                cat = "bonifica"
            comp = self._rfi_val(f, "competenza")
            ente_tipo = acq.ente_da_testo(comp) or ""
            for parte in getattr(g, "geoms", [g]):
                if parte.geom_type == "LineString":
                    out.append(acq.CorsoAcqua(
                        geom=parte, categoria=cat, waterway="disegnato",
                        nome=nome or ("Demanio marittimo" if cat == "marittimo"
                                      else "Corso d'acqua senza nome"),
                        ente_tipo=ente_tipo,
                        ente_nome=comp if (comp and len(comp) > 4 and comp.upper()
                                           not in ("RIP", "RIB", "RIM")) else "",
                        con_nome=bool(nome), fonte=acq.FONTE_DISEGNO))
        return out

    def _acq_aggiorna_disegnati(self, st):
        """Sostituisce in st['corsi'] le linee disegnate a mano con quelle
        attuali del layer «Corsi d'acqua disegnati» (anche non ancora salvate):
        aggiunte, modifiche e cancellazioni contano subito. Se cambiano, si
        rifanno i layer corsi e fascia."""
        acq = _acq_mod()
        lyr = next(iter(self.project.mapLayersByName(NOME_LAYER_DISEGNATI)), None)
        vecchi = [c for c in (st.get("corsi") or []) if c.fonte == acq.FONTE_DISEGNO]
        if lyr is None and not vecchi:
            return
        nuovi = self._acq_corsi_disegnati()

        def firma(cc):
            return sorted((c.geom.wkb_hex, c.nome, c.categoria, c.ente_nome) for c in cc)
        if firma(nuovi) == firma(vecchi):
            return
        altri = [c for c in (st.get("corsi") or []) if c.fonte != acq.FONTE_DISEGNO]
        corsi = altri + nuovi
        # una dividente disegnata sostituisce la costa OSM (come in «Crea il layer»)
        if any(c.categoria == "marittimo" for c in nuovi):
            corsi = [c for c in corsi
                     if not (c.categoria == "marittimo" and c.fonte == acq.FONTE_OSM)]
        st["corsi"] = corsi
        if corsi:
            self._acq_layer_corsi(corsi)
            self._acq_layer_fascia(corsi, st.get("alvei") or [])
            self._acq_ordina_layer()
        self._log_a("Corsi d'acqua disegnati a mano aggiornati dal layer «%s»: %d linee "
                    "(prima %d). Layer corsi e fascia rifatti." % (
                        NOME_LAYER_DISEGNATI, len(nuovi), len(vecchi)))
        if lyr is not None and lyr.isEditable() and lyr.isModified():
            self._log_a("Attenzione: il layer «%s» ha modifiche non salvate (sono già usate "
                        "nella ricerca, ma ricordati di salvarle)." % NOME_LAYER_DISEGNATI)

    def _acq_corsi_da_layer(self):
        """Linee (o bordi dei poligoni) del layer scelto, come CorsoAcqua."""
        acq = _acq_mod()
        lyr = self.cb_acq_layer.currentLayer()
        if lyr is None or not lyr.isValid():
            return None
        from shapely.geometry import LineString
        c_nome = self.cb_acq_campo_nome.currentField()
        c_ente = self.cb_acq_campo_ente.currentField()
        cat_pred = self.cb_acq_categoria.currentData()
        cat_da_ente = {"consorzio": "bonifica", "demanio_marittimo": "marittimo",
                       "genio_civile": "demanio", "comune": "demanio"}
        corsi, alvei = [], []
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            comp = self._rfi_val(f, c_ente)
            ente_tipo = acq.ente_da_testo(comp) or ""
            categoria = cat_da_ente.get(ente_tipo) or cat_pred
            # un testo lungo nella competenza e' il nome dell'ente (es. "Consorzio ...")
            ente_nome = comp if (comp and len(comp) > 4 and comp.upper() not in
                                 ("RIP", "RIB", "RIM")) else ""
            nome = self._rfi_val(f, c_nome) or (
                "Demanio marittimo" if categoria == "marittimo" else "Corso d'acqua senza nome")
            if g.geom_type in ("Polygon", "MultiPolygon"):
                for pg in getattr(g, "geoms", [g]):
                    alvei.append(pg)
                    bordi = [pg.exterior] + list(pg.interiors)
                    for b in bordi:
                        corsi.append(acq.CorsoAcqua(geom=LineString(b.coords), nome=nome,
                                                    categoria=categoria, ente_tipo=ente_tipo,
                                                    ente_nome=ente_nome, con_nome=True,
                                                    fonte=lyr.name()))
            else:
                for parte in getattr(g, "geoms", [g]):
                    if parte.geom_type == "LineString":
                        corsi.append(acq.CorsoAcqua(
                            geom=parte, nome=nome, categoria=categoria, ente_tipo=ente_tipo,
                            ente_nome=ente_nome, con_nome=bool(self._rfi_val(f, c_nome)),
                            fonte=lyr.name()))
        return {"corsi": corsi, "alvei": alvei}

    def _acq_layer_corsi(self, corsi):
        acq = _acq_mod()
        vl = QgsVectorLayer("LineString?crs=EPSG:4326", "Corsi d'acqua e costa", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("nome", QVariant.String), QgsField("categoria", QVariant.String),
                          QgsField("tipo", QVariant.String), QgsField("tombino", QVariant.Int),
                          QgsField("ente", QVariant.String), QgsField("ente_nome", QVariant.String),
                          QgsField("fonte", QVariant.String)])
        vl.updateFields()
        feats = []
        for c in corsi:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromWkt(c.geom.wkt))
            f["nome"] = c.nome
            f["categoria"] = c.categoria
            f["tipo"] = c.waterway
            f["tombino"] = 1 if c.tombino else 0
            f["ente"] = c.ente_tipo
            f["ente_nome"] = c.ente_nome
            f["fonte"] = c.fonte or ""
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        cats = []
        for k, col in COLORI.items():
            sym = QgsLineSymbol.createSimple({"line_color": "%d,%d,%d,255" % col.getRgb()[:3],
                                              "line_width": {"demanio": "1.0", "bonifica": "0.7",
                                                             "marittimo": "1.2"}[k]})
            cats.append(QgsRendererCategory(k, sym, acq.CATEGORIE[k]))
        vl.setRenderer(QgsCategorizedSymbolRenderer("categoria", cats))
        self._rfi_etichetta(vl, "if(\"nome\" LIKE '%senza nome%', '', \"nome\")", 8,
                            espressione=True, colore=QColor(0, 60, 150))
        self._acq_sostituisci_layer("Corsi d'acqua e costa", vl)
        return vl

    def _acq_layer_fascia(self, corsi, alvei):
        """Una fascia per categoria (dissolta), calcolata in metri e riportata in WGS84."""
        from shapely.ops import unary_union
        acq = _acq_mod()
        vl = QgsVectorLayer("Polygon?crs=EPSG:4326", "Fascia di rispetto acque", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("categoria", QVariant.String), QgsField("fascia_m", QVariant.Double)])
        vl.updateFields()
        if corsi:
            try:
                from . import ftth_rfi as rfi
            except ImportError:
                import ftth_rfi as rfi
            c0 = unary_union([c.geom for c in corsi]).centroid
            p = rfi._Proiezione(c0.x, c0.y)
            alvei_m = [p.avanti(a) for a in alvei]
            feats = []
            for cat in acq.CATEGORIE:
                linee = [p.avanti(c.geom) for c in corsi if c.categoria == cat]
                if not linee:
                    continue
                u = unary_union(linee)
                miei = [a for a in alvei_m if a.intersects(u)]
                if miei:
                    u = unary_union([u] + miei)
                m = self.spin_acq_fasce[cat].value()
                if cat == "marittimo":
                    # solo verso terra: sul mare la fascia non ha senso
                    costa = [p.avanti(c.geom) for c in
                             list(corsi) + list(self._acq_state().get("costa_osm") or [])
                             if c.categoria == "marittimo" and c.fonte == acq.FONTE_OSM]
                    zona, orientata = acq.zona_marittima_m(
                        [(p.avanti(c.geom), c.fonte == acq.FONTE_OSM)
                         for c in corsi if c.categoria == cat], m, costa)
                    if not orientata:
                        self._log_a("Dividente senza linea di costa OSM vicina: non so da che "
                                    "parte è il mare, la fascia marittima è disegnata sui due "
                                    "lati. Fai la ricerca A (anche senza spuntare la costa) "
                                    "per orientarla.")
                    g = p.indietro(zona)
                else:
                    g = p.indietro(u.buffer(m))
                f = QgsFeature(vl.fields())
                f.setGeometry(QgsGeometry.fromWkt(g.wkt))
                f["categoria"] = cat
                f["fascia_m"] = m
                feats.append(f)
            pr.addFeatures(feats)
            vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
            "color": "60,150,230,35", "outline_color": "0,90,200,255",
            "outline_width": "0.4", "outline_style": "dash"})))
        self._acq_sostituisci_layer("Fascia di rispetto acque", vl)
        # canali consortili: fascia 4-12 m, in mappa anche il limite dei 4 m
        nome_int = "Fascia canali consortili - limite 4 m"
        interne = []
        if corsi:
            for cat, m_int in acq.FASCIA_INTERNA.items():
                linee = [p.avanti(c.geom) for c in corsi if c.categoria == cat]
                if linee and m_int < self.spin_acq_fasce[cat].value():
                    interne.append(p.indietro(unary_union(linee).buffer(m_int)))
        if interne:
            vi = QgsVectorLayer("Polygon?crs=EPSG:4326", nome_int, "memory")
            fi = QgsFeature(vi.fields())
            fi.setGeometry(QgsGeometry.fromWkt(unary_union(interne).wkt))
            vi.dataProvider().addFeatures([fi])
            vi.updateExtents()
            vi.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple({
                "color": "0,0,0,0", "outline_color": "0,90,200,220",
                "outline_width": "0.3", "outline_style": "dot"})))
            self._acq_sostituisci_layer(nome_int, vi)
        else:
            for l in list(self.project.mapLayersByName(nome_int)):
                self.project.removeMapLayer(l.id())

    # ------------------------------------------------------------- layer
    def _acq_gruppo(self):
        root = self.project.layerTreeRoot()
        g = root.findGroup(GRUPPO_ACQUE)
        if g is None:
            from . import ftth_gruppi_istanze as _GRp
            g = _GRp.gruppo_sezione(root, "acque").insertGroup(0, GRUPPO_ACQUE)
        if g is None:
            g = root.insertGroup(0, GRUPPO_ACQUE)
        return g

    def _acq_sostituisci_layer(self, nome, nuovo):
        for l in list(self.project.mapLayers().values()):
            if l.name() == nome:
                self.project.removeMapLayer(l.id())
        from . import ftth_memoria as _MEM     # su file: resta nel progetto salvato
        nuovo = _MEM.permanente(self.project, nuovo)
        self.project.addMapLayer(nuovo, False)
        self._acq_gruppo().addLayer(nuovo)

    def _acq_ordina_layer(self):
        root = self.project.layerTreeRoot()
        gruppo = self._acq_gruppo()
        for nome in reversed(LAYER_ACQUE):
            lid = self._rfi_layer_id(nome)
            nodo = root.findLayer(lid) if lid else None
            if nodo is None:
                continue
            clone = nodo.clone()
            parent = nodo.parent()
            gruppo.insertChildNode(0, clone)
            parent.removeChildNode(nodo)

    def _acq_salva_layer(self, *_):
        """Errori sempre a video: prima un'eccezione finiva solo nella console
        Python di QGIS e il pulsante sembrava non fare nulla."""
        try:
            self._acq_salva_layer_impl()
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_a("ERRORE salvataggio layer:\n" + traceback.format_exc())
            QMessageBox.critical(self, "Salvataggio non riuscito", str(e))

    def _acq_salva_layer_impl(self, cartella=None, chiedi_progetto=True):
        """«Salva nel progetto»: i layer della scheda (con i testi corretti e le
        scelte fatte in tabella) in un GeoPackage, rimessi nel progetto al posto
        di quelli temporanei; poi, con conferma, il salvataggio del progetto."""
        from qgis.core import QgsSettings
        st = self._acq_state()
        if st.get("interferenze"):
            # tabella e tabella attributi delle etichette -> layer aggiornati
            if self.tab_acq.rowCount():
                self._acq_leggi_tabella()
            self._acq_sincronizza_da_layer()
            self._acq_layer_interferenze(st["interferenze"])
        if not any(self._rfi_layer_id(n) for n in LAYER_ACQUE):
            QMessageBox.information(self, "Layer acque", "Nessun layer da salvare: carica "
                                    "prima i corsi d'acqua.")
            return
        if cartella is None:
            gia, ok = self.project.readEntry(PRJ_SCOPE, "gpkg", "")
            partenza = (os.path.dirname(gia) if ok and gia else "") or \
                os.path.join(self.project.homePath() or os.path.expanduser("~"),
                             "01_File shp", "Acque")
            os.makedirs(partenza, exist_ok=True)
            cartella = QFileDialog.getExistingDirectory(
                self, "Cartella del GeoPackage con i layer acque", partenza)
            if not cartella:
                return
        QgsSettings().setValue("ftth_permessi/acque_cartella_layer", cartella)
        comune = (self.txt_acq_comune.text().strip() or "progetto").replace(" ", "_")
        gpkg = os.path.join(cartella, "Layer_Acque_%s.gpkg" % comune)
        esiti = self._acq_scrivi_gpkg(gpkg)
        self._acq_scrivi_voci_progetto(gpkg)
        testo = "GeoPackage: %s\n\n%s\n\nGli stili sono incorporati nel file." % (
            gpkg, "\n".join(esiti))
        self._log_a(testo)
        if not chiedi_progetto:
            return gpkg
        if not self.project.fileName():
            QMessageBox.information(self, "Layer acque salvati", testo + "\n\nIl progetto non ha "
                                    "ancora un nome: salvalo da QGIS (Progetto > Salva con nome).")
            return gpkg
        r = QMessageBox.question(
            self, "Layer acque salvati",
            testo + "\n\nSalvo adesso anche il progetto?\n%s" % self.project.fileName(),
            QMessageBox.Yes | QMessageBox.No, QMessageBox.Yes)
        if r == QMessageBox.Yes:
            if self.project.write():
                self._log_a("Progetto salvato: %s" % self.project.fileName())
            else:
                QMessageBox.warning(self, "Progetto non salvato",
                                    "Salvataggio del progetto non riuscito: %s"
                                    % self.project.error())
        else:
            self._log_a("Ricorda di salvare il progetto.")
        return gpkg

    def _acq_scrivi_voci_progetto(self, gpkg=None):
        prj = self.project
        if gpkg:
            prj.writeEntry(PRJ_SCOPE, "gpkg", gpkg)
        prj.writeEntry(PRJ_SCOPE, "comune", self.txt_acq_comune.text().strip())
        prj.writeEntry(PRJ_SCOPE, "per_corso",
                       "1" if self.cb_acq_raggruppa.currentData() else "0")
        prj.writeEntry(PRJ_SCOPE, "fasce", json.dumps(
            {k: sp.value() for k, sp in self.spin_acq_fasce.items()}))

    def _acq_gpkg_progetto(self):
        """GeoPackage gia' usato da questo progetto (salvataggi automatici)."""
        g, ok = self.project.readEntry(PRJ_SCOPE, "gpkg", "")
        return g if ok and g and os.path.isdir(os.path.dirname(g)) else None

    def _acq_scrivi_gpkg(self, gpkg):
        """Scrive nel GeoPackage i layer temporanei della scheda e li sostituisce
        nel progetto (stessa posizione, stesso stile). Ritorna gli esiti."""
        from qgis.core import QgsVectorFileWriter
        presenti = [(n, self.project.mapLayer(self._rfi_layer_id(n)))
                    for n in LAYER_ACQUE if self._rfi_layer_id(n)]
        esiti, primo = [], True
        root = self.project.layerTreeRoot()
        for nome, lyr in presenti:
            if lyr is None:
                continue
            if lyr.providerType() != "memory" and \
                    os.path.normcase(lyr.source().split("|")[0]) == os.path.normcase(gpkg):
                esiti.append("%s: già salvato" % nome)
                continue
            opz = QgsVectorFileWriter.SaveVectorOptions()
            opz.driverName = "GPKG"
            opz.layerName = nome
            opz.fileEncoding = "UTF-8"
            # mai riscrivere il file intero se esiste gia': i layer salvati prima
            # sono aperti in QGIS, Windows blocca il file e non si salvava nulla
            opz.actionOnExistingFile = (
                QgsVectorFileWriter.CreateOrOverwriteFile if (primo and not os.path.isfile(gpkg))
                else QgsVectorFileWriter.CreateOrOverwriteLayer)
            err = QgsVectorFileWriter.writeAsVectorFormatV3(
                lyr, gpkg, self.project.transformContext(), opz)
            if (err[0] if isinstance(err, tuple) else err) != QgsVectorFileWriter.NoError:
                esiti.append("%s: NON salvato (%s)" % (nome, err[1] if isinstance(err, tuple) else err))
                continue
            primo = False
            nuovo = QgsVectorLayer("%s|layername=%s" % (gpkg, nome), nome, "ogr")
            if not nuovo.isValid():
                esiti.append("%s: scritto ma non ricaricato" % nome)
                continue
            nuovo.setRenderer(lyr.renderer().clone())
            if lyr.labeling() is not None:
                nuovo.setLabeling(lyr.labeling().clone())
            nuovo.setLabelsEnabled(lyr.labelsEnabled())
            nuovo.setOpacity(lyr.opacity())
            nuovo.saveStyleToDatabase(nome, "Stile %s (FTTH Permessi Manager)" % nome, True, "")
            nodo = root.findLayer(lyr.id())
            parent = nodo.parent() if nodo is not None else self._acq_gruppo()
            pos = parent.children().index(nodo) if nodo is not None else 0
            self.project.addMapLayer(nuovo, False)
            parent.insertLayer(pos, nuovo)
            self.project.removeMapLayer(lyr.id())
            esiti.append("%s: salvato" % nome)
        return esiti

    # ------------------------------------------- lavoro salvato nel progetto
    def _acq_layer_nome(self, nome):
        lid = self._rfi_layer_id(nome)
        lyr = self.project.mapLayer(lid) if lid else None
        return lyr if lyr is not None and lyr.isValid() else None

    @staticmethod
    def _acq_val(f, campo):
        try:
            v = f[campo]
        except KeyError:
            return None
        if v is None or (hasattr(v, "isNull") and v.isNull()):
            return None
        return v

    def _acq_testi_da_layer(self):
        """Dai layer «Etichette acque» e «Interferenze acque» del progetto:
        ({chiave elemento: testo}, {chiave interferenza: testo unico},
        {chiave interferenza: scelte fatte in tabella}). Un testo vuoto o uguale
        al proposto non conta (= automatico)."""
        el, unici, scelte = {}, {}, {}
        lyr = self._acq_layer_nome(NOME_ETICHETTE)
        if lyr is not None:
            for f in lyr.getFeatures():
                k = self._acq_val(f, "chiave")
                if not k:
                    continue
                t = _righe_da_testo(self._acq_val(f, "testo"))
                el[k] = t if t and t != _righe_da_testo(self._acq_val(f, "proposto")) else ""
        lyr = self._acq_layer_nome("Interferenze acque")
        if lyr is not None and lyr.fields().indexOf("chiave") >= 0:
            for f in lyr.getFeatures():
                k = self._acq_val(f, "chiave")
                if not k:
                    continue
                unici[k] = _righe_da_testo(self._acq_val(f, "testo_unico"))
                scelte[k] = {c: self._acq_val(f, c) for c in
                             ("includi", "ente_tipo", "ente_nome", "tecnica_attr", "via")}
        return el, unici, scelte

    def _acq_sincronizza_da_layer(self):
        """Riporta nelle interferenze della scheda i testi scritti nella tabella
        attributi del layer «Etichette acque» (vale il layer)."""
        acq = _acq_mod()
        el, unici, _sc = self._acq_testi_da_layer()
        if not el and not unici:
            return 0
        n = 0
        for i in self._acq_state().get("interferenze") or []:
            for e in acq.elementi_etichettabili(i):
                k = e.get("chiave_el")
                if k in el and (e.get("testo") or "") != el[k]:
                    e["testo"] = el[k]
                    n += 1
            ki = acq.chiave_interferenza(i)
            if ki in unici and (i.etichetta or "") != unici[ki]:
                i.etichetta = unici[ki]
                n += 1
        if n:
            for r in range(self.tab_acq.rowCount()):
                i = self._acq_riga(r)
                it = self.tab_acq.item(r, C_ETICH)
                if i is not None and it is not None:
                    it.setText(self._acq_riassunto_etichette(i))
        return n

    def _acq_testi_su_layer(self, i):
        """Dopo la finestra delle etichette: i testi vanno subito nei layer
        (anche nel GeoPackage, se il lavoro e' gia' salvato)."""
        acq = _acq_mod()
        nuovi = {e["chiave_el"]: (e.get("testo") or "").replace("\n", SEP_RIGHE)
                 for e in acq.elementi_etichettabili(i)}
        for nome, campo, valori in (
                (NOME_ETICHETTE, "testo", nuovi),
                ("Interferenze acque", "testo_unico",
                 {acq.chiave_interferenza(i): (i.etichetta or "").replace("\n", SEP_RIGHE)})):
            lyr = self._acq_layer_nome(nome)
            if lyr is None or lyr.fields().indexOf(campo) < 0:
                continue
            idx = lyr.fields().indexOf(campo)
            modifiche = {f.id(): valori[f["chiave"]] for f in lyr.getFeatures()
                         if self._acq_val(f, "chiave") in valori and
                         (self._acq_val(f, campo) or "") != valori[f["chiave"]]}
            if not modifiche:
                continue
            if lyr.isEditable():
                for fid, v in modifiche.items():
                    lyr.changeAttributeValue(fid, idx, v)
            else:
                lyr.dataProvider().changeAttributeValues(
                    {fid: {idx: v} for fid, v in modifiche.items()})
            lyr.triggerRepaint()

    def _acq_corsi_da_progetto(self):
        """Corsi d'acqua dal layer salvato nel progetto (riapertura): evita di
        rifare ricerca e «Crea il layer corsi d'acqua»."""
        acq = _acq_mod()
        lyr = self._acq_layer_nome("Corsi d'acqua e costa")
        if lyr is None:
            return []
        corsi = []
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = self._rfi_wkt(f.geometry(), lyr)
            for parte in getattr(g, "geoms", [g]):
                if parte.geom_type != "LineString":
                    continue
                nome = self._acq_val(f, "nome") or "Corso d'acqua senza nome"
                corsi.append(acq.CorsoAcqua(
                    geom=parte, nome=nome, waterway=self._acq_val(f, "tipo") or "",
                    categoria=self._acq_val(f, "categoria") or "bonifica",
                    tombino=bool(self._acq_val(f, "tombino")),
                    ente_tipo=self._acq_val(f, "ente") or "",
                    ente_nome=self._acq_val(f, "ente_nome") or "",
                    con_nome="senza nome" not in nome,
                    fonte=self._acq_val(f, "fonte") or ""))
        return corsi

    # ------------------------------------------------------- interferenze
    def _acq_trova(self):
        bar = getattr(self, "bar_acq_i", None)
        self.btn_acq_trova.setEnabled(False)
        try:
            if bar is not None:
                bar.azzera()
                bar.fase(0, 10, "Lettura della rete")
            self._acq_trova_impl()
            if bar is not None:
                bar.fine("Interferenze trovate: %d" % len(
                    self._acq_state().get("interferenze") or []))
        except Exception as e:  # noqa: BLE001
            import traceback
            self._log_a("ERRORE:\n" + traceback.format_exc())
            if bar is not None:
                bar.interrotta("Errore: vedi il registro")
            QMessageBox.critical(self, "Errore", "Ricerca interferenze non riuscita:\n%s" % e)
        finally:
            self.btn_acq_trova.setEnabled(True)

    def _acq_rete(self):
        """Tratte, pozzetti e armadi del progetto in WGS84 (come la scheda RFI)."""
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        lyr_infra = self._find_layer("03 INFRASTRUTTURE")
        if lyr_infra is None:
            return None
        c_stato = self._rfi_campo(lyr_infra, "STATO")
        c_tipo = self._rfi_campo(lyr_infra, "TIPOLOGIA")
        c_lung = self._rfi_campo(lyr_infra, "LUNGHEZZA", "Lungh")
        tratte = []
        for f in lyr_infra.getFeatures():
            if not f.hasGeometry():
                continue
            try:
                lung = float(self._rfi_val(f, c_lung).replace(",", ".")) if c_lung else None
            except ValueError:
                lung = None
            tratte.append({"geom": self._rfi_wkt(f.geometry(), lyr_infra),
                           "stato": self._rfi_val(f, c_stato) or "Nuovo",
                           "tecnica": rfi.mappa_tecnica(self._rfi_val(f, c_tipo)),
                           "fid": f.id(), "lunghezza": lung if lung and lung > 0 else None})
        pozzetti, armadi = [], []
        lyr_poz = self._find_layer("02_POZZETTO")
        if lyr_poz is not None and lyr_poz.isValid():
            c_dim = self._rfi_campo(lyr_poz, "TIPO_POZZE", "TIPO_POZZETTO", "DIMENSIONE")
            c_sp = self._rfi_campo(lyr_poz, "STATO")
            for f in lyr_poz.getFeatures():
                if not f.hasGeometry():
                    continue
                g = self._rfi_wkt(f.geometry(), lyr_poz)
                pozzetti.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                                 "stato": self._rfi_val(f, c_sp),
                                 "dim": rfi.norm_pozzetto(self._rfi_val(f, c_dim)),
                                 # misura come scritta nel progetto (= legenda) per le etichette
                                 "dim_testo": self._rfi_val(f, c_dim), "fid": f.id()})
        lyr_arm = self._find_layer("01_ARMADIO OTTICO")
        if lyr_arm is not None and lyr_arm.isValid():
            c_ida = self._rfi_campo(lyr_arm, "AREA_AO", "ID_ARMADIO", "ID_ARMAD")  # AREA_AO = numero ARLO
            c_sta = self._rfi_campo(lyr_arm, "STATO")
            for f in lyr_arm.getFeatures():
                if not f.hasGeometry():
                    continue
                g = self._rfi_wkt(f.geometry(), lyr_arm)
                armadi.append({"geom": g if g.geom_type == "Point" else g.representative_point(),
                               "stato": self._rfi_val(f, c_sta), "id": self._rfi_val(f, c_ida),
                               "fid": f.id()})
        return tratte, pozzetti, armadi

    def _acq_comprensori(self):
        lyr = self.cb_acq_compr.currentLayer()
        campo = self.cb_acq_compr_campo.currentField()
        if lyr is None or not lyr.isValid():
            return []
        out = []
        for f in lyr.getFeatures():
            if f.hasGeometry():
                out.append({"geom": self._rfi_wkt(f.geometry(), lyr),
                            "nome": self._rfi_val(f, campo) if campo else ""})
        return out

    def _acq_trova_impl(self):
        acq = _acq_mod()
        st = self._acq_state()
        # niente più «Crea il layer» a parte: il layer dei corsi d'acqua si rifà
        # qui dalle righe spuntate, dal layer B1 e dai disegnati
        if st.get("screening") or self.cb_acq_layer.currentLayer() is not None:
            st["corsi"] = []
            self._acq_trasferisci_impl()
            if not st.get("corsi"):
                return
        if not st.get("corsi"):
            # progetto riaperto: i corsi salvati nel progetto bastano
            st["corsi"] = self._acq_corsi_da_progetto()
            if st["corsi"]:
                self._log_a("Corsi d'acqua ripresi dal progetto: %d linee (per aggiornarli da "
                            "OSM o dal layer usa il punto 2)."
                            % len(st["corsi"]))
        # i corsi disegnati a mano si rileggono sempre dal loro layer: chi disegna
        # (o corregge) un canale dopo «Crea il layer» li ritrova nella ricerca
        self._acq_aggiorna_disegnati(st)
        # corsi d'acqua con il tracciato corretto a mano
        self._acq_applica_tracciati(st)
        if not st.get("corsi"):
            QMessageBox.warning(self, "Corsi d'acqua mancanti",
                                "Prima trova i corsi d'acqua al punto 2 (A), oppure scegli un "
                                "layer (B1) o disegna il canale (B2).")
            return
        rete = self._acq_rete()
        if rete is None:
            QMessageBox.warning(self, "Layer mancante", "Manca '03 INFRASTRUTTURE' nel progetto.")
            return
        tratte, pozzetti, armadi = rete
        fasce = {k: sp.value() for k, sp in self.spin_acq_fasce.items()}
        from .ftth_barra import in_sottofondo
        bar = getattr(self, "bar_acq_i", None)
        if bar is not None:
            bar.fase(10, 95, "Ricerca delle interferenze")
        interf = in_sottofondo(
            bar, acq.trova_interferenze_acque,
            st["corsi"], tratte, pozzetti, armadi, alvei=st.get("alvei"),
            ponti=st.get("ponti"), strade=st.get("strade"),
            comprensori=self._acq_comprensori(), fasce=fasce, costa=st.get("costa_osm"))
        if bar is not None:
            bar.fase(95, 99, "Tabella")
        for i in interf:
            if i.ente_tipo == "consorzio" and not i.ente_nome:
                i.note.append("indicare il nome del Consorzio competente")
        # testi delle etichette corretti a mano nella ricerca precedente:
        # tornano sugli stessi scavi/pozzetti (stessa chiave)
        scelte = {}
        if st.get("interferenze"):
            if self.tab_acq.rowCount():
                self._acq_leggi_tabella()
            self._acq_sincronizza_da_layer()
            el_mod, unici = acq.testi_modificati(st["interferenze"])
            da_dove = "Etichette corrette a mano"
        else:
            # progetto riaperto: testi, enti e spunte dai layer salvati
            el_mod, unici, scelte = self._acq_testi_da_layer()
            el_mod = {k: v for k, v in el_mod.items() if v}
            unici = {k: v for k, v in unici.items() if v}
            da_dove = "Dal progetto salvato: etichette corrette a mano"
        if el_mod or unici:
            persi = acq.riapplica_testi(interf, el_mod, unici)
            self._log_a("%s: %d ripristinate%s" % (
                da_dove, len(el_mod) + len(unici) - persi,
                (", %d perse perché lo scavo o il pozzetto è cambiato nel progetto "
                 "(torna il testo automatico)" % persi) if persi else ""))
        if scelte:
            n = 0
            for i in interf:
                s = scelte.get(acq.chiave_interferenza(i))
                if not s:
                    continue
                n += 1
                if s.get("includi") is not None:
                    i.includi = bool(int(s["includi"]))
                for c in ("ente_tipo", "ente_nome", "tecnica_attr", "via"):
                    if s.get(c) is not None:
                        setattr(i, c, str(s[c]))
                if i.ente_nome:
                    i.note = [x for x in i.note if "nome del Consorzio" not in x]
            self._log_a("Dal progetto salvato: enti, spunte e vie ripresi su %d interferenze "
                        "su %d." % (n, len(interf)))
        st["interferenze"] = interf
        self._acq_riempi_tabella(interf)
        self._acq_layer_interferenze(interf)
        gpkg = self._acq_gpkg_progetto()
        if gpkg:
            # lavoro gia' salvato nel progetto: si aggiorna anche il GeoPackage
            self._acq_scrivi_gpkg(gpkg)
            self._log_a("Layer acque aggiornati nel GeoPackage del progetto (%s). Salva il "
                        "progetto per conservarli." % os.path.basename(gpkg))
        self._acq_riempi_enti()
        self._acq_aggiorna_destinatari()
        per = {}
        for i in interf:
            k = acq.ENTI_TIPO.get(i.ente_tipo, i.ente_tipo)
            per[k] = per.get(k, 0) + 1
        self._log_a("Interferenze trovate: %d%s" % (len(interf), (" (" + ", ".join(
            "%s: %d" % kv for kv in sorted(per.items())) + ")") if per else ""))
        if not interf:
            QMessageBox.information(self, "Nessuna interferenza",
                                    "Nessuna tratta del progetto entra nelle fasce di rispetto.")

    def _acq_riempi_tabella(self, interf):
        acq = _acq_mod()
        try:
            from . import ftth_rfi as rfi
        except ImportError:
            import ftth_rfi as rfi
        t = self.tab_acq
        t.setRowCount(0)
        for i in interf:
            r = t.rowCount()
            t.insertRow(r)
            chk = QTableWidgetItem()
            chk.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled)
            chk.setCheckState(Qt.Checked if i.includi else Qt.Unchecked)
            t.setItem(r, C_INCL, chk)
            idi = QTableWidgetItem(str(i.id))
            idi.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            idi.setData(Qt.UserRole, i.id)
            t.setItem(r, C_ID, idi)

            def _fisso(testo, col):
                it = QTableWidgetItem(testo)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                t.setItem(r, col, it)
                return it
            _fisso(acq.descr_tipo(i.tipo, i.categoria), C_TIPO)
            t.setItem(r, C_CORSO, QTableWidgetItem(i.corso))
            _fisso(acq.CATEGORIE.get(i.categoria, i.categoria), C_CAT)
            cb = QComboBox()
            for k, d in acq.ENTI_TIPO.items():
                cb.addItem(d, k)
            cb.setCurrentIndex(max(0, cb.findData(i.ente_tipo)))
            t.setCellWidget(r, C_ENTE, cb)
            t.setItem(r, C_ENTE_NOME, QTableWidgetItem(i.ente_nome))
            cbt = QComboBox()
            if i.categoria == "marittimo" or i.tipo == "parallelismo":
                cbt.addItem("—", "")
                cbt.setEnabled(False)
            else:
                for k, d in acq.TECNICHE_ATTR.items():
                    cbt.addItem(d, k)
                cbt.setCurrentIndex(max(0, cbt.findData(i.tecnica_attr or "?")))
            t.setCellWidget(r, C_TEC, cbt)
            t.setItem(r, C_VIA, QTableWidgetItem(i.via))
            _fisso(", ".join("%s %s m" % (rfi.ETICH_TECNICA.get(k, k), v)
                             for k, v in i.metri.items() if v) or "—", C_METRI)
            _fisso(", ".join("%s×%d" % (d, n) for d, n in i.pozzetti.items()) or "—", C_POZZ)
            _fisso("attraversa" if i.attraversa else
                   ("%.1f" % i.dist_min_m if i.dist_min_m is not None else ""), C_DIST)
            et = _fisso(self._acq_riassunto_etichette(i), C_ETICH)
            et.setToolTip("Doppio clic: una riga per ogni scavo e pozzetto di questa "
                          "interferenza, ognuna modificabile (vuota = testo automatico).")
            it = _fisso("; ".join(i.note), C_NOTE)
            if i.note:
                it.setForeground(QColor(170, 60, 0))
        t.resizeColumnsToContents()

    def _acq_riga(self, r):
        it = self.tab_acq.item(r, C_ID)
        iid = it.data(Qt.UserRole) if it else None
        return next((i for i in self._acq_state()["interferenze"] if i.id == iid), None)

    def _acq_leggi_tabella(self):
        """Riporta nelle interferenze le correzioni fatte in tabella."""
        acq = _acq_mod()
        for r in range(self.tab_acq.rowCount()):
            i = self._acq_riga(r)
            if i is None:
                continue
            txt = lambda c: (self.tab_acq.item(r, c).text().strip()  # noqa: E731
                             if self.tab_acq.item(r, c) else "")
            i.includi = self.tab_acq.item(r, C_INCL).checkState() == Qt.Checked
            i.corso = txt(C_CORSO) or i.corso
            i.ente_tipo = self.tab_acq.cellWidget(r, C_ENTE).currentData()
            i.ente_nome = txt(C_ENTE_NOME)
            i.tecnica_attr = self.tab_acq.cellWidget(r, C_TEC).currentData() or ""
            i.via = txt(C_VIA)
            # i testi delle etichette si cambiano nella finestra (doppio clic
            # sulla colonna), non qui
            if i.ente_nome:
                i.note = [n for n in i.note if "nome del Consorzio" not in n]
        return self._acq_state()["interferenze"]

    # --------------------------------------------- etichette per elemento
    def _acq_riassunto_etichette(self, i):
        acq = _acq_mod()
        if i.etichetta:
            return "testo unico: " + i.etichetta.replace("\n", SEP_RIGHE)
        el = acq.elementi_etichettabili(i)
        if not el:
            return acq.etichetta_automatica(i).replace("\n", SEP_RIGHE)
        mod = sum(1 for e in el if e.get("testo"))
        aut = len(el) - mod

        def _n(k, sing, plur):
            return "%d %s" % (k, sing if k == 1 else plur)
        parti = []
        if aut:
            parti.append(_n(aut, "automatica", "automatiche"))
        if mod:
            parti.append(_n(mod, "modificata", "modificate"))
        return ", ".join(parti)

    def _acq_doppio_clic(self, r, c):
        if c == C_ETICH:
            i = self._acq_riga(r)
            if i is None:
                return
            self._acq_sincronizza_da_layer()     # correzioni dalla tabella attributi
            if self._acq_finestra_etichette(i):
                self._acq_testi_su_layer(i)
                it = self.tab_acq.item(r, C_ETICH)
                if it is not None:
                    it.setText(self._acq_riassunto_etichette(i))
        else:
            self._acq_zoom_riga()

    def _acq_finestra_etichette(self, i):
        """Una riga per ogni scavo continuo e pozzetto dell'interferenza:
        testo proposto e testo in tavola (vuoto = automatico). In fondo, in
        alternativa, un testo unico per tutta l'interferenza."""
        from qgis.PyQt.QtWidgets import (QDialog, QDialogButtonBox, QLabel, QVBoxLayout as _V)
        acq = _acq_mod()
        el = acq.elementi_etichettabili(i)
        dlg = QDialog(self)
        dlg.setWindowTitle("Etichette in tavola — interferenza %d (%s)" % (i.id, i.via or i.corso))
        dlg.resize(760, 360)
        v = _V(dlg)
        v.addWidget(QLabel("Correggi solo le righe che ti servono: quelle vuote restano "
                           "automatiche. Ogni etichetta resta attaccata al suo elemento."))
        tab = QTableWidget(len(el), 3)
        tab.setHorizontalHeaderLabels(["Elemento", "Testo proposto", "Testo in tavola"])
        tab.horizontalHeader().setStretchLastSection(True)
        nomi = {"scavo": "Scavo", "pozzetto": "Pozzetto", "armadio": "Armadio",
                "colonnina": "Colonnina PTE"}
        n_sc = 0
        for r, e in enumerate(el):
            if e["tipo"] == "scavo":
                n_sc += 1
                nome = "Scavo continuo %d" % n_sc
            else:
                nome = nomi.get(e["tipo"], e["tipo"])
            for col, testo in ((0, nome), (1, acq.testo_elemento_auto(e))):
                it = QTableWidgetItem(testo)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                tab.setItem(r, col, it)
            it = QTableWidgetItem((e.get("testo") or "").replace("\n", SEP_RIGHE))
            it.setToolTip("Una riga per ogni ' / '. Vuoto = testo proposto.")
            tab.setItem(r, 2, it)
        tab.resizeColumnsToContents()
        tab.setColumnWidth(2, max(tab.columnWidth(2), 300))
        v.addWidget(tab)
        v.addWidget(QLabel("In alternativa, un testo unico per tutta l'interferenza (sostituisce "
                           "le etichette sopra; righe separate da ' / '):"))
        unico = QLineEdit((i.etichetta or "").replace("\n", SEP_RIGHE))
        v.addWidget(unico)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(dlg.accept)
        bb.rejected.connect(dlg.reject)
        v.addWidget(bb)
        if dlg.exec_() != QDialog.Accepted:
            return False

        def _righe(s):
            return "\n".join(p.strip() for p in (s or "").split("/") if p.strip())
        for r, e in enumerate(el):
            testo = _righe(tab.item(r, 2).text() if tab.item(r, 2) else "")
            e["testo"] = testo if testo and testo != acq.testo_elemento_auto(e) else ""
        i.etichetta = _righe(unico.text())
        return True

    def _acq_zoom_riga(self):
        righe = self.tab_acq.selectionModel().selectedRows() if self.tab_acq.selectionModel() else []
        if not righe:
            return
        i = self._acq_riga(righe[0].row())
        if i is None:
            return
        wgs = QgsCoordinateReferenceSystem("EPSG:4326")
        d = 0.0012
        rect = QgsRectangle(i.lon - d, i.lat - d, i.lon + d, i.lat + d)
        tr = QgsCoordinateTransform(wgs, self.iface.mapCanvas().mapSettings().destinationCrs(),
                                    self.project)
        self.iface.mapCanvas().setExtent(tr.transformBoundingBox(rect))
        self.iface.mapCanvas().refresh()

    def _acq_layer_interferenze(self, interf):
        acq = _acq_mod()
        vl = QgsVectorLayer("Point?crs=EPSG:4326", "Interferenze acque", "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("id", QVariant.Int), QgsField("tipo", QVariant.String),
                          QgsField("corso", QVariant.String), QgsField("ente", QVariant.String),
                          QgsField("etichetta", QVariant.String),
                          # scelte della tabella, riprese alla riapertura del progetto
                          QgsField("chiave", QVariant.String), QgsField("includi", QVariant.Int),
                          QgsField("ente_tipo", QVariant.String),
                          QgsField("ente_nome", QVariant.String),
                          QgsField("tecnica_attr", QVariant.String),
                          QgsField("via", QVariant.String),
                          QgsField("testo_unico", QVariant.String)])
        vl.updateFields()
        feats = []
        for i in interf:
            f = QgsFeature(vl.fields())
            f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat)))
            f["id"] = i.id
            f["tipo"] = acq.descr_tipo(i.tipo, i.categoria)
            f["corso"] = i.corso
            f["ente"] = i.ente_nome or acq.ENTI_TIPO.get(i.ente_tipo, i.ente_tipo)
            f["etichetta"] = "#%d %s" % (i.id, i.corso)
            f["chiave"] = acq.chiave_interferenza(i)
            f["includi"] = 1 if i.includi else 0
            f["ente_tipo"] = i.ente_tipo
            f["ente_nome"] = i.ente_nome or ""
            f["tecnica_attr"] = i.tecnica_attr or ""
            f["via"] = i.via or ""
            f["testo_unico"] = (i.etichetta or "").replace("\n", SEP_RIGHE)
            feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "circle", "color": "0,120,255,90", "outline_color": "0,60,170,255",
             "size": "7"})))
        self._rfi_etichetta(vl, "etichetta", 8, colore=QColor(0, 60, 170))
        self._acq_sostituisci_layer("Interferenze acque", vl)
        self._acq_layer_tratte(interf)
        self._acq_layer_etichette(interf)
        self._acq_ordina_layer()

    def _acq_layer_tratte(self, interf):
        """Gli scavi continui che cadono in fascia, evidenziati in mappa."""
        acq = _acq_mod()
        vl = QgsVectorLayer("MultiLineString?crs=EPSG:4326", NOME_TRATTE, "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("chiave", QVariant.String), QgsField("interf", QVariant.Int),
                          QgsField("corso", QVariant.String), QgsField("tecnica", QVariant.String),
                          QgsField("metri", QVariant.Int), QgsField("includi", QVariant.Int)])
        vl.updateFields()
        feats = []
        for i in interf:
            for e in acq.elementi_etichettabili(i):
                if e.get("tipo") != "scavo" or not e.get("_wkt"):
                    continue
                g = QgsGeometry.fromWkt(e["_wkt"])
                if g is None or g.isEmpty():
                    continue
                g.convertToMultiType()
                f = QgsFeature(vl.fields())
                f.setGeometry(g)
                f["chiave"] = e["chiave_el"]
                f["interf"] = i.id
                f["corso"] = i.corso
                f["tecnica"] = str(e.get("tecnica") or "")
                f["metri"] = int(e.get("metri") or 0)
                f["includi"] = 1 if i.includi else 0
                feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
            {"line_color": "255,120,0,150", "line_width": "1.6", "capstyle": "round"})))
        self._acq_sostituisci_layer(NOME_TRATTE, vl)

    def _acq_layer_etichette(self, interf):
        """Un punto per ogni scavo continuo e pozzetto in fascia con il testo che
        va in tavola: «proposto» (automatico) e «testo» (corretto a mano; vuoto =
        proposto). Si corregge dalla finestra della scheda o dalla tabella
        attributi; il layer salvato nel progetto conserva le correzioni."""
        acq = _acq_mod()
        vl = QgsVectorLayer("Point?crs=EPSG:4326", NOME_ETICHETTE, "memory")
        pr = vl.dataProvider()
        pr.addAttributes([QgsField("chiave", QVariant.String), QgsField("interf", QVariant.Int),
                          QgsField("corso", QVariant.String), QgsField("elemento", QVariant.String),
                          QgsField("proposto", QVariant.String),
                          QgsField("testo", QVariant.String), QgsField("includi", QVariant.Int)])
        vl.updateFields()
        feats = []
        for i in interf:
            for e in acq.elementi_etichettabili(i):
                if e.get("lon") is None or e.get("lat") is None:
                    continue
                f = QgsFeature(vl.fields())
                f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(e["lon"], e["lat"])))
                f["chiave"] = e["chiave_el"]
                f["interf"] = i.id
                f["corso"] = i.corso
                f["elemento"] = e["tipo"]
                f["proposto"] = acq.testo_elemento_auto(e).replace("\n", SEP_RIGHE)
                f["testo"] = (e.get("testo") or "").replace("\n", SEP_RIGHE)
                f["includi"] = 1 if i.includi else 0
                feats.append(f)
        pr.addFeatures(feats)
        vl.updateExtents()
        vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
            {"name": "circle", "color": "255,255,255,255", "outline_color": "0,60,170,255",
             "outline_width": "0.4", "size": "1.8"})))
        self._rfi_etichetta(
            vl, "replace(coalesce(nullif(trim(\"testo\"), ''), \"proposto\"), ' / ', '\\n')",
            7, espressione=True, colore=QColor(0, 60, 170))
        lab = vl.labeling()
        if lab is not None:
            pal = lab.settings()
            try:
                from qgis.core import QgsPalLayerSettings as _P
                pal.placement = _P.OrderedPositionsAroundPoint
                pal.dist = 1.5
            except Exception:  # noqa: BLE001
                pass
            lab.setSettings(pal)
        self._acq_sostituisci_layer(NOME_ETICHETTE, vl)

    # ------------------------------------------- ente per corso d'acqua
    def _acq_chiave_corso(self, i):
        return _acq_mod().nome_corso_istanza(i.corso, i.categoria)

    def _acq_riempi_enti(self):
        """Una riga per corso d'acqua con l'ente delle sue interferenze: si
        sceglie qui una volta sola, prima di generare (istanze sempre per ente)."""
        acq = _acq_mod()
        from collections import Counter
        interf = self._acq_leggi_tabella() if self.tab_acq.rowCount() else []
        gruppi = {}
        for i in interf:
            gruppi.setdefault(self._acq_chiave_corso(i), []).append(i)
        corsi = self._acq_state().get("corsi") or []
        compr = self.cb_acq_compr.currentLayer() is not None
        t = self.tab_acq_enti
        t.blockSignals(True)
        t.setRowCount(0)
        for k, lst in sorted(gruppi.items(),
                             key=lambda kv: (not acq._con_nome(kv[0]), kv[0].lower())):
            r = t.rowCount()
            t.insertRow(r)

            def _fisso(testo, col, dato=None):
                it = QTableWidgetItem(testo)
                it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                if dato is not None:
                    it.setData(Qt.UserRole, dato)
                t.setItem(r, col, it)
            cat = lst[0].categoria
            _fisso(k, 0, k)
            _fisso(acq.CATEGORIE.get(cat, cat), 1)
            escl = sum(1 for i in lst if not i.includi)
            _fisso("%d%s" % (len(lst), (" (%d escluse)" % escl) if escl else ""), 2)
            tipo = Counter(i.ente_tipo for i in lst).most_common(1)[0][0]
            nome = Counter((i.ente_nome or "") for i in lst if i.ente_tipo == tipo
                           ).most_common(1)[0][0]
            cb = QComboBox()
            for kk, dsc in acq.ENTI_TIPO.items():
                cb.addItem(dsc, kk)
            cb.setCurrentIndex(max(0, cb.findData(tipo)))
            cb.currentIndexChanged.connect(
                lambda _=0, chiave=k, combo=cb, riga=r: self._acq_ente_scelto(
                    chiave, combo.currentData(), riga))
            t.setCellWidget(r, 3, cb)
            t.setItem(r, 4, QTableWidgetItem(nome))
            # perche' quell'ente: aiuta a capire se fidarsi della proposta
            da_layer = next((c for c in corsi if c.nome == lst[0].corso and c.ente_tipo), None)
            if len({(i.ente_tipo, i.ente_nome or "") for i in lst}) > 1:
                motivo = "righe con enti diversi al punto 3: qui li rendi uguali"
            elif da_layer is not None:
                motivo = "competenza indicata nel layer «%s»" % (da_layer.fonte or "del progetto")
            elif tipo == "consorzio" and nome and compr:
                motivo = "comprensorio di bonifica in cui ricade"
            else:
                motivo = "solo la categoria del corso d'acqua: da verificare (siti utili)"
            _fisso(motivo, 5)
        t.blockSignals(False)
        # larghezze fisse: con l'adattamento al contenuto il nome dell'ente
        # (la colonna da compilare) finiva fuori vista
        for col, lw in enumerate((190, 150, 85, 230, 280)):
            t.setColumnWidth(col, lw)

    def _acq_ente_scelto(self, chiave, tipo, riga=None):
        """Ente cambiato per un corso d'acqua: vale per tutte le sue righe. Il
        nome dell'ente precedente non vale piu' e si svuota."""
        for r in range(self.tab_acq.rowCount()):
            i = self._acq_riga(r)
            if i is None or self._acq_chiave_corso(i) != chiave:
                continue
            cb = self.tab_acq.cellWidget(r, C_ENTE)
            if cb is not None:
                cb.setCurrentIndex(max(0, cb.findData(tipo)))
            self.tab_acq.setItem(r, C_ENTE_NOME, QTableWidgetItem(""))
        if riga is not None and self.tab_acq_enti.item(riga, 4) is not None:
            self.tab_acq_enti.blockSignals(True)
            self.tab_acq_enti.item(riga, 4).setText("")
            self.tab_acq_enti.blockSignals(False)
        self._acq_leggi_tabella()
        self._acq_aggiorna_destinatari()

    def _acq_ente_nome_cambiato(self, item):
        if item is None or item.column() != 4:
            return
        k_it = self.tab_acq_enti.item(item.row(), 0)
        chiave = k_it.data(Qt.UserRole) if k_it is not None else None
        if not chiave:
            return
        nome = item.text().strip()
        for r in range(self.tab_acq.rowCount()):
            i = self._acq_riga(r)
            if i is not None and self._acq_chiave_corso(i) == chiave:
                self.tab_acq.setItem(r, C_ENTE_NOME, QTableWidgetItem(nome))
        self._acq_leggi_tabella()
        self._acq_aggiorna_destinatari()

    # -------------------------------------------------------- destinatari
    def _acq_dest_salvati(self):
        try:
            from qgis.core import QgsSettings
            return json.loads(QgsSettings().value("ftth_permessi/acque_destinatari", "") or "{}")
        except Exception:  # noqa: BLE001
            return {}

    def _acq_aggiorna_destinatari(self):
        acq = _acq_mod()
        interf = self._acq_leggi_tabella() if self.tab_acq.rowCount() else []
        salvati = self._acq_dest_salvati()
        # quello gia' scritto in tabella vale piu' del ricordato
        attuali = {}
        for r in range(self.tab_acq_dest.rowCount()):
            k = self.tab_acq_dest.item(r, 0).data(Qt.UserRole)
            attuali[k] = [self.tab_acq_dest.item(r, c).text() if self.tab_acq_dest.item(r, c)
                          else "" for c in (1, 2, 3)]
        enti = []
        for i in interf:
            if not i.includi:
                continue
            k = "%s|%s" % (i.ente_tipo, (i.ente_nome or "").strip())
            if k not in [e[0] for e in enti]:
                enti.append((k, i.ente_tipo, (i.ente_nome or "").strip()))
        t = self.tab_acq_dest
        t.blockSignals(True)
        t.setRowCount(0)
        regione = self._acq_state().get("regione") or ""
        for k, et, en in enti:
            r = t.rowCount()
            t.insertRow(r)
            it = QTableWidgetItem(en or acq.ENTI_TIPO.get(et, et))
            it.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
            it.setData(Qt.UserRole, k)
            t.setItem(r, 0, it)
            noto = acq.destinatario_noto(et, en, regione)
            val = attuali.get(k) or salvati.get(k) or [
                noto.get("nome") or en, noto.get("indirizzo", ""), noto.get("pec", "")]
            for c, testo in zip((1, 2, 3), val):
                t.setItem(r, c, QTableWidgetItem(testo or ""))
        t.blockSignals(False)
        t.resizeColumnsToContents()

    def _acq_ricorda_destinatari(self, *_):
        salvati = self._acq_dest_salvati()
        t = self.tab_acq_dest
        for r in range(t.rowCount()):
            k = t.item(r, 0).data(Qt.UserRole) if t.item(r, 0) else None
            if not k:
                continue
            salvati[k] = [t.item(r, c).text() if t.item(r, c) else "" for c in (1, 2, 3)]
        try:
            from qgis.core import QgsSettings
            QgsSettings().setValue("ftth_permessi/acque_destinatari", json.dumps(salvati))
        except Exception:  # noqa: BLE001
            pass
