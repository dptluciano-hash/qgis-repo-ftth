# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""
Classe principale del plugin FTTH Permessi Manager.
Registra l'azione in toolbar/menu e apre il dialogo principale.
"""
import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject, QgsMessageLog, Qgis


class FTTHPermessiPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = "&FTTH Permessi"
        self.toolbar = self.iface.addToolBar("FTTH Permessi")
        self.toolbar.setObjectName("FTTHPermessiToolbar")
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Gestione Permessi FTTH", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.action.setEnabled(True)

        self.toolbar.addAction(self.action)
        self.iface.addPluginToMenu(self.menu, self.action)
        self.actions.append(self.action)

        # I coni di ripresa ruotati devono riportare l'orientamento sul punto
        # anche se il plugin non viene mai aperto: la connessione al
        # salvataggio vive nell'oggetto layer di questa sessione, quindi va
        # rifatta a ogni apertura di progetto. Senza questo, chi riapre un
        # progetto, ruota un cono e salva non vede cambiare niente sul punto.
        # La lambda viene conservata: un segnale si puo' scollegare solo se si
        # ha in mano lo stesso oggetto che e' stato collegato. Senza questo,
        # dopo un 'Ricarica plugin' la vecchia istanza resta agganciata al
        # progetto e lavora in parallelo alla nuova.
        self._slot_layers = lambda _l: self._aggancia_coni()
        try:
            QgsProject.instance().readProject.connect(self._aggancia_coni)
            QgsProject.instance().layersAdded.connect(self._slot_layers)
            self._aggancia_coni()      # progetto gia' aperto all'avvio di QGIS
        except Exception as e:
            self._avvisa("aggancio dei coni all'avvio non riuscito", e)

    def _avvisa(self, testo, err):
        """Un guasto all'avvio non deve sparire: senza una riga da qualche
        parte, un errore di import spegne il riporto delle rotazioni per
        sempre e non se ne accorge nessuno."""
        try:
            QgsMessageLog.logMessage("%s: %s" % (testo, err),
                                     "FTTH Permessi", Qgis.Warning)
        except Exception:
            pass

    def _aggancia_coni(self, *args):
        try:
            from .ftth_permessi_dialog import aggancia_coni_progetto
            aggancia_coni_progetto(QgsProject.instance(), self.iface)
        except Exception as e:
            self._avvisa("riaggancio dei coni al progetto non riuscito", e)
        try:    # «Solo comunale» lasciato attivo in un progetto salvato: si toglie
            from . import ftth_pannello as _PN
            _PN.filtro_comunale(QgsProject.instance(), False)
        except Exception as e:
            self._avvisa("ripristino dei layer comunali non riuscito", e)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        # si stacca quello che si era attaccato, altrimenti la vecchia
        # istanza continua a rispondere ai segnali del progetto
        for segnale, slot in ((QgsProject.instance().readProject, self._aggancia_coni),
                              (QgsProject.instance().layersAdded,
                               getattr(self, "_slot_layers", None))):
            if slot is None:
                continue
            try:
                segnale.disconnect(slot)
            except (TypeError, RuntimeError):
                pass
        if self.toolbar is not None:
            self.toolbar.deleteLater()      # 'del' non la toglie dalla finestra
            self.toolbar = None

    def run(self):
        # Import ritardato: evita di caricare PyQt/QGIS widgets finché non serve
        from .ftth_permessi_dialog import FTTHPermessiDialog

        if self.dlg is None:
            self.dlg = FTTHPermessiDialog(self.iface, QgsProject.instance())

        self.dlg.refresh_layers()
        # Istanze Acque: se nel frattempo e' stato aperto un altro progetto la
        # scheda riparte dal lavoro salvato in quello
        for metodo in ("_acq_al_cambio_progetto", "_quadro_al_cambio_progetto"):
            if hasattr(self.dlg, metodo):
                try:
                    getattr(self.dlg, metodo)()
                except Exception:  # noqa: BLE001
                    pass
        # all'apertura tutti i menu a tendina (riquadri) chiusi
        if not self.dlg.isVisible() and hasattr(self.dlg, "_chiudi_tutte_le_sezioni"):
            try:
                self.dlg._chiudi_tutte_le_sezioni()
            except Exception:  # noqa: BLE001
                pass
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
