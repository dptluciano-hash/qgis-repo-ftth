# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""
Classe principale del plugin FTTH Permessi Manager.
Registra l'azione in toolbar/menu e apre il dialogo principale.
"""
import os

from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from qgis.core import QgsProject


class FTTHPermessiPlugin:

    def __init__(self, iface):
        self.iface = iface
        self.plugin_dir = os.path.dirname(__file__)
        self.actions = []
        self.menu = "&FTTH Permessi"
        self.toolbar = self.iface.addToolBar("FTTH Permessi")
        self.toolbar.setObjectName("FTTHPermessiToolbar")
        self.dlg = None

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "icon.png")
        icon = QIcon(icon_path) if os.path.exists(icon_path) else QIcon()

        self.action = QAction(icon, "Gestione Permessi FTTH", self.iface.mainWindow())
        self.action.triggered.connect(self.run)
        self.action.setEnabled(True)

        self.toolbar.addAction(self.action)
        self.iface.addPluginToMenu(self.menu, self.action)
        self.actions.append(self.action)

    def unload(self):
        for action in self.actions:
            self.iface.removePluginMenu(self.menu, action)
            self.iface.removeToolBarIcon(action)
        del self.toolbar

    def run(self):
        # Import ritardato: evita di caricare PyQt/QGIS widgets finché non serve
        from .ftth_permessi_dialog import FTTHPermessiDialog

        if self.dlg is None:
            self.dlg = FTTHPermessiDialog(self.iface, QgsProject.instance())

        self.dlg.refresh_layers()
        self.dlg.show()
        self.dlg.raise_()
        self.dlg.activateWindow()
