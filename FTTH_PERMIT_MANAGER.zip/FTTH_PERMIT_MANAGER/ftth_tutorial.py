# -*- coding: utf-8 -*-
"""Tutorial interattivo del plugin: guida passo passo della sezione aperta.

Premendo «Tutorial» la finestra si scurisce e, un passo alla volta, viene
evidenziato un elemento della sezione corrente con un fumetto che spiega cosa
fare (Indietro / Avanti / Chiudi, anche con le frecce e Esc). I passi si
costruiscono da soli leggendo la sezione: introduzione, poi ogni riquadro nel
suo ordine (che viene aperto se è chiuso) con la sua descrizione, poi i
pulsanti principali. Per le sezioni più usate c'è un'introduzione scritta.
"""
from qgis.PyQt.QtCore import QEvent, QPoint, QRect, Qt
from qgis.PyQt.QtGui import QColor, QPainter, QPainterPath, QPen
from qgis.PyQt.QtWidgets import (
    QFrame, QGroupBox, QHBoxLayout, QLabel, QPushButton, QScrollArea, QTabWidget, QVBoxLayout,
    QWidget,
)

NAVY = "#031B52"
ARANCIO = "#FF7C02"

# introduzioni scritte, per nome della sezione (il resto si legge dalla scheda)
INTRO = {
    "Seleziona elementi": "Qui si selezionano gli elementi da togliere o da controllare prima di "
        "presentare il permesso comunale. Imposta in alto i layer del progetto, poi lancia le "
        "regole una alla volta: la 1 seleziona la rete di delivery dal civico al PTE, le altre "
        "casi particolari. Il registro in fondo dice cosa è stato trovato.",
    "Keyplan e tavole": "Si costruiscono le tavole della planimetria: prima il layer della rete "
        "nuova, poi le tavole di inquadramento, poi il keyplan, la numerazione e il salvataggio.",
    "Punti di ripresa": "Si piazzano i coni dei punti di ripresa fotografica per ogni tavola e "
        "si numerano le foto, così le PL trovano FOTO-n.jpg nella cartella 04_Foto. In tavola la scritta «FOTO n» si mette da sola di lato al cono, mai sopra. "
        "Ogni sezione ha la sua tavola, anche se è vicina a un'altra. Al passo 6 scegli i tubi "
        "posati («Tubi nei particolari…»); a ogni «Genera» la finestra dei tubi si apre "
        "comunque per farteli controllare.",
    "Verifica armadi": "Si controllano gli armadi uno per uno su Street View e Google Maps e si "
        "segna l'esito (salvato nel progetto). Se un armadio va spostato: «Sposta l'armadio», "
        "clic sul punto nuovo in mappa (esito «Spostato» e nuovo indirizzo); «Vedi dove era "
        "prima» e «Rimetti dove era» per tornare indietro. L'Excel riporta vecchio e nuovo "
        "indirizzo con il link al punto esatto.",
    "Verifica interferenze": "Si trovano le tratte vicine a ferrovie, corsi d'acqua, strade "
        "ANAS, provinciali e autostrade già nel permesso comunale, per decidere se spostarle "
        "prima di chiedere le autorizzazioni agli altri enti. Le opere e le fasce di rispetto "
        "vanno in mappa nel gruppo «Verifica interferenze»; il pannello a destra è una tabella "
        "con filtri: selezioni più righe (Ctrl/Maiusc + clic) e dai l'esito a tutte insieme. "
        "«Mostra le escluse» fa vedere le tratte non controllate; c'è l'esportazione Excel.",
    "Esportazione": "Si preparano gli shape da consegnare e si esportano in PDF i layout del "
        "progetto (atlante), da unire poi in un unico documento.",
    "Screening territorio": "Primo passo per gli altri enti: scrivi il comune e lo screening "
        "trova strade classificate, ferrovie, acque, vincoli e aree protette che la rete tocca.",
    "Quadro pratiche": "Il riepilogo delle pratiche da presentare agli altri enti, a partire "
        "dallo screening: da qui si va alla scheda di ogni istanza.",
    "Istanze Strade": "Istanze per strade statali, provinciali e regionali, in 6 passi come le "
        "altre istanze: comune, strade ed enti (con «Mostra in mappa»; se il tracciato OSM è "
        "sbagliato si corregge nelle avanzate del passo 2), interferenze con le chilometriche "
        "strada per strada, enti e destinatari, foto sezioni ed etichette, stampa. Le direttive "
        "di un ente (es. Città Metropolitana di Genova: nulla osta nei centri abitati, "
        "planimetrie 1:5000 e 1:200, piano di cantiere) si applicano da sole; per un altro ente "
        "«Carica regole ente…» nelle avanzate del passo 6 legge il file delle direttive.",
    "Istanze RFI": "Istanze ferroviarie: ferrovie ed enti (con Mostra in mappa e altre fonti), "
        "interferenze con la tipologia proposta (A, B, C, D), progressive chilometriche linea "
        "per linea, destinatari e generazione dei documenti. Al passo 5 scegli la scala delle "
        "tavole (automatica, anche miste, oppure 1:500, 1:1000 o 1:2000 fissa) e «Calcola "
        "numero di tavole (anteprima)» divide le interferenze nel minor numero di tavole "
        "(senza sovrapposizioni), te le mostra e disegna i riquadri: fai una sezione dentro "
        "ogni riquadro (le tavole escono nell'ordine del numero scritto sul riquadro; il "
        "foglio della sezione va in tavola alla sua misura vera, mai ingrandito). Tutti i pozzetti sugli scavi dell'istanza (nuovi ed esistenti) entrano da soli in tavola. Tutto ciò che è di RFI (foto, "
        "sezioni, coni, etichette, quote, ferrovia e fascia) sta nel gruppo «Altri enti > RFI»; "
        "allo stesso modo Strade, Acque, Soprintendenza e Parchi nei loro gruppi.",
    "Istanze Acque": "Istanze per corsi d'acqua e demanio: corsi d'acqua ed enti da OSM o dal "
        "tuo layer (con Mostra in mappa), interferenze, enti competenti e generazione. Per i "
        "canali consortili la fascia è 4-12 m: si cerca entro 12 m e in tavola c'è anche il "
        "limite dei 4 m.",
    "Istanze Soprintendenza": "Istanze paesaggistiche: comune, aree vincolate ed enti (SITAP o "
        "tuo layer, con Mostra in mappa), interventi nelle aree, destinatari e generazione. Al "
        "punto 6 puoi aggiungere le colonnine PTE nuove come elementi fuori terra e il "
        "particolare costruttivo della colonnina.",
    "Istanze Parchi / Natura 2000": "Istanze per parchi e siti Natura 2000: aree protette (con "
        "Mostra in mappa), interventi, esito VIncA per via, destinatari e generazione.",
    "Vista istanze": "Cosa vedere in mappa incrociando tutte le schede istanze: con l'occhio (o "
        "la spunta) accendi o spegni l'istanza comunale (la rete senza istanze), le strade per "
        "famiglia (SS, SP…) e una per una, le linee ferroviarie, i corsi d'acqua e le aree. "
        "Ogni istanza è un gruppo in «Altri enti» fatto degli stessi shape comunali con un "
        "filtro: quello che modifichi lì cambia nel comunale, e il gruppo resta nel progetto. "
        "Pulsanti «Tutto», «Solo comunale», «Solo istanze altri enti»; il cursore rende "
        "trasparente la rete comunale e lascia piene le istanze sopra. Quando inizi le istanze "
        "agli altri enti, «Dividi per gruppi» mette il progetto comunale nel gruppo «Comunale» "
        "del pannello Layer e le istanze in «Altri enti».",
    "Consegna pratiche": "Si raccolgono i documenti di ogni istanza in una cartella di consegna "
        "e si crea il PDF unico da allegare alla PEC. «Shape per istanza»: spunti le istanze e "
        "per ognuna nasce una cartella con i suoi shape (solo le sue tratte, pozzetti e armadi, "
        "più i suoi punti di ripresa e sezioni) e lo ZIP. «Crea shape» esporta i layer che "
        "scegli tu. Nel comunale, dopo «Crea la cartella di consegna shape», il pulsante "
        "«Prepara Assegnazione Service» copia nella cartella «Assegnazione Service» del "
        "progetto la cartella shape (con lo ZIP) e la cartella 04_Foto, senza Autocad.",
}


def pagina_corrente(dialog):
    """(nome della sezione, widget della pagina) della scheda visibile."""
    tw = getattr(dialog, "_tabs_principali", None)
    nome = ""
    w = tw
    while isinstance(w, QTabWidget):
        nome = w.tabText(w.currentIndex())
        w = w.currentWidget()
    if isinstance(w, QScrollArea):
        w = w.widget()
    return nome, w


def _testo_di(widget, limite=420):
    """Prima descrizione (etichetta lunga) dentro il widget."""
    for l in widget.findChildren(QLabel):
        t = (l.text() or "").strip()
        if len(t) > 60 and not t.startswith("<img"):
            t = " ".join(t.replace("<br>", " ").split())
            return t if len(t) <= limite else t[:limite].rsplit(" ", 1)[0] + "…"
    return ""


def costruisci_passi(dialog):
    """[(widget bersaglio o None, titolo, testo)] della sezione aperta."""
    nome, pagina = pagina_corrente(dialog)
    if pagina is None:
        return []
    passi = [(pagina, nome or "Sezione", INTRO.get(nome) or _testo_di(pagina) or
              "Questa è la sezione aperta: la guida ti accompagna nei suoi passaggi.")]
    # riquadri di primo livello, nell'ordine in cui compaiono
    gruppi = [g for g in pagina.findChildren(QGroupBox)
              if not any(isinstance(p, QGroupBox) for p in _antenati(g, pagina))]
    gruppi.sort(key=lambda g: g.mapTo(pagina, QPoint(0, 0)).y())
    for n, g in enumerate(gruppi, 1):
        titolo = (g.title() or "").strip() or "Riquadro %d" % n
        testo = _testo_di(g) or "Compila i campi che servono in questo riquadro."
        comandi = []
        for b in g.findChildren(QPushButton):
            t = (b.text() or "").strip()
            if t and len(t) > 3 and t not in comandi and t not in ("◀", "▶", "Sfoglia…"):
                comandi.append(t)
        if comandi:
            testo += "\n\nComandi: " + ", ".join("«%s»" % c for c in comandi[:5]) + \
                ("…" if len(comandi) > 5 else "")
        passi.append((g, "%s" % titolo, testo))
    # pulsanti principali fuori dai riquadri (es. Genera, Avvia screening)
    for b in pagina.findChildren(QPushButton):
        if any(isinstance(p, QGroupBox) for p in _antenati(b, pagina)):
            continue
        if b.property("primario") or "font-weight:bold" in (b.styleSheet() or "").replace(" ", ""):
            passi.append((b, b.text().strip(), "Quando i passaggi sopra sono pronti, premi "
                          "«%s»." % b.text().strip()))
    passi.append((None, "Fine", "La guida è finita. Il pulsante «? Guida» in cima alla sezione "
                  "ha la spiegazione completa; il registro in fondo racconta cosa ha fatto il "
                  "plugin. Puoi rilanciare il tutorial in ogni sezione."))
    return passi


def _antenati(w, fino_a):
    p = w.parentWidget()
    while p is not None and p is not fino_a:
        yield p
        p = p.parentWidget()


class Tutorial(QWidget):
    """Velo scuro con il buco sull'elemento del passo e il fumetto."""

    def __init__(self, dialog):
        super().__init__(dialog)
        self.dialog = dialog
        self.passi = costruisci_passi(dialog)
        self.i = 0
        self._buco = QRect()
        self.setAttribute(Qt.WA_StyledBackground, False)
        self.setFocusPolicy(Qt.StrongFocus)
        self.fumetto = QFrame(self)
        self.fumetto.setObjectName("fumettoTutorial")
        self.fumetto.setStyleSheet(
            "#fumettoTutorial { background: white; border: 2px solid %s; border-radius: 10px; }"
            "QLabel { background: transparent; color: #1f1f1f; }"
            "QPushButton { padding: 4px 12px; }" % NAVY)
        v = QVBoxLayout(self.fumetto)
        v.setContentsMargins(14, 10, 14, 10)
        self.lbl_passo = QLabel("")
        self.lbl_passo.setStyleSheet("color: %s; font-weight: bold;" % ARANCIO)
        v.addWidget(self.lbl_passo)
        self.lbl_tit = QLabel("")
        self.lbl_tit.setWordWrap(True)
        self.lbl_tit.setStyleSheet("color: %s; font-weight: bold; font-size: 11pt;" % NAVY)
        v.addWidget(self.lbl_tit)
        self.lbl_txt = QLabel("")
        self.lbl_txt.setWordWrap(True)
        v.addWidget(self.lbl_txt)
        r = QHBoxLayout()
        self.b_chiudi = QPushButton("Chiudi")
        self.b_chiudi.clicked.connect(self.chiudi)
        r.addWidget(self.b_chiudi)
        r.addStretch()
        self.b_ind = QPushButton("◀ Indietro")
        self.b_ind.clicked.connect(lambda: self.vai(self.i - 1))
        r.addWidget(self.b_ind)
        self.b_av = QPushButton("Avanti ▶")
        self.b_av.setStyleSheet("background: %s; color: white; font-weight: bold; "
                                "border-radius: 6px;" % NAVY)
        self.b_av.clicked.connect(lambda: self.vai(self.i + 1))
        r.addWidget(self.b_av)
        v.addLayout(r)
        self.fumetto.setFixedWidth(380)
        dialog.installEventFilter(self)

    def avvia(self):
        if not self.passi:
            return
        self.setGeometry(self.dialog.rect())
        self.show()
        self.raise_()
        self.setFocus()
        self.vai(0)

    def chiudi(self):
        try:
            self.dialog.removeEventFilter(self)
        except Exception:  # noqa: BLE001
            pass
        self.hide()
        self.deleteLater()

    def eventFilter(self, obj, ev):
        if obj is self.dialog and ev.type() in (QEvent.Resize, QEvent.Move):
            self.setGeometry(self.dialog.rect())
            self._posiziona()
        return False

    def keyPressEvent(self, ev):
        k = ev.key()
        if k == Qt.Key_Escape:
            self.chiudi()
        elif k in (Qt.Key_Right, Qt.Key_Return, Qt.Key_Enter, Qt.Key_Space):
            self.vai(self.i + 1)
        elif k == Qt.Key_Left:
            self.vai(self.i - 1)

    def vai(self, i):
        if i >= len(self.passi):
            self.chiudi()
            return
        self.i = max(0, i)
        bersaglio, titolo, testo = self.passi[self.i]
        if bersaglio is not None:
            # apre il riquadro chiuso e lo porta in vista
            if hasattr(bersaglio, "setCollapsed") and getattr(bersaglio, "isCollapsed", None) \
                    and bersaglio.isCollapsed():
                bersaglio.setCollapsed(False)
            area = next((p for p in _antenati(bersaglio, self.dialog)
                         if isinstance(p, QScrollArea)), None)
            if area is not None and bersaglio is not area.widget():
                from qgis.PyQt.QtWidgets import QApplication
                QApplication.processEvents()
                area.ensureWidgetVisible(bersaglio, 10, 30)
        self.lbl_passo.setText("Passo %d di %d" % (self.i + 1, len(self.passi)))
        self.lbl_tit.setText(titolo)
        self.lbl_txt.setText(testo)
        # le QLabel a capo automatico non calcolano da sole l'altezza giusta
        # dentro un riquadro a larghezza fissa (titolo su due righe → testo
        # tagliato): larghezza fissa e altezza calcolata per quella larghezza
        larg = self.fumetto.width() - 28
        for lbl in (self.lbl_tit, self.lbl_txt):
            lbl.setFixedWidth(larg)
            lbl.setMinimumHeight(lbl.heightForWidth(larg))
        self.b_ind.setEnabled(self.i > 0)
        self.b_av.setText("Fine ✓" if self.i == len(self.passi) - 1 else "Avanti ▶")
        self._posiziona()

    def _posiziona(self):
        if not self.passi:
            return
        bersaglio = self.passi[self.i][0]
        if bersaglio is not None and bersaglio.isVisible():
            tl = bersaglio.mapTo(self.dialog, QPoint(0, 0))
            r = QRect(tl, bersaglio.size()).adjusted(-6, -6, 6, 6)
            # dentro l'area di scorrimento: solo la parte visibile
            area = next((p for p in _antenati(bersaglio, self.dialog)
                         if isinstance(p, QScrollArea)), None)
            if area is not None:
                vp = area.viewport()
                r = r.intersected(QRect(vp.mapTo(self.dialog, QPoint(0, 0)), vp.size()))
            self._buco = r.intersected(self.rect())
        else:
            self._buco = QRect()
        self.fumetto.adjustSize()
        fw, fh = self.fumetto.width(), self.fumetto.height()
        W, H = self.width(), self.height()
        if self._buco.isNull() or self._buco.isEmpty():
            x, y = (W - fw) // 2, (H - fh) // 2
        else:
            b = self._buco
            # a destra dell'elemento se c'è posto, poi sotto, poi sopra
            if b.right() + 16 + fw <= W:
                x, y = b.right() + 16, b.top()
            elif b.bottom() + 16 + fh <= H:
                x, y = b.left(), b.bottom() + 16
            elif b.top() - 16 - fh >= 0:
                x, y = b.left(), b.top() - 16 - fh
            else:
                x, y = W - fw - 16, H - fh - 16
            x = max(8, min(x, W - fw - 8))
            y = max(8, min(y, H - fh - 8))
        self.fumetto.move(x, y)
        self.update()

    def paintEvent(self, _ev):
        from qgis.PyQt.QtGui import QRegion
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing, True)
        ha_buco = not self._buco.isNull() and not self._buco.isEmpty()
        zona = QRegion(self.rect())
        if ha_buco:
            zona = zona.subtracted(QRegion(self._buco))
        p.setClipRegion(zona)
        p.fillRect(self.rect(), QColor(3, 27, 82, 140))
        p.setClipping(False)
        if ha_buco:
            p.setPen(QPen(QColor(ARANCIO), 3))
            p.drawRoundedRect(self._buco, 8, 8)
        p.end()

    def mousePressEvent(self, ev):
        # clic fuori dal fumetto: niente (il velo blocca la finestra), il
        # tutorial si guida con i pulsanti o la tastiera
        ev.accept()


def avvia_tutorial(dialog):
    vecchio = getattr(dialog, "_tutorial", None)
    if vecchio is not None:
        try:
            vecchio.chiudi()
        except Exception:  # noqa: BLE001
            pass
    t = Tutorial(dialog)
    dialog._tutorial = t
    t.avvia()
    return t


# le schede istanze hanno gli stessi 6 passi: i passi 5 e 6 sono uguali ovunque
for _k in ("Istanze Strade", "Istanze RFI", "Istanze Acque", "Istanze Soprintendenza",
           "Istanze Parchi / Natura 2000"):
    if _k in INTRO:
        INTRO[_k] += (" Al passo 5 «Calcola numero di tavole» disegna in mappa i riquadri "
                      "delle tavole (cancellane o spostane uno e la stampa lo segue); poi foto, "
                      "sezioni e, se serve, «Modifica etichette in mappa» (le trascini con "
                      "«Sposta elemento»; ripremendo il pulsante si salvano). Al passo 6 «Anteprima di "
                      "stampa» per vedere PL (nel layout di QGIS o con «Anteprima veloce», senza PDF) e relazione "
                      "e «Genera le istanze». "
                      "Il lavoro della scheda si salva con il progetto e si riprende quando lo riapri; "
                      "se non ci riesce compare un avviso giallo con il motivo.")
