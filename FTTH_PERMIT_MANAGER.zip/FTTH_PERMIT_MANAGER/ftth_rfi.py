# -*- coding: utf-8 -*-
"""
ftth_rfi.py — Istanze di attraversamento/parallelismo ferroviario (RFI e
gestori in concessione: FS Ferrovie Sud Est, FER, ...).

LOGICA PURA: nessun import qgis/PyQt. Le geometrie arrivano come shapely in
EPSG:4326 (le prepara la scheda QGIS), i documenti si compilano con
python-docx. Testabile headless. (c) Beexact S.r.l.

Flusso:
    interf = trova_interferenze(linee, tratte, pozzetti, cippi, stazioni)
    # ... l'utente conferma/corregge tipologia, km, linea, stazione ...
    istanze = raggruppa_istanze(interf, gestori)
    for ist in istanze:
        genera_documenti_istanza(ist, comune, cartella_template, cartella_out)

Regole (documento "Elenco documenti per presentazione nuova istanza"):
  - TIPOLOGIA A: attraversamento con riutilizzo di infrastrutture esistenti
                 (+ Allegato J e esito ente terzo; nessun sopralluogo)
  - TIPOLOGIA B: attraversamento con nuova infrastruttura in sottovia o sopra
                 galleria (+ verbale di sopralluogo congiunto)
  - TIPOLOGIA C: attraversamento in No-Dig (+ verbale di sopralluogo)
  - TIPOLOGIA D: parallelismo con nuova infrastruttura interrata tra 6 e 30 m
                 (nessun sopralluogo)
  Una istanza per ogni combinazione tipologia / gestore / linea / stazione.
"""
from __future__ import annotations

import copy
import datetime
import math
import os
import re
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# RESE DI SCAVO (metri/giorno) — default modificabili per progetto.
# ---------------------------------------------------------------------------
RESE_DEFAULT = {
    "microtrincea": 150.0,   # stima
    "nodig":         30.0,   # stima (tratta corta, buche lancio/arrivo)
    "trincea":       50.0,   # verificata
    "minitrincea":  130.0,   # verificata
}

# Posa pozzetti: pezzi al giorno per squadra (scavo buca, posa elementi
# prefabbricati, rinfianco in cls, chiusino in quota). Stime.
RESE_POZZETTI = {
    "125x80": 2.0,
    "90x70":  3.0,
    "76x40":  4.0,
    "45x15":  6.0,
    "40x15":  6.0,
}
RESA_POZZETTI_ALTRI = 3.0

# Ripristini: ripristino definitivo del manto (fresatura, binder/tappetino,
# sigillatura) in metri al giorno per tecnica; per il no-dig si ripristinano
# solo le buche di lancio e arrivo (mezza giornata per tratta). Stime.
RESE_RIPRISTINO = {
    "microtrincea": 300.0,
    "minitrincea":  250.0,
    "trincea":      120.0,
}
GIORNI_RIPRISTINO_NODIG = 0.5
# ripristino attorno al chiusino (anello in cls + manto), pozzetti al giorno
RESA_RIPRISTINO_POZZETTI = 8.0

# Ordine colonne tabelle (come nei template reali)
TECNICHE = ["microtrincea", "nodig", "trincea", "minitrincea"]
ETICH_TECNICA = {
    "microtrincea": "Microtrincea",
    "nodig":        "No Dig",
    "trincea":      "Trincea",
    "minitrincea":  "Minitrincea",
}
# come compaiono nell'oggetto del Modello B ("mediante nuovo scavo mini-trincea, ...")
LAVORAZIONE_TECNICA = {
    "minitrincea":  "nuovo scavo mini-trincea",
    "microtrincea": "nuovo scavo micro-trincea",
    "trincea":      "nuovo scavo trincea",
    "nodig":        "perforazione No-Dig",
}

# Mappa valori campo TIPOLOGIA (layer 03 INFRASTRUTTURE) -> tecnica interna
MAP_TIPOLOGIA = {
    "tradizionale": "trincea",
    "trincea": "trincea",
    "mini trincea": "minitrincea",
    "minitrincea": "minitrincea",
    "no dig": "nodig",
    "nodig": "nodig",
    "no-dig": "nodig",
    "microtrincea": "microtrincea",
    "micro trincea": "microtrincea",
    # 'aerea' e '' -> escluse (non sono scavi)
}

KM_DA_VERIFICARE = "km da verificare"
KM_SEGNAPOSTO = "XXX+XXX"     # nei documenti, al posto di un km non stimato

FASCIA_M = 30.0               # fascia di rispetto ferroviaria (DPR 753/1980)
FASCIA_PROPRIETA_M = 6.0      # sotto i 6 m si e' di norma in proprieta' ferroviaria
TOLL_CLUSTER_M = 15.0         # pezzi di scavo piu' vicini di cosi' = stessa interferenza
RAGGIO_STAZIONE_M = 5000.0    # oltre questa distanza nessuna stazione di riferimento


PROVINCE_SIGLA = {
    "agrigento": "AG", "alessandria": "AL", "ancona": "AN", "aosta": "AO", "valle d'aosta": "AO",
    "ascoli piceno": "AP", "l'aquila": "AQ", "arezzo": "AR", "asti": "AT", "avellino": "AV",
    "bari": "BA", "bergamo": "BG", "biella": "BI", "belluno": "BL", "benevento": "BN",
    "bologna": "BO", "brindisi": "BR", "brescia": "BS", "barletta-andria-trani": "BT",
    "bolzano": "BZ", "alto adige": "BZ", "cagliari": "CA", "campobasso": "CB", "caserta": "CE",
    "chieti": "CH", "caltanissetta": "CL", "cuneo": "CN", "como": "CO", "cremona": "CR",
    "cosenza": "CS", "catania": "CT", "catanzaro": "CZ", "enna": "EN", "forlì-cesena": "FC",
    "forli-cesena": "FC", "ferrara": "FE", "foggia": "FG", "firenze": "FI", "fermo": "FM",
    "frosinone": "FR", "genova": "GE", "gorizia": "GO", "grosseto": "GR", "imperia": "IM",
    "isernia": "IS", "crotone": "KR", "lecco": "LC", "lecce": "LE", "livorno": "LI", "lodi": "LO",
    "latina": "LT", "lucca": "LU", "monza e della brianza": "MB", "monza e brianza": "MB",
    "macerata": "MC", "messina": "ME", "milano": "MI", "mantova": "MN", "modena": "MO",
    "massa-carrara": "MS", "massa e carrara": "MS", "matera": "MT", "napoli": "NA",
    "novara": "NO", "nuoro": "NU", "oristano": "OR", "palermo": "PA", "piacenza": "PC",
    "padova": "PD", "pescara": "PE", "perugia": "PG", "pisa": "PI", "pordenone": "PN",
    "prato": "PO", "parma": "PR", "pistoia": "PT", "pesaro e urbino": "PU", "pavia": "PV",
    "potenza": "PZ", "ravenna": "RA", "reggio calabria": "RC", "reggio di calabria": "RC",
    "reggio emilia": "RE", "reggio nell'emilia": "RE", "ragusa": "RG", "rieti": "RI",
    "roma": "RM", "rimini": "RN", "rovigo": "RO", "salerno": "SA", "siena": "SI",
    "sondrio": "SO", "la spezia": "SP", "siracusa": "SR", "sassari": "SS", "sud sardegna": "SU",
    "savona": "SV", "taranto": "TA", "teramo": "TE", "trento": "TN", "trentino": "TN",
    "torino": "TO", "trapani": "TP", "terni": "TR", "trieste": "TS", "treviso": "TV",
    "udine": "UD", "varese": "VA", "verbano-cusio-ossola": "VB", "vercelli": "VC",
    "venezia": "VE", "vicenza": "VI", "verona": "VR", "viterbo": "VT", "vibo valentia": "VV",
}


def sigla_provincia(nome: str) -> str:
    """'Salerno' / 'Città Metropolitana di Napoli' / 'SA' -> sigla; '' se ignota."""
    s = (nome or "").strip()
    if len(s) == 2 and s.isalpha():
        return s.upper()
    n = s.lower()
    for pref in ("città metropolitana di ", "citta metropolitana di ", "provincia di ",
                 "provincia autonoma di ", "libero consorzio comunale di ",
                 "provincia del ", "provincia della "):
        if n.startswith(pref):
            n = n[len(pref):]
    n = n.split(" - ")[0].split("/")[0].strip()
    return PROVINCE_SIGLA.get(n, "")


def mappa_tecnica(valore_tipologia: str) -> Optional[str]:
    """Converte il valore del campo TIPOLOGIA nella tecnica interna, o None
    se non e' uno scavo (aerea/vuoto/sconosciuto)."""
    if not valore_tipologia:
        return None
    return MAP_TIPOLOGIA.get(str(valore_tipologia).strip().lower())


# ---------------------------------------------------------------------------
# Tipologie di interferenza: testi che cambiano nei documenti
# ---------------------------------------------------------------------------
TIPOLOGIE = {
    "A": {
        "titolo": "TIPOLOGIA A – Attraversamenti con riutilizzo di infrastrutture esistenti",
        "breve": "Attraversamento con riutilizzo di infrastruttura esistente",
        "descr": "in attraversamento con riutilizzo di infrastrutture esistenti",
        "tabella": "— nessuno: riutilizzo di infrastrutture esistenti in attraversamento "
                   "(metri dell'infrastruttura riutilizzata)",
        "lavori": "attraversamento con riutilizzo di infrastrutture esistenti della",
        "bollo": "l'attraversamento con riutilizzo di infrastrutture esistenti della",
        "cartiglio": "INTERFERENZE TIPO A - ATTRAVERSAMENTO CON RIUTILIZZO",
        "sopralluogo": False,
        "allegati": [
            "• Allegato J – Schema 1 di comunicazione interferenze tipo A "
            "(riutilizzo per ENEL, TIM o ente terzo)",
            "• Esito dell'ente terzo proprietario dell'infrastruttura, con evidenziata "
            "la tratta di interesse",
        ],
        "promemoria": [
            "Prima dell'istanza verificare con l'ente proprietario (ENEL, TIM, ...) "
            "l'esistenza di regolare convenzione ente terzo/RFI.",
            "Allegare l'Allegato J compilato (parti in giallo secondo il riutilizzo) e "
            "l'esito dell'ente terzo con screenshot della tratta.",
            "Non serve il sopralluogo preliminare congiunto.",
        ],
    },
    "B": {
        "titolo": "TIPOLOGIA B – Attraversamento con realizzazione di nuova infrastruttura "
                  "in SOTTOVIA o SOPRA GALLERIA ferroviaria",
        "breve": "Attraversamento in sottovia o sopra galleria",
        "descr": "in attraversamento in sottovia o sopra galleria ferroviaria",
        "tabella": "in attraversamento (sottovia o sopra galleria)",
        "lavori": "attraversamento in sottovia o sopra galleria della",
        "bollo": "l'attraversamento in sottovia o sopra galleria della",
        "cartiglio": "INTERFERENZE TIPO B - ATTRAVERSAMENTO SOTTOVIA/SOPRA GALLERIA",
        "sopralluogo": True,
        "allegati": ["• Verbale di sopralluogo preliminare congiunto"],
        "promemoria": [
            "PRIMA dell'invio della PEC concordare con il gestore il sopralluogo "
            "preliminare in campo e redigere il verbale.",
        ],
    },
    "C": {
        "titolo": "TIPOLOGIA C – Attraversamento in NO-DIG",
        "breve": "Attraversamento in No-Dig",
        "descr": "in attraversamento in No-Dig",
        "tabella": "in attraversamento No-Dig",
        "lavori": "attraversamento in No-Dig della",
        "bollo": "l'attraversamento in No-Dig della",
        "cartiglio": "INTERFERENZE TIPO C - ATTRAVERSAMENTO NO-DIG",
        "sopralluogo": True,
        "allegati": ["• Verbale di sopralluogo preliminare congiunto"],
        "promemoria": [
            "PRIMA dell'invio della PEC concordare con il gestore il sopralluogo "
            "preliminare in campo e redigere il verbale.",
        ],
    },
    "D": {
        "titolo": "TIPOLOGIA D – Parallelismo con realizzazione di nuova infrastruttura "
                  "interrata all’esterno della proprietà RFI (tra i 6 e i 30m)",
        "breve": "Parallelismo",
        "descr": "in parallelismo e fascia di rispetto 6-30m",
        "tabella": "in fascia di rispetto 6m / 30m",
        "lavori": "scavo in parallelismo della",
        "bollo": "il parallelismo della",
        "cartiglio": "INTERFERENZE TIPO D - PARALLELISMO",
        "sopralluogo": False,
        "allegati": [],
        "promemoria": ["Non serve il sopralluogo preliminare congiunto."],
    },
}


def classifica_tipologia(attraversa: bool, stato: str, tecnica: Optional[str],
                         dist_min_m: Optional[float] = None):
    """Tipologia proposta per una interferenza. Ritorna (tipologia, note).
    tipologia None = nessuna istanza (riutilizzo esistente in parallelo);
    '?' = da decidere a mano (es. tratta aerea che attraversa)."""
    esistente = (stato or "").strip().lower() == "esistente"
    note = []
    if attraversa:
        if esistente:
            return "A", note
        if tecnica == "nodig":
            return "C", note
        if tecnica is None:
            note.append("tratta senza scavo (aerea?) che attraversa la ferrovia: "
                        "scegliere la tipologia a mano")
            return "?", note
        note.append("attraversamento con scavo: verificare che avvenga in sottovia "
                    "o sopra galleria")
        return "B", note
    if esistente:
        # riutilizzo in parallelo su proprieta' di terzi: nessuna istanza
        return None, ["riutilizzo esistente in parallelo: nessuna istanza (verificare "
                      "se in proprieta' del gestore)"]
    if tecnica is None:
        return None, ["tratta senza scavo in fascia: nessuna istanza"]
    if dist_min_m is not None and dist_min_m < FASCIA_PROPRIETA_M:
        note.append("scavo a %.1f m dalla rotaia, entro i 6 m: probabile proprieta' del "
                    "gestore, verificare convenzione come per la tipologia A" % dist_min_m)
    return "D", note


# ---------------------------------------------------------------------------
# Gestori ferroviari e destinatari
# ---------------------------------------------------------------------------
@dataclass
class Gestore:
    chiave: str
    nome: str                 # come compare nei testi (es. "FS Ferrovie Sud Est")
    sigla: str                # nei nomi dei file (es. "FS FERROVIE SUD EST")
    rfi: bool = False
    dest_nome: str = ""       # prima riga del destinatario
    dest_indirizzo: str = ""
    dest_pec: str = ""
    fonte: str = ""

    def destinatario_completo(self) -> bool:
        return bool(self.dest_nome and self.dest_pec)


def _kb_gestori(kb: dict) -> list:
    return (kb or {}).get("gestori_ferroviari") or []


def riconosci_gestore(operator: str, nome_linea: str, kb: dict) -> Gestore:
    """Gestore dalla kb in base ai tag OSM operator/name. Se nessuna voce
    combacia ritorna un gestore 'altro' col nome dell'operatore e senza
    destinatario (da compilare a mano nella scheda)."""
    testo = " ".join(x for x in (operator or "", nome_linea or "") if x).lower()
    for g in _kb_gestori(kb):
        for pat in g.get("match") or []:
            if re.search(pat, testo, re.I):
                d = g.get("destinatario") or {}
                return Gestore(chiave=g["chiave"], nome=g.get("nome", g["chiave"]),
                               sigla=g.get("sigla", g["chiave"].upper()),
                               rfi=bool(g.get("rfi")), dest_nome=d.get("nome", ""),
                               dest_indirizzo=d.get("indirizzo", ""),
                               dest_pec=d.get("pec", ""), fonte=g.get("fonte", ""))
    nome = (operator or "").strip() or "Gestore da individuare"
    chiave = "altro_" + re.sub(r"[^a-z0-9]+", "_", nome.lower()).strip("_")
    return Gestore(chiave=chiave, nome=nome, sigla=nome.upper()[:30])


def destinatario_rfi(gestore: Gestore, doit_citta: str, doit_indirizzo: str = "",
                     doit_pec: str = "") -> Gestore:
    """Completa il destinatario di un gestore RFI con la DOIT competente."""
    g = copy.copy(gestore)
    if doit_citta:
        g.dest_nome = "RFI - Direzione Operativa Infrastrutture Territoriale di %s" % doit_citta.upper()
    g.dest_indirizzo = doit_indirizzo or g.dest_indirizzo
    g.dest_pec = doit_pec or g.dest_pec
    return g


# ---------------------------------------------------------------------------
# Modello dati
# ---------------------------------------------------------------------------
@dataclass
class Tratta:
    """Riga delle tabelle della relazione: metri per tecnica e pozzetti."""
    km_da: str
    km_a: str
    metri: dict = field(default_factory=dict)    # {tecnica: metri}
    pozzetti: dict = field(default_factory=dict)  # {dimensione: n}
    etichetta: str = ""
    # righe della tabella pozzetti: [(etichetta "Al km X", {dim: n})], una per km
    righe_pozzetti: list = field(default_factory=list)

    def totale_metri(self) -> float:
        return sum(self.metri.get(t, 0.0) for t in TECNICHE)

    def descrizione(self, forma="dal") -> str:
        if self.etichetta:
            return self.etichetta
        return etichetta_km(self.km_da, self.km_a)


def _km_testo(km: str) -> str:
    return KM_SEGNAPOSTO if (not km or km == KM_DA_VERIFICARE) else km


def etichetta_km(km_da: str, km_a: str) -> str:
    """'Al km X' per un punto, 'Da km X al km Y' per un tratto."""
    a, b = _km_testo(km_da), _km_testo(km_a)
    if not km_a or a == b:
        return "Al km %s" % a
    return "Da km %s al km %s" % (a, b)


@dataclass
class Interferenza:
    id: int
    tipologia: Optional[str]          # A/B/C/D, '?' da decidere, None = nessuna istanza
    linea: str                        # nome linea come va nei documenti
    gestore: str                      # chiave gestore
    stazione: str = ""
    km_da: str = ""
    km_a: str = ""
    metri: dict = field(default_factory=dict)
    pozzetti: dict = field(default_factory=dict)
    lon: float = 0.0
    lat: float = 0.0
    dist_min_m: Optional[float] = None
    attraversa: bool = False
    note: list = field(default_factory=list)
    includi: bool = True
    foto: str = ""                    # percorso foto per la tavola (facoltativo)
    proprietario: str = ""            # tipologia A: ENEL / TIM / ente terzo
    bbox: tuple = ()                  # (minx, miny, maxx, maxy) WGS84 per le tavole
    # pozzetti e armadi nuovi in fascia, per le etichette della planimetria:
    # [{'tipo': 'pozzetto'|'armadio', 'dim': str, 'lon', 'lat', 'km': str}]
    elementi: list = field(default_factory=list)
    # id (fid QGIS) delle tratte di 03 INFRASTRUTTURE che formano l'interferenza:
    # la planimetria mostra solo queste
    tratte_fid: list = field(default_factory=list)

    def tratta(self) -> Tratta:
        # tabella pozzetti: una riga per km di posa (come nelle pratiche:
        # "AL KM 74+813"); senza i singoli pozzetti, una riga con i km del tratto
        per_km = {}
        for e in self.elementi:
            if e.get("tipo") == "pozzetto" and e.get("dim"):
                k = e.get("km") or ""
                per_km.setdefault(k, {})
                per_km[k][e["dim"]] = per_km[k].get(e["dim"], 0) + 1
        if per_km:
            righe = [(etichetta_km(k, k), d) for k, d in
                     sorted(per_km.items(), key=lambda kv: km_valore(kv[0]) or 0)]
        elif self.pozzetti:
            righe = [(etichetta_km(self.km_da, self.km_a), dict(self.pozzetti))]
        else:
            righe = []
        return Tratta(self.km_da, self.km_a, dict(self.metri), dict(self.pozzetti),
                      etichetta_km(self.km_da, self.km_a), righe)

    def totale_metri(self) -> float:
        return sum(self.metri.values())


@dataclass
class Istanza:
    numero: int
    tipologia: str
    gestore: Gestore
    linea: str
    stazione: str
    interferenze: list = field(default_factory=list)
    nome_base: str = ""               # es. "ANDRANO_FS FERROVIE SUD EST_TipoD"

    def tratte(self) -> list:
        return [i.tratta() for i in self.interferenze]

    def km_estremi(self):
        """(km_da, km_a) minimo e massimo fra le interferenze stimate."""
        kms = []
        for i in self.interferenze:
            for k in (i.km_da, i.km_a):
                v = km_valore(k)
                if v is not None:
                    kms.append((v, k))
        if not kms:
            return "", ""
        kms.sort()
        return kms[0][1], kms[-1][1]


def km_valore(km: str) -> Optional[int]:
    """'29+417' -> 29417 metri; None se non interpretabile."""
    m = re.match(r"^\s*(\d+)\+(\d{1,3})\s*$", str(km or ""))
    if not m:
        return None
    return int(m.group(1)) * 1000 + int(m.group(2))


# ---------------------------------------------------------------------------
# Cronoprogramma
# ---------------------------------------------------------------------------
def arrotonda_mezzo_sup(x: float) -> float:
    """Arrotonda al mezzo giorno superiore (0.1 -> 0.5, 0.6 -> 1.0)."""
    if x <= 0:
        return 0.0
    return math.ceil(x * 2) / 2.0


def giorni_per_tecnica(tratte: list, rese: Optional[dict] = None):
    """({tecnica: giorni}, totale) sommando i metri di tutte le tratte."""
    rese = rese or RESE_DEFAULT
    tot = {t: 0.0 for t in TECNICHE}
    for tr in tratte:
        for t in TECNICHE:
            tot[t] += tr.metri.get(t, 0.0)
    giorni = {t: (arrotonda_mezzo_sup(tot[t] / rese[t]) if tot[t] > 0 else 0.0)
              for t in TECNICHE}
    somma = sum(giorni.values())
    return giorni, (math.ceil(somma) if somma > 0 else 0)


# ---------------------------------------------------------------------------
# Stima chilometrica ferroviaria da cippi km (OSM railway=milestone)
# ---------------------------------------------------------------------------
def _dist_m(lat1, lon1, lat2, lon2):
    """Distanza approssimata in metri tra due punti lat/lon (equirettangolare)."""
    R = 6371000.0
    x = math.radians(lon2 - lon1) * math.cos(math.radians((lat1 + lat2) / 2))
    y = math.radians(lat2 - lat1)
    return math.sqrt(x * x + y * y) * R


def _fmt_progressiva(km_float: float) -> str:
    """99.731 km -> '99+731'. Input in KM (float)."""
    km_int = int(km_float)
    metri = int(round((km_float - km_int) * 1000))
    if metri == 1000:
        km_int += 1
        metri = 0
    return f"{km_int}+{metri:03d}"


def stima_progressiva(lat: float, lon: float, cippi: list) -> str:
    """Stima la progressiva chilometrica di un punto dai cippi km.
    cippi = lista di dict {'km': float, 'lat': float, 'lon': float}.
    Interpola fra i due cippi piu' vicini se sono consecutivi (gap <= 1,5 km),
    altrimenti ritorna KM_DA_VERIFICARE."""
    if not cippi or len(cippi) < 2:
        return KM_DA_VERIFICARE
    cin = sorted(cippi, key=lambda c: _dist_m(lat, lon, c["lat"], c["lon"]))
    a, b = cin[0], cin[1]
    d_ab = _dist_m(a["lat"], a["lon"], b["lat"], b["lon"])
    if d_ab == 0:
        return _fmt_progressiva(a["km"])
    if abs(a["km"] - b["km"]) > 1.5:
        return KM_DA_VERIFICARE
    if _dist_m(lat, lon, a["lat"], a["lon"]) > 3000:
        return KM_DA_VERIFICARE

    def to_xy(la, lo):
        x = math.radians(lo - a["lon"]) * math.cos(math.radians(a["lat"])) * 6371000.0
        y = math.radians(la - a["lat"]) * 6371000.0
        return x, y
    px, py = to_xy(lat, lon)
    bx, by = to_xy(b["lat"], b["lon"])
    denom = bx * bx + by * by
    if denom == 0:
        return KM_DA_VERIFICARE
    t = (px * bx + py * by) / denom
    t = max(0.0, min(1.0, t))
    km = a["km"] + (b["km"] - a["km"]) * t
    return _fmt_progressiva(km)


# ---------------------------------------------------------------------------
# Ricerca delle interferenze (shapely, EPSG:4326 in ingresso)
# ---------------------------------------------------------------------------
class _Proiezione:
    """Equirettangolare locale: metri attorno a un'origine. Sui pochi km di un
    comune l'errore e' trascurabile rispetto alla precisione dei dati OSM."""

    def __init__(self, lon0, lat0):
        self.lon0, self.lat0 = lon0, lat0
        self.kx = 111320.0 * math.cos(math.radians(lat0))
        self.ky = 110540.0

    def avanti(self, g):
        from shapely.ops import transform
        return transform(lambda x, y, z=None: ((x - self.lon0) * self.kx,
                                               (y - self.lat0) * self.ky), g)

    def indietro(self, g):
        from shapely.ops import transform
        return transform(lambda x, y, z=None: (x / self.kx + self.lon0,
                                               y / self.ky + self.lat0), g)


def nome_linea_osm(tags: dict) -> str:
    """Nome della linea da mettere nei documenti, dai tag OSM della way."""
    nome = (tags.get("name") or "").strip()
    ref = (tags.get("ref") or "").strip()
    if nome and ref and ref not in nome:
        return "Linea %s %s" % (ref, nome)
    if nome:
        return nome
    if ref:
        return "Linea %s" % ref
    return "Linea ferroviaria"


def _solo_linee(g):
    from shapely.geometry import MultiLineString
    if g is None or g.is_empty:
        return None
    if g.geom_type in ("LineString", "MultiLineString"):
        return g
    parti = []
    for p in getattr(g, "geoms", []):
        if p.geom_type == "LineString":
            parti.append(p)
        elif p.geom_type == "MultiLineString":
            parti.extend(p.geoms)
    return MultiLineString(parti) if parti else None


def _estremi(g):
    """Punti estremi di una (multi)linea."""
    pts = []
    for p in getattr(g, "geoms", [g]):
        cs = list(p.coords)
        if cs:
            pts += [cs[0], cs[-1]]
    return pts


def trova_interferenze(linee: list, tratte: list, pozzetti: list = None,
                       cippi: list = None, stazioni: list = None, kb: dict = None,
                       fascia_m: float = FASCIA_M, armadi: list = None) -> list:
    """Interferenze fra la rete di progetto e le linee ferroviarie.

    linee:    [{'geom': LineString, 'tags': {name, ref, operator, ...}}]
    tratte:   [{'geom': (Multi)LineString, 'stato': 'Nuovo'|'Esistente',
                'tecnica': interna o None, 'proprietario': str}]
    pozzetti: [{'geom': Point, 'stato': str, 'dim': '76x40'}]
    cippi:    [{'km': float, 'lat', 'lon'}]
    stazioni: [{'geom': Point, 'nome': str}]
    Tutte le geometrie in EPSG:4326. Ritorna una lista di Interferenza."""
    from shapely.geometry import Point
    from shapely.ops import unary_union

    pozzetti = pozzetti or []
    cippi = cippi or []
    stazioni = stazioni or []
    if not linee or not tratte:
        return []
    c = unary_union([l["geom"] for l in linee]).centroid
    pr = _Proiezione(c.x, c.y)

    # linee raggruppate per (gestore, nome): i binari paralleli di una linea
    # sono way distinte in OSM ma sono la stessa interferenza
    gruppi = {}
    for l in linee:
        tags = l.get("tags") or {}
        nome = nome_linea_osm(tags)
        g = riconosci_gestore(tags.get("operator", ""), tags.get("name", ""), kb or {})
        k = (g.chiave, nome)
        gruppi.setdefault(k, {"gestore": g, "nome": nome, "geoms": []})
        gruppi[k]["geoms"].append(pr.avanti(l["geom"]))

    tr_m = []
    for k, t in enumerate(tratte):
        g = t.get("geom")
        if g is None or g.is_empty:
            continue
        tr_m.append(dict(t, gm=pr.avanti(g), _k=k))

    risultati = []
    nid = 1
    # una tratta che entra in fascia si computa INTERA (lo scavo e' continuo,
    # anche la parte fuori fascia) e una volta sola, anche se esce e rientra
    contate = set()
    geom_interf = {}     # id interferenza -> geometria intera delle sue tratte (metri)
    for (_, nome), gr in gruppi.items():
        asse = unary_union(gr["geoms"])
        fascia = asse.buffer(fascia_m)
        attraversamenti = []    # [{'punto', 'pezzi': [(tratta, pezzo)]}]
        paralleli = []          # [(tratta, pezzo)]
        for t in tr_m:
            gm = t["gm"]
            if not gm.intersects(fascia):
                continue
            pezzo = _solo_linee(gm.intersection(fascia))
            if pezzo is None or pezzo.length < 0.5:
                continue
            if gm.intersects(asse):
                punto = gm.intersection(asse).centroid
                for a in attraversamenti:
                    if a["punto"].distance(punto) <= TOLL_CLUSTER_M:
                        a["pezzi"].append((t, pezzo))
                        break
                else:
                    attraversamenti.append({"punto": punto, "pezzi": [(t, pezzo)]})
            else:
                paralleli.append((t, pezzo))

        def _metri(pezzi):
            """Metri per tecnica della SOLA parte in fascia (computo metrico e
            cronoprogramma). La parte fuori fascia si disegna in tavola come
            'non di competenza' ma non si conta. Se la tratta ha il campo
            LUNGHEZZA, la parte in fascia e' proporzionata a quel valore."""
            m = {}
            for t, p in pezzi:
                if (t["_k"], round(p.length, 2)) in contate:
                    continue
                contate.add((t["_k"], round(p.length, 2)))
                tec = t.get("tecnica")
                if tec:
                    L = p.length
                    if t.get("lunghezza") and t["gm"].length > 0:
                        L = L * float(t["lunghezza"]) / t["gm"].length
                    m[tec] = m.get(tec, 0.0) + L
            # metri a cifra tonda (tavola, computo e cronoprogramma usano
            # questi stessi valori, quindi i totali tornano); un pezzetto
            # sotto il mezzo metro conta comunque 1 m
            # mezzo metro si arrotonda per eccesso (104,5 -> 105)
            return {k: max(1, int(v + 0.5)) for k, v in m.items() if v > 0}

        def _segni_tratte(pezzi):
            """Per la tavola: km dove ogni tratta entra/esce dalla fascia e la
            scritta NON DI COMPETENZA sui tratti fuori fascia."""
            out, visti = [], set()
            for t, _p in pezzi:
                if t["_k"] in visti:
                    continue
                visti.add(t["_k"])
                gm = t["gm"]
                # etichetta dello scavo di QUESTA tratta (scavi diversi =
                # etichette diverse), a meta' del suo pezzo in fascia piu' lungo
                miei = [p for tt, p in pezzi if tt["_k"] == t["_k"]]
                if t.get("tecnica") and miei:
                    L = sum(p.length for p in miei)
                    if t.get("lunghezza") and gm.length > 0:
                        L = L * float(t["lunghezza"]) / gm.length
                    parti = [q for p in miei for q in getattr(p, "geoms", [p])]
                    lungo = max(parti, key=lambda q: q.length)
                    w = pr.indietro(lungo.interpolate(0.5, normalized=True))
                    out.append({"tipo": "scavo", "tecnica": t["tecnica"],
                                "metri": max(1, int(L + 0.5)), "lon": w.x, "lat": w.y,
                                "km": stima_progressiva(w.y, w.x, cippi),
                                "fid": t.get("fid")})
                bordo = gm.intersection(fascia.boundary)
                punti = [g for g in getattr(bordo, "geoms", [bordo])
                         if not g.is_empty and g.geom_type == "Point"]
                for q in punti:
                    w = pr.indietro(q)
                    out.append({"tipo": "ingresso", "lon": w.x, "lat": w.y,
                                "km": stima_progressiva(w.y, w.x, cippi)})
                fuori = _solo_linee(gm.difference(fascia))
                for parte in getattr(fuori, "geoms", [fuori]) if fuori is not None else []:
                    if parte.length >= 3:
                        w = pr.indietro(parte.interpolate(0.5, normalized=True))
                        out.append({"tipo": "fuori", "lon": w.x, "lat": w.y, "km": ""})
            return out

        def _nuova(tip, note, pezzi, geom_rif, attraversa, dist=None, proprietario=""):
            nonlocal nid
            if attraversa:
                cen = pr.indietro(geom_rif).centroid
            else:
                # punto SULLA linea di scavo (meta' del tratto in fascia piu'
                # lungo): li' si aggancia l'etichetta dello scavo in tavola
                lungo = max((p for _, p in pezzi), key=lambda p: p.length)
                parti = list(getattr(lungo, "geoms", [lungo]))
                lungo = max(parti, key=lambda p: p.length)
                cen = pr.indietro(lungo.interpolate(0.5, normalized=True))
            if attraversa:
                km = stima_progressiva(cen.y, cen.x, cippi)
                km_da = km_a = km
            else:
                prog = [stima_progressiva(y, x, cippi) for x, y in _estremi(pr.indietro(
                    unary_union([p for _, p in pezzi])))]
                validi = sorted({p for p in prog if km_valore(p) is not None}, key=km_valore)
                if validi:
                    km_da, km_a = validi[0], validi[-1]
                    if abs(km_valore(km_a) - km_valore(km_da)) < 20:
                        km_a = km_da
                else:
                    km_da = km_a = KM_DA_VERIFICARE
            intere = unary_union([t["gm"] for t, _ in pezzi])
            i = Interferenza(
                id=nid, tipologia=tip, linea=nome, gestore=gr["gestore"].chiave,
                km_da=km_da, km_a=km_a, metri=_metri(pezzi), lon=cen.x, lat=cen.y,
                dist_min_m=dist, attraversa=attraversa, note=list(note),
                proprietario=proprietario,
                bbox=tuple(pr.indietro(intere).bounds),
                tratte_fid=sorted({t.get("fid") for t, _ in pezzi if t.get("fid") is not None}),
                elementi=_segni_tratte(pezzi))
            geom_interf[nid] = intere
            nid += 1
            return i

        # attraversamenti: la tratta che taglia l'asse decide la tipologia
        for a in attraversamenti:
            t0 = max(a["pezzi"], key=lambda tp: tp[1].length)[0]
            a["tip"], a["note"] = classifica_tipologia(True, t0.get("stato"), t0.get("tecnica"))
            a["t0"] = t0
        # gli scavi nuovi in fascia che arrivano a un attraversamento B/C ne sono
        # l'avvicinamento: vanno con l'attraversamento, non in un parallelismo D
        restanti = []
        for t, p in paralleli:
            vicino = None
            if (t.get("stato") or "").strip().lower() != "esistente" and t.get("tecnica"):
                for a in attraversamenti:
                    if a["tip"] in ("B", "C") and any(
                            p.distance(q) <= 1.0 for _, q in a["pezzi"]):
                        vicino = a
                        break
            if vicino is not None:
                vicino["pezzi"].append((t, p))
            else:
                restanti.append((t, p))
        paralleli = restanti
        for a in attraversamenti:
            t0 = a["t0"]
            i = _nuova(a["tip"], a["note"], a["pezzi"], a["punto"], True,
                       proprietario=t0.get("proprietario", ""))
            if i.tipologia == "A" and not i.proprietario:
                i.note.append("indicare il proprietario dell'infrastruttura riutilizzata "
                              "(ENEL, TIM, ente terzo)")
            risultati.append(i)

        # paralleli: pezzi vicini fra loro (scavo continuo) = una interferenza
        nuovi = [(t, p) for t, p in paralleli]
        cluster = []
        for t, p in nuovi:
            dove = [cl for cl in cluster if any(p.distance(q) <= TOLL_CLUSTER_M for _, q in cl)]
            if not dove:
                cluster.append([(t, p)])
            else:
                base = dove[0]
                base.append((t, p))
                for altro in dove[1:]:
                    base.extend(altro)
                    cluster.remove(altro)
        for cl in cluster:
            g_cl = unary_union([p for _, p in cl])
            dist = round(g_cl.distance(asse), 1)
            stati = {(t.get("stato") or "").strip().lower() for t, _ in cl}
            tec = next((t.get("tecnica") for t, _ in cl if t.get("tecnica")), None)
            stato = "esistente" if stati == {"esistente"} else "nuovo"
            tip, note = classifica_tipologia(False, stato, tec, dist)
            if tip is None:
                continue
            # dal cluster tolgo i pezzi esistenti o senza scavo: non vanno in istanza
            cl_nuovi = [(t, p) for t, p in cl
                        if (t.get("stato") or "").strip().lower() != "esistente"
                        and t.get("tecnica")]
            if not cl_nuovi:
                continue
            risultati.append(_nuova(tip, note, cl_nuovi, g_cl, False, dist))

        # pozzetti e armadi nuovi in fascia: all'interferenza piu' vicina di
        # questa linea; ognuno con il proprio km per l'etichetta in tavola
        mie = [i for i in risultati if i.linea == nome and i.gestore == gr["gestore"].chiave]
        if mie:
            punti = [("pozzetto", pz) for pz in pozzetti] + [("armadio", a) for a in (armadi or [])]
            for tipo, pz in punti:
                if (pz.get("stato") or "").strip().lower() == "esistente":
                    continue
                if pz.get("geom") is None or (tipo == "pozzetto" and not pz.get("dim")):
                    continue
                pm = pr.avanti(pz["geom"])
                # in fascia, oppure attaccato a uno scavo che entra in fascia
                # (fa parte dello scavo continuo); il resto non si conta
                attaccata = [i for i in mie if i.id in geom_interf
                             and pm.distance(geom_interf[i.id]) <= 1.0]
                if not pm.within(fascia) and not attaccata:
                    continue
                vicina = min(attaccata or mie, key=lambda i: pm.distance(
                    geom_interf[i.id] if i.id in geom_interf else pr.avanti(Point(i.lon, i.lat))))
                in_fascia = pm.within(fascia)
                # fuori fascia: si disegna (e' sullo scavo continuo) ma non si conta
                if tipo == "pozzetto" and in_fascia:
                    vicina.pozzetti[pz["dim"]] = vicina.pozzetti.get(pz["dim"], 0) + 1
                g = pz["geom"]
                vicina.elementi.append({
                    "tipo": tipo if in_fascia else tipo + "_fuori",
                    "dim": pz.get("dim") or "", "lon": g.x, "lat": g.y,
                    "km": stima_progressiva(g.y, g.x, cippi), "id": pz.get("id") or "",
                    "fid": pz.get("fid")})

    # stazione di riferimento: la piu' vicina entro il raggio
    for i in risultati:
        if not stazioni:
            break
        best = min(stazioni, key=lambda s: _dist_m(i.lat, i.lon, s["geom"].y, s["geom"].x))
        if _dist_m(i.lat, i.lon, best["geom"].y, best["geom"].x) <= RAGGIO_STAZIONE_M:
            i.stazione = best.get("nome") or ""

    risultati.sort(key=lambda i: (i.gestore, i.linea, km_valore(i.km_da) or 0, i.id))
    for n, i in enumerate(risultati, 1):
        i.id = n
    return risultati


# ---------------------------------------------------------------------------
# Raggruppamento in istanze
# ---------------------------------------------------------------------------
def _pulisci_nome(s: str) -> str:
    return re.sub(r'[\\/:*?"<>|]+', "-", (s or "").strip())


def raggruppa_istanze(interferenze: list, gestori: dict, comune: str) -> list:
    """Una istanza per ogni (tipologia, gestore, linea, stazione) fra le
    interferenze incluse con tipologia A/B/C/D. `gestori` = {chiave: Gestore}."""
    gruppi = {}
    for i in interferenze:
        if not i.includi or i.tipologia not in TIPOLOGIE:
            continue
        k = (i.tipologia, i.gestore, i.linea, i.stazione or "")
        gruppi.setdefault(k, []).append(i)
    istanze = []
    for n, (k, lst) in enumerate(sorted(gruppi.items(), key=lambda kv: (kv[0][1], kv[0][2], kv[0][0], kv[0][3])), 1):
        tip, gk, linea, staz = k
        g = gestori.get(gk) or Gestore(chiave=gk, nome=gk, sigla=gk.upper())
        lst.sort(key=lambda i: (km_valore(i.km_da) or 0, i.id))
        istanze.append(Istanza(numero=n, tipologia=tip, gestore=g, linea=linea,
                               stazione=staz, interferenze=lst))
    # nome base dei file: COMUNE_SIGLA_TipoX, con stazione o progressivo se serve
    conta = {}
    for ist in istanze:
        conta[(ist.gestore.sigla, ist.tipologia)] = conta.get((ist.gestore.sigla, ist.tipologia), 0) + 1
    visti = {}
    for ist in istanze:
        base = "%s_%s_Tipo%s" % (comune.upper(), ist.gestore.sigla, ist.tipologia)
        if conta[(ist.gestore.sigla, ist.tipologia)] > 1:
            suff = ist.stazione.upper() if ist.stazione else ""
            visti[(ist.gestore.sigla, ist.tipologia)] = visti.get((ist.gestore.sigla, ist.tipologia), 0) + 1
            n = visti[(ist.gestore.sigla, ist.tipologia)]
            base += "_" + (suff or str(n))
        ist.nome_base = _pulisci_nome(base)
    # nomi ancora uguali (stessa stazione su linee diverse): progressivo
    usati = {}
    for ist in istanze:
        if ist.nome_base in usati:
            usati[ist.nome_base] += 1
            ist.nome_base = "%s_%d" % (ist.nome_base, usati[ist.nome_base])
        else:
            usati[ist.nome_base] = 1
    return istanze


# ---------------------------------------------------------------------------
# Testi dei documenti
# ---------------------------------------------------------------------------
@dataclass
class DatiComune:
    nome: str = ""
    prov_sigla: str = ""
    cap: str = ""
    indirizzo: str = ""
    pec: str = ""


NOMI_FILE = {
    "art49": "1.0_{base}_art.49.docx",
    "pl":    "1.1_{base}_PL.pdf",
    "rt":    "1.2_{base}_RT+CR.docx",
    "bollo": "1.3_{base}_Bollo.docx",
    "modb":  "1.4_{base}_MODELLO B.docx",
}
TEMPLATE_FILES = {
    "art49": "TEMPLATE_1.0_art.49.docx",
    "rt":    "TEMPLATE_1.2_RT+CR.docx",
    "bollo": "TEMPLATE_1.3_Bollo.docx",
    "modb":  "TEMPLATE_1.4_MODELLO B.docx",
}
XXX = "XXXXX"


def lavorazioni(ist: Istanza) -> str:
    """'nuovo scavo mini-trincea, nuovo scavo trincea, posa nuovo pozzetto 76x40'."""
    if ist.tipologia == "A":
        parti = ["riutilizzo di infrastruttura esistente"]
    else:
        parti = []
        tot = {}
        for i in ist.interferenze:
            for t, m in i.metri.items():
                tot[t] = tot.get(t, 0) + m
        for t in ("minitrincea", "microtrincea", "trincea", "nodig"):
            if tot.get(t):
                parti.append(LAVORAZIONE_TECNICA[t])
    pz = {}
    for i in ist.interferenze:
        for d, n in i.pozzetti.items():
            pz[d] = pz.get(d, 0) + n
    for d, n in sorted(pz.items()):
        parti.append("posa nuovo pozzetto %s" % d if n == 1 else
                     "posa n. %d nuovi pozzetti %s" % (n, d))
    return ", ".join(parti) or "posa di infrastruttura in fibra ottica"


def valori_istanza(ist: Istanza, comune: DatiComune, oggi: datetime.date = None) -> dict:
    """{segnaposto: valore} per tutti i modelli di una istanza."""
    oggi = oggi or datetime.date.today()
    tip = TIPOLOGIE[ist.tipologia]
    g = ist.gestore
    km_da, km_a = ist.km_estremi()
    if ist.tipologia == "D" and len(ist.interferenze) == 1:
        km_da, km_a = ist.interferenze[0].km_da, ist.interferenze[0].km_a
    if km_da:
        km_txt = " al km %s" % _km_testo(km_da) if (not km_a or km_a == km_da) else \
            " dal km %s al km %s" % (_km_testo(km_da), _km_testo(km_a))
    else:
        km_txt = " dal km %s al km %s" % (KM_SEGNAPOSTO, KM_SEGNAPOSTO)
    linea_doc = ist.linea if g.rfi else "%s - %s" % (g.nome, ist.linea)
    # "la Linea FS Ferrovie Sud Est - Ferrovia ..." / "la Linea Ferroviaria Milano-Venezia"
    if linea_doc.lower().startswith("linea"):
        linea_pref = linea_doc
    else:
        linea_pref = ("Linea Ferroviaria " if g.rfi else "Linea ") + linea_doc
    linea_km = linea_pref + km_txt
    base = ist.nome_base
    v = {
        "NOME_COMUNE": comune.nome.upper(),
        "PROV_SIGLA": comune.prov_sigla.upper(),
        "CAP": comune.cap,
        "INDIRIZZO_COMUNE": comune.indirizzo or XXX,
        "COMUNE_PEC": comune.pec or XXX,
        "DEST_NOME": g.dest_nome or g.nome,
        "DEST_INDIRIZZO": g.dest_indirizzo or XXX,
        "DEST_PEC": g.dest_pec or XXX,
        "LINEA": ist.linea,
        "KM_DA": _km_testo(km_da),
        "KM_A": _km_testo(km_a or km_da),
        "OGGETTO_LINEA": "la %s." % linea_km,
        "LINEA_KM": linea_km,
        "DESCR_INTERFERENZA": tip["descr"],
        "DESCR_TABELLA": tip["tabella"],
        "LAVORI_SU_LINEA": "%s %s" % (tip["lavori"], linea_km),
        "OGGETTO_BOLLO": "%s %s." % (tip["bollo"], linea_km),
        "OGGETTO_MODB": "%s%s %sdella %s nel Comune di %s mediante %s" % (
            tip["breve"], km_txt,
            "in fascia di rispetto " if ist.tipologia == "D" else "",
            linea_doc if linea_doc.lower().startswith("linea") else "linea " + linea_doc,
            comune.nome.upper(), lavorazioni(ist)),
        "TIPOLOGIA_TITOLO": tip["titolo"],
        "PL_FILE": NOMI_FILE["pl"].format(base=base),
        "RT_FILE": NOMI_FILE["rt"].format(base=base).replace(".docx", ".pdf"),
        "MESE_ANNO": oggi.strftime("%m/%Y"),
        # firmatari: restano da compilare (scelta dell'utente)
        "DATA": "XX/XX/%d" % oggi.year,
        "LUOGO_FIRMA": XXX,
        "PROC_COGNOME": XXX, "PROC_NOME": XXX, "PROC_CF": XXX,
        "PROC_NATO_A": XXX, "PROC_PROV": "XX", "PROC_NATO_IL": "XX/XX/XXXX",
        "PROC_RESIDENZA": XXX, "PROC_VIA": XXX, "PROC_DOC": XXX,
        # compatibilita' con i modelli precedenti
        "DOIT_CITTA": g.dest_nome or g.nome,
        "DOIT_INDIRIZZO": g.dest_indirizzo or XXX,
        "DOIT_PEC": g.dest_pec or XXX,
    }
    return v


# ---------------------------------------------------------------------------
# Sostituzione testo nei .docx (tutti i paragrafi, anche tabelle annidate,
# senza toccare a capo e formattazione dei run)
# ---------------------------------------------------------------------------
def _ns_t():
    from docx.oxml.ns import qn
    return qn("w:t"), qn("w:p")


def _tutti_i_paragrafi(doc):
    """Ogni w:p del documento: corpo (comprese tabelle annidate e caselle di
    testo), intestazioni e pie' di pagina."""
    W_T, W_P = _ns_t()
    els = [doc.element.body]
    for s in doc.sections:
        for hf in (s.header, s.footer, s.first_page_header, s.first_page_footer,
                   s.even_page_header, s.even_page_footer):
            try:
                els.append(hf._element)
            except Exception:  # noqa: BLE001
                pass
    # lista materializzata: gli id() dei proxy lxml vengono riciclati, quindi
    # non si possono usare per scartare i doppioni (salterebbero paragrafi);
    # corpo, intestazioni e pie' di pagina sono comunque alberi distinti
    tutti = []
    for el in els:
        tutti.extend(el.iter(W_P))
    return iter(tutti)


def sostituisci_in_paragrafo(p, vecchio: str, nuovo: str) -> int:
    """Sostituisce `vecchio` con `nuovo` anche quando il testo e' spezzato su
    piu' run: il nuovo testo va nel run dove inizia la corrispondenza, i run
    successivi perdono solo i caratteri sostituiti (a capo e stili restano)."""
    W_T, _ = _ns_t()
    nodi = list(p.iter(W_T))
    if not nodi:
        return 0
    n = 0
    da = 0
    while True:
        testi = [t.text or "" for t in nodi]
        full = "".join(testi)
        i = full.find(vecchio, da)
        if i < 0:
            return n
        f = i + len(vecchio)
        pos = 0
        inizio = fine = None
        for k, tx in enumerate(testi):
            if inizio is None and i < pos + len(tx):
                inizio = (k, i - pos)
            if f <= pos + len(tx):
                fine = (k, f - pos)
                break
            pos += len(tx)
        if inizio is None or fine is None:
            return n
        (ks, os_), (ke, oe) = inizio, fine
        if ks == ke:
            nodi[ks].text = testi[ks][:os_] + nuovo + testi[ks][oe:]
        else:
            nodi[ks].text = testi[ks][:os_] + nuovo
            for k in range(ks + 1, ke):
                nodi[k].text = ""
            nodi[ke].text = testi[ke][oe:]
        for k in (ks, ke):
            nodi[k].set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
        n += 1
        da = i + len(nuovo)


def testo_paragrafo(p) -> str:
    W_T, _ = _ns_t()
    return "".join(t.text or "" for t in p.iter(W_T))


def sostituisci_tutto(doc, valori: dict) -> int:
    """Sostituisce ogni <<CHIAVE>> in tutto il documento."""
    tot = 0
    for p in _tutti_i_paragrafi(doc):
        t = testo_paragrafo(p)
        if "<<" not in t:
            continue
        for k, v in valori.items():
            tag = "<<%s>>" % k
            if tag in t:
                tot += sostituisci_in_paragrafo(p, tag, "" if v is None else str(v))
                t = testo_paragrafo(p)
    return tot


def applica_condizioni(doc, condizioni: dict) -> None:
    """Blocchi condizionali del modello: i paragrafi che iniziano con
    <<SE_XXX>> restano (senza il segnaposto) se condizioni['SE_XXX'] e' vera,
    altrimenti spariscono (es. descrizione di pozzetti o armadi assenti)."""
    for p in list(_tutti_i_paragrafi(doc)):
        t = testo_paragrafo(p)
        for k, v in condizioni.items():
            tag = "<<%s>>" % k
            if tag in t:
                if v:
                    sostituisci_in_paragrafo(p, tag, "")
                else:
                    p.getparent().remove(p)
                break


NOTA_CRONOPROGRAMMA = ("*I giorni indicati comprendono anche i ripristini stradali eseguiti, "
                       "a regola d’arte, sulle superfici interessate dai lavori.")

# sottoparagrafi del capitolo TECNICHE DI SCAVO -> tecnica (None = mai
# presente nei dati: si toglie sempre)
BLOCCHI_TECNICHE = [
    ("MINITRINCEA", "minitrincea"),
    ("MICROTRINCEA", "microtrincea"),
    ("TRINCEA TRADIZIONALE", "trincea"),
    ("PERFORAZIONE NO-DIG", "nodig"),
    ("PERFORAZIONE NO DIG", "nodig"),
    ("CANALA", None),
]


def adatta_relazione(doc, tecniche_presenti, con_pozzetti=True) -> None:
    """Relazione coerente con la planimetria:
    - nel capitolo TECNICHE DI SCAVO restano solo le tecniche usate
      dall'istanza (le stesse dei particolari della PL);
    - senza pozzetti nuovi spariscono anche le frasi generiche sui pozzetti
      (premessa e scelte progettuali; i blocchi POZZETTO CLS / CHIUSINO /
      ARMADIO sono gia' condizionali nel modello);
    - sotto il cronoprogramma niente nota "*Particolari costruttivi allegati"
      (riguarda scavi e pozzetti, non i tempi)."""
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    body = doc.element.body
    if not con_pozzetti:
        for p in list(doc.paragraphs):
            t = p.text.strip().replace("’", "'")
            if t.startswith("Posa di pozzetti") or (
                    t.startswith("Per l'ispezione e la posa dei cavi sono stati previsti")
                    and "pozzett" in t):
                p._p.getparent().remove(p._p)

    # tabelle in linea col testo: nel modello alcune erano "flottanti" e il
    # titolo successivo si affiancava alla tabella ("3." a destra)
    for tb in doc.tables:
        tblpr = tb._tbl.tblPr
        if tblpr is not None:
            fl = tblpr.find(W + "tblpPr")
            if fl is not None:
                tblpr.remove(fl)

    # 1) nota sotto la tabella del cronoprogramma: al posto del rimando ai
    # particolari, l'attestazione che i giorni comprendono i ripristini
    # (giorni_tratta li conta davvero: scavo + posa pozzetti + ripristini)
    if len(doc.tables) > RT_TAB_CRONO:
        el = doc.tables[RT_TAB_CRONO]._tbl.getnext()
        while el is not None and el.tag == W + "p":
            t = "".join(x.text or "" for x in el.iter(W + "t")).strip()
            if t.startswith("*Particolari"):
                ts = list(el.iter(W + "t"))
                ts[0].text = NOTA_CRONOPROGRAMMA
                for x in ts[1:]:
                    x.text = ""
                break
            if t:
                break
            el = el.getnext()

    # 2) blocchi delle tecniche non usate
    pars = list(doc.paragraphs)
    k0 = next((k for k, p in enumerate(pars)
               if "TECNICHE DI SCAVO" in p.text.upper() and p.text.strip().isupper()
               and not p.style.name.lower().startswith("toc")), None)
    if k0 is None:
        return
    k1 = next((k for k in range(k0 + 1, len(pars))
               if re.match(r"^\d+\.\s", pars[k].text.strip()) and pars[k].text.strip().isupper()),
              len(pars))
    attivo, togli = None, []
    for p in pars[k0 + 1:k1]:
        t = p.text.strip().upper()
        trovato = next(((n, tec) for n, tec in BLOCCHI_TECNICHE
                        if t.startswith(n) and len(t) < 80 and p.text.strip().isupper()), None)
        if trovato:
            attivo = trovato[1] if trovato[1] in tecniche_presenti else "VIA"
        if attivo == "VIA":
            togli.append(p)
    for p in togli:
        p._p.getparent().remove(p._p)


def compatta_copertina(doc) -> None:
    """La copertina della relazione (prima tabella) deve stare in una pagina.

    Con destinatari e oggetti lunghi (es. "Linea 124 Ferrovia Battipaglia –
    Potenza – Metaponto dal km ... al km ...") la tabella cresceva e il
    riquadro PROGETTISTA finiva da solo sulla pagina dopo. Quindi:
    - le righe vuote ripetute dentro le celle diventano una sola;
    - le altezze minime delle righe sono ridotte (crescono comunque col testo);
    - nessuna riga si spezza fra due pagine;
    - il nome file nel riquadro progettista e' piu' piccolo e non va a capo
      a meta' ("...RT+CR.pd / f")."""
    from docx.shared import Pt
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    if not doc.tables:
        return
    tbl = doc.tables[0]
    # deve essere la copertina: tabella prima di qualsiasi testo
    primo = doc.element.body[0]
    if primo is not tbl._tbl:
        return
    ridotte = {1: 2000, 2: 3600, 4: 1700, 5: 1700}
    for i, row in enumerate(tbl.rows):
        tr = row._tr
        trpr = tr.get_or_add_trPr()
        if trpr.find(W + "cantSplit") is None:
            trpr.insert(0, trpr.makeelement(W + "cantSplit", {}))
        h = trpr.find(W + "trHeight")
        if h is not None and i in ridotte:
            try:
                if int(h.get(W + "val")) > ridotte[i]:
                    h.set(W + "val", str(ridotte[i]))
            except (TypeError, ValueError):
                pass
        visti = set()
        for cella in row.cells:
            if id(cella._tc) in visti:          # celle unite ripetute
                continue
            visti.add(id(cella._tc))
            pars = cella.paragraphs
            vuoto_prec = False
            for k, p in enumerate(pars):
                vuoto = not p.text.strip() and p._p.find(".//" + W + "drawing") is None
                if vuoto and vuoto_prec and len(cella.paragraphs) > 1:
                    p._p.getparent().remove(p._p)
                    continue
                vuoto_prec = vuoto
                t = p.text.strip()
                if t.lower().endswith((".pdf", ".docx")) and len(t) > 25:
                    for r in p.runs:
                        r.font.size = Pt(10)


def uniforma_spaziature(doc, inizio: str = "PREMESSA") -> None:
    """Stessa distanza fra tutti i paragrafi della relazione.

    Il modello alternava righe vuote (premessa, cap. 1-4), paragrafi
    attaccati (cap. 5-12) e titoli con interlinea 2,5. Dal titolo `inizio`
    in poi: si tolgono le righe vuote e la distanza la danno le spaziature
    del paragrafo -> corpo 1,5 righe + 6 pt dopo; titoli di capitolo 18 pt
    prima / 8 pt dopo; sottotitoli (MINITRINCEA, POZZETTO CLS...) 12 pt
    prima / 4 pt dopo; elenchi puntati 2 pt fra le voci. Copertina e indice
    restano come sono."""
    from docx.shared import Pt
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    paragrafi = list(doc.paragraphs)
    avvio = None
    for k, p in enumerate(paragrafi):
        if p.text.strip().upper() == inizio and not p.style.name.lower().startswith("toc"):
            avvio = k
            break
    if avvio is None:
        return

    def _interlinea(p):
        v, s = p.paragraph_format.line_spacing, p.style
        while v is None and s is not None:
            v, s = s.paragraph_format.line_spacing, s.base_style
        return v

    def _vuoto_rimovibile(p):
        el = p._p
        if p.text.strip():
            return False
        # immagini, interruzioni di pagina/sezione e campi restano
        for tag in ("drawing", "pict", "br", "sectPr", "fldChar", "object"):
            if el.find(".//" + W + tag) is not None:
                return False
        prima, dopo = el.getprevious(), el.getnext()
        # un paragrafo vuoto fra due tabelle le tiene separate in Word
        if prima is not None and dopo is not None and \
                prima.tag == W + "tbl" and dopo.tag == W + "tbl":
            return False
        return True

    for p in paragrafi[avvio:]:
        if _vuoto_rimovibile(p):
            p._p.getparent().remove(p._p)
            continue
        t = p.text.strip()
        pf = p.paragraph_format
        el = p._p
        ppr = el.pPr
        elenco = ppr is not None and ppr.find(W + "numPr") is not None
        il = _interlinea(p)
        titolo = (p.style.name.lower().startswith("heading")
                  or (isinstance(il, float) and il >= 2.0)
                  or t.upper() == inizio
                  or bool(re.match(r"^\d+\.\s", t) and t.isupper()))
        segue_tabella = el.getnext() is not None and el.getnext().tag == W + "tbl"
        sottotitolo = (not titolo and t.isupper() and len(t) <= 90
                       and not t.endswith((".", ";")))
        if titolo:
            pf.line_spacing = 1.15
            pf.space_before = Pt(18)
            pf.space_after = Pt(8)
            pf.keep_with_next = True
            pf.alignment = WD_ALIGN_PARAGRAPH.LEFT
        elif sottotitolo or segue_tabella:
            pf.line_spacing = 1.15
            pf.space_before = Pt(12)
            pf.space_after = Pt(4)
            pf.keep_with_next = True
        elif t.startswith("*"):
            # nota sotto le tabelle del computo
            pf.line_spacing = 1.0
            pf.space_before = Pt(4)
            pf.space_after = Pt(10)
        else:
            pf.line_spacing = 1.5
            pf.space_before = Pt(0)
            pf.space_after = Pt(2) if elenco else Pt(6)
            if elenco:
                nxt = el.getnext()
                ultimo = nxt is None or nxt.tag != W + "p" or nxt.find(
                    W + "pPr/" + W + "numPr") is None
                if ultimo:
                    pf.space_after = Pt(6)
            # contextualSpacing azzera lo spazio fra paragrafi dello stesso
            # stile (List Paragraph): va tolto o gli spazi non sono uguali
            if ppr is not None:
                cs = ppr.find(W + "contextualSpacing")
                if cs is not None:
                    ppr.remove(cs)


def espandi_paragrafo(doc, chiave: str, righe: list) -> bool:
    """Il paragrafo che contiene <<chiave>> viene clonato una volta per riga
    (stessa formattazione); con lista vuota il paragrafo sparisce."""
    tag = "<<%s>>" % chiave
    for p in list(_tutti_i_paragrafi(doc)):
        if tag not in testo_paragrafo(p):
            continue
        prec = p
        for r in righe:
            nuovo = copy.deepcopy(p)
            sostituisci_in_paragrafo(nuovo, tag, r)
            prec.addnext(nuovo)
            prec = nuovo
        p.getparent().remove(p)
        return True
    return False


# ---------------------------------------------------------------------------
# Tabelle della relazione tecnica (SCAVI, POZZETTI, CRONOPROGRAMMA)
# ---------------------------------------------------------------------------
RT_TAB_SCAVI = 1       # r4 = riga modello; colonne 1..4 tecniche, 5 totale
RT_TAB_POZZETTI = 2    # r2 = riga modello; colonne 1..4 dimensioni, 5 totale
RT_TAB_CRONO = 3       # r2 = riga modello; colonne 1..4 metri, 5 pozzetti, 6 gg
CRONO_COL_POZZETTI = 5
CRONO_COL_GG = 6
COL_TECNICA = {"microtrincea": 1, "nodig": 2, "trincea": 3, "minitrincea": 4}
DIM_POZZETTI = ["125x80", "76x40", "45x15", "90x70"]
COL_POZZETTO = {d: i + 1 for i, d in enumerate(DIM_POZZETTI)}
# sinonimi delle dimensioni nei dati di progetto
ALIAS_POZZETTI = {"40x76": "76x40", "80x125": "125x80", "15x45": "45x15",
                  "70x90": "90x70", "125X80": "125x80", "76X40": "76x40"}


def norm_pozzetto(d: str) -> str:
    d = str(d or "").strip().lower().replace(" ", "").replace("cm", "")
    return ALIAS_POZZETTI.get(d, d)


def _fmt_num(x: float) -> str:
    """Metri di scavo a cifra tonda: 66.9 -> '67' (tavola e relazione).
    Anche i valori corretti a mano nella tabella interferenze escono interi."""
    return str(int(float(x) + 0.5))


def _fmt_giorni(g: float) -> str:
    if abs(g - round(g)) < 1e-9:
        return str(int(round(g)))
    return f"{g:.1f}".replace(".", ",")


def _dash(x) -> str:
    return "-" if not x else _fmt_num(x)


def _clona_riga(tbl, riga_modello_idx):
    tr = tbl.rows[riga_modello_idx]._tr
    nuovo_tr = copy.deepcopy(tr)
    tbl._tbl.append(nuovo_tr)
    return tbl.rows[-1]


def _set_cella(cell, testo):
    """Scrive il testo nella cella tenendo lo stile del primo run. I paragrafi
    in piu' delle celle del modello vengono tolti (lasciati vuoti spostavano i
    valori a altezze diverse) e il contenuto e' centrato in verticale."""
    from docx.enum.table import WD_ALIGN_VERTICAL
    if cell.paragraphs and cell.paragraphs[0].runs:
        cell.paragraphs[0].runs[0].text = testo
        for r in cell.paragraphs[0].runs[1:]:
            r.text = ""
    else:
        cell.text = testo
    for p in cell.paragraphs[1:]:
        p._p.getparent().remove(p._p)
    try:
        from docx.shared import Pt
        pf = cell.paragraphs[0].paragraph_format
        pf.space_before = Pt(0)
        pf.space_after = Pt(0)
        pf.line_spacing = 1.0            # la colonna Tot del modello ha interlinea
                                         # 2,5: il valore finiva in cima alla cella
        cell.vertical_alignment = WD_ALIGN_VERTICAL.CENTER
    except Exception:  # noqa: BLE001
        pass


def _svuota_righe_dopo(tbl, keep_idx):
    while len(tbl.rows) > keep_idx + 1:
        tbl._tbl.remove(tbl.rows[-1]._tr)


def riempi_tabelle_rt(doc, tratte: list, rese: Optional[dict] = None) -> None:
    """Una riga per interferenza in ciascuna delle tre tabelle + riga totale."""
    rese = rese or RESE_DEFAULT
    if not tratte:
        return
    # SCAVI
    tb = doc.tables[RT_TAB_SCAVI]
    modello = 4
    _svuota_righe_dopo(tb, modello)
    tot_tec = {t: 0.0 for t in TECNICHE}
    for i, tr in enumerate(tratte):
        row = tb.rows[modello] if i == 0 else _clona_riga(tb, modello)
        _set_cella(row.cells[0], tr.descrizione())
        tot_r = 0.0
        for t in TECNICHE:
            m = tr.metri.get(t, 0.0)
            tot_r += m
            tot_tec[t] += m
            _set_cella(row.cells[COL_TECNICA[t]], _dash(m))
        _set_cella(row.cells[5], _dash(tot_r))
    rtot = _clona_riga(tb, modello)
    _set_cella(rtot.cells[0], "Totale complessivo")
    for t in TECNICHE:
        _set_cella(rtot.cells[COL_TECNICA[t]], _dash(tot_tec[t]))
    _set_cella(rtot.cells[5], _dash(sum(tot_tec.values())))

    # POZZETTI
    tb = doc.tables[RT_TAB_POZZETTI]
    modello = 2
    _svuota_righe_dopo(tb, modello)
    tot_dim = {d: 0 for d in DIM_POZZETTI}
    altre = {}
    # una riga per km di posa e solo dove ci sono pozzetti (come nelle pratiche)
    righe = [r for tr in tratte for r in (tr.righe_pozzetti or
             ([(tr.descrizione(), tr.pozzetti)] if tr.pozzetti else []))]
    if not righe:
        righe = [("Nessun nuovo pozzetto", {})]
    for i, (etich, pozz) in enumerate(righe):
        row = tb.rows[modello] if i == 0 else _clona_riga(tb, modello)
        _set_cella(row.cells[0], etich)
        tot_r = 0
        pz = {}
        for d, n in pozz.items():
            dn = norm_pozzetto(d)
            if dn in COL_POZZETTO:
                pz[dn] = pz.get(dn, 0) + n
            else:
                altre[dn] = altre.get(dn, 0) + n
        for d in DIM_POZZETTI:
            n = pz.get(d, 0)
            tot_r += n
            tot_dim[d] += n
            _set_cella(row.cells[COL_POZZETTO[d]], str(n) if n else "-")
        _set_cella(row.cells[5], str(tot_r) if tot_r else "-")
    rtot = _clona_riga(tb, modello)
    _set_cella(rtot.cells[0], "Totale Complessivo")
    for d in DIM_POZZETTI:
        _set_cella(rtot.cells[COL_POZZETTO[d]], str(tot_dim[d]) if tot_dim[d] else "-")
    s = sum(tot_dim.values())
    _set_cella(rtot.cells[5], str(s) if s else "-")

    # CRONOPROGRAMMA
    tb = doc.tables[RT_TAB_CRONO]
    modello = 2
    _svuota_righe_dopo(tb, modello)
    # giorni a mezza giornata (come nelle pratiche presentate: "1,5"), riga
    # per riga; i totali sono la somma delle righe, cosi' la tabella torna
    # (prima la riga arrotondava al giorno intero e il totale no: 2+1 != 2)
    # colonne: metri per tecnica | pozzetti posati | gg. La riga "Totale"
    # somma le quantita' (metri, pozzetti) e i giorni. I gg di ogni riga
    # comprendono scavo, posa pozzetti e ripristini (scavi e chiusini).
    tot_m = {t: 0 for t in TECNICHE}
    n_pozz_tot = 0
    gg_tot = 0.0
    for i, tr in enumerate(tratte):
        row = tb.rows[modello] if i == 0 else _clona_riga(tb, modello)
        _set_cella(row.cells[0], tr.descrizione())
        g_sc, g_pz, g_rp = giorni_tratta(tr, rese)
        for t in TECNICHE:
            m = tr.metri.get(t, 0.0)
            tot_m[t] += m
            _set_cella(row.cells[COL_TECNICA[t]], _dash(m))
        n_pz = sum(int(n) for n in (tr.pozzetti or {}).values())
        n_pozz_tot += n_pz
        _set_cella(row.cells[CRONO_COL_POZZETTI], str(n_pz) if n_pz else "-")
        gg = sum(g_sc.values()) + g_pz + g_rp
        gg_tot += gg
        _set_cella(row.cells[CRONO_COL_GG], _fmt_giorni(gg) if gg > 0 else "-")
    rtot = _clona_riga(tb, modello)
    _set_cella(rtot.cells[0], "Totale")
    for t in TECNICHE:
        _set_cella(rtot.cells[COL_TECNICA[t]], _dash(tot_m[t]))
    _set_cella(rtot.cells[CRONO_COL_POZZETTI], str(n_pozz_tot) if n_pozz_tot else "-")
    _set_cella(rtot.cells[CRONO_COL_GG], _fmt_giorni(gg_tot) if gg_tot else "-")
    return altre


def giorni_tratta(tr, rese: Optional[dict] = None):
    """Giorni di una riga del cronoprogramma, a mezze giornate:
    ({tecnica: giorni scavo}, giorni posa pozzetti, giorni ripristino).
    Il ripristino comprende manto sugli scavi e sistemazione attorno ai
    chiusini dei pozzetti posati."""
    r = rese_complete(rese)
    scavo = {}
    rip = 0.0
    for t in TECNICHE:
        m = tr.metri.get(t, 0.0)
        if m > 0:
            scavo[t] = arrotonda_mezzo_sup(m / r[t])
            rip += (r["ripristino_nodig"] if t == "nodig"
                    else m / r["ripristino"][t])
    pz = 0.0
    n_tot = 0
    for d, n in (tr.pozzetti or {}).items():
        n = int(n or 0)
        n_tot += n
        pz += n / r["pozzetti"].get(norm_pozzetto(d), r["pozzetti_altri"])
    rip += n_tot / r["ripristino_chiusini"]
    return scavo, arrotonda_mezzo_sup(pz), arrotonda_mezzo_sup(rip)


def rese_complete(rese: Optional[dict] = None) -> dict:
    """Tutte le rese del cronoprogramma, con i valori predefiniti dove
    `rese` (dalla scheda RFI) non dice nulla. Chiavi:
    microtrincea/nodig/trincea/minitrincea (scavo, m/giorno),
    pozzetti {dim: pezzi/giorno}, pozzetti_altri, ripristino {tecnica: m/giorno},
    ripristino_nodig (giorni per tratta), ripristino_chiusini (pezzi/giorno).
    Valori nulli o negativi sono ignorati (resta il predefinito)."""
    r = dict(RESE_DEFAULT)
    r["pozzetti"] = dict(RESE_POZZETTI)
    r["pozzetti_altri"] = RESA_POZZETTI_ALTRI
    r["ripristino"] = dict(RESE_RIPRISTINO)
    r["ripristino_nodig"] = GIORNI_RIPRISTINO_NODIG
    r["ripristino_chiusini"] = RESA_RIPRISTINO_POZZETTI

    def _ok(v):
        try:
            return float(v) > 0
        except (TypeError, ValueError):
            return False
    for k, v in (rese or {}).items():
        if isinstance(v, dict) and isinstance(r.get(k), dict):
            r[k].update({kk: float(vv) for kk, vv in v.items() if _ok(vv)})
        elif k in r and not isinstance(r[k], dict) and _ok(v):
            r[k] = float(v)
    return r


# ---------------------------------------------------------------------------
# Generazione documenti di una istanza
# ---------------------------------------------------------------------------
def genera_documenti_istanza(ist: Istanza, comune: DatiComune, cartella_template: str,
                             cartella_out: str, rese: Optional[dict] = None,
                             oggi: datetime.date = None) -> dict:
    """Compila i 4 modelli Word dell'istanza in `cartella_out`.
    Ritorna {chiave: percorso} (None se il modello manca)."""
    from docx import Document
    os.makedirs(cartella_out, exist_ok=True)
    valori = valori_istanza(ist, comune, oggi)
    tip = TIPOLOGIE[ist.tipologia]
    prodotti = {}
    for chiave, nome_tpl in TEMPLATE_FILES.items():
        tpl = os.path.join(cartella_template, nome_tpl)
        if not os.path.isfile(tpl):
            prodotti[chiave] = None
            continue
        doc = Document(tpl)
        if chiave == "modb":
            espandi_paragrafo(doc, "ALLEGATI_EXTRA", tip["allegati"])
        if chiave == "rt":
            applica_condizioni(doc, {
                "SE_POZZETTI": any(i.pozzetti for i in ist.interferenze),
                "SE_ARMADI": any(e.get("tipo") == "armadio"
                                 for i in ist.interferenze for e in i.elementi)})
            riempi_tabelle_rt(doc, ist.tratte(), rese)
        sostituisci_tutto(doc, valori)
        if chiave == "rt":
            adatta_relazione(doc, {t for tr in ist.tratte() for t, m in tr.metri.items() if m},
                             con_pozzetti=any(i.pozzetti for i in ist.interferenze))
            uniforma_spaziature(doc)
            compatta_copertina(doc)
        out = os.path.join(cartella_out, NOMI_FILE[chiave].format(base=ist.nome_base))
        doc.save(out)
        prodotti[chiave] = out
    return prodotti


def promemoria_istanza(ist: Istanza, comune: DatiComune) -> str:
    """Testo del file LEGGIMI della cartella: documenti, cosa manca, avvertenze."""
    tip = TIPOLOGIE[ist.tipologia]
    g = ist.gestore
    L = ["ISTANZA %d — %s" % (ist.numero, ist.nome_base), "",
         tip["titolo"],
         "Gestore: %s" % g.nome,
         "Destinatario: %s — %s — PEC %s" % (g.dest_nome or "DA COMPILARE",
                                             g.dest_indirizzo or "indirizzo DA COMPILARE",
                                             g.dest_pec or "DA COMPILARE"),
         "Linea: %s" % ist.linea,
         "Stazione di riferimento: %s" % (ist.stazione or "—"),
         "Comune: %s (%s)" % (comune.nome.upper(), comune.prov_sigla.upper()), "",
         "Interferenze:"]
    for i in ist.interferenze:
        metri = ", ".join("%s %s m" % (ETICH_TECNICA[t], _fmt_num(m))
                          for t, m in i.metri.items() if m)
        pz = ", ".join("%s x%d" % (d, n) for d, n in i.pozzetti.items())
        L.append("  - #%d %s — %s%s" % (i.id, etichetta_km(i.km_da, i.km_a),
                                        metri or "nessuno scavo",
                                        (" — pozzetti " + pz) if pz else ""))
        for n in i.note:
            L.append("      ! %s" % n)
    L += ["", "Documenti:",
          "  1.0 Istanza art. 49 (Word)",
          "  1.1 Planimetria PL (PDF, dal layout QGIS)",
          "  1.2 Relazione tecnica + cronoprogramma (Word + PDF)",
          "  1.3 Autocertificazione bollo (Word)",
          "  1.4 Modello B — schema di richiesta interferenze (Word)", ""]
    L.append("Da fare prima dell'invio:")
    for p in tip["promemoria"]:
        L.append("  - %s" % p)
    L.append("  - Compilare i campi XXXXX (procuratore, referenti, firme) e verificare "
             "i km segnati XXX+XXX.")
    if not g.destinatario_completo():
        L.append("  - Destinatario incompleto: inserire indirizzo e PEC del gestore.")
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------
# Conversione in PDF (Word via COM, poi LibreOffice)
# ---------------------------------------------------------------------------
def _soffice():
    for c in (r"C:\Program Files\LibreOffice\program\soffice.exe",
              r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"):
        if os.path.isfile(c):
            return c
    return None


def converti_pdf(docx_paths: list) -> dict:
    """Converte i .docx in PDF accanto al file. Ritorna {docx: pdf o None}.
    Usa Microsoft Word (pywin32), altrimenti LibreOffice se installato."""
    ris = {p: None for p in docx_paths}
    if not docx_paths:
        return ris
    word = None
    try:
        import win32com.client  # noqa: F401
        import pythoncom
        pythoncom.CoInitialize()
        word = win32com.client.DispatchEx("Word.Application")
        word.Visible = False
        word.DisplayAlerts = 0
        for p in docx_paths:
            pdf = os.path.splitext(p)[0] + ".pdf"
            doc = word.Documents.Open(os.path.abspath(p), ReadOnly=False)
            try:
                # indice: numeri di pagina aggiornati al testo generato (le
                # voci restano quelle del modello); si salva anche il Word
                try:
                    if doc.TablesOfContents.Count > 0:
                        for k in range(1, doc.TablesOfContents.Count + 1):
                            doc.TablesOfContents(k).UpdatePageNumbers()
                        doc.Save()
                except Exception:  # noqa: BLE001
                    pass
                doc.SaveAs2(os.path.abspath(pdf), FileFormat=17)   # wdFormatPDF
                ris[p] = pdf
            finally:
                doc.Close(False)
        return ris
    except Exception:  # noqa: BLE001 — niente Word: provo LibreOffice
        pass
    finally:
        if word is not None:
            try:
                word.Quit()
            except Exception:  # noqa: BLE001
                pass
    so = _soffice()
    if so:
        import subprocess
        for p in docx_paths:
            subprocess.run([so, "--headless", "--convert-to", "pdf", "--outdir",
                            os.path.dirname(os.path.abspath(p)), p],
                           capture_output=True, timeout=180)
            pdf = os.path.splitext(p)[0] + ".pdf"
            ris[p] = pdf if os.path.isfile(pdf) else None
    return ris
