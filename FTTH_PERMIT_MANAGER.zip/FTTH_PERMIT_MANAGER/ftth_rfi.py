# -*- coding: utf-8 -*-
"""
ftth_rfi.py — Generazione istanze RFI (tipologia D e successive A/B/C).

LOGICA PURA: nessun import qgis/PyQt. Riceve i dati gia' estratti (dal plugin
o da un dict di test) e compila i template .docx della cartella "RFI TipoD".
Testabile headless. (c) Beexact S.r.l.

Dipendenze: python-docx.

Flusso:
    dati = DatiIstanzaRFI(...)          # dati testata + tratte di scavo
    calcola_cronoprogramma(dati, rese)  # riempie giorni scavo/tecnica
    genera_istanze(dati, cartella_template, cartella_out)  # scrive i 4 docx

I template devono contenere i segnaposto <<...>> (vedi SEGNAPOSTI) e le
3 tabelle nella RT (SCAVI idx1, POZZETTI idx2, CRONOPROGRAMMA idx3).
"""
from __future__ import annotations
import os
import math
import copy
from dataclasses import dataclass, field
from typing import Optional

# ---------------------------------------------------------------------------
# RESE DI SCAVO (metri/giorno) — default modificabili per progetto.
# Verificate su Chiavenna/Calcinato/Gambolo per trincea/minitrincea.
# ---------------------------------------------------------------------------
RESE_DEFAULT = {
    "microtrincea": 150.0,   # stima
    "nodig":         30.0,   # stima (tratta corta, buche lancio/arrivo)
    "trincea":       50.0,   # verificata
    "minitrincea":  130.0,   # verificata
}

# Ordine colonne tabelle (come nei template reali)
TECNICHE = ["microtrincea", "nodig", "trincea", "minitrincea"]
ETICH_TECNICA = {
    "microtrincea": "Microtrincea",
    "nodig":        "No Dig",
    "trincea":      "Trincea",
    "minitrincea":  "Minitrincea",
}

# I 22 segnaposto di testata (tutti quelli presenti nei template)
SEGNAPOSTI = [
    "CAP", "COMUNE_PEC", "DATA", "DOIT_CITTA", "DOIT_INDIRIZZO", "DOIT_PEC",
    "INDIRIZZO_COMUNE", "KM_A", "KM_DA", "LINEA", "LUOGO_FIRMA", "NOME_COMUNE",
    "PROC_CF", "PROC_COGNOME", "PROC_DOC", "PROC_NATO_A", "PROC_NATO_IL",
    "PROC_NOME", "PROC_PROV", "PROC_RESIDENZA", "PROC_VIA", "PROV_SIGLA",
]

# Mappa valori campo TIPOLOGIA (layer 03 INFRASTRUTTURE) -> tecnica interna
MAP_TIPOLOGIA = {
    "tradizionale": "trincea",
    "mini trincea": "minitrincea",
    "minitrincea": "minitrincea",
    "no dig": "nodig",
    "nodig": "nodig",
    "microtrincea": "microtrincea",
    "micro trincea": "microtrincea",
    # 'aerea' e '' -> escluse (non sono scavi)
}


def mappa_tecnica(valore_tipologia: str) -> Optional[str]:
    """Converte il valore del campo TIPOLOGIA nella tecnica interna, o None
    se non e' uno scavo (aerea/vuoto/sconosciuto)."""
    if not valore_tipologia:
        return None
    return MAP_TIPOLOGIA.get(valore_tipologia.strip().lower())


# Mappa nome file template -> chiave documento
TEMPLATE_FILES = {
    "art49":   "TEMPLATE_1.0_art.49.docx",
    "rt":      "TEMPLATE_1.2_RT+CR.docx",
    "bollo":   "TEMPLATE_1.3_Bollo.docx",
    "modb":    "TEMPLATE_1.4_MODELLO B.docx",
}
# Suffissi output
OUT_SUFFIX = {
    "art49": "_RFI_TipoD_art.49",
    "rt":    "_RFI_TipoD_RT+CR",
    "bollo": "_RFI_TipoD_Bollo",
    "modb":  "_RFI_TipoD_MODELLO B",
}


def _fmt_num(x: float) -> str:
    """Formatta numero all'italiana: 34.0 -> '34,00'; intero se .0 su giorni."""
    return f"{x:.2f}".replace(".", ",")


def _fmt_giorni(g: float) -> str:
    """Giorni: mostra intero se intero, altrimenti con la virgola (0,5)."""
    if abs(g - round(g)) < 1e-9:
        return str(int(round(g)))
    return f"{g:.1f}".replace(".", ",")


def arrotonda_mezzo_sup(x: float) -> float:
    """Arrotonda al mezzo giorno superiore (0.1 -> 0.5, 0.6 -> 1.0)."""
    if x <= 0:
        return 0.0
    return math.ceil(x * 2) / 2.0


# ---------------------------------------------------------------------------
# Modello dati
# ---------------------------------------------------------------------------
@dataclass
class Tratta:
    """Una tratta di scavo, con i metri per tecnica."""
    km_da: str
    km_a: str
    metri: dict = field(default_factory=dict)   # {tecnica: metri}
    pozzetti: dict = field(default_factory=dict) # {dimensione: n} es {"76x40":1}

    def totale_metri(self) -> float:
        return sum(self.metri.get(t, 0.0) for t in TECNICHE)


@dataclass
class DatiIstanzaRFI:
    # testata
    nome_comune: str = ""
    prov_sigla: str = ""
    cap: str = ""
    indirizzo_comune: str = ""
    comune_pec: str = ""
    linea: str = ""
    km_da: str = ""
    km_a: str = ""
    doit_citta: str = ""
    doit_indirizzo: str = ""
    doit_pec: str = ""
    fascia: str = "6-30m"
    data: str = ""
    luogo_firma: str = ""
    # procuratore (variabile)
    proc_cognome: str = ""
    proc_nome: str = ""
    proc_cf: str = ""
    proc_nato_a: str = ""
    proc_prov: str = ""
    proc_nato_il: str = ""
    proc_residenza: str = ""
    proc_via: str = ""
    proc_doc: str = ""
    # tratte di scavo
    tratte: list = field(default_factory=list)
    # cronoprogramma calcolato: {tecnica: giorni}
    giorni_tecnica: dict = field(default_factory=dict)
    giorni_totali: float = 0.0

    def valori_segnaposto(self) -> dict:
        """Ritorna {NOME_SEGNAPOSTO: valore} per la sostituzione."""
        return {
            "NOME_COMUNE": self.nome_comune,
            "PROV_SIGLA": self.prov_sigla,
            "CAP": self.cap,
            "INDIRIZZO_COMUNE": self.indirizzo_comune,
            "COMUNE_PEC": self.comune_pec,
            "LINEA": self.linea,
            "KM_DA": self.km_da,
            "KM_A": self.km_a,
            "DOIT_CITTA": self.doit_citta,
            "DOIT_INDIRIZZO": self.doit_indirizzo,
            "DOIT_PEC": self.doit_pec,
            "DATA": self.data,
            "LUOGO_FIRMA": self.luogo_firma or self.nome_comune,
            "PROC_COGNOME": self.proc_cognome,
            "PROC_NOME": self.proc_nome,
            "PROC_CF": self.proc_cf,
            "PROC_NATO_A": self.proc_nato_a,
            "PROC_PROV": self.proc_prov,
            "PROC_NATO_IL": self.proc_nato_il,
            "PROC_RESIDENZA": self.proc_residenza,
            "PROC_VIA": self.proc_via,
            "PROC_DOC": self.proc_doc,
        }


# ---------------------------------------------------------------------------
# Cronoprogramma
# ---------------------------------------------------------------------------
def calcola_cronoprogramma(dati: DatiIstanzaRFI, rese: Optional[dict] = None) -> None:
    """Calcola i giorni per tecnica (mezzo giorno sup) e il totale (intero sup).
    Somma i metri di tutte le tratte per tecnica."""
    rese = rese or RESE_DEFAULT
    metri_tot = {t: 0.0 for t in TECNICHE}
    for tr in dati.tratte:
        for t in TECNICHE:
            metri_tot[t] += tr.metri.get(t, 0.0)
    giorni = {}
    for t in TECNICHE:
        m = metri_tot[t]
        if m > 0:
            giorni[t] = arrotonda_mezzo_sup(m / rese[t])
        else:
            giorni[t] = 0.0
    dati.giorni_tecnica = giorni
    dati.giorni_totali = math.ceil(sum(giorni.values())) if sum(giorni.values()) > 0 else 0
    return None


# ---------------------------------------------------------------------------
# Sostituzione segnaposto (gestisce run frammentati e hyperlink w:t)
# ---------------------------------------------------------------------------
def _sost_par(par, repls: dict) -> int:
    from docx.oxml.ns import qn
    wt = par._p.findall('.//' + qn('w:t'))
    full = "".join(t.text or "" for t in wt)
    if not any(k in full for k in repls):
        return 0
    n = 0
    # per-nodo
    for t in wt:
        if t.text:
            for k, v in repls.items():
                if k in t.text:
                    t.text = t.text.replace(k, v); n += 1
    # chiavi spezzate tra nodi
    joined = "".join(t.text or "" for t in wt)
    if any(k in joined for k in repls):
        for k, v in repls.items():
            joined = joined.replace(k, v)
        if wt:
            wt[0].text = joined
            for t in wt[1:]:
                t.text = ""
            n += 1
    return n


def _sostituisci_tutto(doc, repls: dict) -> int:
    tot = 0
    for par in doc.paragraphs:
        tot += _sost_par(par, repls)
    for tb in doc.tables:
        for row in tb.rows:
            for cell in row.cells:
                for par in cell.paragraphs:
                    tot += _sost_par(par, repls)
    for sec in doc.sections:
        for hf in (sec.header, sec.footer):
            for par in hf.paragraphs:
                tot += _sost_par(par, repls)
    return tot


# ---------------------------------------------------------------------------
# Riempimento tabelle RT (SCAVI, POZZETTI, CRONOPROGRAMMA)
# ---------------------------------------------------------------------------
def _clona_riga(tbl, riga_modello_idx):
    """Clona una riga della tabella (con formattazione) e la accoda."""
    from copy import deepcopy
    tr = tbl.rows[riga_modello_idx]._tr
    nuovo_tr = deepcopy(tr)
    tbl._tbl.append(nuovo_tr)
    return tbl.rows[-1]


def _set_cella(cell, testo):
    """Scrive testo in cella preservando la formattazione del primo run."""
    # usa il primo paragrafo/run se esiste
    if cell.paragraphs and cell.paragraphs[0].runs:
        cell.paragraphs[0].runs[0].text = testo
        for r in cell.paragraphs[0].runs[1:]:
            r.text = ""
        # eventuali paragrafi extra svuotati
        for p in cell.paragraphs[1:]:
            for r in p.runs:
                r.text = ""
    else:
        cell.text = testo


# NB: il riempimento tabelle dettagliato dipende dalla struttura esatta del
# template (righe modello) e viene rifinito nel test su dati reali.

# Indici tabelle nella RT e righe-modello (struttura template reale)
RT_TAB_SCAVI = 1       # r4 = riga tratta modello; colonne 1..4 tecniche, 5 tot
RT_TAB_POZZETTI = 2    # r2 = riga tratta modello; colonne 1..4 dim, 5 tot
RT_TAB_CRONO = 3       # r2 = riga tratta modello; col 1..4 metri tecnica, 5 gg
# Colonne tecniche nelle tabelle SCAVI/CRONO: micro=1, nodig=2, trincea=3, mini=4
COL_TECNICA = {"microtrincea": 1, "nodig": 2, "trincea": 3, "minitrincea": 4}
# Dimensioni pozzetti (ordine colonne TAB2): 125x80=1,76x40=2,45x15=3,90x70=4
DIM_POZZETTI = ["125x80", "76x40", "45x15", "90x70"]
COL_POZZETTO = {d: i + 1 for i, d in enumerate(DIM_POZZETTI)}


def _svuota_righe_dopo(tbl, keep_idx):
    """Elimina tutte le righe di indice > keep_idx (rimuove i totali duplicati)."""
    while len(tbl.rows) > keep_idx + 1:
        tr = tbl.rows[-1]._tr
        tbl._tbl.remove(tr)


def _dash(x: float) -> str:
    """0 -> '-', altrimenti numero italiano."""
    return "-" if (x is None or x == 0) else _fmt_num(x)


def riempi_tabelle_rt(doc, dati: "DatiIstanzaRFI") -> None:
    """Riempie le 3 tabelle della RT clonando la riga-modello per ogni tratta,
    poi aggiunge la riga Totale. Mantiene la formattazione del template."""
    tratte = dati.tratte
    if not tratte:
        return

    # ---------- TAB SCAVI ----------
    tb = doc.tables[RT_TAB_SCAVI]
    modello = 4
    _svuota_righe_dopo(tb, modello)          # tengo header + 1 riga modello
    tot_tec = {t: 0.0 for t in TECNICHE}
    for i, tr in enumerate(tratte):
        row = tb.rows[modello] if i == 0 else _clona_riga(tb, modello)
        _set_cella(row.cells[0], f"Dal Km {tr.km_da} al Km {tr.km_a}")
        tot_r = 0.0
        for t in TECNICHE:
            m = tr.metri.get(t, 0.0); tot_r += m; tot_tec[t] += m
            _set_cella(row.cells[COL_TECNICA[t]], _dash(m))
        _set_cella(row.cells[5], _dash(tot_r))
    # riga Totale complessivo
    rtot = _clona_riga(tb, modello)
    _set_cella(rtot.cells[0], "Totale complessivo")
    for t in TECNICHE:
        _set_cella(rtot.cells[COL_TECNICA[t]], _dash(tot_tec[t]))
    _set_cella(rtot.cells[5], _dash(sum(tot_tec.values())))

    # ---------- TAB POZZETTI ----------
    tb = doc.tables[RT_TAB_POZZETTI]
    modello = 2
    _svuota_righe_dopo(tb, modello)
    tot_dim = {d: 0 for d in DIM_POZZETTI}
    for i, tr in enumerate(tratte):
        row = tb.rows[modello] if i == 0 else _clona_riga(tb, modello)
        _set_cella(row.cells[0], f"Al Km {tr.km_da}")
        tot_r = 0
        for d in DIM_POZZETTI:
            n = tr.pozzetti.get(d, 0); tot_r += n; tot_dim[d] += n
            _set_cella(row.cells[COL_POZZETTO[d]], str(n) if n else "-")
        _set_cella(row.cells[5], str(tot_r) if tot_r else "-")
    rtot = _clona_riga(tb, modello)
    _set_cella(rtot.cells[0], "Totale Complessivo")
    for d in DIM_POZZETTI:
        _set_cella(rtot.cells[COL_POZZETTO[d]], str(tot_dim[d]) if tot_dim[d] else "-")
    _set_cella(rtot.cells[5], str(sum(tot_dim.values())) if sum(tot_dim.values()) else "-")

    # ---------- TAB CRONOPROGRAMMA ----------
    tb = doc.tables[RT_TAB_CRONO]
    modello = 2
    _svuota_righe_dopo(tb, modello)
    rese_uso = getattr(dati, "_rese", None) or RESE_DEFAULT
    for i, tr in enumerate(tratte):
        row = tb.rows[modello] if i == 0 else _clona_riga(tb, modello)
        _set_cella(row.cells[0], f"Dal Km {tr.km_da} al Km {tr.km_a}")
        gg_tratta = 0.0
        for t in TECNICHE:
            m = tr.metri.get(t, 0.0)
            _set_cella(row.cells[COL_TECNICA[t]], _dash(m))
            if m > 0:
                gg_tratta += arrotonda_mezzo_sup(m / rese_uso[t])
        _set_cella(row.cells[5], _fmt_giorni(math.ceil(gg_tratta) if gg_tratta > 0 else 0))
    # riga Totale giorni
    rtot = _clona_riga(tb, modello)
    _set_cella(rtot.cells[0], "Totale Giorni lavorazione")
    for t in TECNICHE:
        g = dati.giorni_tecnica.get(t, 0.0)
        _set_cella(rtot.cells[COL_TECNICA[t]], _fmt_giorni(g) if g > 0 else "-")
    _set_cella(rtot.cells[5], _fmt_giorni(dati.giorni_totali))


# ---------------------------------------------------------------------------
# Estrazione dati dai layer (lettura DBF diretta - testabile senza QGIS)
# ---------------------------------------------------------------------------
def _leggi_dbf(path: str):
    """Legge un .dbf e ritorna (lista_campi, lista_record_dict). Solo lettura."""
    import struct
    with open(path, "rb") as f:
        data = f.read()
    num_rec = struct.unpack('<I', data[4:8])[0]
    hdr_len = struct.unpack('<H', data[8:10])[0]
    rec_len = struct.unpack('<H', data[10:12])[0]
    campi = []
    pos = 32
    while data[pos] != 0x0D:
        name = data[pos:pos + 11].split(b'\x00')[0].decode('latin1')
        flen = data[pos + 16]
        campi.append((name, flen))
        pos += 32
    record = []
    for r in range(num_rec):
        rec = data[hdr_len + r * rec_len: hdr_len + (r + 1) * rec_len]
        if rec[:1] == b'*':          # record cancellato
            continue
        off = 1
        d = {}
        for name, flen in campi:
            d[name] = rec[off:off + flen].decode('latin1').strip()
            off += flen
        record.append(d)
    return [c[0] for c in campi], record


def leggi_tratte_da_layer(path_infrastrutture_dbf: str,
                          path_pozzetto_dbf: str,
                          solo_nuovo: bool = True) -> list:
    """Legge INFRASTRUTTURE e POZZETTO e costruisce una lista di Tratta
    AGGREGATA (una sola tratta complessiva con i metri per tecnica e i pozzetti
    per dimensione). Filtra STATO='Nuovo' se solo_nuovo.
    NB: aggrega tutto in un'unica tratta; la suddivisione per km si affina in UI.
    """
    metri = {}
    _, rec_i = _leggi_dbf(path_infrastrutture_dbf)
    for r in rec_i:
        if solo_nuovo and r.get("STATO", "").strip().lower() != "nuovo":
            continue
        tec = mappa_tecnica(r.get("TIPOLOGIA", ""))
        if not tec:
            continue
        try:
            L = float((r.get("LUNGHEZZA") or r.get("Lungh") or "0").replace(",", "."))
        except ValueError:
            L = 0.0
        metri[tec] = metri.get(tec, 0.0) + L

    pozzetti = {}
    if path_pozzetto_dbf and os.path.isfile(path_pozzetto_dbf):
        _, rec_p = _leggi_dbf(path_pozzetto_dbf)
        for r in rec_p:
            if solo_nuovo and r.get("STATO", "").strip().lower() != "nuovo":
                continue
            dim = (r.get("TIPO_POZZE") or "").strip()
            if dim:
                pozzetti[dim] = pozzetti.get(dim, 0) + 1

    # arrotonda i metri a 2 decimali
    metri = {k: round(v, 2) for k, v in metri.items() if v > 0}
    return [Tratta(km_da="", km_a="", metri=metri, pozzetti=pozzetti)]


# ---------------------------------------------------------------------------
# Stima chilometrica ferroviaria da cippi km (OSM railway=milestone)
# ---------------------------------------------------------------------------
KM_DA_VERIFICARE = "km da verificare"


def _dist_m(lat1, lon1, lat2, lon2):
    """Distanza approssimata in metri tra due punti lat/lon (equirettangolare)."""
    R = 6371000.0
    x = math.radians(lon2 - lon1) * math.cos(math.radians((lat1 + lat2) / 2))
    y = math.radians(lat2 - lat1)
    return math.sqrt(x * x + y * y) * R


def _fmt_progressiva(km_float: float) -> str:
    """0.99731 km -> 'km 99+731'. Input in KM (float)."""
    km_int = int(km_float)
    metri = int(round((km_float - km_int) * 1000))
    if metri == 1000:
        km_int += 1; metri = 0
    return f"{km_int}+{metri:03d}"


def stima_progressiva(lat: float, lon: float, cippi: list) -> str:
    """Stima la progressiva chilometrica di un punto dai cippi km.
    cippi = lista di dict {'km': float, 'lat': float, 'lon': float}.
    Strategia: trova i 2 cippi piu' vicini al punto; se sono CONSECUTIVI
    (|km differ| ~ 1) interpola linearmente sulla proiezione; altrimenti,
    se il gap e' troppo grande o manca un lato, ritorna KM_DA_VERIFICARE.
    """
    if not cippi or len(cippi) < 2:
        return KM_DA_VERIFICARE
    # ordina per distanza dal punto
    cin = sorted(cippi, key=lambda c: _dist_m(lat, lon, c["lat"], c["lon"]))
    a, b = cin[0], cin[1]
    d_ab = _dist_m(a["lat"], a["lon"], b["lat"], b["lon"])
    if d_ab == 0:
        return _fmt_progressiva(a["km"])
    # i due cippi devono essere "adiacenti" come km (gap <= 1.5 km)
    if abs(a["km"] - b["km"]) > 1.5:
        return KM_DA_VERIFICARE
    # proiezione del punto sul segmento a-b (in spazio metrico locale)
    def to_xy(la, lo):
        x = math.radians(lo - a["lon"]) * math.cos(math.radians(a["lat"])) * 6371000.0
        y = math.radians(la - a["lat"]) * 6371000.0
        return x, y
    px, py = to_xy(lat, lon)
    bx, by = to_xy(b["lat"], b["lon"])
    denom = bx * bx + by * by
    if denom == 0:
        return KM_DA_VERIFICARE
    t = (px * bx + py * by) / denom      # frazione lungo a->b
    t = max(0.0, min(1.0, t))
    km = a["km"] + (b["km"] - a["km"]) * t
    return _fmt_progressiva(km)


# ---------------------------------------------------------------------------
# Generazione documenti
# ---------------------------------------------------------------------------
def genera_istanze(dati: DatiIstanzaRFI, cartella_template: str,
                   cartella_out: str, solo_rt_pdf: bool = True,
                   documenti: Optional[list] = None) -> dict:
    """Compila i template selezionati. Ritorna {chiave: percorso_docx}.
    Non genera PDF qui (serve LibreOffice/Word); il chiamante decide."""
    from docx import Document
    os.makedirs(cartella_out, exist_ok=True)
    repls = {f"<<{k}>>": v for k, v in dati.valori_segnaposto().items()}
    documenti = documenti or list(TEMPLATE_FILES.keys())
    prodotti = {}
    for chiave in documenti:
        tpl = os.path.join(cartella_template, TEMPLATE_FILES[chiave])
        if not os.path.isfile(tpl):
            prodotti[chiave] = None
            continue
        doc = Document(tpl)
        _sostituisci_tutto(doc, repls)
        # riempimento tabelle solo nella Relazione Tecnica
        if chiave == "rt":
            riempi_tabelle_rt(doc, dati)
        out = os.path.join(cartella_out,
                           dati.nome_comune + OUT_SUFFIX[chiave] + ".docx")
        doc.save(out)
        prodotti[chiave] = out
    return prodotti
