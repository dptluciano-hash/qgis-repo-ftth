# -*- coding: utf-8 -*-
"""Planimetria 1.1 PL delle istanze acque (Consorzi, demanio idrico e
marittimo), sul modello delle pratiche Beexact (Besnate, Valderice).

Una PL per corso d'acqua (o costa), A3 orizzontale:
  - COROGRAFIA: una mappa sola; il corso d'acqua dell'istanza in evidenza con
    il suo nome, gli altri corsi sottili e anch'essi con il nome, le zone delle
    tavole cerchiate e tratteggiate ("TAV. n"), rosa dei venti e scala grafica;
  - TAVOLA n (una per zona): PLANIMETRIA grande al centro con il canale, la
    fascia, la rete, le interferenze numerate e una etichetta per ciascuna;
    a sinistra ORTOFOTO e STRALCIO CATASTALE; sotto SEZIONE e FOTO;
  - PC: particolari costruttivi.
Cartiglio a destra come RFI (legenda, loghi, dati), niente timbro.
Riusa i mattoni di ftth_rfi_layout. (c) Beexact S.r.l.
"""
import datetime
import math
import os

from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QColor, QFont
from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsFeature, QgsField,
    QgsFillSymbol, QgsGeometry, QgsLayoutExporter, QgsLayoutItemPage, QgsLayoutItemPicture,
    QgsLayoutItemScaleBar, QgsLayoutSize, QgsLineSymbol, QgsMarkerSymbol, QgsPalLayerSettings,
    QgsPointXY, QgsPrintLayout, QgsRectangle, QgsSingleSymbolRenderer, QgsTextBufferSettings,
    QgsTextFormat, QgsUnitTypes, QgsVectorLayer, QgsVectorLayerSimpleLabeling,
)

try:
    from . import ftth_rfi_layout as L
    from . import ftth_acque as A
except ImportError:
    import ftth_rfi_layout as L
    import ftth_acque as A

MM = L.MM
BLU = QColor(0, 110, 210)
BLU_SCURO = QColor(0, 60, 150)
ROSSO = QColor(200, 0, 0)


# --------------------------------------------------------------------------- #
#  Layer di servizio della PL
# --------------------------------------------------------------------------- #
def _mem(project, geom, nome, campi, legenda):
    vl = QgsVectorLayer("%s?crs=EPSG:4326" % geom, nome, "memory")
    vl.dataProvider().addAttributes([QgsField(n, t) for n, t in campi])
    vl.updateFields()
    vl.setCustomProperty("rfi/titolo_legenda", legenda)
    return vl


def _formato(dim, colore, grassetto=True, corsivo=False, alone=1.0):
    tf = QgsTextFormat()
    f = QFont("Arial", int(dim))
    f.setBold(grassetto)
    f.setItalic(corsivo)
    tf.setFont(f)
    tf.setSize(dim)
    tf.setColor(colore)
    b = QgsTextBufferSettings()
    b.setEnabled(alone > 0)
    b.setSize(alone)
    b.setColor(QColor(255, 255, 255))
    tf.setBuffer(b)
    return tf


def _etichetta_lungo_linea(vl, campo, dim, colore, ripeti_mm=90):
    pal = QgsPalLayerSettings()
    pal.fieldName = campo
    try:
        pal.placement = QgsPalLayerSettings.Curved
    except Exception:  # noqa: BLE001
        pass
    pal.repeatDistance = ripeti_mm
    try:
        pal.repeatDistanceUnit = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        pass
    try:
        pal.dist = 0.8
        pal.distUnits = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        pass
    try:
        # i canali in OSM sono spezzati in tratti corti: si uniscono quelli con
        # lo stesso nome prima di scrivere, e il nome puo' sporgere un poco
        # oltre la fine della linea. Cosi' ogni canale ha il suo nome (prima
        # "Canale Milani" non trovava spazio e spariva)
        ls = pal.lineSettings()
        ls.setMergeLines(True)
        ls.setOverrunDistance(6)
        try:
            ls.setOverrunDistanceUnit(QgsUnitTypes.RenderMillimeters)
        except Exception:  # noqa: BLE001
            pass
        pal.setLineSettings(ls)
    except Exception:  # noqa: BLE001
        pass
    pal.priority = 9
    # corsivo grassetto piccolo con alone bianco sottile: leggibile, non invadente
    pal.setFormat(_formato(dim, colore, True, True, 0.7))
    vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    vl.setLabelsEnabled(True)


def _copia_nomi_sempre(project, pref, corso_l):
    """Copia del corso d'acqua per la corografia: stesso stile e stessa
    legenda, ma il nome si scrive SEMPRE (QGIS cerca prima una posizione
    libera; se non c'e', accetta di toccare un'altra scritta). Alla scala
    della corografia un canale che passa sul pallino TAV. perdeva il nome."""
    vl = QgsVectorLayer("MultiLineString?crs=EPSG:4326", "%s - corso corografia" % pref, "memory")
    vl.dataProvider().addAttributes(corso_l.fields().toList())
    vl.updateFields()
    # un elemento per canale (tratti uniti): il nome si scrive UNA volta, sul
    # tratto piu' lungo, invece che su ogni pezzetto staccato
    per_nome, feats = {}, []
    for f in corso_l.getFeatures():
        chiave = (f["nome"] or "", f["voce"] if "voce" in f.fields().names() else "")
        per_nome.setdefault(chiave, []).append(f)
    for (nome, voce), lst in per_nome.items():
        g = QgsGeometry.unaryUnion([f.geometry() for f in lst])
        g.convertToMultiType()
        nf = QgsFeature(vl.fields())
        nf.setGeometry(g)
        nf["nome"] = nome
        if "voce" in vl.fields().names():
            nf["voce"] = voce
        feats.append(nf)
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    vl.setRenderer(corso_l.renderer().clone())
    for k in ("rfi/titolo_legenda", "rfi/titolo_nascosto"):
        if corso_l.customProperty(k) is not None:
            vl.setCustomProperty(k, corso_l.customProperty(k))
    try:
        pal = QgsPalLayerSettings(corso_l.labeling().settings())
        pal.displayAll = True
        try:
            from qgis.core import Qgis
            ps = pal.placementSettings()
            ps.setOverlapHandling(Qgis.LabelOverlapHandling.AllowOverlapIfRequired)
            pal.setPlacementSettings(ps)
        except Exception:  # noqa: BLE001
            pass
        vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        vl.setLabelsEnabled(True)
    except Exception:  # noqa: BLE001
        pass
    return L._aggiungi_base(project, vl)


def _layer_nomi_corti(project, pref, corsi_ist, scala, dim_pt=7):
    """Nomi dei canali troppo corti per stare lungo la linea alla `scala`
    della mappa (es. Canale Milani a 1:10000): un punto per canale con il
    nome in orizzontale accanto. None se tutti i nomi stanno sulla linea."""
    from shapely.ops import linemerge, unary_union
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    per_nome = {}
    for c in corsi_ist:
        if A._con_nome(c.nome):
            per_nome.setdefault(c.nome.upper(), []).append(c.geom)
    if not per_nome:
        return None
    c0 = unary_union([g for gs in per_nome.values() for g in gs]).centroid
    pr = R._Proiezione(c0.x, c0.y)
    corti = []
    for nome, geoms in per_nome.items():
        u = linemerge(unary_union([pr.avanti(g) for g in geoms]))
        parti = list(getattr(u, "geoms", [u]))
        # conta il tratto DRITTO piu' lungo (linea semplificata), non la
        # lunghezza totale: un canale a gomiti e' lungo ma il nome curvo non
        # ci sta (Canale Milani a 1:10000)
        from shapely.geometry import LineString
        segmenti = []
        for p in parti:
            s = p.simplify(scala / 1000.0 * 1.5)          # 1,5 mm di tolleranza sulla carta
            cs = list(s.coords)
            segmenti += [LineString([a, b]) for a, b in zip(cs[:-1], cs[1:])]
        dritto = max(segmenti, key=lambda q: q.length) if segmenti else parti[0]
        testo_m = len(nome) * dim_pt * 0.36 * 0.62 * scala / 1000.0   # mm -> m alla scala
        if dritto.length < testo_m * 1.5:
            p = pr.indietro(dritto.interpolate(0.5, normalized=True))
            corti.append((nome, p))
    if not corti:
        return None
    vl = _mem(project, "Point", "%s - nomi corti 1:%d" % (pref, scala),
              [("nome", QVariant.String)], "")
    feats = []
    for nome, p in corti:
        f = QgsFeature(vl.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(p.x, p.y)))
        f["nome"] = nome
        feats.append(f)
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    vl.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "0,0,0,0", "outline_color": "0,0,0,0", "size": "1"})))
    pal = QgsPalLayerSettings()
    pal.fieldName = "nome"
    try:
        pal.placement = QgsPalLayerSettings.OrderedPositionsAroundPoint
        pal.dist = 1.0
        pal.distUnits = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        pass
    pal.priority = 9
    pal.displayAll = True
    pal.setFormat(_formato(dim_pt, BLU_SCURO, True, True, 0.7))
    vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    vl.setLabelsEnabled(True)
    return L._aggiungi_base(project, vl)


def _layer_corsi(project, pref, corsi_ist, altri, alvei, fasce, costa=None):
    """Corso d'acqua dell'istanza (in evidenza, con nome), altri corsi
    (sottili, con nome) e fascia di rispetto dei soli corsi dell'istanza.
    Con piu' corsi d'acqua (istanza unica per ente) la legenda ha una voce
    per ognuno col suo nome, tutte con lo stesso simbolo blu; i tratti senza
    nome stanno in un'unica voce. fasce = {categoria: metri}."""
    from shapely.ops import unary_union
    from qgis.core import QgsCategorizedSymbolRenderer, QgsRendererCategory
    try:
        from . import ftth_rfi as R
    except ImportError:
        import ftth_rfi as R
    voci, etich, cat_voce = [], {}, {}
    for c in corsi_ist:
        v = A.nome_corso_istanza(c.nome, c.categoria)
        if v not in voci:
            voci.append(v)
        cat_voce.setdefault(v, c.categoria)
        if c.categoria == "marittimo":
            # demanio marittimo: in legenda la linea da cui partono i 30 m
            # (dividente con la sua fonte, o la costa OSM detta come tale)
            if v not in etich or c.fonte != A.FONTE_OSM:
                etich[v] = A.legenda_marittimo(c.fonte)
        else:
            etich.setdefault(v, v.upper())
    # prima i corsi con nome, in ordine alfabetico; i "senza nome" in fondo
    voci.sort(key=lambda v: (not A._con_nome(v), v.lower()))
    titolo = etich[voci[0]] if len(voci) == 1 else "Corsi d'acqua dell'istanza"
    corso = _mem(project, "LineString", "%s - corso" % pref,
                 [("nome", QVariant.String), ("voce", QVariant.String)], titolo)
    feats = []
    for c in corsi_ist:
        f = QgsFeature(corso.fields())
        f.setGeometry(QgsGeometry.fromWkt(c.geom.wkt))
        # la dividente non ha un nome da scrivere lungo la linea: basta la legenda
        f["nome"] = c.nome.upper() if (A._con_nome(c.nome) and c.categoria != "marittimo") else ""
        f["voce"] = A.nome_corso_istanza(c.nome, c.categoria)
        feats.append(f)
    corso.dataProvider().addFeatures(feats)

    def _simbolo(cat=None):
        if cat == "marittimo":
            # dividente come nelle pratiche della Regione: linea magenta
            return QgsLineSymbol.createSimple({"line_color": "230,0,200,255",
                                               "line_width": "0.6", "capstyle": "round"})
        return QgsLineSymbol.createSimple({"line_color": "%d,%d,%d,255" % BLU.getRgb()[:3],
                                           "line_width": "0.8", "capstyle": "round"})
    if len(voci) > 1:
        corso.setRenderer(QgsCategorizedSymbolRenderer(
            "voce", [QgsRendererCategory(v, _simbolo(cat_voce.get(v)), etich[v]) for v in voci]))
        # in legenda solo le voci, senza la riga del nome del layer
        corso.setCustomProperty("rfi/titolo_nascosto", True)
    else:
        corso.setRenderer(QgsSingleSymbolRenderer(_simbolo(cat_voce.get(voci[0]) if voci
                                                           else None)))
    _etichetta_lungo_linea(corso, "nome", 7, BLU_SCURO, 110)
    corso.updateExtents()

    alt = _mem(project, "LineString", "%s - altri corsi" % pref,
               [("nome", QVariant.String)], "Altri corsi d'acqua")
    feats = []
    for c in altri:
        f = QgsFeature(alt.fields())
        f.setGeometry(QgsGeometry.fromWkt(c.geom.wkt))
        f["nome"] = c.nome if A._con_nome(c.nome) else ""
        feats.append(f)
    alt.dataProvider().addFeatures(feats)
    alt.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
        {"line_color": "120,180,230,255", "line_width": "0.45"})))
    _etichetta_lungo_linea(alt, "nome", 7, QColor(70, 120, 170), 120)
    alt.updateExtents()

    # fascia: ogni categoria con la sua misura; in legenda le misure diverse
    cats = []
    for c in corsi_ist:
        if c.categoria not in cats:
            cats.append(c.categoria)
    misure = {k: float(fasce.get(k, 10.0)) for k in cats}
    if cats == ["marittimo"]:
        da_dividente = any(c.fonte != A.FONTE_OSM for c in corsi_ist)
        testo = "Fascia di rispetto %g m dalla\n%s (art. 55 Cod. Nav.)" % (
            misure["marittimo"], "dividente demaniale" if da_dividente else "linea di costa")
    elif len(set(misure.values())) <= 1:
        testo = "Fascia di rispetto (%g m)" % (next(iter(misure.values())) if misure else 10.0)
    else:
        nomi = {"demanio": "demanio idrico", "bonifica": "bonifica", "marittimo": "demanio marittimo"}
        testo = "Fascia di rispetto (%s)" % ", ".join(
            "%g m %s" % (misure[k], nomi.get(k, k)) for k in cats)
    fas = _mem(project, "Polygon", "%s - fascia" % pref, [("m", QVariant.Double)], testo)
    if corsi_ist:
        c0 = unary_union([c.geom for c in corsi_ist]).centroid
        pr = R._Proiezione(c0.x, c0.y)
        al_tutti = [pr.avanti(a) for a in alvei]
        pezzi = []
        for k in cats:
            if k == "marittimo":
                # solo verso terra (con la dividente: spiaggia demaniale + 30 m)
                costa_m = [pr.avanti(c.geom) for c in (costa or [])
                           if c.categoria == "marittimo" and c.fonte == A.FONTE_OSM]
                zona, _ori = A.zona_marittima_m(
                    [(pr.avanti(c.geom), c.fonte == A.FONTE_OSM)
                     for c in corsi_ist if c.categoria == k], misure[k], costa_m)
                pezzi.append(zona)
                continue
            u = unary_union([pr.avanti(c.geom) for c in corsi_ist if c.categoria == k])
            al = [a for a in al_tutti if a.intersects(u)]
            if al:
                u = unary_union([u] + al)
            pezzi.append(u.buffer(misure[k]))
        f = QgsFeature(fas.fields())
        f.setGeometry(QgsGeometry.fromWkt(pr.indietro(unary_union(pezzi)).wkt))
        f["m"] = max(misure.values()) if misure else 10.0
        fas.dataProvider().addFeatures([f])
    fas.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
        {"color": "90,170,240,45", "outline_color": "0,110,210,255",
         "outline_width": "0.35", "outline_style": "dash"})))
    fas.updateExtents()
    return [L._aggiungi_base(project, l) for l in (corso, alt, fas)]


def _layer_interferenze(project, pref, ist):
    """Interferenze numerate (cerchietto blu con il numero, su ortofoto e
    catastale) ed etichette della planimetria: UNA PER ELEMENTO (ogni scavo
    con tecnica e metri, ogni pozzetto, l'armadio), senza numero. Le
    etichette vicine si accorpano solo in tavola, se non c'e' spazio
    (_etichette_tavola). Un testo scritto a mano nella scheda resta un'unica
    etichetta per quell'interferenza (tipo 'libera')."""
    num = _mem(project, "Point", "%s - numeri" % pref, [("n", QVariant.Int)],
               "Interferenza n.")
    et = _mem(project, "Point", "%s - etichette" % pref,
              [("testo", QVariant.String), ("tipo", QVariant.String), ("interf", QVariant.Int),
               ("px", QVariant.Double), ("py", QVariant.Double),
               ("chiave", QVariant.String), ("gruppo", QVariant.String)], "")
    fn, fe = [], []

    def _voce(lon, lat, testo, tipo, chiave, tav, gruppo=""):
        f = QgsFeature(et.fields())
        f.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(lon, lat)))
        f["testo"] = testo
        f["tipo"] = tipo
        f["chiave"] = chiave
        f["interf"] = tav
        f["gruppo"] = gruppo
        fe.append(f)
    for n, i in enumerate(ist.interferenze, 1):
        p = QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
        f = QgsFeature(num.fields())
        f.setGeometry(p)
        f["n"] = n
        fn.append(f)
        tav = i.tavola or 1
        if i.etichetta:
            _voce(i.lon, i.lat, i.etichetta, "libera", "", tav)
            continue
        messe = 0
        for e in i.elementi:
            t = e.get("tipo")
            # testo corretto a mano per QUESTO elemento (finestra della scheda):
            # va cosi' com'e', gli altri restano automatici
            mod = (e.get("testo") or "").strip()
            if t == "scavo" and e.get("metri"):
                tec = A.TECNICA_ETICHETTA.get(e.get("tecnica"), str(e.get("tecnica")).upper())
                if mod:
                    _voce(e["lon"], e["lat"], mod, "scavo_mod", tec, tav, e.get("gruppo") or "")
                else:
                    _voce(e["lon"], e["lat"], A.testo_elemento_auto(e), "scavo", tec, tav,
                          e.get("gruppo") or "")
                messe += 1
            elif t == "pozzetto" and e.get("dim"):
                # misura come nel progetto (= legenda): 40x76, non 76X40
                dim = str(e.get("dim_testo") or e["dim"]).upper()
                if mod:
                    _voce(e["lon"], e["lat"], mod, "pozzetto_mod", dim, tav, e.get("gruppo") or "")
                else:
                    _voce(e["lon"], e["lat"], A.testo_elemento_auto(e), "pozzetto", dim, tav,
                          e.get("gruppo") or "")
                messe += 1
            elif t == "armadio":
                _voce(e["lon"], e["lat"], mod or A.testo_elemento_auto(e),
                      "armadio_mod" if mod else "armadio", "armadio", tav)
                messe += 1
        if not messe:
            # niente scavi ne' pozzetti (posa aerea, sul ponte): etichetta al punto
            _voce(i.lon, i.lat, A.etichetta_automatica(i), "libera", "", tav)
    num.dataProvider().addFeatures(fn)
    et.dataProvider().addFeatures(fe)
    num.updateExtents()
    et.updateExtents()
    # numero DENTRO il simbolo (carattere centrato sul cerchio): come
    # etichetta il motore lo spostava e usciva storto rispetto al cerchio
    sym = QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "0,110,210,255", "outline_color": "255,255,255,255",
         "outline_width": "0.4", "size": "5"})
    try:
        from qgis.core import QgsFontMarkerSymbolLayer, QgsProperty, QgsSymbolLayer
        fm = QgsFontMarkerSymbolLayer("Arial", "0", 3.2, QColor(255, 255, 255))
        try:
            fm.setFontStyle("Bold")
        except Exception:  # noqa: BLE001
            pass
        fm.setStrokeWidth(0)
        fm.setDataDefinedProperty(QgsSymbolLayer.PropertyCharacter,
                                  QgsProperty.fromExpression('to_string("n")'))
        # due cifre: carattere un po' piu' piccolo per restare nel cerchio
        fm.setDataDefinedProperty(QgsSymbolLayer.PropertySize,
                                  QgsProperty.fromExpression('CASE WHEN "n" >= 10 THEN 2.6 ELSE 3.2 END'))
        sym.appendSymbolLayer(fm)
        num.setRenderer(QgsSingleSymbolRenderer(sym))
        num.setLabelsEnabled(False)
    except Exception:  # noqa: BLE001
        num.setRenderer(QgsSingleSymbolRenderer(sym))
        pal = QgsPalLayerSettings()
        pal.fieldName = "n"
        pal.placement = QgsPalLayerSettings.OverPoint
        pal.setFormat(_formato(8, QColor(255, 255, 255), True, False, 0))
        pal.displayAll = True
        num.setLabeling(QgsVectorLayerSimpleLabeling(pal))
        num.setLabelsEnabled(True)

    et.setRenderer(QgsSingleSymbolRenderer(QgsMarkerSymbol.createSimple(
        {"name": "circle", "color": "0,0,0,0", "outline_color": "0,0,0,0", "size": "1"})))
    pal = QgsPalLayerSettings()
    pal.fieldName = "testo"
    pal.priority = 10
    try:
        from qgis.core import QgsProperty, QgsSimpleLineCallout
        c = QgsSimpleLineCallout()
        c.setEnabled(True)
        c.setLineSymbol(QgsLineSymbol.createSimple({"line_color": "200,0,0,255",
                                                    "line_width": "0.18"}))
        pal.setCallout(c)
        dd = pal.dataDefinedProperties()
        dd.setProperty(QgsPalLayerSettings.PositionX, QgsProperty.fromField("px"))
        dd.setProperty(QgsPalLayerSettings.PositionY, QgsProperty.fromField("py"))
        dd.setProperty(QgsPalLayerSettings.Hali, QgsProperty.fromValue("Center"))
        dd.setProperty(QgsPalLayerSettings.Vali, QgsProperty.fromValue("Half"))
        dd.setProperty(QgsPalLayerSettings.AlwaysShow,
                       QgsProperty.fromExpression("\"px\" IS NOT NULL"))
    except Exception:  # noqa: BLE001
        pass
    # riquadro bianco bordato di rosso dietro l'etichetta: si legge su
    # qualunque sfondo e non si confonde con le scritte della cartografia
    # etichetta leggera: 7 pt, riquadro bianco stretto con bordo rosso sottile
    tf = _formato(PT_ETICHETTE, ROSSO, True, False, 0)
    try:
        from qgis.core import QgsTextBackgroundSettings
        from qgis.PyQt.QtCore import QSizeF
        bg = QgsTextBackgroundSettings()
        bg.setEnabled(True)
        bg.setFillColor(QColor(255, 255, 255, 240))
        bg.setStrokeColor(ROSSO)
        bg.setStrokeWidth(0.15)
        bg.setSizeType(QgsTextBackgroundSettings.SizeBuffer)
        bg.setSize(QSizeF(0.8, 0.4))
        tf.setBackground(bg)
    except Exception:  # noqa: BLE001
        tf = _formato(PT_ETICHETTE, ROSSO, True, False, 1.0)
    pal.setFormat(tf)
    et.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    et.setLabelsEnabled(True)
    return L._aggiungi_base(project, num), L._aggiungi_base(project, et)


def _ostacoli_tavola(project, vis, centro, scala, w_mm, h_mm, crs, linee_layer, punti_layer):
    """Segmenti (scavi, corso d'acqua) e riquadri (pozzetti) in mm della
    planimetria, che le etichette non devono coprire.
    linee_layer = [(layer, peso)]; punti_layer = [layer]."""
    k_mm = 1000.0 / scala
    largo = QgsRectangle(vis)
    largo.grow(20.0 / k_mm)

    def mm(p):
        return ((p.x() - centro.x()) * k_mm + w_mm / 2.0,
                h_mm / 2.0 - (p.y() - centro.y()) * k_mm)
    linee, box = [], []
    for lyr, peso in linee_layer:
        if lyr is None:
            continue
        t = QgsCoordinateTransform(lyr.crs(), crs, project)
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = QgsGeometry(f.geometry())
            g.transform(t)
            if not g.boundingBox().intersects(largo):
                continue
            if g.type() == 2:                      # poligono (fascia): conta il bordo
                g = QgsGeometry(g.constGet().boundary()).simplify(1.0 / k_mm)
            parti = g.asMultiPolyline() if g.isMultipart() else [g.asPolyline()]
            for linea in parti:
                for a, b in zip(linea[:-1], linea[1:]):
                    linee.append((mm(a), mm(b), peso))
    for lyr in punti_layer:
        if lyr is None:
            continue
        t = QgsCoordinateTransform(lyr.crs(), crs, project)
        for f in lyr.getFeatures():
            if not f.hasGeometry():
                continue
            g = QgsGeometry(f.geometry())
            g.transform(t)
            p = g.centroid().asPoint()
            if largo.contains(p):
                x, y = mm(p)
                box.append((x - 2.5, y - 2.5, x + 2.5, y + 2.5))
    return linee, box


PT_ETICHETTE = 7.0                       # corpo delle etichette di scavi e pozzetti


def _box_etichetta_acque(testo):
    """Ingombro in mm di un'etichetta (Arial grassetto maiuscolo 7 pt) con il
    suo riquadro bianco, piu' un filo d'aria."""
    mm = PT_ETICHETTE * 25.4 / 72.0
    righe = (testo or "").split("\n")
    w = max(len(r) for r in righe) * mm * 0.66 + 2.6
    h = len(righe) * mm * 1.25 + 1.8
    return w, h


def _etichette_tavola(project, pref, k, ist, et_l, vis, centro, scala, w_mm, h_mm, tr, tr_inv,
                      linee=None, ostacoli=None, unire=True):
    """Layer delle etichette della tavola k: tutte le interferenze che cadono
    nel riquadro della planimetria, con la posizione calcolata da
    ftth_acque.disponi_etichette (niente sovrapposizioni, richiami che non si
    incrociano, nessuna etichetta sopra scavi, pozzetti o corso d'acqua).
    Stessa vestizione di et_l."""
    k_mm = 1000.0 / scala
    vl = QgsVectorLayer("Point?crs=EPSG:4326", "%s - etichette tav %d" % (pref, k), "memory")
    vl.dataProvider().addAttributes(et_l.fields().toList())
    vl.updateFields()
    margine_dentro = 3.0 / k_mm           # 3 mm dal bordo
    interno = QgsRectangle(vis)
    interno.grow(-margine_dentro)
    voci = []
    for f in et_l.getFeatures():
        p = tr.transform(f.geometry().asPoint())
        if not interno.contains(p):
            continue
        voci.append(((p.x() - centro.x()) * k_mm + w_mm / 2.0,
                     h_mm / 2.0 - (p.y() - centro.y()) * k_mm,
                     f["testo"], f["tipo"], f["chiave"] or "", f["gruppo"] or ""))

    def _dim(testo):
        return _box_etichetta_acque(testo)
    # prima un'etichetta per scavo e per pozzetto; se non stanno senza
    # sovrapposizioni, incroci o etichette sopra gli scavi, si unisce ogni
    # scavo con i SUOI pozzetti (mai scavi diversi fra loro)
    scelta = None
    try:        # casella «Etichette accorpate» (passo 5 delle schede istanze)
        from qgis.core import QgsSettings
        if str(QgsSettings().value("ftth_permessi/etichette_accorpate", "true")).lower() \
                in ("false", "0"):
            unire = False
    except Exception:  # noqa: BLE001
        pass
    for unisci in ((False, True) if unire else (False,)):
        gruppi = A.accorpa_etichette(voci, unisci)
        ancore = [(x, y) for x, y, _t in gruppi]
        dim = [_dim(t) for _x, _y, t in gruppi]
        pos = A.disponi_etichette(ancore, dim, w_mm, h_mm, ostacoli=ostacoli, linee=linee)
        n_conf = A.conflitti_etichette(ancore, dim, pos, w_mm, h_mm,
                                       [l for l in (linee or []) if l[2] >= 3000])
        if scelta is None or n_conf < scelta[0]:
            scelta = (n_conf, gruppi, pos)
        if n_conf == 0:
            break
    _n, gruppi, pos = scelta
    feats = []
    for x, y, testo in gruppi:
        g = QgsFeature(vl.fields())
        g.setGeometry(QgsGeometry.fromPointXY(tr_inv.transform(QgsPointXY(
            centro.x() + (x - w_mm / 2.0) / k_mm, centro.y() + (h_mm / 2.0 - y) / k_mm))))
        g["testo"] = testo
        g["tipo"] = "scavo"
        g["interf"] = k
        feats.append(g)
    for g, (cx, cy) in zip(feats, pos):
        q = tr_inv.transform(QgsPointXY(centro.x() + (cx - w_mm / 2.0) / k_mm,
                                        centro.y() + (h_mm / 2.0 - cy) / k_mm))
        # px/py nel CRS del layer (EPSG:4326), come la vestizione si aspetta
        g["px"] = q.x()
        g["py"] = q.y()
    # etichette spostate a mano nel layer «Etichette PL (spostabili)»
    try:
        fin = L.posizioni_manuali(project, ist.nome_base, [
            (g["testo"], g.geometry().asPoint().x(), g.geometry().asPoint().y(),
             g["px"], g["py"]) for g in feats])
        for g, (x, y) in zip(feats, fin):
            g["px"], g["py"] = x, y
    except Exception:  # noqa: BLE001
        pass
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    vl.setRenderer(et_l.renderer().clone())
    vl.setLabeling(et_l.labeling().clone())
    vl.setLabelsEnabled(True)
    return L._aggiungi_base(project, vl)


def testo_interferenza(n, i):
    """Etichetta in tavola: numero + testo (corretto a mano nella scheda o
    quello proposto)."""
    return A.testo_etichetta(n, i)


def _layer_aree(project, pref, ist, tr, tr_inv, riquadri):
    """Corografia: l'impronta di ogni tavola come riquadro (convenzione delle
    tavole urbanistiche: «vedi TAV. n»), bordo grigio antracite tratto-punto
    senza riempimento, con TAV. n accanto. Prima era un pallino blu.
    riquadri = [QgsRectangle] nel CRS metrico, uno per tavola."""
    vl = _mem(project, "Polygon", "%s - zone tavole" % pref, [("tav", QVariant.String)],
              "Inquadramento delle tavole")
    feats = []
    for k, rect in enumerate(riquadri, 1):
        g = QgsGeometry.fromRect(rect)
        g.transform(tr_inv)
        f = QgsFeature(vl.fields())
        f.setGeometry(g)
        f["tav"] = "TAV. %d" % k
        feats.append(f)
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()
    from qgis.core import QgsSimpleLineSymbolLayer
    sym = QgsFillSymbol.createSimple({"color": "255,255,255,40", "outline_style": "no"})
    alone = QgsSimpleLineSymbolLayer(QColor(255, 255, 255, 200), 0.9)   # stacca dall'ortofoto
    sym.appendSymbolLayer(alone)
    bordo = QgsSimpleLineSymbolLayer(QColor(45, 45, 45, 255), 0.4)
    bordo.setPenStyle(Qt.DashDotLine)
    sym.appendSymbolLayer(bordo)
    vl.setRenderer(QgsSingleSymbolRenderer(sym))
    pal = QgsPalLayerSettings()
    pal.fieldName = "tav"
    try:
        # fuori dal riquadro, accanto al bordo
        pal.placement = QgsPalLayerSettings.OutsidePolygons
        pal.dist = 0.8
        pal.distUnits = QgsUnitTypes.RenderMillimeters
    except Exception:  # noqa: BLE001
        try:
            pal.placement = QgsPalLayerSettings.AroundPoint
        except Exception:  # noqa: BLE001
            pass
    pal.setFormat(_formato(7.5, QColor(45, 45, 45), True, False, 0.8))
    pal.displayAll = True
    vl.setLabeling(QgsVectorLayerSimpleLabeling(pal))
    vl.setLabelsEnabled(True)
    return L._aggiungi_base(project, vl)


def _layer_solo_nome(project, pref, corso_l):
    """Copia del corso d'acqua senza linea, con il solo nome: sullo stralcio
    catastale la linea copriva particelle e numeri."""
    vl = QgsVectorLayer("LineString?crs=EPSG:4326", "%s - nome corso" % pref, "memory")
    vl.dataProvider().addAttributes(corso_l.fields().toList())
    vl.updateFields()
    vl.dataProvider().addFeatures(list(corso_l.getFeatures()))
    vl.updateExtents()
    vl.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
        {"line_color": "0,0,0,0", "line_width": "0.1"})))
    _etichetta_lungo_linea(vl, "nome", 7, BLU_SCURO, 90)
    return L._aggiungi_base(project, vl)


def rete_dal_gruppo(project, ist, copia_filtrata, prefisso, log=None):
    """(infra, pozz, arm) per la PL dal gruppo dell'istanza nel progetto
    (Istanze > sezione > istanza), o None se il gruppo non c'è."""
    try:
        try:
            from . import ftth_gruppi_istanze as GR
        except ImportError:
            import ftth_gruppi_istanze as GR
        rete = GR.rete_per_pl(project, ist, copia_filtrata, prefisso)
        if rete and rete[0] is not None:
            if log:
                extra = GR.elementi_in_piu(project, ist)
                log("rete in tavola dagli elementi con il nome dell'istanza negli shape%s" % (
                    " (%d aggiunti a mano)" % extra
                    if extra else ""))
            return rete
    except Exception as e:  # noqa: BLE001
        if log:
            log("gruppo dell'istanza non usato (%s): rete dai layer principali" % e)
    return None


def rete_sempre_visibile(infra):
    """Le tratte senza TIPOLOGIA (posa aerea o in tubo esistente) non hanno una
    categoria nello stile del progetto e sparivano dalla planimetria: si
    aggiunge la voce 'tutti gli altri valori', cosi' l'elemento si vede e
    compare in legenda."""
    try:
        from qgis.core import (QgsCategorizedSymbolRenderer, QgsRendererCategory,
                               QgsRuleBasedRenderer, QgsExpression, QgsExpressionContext,
                               QgsExpressionContextUtils)
        r = infra.renderer() if infra is not None else None
        if isinstance(r, QgsRuleBasedRenderer):
            # stile a regole (es. Eboli): la regola 'Aerea' (TIPOLOGIA vuota) e'
            # spenta nel progetto. Nella copia si accendono le regole spente
            # che riguardano davvero le tratte dell'istanza, tranne esistenti
            # e refusi (ELSE)
            ctx = QgsExpressionContext()
            ctx.appendScopes(QgsExpressionContextUtils.globalProjectLayerScopes(infra))
            feats = list(infra.getFeatures())
            for ru in r.rootRule().children():
                if ru.active() or ru.isElse() or not ru.filterExpression():
                    continue
                if "esistent" in (ru.label() or "").lower():
                    continue
                ex = QgsExpression(ru.filterExpression())
                for f in feats:
                    ctx.setFeature(f)
                    if ex.evaluate(ctx):
                        ru.setActive(True)
                        break
            infra.triggerRepaint()
            return
        if not isinstance(r, QgsCategorizedSymbolRenderer):
            return
        if any(c.value() in (None, "") or str(c.value()) == "NULL" for c in r.categories()):
            return
        sym = QgsLineSymbol.createSimple({"line_color": "90,90,90,255", "line_width": "0.6",
                                          "line_style": "dash"})
        r.addCategory(QgsRendererCategory("", sym, "Posa senza scavo"))
        infra.triggerRepaint()
    except Exception:  # noqa: BLE001
        pass


def titolo_da_file(path, predefinito):
    """Titolo del riquadro dal nome del file: 'SEZIONE A-A'.svg' -> "SEZIONE
    A-A'", 'FOTO-56.jpg' -> 'FOTO 56'. I particolari del plugin (PC-..)
    tengono il titolo della tecnica."""
    import re
    nome = os.path.splitext(os.path.basename(path or ""))[0]
    if not nome or re.match(r"^PC-\d+", nome, re.I):
        return predefinito
    t = nome.upper()
    t = re.sub(r"^FOTO[-_ ]?(\d+)$", r"FOTO \1", t)
    return t.replace("_", " ").strip() or predefinito


# --------------------------------------------------------------------------- #
#  Elementi di pagina
# --------------------------------------------------------------------------- #
def _voce_interferenze(layout, pagina, titolo="INTERFERENZE", voce="Interferenza"):
    """Voce di legenda dei cerchietti blu numerati. Sono su ortofoto e
    catastale, non in planimetria, e la legenda (filtrata sulla planimetria)
    li escludeva: si disegna a mano in fondo al riquadro LEGENDA, con lo
    stesso stile delle altre voci."""
    from qgis.core import QgsLayoutItemShape, QgsLayoutItemLegend
    pw, ph = L.PAGINA
    cx = pw - L.MARGINE - L.CART_W
    x = cx + 3 + 2.8                    # allineata ai titoli di blocco della legenda
    # in testa alla legenda, subito sotto il titolo LEGENDA: le altre voci
    # scendono di poco. In fondo restava staccata dalle voci (l'altezza vera
    # della legenda filtrata non si puo' misurare prima della stampa).
    # Posizioni nella PAGINA, non nel layout (che somma le pagine).
    ALTO = 13.0
    y = L.MARGINE + 13
    for it in layout.items():
        if isinstance(it, QgsLayoutItemLegend) and it.page() == pagina:
            try:
                p = it.pagePositionWithUnits()
                s = it.sizeWithUnits()
                y = p.y() + 1.0
                it.attemptMove(L.QgsLayoutPoint(p.x(), p.y() + ALTO, MM), True, False, pagina)
                it.attemptResize(L.QgsLayoutSize(s.width(), s.height() - ALTO, MM))
            except Exception:  # noqa: BLE001
                pass
    L._lbl(layout, pagina, x - 1, y, L.CART_W - 14, 5, titolo, 9, True, Qt.AlignLeft)
    sh = QgsLayoutItemShape(layout)
    sh.setShapeType(QgsLayoutItemShape.Ellipse)
    layout.addLayoutItem(sh)
    L._mv(sh, x + 1.5, y + 6.2, 4.6, 4.6, pagina)
    try:
        sym = sh.symbol()
        sym.setColor(QColor(0, 110, 210))
        sym.symbolLayer(0).setStrokeColor(QColor(255, 255, 255))
        sym.symbolLayer(0).setStrokeWidth(0.4)
    except Exception:  # noqa: BLE001
        pass
    L._lbl(layout, pagina, x + 1.5, y + 6.2, 4.6, 4.6, "1", 7, True, colore=QColor(255, 255, 255))
    L._lbl(layout, pagina, x + 10.5, y + 5.4, L.CART_W - 22, 6.4, voce, 9, False,
           Qt.AlignLeft)


def _nord(layout, pagina, x, y, mappa, lato=16):
    try:
        pic = QgsLayoutItemPicture(layout)
        pic.setPicturePath(":/images/north_arrows/layout_default_north_arrow.svg")
        pic.setLinkedMap(mappa)
        layout.addLayoutItem(pic)
        L._mv(pic, x, y, lato, lato, pagina)
    except Exception:  # noqa: BLE001
        L._lbl(layout, pagina, x, y, lato, lato, "N\n↑", 12, True)


def _scala_grafica(layout, pagina, x, y, mappa):
    try:
        sb = QgsLayoutItemScaleBar(layout)
        sb.setStyle("Single Box")
        sb.setLinkedMap(mappa)
        sb.applyDefaultSize()
        sb.setNumberOfSegmentsLeft(0)
        sb.setNumberOfSegments(2)
        layout.addLayoutItem(sb)
        sb.attemptMove(L.QgsLayoutPoint(x, y, MM), True, False, pagina)
        sb.setBackgroundEnabled(True)
        sb.setBackgroundColor(QColor(255, 255, 255, 220))
    except Exception:  # noqa: BLE001
        pass


# direzione del tratteggio per tipo di vincolo (gradi); il resto: 45° o 135°
ANGOLO_RETINO = {"art136": 45, "unesco": 0, "centro_storico": 0, "bene_culturale": 0,
                 "archeologia": 90, "art142m": 90, "parco": 45, "natura2000": 135}


def _layer_vincoli(project, pref, aree, titolo, ritaglio=None):
    """Aree vincolate per le PL di Soprintendenza e Parchi / Natura 2000:
    tratteggio obliquo col bordo, un colore per tipo di vincolo e una voce di
    legenda per articolo (o per parco / sito).
    `ritaglio` (shapely, WGS84): i poligoni si tagliano attorno all'istanza e
    si semplificano (~1 m). Un sito Natura 2000 intero, con migliaia di
    vertici, disegnato in ogni tavola faceva PDF da 50-70 MB."""
    from qgis.core import (QgsCategorizedSymbolRenderer, QgsRendererCategory,
                           QgsLinePatternFillSymbolLayer, QgsSimpleLineSymbolLayer)
    try:
        from . import ftth_vincoli as V
    except ImportError:
        import ftth_vincoli as V
    vl = _mem(project, "MultiPolygon", "%s - vincoli" % pref,
              [("voce", QVariant.String), ("tipo", QVariant.String)], titolo)
    feats, voci = [], []
    for a in aree:
        if a.geom is None:
            continue
        g = a.geom
        try:
            if ritaglio is not None:
                g = g.intersection(ritaglio)
            g = g.simplify(0.00001, preserve_topology=True)
        except Exception:  # noqa: BLE001
            g = a.geom
        if g.is_empty:
            continue
        f = QgsFeature(vl.fields())
        f.setGeometry(QgsGeometry.fromWkt(g.wkt))
        v = V.voce_pulita(a.voce())
        f["voce"] = v
        f["tipo"] = a.tipo
        feats.append(f)
        if (v, a.tipo) not in voci:
            voci.append((v, a.tipo))
    vl.dataProvider().addFeatures(feats)
    vl.updateExtents()

    def _simbolo(tipo):
        r, g, b = V.COLORI_AREA.get(tipo, (200, 30, 30))
        if str(tipo).startswith("strada_"):
            # strade: velo leggero e bordo tratteggiato; il tratteggio pieno a
            # 1:500 copriva mezza tavola e toglieva risalto a scavi ed etichette
            sym = QgsFillSymbol.createSimple({"color": "%d,%d,%d,%d" % (
                r, g, b, 22 if tipo == "strada_fascia" else 45), "outline_style": "no"})
            bordo = QgsSimpleLineSymbolLayer(QColor(r, g, b, 220),
                                             0.35 if tipo == "strada_fascia" else 0.25)
            bordo.setPenStyle(Qt.DashLine if tipo == "strada_fascia" else Qt.SolidLine)
            sym.appendSymbolLayer(bordo)
            return sym
        # retino da tavola urbanistica: velo appena accennato, tratteggio
        # sottile e fitto, bordo continuo. Direzioni diverse per famiglia di
        # vincolo (art. 136 a 45°, art. 142 a 135°, ...) così le sovrapposizioni
        # si leggono come incrocio invece di confondersi
        sym = QgsFillSymbol.createSimple({"color": "%d,%d,%d,18" % (r, g, b),
                                          "outline_style": "no"})
        trat = QgsLinePatternFillSymbolLayer()
        trat.setLineAngle(ANGOLO_RETINO.get(tipo, 135 if str(tipo).startswith("art142") else 45))
        trat.setDistance(1.6)
        trat.setLineWidth(0.15)
        trat.setColor(QColor(r, g, b, 170))
        try:
            trat.subSymbol().setColor(QColor(r, g, b, 170))
            trat.subSymbol().setWidth(0.15)
        except Exception:  # noqa: BLE001
            pass
        sym.appendSymbolLayer(trat)
        bordo = QgsSimpleLineSymbolLayer(QColor(r, g, b, 235), 0.35)
        sym.appendSymbolLayer(bordo)
        return sym
    def _a_capo(v, larg=34):
        """Voce lunga su piu' righe (la legenda e' stretta): prima dopo
        «D.Lgs. 42/2004 -», poi a parole."""
        v = v.replace(" D.Lgs. 42/2004 - ", " D.Lgs. 42/2004\n")
        righe = []
        for pezzo in v.split("\n"):
            cur = ""
            for p in pezzo.split():
                if cur and len(cur) + 1 + len(p) > larg:
                    righe.append(cur)
                    cur = p
                else:
                    cur = (cur + " " + p).strip()
            righe.append(cur)
        return "\n".join(righe)
    if len(voci) > 1:
        vl.setRenderer(QgsCategorizedSymbolRenderer(
            "voce", [QgsRendererCategory(v, _simbolo(t), _a_capo(v)) for v, t in voci]))
        vl.setCustomProperty("rfi/titolo_nascosto", True)
    else:
        vl.setRenderer(QgsSingleSymbolRenderer(_simbolo(voci[0][1] if voci else "")))
        if voci:
            vl.setCustomProperty("rfi/titolo_legenda", _a_capo(voci[0][0]))
    return L._aggiungi_base(project, vl)


# --------------------------------------------------------------------------- #
#  API
# --------------------------------------------------------------------------- #
def genera_pl_acque(project, ist, comune, out_pdf, corsi=None, alvei=None, fasce=None,
                    ente="", orto_id=None, esporta=True, cartella_utente=None,
                    cartella_sezioni=None, cartella_foto=None, log=None, costa=None,
                    vincolo=None):
    """Layout 'ACQUE PL - <istanza>' e PDF. `corsi` = tutti i CorsoAcqua
    caricati nella scheda (per evidenziare quello dell'istanza e mostrare gli
    altri), `fasce` = {categoria: metri}. Ritorna True se il PDF e' scritto.
    `vincolo` (schede Soprintendenza e Parchi / Natura 2000): al posto dei
    corsi d'acqua le aree vincolate tratteggiate, {'aree': [AreaVincolo],
    'prefisso', 'titolo_legenda', 'tipologia_cartiglio', 'linea_cartiglio'};
    in tavola il FOTOINSERIMENTO al posto della sezione."""
    if not ist.interferenze:
        return False
    avvisa = log or (lambda _t: None)
    corsi = corsi or []
    fasce = dict(A.FASCIA_PREDEFINITA, **(fasce or {}))
    if not ist.tavole:
        ist.tavole = A.tavole_per_zona(ist.interferenze)
        ist.interferenze = [i for t in ist.tavole for i in t]
    home = project.homePath() or os.path.dirname(project.fileName() or "")
    cart_sez = [cartella_sezioni, os.path.join(home, "05_Sezioni") if home else None,
                cartella_utente, os.path.join(L.ASSETS, "rfi_sezioni")]
    cart_foto = [cartella_foto, os.path.join(home, "04_Foto") if home else None, cartella_utente]
    cart_part = [cartella_utente, os.path.join(L.ASSETS, "rfi_particolari")]

    # foto e sezioni di questa istanza: prima la sua sottocartella (04_Foto/SP28,
    # 05_Sezioni/<linea>…), poi la cartella; i punti di altre istanze no
    nomi_ist = L.nomi_istanza(ist)
    cart_sez = L.cartelle_istanza(cart_sez, nomi_ist)
    cart_foto = L.cartelle_istanza(cart_foto, nomi_ist)

    lon0 = sum(i.lon for i in ist.interferenze) / len(ist.interferenze)
    crs = L._crs_metrico(project, lon0)
    wgs = QgsCoordinateReferenceSystem("EPSG:4326")
    tr = QgsCoordinateTransform(wgs, crs, project)
    tr_inv = QgsCoordinateTransform(crs, wgs, project)
    pref = "%s tavole %s" % ((vincolo or {}).get("prefisso", "ACQUE"), ist.nome_base)

    # corso d'acqua dell'istanza: con nome = tutto il corso; senza nome = i
    # tratti vicini alle interferenze (sono fossi diversi con lo stesso nome)
    from shapely.geometry import Point
    cat = ist.interferenze[0].categoria
    cats = {i.categoria for i in ist.interferenze}
    punti = [Point(i.lon, i.lat) for i in ist.interferenze]
    miei, altri = [], []
    for c in ([] if vincolo else corsi):
        chiavi = ist.corsi_chiavi or [ist.corso]
        stesso = A.nome_corso_istanza(c.nome, c.categoria) in chiavi and c.categoria in cats
        # senza nome: solo i fossi dove ci sono davvero le interferenze (il
        # punto dell'interferenza sta in fascia, entro fascia + qualche metro)
        soglia = (fasce.get(c.categoria, 10.0) + 8.0) / 111000.0
        if stesso and (A._con_nome(c.nome) or c.categoria == "marittimo"
                       or min(c.geom.distance(p) for p in punti) < soglia):
            miei.append(c)
        else:
            altri.append(c)
    # in PL solo il corso d'acqua dell'istanza: gli altri canali e fiumi non
    # c'entrano con la pratica e confondevano (layer creato ma non stampato)
    if vincolo:
        # aree vincolate tratteggiate al posto del corso d'acqua e della fascia
        # ritaglio: le interferenze dell'istanza + ~3 km (copre corografia e tavole)
        from shapely.geometry import box as _box
        xs = [i.lon for i in ist.interferenze]
        ys = [i.lat for i in ist.interferenze]
        ritaglio = _box(min(xs) - 0.04, min(ys) - 0.03, max(xs) + 0.04, max(ys) + 0.03)
        corso_l = _layer_vincoli(project, pref, vincolo.get("aree") or [],
                                 vincolo.get("titolo_legenda") or "VINCOLI", ritaglio)
        fascia_l = None
    else:
        corso_l, altri_l, fascia_l = _layer_corsi(project, pref, miei, altri, alvei or [],
                                                  fasce, costa=list(corsi) + list(costa or []))
    altri_l = None
    num_l, et_l = _layer_interferenze(project, pref, ist)

    infra = L._trova(project, "03 INFRASTRUTTURE")
    pozz = L._trova(project, "02_POZZETTO")
    arm = L._trova(project, "01_ARMADIO OTTICO")
    # «solo armadi» (Soprintendenza): in planimetria l'armadio con il suo scavo
    # e il suo pozzetto, anche se nei conteggi entrano solo gli armadi
    rete_ist = getattr(ist, "interferenze_pl", None) or ist.interferenze
    fid_tratte = {f for i in rete_ist for f in i.tratte_fid}
    fid_pozz = {e.get("fid") for i in rete_ist for e in i.elementi
                if e.get("tipo") in ("pozzetto", "pozzetto_fuori")}
    fid_arm = {e.get("fid") for i in rete_ist for e in i.elementi
               if e.get("tipo") in ("armadio", "armadio_fuori")}
    da_gruppo = rete_dal_gruppo(project, ist, L.copia_filtrata, pref, avvisa)
    if da_gruppo:
        infra, pozz, arm = da_gruppo
        fid_tratte = fid_tratte or {"gruppo"}
        rete_sempre_visibile(infra)
    else:   # mai la rete intera: fuori dall'istanza (suolo comunale) non si stampa
        infra = L.copia_filtrata(project, infra, fid_tratte, pref) or infra
        rete_sempre_visibile(infra)
        pozz = L.copia_filtrata(project, pozz, fid_pozz, pref) if pozz is not None else None
        arm = L.copia_filtrata(project, arm, fid_arm, pref) if arm is not None else None
    if fid_tratte:
        # in planimetria solo le etichette del plugin: quelle del progetto
        # ("Mt. 2", "MT 5"...) si sommavano e si accavallavano
        for l in (infra, pozz, arm):
            if l is not None:
                l.setLabelsEnabled(False)
    # la rete dell'istanza (scavi, pozzetti, armadi) anche sull'ortofoto
    rete_orto = L.rete_ortofoto(project, pref, infra, pozz, arm) if fid_tratte else []
    base = L._base_stampe(project)
    orto = L._ortofoto(project, orto_id)
    catasto = L._catasto_stampe(project)
    foto_l = next((l for n in L.NOMI_LAYER_FOTO for l in project.mapLayersByName(n)), None)
    sez_l = next((l for n in L.NOMI_LAYER_SEZIONI for l in project.mapLayersByName(n)), None)
    cart_img = os.path.join(os.path.dirname(out_pdf) or ".", "_immagini_tavole")

    nome_file = os.path.basename(out_pdf)
    corso_txt = ist.corso if A._con_nome(ist.corso) else ist.corso
    dati = {"comune": comune.nome, "tipologia_cartiglio": (ente or "").upper(),
            "linea_cartiglio": ("«%s»" % corso_txt).upper(),
            "data": datetime.date.today().strftime("%m/%Y"), "nome_file": nome_file,
            # "demanio" in legenda era fuorviante: si dice cosa sono le linee
            "titolo_legenda_ente": "COSTA" if cat == "marittimo" else "CORSI D'ACQUA"}
    if vincolo:
        dati.update({"tipologia_cartiglio": vincolo.get("tipologia_cartiglio") or
                     (ente or "").upper(),
                     "linea_cartiglio": vincolo.get("linea_cartiglio") or "",
                     "titolo_legenda_ente": vincolo.get("titolo_legenda") or "VINCOLI"})

    nome_layout = "%s PL - %s" % ((vincolo or {}).get("prefisso", "ACQUE"), ist.nome_base)
    mgr = project.layoutManager()
    vecchio = mgr.layoutByName(nome_layout)
    if vecchio is not None:
        mgr.removeLayout(vecchio)
    layout = QgsPrintLayout(project)
    layout.initializeDefaults()
    layout.setName(nome_layout)
    pc = layout.pageCollection()
    pc.pages()[0].setPageSize(QgsLayoutSize(L.PAGINA[0], L.PAGINA[1], MM))

    disponibili = []
    for chiave in L.particolari_necessari(ist):
        nomi = [chiave] + ([L.LIBRERIA_PC[chiave]] if chiave in L.LIBRERIA_PC else [])
        f = L.cerca_file(nomi, cart_part)
        if f:
            w_, h_ = L.dimensioni_svg(f)
            disponibili.append((chiave, f, w_, h_))
    area_w = L.PAGINA[0] - 2 * L.MARGINE - L.CART_W - 4
    area_h = L.PAGINA[1] - 2 * L.MARGINE
    _, impag_pc = L.impagina_particolari(disponibili, area_w - 8, area_h - 8)

    def _rect(lista, margine=40):
        r = None
        for i in lista:
            g_ = QgsGeometry.fromRect(QgsRectangle(*i.bbox)) if i.bbox else \
                QgsGeometry.fromPointXY(QgsPointXY(i.lon, i.lat))
            g_.transform(tr)
            b = g_.boundingBox()
            if r is None:
                r = QgsRectangle(b)
            else:
                r.combineExtentWith(b)
        r.grow(margine)
        return r

    M = L.MARGINE
    tit = 6.0
    gap = 6.0
    # stralcio catastale: il corso d'acqua solo come nome, senza la linea
    nome_l = None if vincolo else _layer_solo_nome(project, pref, corso_l)
    # tavole: quattro riquadri come RFI, tutte alla STESSA scala (la piu'
    # grande che serve), cosi' in corografia le zone sono riquadri uguali
    col_w = (area_w - gap) / 2.0
    riga_h = (area_h - 2 * tit - gap) / 2.0
    def _rect_punti(lista, margine):
        """Riquadro dei PUNTI delle interferenze (+ margine per le etichette),
        come in ftth_acque.tavole_per_zona: le tavole sono pensate cosi'."""
        pts = [tr.transform(QgsPointXY(i.lon, i.lat)) for i in lista]
        r = QgsRectangle(min(p.x() for p in pts), min(p.y() for p in pts),
                         max(p.x() for p in pts), max(p.y() for p in pts))
        r.grow(margine)
        return r
    s_pl = max(L._scala_che_contiene(_rect_punti(tav, A.MARGINE_TAVOLA_M), col_w, riga_h, 1000)
               for tav in ist.tavole)
    dxv, dyv = col_w * s_pl / 2000.0, riga_h * s_pl / 2000.0
    centri = [_rect_punti(tav, 0).center() for tav in ist.tavole]
    riquadri = [QgsRectangle(c.x() - dxv, c.y() - dyv, c.x() + dxv, c.y() + dyv) for c in centri]
    # una sezione per tavola: se nel riquadro di una zona ci sono più sezioni
    # disegnate, una tavola per sezione, centrata sulla sezione (stessa scala)
    senza_sez = bool(vincolo) and (vincolo or {}).get("riquadro", "fotoinserimento") in (
        "fotoinserimento", "solo_foto")
    tav_pl = []          # (interferenze della zona, centro, riquadro, sezioni)
    assegn = [[] for _ in riquadri] if senza_sez else L.assegna_sezioni(
        project, sez_l, crs, riquadri, centri, nomi_ist)
    for tav, c_, q_, secs in zip(ist.tavole, centri, riquadri, assegn):
        if len(secs) <= L.SEZIONI_PER_TAVOLA:
            tav_pl.append((tav, c_, q_, secs))
            continue
        a_crs = QgsCoordinateTransform(sez_l.crs(), crs, project)
        for n0, f in enumerate(secs):
            if n0 == 0:
                tav_pl.append((tav, c_, q_, [f]))
                continue
            g_ = QgsGeometry(f.geometry())
            g_.transform(a_crs)
            cs = g_.boundingBox().center()
            tav_pl.append((tav, cs, QgsRectangle(cs.x() - dxv, cs.y() - dyv,
                                                 cs.x() + dxv, cs.y() + dyv), [f]))
        avvisa("%d sezioni nella stessa tavola: una tavola per sezione" % len(secs))
    centri = [t[1] for t in tav_pl]
    riquadri = [t[2] for t in tav_pl]
    n_pagine = 1 + len(tav_pl) + len(impag_pc)
    for _ in range(n_pagine - 1):
        p = QgsLayoutItemPage(layout)
        p.setPageSize(QgsLayoutSize(L.PAGINA[0], L.PAGINA[1], MM))
        pc.addPage(p)
    aree_l = _layer_aree(project, pref, ist, tr, tr_inv, riquadri)
    # ---- pagina 1: COROGRAFIA, meta' su cartografia e meta' su ortofoto ----
    r_all = None
    for q in riquadri:
        r_all = QgsRectangle(q) if r_all is None else (r_all.combineExtentWith(q) or r_all)
    r_all.grow(150)
    mezza = (area_h - 2 * tit - gap) / 2.0
    # Soprintendenza / Parchi: geoportale consultato (link e/o estratto della
    # mappa dei vincoli) a lato delle due corografie, che si stringono
    geo = (vincolo or {}).get("geoportale") or {}
    geo_link = (geo.get("link") or "").strip()
    geo_img = (geo.get("immagine") or "").strip()
    if geo_img and not os.path.isfile(geo_img):
        avvisa("estratto del geoportale non trovato: %s" % geo_img)
        geo_img = ""
    area_w_tot = area_w
    if geo_img:
        area_w = area_w_tot * 0.66
    s_coro = max(2000, L._scala_che_contiene(r_all, area_w, mezza, 2000))
    if geo_img:
        gx, gw = M + area_w + gap, area_w_tot - area_w - gap
        L._lbl(layout, 0, gx, M, gw, tit, "ESTRATTO DAL GEOPORTALE", 9, True)
        h_link = 16 if geo_link else 0
        h_img = area_h - tit - h_link - (gap if geo_link else 0)
        # riquadro alto quanto serve all'immagine (screenshot orizzontale:
        # niente spazio vuoto sotto), il link subito sotto
        try:
            from qgis.PyQt.QtGui import QImageReader
            dim = QImageReader(geo_img).size()
            if dim.width() > 0:
                h_img = min(h_img, (gw - 2) * dim.height() / float(dim.width()) + 2)
        except Exception:  # noqa: BLE001
            pass
        L._box(layout, 0, gx, M + tit, gw, h_img, 0.3)
        L._immagine(layout, 0, gx + 1, M + tit + 1, gw - 2, h_img - 2, geo_img)
        if geo_link:
            L._lbl(layout, 0, gx, M + tit + h_img + gap, gw, h_link,
                   "Fonte: %s\nConsultato il %s" % (geo_link, dati.get("data", "")),
                   7, False, Qt.AlignLeft, frame=True)
    L._lbl(layout, 0, M, M, area_w, tit, "COROGRAFIA SU CARTOGRAFIA - SCALA 1:%d" % s_coro, 9, True)
    if vincolo:
        nomi_coro, corso_coro = None, corso_l
    else:
        nomi_coro = _layer_nomi_corti(project, pref, miei, s_coro)
        corso_coro = _copia_nomi_sempre(project, pref, corso_l)
    # demanio marittimo: in corografia anche la fascia, cosi' si vede da dove
    # partono i 30 m (dividente) e fin dove arrivano
    fascia_coro = fascia_l if cat == "marittimo" else None
    m_coro = L._mappa(layout, 0, M, M + tit, area_w, mezza, crs,
                      [aree_l, nomi_coro, corso_coro, altri_l, fascia_coro] + base,
                      r_all.center(), s_coro)
    _nord(layout, 0, M + area_w - 20, M + tit + 3, m_coro, 14)
    y_or = M + tit + mezza + gap
    L._lbl(layout, 0, M, y_or, area_w, tit, "COROGRAFIA SU ORTOFOTO - SCALA 1:%d" % s_coro, 9, True)
    L._mappa(layout, 0, M, y_or + tit, area_w, mezza, crs,
             [aree_l, nomi_coro, corso_coro, fascia_coro, orto], r_all.center(), s_coro)
    if geo_link and not geo_img:
        # solo il link: una riga in basso a sinistra sull'ortofoto
        L._lbl(layout, 0, M + 2, y_or + tit + mezza - 9, min(area_w * 0.6, 160), 7,
               "Vincoli dal geoportale: %s (consultato il %s)" % (geo_link, dati.get("data", "")),
               7, False, Qt.AlignLeft, frame=True).setBackgroundEnabled(True)
    area_w = area_w_tot
    L._cartiglio(layout, 0, dati, "COROGRAFIA", "1:%d" % s_coro, legenda_map=m_coro,
                 legenda_layers=[corso_coro, altri_l, fascia_coro, aree_l])
    if not vincolo and cat == "marittimo" and not any(c.fonte != A.FONTE_OSM for c in miei):
        avvisa("ATTENZIONE: manca la dividente demaniale, la fascia dei 30 m parte dalla linea "
               "di costa OSM (in legenda è scritto). Prima di inviare carica la dividente "
               "(es. SITR) al punto B1 e rigenera.")

    # ---- tavole per zona: quattro riquadri come le tavole RFI ----
    # Soprintendenza e Parchi: «interventi», non «interferenze»
    voce_leg = ("INTERVENTI", "Intervento") if vincolo and vincolo.get("titolo_legenda") != \
        "STRADA" else ()
    x1, x2 = M, M + col_w + gap
    y1, y2 = M, M + tit + riga_h + gap
    mezza_r = (riga_h - tit - 3) / 2.0
    for k, (tav, c_pl, vis, sez_fisse) in enumerate(tav_pl, 1):
        pag = k
        # etichette della tavola: una per OGNI interferenza inquadrata (anche
        # di altre tavole, se cade nel riquadro), posizionate senza
        # sovrapposizioni ne' linee di richiamo incrociate
        linee_ost, box_ost = _ostacoli_tavola(
            project, vis, c_pl, s_pl, col_w, riga_h, crs,
            [(infra, 3000)] + ([] if vincolo else [(corso_l, 1500), (fascia_l, 120)]),
            [pozz, arm])
        et_k = _etichette_tavola(project, pref, k, ist, et_l, vis, c_pl, s_pl, col_w, riga_h,
                                 tr, tr_inv, linee_ost, box_ost)
        foto_in = L.feature_nel_riquadro(project, foto_l, crs, vis, c_pl, istanza=nomi_ist)
        sez_in = [(f, 0.0) for f in sez_fisse]     # ogni sezione in una tavola
        foto_c = L.copia_filtrata(project, foto_l, [f.id() for f, _ in foto_in],
                                  "%s %d" % (pref, k), "Punto di ripresa fotografica",
                                  "rilievo") if foto_in else None
        sez_c = L.copia_filtrata(project, sez_l, [f.id() for f, _ in sez_in],
                                 "%s %d" % (pref, k), "Sezione", "rilievo") if sez_in else None
        # ORTOFOTO (in alto a sinistra): stessa scala e stesso inquadramento
        # della planimetria e del catastale
        s_or = s_pl
        L._lbl(layout, pag, x1, y1, col_w, tit, "ORTOFOTO - SCALA 1:%d" % s_or, 9, True)
        L._mappa(layout, pag, x1, y1 + tit, col_w, riga_h, crs,
                 [num_l] + rete_orto + [corso_l, orto], c_pl, s_or)
        # PLANIMETRIA (in alto a destra)
        L._lbl(layout, pag, x2, y1, col_w, tit, "PLANIMETRIA%s - SCALA 1:%d" % (
            " - AREA ARMADIO" if getattr(ist, "solo_armadi", False) else "", s_pl), 9, True)
        m_pl = L._mappa(layout, pag, x2, y1 + tit, col_w, riga_h, crs,
                        [et_k, foto_c, sez_c, pozz, arm, infra, corso_l, altri_l,
                         fascia_l] + base, c_pl, s_pl)
        _nord(layout, pag, x2 + col_w - 13, y1 + tit + 2, m_pl, 11)
        # STRALCIO CATASTALE (in basso a sinistra): il corso d'acqua solo col nome
        s_cat = s_pl
        c0 = tr_inv.transform(c_pl)
        foglio = L.foglio_catastale(c0.y(), c0.x())
        L._lbl(layout, pag, x1, y2, col_w, tit, "STRALCIO CATASTALE%s - SCALA 1:%d"
               % (" - FOGLIO %s" % foglio if foglio else "", s_cat), 9, True)
        png = L.render_png(project, [num_l, nome_l] + catasto, crs, c_pl, s_cat, col_w, riga_h,
                           os.path.join(cart_img, "catasto_%s_%d.png" % (ist.nome_base, k)))
        if png:
            L._immagine(layout, pag, x1, y2 + tit, col_w, riga_h, png)
            L._box(layout, pag, x1, y2 + tit, col_w, riga_h, 0.3)
        else:
            L._mappa(layout, pag, x1, y2 + tit, col_w, riga_h, crs, [num_l, nome_l] + catasto,
                     c_pl, s_cat)
        if vincolo and vincolo.get("riquadro") == "solo_foto":
            # Soprintendenza: niente sezione né fotoinserimento, tutto il
            # riquadro in basso a destra alle foto dei punti di ripresa: 1 posto
            # (tutto il riquadro), 2 (uno sopra l'altro) o 4 (griglia 2x2)
            n_ft = int(vincolo.get("foto_per_tavola") or 2)
            posti = 4 if n_ft >= 4 else (1 if n_ft <= 1 else 2)
            foto = []
            for f, _d in foto_in:
                n = L.numero_foto(foto_l, f)
                p = L.cerca_file(L.nomi_file_foto(n), cart_foto) if n else None
                if p:
                    foto.append((titolo_da_file(p, "FOTO %s" % n), p))
                elif n:
                    avvisa("tavola %d: punto di ripresa FOTO %s senza file FOTO-%s.jpg in "
                           "04_Foto" % (k, n, n))
            if len(foto) > posti:
                avvisa("tavola %d: %d foto, in tavola ne stanno %d (scegli 4 foto per tavola "
                       "nella scheda)" % (k, len(foto), posti))
                foto = foto[:posti]
            L._lbl(layout, pag, x2, y2, col_w, tit,
                   " - ".join(t for t, _ in foto) if foto else "FOTO", 9, True)
            L._box(layout, pag, x2, y2 + tit, col_w, riga_h)
            col, righe = {1: (1, 1), 2: (1, 2)}.get(posti, (2, 2))
            g_ = 2.0
            w_c = (col_w - 2 - g_ * (col - 1)) / col
            h_c = (riga_h - 2 - g_ * (righe - 1)) / righe
            for n_f in range(posti):
                cx_, ry_ = n_f % col, n_f // col
                xx, yy = x2 + 1 + cx_ * (w_c + g_), y2 + tit + 1 + ry_ * (h_c + g_)
                if n_f < len(foto):
                    p = L.foto_ritagliata(foto[n_f][1], w_c, h_c, cart_img)
                    L._immagine(layout, pag, xx, yy, w_c, h_c, p)
                else:
                    L._box(layout, pag, xx, yy, w_c, h_c, 0.15)
                    L._lbl(layout, pag, xx, yy, w_c, h_c,
                           "Foto da inserire: punto di ripresa nella planimetria con "
                           "FOTO-n.jpg in 04_Foto", 7, colore=QColor(150, 150, 150))
            if not foto:
                avvisa("tavola %d: nessuna foto" % k)
            L._cartiglio(layout, pag, dati, "%d" % k, "1:%d" % s_pl, legenda_map=m_pl,
                         legenda_layers=[infra, pozz, arm, foto_c, corso_l, altri_l, fascia_l])
            _voce_interferenze(layout, pag, *voce_leg)
            continue
        # SEZIONE (in basso a destra, sopra): SOLO quella disegnata in QGIS nel
        # layer Sezioni (come RFI), file 05_Sezioni/SEZIONE <sigla>; il titolo
        # e' il nome del file. Niente sezione tipo al suo posto.
        sez, tit_sez = None, "SEZIONE"
        fotoins = bool(vincolo) and vincolo.get("riquadro", "fotoinserimento") == "fotoinserimento"
        if fotoins:
            # vincoli: al posto della sezione il FOTOINSERIMENTO (foto con
            # armadio o scavo inseriti, preparata fuori dal plugin)
            tit_sez = "FOTOINSERIMENTO"
            p = L.cerca_file(["FOTOINSERIMENTO %d" % k, "FOTOINSERIMENTO_%d" % k,
                              "FOTOINSERIMENTO-%d" % k, "FOTOINSERIMENTO"],
                             cart_foto + cart_sez)
            if p:
                sez, tit_sez = p, titolo_da_file(p, "FOTOINSERIMENTO %d" % k)
            sez_in = []
        for f, _d in sez_in:
            sigla = L.sigla_sezione(sez_l, f)
            if not sigla:
                continue
            p = L.cerca_file(["SEZIONE %s" % sigla, "SEZIONE_%s" % sigla, sigla], cart_sez)
            if p:
                sez, tit_sez = p, titolo_da_file(p, "SEZIONE %s" % sigla)
                break
            avvisa("tavola %d: sezione %s disegnata ma file 'SEZIONE %s' non trovato in "
                   "05_Sezioni" % (k, sigla, sigla))
        L._lbl(layout, pag, x2, y2, col_w, tit, tit_sez, 9, True)
        L._box(layout, pag, x2, y2 + tit, col_w, mezza_r)
        if sez:
            if fotoins:
                sez = L.foto_ritagliata(sez, col_w - 2, mezza_r - 2, cart_img)
            L._immagine(layout, pag, x2 + 1, y2 + tit + 1, col_w - 2, mezza_r - 2, sez)
        elif fotoins:
            L._lbl(layout, pag, x2, y2 + tit, col_w, mezza_r,
                   "Fotoinserimento da inserire: foto con l'armadio o lo scavo inseriti, "
                   "salvata come FOTOINSERIMENTO %d.jpg in 04_Foto" % k,
                   7, colore=QColor(150, 150, 150))
            avvisa("tavola %d: manca FOTOINSERIMENTO %d.jpg in 04_Foto" % (k, k))
        else:
            L._lbl(layout, pag, x2, y2 + tit, col_w, mezza_r,
                   "Sezione da inserire: traccia la sezione nel layer Sezioni (sezione = A) "
                   "dentro la planimetria e metti il disegno SEZIONE A-A'.svg in 05_Sezioni",
                   7, colore=QColor(150, 150, 150))
            avvisa("tavola %d: nessuna sezione disegnata nel layer Sezioni" % k)
        # FOTO (in basso a destra, sotto): SOLO dai punti di ripresa piazzati in
        # QGIS dentro la planimetria (come RFI); titolo dal nome del file
        yf = y2 + tit + mezza_r + 3
        foto = []
        for f, _d in foto_in:
            n = L.numero_foto(foto_l, f)
            p = L.cerca_file(L.nomi_file_foto(n), cart_foto) if n else None
            if p:
                foto.append((titolo_da_file(p, "FOTO %s" % n), p))
            elif n:
                avvisa("tavola %d: punto di ripresa FOTO %s senza file FOTO-%s.jpg in 04_Foto"
                       % (k, n, n))
            if len(foto) == 2:
                break
        L._lbl(layout, pag, x2, yf, col_w, tit,
               " - ".join(t for t, _ in foto) if foto else "FOTO", 9, True)
        L._box(layout, pag, x2, yf + tit, col_w, mezza_r)
        if foto:
            w_ft = (col_w - 2 - 2 * (len(foto) - 1)) / len(foto)
            for n_f, (_t, p) in enumerate(foto):
                p = L.foto_ritagliata(p, w_ft, mezza_r - 2, cart_img)
                L._immagine(layout, pag, x2 + 1 + n_f * (w_ft + 2), yf + tit + 1,
                            w_ft, mezza_r - 2, p)
        else:
            L._lbl(layout, pag, x2, yf + tit, col_w, mezza_r,
                   "Foto da inserire: punto di ripresa nel riquadro della planimetria con "
                   "FOTO-n.jpg in 04_Foto", 7, colore=QColor(150, 150, 150))
            avvisa("tavola %d: nessuna foto" % k)
        L._cartiglio(layout, pag, dati, "%d" % k, "1:%d" % s_pl, legenda_map=m_pl,
                     legenda_layers=[infra, pozz, arm, foto_c, sez_c, corso_l, altri_l,
                                     fascia_l])
        _voce_interferenze(layout, pag, *voce_leg)

    # ---- particolari costruttivi ----
    for n_pag, pezzi in enumerate(impag_pc):
        pag = 1 + len(tav_pl) + n_pag
        L._box(layout, pag, M, M, area_w, area_h, 0.3)
        larg = max((x + w for _, _, x, _, w, _ in pezzi), default=0)
        alt = max((y + h for _, _, _, y, _, h in pezzi), default=0)
        ox = M + (area_w - larg) / 2.0
        oy = M + (area_h - alt) / 2.0
        for _chiave, f, x, y, w, h in pezzi:
            L._immagine(layout, pag, ox + x, oy + y, w, h, f)
        L._cartiglio(layout, pag, dati, "PC" + (" %d" % (n_pag + 1) if len(impag_pc) > 1 else ""),
                     "NON IN SCALA")

    mgr.addLayout(layout)
    if not esporta:
        return True
    os.makedirs(os.path.dirname(out_pdf) or ".", exist_ok=True)
    exp = QgsLayoutExporter(layout)
    s = QgsLayoutExporter.PdfExportSettings()
    s.dpi = 200
    try:
        from qgis.core import Qgis
        s.textRenderFormat = Qgis.TextRenderFormat.AlwaysText
    except Exception:  # noqa: BLE001
        pass
    r = exp.exportToPdf(out_pdf, s)
    return r == QgsLayoutExporter.Success and os.path.isfile(out_pdf)
