"""Quadro delle pratiche: dagli enti dello screening del territorio alle
istanze da presentare, per categoria (logica, senza QGIS).

Lo screening sa gia' distinguere (ftth_screening.classifica_enti_impatto) gli
enti la cui competenza e' TOCCATA dalla rete in progetto da quelli solo
PRESENTI nel comune e da quelli NON VERIFICABILI con i dati raccolti. Il
quadro raggruppa queste voci per categoria, dice quale scheda del plugin
prepara la pratica e tiene lo stato di ciascuna (da fare, generata,
inviata...), salvato nel progetto.
"""
import datetime

# (chiave, titolo, scheda del plugin che prepara la pratica o None)
CATEGORIE = [
    ("strade", "Strade e suolo pubblico", "Istanze Strade"),
    ("ferrovie", "Ferrovie", "Istanze RFI"),
    ("acque", "Acque", "Istanze Acque"),
    ("paesaggio", "Beni culturali e paesaggio", "Istanze Soprintendenza"),
    ("natura", "Parchi e Natura 2000", "Istanze Parchi / Natura 2000"),
    ("idrogeo", "Rischio idrogeologico", None),
    ("altri", "Altri enti", None),
]
TITOLO = {k: t for k, t, _s in CATEGORIE}
SCHEDA = {k: s for k, _t, s in CATEGORIE}
ORDINE = {k: n for n, (k, _t, _s) in enumerate(CATEGORIE)}

# stesso significato delle costanti di ftth_screening (IMPATTO_*)
IMPATTO_RETE, IMPATTO_TERRITORIO, IMPATTO_IGNOTO = "impatto", "territorio", "ignoto"
IMPATTO_TESTO = {
    IMPATTO_RETE: "Sì",
    IMPATTO_IGNOTO: "Da verificare",
    IMPATTO_TERRITORIO: "No, solo nel comune",
}
ORDINE_IMPATTO = {IMPATTO_RETE: 0, IMPATTO_IGNOTO: 1, IMPATTO_TERRITORIO: 2}

# "" = stato non ancora scelto: lo sceglie l'utente (prima si partiva da
# «da fare» / «da verificare» / «non necessaria» secondo lo screening)
STATI = ["", "da fare", "da verificare", "in preparazione", "generata", "non necessaria"]
# stati tolti su richiesta dell'utente: nei progetti gia' salvati valgono «generata»
_STATI_VECCHI = {"inviata": "generata", "autorizzata": "generata"}
STATO_INIZIALE = {IMPATTO_RETE: "da fare", IMPATTO_IGNOTO: "da verificare",
                  IMPATTO_TERRITORIO: "non necessaria"}

# provenienza della voce nello screening (_origine) -> categoria
_ORIGINE = {
    "comune": "strade", "strada": "strade",
    "ferrovia": "ferrovie", "ferrovia_dismessa": "ferrovie",
    "idrico_attraversato": "acque", "idrico_prossimita": "acque",
    "idrico_non_misurato": "acque", "bonifica": "acque",
    "soprintendenza": "paesaggio", "vincolo": "paesaggio",
    "boschi_misurati": "paesaggio", "boschi_non_misurati": "paesaggio",
    "natura2000": "natura", "parchi": "natura",
    "idrogeologico": "idrogeo",
}


def categoria_ente(e: dict) -> str:
    org = e.get("_origine") or ""
    if org == "vincolo":
        k = (e.get("_chiave_vincolo") or "").lower()
        if "idrogeo" in k or "pai" in k:
            return "idrogeo"
        if "parc" in k or "natura" in k or "zsc" in k or "zps" in k:
            return "natura"
    if org in _ORIGINE:
        return _ORIGINE[org]
    # voci aggiunte da classifica_enti_impatto (strade fuori fascia) non hanno
    # _origine ma hanno la scheda della strada
    sc = e.get("scheda") or {}
    if "strad" in str(sc.get("descrizione", "")).lower() or \
            "strad" in str(e.get("ruolo", "")).lower():
        return "strade"
    return "altri"


def chiave_voce(cat: str, e: dict) -> str:
    """Chiave stabile della voce: lo stato scelto dall'utente resta attaccato
    alla stessa pratica anche rifacendo lo screening."""
    return "%s|%s|%s" % (cat, str(e.get("ente") or "").strip().lower(),
                         str(e.get("ruolo") or "").strip().lower())


def voci_da_screening(rep: dict, classifica, oggi=None) -> dict:
    """{comune, data, modo, voci: [...]} dal report dello screening.
    `classifica` = ftth_screening.classifica_enti_impatto (passata da fuori per
    non legare questo modulo alla rete)."""
    modo, gruppi = classifica(rep)
    voci = []
    for imp, lst in gruppi.items():
        for e, motivo in lst:
            cat = categoria_ente(e)
            voci.append({
                "chiave": chiave_voce(cat, e),
                "categoria": cat,
                "ente": str(e.get("ente") or ""),
                "ruolo": str(e.get("ruolo") or ""),
                "motivo": str(motivo or e.get("trigger") or ""),
                "impatto": imp,
                "pec": str((e.get("contatti") or {}).get("pec") or ""),
                "livello": e.get("livello", 9) if isinstance(e.get("livello"), int) else 9,
            })
    voci.sort(key=lambda v: (ORDINE.get(v["categoria"], 99),
                             ORDINE_IMPATTO.get(v["impatto"], 9), v["livello"], v["ente"]))
    c = rep.get("comune") or {}
    return {"comune": c.get("nome") or "", "provincia": c.get("provincia") or "",
            "regione": c.get("regione") or "",
            "data": (oggi or datetime.date.today()).strftime("%d/%m/%Y"),
            "modo": modo, "voci": voci}


def stato_voce(voce: dict, stati: dict) -> str:
    s = (stati.get(voce["chiave"]) or {}).get("stato")
    s = _STATI_VECCHI.get(s, s)
    return s if s in STATI else ""


def riepilogo(quadro: dict, stati: dict) -> dict:
    """{categoria: {'da_presentare': n, 'fatte': n, 'verificare': n}} per il
    titolo di ogni categoria nel quadro. Senza stato scelto conta quello che
    dice lo screening (rete toccata = da presentare)."""
    out = {}
    for v in quadro.get("voci") or []:
        r = out.setdefault(v["categoria"], {"da_presentare": 0, "fatte": 0, "verificare": 0})
        s = stato_voce(v, stati) or STATO_INIZIALE.get(v["impatto"], "da verificare")
        if s == "generata":
            r["fatte"] += 1
        elif s == "da verificare":
            r["verificare"] += 1
        elif s != "non necessaria":
            r["da_presentare"] += 1
    return out


MODO_TESTO = {
    "tracciato": "misurato sul tracciato della rete in progetto",
    "area": "misurato sull'area di progetto",
    "comune": "solo sul territorio comunale: nessun ente può dirsi toccato dalla rete, "
              "rifai lo screening con il tracciato o l'area di progetto",
}
