# -*- coding: utf-8 -*-
# © Beexact S.r.l. — Tutti i diritti riservati. Uso interno; vietata la riproduzione.
"""Tracciati sbagliati di OpenStreetMap corretti a mano, uguale in tutte le
schede istanze (Strade, Ferrovie, Acque).

Al passo 2: si seleziona la riga (strada, linea ferroviaria, corso d'acqua),
«Correggi tracciato» copia la sua geometria in un layer di correzione
(GeoPackage Istanze.gpkg del progetto) in modifica con lo strumento vertici;
«Usa i tracciati corretti» salva e restituisce {chiave: WKT}, che la scheda
tiene nel suo stato (salvato nel progetto) e riapplica a ogni nuova ricerca."""
import os

CAMPO = "chiave"


def riquadro(dlg, oggetto, slot_correggi, slot_usa):
    """Riquadro «Avanzate: il tracciato di <oggetto> in mappa è sbagliato»,
    con i passi sempre visibili e i due pulsanti: stesse parole in ogni
    scheda. `oggetto` = «una strada», «una ferrovia», «un corso d'acqua»."""
    from qgis.PyQt.QtWidgets import QHBoxLayout, QLabel, QPushButton, QVBoxLayout
    gb = dlg._gruppo("Avanzate: il tracciato di %s in mappa è sbagliato" % oggetto)
    v = QVBoxLayout(gb)
    lab = QLabel(
        "OpenStreetMap a volte ha un tracciato vecchio o sbagliato. Per correggerlo:<br>"
        "1. seleziona la riga nella tabella qui sopra e premi «Correggi tracciato»: in "
        "mappa si attiva lo strumento vertici;<br>"
        "2. sposta, aggiungi o togli i vertici della linea viola;<br>"
        "3. premi «Usa i tracciati corretti», poi rifai «Trova le interferenze» al punto 3.<br>"
        "La correzione resta nel progetto anche dopo una nuova ricerca.")
    lab.setWordWrap(True)
    v.addWidget(lab)
    r = QHBoxLayout()
    b_c = QPushButton("Correggi tracciato")
    b_c.setToolTip("Il tracciato della riga selezionata va in un layer di correzione, in "
                   "modifica, con lo strumento vertici.")
    b_c.clicked.connect(slot_correggi)
    b_u = QPushButton("Usa i tracciati corretti")
    b_u.setToolTip("Salva il layer di correzione: da ora la ricerca usa il tracciato "
                   "corretto. Poi rifai «Trova le interferenze».")
    b_u.clicked.connect(slot_usa)
    r.addWidget(b_c)
    r.addWidget(b_u)
    r.addStretch()
    v.addLayout(r)
    return gb


def layer(dlg, nome, tabella, sezione, crea=True):
    """Layer di correzione `nome` (tabella `tabella` di Istanze.gpkg), creato
    se manca, nel gruppo della sezione nel pannello Layer."""
    from qgis.core import (QgsField, QgsLineSymbol, QgsSingleSymbolRenderer,
                           QgsVectorFileWriter, QgsVectorLayer)
    from qgis.PyQt.QtCore import QVariant
    for l in dlg.project.mapLayersByName(nome):
        return l
    if not crea:
        return None
    from . import ftth_gruppi_istanze as GR
    percorso = GR.percorso_file(dlg.project)
    os.makedirs(os.path.dirname(percorso), exist_ok=True)
    mem = QgsVectorLayer("MultiLineString?crs=EPSG:4326", nome, "memory")
    mem.dataProvider().addAttributes([QgsField(CAMPO, QVariant.String)])
    mem.updateFields()
    opt = QgsVectorFileWriter.SaveVectorOptions()
    opt.driverName = "GPKG"
    opt.layerName = tabella
    opt.actionOnExistingFile = (QgsVectorFileWriter.CreateOrOverwriteLayer
                                if os.path.exists(percorso)
                                else QgsVectorFileWriter.CreateOrOverwriteFile)
    ris = QgsVectorFileWriter.writeAsVectorFormatV3(mem, percorso,
                                                    dlg.project.transformContext(), opt)
    if ris[0] != QgsVectorFileWriter.NoError:
        raise RuntimeError(ris[1] or "layer non scritto")
    lyr = QgsVectorLayer("%s|layername=%s" % (percorso, tabella), nome, "ogr")
    lyr.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
        {"line_color": "230,0,180,255", "line_width": "1.2"})))
    dlg.project.addMapLayer(lyr, False)
    GR.gruppo_sezione(dlg.project.layerTreeRoot(), sezione).insertLayer(0, lyr)
    return lyr


def inizia(dlg, nome, tabella, sezione, chiave, geom, descrizione=""):
    """Mette il tracciato `geom` (shapely WGS84) della riga `chiave` nel layer
    di correzione (se non c'è già), in modifica, e attiva lo strumento
    vertici sulla mappa. Ritorna il layer o None."""
    from qgis.core import QgsFeature, QgsGeometry
    from qgis.PyQt.QtWidgets import QMessageBox
    if geom is None or geom.is_empty:
        QMessageBox.information(dlg, "Correggi tracciato",
                                "Seleziona nella tabella la riga da correggere.")
        return None
    try:
        lyr = layer(dlg, nome, tabella, sezione)
    except Exception as e:  # noqa: BLE001
        QMessageBox.warning(dlg, "Correggi tracciato", "Layer non creato: %s" % e)
        return None
    k = lyr.fields().indexOf(CAMPO)
    esiste = next((f for f in lyr.getFeatures() if f[CAMPO] == chiave), None)
    if not lyr.isEditable():
        lyr.startEditing()
    if esiste is None:
        f = QgsFeature(lyr.fields())
        g = QgsGeometry.fromWkt(geom.wkt)
        g.convertToMultiType()
        f.setGeometry(g)
        f.setAttribute(k, chiave)
        lyr.addFeature(f)
    iface = getattr(dlg, "iface", None)
    try:
        iface.setActiveLayer(lyr)
        from . import ftth_trovati as _TR
        _TR.zoom(iface, dlg.project, geom)
        iface.actionVertexTool().trigger()
    except Exception:  # noqa: BLE001
        pass
    return lyr


def leggi(dlg, nome):
    """Salva il layer di correzione e ritorna {chiave: WKT} (None se non c'è
    il layer o il salvataggio non riesce)."""
    from qgis.PyQt.QtWidgets import QMessageBox
    lyr = layer(dlg, nome, "", "", crea=False)
    if lyr is None:
        QMessageBox.information(dlg, "Tracciati", "Nessun tracciato da usare: prima "
                                                  "«Correggi tracciato».")
        return None
    if lyr.isEditable() and not lyr.commitChanges():
        QMessageBox.warning(dlg, "Tracciati", "Salvataggio non riuscito: %s"
                            % "; ".join(lyr.commitErrors()))
        return None
    from shapely import wkt as _wkt
    out = {}
    for f in lyr.getFeatures():
        if f.hasGeometry() and f[CAMPO]:
            try:
                out[str(f[CAMPO])] = _wkt.loads(f.geometry().asWkt()).wkt
            except Exception:  # noqa: BLE001
                pass
    return out


def parti(wkt):
    """Linee (shapely) di un WKT, anche Multi."""
    from shapely import wkt as _wkt
    try:
        g = _wkt.loads(wkt)
    except Exception:  # noqa: BLE001
        return []
    return [p for p in getattr(g, "geoms", [g]) if p.geom_type == "LineString"]
