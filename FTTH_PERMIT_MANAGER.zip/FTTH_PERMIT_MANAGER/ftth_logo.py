"""Logo FiberCop «Milano Cortina 2026» al posto di quello classico.

Alcuni territori FOL lo chiedono: con il flag attivo (uno solo per progetto,
lo stesso in tutte le schede) il logo va nelle planimetrie del plugin, nei
documenti Word generati e nei layout del progetto esportati dalla scheda
Esportazione. Senza flag vale il logo classico ovunque (anche nei modelli che
avevano già quello olimpico, così i documenti restano coerenti fra loro).
"""
import hashlib
import os
import re
import zipfile

ASSETS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "assets")
PRJ_SCOPE = "ftth_logo"
PRJ_CHIAVE = "milano_cortina"

LOGO_CLASSICO = {"png": os.path.join(ASSETS, "fibercop_logo.png"),
                 "jpg": os.path.join(ASSETS, "fibercop_logo.jpg")}
LOGO_MC = {"png": os.path.join(ASSETS, "fibercop_milano_cortina.png"),
           "jpg": os.path.join(ASSETS, "fibercop_milano_cortina.jpg")}
TESTO_FLAG = "Logo FiberCop «Milano Cortina 2026» (territori FOL che lo richiedono)"

# impronte SHA1 dei loghi presenti nei modelli Word del plugin
HASH_CLASSICO = {
    "10ff8d5e3865d78a2daded69b86292fe35c335fa",   # art. 49 (con margini bianchi)
    "0712be4a730dff3fda0a77d048d57dae150b0aa3",   # art. 49 strade
    "c2bcf5159685cc403fe317da129cdaa640131f39",   # RT+CR copertina
    "ee7328b7c5d06c95d3548498bd4deac4217fc954",   # fibercop_logo.png
}
HASH_MC = {
    "32405730efca48fcab6caabfb9f13889b18ae484",   # bollo
    "6f4732a3945b7a331f97ece0ad97c342b95660cb",   # modello B
}


# --------------------------------------------------------------------- flag
def attivo(project) -> bool:
    if project is None:
        return False
    v, _ok = project.readEntry(PRJ_SCOPE, PRJ_CHIAVE, "0")
    return str(v) == "1"


def imposta(project, si: bool):
    if project is not None:
        project.writeEntry(PRJ_SCOPE, PRJ_CHIAVE, "1" if si else "0")


def crea_checkbox(dialog):
    """Casella del flag per una scheda: tutte le caselle del dialogo sono
    legate allo stesso valore del progetto e si aggiornano insieme."""
    from qgis.PyQt.QtWidgets import QCheckBox
    cb = QCheckBox(TESTO_FLAG)
    cb.setToolTip("Nelle planimetrie e nei documenti Word al posto del logo FiberCop classico "
                  "va quello «Fiber infrastructure partner of Milano Cortina 2026». La scelta "
                  "vale per tutto il progetto (stessa casella in tutte le schede) e si salva "
                  "con il progetto.")
    cb.setChecked(attivo(getattr(dialog, "project", None)))
    if not hasattr(dialog, "_caselle_logo"):
        dialog._caselle_logo = []
    dialog._caselle_logo.append(cb)

    def _cambia(si):
        imposta(getattr(dialog, "project", None), si)
        for altra in dialog._caselle_logo:
            if altra is not cb and altra.isChecked() != si:
                altra.blockSignals(True)
                altra.setChecked(si)
                altra.blockSignals(False)
    cb.toggled.connect(_cambia)
    return cb


# --------------------------------------------------------------- planimetrie
def percorso_logo(project=None, attivo_mc=None) -> str:
    """Logo FiberCop da usare nei layout del plugin."""
    mc = attivo(project) if attivo_mc is None else attivo_mc
    p = LOGO_MC["png"] if mc else LOGO_CLASSICO["png"]
    return p if os.path.isfile(p) else LOGO_CLASSICO["png"]


def scambia_logo_layout(layout, attivo_mc: bool) -> list:
    """Layout del progetto (scheda Esportazione): le immagini con il logo
    FiberCop classico puntano a quello olimpico. Ritorna [(item, percorso
    originale)] per rimettere tutto com'era dopo l'esportazione."""
    if not attivo_mc or layout is None:
        return []
    from qgis.core import QgsLayoutItemPicture
    fatti = []
    for it in layout.items():
        if not isinstance(it, QgsLayoutItemPicture):
            continue
        p = it.picturePath() or ""
        nome = os.path.basename(p).lower()
        if "fibercop" in nome and "milano" not in nome and "cortina" not in nome:
            fatti.append((it, p))
            it.setPicturePath(LOGO_MC["png"])
            it.refreshPicture()
    return fatti


def ripristina_logo_layout(fatti):
    for it, p in fatti or []:
        try:
            it.setPicturePath(p)
            it.refreshPicture()
        except Exception:  # noqa: BLE001
            pass


# ------------------------------------------------------------------ Word
def _dim_png_jpg(dati: bytes):
    """(larghezza, altezza) in pixel di un PNG o JPEG, senza librerie."""
    if dati[:8] == b"\x89PNG\r\n\x1a\n":
        return int.from_bytes(dati[16:20], "big"), int.from_bytes(dati[20:24], "big")
    i = 2
    while i < len(dati) - 9:
        if dati[i] != 0xFF:
            i += 1
            continue
        m = dati[i + 1]
        if m in (0xC0, 0xC1, 0xC2):
            return int.from_bytes(dati[i + 7:i + 9], "big"), int.from_bytes(dati[i + 5:i + 7], "big")
        i += 2 + int.from_bytes(dati[i + 2:i + 4], "big")
    return None


def applica_docx(path: str, attivo_mc: bool) -> int:
    """Nel .docx il logo FiberCop classico diventa quello olimpico (o il
    contrario se il flag è spento). L'immagine nuova sta DENTRO il riquadro
    di quella vecchia (stesse proporzioni, mai più grande), così intestazioni
    e copertine non si spostano. Ritorna quante immagini ha cambiato."""
    da_cambiare = HASH_CLASSICO if attivo_mc else HASH_MC
    nuovo = LOGO_MC if attivo_mc else LOGO_CLASSICO
    try:
        zin = zipfile.ZipFile(path)
    except (OSError, zipfile.BadZipFile):
        return 0
    with zin:
        voci = {n: zin.read(n) for n in zin.namelist()}
    sostituite = {}                       # 'media/image1.png' -> (w, h)
    for n, dati in list(voci.items()):
        if not n.startswith("word/media/"):
            continue
        if hashlib.sha1(dati).hexdigest() not in da_cambiare:
            continue
        est = "png" if n.lower().endswith(".png") else "jpg"
        if not os.path.isfile(nuovo[est]):
            continue
        with open(nuovo[est], "rb") as fh:
            img = fh.read()
        dim = _dim_png_jpg(img)
        if not dim:
            continue
        voci[n] = img
        sostituite[n[len("word/"):]] = dim
    if not sostituite:
        return 0
    # riquadri delle immagini cambiate: proporzioni del logo nuovo
    for rels in [n for n in voci if n.startswith("word/_rels/") and n.endswith(".rels")]:
        parte = "word/" + os.path.basename(rels)[:-len(".rels")]
        if parte not in voci:
            continue
        testo_rels = voci[rels].decode("utf-8")
        rid_dim = {}
        for m in re.finditer(r'<Relationship [^>]*>', testo_rels):
            tag = m.group(0)
            rid = re.search(r'Id="([^"]+)"', tag)
            tgt = re.search(r'Target="([^"]+)"', tag)
            if rid and tgt and tgt.group(1) in sostituite:
                rid_dim[rid.group(1)] = sostituite[tgt.group(1)]
        if not rid_dim:
            continue
        xml = voci[parte].decode("utf-8")

        def _blocco(m):
            b = m.group(0)
            emb = re.search(r'r:embed="([^"]+)"', b)
            if not emb or emb.group(1) not in rid_dim:
                return b
            w, h = rid_dim[emb.group(1)]
            ext = re.search(r'<wp:extent cx="(\d+)" cy="(\d+)"', b)
            if not ext:
                return b
            cx, cy = int(ext.group(1)), int(ext.group(2))
            k = min(cx / float(w), cy / float(h))
            ncx, ncy = int(w * k), int(h * k)
            b = b.replace('cx="%d" cy="%d"' % (cx, cy), 'cx="%d" cy="%d"' % (ncx, ncy))
            return b
        xml = re.sub(r'<w:drawing>.*?</w:drawing>', _blocco, xml, flags=re.S)
        voci[parte] = xml.encode("utf-8")
    tmp = path + ".tmp"
    with zipfile.ZipFile(path) as zorig, zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zout:
        for info in zorig.infolist():
            zout.writestr(info, voci[info.filename])
    os.replace(tmp, path)
    return len(sostituite)


def applica_cartella(cartella: str, attivo_mc: bool) -> int:
    """Tutti i .docx della cartella (e sottocartelle). Ritorna i file cambiati."""
    n = 0
    for radice, _d, files in os.walk(cartella or ""):
        for f in files:
            if f.lower().endswith(".docx") and not f.startswith("~$"):
                if applica_docx(os.path.join(radice, f), attivo_mc):
                    n += 1
    return n
